/*  1:   */ package org.benf.cfr.reader.entityfactories;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.entities.attributes.Attribute;
/*  4:   */ import org.benf.cfr.reader.entities.attributes.AttributeAnnotationDefault;
/*  5:   */ import org.benf.cfr.reader.entities.attributes.AttributeBootstrapMethods;
/*  6:   */ import org.benf.cfr.reader.entities.attributes.AttributeCode;
/*  7:   */ import org.benf.cfr.reader.entities.attributes.AttributeConstantValue;
/*  8:   */ import org.benf.cfr.reader.entities.attributes.AttributeDeprecated;
/*  9:   */ import org.benf.cfr.reader.entities.attributes.AttributeExceptions;
/* 10:   */ import org.benf.cfr.reader.entities.attributes.AttributeInnerClasses;
/* 11:   */ import org.benf.cfr.reader.entities.attributes.AttributeLineNumberTable;
/* 12:   */ import org.benf.cfr.reader.entities.attributes.AttributeLocalVariableTable;
/* 13:   */ import org.benf.cfr.reader.entities.attributes.AttributeLocalVariableTypeTable;
/* 14:   */ import org.benf.cfr.reader.entities.attributes.AttributeRuntimeInvisibleAnnotations;
/* 15:   */ import org.benf.cfr.reader.entities.attributes.AttributeRuntimeInvisibleParameterAnnotations;
/* 16:   */ import org.benf.cfr.reader.entities.attributes.AttributeRuntimeInvisibleTypeAnnotations;
/* 17:   */ import org.benf.cfr.reader.entities.attributes.AttributeRuntimeVisibleAnnotations;
/* 18:   */ import org.benf.cfr.reader.entities.attributes.AttributeRuntimeVisibleParameterAnnotations;
/* 19:   */ import org.benf.cfr.reader.entities.attributes.AttributeRuntimeVisibleTypeAnnotations;
/* 20:   */ import org.benf.cfr.reader.entities.attributes.AttributeScala;
/* 21:   */ import org.benf.cfr.reader.entities.attributes.AttributeScalaSig;
/* 22:   */ import org.benf.cfr.reader.entities.attributes.AttributeSignature;
/* 23:   */ import org.benf.cfr.reader.entities.attributes.AttributeSourceFile;
/* 24:   */ import org.benf.cfr.reader.entities.attributes.AttributeStackMapTable;
/* 25:   */ import org.benf.cfr.reader.entities.attributes.AttributeSynthetic;
/* 26:   */ import org.benf.cfr.reader.entities.attributes.AttributeUnknown;
/* 27:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/* 28:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryUTF8;
/* 29:   */ import org.benf.cfr.reader.util.ClassFileVersion;
/* 30:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/* 31:   */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/* 32:   */ 
/* 33:   */ public class AttributeFactory
/* 34:   */ {
/* 35:   */   private static final long OFFSET_OF_ATTRIBUTE_NAME_INDEX = 0L;
/* 36:   */   
/* 37:   */   public static Attribute build(ByteData raw, ConstantPool cp, ClassFileVersion classFileVersion)
/* 38:   */   {
/* 39:14 */     short nameIndex = raw.getS2At(0L);
/* 40:15 */     ConstantPoolEntryUTF8 name = (ConstantPoolEntryUTF8)cp.getEntry(nameIndex);
/* 41:16 */     String attributeName = name.getValue();
/* 42:22 */     if ("Code".equals(attributeName)) {
/* 43:25 */       return new AttributeCode(raw, cp, classFileVersion);
/* 44:   */     }
/* 45:   */     try
/* 46:   */     {
/* 47:29 */       if ("LocalVariableTable".equals(attributeName)) {
/* 48:30 */         return new AttributeLocalVariableTable(raw, cp);
/* 49:   */       }
/* 50:31 */       if ("Signature".equals(attributeName)) {
/* 51:32 */         return new AttributeSignature(raw, cp);
/* 52:   */       }
/* 53:33 */       if ("ConstantValue".equals(attributeName)) {
/* 54:34 */         return new AttributeConstantValue(raw, cp);
/* 55:   */       }
/* 56:35 */       if ("LineNumberTable".equals(attributeName)) {
/* 57:36 */         return new AttributeLineNumberTable(raw, cp);
/* 58:   */       }
/* 59:37 */       if ("Exceptions".equals(attributeName)) {
/* 60:38 */         return new AttributeExceptions(raw, cp);
/* 61:   */       }
/* 62:39 */       if ("Deprecated".equals(attributeName)) {
/* 63:40 */         return new AttributeDeprecated(raw, cp);
/* 64:   */       }
/* 65:41 */       if ("RuntimeVisibleAnnotations".equals(attributeName)) {
/* 66:42 */         return new AttributeRuntimeVisibleAnnotations(raw, cp);
/* 67:   */       }
/* 68:43 */       if ("RuntimeVisibleTypeAnnotations".equals(attributeName)) {
/* 69:44 */         return new AttributeRuntimeVisibleTypeAnnotations(raw, cp);
/* 70:   */       }
/* 71:45 */       if ("RuntimeInvisibleTypeAnnotations".equals(attributeName)) {
/* 72:46 */         return new AttributeRuntimeInvisibleTypeAnnotations(raw, cp);
/* 73:   */       }
/* 74:47 */       if ("RuntimeInvisibleAnnotations".equals(attributeName)) {
/* 75:48 */         return new AttributeRuntimeInvisibleAnnotations(raw, cp);
/* 76:   */       }
/* 77:49 */       if ("RuntimeVisibleParameterAnnotations".equals(attributeName)) {
/* 78:50 */         return new AttributeRuntimeVisibleParameterAnnotations(raw, cp);
/* 79:   */       }
/* 80:51 */       if ("RuntimeInvisibleParameterAnnotations".equals(attributeName)) {
/* 81:52 */         return new AttributeRuntimeInvisibleParameterAnnotations(raw, cp);
/* 82:   */       }
/* 83:53 */       if ("SourceFile".equals(attributeName)) {
/* 84:54 */         return new AttributeSourceFile(raw, cp);
/* 85:   */       }
/* 86:55 */       if ("InnerClasses".equals(attributeName)) {
/* 87:56 */         return new AttributeInnerClasses(raw, cp);
/* 88:   */       }
/* 89:57 */       if ("BootstrapMethods".equals(attributeName)) {
/* 90:58 */         return new AttributeBootstrapMethods(raw, cp);
/* 91:   */       }
/* 92:59 */       if ("AnnotationDefault".equals(attributeName)) {
/* 93:60 */         return new AttributeAnnotationDefault(raw, cp);
/* 94:   */       }
/* 95:61 */       if ("LocalVariableTypeTable".equals(attributeName)) {
/* 96:62 */         return new AttributeLocalVariableTypeTable(raw, cp);
/* 97:   */       }
/* 98:63 */       if ("StackMapTable".equals(attributeName)) {
/* 99:64 */         return new AttributeStackMapTable(raw, cp);
/* :0:   */       }
/* :1:65 */       if ("Synthetic".equals(attributeName)) {
/* :2:66 */         return new AttributeSynthetic(raw, cp);
/* :3:   */       }
/* :4:67 */       if ("ScalaSig".equals(attributeName)) {
/* :5:68 */         return new AttributeScalaSig(raw, cp);
/* :6:   */       }
/* :7:69 */       if ("Scala".equals(attributeName)) {
/* :8:70 */         return new AttributeScala(raw, cp);
/* :9:   */       }
/* ;0:   */     }
/* ;1:   */     catch (Exception e) {}
/* ;2:75 */     return new AttributeUnknown(raw, attributeName);
/* ;3:   */   }
/* ;4:   */   
/* ;5:   */   public static UnaryFunction<ByteData, Attribute> getBuilder(ConstantPool cp, ClassFileVersion classFileVersion)
/* ;6:   */   {
/* ;7:79 */     return new AttributeBuilder(cp, classFileVersion);
/* ;8:   */   }
/* ;9:   */   
/* <0:   */   private static class AttributeBuilder
/* <1:   */     implements UnaryFunction<ByteData, Attribute>
/* <2:   */   {
/* <3:   */     private final ConstantPool cp;
/* <4:   */     private final ClassFileVersion classFileVersion;
/* <5:   */     
/* <6:   */     public AttributeBuilder(ConstantPool cp, ClassFileVersion classFileVersion)
/* <7:   */     {
/* <8:87 */       this.cp = cp;
/* <9:88 */       this.classFileVersion = classFileVersion;
/* =0:   */     }
/* =1:   */     
/* =2:   */     public Attribute invoke(ByteData arg)
/* =3:   */     {
/* =4:93 */       return AttributeFactory.build(arg, this.cp, this.classFileVersion);
/* =5:   */     }
/* =6:   */   }
/* =7:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entityfactories.AttributeFactory
 * JD-Core Version:    0.7.0.1
 */