/*  1:   */ package org.benf.cfr.reader.entityfactories;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Map;
/*  5:   */ import org.benf.cfr.reader.util.KnowsRawName;
/*  6:   */ import org.benf.cfr.reader.util.KnowsRawSize;
/*  7:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  8:   */ import org.benf.cfr.reader.util.bytestream.OffsettingByteData;
/*  9:   */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/* 10:   */ 
/* 11:   */ public class ContiguousEntityFactory
/* 12:   */ {
/* 13:   */   public static <X extends KnowsRawSize> long build(ByteData raw, short count, List<X> tgt, UnaryFunction<ByteData, X> func)
/* 14:   */   {
/* 15:16 */     OffsettingByteData data = raw.getOffsettingOffsetData(0L);
/* 16:17 */     for (short x = 0; x < count; x = (short)(x + 1))
/* 17:   */     {
/* 18:19 */       X tmp = (KnowsRawSize)func.invoke(data);
/* 19:20 */       tgt.add(tmp);
/* 20:21 */       data.advance(tmp.getRawByteLength());
/* 21:   */     }
/* 22:23 */     return data.getOffset();
/* 23:   */   }
/* 24:   */   
/* 25:   */   public static <X> long buildSized(ByteData raw, short count, int itemLength, List<X> tgt, UnaryFunction<ByteData, X> func)
/* 26:   */   {
/* 27:28 */     OffsettingByteData data = raw.getOffsettingOffsetData(0L);
/* 28:29 */     for (short x = 0; x < count; x = (short)(x + 1))
/* 29:   */     {
/* 30:31 */       X tmp = func.invoke(data);
/* 31:32 */       tgt.add(tmp);
/* 32:33 */       data.advance(itemLength);
/* 33:   */     }
/* 34:35 */     return data.getOffset();
/* 35:   */   }
/* 36:   */   
/* 37:   */   public static <X extends KnowsRawName> Map<String, X> addToMap(Map<String, X> tgt, List<X> source)
/* 38:   */   {
/* 39:40 */     for (X item : source) {
/* 40:42 */       tgt.put(item.getRawName(), item);
/* 41:   */     }
/* 42:44 */     return tgt;
/* 43:   */   }
/* 44:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entityfactories.ContiguousEntityFactory
 * JD-Core Version:    0.7.0.1
 */