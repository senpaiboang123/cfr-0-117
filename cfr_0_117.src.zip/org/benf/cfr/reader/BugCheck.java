/*  1:   */ package org.benf.cfr.reader;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ import java.util.HashMap;
/*  5:   */ import java.util.List;
/*  6:   */ import org.benf.cfr.reader.util.ListFactory;
/*  7:   */ import org.benf.cfr.reader.util.functors.NonaryFunction;
/*  8:   */ 
/*  9:   */ public class BugCheck
/* 10:   */ {
/* 11:   */   public static NonaryFunction<Void> checkKnownJreBugs()
/* 12:   */   {
/* 13:15 */     List<String> bugs = ListFactory.newList();
/* 14:16 */     checkNPE(bugs);
/* 15:17 */     if (bugs.isEmpty()) {
/* 16:17 */       new NonaryFunction()
/* 17:   */       {
/* 18:   */         public Void invoke()
/* 19:   */         {
/* 20:20 */           return null;
/* 21:   */         }
/* 22:   */       };
/* 23:   */     }
/* 24:24 */     new NonaryFunction()
/* 25:   */     {
/* 26:   */       public Void invoke()
/* 27:   */       {
/* 28:27 */         System.err.println("//*********** [[ WARNING ]] ***************");
/* 29:28 */         for (String err : this.val$bugs) {
/* 30:29 */           System.err.println("// " + err);
/* 31:   */         }
/* 32:31 */         System.err.println("//*********** [[ WARNING ]] ***************");
/* 33:32 */         return null;
/* 34:   */       }
/* 35:   */     };
/* 36:   */   }
/* 37:   */   
/* 38:   */   private static void checkNPE(List<String> errs)
/* 39:   */   {
/* 40:38 */     HashMap<Integer, Integer> test = new HashMap();
/* 41:39 */     for (int idx = 0; idx < 9000; idx += 32) {
/* 42:40 */       test.put(Integer.valueOf(idx), Integer.valueOf(idx));
/* 43:   */     }
/* 44:   */     try
/* 45:   */     {
/* 46:43 */       test.put(null, null);
/* 47:   */     }
/* 48:   */     catch (NullPointerException e)
/* 49:   */     {
/* 50:45 */       errs.add("The JRE you are using has a buggy implementation of HashMap.  CFR may not work correctly.");
/* 51:   */     }
/* 52:   */   }
/* 53:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.BugCheck
 * JD-Core Version:    0.7.0.1
 */