/*  1:   */ package org.benf.cfr.reader.util;
/*  2:   */ 
/*  3:   */ import java.util.Collection;
/*  4:   */ import java.util.Set;
/*  5:   */ import org.benf.cfr.reader.util.output.Dumpable;
/*  6:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  7:   */ 
/*  8:   */ public class DecompilerComments
/*  9:   */   implements Dumpable
/* 10:   */ {
/* 11:10 */   Set<DecompilerComment> comments = SetFactory.newOrderedSet();
/* 12:   */   
/* 13:   */   public void addComment(String comment)
/* 14:   */   {
/* 15:16 */     DecompilerComment decompilerComment = new DecompilerComment(comment);
/* 16:17 */     this.comments.add(decompilerComment);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void addComment(DecompilerComment comment)
/* 20:   */   {
/* 21:21 */     this.comments.add(comment);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void addComments(Collection<DecompilerComment> comments)
/* 25:   */   {
/* 26:25 */     this.comments.addAll(comments);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public Dumper dump(Dumper d)
/* 30:   */   {
/* 31:30 */     if (this.comments.isEmpty()) {
/* 32:30 */       return d;
/* 33:   */     }
/* 34:31 */     d.print("/*").newln();
/* 35:32 */     for (DecompilerComment comment : this.comments) {
/* 36:33 */       d.print(" * ").dump(comment).newln();
/* 37:   */     }
/* 38:35 */     d.print(" */").newln();
/* 39:36 */     return d;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public Collection<DecompilerComment> getCommentCollection()
/* 43:   */   {
/* 44:40 */     return this.comments;
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.util.DecompilerComments
 * JD-Core Version:    0.7.0.1
 */