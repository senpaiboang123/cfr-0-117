/*  1:   */ package org.benf.cfr.reader.util;
/*  2:   */ 
/*  3:   */ public enum BoolPair
/*  4:   */ {
/*  5: 7 */   NEITHER(0),  FIRST(1),  SECOND(1),  BOTH(2);
/*  6:   */   
/*  7:   */   private final int count;
/*  8:   */   
/*  9:   */   private BoolPair(int count)
/* 10:   */   {
/* 11:15 */     this.count = count;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public static BoolPair get(boolean a, boolean b)
/* 15:   */   {
/* 16:19 */     if (a)
/* 17:   */     {
/* 18:20 */       if (b) {
/* 19:20 */         return BOTH;
/* 20:   */       }
/* 21:21 */       return FIRST;
/* 22:   */     }
/* 23:23 */     if (b) {
/* 24:23 */       return SECOND;
/* 25:   */     }
/* 26:24 */     return NEITHER;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public int getCount()
/* 30:   */   {
/* 31:28 */     return this.count;
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.util.BoolPair
 * JD-Core Version:    0.7.0.1
 */