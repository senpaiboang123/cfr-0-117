package org.benf.cfr.reader.util;

public abstract interface BinaryPredicate<X, Y>
{
  public abstract boolean test(X paramX, Y paramY);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.util.BinaryPredicate
 * JD-Core Version:    0.7.0.1
 */