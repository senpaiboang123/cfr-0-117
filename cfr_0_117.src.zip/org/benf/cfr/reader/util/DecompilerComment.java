/*  1:   */ package org.benf.cfr.reader.util;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*  4:   */ import org.benf.cfr.reader.util.getopt.PermittedOptionProvider.Argument;
/*  5:   */ import org.benf.cfr.reader.util.output.Dumpable;
/*  6:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  7:   */ 
/*  8:   */ public class DecompilerComment
/*  9:   */   implements Dumpable
/* 10:   */ {
/* 11: 9 */   public static DecompilerComment UNABLE_TO_STRUCTURE = new DecompilerComment("Unable to fully structure code", true);
/* 12:10 */   public static DecompilerComment AGGRESSIVE_TOPOLOGICAL_SORT = new DecompilerComment("Enabled aggressive block sorting");
/* 13:11 */   public static DecompilerComment AGGRESSIVE_EXCEPTION_AGG = new DecompilerComment("Enabled aggressive exception aggregation");
/* 14:12 */   public static DecompilerComment COND_PROPAGATE = new DecompilerComment("Enabled force condition propagation");
/* 15:13 */   public static DecompilerComment RETURNING_IFS = new DecompilerComment("Lifted jumps to return sites");
/* 16:14 */   public static DecompilerComment PRUNE_EXCEPTIONS = new DecompilerComment("Enabled unnecessary exception pruning");
/* 17:15 */   public static DecompilerComment COMMENT_MONITORS = new DecompilerComment("Converted monitor instructions to comments");
/* 18:16 */   public static DecompilerComment PARAMETER_CORRUPTION = new DecompilerComment("WARNING - Possible parameter corruption");
/* 19:17 */   public static DecompilerComment TRY_BACKEDGE_REMOVED = new DecompilerComment("WARNING - Removed back jump from a try to a catch block - possible behaviour change.");
/* 20:18 */   public static DecompilerComment LOOPING_EXCEPTIONS = new DecompilerComment("WARNING - Removed try catching itself - possible behaviour change.");
/* 21:19 */   public static DecompilerComment TYPE_CLASHES = new DecompilerComment("Could not resolve type clashes", true);
/* 22:20 */   public static DecompilerComment ITERATED_TYPE_HINTS = new DecompilerComment("Iterators could be improved", true);
/* 23:21 */   public static DecompilerComment LOOSE_CATCH_BLOCK = new DecompilerComment("Loose catch block", true);
/* 24:22 */   public static DecompilerComment CLASS_RENAMED = new DecompilerComment("Inner class renamed, behaviour may change", true);
/* 25:23 */   public static DecompilerComment RENAME_MEMBERS = new DecompilerComment("Duplicate member names - consider using --" + OptionsImpl.RENAME_DUP_MEMBERS.getName() + " true");
/* 26:24 */   public static DecompilerComment ILLEGAL_IDENTIFIERS = new DecompilerComment("Illegal identifiers - consider using --" + OptionsImpl.RENAME_ILLEGAL_IDENTS.getName() + " true");
/* 27:25 */   public static DecompilerComment WHOLE_CLASS_EXCEPTION = new DecompilerComment("Exception performing whole class analysis.");
/* 28:26 */   public static DecompilerComment BAD_ANNOTATION = new DecompilerComment("Issues handling annotations - annotations may be inaccurate");
/* 29:   */   private final String comment;
/* 30:   */   private final String summaryMessage;
/* 31:   */   private final boolean failed;
/* 32:   */   private final boolean exception;
/* 33:   */   
/* 34:   */   public DecompilerComment(String comment)
/* 35:   */   {
/* 36:34 */     this.comment = comment;
/* 37:35 */     this.summaryMessage = null;
/* 38:36 */     this.failed = false;
/* 39:37 */     this.exception = false;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public DecompilerComment(String comment, boolean failed)
/* 43:   */   {
/* 44:41 */     this.comment = comment;
/* 45:42 */     this.summaryMessage = comment;
/* 46:43 */     this.failed = failed;
/* 47:44 */     this.exception = false;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public DecompilerComment(String comment, Exception e)
/* 51:   */   {
/* 52:48 */     this.comment = comment;
/* 53:49 */     this.summaryMessage = ("Exception : " + e.toString());
/* 54:50 */     this.failed = true;
/* 55:51 */     this.exception = true;
/* 56:   */   }
/* 57:   */   
/* 58:   */   public Dumper dump(Dumper d)
/* 59:   */   {
/* 60:56 */     return d.print(this.comment);
/* 61:   */   }
/* 62:   */   
/* 63:   */   public String getSummaryMessage()
/* 64:   */   {
/* 65:60 */     return this.summaryMessage;
/* 66:   */   }
/* 67:   */   
/* 68:   */   public boolean isFailed()
/* 69:   */   {
/* 70:64 */     return this.failed;
/* 71:   */   }
/* 72:   */   
/* 73:   */   public boolean isException()
/* 74:   */   {
/* 75:68 */     return this.exception;
/* 76:   */   }
/* 77:   */   
/* 78:   */   public String toString()
/* 79:   */   {
/* 80:73 */     return this.comment;
/* 81:   */   }
/* 82:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.util.DecompilerComment
 * JD-Core Version:    0.7.0.1
 */