package org.benf.cfr.reader.util.annotation;

import java.lang.annotation.Annotation;

public @interface Nullable {}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.util.annotation.Nullable
 * JD-Core Version:    0.7.0.1
 */