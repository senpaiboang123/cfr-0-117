/*  1:   */ package org.benf.cfr.reader.util;
/*  2:   */ 
/*  3:   */ public class ConfusedCFRException
/*  4:   */   extends RuntimeException
/*  5:   */ {
/*  6:   */   public ConfusedCFRException(String s)
/*  7:   */   {
/*  8: 6 */     super(s);
/*  9:   */   }
/* 10:   */   
/* 11:   */   public ConfusedCFRException(Exception e)
/* 12:   */   {
/* 13:10 */     super(e);
/* 14:   */   }
/* 15:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.util.ConfusedCFRException
 * JD-Core Version:    0.7.0.1
 */