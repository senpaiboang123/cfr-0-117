/* 1:  */ package org.benf.cfr.reader.util;
/* 2:  */ 
/* 3:  */ public class CannotPerformDecode
/* 4:  */   extends ConfusedCFRException
/* 5:  */ {
/* 6:  */   public CannotPerformDecode(String s)
/* 7:  */   {
/* 8:5 */     super(s);
/* 9:  */   }
/* ::  */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.util.CannotPerformDecode
 * JD-Core Version:    0.7.0.1
 */