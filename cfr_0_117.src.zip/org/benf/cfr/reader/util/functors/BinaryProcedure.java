package org.benf.cfr.reader.util.functors;

public abstract interface BinaryProcedure<X, Y>
{
  public abstract void call(X paramX, Y paramY);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.util.functors.BinaryProcedure
 * JD-Core Version:    0.7.0.1
 */