package org.benf.cfr.reader.util.functors;

public abstract interface BinaryFunction<X, Y, R>
{
  public abstract R invoke(X paramX, Y paramY);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.util.functors.BinaryFunction
 * JD-Core Version:    0.7.0.1
 */