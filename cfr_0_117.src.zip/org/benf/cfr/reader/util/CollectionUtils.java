/*  1:   */ package org.benf.cfr.reader.util;
/*  2:   */ 
/*  3:   */ import java.util.Collection;
/*  4:   */ 
/*  5:   */ public class CollectionUtils
/*  6:   */ {
/*  7:   */   public static String join(Collection<? extends Object> in, String sep)
/*  8:   */   {
/*  9: 7 */     StringBuilder sb = new StringBuilder();
/* 10: 8 */     boolean first = true;
/* 11: 9 */     for (Object o : in)
/* 12:   */     {
/* 13:10 */       if (first) {
/* 14:11 */         first = false;
/* 15:   */       } else {
/* 16:13 */         sb.append(sep);
/* 17:   */       }
/* 18:15 */       sb.append(o.toString());
/* 19:   */     }
/* 20:17 */     return sb.toString();
/* 21:   */   }
/* 22:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.util.CollectionUtils
 * JD-Core Version:    0.7.0.1
 */