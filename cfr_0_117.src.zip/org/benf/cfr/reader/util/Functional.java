/*   1:    */ package org.benf.cfr.reader.util;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.Comparator;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Set;
/*   8:    */ import java.util.TreeMap;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  10:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  11:    */ 
/*  12:    */ public class Functional
/*  13:    */ {
/*  14:    */   public static class NotNull<X>
/*  15:    */     implements Predicate<X>
/*  16:    */   {
/*  17:    */     public boolean test(X in)
/*  18:    */     {
/*  19: 13 */       return in != null;
/*  20:    */     }
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static <X> List<X> filterColl(Collection<X> input, Predicate<X> predicate)
/*  24:    */   {
/*  25: 18 */     return filter(input, predicate);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public static <X> List<X> filter(Collection<X> input, Predicate<X> predicate)
/*  29:    */   {
/*  30: 22 */     List<X> result = ListFactory.newList();
/*  31: 23 */     for (X item : input) {
/*  32: 24 */       if (predicate.test(item)) {
/*  33: 24 */         result.add(item);
/*  34:    */       }
/*  35:    */     }
/*  36: 26 */     return result;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static <X> Set<X> filterSet(Collection<X> input, Predicate<X> predicate)
/*  40:    */   {
/*  41: 31 */     Set<X> result = SetFactory.newSet();
/*  42: 32 */     for (X item : input) {
/*  43: 33 */       if (predicate.test(item)) {
/*  44: 33 */         result.add(item);
/*  45:    */       }
/*  46:    */     }
/*  47: 35 */     return result;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static <X> boolean any(Collection<X> input, Predicate<X> predicate)
/*  51:    */   {
/*  52: 39 */     List<X> result = ListFactory.newList();
/*  53: 40 */     for (X item : input) {
/*  54: 41 */       if (predicate.test(item)) {
/*  55: 41 */         return true;
/*  56:    */       }
/*  57:    */     }
/*  58: 43 */     return false;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static <X> boolean all(Collection<X> input, Predicate<X> predicate)
/*  62:    */   {
/*  63: 47 */     List<X> result = ListFactory.newList();
/*  64: 48 */     for (X item : input) {
/*  65: 49 */       if (!predicate.test(item)) {
/*  66: 49 */         return false;
/*  67:    */       }
/*  68:    */     }
/*  69: 51 */     return true;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public static <X> Pair<List<X>, List<X>> partition(Collection<X> input, Predicate<X> predicate)
/*  73:    */   {
/*  74: 55 */     List<X> lTrue = ListFactory.newList();
/*  75: 56 */     List<X> lFalse = ListFactory.newList();
/*  76: 57 */     for (X item : input) {
/*  77: 58 */       if (predicate.test(item)) {
/*  78: 59 */         lTrue.add(item);
/*  79:    */       } else {
/*  80: 61 */         lFalse.add(item);
/*  81:    */       }
/*  82:    */     }
/*  83: 64 */     return new Pair(lTrue, lFalse);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public static <X, Y> List<Y> map(Collection<X> input, UnaryFunction<X, Y> function)
/*  87:    */   {
/*  88: 69 */     List<Y> result = ListFactory.newList();
/*  89: 70 */     for (X item : input) {
/*  90: 71 */       result.add(function.invoke(item));
/*  91:    */     }
/*  92: 73 */     return result;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public static <X> List<X> uniqAll(List<X> input)
/*  96:    */   {
/*  97: 77 */     Set<X> found = SetFactory.newSet();
/*  98: 78 */     List<X> result = ListFactory.newList();
/*  99: 79 */     for (X in : input) {
/* 100: 80 */       if (found.add(in)) {
/* 101: 80 */         result.add(in);
/* 102:    */       }
/* 103:    */     }
/* 104: 82 */     return result;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public static <Y, X> Map<Y, List<X>> groupToMapBy(List<X> input, UnaryFunction<X, Y> mapF)
/* 108:    */   {
/* 109: 86 */     Map<Y, List<X>> temp = MapFactory.newMap();
/* 110: 87 */     return groupToMapBy(input, temp, mapF);
/* 111:    */   }
/* 112:    */   
/* 113:    */   public static <Y, X> Map<Y, List<X>> groupToMapBy(List<X> input, Map<Y, List<X>> tgt, UnaryFunction<X, Y> mapF)
/* 114:    */   {
/* 115: 91 */     for (X x : input)
/* 116:    */     {
/* 117: 92 */       Y key = mapF.invoke(x);
/* 118: 93 */       List<X> lx = (List)tgt.get(key);
/* 119: 94 */       if (lx == null)
/* 120:    */       {
/* 121: 95 */         lx = ListFactory.newList();
/* 122: 96 */         tgt.put(key, lx);
/* 123:    */       }
/* 124: 98 */       lx.add(x);
/* 125:    */     }
/* 126:100 */     return tgt;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public static <Y, X> List<Y> groupBy(List<X> input, Comparator<? super X> comparator, UnaryFunction<List<X>, Y> gf)
/* 130:    */   {
/* 131:104 */     TreeMap<X, List<X>> temp = new TreeMap(comparator);
/* 132:105 */     for (X x : input)
/* 133:    */     {
/* 134:106 */       List<X> lx = (List)temp.get(x);
/* 135:107 */       if (lx == null)
/* 136:    */       {
/* 137:108 */         lx = ListFactory.newList();
/* 138:109 */         temp.put(x, lx);
/* 139:    */       }
/* 140:111 */       lx.add(x);
/* 141:    */     }
/* 142:113 */     List<Y> res = ListFactory.newList();
/* 143:114 */     for (List<X> lx : temp.values()) {
/* 144:115 */       res.add(gf.invoke(lx));
/* 145:    */     }
/* 146:117 */     return res;
/* 147:    */   }
/* 148:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.util.Functional
 * JD-Core Version:    0.7.0.1
 */