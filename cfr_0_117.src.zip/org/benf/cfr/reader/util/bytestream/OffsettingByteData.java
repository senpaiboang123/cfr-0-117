package org.benf.cfr.reader.util.bytestream;

public abstract interface OffsettingByteData
  extends ByteData
{
  public abstract void advance(long paramLong);
  
  public abstract void rewind(long paramLong);
  
  public abstract long getOffset();
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.util.bytestream.OffsettingByteData
 * JD-Core Version:    0.7.0.1
 */