/*  1:   */ package org.benf.cfr.reader.util.bytestream;
/*  2:   */ 
/*  3:   */ import java.io.ByteArrayInputStream;
/*  4:   */ import java.io.DataInputStream;
/*  5:   */ 
/*  6:   */ public class OffsetBackedByteData
/*  7:   */   extends AbstractBackedByteData
/*  8:   */ {
/*  9:   */   final int offset;
/* 10:   */   final byte[] data;
/* 11:   */   
/* 12:   */   public OffsetBackedByteData(byte[] data, long offset)
/* 13:   */   {
/* 14:11 */     this.offset = ((int)offset);
/* 15:12 */     this.data = data;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public DataInputStream rawDataAsStream(int start, int len)
/* 19:   */   {
/* 20:17 */     return new DataInputStream(new ByteArrayInputStream(this.data, start + this.offset, len));
/* 21:   */   }
/* 22:   */   
/* 23:   */   public ByteData getOffsetData(long offset)
/* 24:   */   {
/* 25:22 */     return new OffsetBackedByteData(this.data, this.offset + offset);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public OffsettingByteData getOffsettingOffsetData(long offset)
/* 29:   */   {
/* 30:27 */     return new OffsettingBackedByteData(this.data, this.offset + offset);
/* 31:   */   }
/* 32:   */   
/* 33:   */   public byte getS1At(long o)
/* 34:   */   {
/* 35:32 */     return this.data[((int)(this.offset + o))];
/* 36:   */   }
/* 37:   */   
/* 38:   */   public byte[] getBytesAt(int count, long offset)
/* 39:   */   {
/* 40:37 */     byte[] res = new byte[count];
/* 41:38 */     System.arraycopy(this.data, (int)(this.offset + offset), res, 0, count);
/* 42:39 */     return res;
/* 43:   */   }
/* 44:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.util.bytestream.OffsetBackedByteData
 * JD-Core Version:    0.7.0.1
 */