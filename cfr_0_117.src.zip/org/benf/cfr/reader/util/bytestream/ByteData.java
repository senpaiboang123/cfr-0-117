package org.benf.cfr.reader.util.bytestream;

public abstract interface ByteData
{
  public abstract byte getS1At(long paramLong);
  
  public abstract short getU1At(long paramLong);
  
  public abstract short getS2At(long paramLong);
  
  public abstract int getU2At(long paramLong);
  
  public abstract int getS4At(long paramLong);
  
  public abstract double getDoubleAt(long paramLong);
  
  public abstract float getFloatAt(long paramLong);
  
  public abstract long getLongAt(long paramLong);
  
  public abstract byte[] getBytesAt(int paramInt, long paramLong);
  
  public abstract ByteData getOffsetData(long paramLong);
  
  public abstract OffsettingByteData getOffsettingOffsetData(long paramLong);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.util.bytestream.ByteData
 * JD-Core Version:    0.7.0.1
 */