/*  1:   */ package org.benf.cfr.reader.util.bytestream;
/*  2:   */ 
/*  3:   */ import java.io.ByteArrayInputStream;
/*  4:   */ import java.io.DataInputStream;
/*  5:   */ 
/*  6:   */ public class BaseByteData
/*  7:   */   extends AbstractBackedByteData
/*  8:   */ {
/*  9:   */   private final byte[] data;
/* 10:   */   
/* 11:   */   public BaseByteData(byte[] data)
/* 12:   */   {
/* 13:10 */     this.data = data;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public DataInputStream rawDataAsStream(int start, int len)
/* 17:   */   {
/* 18:15 */     return new DataInputStream(new ByteArrayInputStream(this.data, start, len));
/* 19:   */   }
/* 20:   */   
/* 21:   */   public ByteData getOffsetData(long offset)
/* 22:   */   {
/* 23:20 */     return new OffsetBackedByteData(this.data, offset);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public OffsettingByteData getOffsettingOffsetData(long offset)
/* 27:   */   {
/* 28:25 */     return new OffsettingBackedByteData(this.data, offset);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public byte[] getBytesAt(int count, long offset)
/* 32:   */   {
/* 33:30 */     byte[] res = new byte[count];
/* 34:31 */     System.arraycopy(this.data, (int)offset, res, 0, count);
/* 35:32 */     return res;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public byte getS1At(long o)
/* 39:   */   {
/* 40:37 */     return this.data[((int)o)];
/* 41:   */   }
/* 42:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.util.bytestream.BaseByteData
 * JD-Core Version:    0.7.0.1
 */