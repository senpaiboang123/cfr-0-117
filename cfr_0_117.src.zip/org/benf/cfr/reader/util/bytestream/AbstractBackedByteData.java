/*  1:   */ package org.benf.cfr.reader.util.bytestream;
/*  2:   */ 
/*  3:   */ import java.io.DataInputStream;
/*  4:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  5:   */ 
/*  6:   */ public abstract class AbstractBackedByteData
/*  7:   */   implements ByteData
/*  8:   */ {
/*  9:   */   abstract DataInputStream rawDataAsStream(int paramInt1, int paramInt2);
/* 10:   */   
/* 11:   */   public int getS4At(long o)
/* 12:   */     throws ConfusedCFRException
/* 13:   */   {
/* 14:14 */     DataInputStream dis = rawDataAsStream((int)o, 4);
/* 15:   */     try
/* 16:   */     {
/* 17:16 */       return dis.readInt();
/* 18:   */     }
/* 19:   */     catch (Exception e)
/* 20:   */     {
/* 21:18 */       throw new ConfusedCFRException(e);
/* 22:   */     }
/* 23:   */   }
/* 24:   */   
/* 25:   */   public double getDoubleAt(long o)
/* 26:   */     throws ConfusedCFRException
/* 27:   */   {
/* 28:24 */     DataInputStream dis = rawDataAsStream((int)o, 8);
/* 29:   */     try
/* 30:   */     {
/* 31:26 */       return dis.readDouble();
/* 32:   */     }
/* 33:   */     catch (Exception e)
/* 34:   */     {
/* 35:28 */       throw new ConfusedCFRException(e);
/* 36:   */     }
/* 37:   */   }
/* 38:   */   
/* 39:   */   public float getFloatAt(long o)
/* 40:   */     throws ConfusedCFRException
/* 41:   */   {
/* 42:34 */     DataInputStream dis = rawDataAsStream((int)o, 8);
/* 43:   */     try
/* 44:   */     {
/* 45:36 */       return dis.readFloat();
/* 46:   */     }
/* 47:   */     catch (Exception e)
/* 48:   */     {
/* 49:38 */       throw new ConfusedCFRException(e);
/* 50:   */     }
/* 51:   */   }
/* 52:   */   
/* 53:   */   public long getLongAt(long o)
/* 54:   */     throws ConfusedCFRException
/* 55:   */   {
/* 56:44 */     DataInputStream dis = rawDataAsStream((int)o, 8);
/* 57:   */     try
/* 58:   */     {
/* 59:46 */       return dis.readLong();
/* 60:   */     }
/* 61:   */     catch (Exception e)
/* 62:   */     {
/* 63:48 */       throw new ConfusedCFRException(e);
/* 64:   */     }
/* 65:   */   }
/* 66:   */   
/* 67:   */   public short getS2At(long o)
/* 68:   */     throws ConfusedCFRException
/* 69:   */   {
/* 70:55 */     DataInputStream dis = rawDataAsStream((int)o, 2);
/* 71:   */     try
/* 72:   */     {
/* 73:57 */       return dis.readShort();
/* 74:   */     }
/* 75:   */     catch (Exception e)
/* 76:   */     {
/* 77:59 */       throw new ConfusedCFRException(e);
/* 78:   */     }
/* 79:   */   }
/* 80:   */   
/* 81:   */   public int getU2At(long o)
/* 82:   */     throws ConfusedCFRException
/* 83:   */   {
/* 84:66 */     DataInputStream dis = rawDataAsStream((int)o, 2);
/* 85:   */     try
/* 86:   */     {
/* 87:68 */       return dis.readUnsignedShort();
/* 88:   */     }
/* 89:   */     catch (Exception e)
/* 90:   */     {
/* 91:70 */       throw new ConfusedCFRException(e);
/* 92:   */     }
/* 93:   */   }
/* 94:   */   
/* 95:   */   public short getU1At(long o)
/* 96:   */     throws ConfusedCFRException
/* 97:   */   {
/* 98:77 */     DataInputStream dis = rawDataAsStream((int)o, 1);
/* 99:   */     try
/* :0:   */     {
/* :1:79 */       return (short)dis.readUnsignedByte();
/* :2:   */     }
/* :3:   */     catch (Exception e)
/* :4:   */     {
/* :5:81 */       throw new ConfusedCFRException(e);
/* :6:   */     }
/* :7:   */   }
/* :8:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.util.bytestream.AbstractBackedByteData
 * JD-Core Version:    0.7.0.1
 */