/*  1:   */ package org.benf.cfr.reader.util.bytestream;
/*  2:   */ 
/*  3:   */ import java.io.ByteArrayInputStream;
/*  4:   */ import java.io.DataInputStream;
/*  5:   */ 
/*  6:   */ public class OffsettingBackedByteData
/*  7:   */   extends AbstractBackedByteData
/*  8:   */   implements OffsettingByteData
/*  9:   */ {
/* 10:   */   final byte[] data;
/* 11:   */   final int originalOffset;
/* 12:   */   int mutableOffset;
/* 13:   */   
/* 14:   */   public OffsettingBackedByteData(byte[] data, long offset)
/* 15:   */   {
/* 16:12 */     this.data = data;
/* 17:13 */     this.originalOffset = ((int)offset);
/* 18:14 */     this.mutableOffset = 0;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void advance(long offset)
/* 22:   */   {
/* 23:19 */     this.mutableOffset = ((int)(this.mutableOffset + offset));
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void rewind(long offset)
/* 27:   */   {
/* 28:24 */     this.mutableOffset = ((int)(this.mutableOffset - offset));
/* 29:   */   }
/* 30:   */   
/* 31:   */   public long getOffset()
/* 32:   */   {
/* 33:29 */     return this.mutableOffset;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public DataInputStream rawDataAsStream(int start, int len)
/* 37:   */   {
/* 38:34 */     return new DataInputStream(new ByteArrayInputStream(this.data, start + this.originalOffset + this.mutableOffset, len));
/* 39:   */   }
/* 40:   */   
/* 41:   */   public ByteData getOffsetData(long offset)
/* 42:   */   {
/* 43:39 */     return new OffsetBackedByteData(this.data, this.originalOffset + this.mutableOffset + offset);
/* 44:   */   }
/* 45:   */   
/* 46:   */   public OffsettingByteData getOffsettingOffsetData(long offset)
/* 47:   */   {
/* 48:44 */     return new OffsettingBackedByteData(this.data, this.originalOffset + this.mutableOffset + offset);
/* 49:   */   }
/* 50:   */   
/* 51:   */   public byte getS1At(long o)
/* 52:   */   {
/* 53:49 */     return this.data[((int)(this.originalOffset + this.mutableOffset + o))];
/* 54:   */   }
/* 55:   */   
/* 56:   */   public byte[] getBytesAt(int count, long offset)
/* 57:   */   {
/* 58:54 */     byte[] res = new byte[count];
/* 59:55 */     System.arraycopy(this.data, (int)(this.originalOffset + this.mutableOffset + offset), res, 0, count);
/* 60:56 */     return res;
/* 61:   */   }
/* 62:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.util.bytestream.OffsettingBackedByteData
 * JD-Core Version:    0.7.0.1
 */