/*  1:   */ package org.benf.cfr.reader.util;
/*  2:   */ 
/*  3:   */ public class ClassFileVersion
/*  4:   */ {
/*  5:   */   private final int major;
/*  6:   */   private final int minor;
/*  7:   */   private final String name;
/*  8:   */   
/*  9:   */   public ClassFileVersion(int major, int minor)
/* 10:   */   {
/* 11: 9 */     this(major, minor, null);
/* 12:   */   }
/* 13:   */   
/* 14:   */   public ClassFileVersion(int major, int minor, String name)
/* 15:   */   {
/* 16:13 */     this.major = major;
/* 17:14 */     this.minor = minor;
/* 18:15 */     this.name = name;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public boolean equalOrLater(ClassFileVersion other)
/* 22:   */   {
/* 23:19 */     if (this.major < other.major) {
/* 24:19 */       return false;
/* 25:   */     }
/* 26:20 */     if (this.major > other.major) {
/* 27:20 */       return true;
/* 28:   */     }
/* 29:21 */     if (this.minor < other.minor) {
/* 30:21 */       return false;
/* 31:   */     }
/* 32:22 */     return true;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public boolean before(ClassFileVersion other)
/* 36:   */   {
/* 37:26 */     return !equalOrLater(other);
/* 38:   */   }
/* 39:   */   
/* 40:   */   public String toString()
/* 41:   */   {
/* 42:31 */     return "" + this.major + "." + this.minor + (this.name == null ? "" : new StringBuilder().append(" (Java ").append(this.name).append(")").toString());
/* 43:   */   }
/* 44:   */   
/* 45:34 */   public static ClassFileVersion JAVA_1_0 = new ClassFileVersion(45, 3, "1.0");
/* 46:35 */   public static ClassFileVersion JAVA_1_2 = new ClassFileVersion(46, 0, "1.2");
/* 47:36 */   public static ClassFileVersion JAVA_1_3 = new ClassFileVersion(47, 0, "1.3");
/* 48:37 */   public static ClassFileVersion JAVA_1_4 = new ClassFileVersion(48, 0, "1.4");
/* 49:38 */   public static ClassFileVersion JAVA_5 = new ClassFileVersion(49, 0, "5");
/* 50:39 */   public static ClassFileVersion JAVA_6 = new ClassFileVersion(50, 0, "6");
/* 51:40 */   public static ClassFileVersion JAVA_7 = new ClassFileVersion(51, 0, "7");
/* 52:41 */   public static ClassFileVersion JAVA_8 = new ClassFileVersion(52, 0, "8");
/* 53:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.util.ClassFileVersion
 * JD-Core Version:    0.7.0.1
 */