/*   1:    */ package org.benf.cfr.reader;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ import java.util.List;
/*   5:    */ import org.benf.cfr.reader.api.ClassFileSource;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*   7:    */ import org.benf.cfr.reader.entities.ClassFile;
/*   8:    */ import org.benf.cfr.reader.entities.Method;
/*   9:    */ import org.benf.cfr.reader.relationship.MemberNameResolver;
/*  10:    */ import org.benf.cfr.reader.state.ClassCache;
/*  11:    */ import org.benf.cfr.reader.state.ClassFileSourceImpl;
/*  12:    */ import org.benf.cfr.reader.state.DCCommonState;
/*  13:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  14:    */ import org.benf.cfr.reader.util.CannotLoadClassException;
/*  15:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  16:    */ import org.benf.cfr.reader.util.Functional;
/*  17:    */ import org.benf.cfr.reader.util.ListFactory;
/*  18:    */ import org.benf.cfr.reader.util.MiscUtils;
/*  19:    */ import org.benf.cfr.reader.util.Predicate;
/*  20:    */ import org.benf.cfr.reader.util.getopt.GetOptParser;
/*  21:    */ import org.benf.cfr.reader.util.getopt.Options;
/*  22:    */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*  23:    */ import org.benf.cfr.reader.util.getopt.PermittedOptionProvider.Argument;
/*  24:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  25:    */ import org.benf.cfr.reader.util.output.Dumper.CannotCreate;
/*  26:    */ import org.benf.cfr.reader.util.output.DumperFactory;
/*  27:    */ import org.benf.cfr.reader.util.output.DumperFactoryImpl;
/*  28:    */ import org.benf.cfr.reader.util.output.IllegalIdentifierDump;
/*  29:    */ import org.benf.cfr.reader.util.output.IllegalIdentifierDump.Factory;
/*  30:    */ import org.benf.cfr.reader.util.output.NopSummaryDumper;
/*  31:    */ import org.benf.cfr.reader.util.output.SummaryDumper;
/*  32:    */ import org.benf.cfr.reader.util.output.ToStringDumper;
/*  33:    */ 
/*  34:    */ public class Main
/*  35:    */ {
/*  36:    */   public static void doClass(DCCommonState dcCommonState, String path, DumperFactory dumperFactory)
/*  37:    */   {
/*  38: 22 */     Options options = dcCommonState.getOptions();
/*  39: 23 */     IllegalIdentifierDump illegalIdentifierDump = IllegalIdentifierDump.Factory.get(options);
/*  40: 24 */     Dumper d = new ToStringDumper();
/*  41:    */     try
/*  42:    */     {
/*  43: 26 */       SummaryDumper summaryDumper = new NopSummaryDumper();
/*  44: 27 */       ClassFile c = dcCommonState.getClassFileMaybePath(path);
/*  45: 28 */       dcCommonState.configureWith(c);
/*  46:    */       try
/*  47:    */       {
/*  48: 33 */         c = dcCommonState.getClassFile(c.getClassType());
/*  49:    */       }
/*  50:    */       catch (CannotLoadClassException e) {}
/*  51: 37 */       if (((Boolean)options.getOption(OptionsImpl.DECOMPILE_INNER_CLASSES)).booleanValue()) {
/*  52: 38 */         c.loadInnerClasses(dcCommonState);
/*  53:    */       }
/*  54: 40 */       if (((Boolean)options.getOption(OptionsImpl.RENAME_DUP_MEMBERS)).booleanValue()) {
/*  55: 41 */         MemberNameResolver.resolveNames(dcCommonState, ListFactory.newList(dcCommonState.getClassCache().getLoadedTypes()));
/*  56:    */       }
/*  57: 46 */       c.analyseTop(dcCommonState);
/*  58:    */       
/*  59:    */ 
/*  60:    */ 
/*  61: 50 */       TypeUsageCollector collectingDumper = new TypeUsageCollector(c);
/*  62: 51 */       c.collectTypeUsages(collectingDumper);
/*  63:    */       
/*  64: 53 */       d = dumperFactory.getNewTopLevelDumper(options, c.getClassType(), summaryDumper, collectingDumper.getTypeUsageInformation(), illegalIdentifierDump);
/*  65:    */       
/*  66: 55 */       String methname = (String)options.getOption(OptionsImpl.METHODNAME);
/*  67: 56 */       if (methname == null) {
/*  68: 57 */         c.dump(d);
/*  69:    */       } else {
/*  70:    */         try
/*  71:    */         {
/*  72: 60 */           for (Method method : c.getMethodByName(methname)) {
/*  73: 61 */             method.dump(d, true);
/*  74:    */           }
/*  75:    */         }
/*  76:    */         catch (NoSuchMethodException e)
/*  77:    */         {
/*  78: 64 */           throw new IllegalArgumentException("No such method '" + methname + "'.");
/*  79:    */         }
/*  80:    */       }
/*  81: 67 */       d.print("");
/*  82:    */     }
/*  83:    */     catch (ConfusedCFRException e)
/*  84:    */     {
/*  85: 69 */       System.err.println(e.toString());
/*  86: 70 */       for (Object x : e.getStackTrace()) {
/*  87: 71 */         System.err.println(x);
/*  88:    */       }
/*  89:    */     }
/*  90:    */     catch (CannotLoadClassException e)
/*  91:    */     {
/*  92: 74 */       System.out.println("Can't load the class specified:");
/*  93: 75 */       System.out.println(e.toString());
/*  94:    */     }
/*  95:    */     catch (RuntimeException e)
/*  96:    */     {
/*  97: 77 */       System.err.println(e.toString());
/*  98: 78 */       for (Object x : e.getStackTrace()) {
/*  99: 79 */         System.err.println(x);
/* 100:    */       }
/* 101:    */     }
/* 102:    */     finally
/* 103:    */     {
/* 104: 82 */       if (d != null) {
/* 105: 82 */         d.close();
/* 106:    */       }
/* 107:    */     }
/* 108:    */   }
/* 109:    */   
/* 110:    */   public static void doJar(DCCommonState dcCommonState, String path, DumperFactory dumperFactory)
/* 111:    */   {
/* 112: 87 */     Options options = dcCommonState.getOptions();
/* 113: 88 */     IllegalIdentifierDump illegalIdentifierDump = IllegalIdentifierDump.Factory.get(options);
/* 114: 89 */     SummaryDumper summaryDumper = null;
/* 115: 90 */     boolean silent = true;
/* 116:    */     try
/* 117:    */     {
/* 118: 92 */       Predicate<String> matcher = MiscUtils.mkRegexFilter((String)options.getOption(OptionsImpl.JAR_FILTER), true);
/* 119: 93 */       silent = ((Boolean)options.getOption(OptionsImpl.SILENT)).booleanValue();
/* 120: 94 */       summaryDumper = dumperFactory.getSummaryDumper(options);
/* 121: 95 */       summaryDumper.notify("Summary for " + path);
/* 122: 96 */       summaryDumper.notify("Decompiled with CFR 0_117");
/* 123: 97 */       if (!silent) {
/* 124: 98 */         System.err.println("Processing " + path + " (use " + OptionsImpl.SILENT.getName() + " to silence)");
/* 125:    */       }
/* 126:100 */       List<JavaTypeInstance> types = dcCommonState.explicitlyLoadJar(path);
/* 127:101 */       types = Functional.filter(types, new Predicate()
/* 128:    */       {
/* 129:    */         public boolean test(JavaTypeInstance in)
/* 130:    */         {
/* 131:104 */           return this.val$matcher.test(in.getRawName());
/* 132:    */         }
/* 133:    */       });
/* 134:111 */       if ((((Boolean)options.getOption(OptionsImpl.RENAME_DUP_MEMBERS)).booleanValue()) || (((Boolean)options.getOption(OptionsImpl.RENAME_ENUM_MEMBERS)).booleanValue())) {
/* 135:113 */         MemberNameResolver.resolveNames(dcCommonState, types);
/* 136:    */       }
/* 137:115 */       for (JavaTypeInstance type : types)
/* 138:    */       {
/* 139:116 */         Dumper d = new ToStringDumper();
/* 140:    */         try
/* 141:    */         {
/* 142:118 */           ClassFile c = dcCommonState.getClassFile(type);
/* 143:121 */           if (c.isInnerClass())
/* 144:    */           {
/* 145:121 */             d = null;
/* 146:143 */             if (d != null) {
/* 147:143 */               d.close();
/* 148:    */             }
/* 149:    */           }
/* 150:    */           else
/* 151:    */           {
/* 152:122 */             if (!silent) {
/* 153:123 */               System.err.println("Processing " + type.getRawName());
/* 154:    */             }
/* 155:125 */             if (((Boolean)options.getOption(OptionsImpl.DECOMPILE_INNER_CLASSES)).booleanValue()) {
/* 156:126 */               c.loadInnerClasses(dcCommonState);
/* 157:    */             }
/* 158:129 */             c.analyseTop(dcCommonState);
/* 159:    */             
/* 160:131 */             TypeUsageCollector collectingDumper = new TypeUsageCollector(c);
/* 161:132 */             c.collectTypeUsages(collectingDumper);
/* 162:133 */             d = dumperFactory.getNewTopLevelDumper(options, c.getClassType(), summaryDumper, collectingDumper.getTypeUsageInformation(), illegalIdentifierDump);
/* 163:    */             
/* 164:135 */             c.dump(d);
/* 165:136 */             d.print("\n");
/* 166:137 */             d.print("\n");
/* 167:    */           }
/* 168:    */         }
/* 169:    */         catch (Dumper.CannotCreate e)
/* 170:    */         {
/* 171:139 */           throw e;
/* 172:    */         }
/* 173:    */         catch (RuntimeException e)
/* 174:    */         {
/* 175:141 */           d.print(e.toString()).print("\n").print("\n").print("\n");
/* 176:    */         }
/* 177:    */         finally {}
/* 178:    */       }
/* 179:    */     }
/* 180:    */     catch (RuntimeException e)
/* 181:    */     {
/* 182:148 */       String err = "Exception analysing jar " + e;
/* 183:149 */       System.err.println(err);
/* 184:150 */       if (summaryDumper != null) {
/* 185:150 */         summaryDumper.notify(err);
/* 186:    */       }
/* 187:    */     }
/* 188:    */     finally
/* 189:    */     {
/* 190:152 */       if (summaryDumper != null) {
/* 191:152 */         summaryDumper.close();
/* 192:    */       }
/* 193:    */     }
/* 194:    */   }
/* 195:    */   
/* 196:    */   public static void main(String[] args)
/* 197:    */   {
/* 198:158 */     GetOptParser getOptParser = new GetOptParser();
/* 199:    */     
/* 200:160 */     Options options = null;
/* 201:    */     try
/* 202:    */     {
/* 203:162 */       options = (Options)getOptParser.parse(args, OptionsImpl.getFactory());
/* 204:    */     }
/* 205:    */     catch (Exception e)
/* 206:    */     {
/* 207:164 */       getOptParser.showHelp(OptionsImpl.getFactory(), e);
/* 208:165 */       System.exit(1);
/* 209:    */     }
/* 210:168 */     if ((options.optionIsSet(OptionsImpl.HELP)) || (options.getOption(OptionsImpl.FILENAME) == null))
/* 211:    */     {
/* 212:169 */       getOptParser.showOptionHelp(OptionsImpl.getFactory(), options, OptionsImpl.HELP);
/* 213:170 */       return;
/* 214:    */     }
/* 215:173 */     ClassFileSource classFileSource = new ClassFileSourceImpl(options);
/* 216:174 */     DCCommonState dcCommonState = new DCCommonState(options, classFileSource);
/* 217:175 */     String path = (String)options.getOption(OptionsImpl.FILENAME);
/* 218:176 */     String type = (String)options.getOption(OptionsImpl.ANALYSE_AS);
/* 219:177 */     if (type == null) {
/* 220:177 */       type = dcCommonState.detectClsJar(path);
/* 221:    */     }
/* 222:179 */     DumperFactory dumperFactory = new DumperFactoryImpl();
/* 223:180 */     if (type.equals("jar")) {
/* 224:181 */       doJar(dcCommonState, path, dumperFactory);
/* 225:    */     } else {
/* 226:183 */       doClass(dcCommonState, path, dumperFactory);
/* 227:    */     }
/* 228:    */   }
/* 229:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.Main
 * JD-Core Version:    0.7.0.1
 */