/*  1:   */ package org.benf.cfr.reader.bytecode;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.util.DecompilerComment;
/*  5:   */ import org.benf.cfr.reader.util.Troolean;
/*  6:   */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  7:   */ import org.benf.cfr.reader.util.getopt.MutableOptions;
/*  8:   */ import org.benf.cfr.reader.util.getopt.PermittedOptionProvider.Argument;
/*  9:   */ import org.benf.cfr.reader.util.getopt.PermittedOptionProvider.ArgumentParam;
/* 10:   */ 
/* 11:   */ public abstract class RecoveryOption<T>
/* 12:   */ {
/* 13:   */   protected final UnaryFunction<BytecodeMeta, Boolean> canhelp;
/* 14:   */   protected final PermittedOptionProvider.Argument<T> arg;
/* 15:   */   protected final T value;
/* 16:   */   protected final DecompilerComment decompilerComment;
/* 17:   */   
/* 18:   */   public RecoveryOption(PermittedOptionProvider.Argument<T> arg, T value, UnaryFunction<BytecodeMeta, Boolean> canHelp, DecompilerComment comment)
/* 19:   */   {
/* 20:19 */     this.arg = arg;
/* 21:20 */     this.value = value;
/* 22:21 */     this.decompilerComment = comment;
/* 23:22 */     this.canhelp = canHelp;
/* 24:   */   }
/* 25:   */   
/* 26:   */   protected boolean applyComment(boolean applied, List<DecompilerComment> commentList)
/* 27:   */   {
/* 28:26 */     if (!applied) {
/* 29:26 */       return false;
/* 30:   */     }
/* 31:27 */     if (this.decompilerComment == null) {
/* 32:27 */       return true;
/* 33:   */     }
/* 34:28 */     commentList.add(this.decompilerComment);
/* 35:29 */     return true;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public abstract boolean apply(MutableOptions paramMutableOptions, List<DecompilerComment> paramList, BytecodeMeta paramBytecodeMeta);
/* 39:   */   
/* 40:   */   public static class TrooleanRO
/* 41:   */     extends RecoveryOption<Troolean>
/* 42:   */   {
/* 43:   */     public TrooleanRO(PermittedOptionProvider.Argument<Troolean> arg, Troolean value)
/* 44:   */     {
/* 45:36 */       super(value, null, null);
/* 46:   */     }
/* 47:   */     
/* 48:   */     public TrooleanRO(PermittedOptionProvider.Argument<Troolean> arg, Troolean value, DecompilerComment comment)
/* 49:   */     {
/* 50:40 */       super(value, null, comment);
/* 51:   */     }
/* 52:   */     
/* 53:   */     public TrooleanRO(PermittedOptionProvider.Argument<Troolean> arg, Troolean value, UnaryFunction<BytecodeMeta, Boolean> canHelp)
/* 54:   */     {
/* 55:44 */       super(value, canHelp, null);
/* 56:   */     }
/* 57:   */     
/* 58:   */     public TrooleanRO(PermittedOptionProvider.Argument<Troolean> arg, Troolean value, UnaryFunction<BytecodeMeta, Boolean> canHelp, DecompilerComment comment)
/* 59:   */     {
/* 60:48 */       super(value, canHelp, comment);
/* 61:   */     }
/* 62:   */     
/* 63:   */     public boolean apply(MutableOptions mutableOptions, List<DecompilerComment> commentList, BytecodeMeta bytecodeMeta)
/* 64:   */     {
/* 65:53 */       if ((this.canhelp != null) && (!((Boolean)this.canhelp.invoke(bytecodeMeta)).booleanValue())) {
/* 66:53 */         return false;
/* 67:   */       }
/* 68:54 */       return applyComment(mutableOptions.override(this.arg, (Troolean)this.value), commentList);
/* 69:   */     }
/* 70:   */   }
/* 71:   */   
/* 72:   */   public static class BooleanRO
/* 73:   */     extends RecoveryOption<Boolean>
/* 74:   */   {
/* 75:   */     public BooleanRO(PermittedOptionProvider.Argument<Boolean> arg, boolean value)
/* 76:   */     {
/* 77:60 */       super(Boolean.valueOf(value), null, null);
/* 78:   */     }
/* 79:   */     
/* 80:   */     public BooleanRO(PermittedOptionProvider.Argument<Boolean> arg, boolean value, DecompilerComment comment)
/* 81:   */     {
/* 82:64 */       super(Boolean.valueOf(value), null, comment);
/* 83:   */     }
/* 84:   */     
/* 85:   */     public BooleanRO(PermittedOptionProvider.Argument<Boolean> arg, boolean value, UnaryFunction<BytecodeMeta, Boolean> canHelp, DecompilerComment comment)
/* 86:   */     {
/* 87:68 */       super(Boolean.valueOf(value), canHelp, comment);
/* 88:   */     }
/* 89:   */     
/* 90:   */     public boolean apply(MutableOptions mutableOptions, List<DecompilerComment> commentList, BytecodeMeta bytecodeMeta)
/* 91:   */     {
/* 92:73 */       if ((this.canhelp != null) && (!((Boolean)this.canhelp.invoke(bytecodeMeta)).booleanValue())) {
/* 93:73 */         return false;
/* 94:   */       }
/* 95:74 */       return applyComment(mutableOptions.override(this.arg, ((Boolean)this.value).booleanValue()), commentList);
/* 96:   */     }
/* 97:   */   }
/* 98:   */   
/* 99:   */   public static class ConditionalRO<X, T>
/* :0:   */     extends RecoveryOption<T>
/* :1:   */   {
/* :2:   */     private final RecoveryOption<T> delegate;
/* :3:   */     private final PermittedOptionProvider.ArgumentParam<X, ?> test;
/* :4:   */     private final X required;
/* :5:   */     
/* :6:   */     public ConditionalRO(PermittedOptionProvider.ArgumentParam<X, ?> test, X required, RecoveryOption<T> delegate)
/* :7:   */     {
/* :8:84 */       super(null, null, null);
/* :9:85 */       this.delegate = delegate;
/* ;0:86 */       this.required = required;
/* ;1:87 */       this.test = test;
/* ;2:   */     }
/* ;3:   */     
/* ;4:   */     public boolean apply(MutableOptions mutableOptions, List<DecompilerComment> commentList, BytecodeMeta bytecodeMeta)
/* ;5:   */     {
/* ;6:92 */       if (mutableOptions.getOption(this.test, null).equals(this.required)) {
/* ;7:93 */         return this.delegate.apply(mutableOptions, commentList, bytecodeMeta);
/* ;8:   */       }
/* ;9:95 */       return false;
/* <0:   */     }
/* <1:   */   }
/* <2:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.RecoveryOption
 * JD-Core Version:    0.7.0.1
 */