/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.stack;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackTypes;
/*  4:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  5:   */ 
/*  6:   */ public class StackDeltaImpl
/*  7:   */   implements StackDelta
/*  8:   */ {
/*  9:   */   private final StackTypes consumed;
/* 10:   */   private final StackTypes produced;
/* 11:   */   
/* 12:   */   public StackDeltaImpl(StackTypes consumed, StackTypes produced)
/* 13:   */   {
/* 14:11 */     if ((consumed == null) || (produced == null)) {
/* 15:12 */       throw new ConfusedCFRException("Must not have null stackTypes");
/* 16:   */     }
/* 17:14 */     this.consumed = consumed;
/* 18:15 */     this.produced = produced;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public boolean isNoOp()
/* 22:   */   {
/* 23:20 */     return (this.consumed.isEmpty()) && (this.produced.isEmpty());
/* 24:   */   }
/* 25:   */   
/* 26:   */   public StackTypes getConsumed()
/* 27:   */   {
/* 28:25 */     return this.consumed;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public StackTypes getProduced()
/* 32:   */   {
/* 33:30 */     return this.produced;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public long getChange()
/* 37:   */   {
/* 38:35 */     return this.produced.size() - this.consumed.size();
/* 39:   */   }
/* 40:   */   
/* 41:   */   public String toString()
/* 42:   */   {
/* 43:40 */     return "Consumes " + this.consumed + ", Produces " + this.produced;
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.stack.StackDeltaImpl
 * JD-Core Version:    0.7.0.1
 */