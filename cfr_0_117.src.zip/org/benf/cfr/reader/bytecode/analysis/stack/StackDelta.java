package org.benf.cfr.reader.bytecode.analysis.stack;

import org.benf.cfr.reader.bytecode.analysis.types.StackTypes;

public abstract interface StackDelta
{
  public abstract boolean isNoOp();
  
  public abstract StackTypes getConsumed();
  
  public abstract StackTypes getProduced();
  
  public abstract long getChange();
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.stack.StackDelta
 * JD-Core Version:    0.7.0.1
 */