/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.stack;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Set;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*   8:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*   9:    */ import org.benf.cfr.reader.util.ListFactory;
/*  10:    */ import org.benf.cfr.reader.util.SetFactory;
/*  11:    */ 
/*  12:    */ public class StackEntry
/*  13:    */ {
/*  14: 15 */   private static long sid = 0L;
/*  15:    */   private final long id0;
/*  16: 18 */   private final Set<Long> ids = SetFactory.newSet();
/*  17: 19 */   private int artificalSourceCount = 0;
/*  18:    */   private final StackSSALabel lValue;
/*  19: 21 */   private long usageCount = 0L;
/*  20:    */   private final StackType stackType;
/*  21: 23 */   private final InferredJavaType inferredJavaType = new InferredJavaType();
/*  22:    */   
/*  23:    */   public StackEntry(StackType stackType)
/*  24:    */   {
/*  25: 26 */     this.id0 = (sid++);
/*  26: 27 */     this.ids.add(Long.valueOf(this.id0));
/*  27: 28 */     this.lValue = new StackSSALabel(this.id0, this);
/*  28: 29 */     this.stackType = stackType;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public long incrementUsage()
/*  32:    */   {
/*  33: 33 */     return ++this.usageCount;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public long decrementUsage()
/*  37:    */   {
/*  38: 37 */     return --this.usageCount;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public long forceUsageCount(long newCount)
/*  42:    */   {
/*  43: 41 */     this.usageCount = newCount;
/*  44: 42 */     return this.usageCount;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public boolean mergeWith(StackEntry other)
/*  48:    */   {
/*  49: 46 */     if (other.stackType != this.stackType) {
/*  50: 47 */       return false;
/*  51:    */     }
/*  52: 50 */     this.ids.addAll(other.ids);
/*  53: 51 */     this.usageCount += other.usageCount;
/*  54: 52 */     return true;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public long getUsageCount()
/*  58:    */   {
/*  59: 56 */     return this.usageCount;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public int getSourceCount()
/*  63:    */   {
/*  64: 60 */     return this.ids.size() + this.artificalSourceCount;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void incSourceCount()
/*  68:    */   {
/*  69: 64 */     this.artificalSourceCount += 1;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void decSourceCount()
/*  73:    */   {
/*  74: 68 */     this.artificalSourceCount -= 1;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public List<Long> getSources()
/*  78:    */   {
/*  79: 72 */     return ListFactory.newList(this.ids);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void removeSource(long x)
/*  83:    */   {
/*  84: 76 */     if (!this.ids.remove(Long.valueOf(x))) {
/*  85: 77 */       throw new ConfusedCFRException("Attempt to remove non existent id");
/*  86:    */     }
/*  87:    */   }
/*  88:    */   
/*  89:    */   public String toString()
/*  90:    */   {
/*  91: 83 */     return "" + this.id0;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public StackSSALabel getLValue()
/*  95:    */   {
/*  96: 87 */     return this.lValue;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public StackType getType()
/* 100:    */   {
/* 101: 91 */     return this.stackType;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public InferredJavaType getInferredJavaType()
/* 105:    */   {
/* 106: 95 */     return this.inferredJavaType;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public int hashCode()
/* 110:    */   {
/* 111:100 */     return (int)this.id0;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public boolean equals(Object o)
/* 115:    */   {
/* 116:105 */     if (o == null) {
/* 117:105 */       return false;
/* 118:    */     }
/* 119:106 */     if (o == this) {
/* 120:106 */       return true;
/* 121:    */     }
/* 122:107 */     if (!(o instanceof StackEntry)) {
/* 123:107 */       return false;
/* 124:    */     }
/* 125:108 */     return this.id0 == ((StackEntry)o).id0;
/* 126:    */   }
/* 127:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.stack.StackEntry
 * JD-Core Version:    0.7.0.1
 */