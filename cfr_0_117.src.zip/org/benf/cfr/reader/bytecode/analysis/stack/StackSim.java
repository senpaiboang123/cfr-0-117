/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.stack;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.types.StackTypes;
/*   7:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*   8:    */ import org.benf.cfr.reader.util.ListFactory;
/*   9:    */ 
/*  10:    */ public class StackSim
/*  11:    */ {
/*  12:    */   private final StackSim parent;
/*  13:    */   private final StackEntryHolder stackEntryHolder;
/*  14:    */   private final long depth;
/*  15:    */   
/*  16:    */   public StackSim()
/*  17:    */   {
/*  18: 17 */     this.depth = 0L;
/*  19: 18 */     this.parent = null;
/*  20: 19 */     this.stackEntryHolder = null;
/*  21:    */   }
/*  22:    */   
/*  23:    */   private StackSim(StackSim parent, StackType stackType)
/*  24:    */   {
/*  25: 23 */     this.parent = parent;
/*  26: 24 */     parent.depth += 1L;
/*  27: 25 */     this.stackEntryHolder = new StackEntryHolder(stackType);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public StackEntry getEntry(int depth)
/*  31:    */   {
/*  32: 29 */     StackSim thisSim = this;
/*  33: 30 */     while (depth > 0)
/*  34:    */     {
/*  35: 31 */       thisSim = thisSim.getParent();
/*  36: 32 */       depth--;
/*  37:    */     }
/*  38: 34 */     if (thisSim.stackEntryHolder == null) {
/*  39: 35 */       throw new ConfusedCFRException("Underrun type stack");
/*  40:    */     }
/*  41: 37 */     return thisSim.stackEntryHolder.getStackEntry();
/*  42:    */   }
/*  43:    */   
/*  44:    */   public List<StackEntryHolder> getHolders(int offset, long num)
/*  45:    */   {
/*  46: 41 */     StackSim thisSim = this;
/*  47: 42 */     List<StackEntryHolder> res = ListFactory.newList();
/*  48: 43 */     while (num > 0L)
/*  49:    */     {
/*  50: 44 */       if (offset > 0)
/*  51:    */       {
/*  52: 45 */         offset--;
/*  53:    */       }
/*  54:    */       else
/*  55:    */       {
/*  56: 47 */         res.add(thisSim.stackEntryHolder);
/*  57: 48 */         num -= 1L;
/*  58:    */       }
/*  59: 50 */       thisSim = thisSim.getParent();
/*  60:    */     }
/*  61: 52 */     return res;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public long getDepth()
/*  65:    */   {
/*  66: 56 */     return this.depth;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public StackSim getChange(StackDelta delta, List<StackEntryHolder> consumed, List<StackEntryHolder> produced, Op02WithProcessedDataAndRefs instruction)
/*  70:    */   {
/*  71: 60 */     if (delta.isNoOp()) {
/*  72: 61 */       return this;
/*  73:    */     }
/*  74:    */     try
/*  75:    */     {
/*  76: 64 */       StackSim thisSim = this;
/*  77: 65 */       StackTypes consumedStack = delta.getConsumed();
/*  78: 66 */       for (StackType stackType : consumedStack)
/*  79:    */       {
/*  80: 67 */         consumed.add(thisSim.stackEntryHolder);
/*  81: 68 */         thisSim = thisSim.getParent();
/*  82:    */       }
/*  83: 70 */       StackTypes producedStack = delta.getProduced();
/*  84: 71 */       for (int x = producedStack.size() - 1; x >= 0; x--) {
/*  85: 72 */         thisSim = new StackSim(thisSim, (StackType)producedStack.get(x));
/*  86:    */       }
/*  87: 74 */       StackSim thatSim = thisSim;
/*  88: 75 */       for (StackType stackType : producedStack)
/*  89:    */       {
/*  90: 76 */         produced.add(thatSim.stackEntryHolder);
/*  91: 77 */         thatSim = thatSim.getParent();
/*  92:    */       }
/*  93: 79 */       return thisSim;
/*  94:    */     }
/*  95:    */     catch (ConfusedCFRException e)
/*  96:    */     {
/*  97: 81 */       throw new ConfusedCFRException("While processing " + instruction + " : " + e.getMessage());
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   private StackSim getParent()
/* 102:    */   {
/* 103: 86 */     if (this.parent == null) {
/* 104: 87 */       throw new ConfusedCFRException("Stack underflow");
/* 105:    */     }
/* 106: 89 */     return this.parent;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public String toString()
/* 110:    */   {
/* 111: 94 */     StackSim next = this;
/* 112: 95 */     StringBuilder sb = new StringBuilder();
/* 113: 96 */     while ((next != null) && 
/* 114: 97 */       (next.stackEntryHolder != null))
/* 115:    */     {
/* 116: 98 */       StackEntry stackEntry = next.stackEntryHolder.getStackEntry();
/* 117: 99 */       sb.append(stackEntry).append('[').append(stackEntry.getType()).append("] ");
/* 118:100 */       next = next.parent;
/* 119:    */     }
/* 120:102 */     return sb.toString();
/* 121:    */   }
/* 122:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.stack.StackSim
 * JD-Core Version:    0.7.0.1
 */