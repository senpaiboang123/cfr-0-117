/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.stack;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/*  4:   */ 
/*  5:   */ public class StackEntryHolder
/*  6:   */ {
/*  7:   */   private StackEntry stackEntry;
/*  8:   */   
/*  9:   */   public StackEntryHolder(StackType stackType)
/* 10:   */   {
/* 11: 9 */     this.stackEntry = new StackEntry(stackType);
/* 12:   */   }
/* 13:   */   
/* 14:   */   public void mergeWith(StackEntryHolder other)
/* 15:   */   {
/* 16:13 */     if (this.stackEntry.mergeWith(other.stackEntry)) {
/* 17:14 */       other.stackEntry = this.stackEntry;
/* 18:   */     }
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String toString()
/* 22:   */   {
/* 23:20 */     return this.stackEntry.toString();
/* 24:   */   }
/* 25:   */   
/* 26:   */   public StackEntry getStackEntry()
/* 27:   */   {
/* 28:24 */     return this.stackEntry;
/* 29:   */   }
/* 30:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.stack.StackEntryHolder
 * JD-Core Version:    0.7.0.1
 */