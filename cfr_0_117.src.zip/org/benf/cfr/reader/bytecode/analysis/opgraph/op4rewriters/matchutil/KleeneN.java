/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  4:   */ 
/*  5:   */ public class KleeneN
/*  6:   */   implements Matcher<StructuredStatement>
/*  7:   */ {
/*  8:   */   private final Matcher<StructuredStatement> inner;
/*  9:   */   private final int nRequired;
/* 10:   */   
/* 11:   */   public KleeneN(int nRequired, Matcher<StructuredStatement> inner)
/* 12:   */   {
/* 13:10 */     this.inner = inner;
/* 14:11 */     this.nRequired = nRequired;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public KleeneN(int nRequired, Matcher<StructuredStatement>... matchers)
/* 18:   */   {
/* 19:15 */     this.inner = new MatchSequence(matchers);
/* 20:16 */     this.nRequired = nRequired;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 24:   */   {
/* 25:21 */     MatchIterator<StructuredStatement> mi = matchIterator.copy();
/* 26:   */     
/* 27:23 */     int nMatches = 0;
/* 28:24 */     while (this.inner.match(mi, matchResultCollector)) {
/* 29:25 */       nMatches++;
/* 30:   */     }
/* 31:28 */     if (nMatches >= this.nRequired)
/* 32:   */     {
/* 33:29 */       matchIterator.advanceTo(mi);
/* 34:30 */       return true;
/* 35:   */     }
/* 36:32 */     return false;
/* 37:   */   }
/* 38:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.KleeneN
 * JD-Core Version:    0.7.0.1
 */