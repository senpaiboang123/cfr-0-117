/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  4:   */ 
/*  5:   */ public class MatchSequence
/*  6:   */   implements Matcher<StructuredStatement>
/*  7:   */ {
/*  8:   */   private final Matcher<StructuredStatement>[] inner;
/*  9:   */   private final String name;
/* 10:   */   
/* 11:   */   public MatchSequence(Matcher<StructuredStatement>... inner)
/* 12:   */   {
/* 13:11 */     this.inner = inner;
/* 14:12 */     this.name = "";
/* 15:   */   }
/* 16:   */   
/* 17:   */   public MatchSequence(String name, Matcher<StructuredStatement>... inner)
/* 18:   */   {
/* 19:16 */     this.inner = inner;
/* 20:17 */     this.name = name;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 24:   */   {
/* 25:22 */     MatchIterator<StructuredStatement> mi = matchIterator.copy();
/* 26:24 */     for (Matcher<StructuredStatement> matcher : this.inner) {
/* 27:25 */       if (!matcher.match(mi, matchResultCollector)) {
/* 28:25 */         return false;
/* 29:   */       }
/* 30:   */     }
/* 31:28 */     matchIterator.advanceTo(mi);
/* 32:29 */     return true;
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchSequence
 * JD-Core Version:    0.7.0.1
 */