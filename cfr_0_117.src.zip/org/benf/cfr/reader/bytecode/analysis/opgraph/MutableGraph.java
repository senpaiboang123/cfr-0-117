package org.benf.cfr.reader.bytecode.analysis.opgraph;

public abstract interface MutableGraph<T>
  extends Graph<T>
{
  public abstract void addSource(T paramT);
  
  public abstract void addTarget(T paramT);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.MutableGraph
 * JD-Core Version:    0.7.0.1
 */