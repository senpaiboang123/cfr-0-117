/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.BooleanExpression;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CompOp;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ComparisonOperation;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.NotOperation;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/* 14:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/* 15:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/* 16:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/* 17:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 18:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/* 19:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 20:   */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/* 21:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 22:   */ 
/* 23:   */ public class TypedBooleanTidier
/* 24:   */   implements StructuredStatementTransformer, ExpressionRewriter
/* 25:   */ {
/* 26:   */   public void transform(Op04StructuredStatement root)
/* 27:   */   {
/* 28:24 */     StructuredScope structuredScope = new StructuredScope();
/* 29:25 */     root.transform(this, structuredScope);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public StructuredStatement transform(StructuredStatement in, StructuredScope scope)
/* 33:   */   {
/* 34:30 */     in.transformStructuredChildren(this, scope);
/* 35:31 */     in.rewriteExpressions(this);
/* 36:32 */     return in;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 40:   */   {
/* 41:37 */     if ((expression instanceof ConditionalExpression)) {
/* 42:38 */       return rewriteExpression((ConditionalExpression)expression, ssaIdentifiers, statementContainer, flags);
/* 43:   */     }
/* 44:40 */     return expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 45:   */   }
/* 46:   */   
/* 47:   */   public ConditionalExpression rewriteExpression(ConditionalExpression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 48:   */   {
/* 49:45 */     expression = (ConditionalExpression)expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 50:46 */     if (!(expression instanceof ComparisonOperation)) {
/* 51:46 */       return expression;
/* 52:   */     }
/* 53:48 */     ComparisonOperation comparisonOperation = (ComparisonOperation)expression;
/* 54:49 */     Expression lhs = comparisonOperation.getLhs();
/* 55:50 */     Expression rhs = comparisonOperation.getRhs();
/* 56:51 */     CompOp op = comparisonOperation.getOp();
/* 57:52 */     if ((lhs.getInferredJavaType().getJavaTypeInstance() != RawJavaType.BOOLEAN) || (rhs.getInferredJavaType().getJavaTypeInstance() != RawJavaType.BOOLEAN) || ((op != CompOp.EQ) && (op != CompOp.NE))) {
/* 58:54 */       return expression;
/* 59:   */     }
/* 60:56 */     if (!(rhs instanceof Literal)) {
/* 61:56 */       return expression;
/* 62:   */     }
/* 63:58 */     boolean b = ((Literal)rhs).getValue().getBoolValue();
/* 64:60 */     if (op == CompOp.NE) {
/* 65:60 */       b = !b;
/* 66:   */     }
/* 67:   */     ConditionalExpression res;
/* 68:   */     ConditionalExpression res;
/* 69:64 */     if ((lhs instanceof ConditionalExpression)) {
/* 70:65 */       res = (ConditionalExpression)lhs;
/* 71:   */     } else {
/* 72:67 */       res = new BooleanExpression(lhs);
/* 73:   */     }
/* 74:69 */     if (!b) {
/* 75:69 */       res = new NotOperation(res);
/* 76:   */     }
/* 77:70 */     return res;
/* 78:   */   }
/* 79:   */   
/* 80:   */   public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 81:   */   {
/* 82:80 */     return lValue;
/* 83:   */   }
/* 84:   */   
/* 85:   */   public StackSSALabel rewriteExpression(StackSSALabel lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 86:   */   {
/* 87:85 */     return lValue;
/* 88:   */   }
/* 89:   */   
/* 90:   */   public void handleStatement(StatementContainer statementContainer) {}
/* 91:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.TypedBooleanTidier
 * JD-Core Version:    0.7.0.1
 */