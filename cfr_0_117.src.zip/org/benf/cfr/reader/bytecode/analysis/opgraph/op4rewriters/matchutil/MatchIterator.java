/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  5:   */ 
/*  6:   */ public class MatchIterator<T>
/*  7:   */ {
/*  8:   */   private final List<T> data;
/*  9:   */   private int idx;
/* 10:   */   
/* 11:   */   public MatchIterator(List<T> data)
/* 12:   */   {
/* 13:12 */     this.data = data;
/* 14:13 */     this.idx = -1;
/* 15:   */   }
/* 16:   */   
/* 17:   */   private MatchIterator(List<T> data, int idx)
/* 18:   */   {
/* 19:17 */     this.data = data;
/* 20:18 */     this.idx = idx;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public T getCurrent()
/* 24:   */   {
/* 25:22 */     if (this.idx < 0) {
/* 26:22 */       throw new IllegalStateException("Accessed before being advanced.");
/* 27:   */     }
/* 28:23 */     if (this.idx >= this.data.size()) {
/* 29:24 */       throw new IllegalStateException("Out of range");
/* 30:   */     }
/* 31:26 */     return this.data.get(this.idx);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public MatchIterator<T> copy()
/* 35:   */   {
/* 36:30 */     return new MatchIterator(this.data, this.idx);
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void advanceTo(MatchIterator<StructuredStatement> other)
/* 40:   */   {
/* 41:34 */     if (this.data != other.data) {
/* 42:34 */       throw new IllegalStateException();
/* 43:   */     }
/* 44:35 */     this.idx = other.idx;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public boolean hasNext()
/* 48:   */   {
/* 49:39 */     return this.idx < this.data.size() - 1;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public boolean isFinished()
/* 53:   */   {
/* 54:43 */     return this.idx >= this.data.size();
/* 55:   */   }
/* 56:   */   
/* 57:   */   public int getRemaining()
/* 58:   */   {
/* 59:47 */     return this.data.size() - this.idx;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public boolean advance()
/* 63:   */   {
/* 64:51 */     if (!isFinished()) {
/* 65:51 */       this.idx += 1;
/* 66:   */     }
/* 67:52 */     return !isFinished();
/* 68:   */   }
/* 69:   */   
/* 70:   */   public void rewind1()
/* 71:   */   {
/* 72:56 */     if (this.idx > 0) {
/* 73:56 */       this.idx -= 1;
/* 74:   */     }
/* 75:   */   }
/* 76:   */   
/* 77:   */   public String toString()
/* 78:   */   {
/* 79:61 */     if (isFinished()) {
/* 80:61 */       return "Finished";
/* 81:   */     }
/* 82:62 */     T t = this.data.get(this.idx);
/* 83:63 */     return t == null ? "null" : t.toString();
/* 84:   */   }
/* 85:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator
 * JD-Core Version:    0.7.0.1
 */