/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ReturnNothingStatement;
/*  7:   */ import org.benf.cfr.reader.entities.Method;
/*  8:   */ import org.benf.cfr.reader.util.getopt.Options;
/*  9:   */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/* 10:   */ 
/* 11:   */ public class StaticInitReturnRewriter
/* 12:   */ {
/* 13:   */   public static List<Op03SimpleStatement> rewrite(Options options, Method method, List<Op03SimpleStatement> statementList)
/* 14:   */   {
/* 15:19 */     if (!method.getName().equals("<clinit>")) {
/* 16:19 */       return statementList;
/* 17:   */     }
/* 18:20 */     if (!((Boolean)options.getOption(OptionsImpl.STATIC_INIT_RETURN)).booleanValue()) {
/* 19:20 */       return statementList;
/* 20:   */     }
/* 21:25 */     Op03SimpleStatement last = (Op03SimpleStatement)statementList.get(statementList.size() - 1);
/* 22:26 */     if (last.getStatement().getClass() != ReturnNothingStatement.class) {
/* 23:26 */       return statementList;
/* 24:   */     }
/* 25:27 */     int x = 0;
/* 26:27 */     for (int len = statementList.size() - 1; x < len; x++)
/* 27:   */     {
/* 28:28 */       Op03SimpleStatement stm = (Op03SimpleStatement)statementList.get(x);
/* 29:29 */       if (stm.getStatement().getClass() == ReturnNothingStatement.class)
/* 30:   */       {
/* 31:30 */         stm.replaceStatement(new GotoStatement());
/* 32:31 */         stm.addTarget(last);
/* 33:32 */         last.addSource(stm);
/* 34:   */       }
/* 35:   */     }
/* 36:35 */     return statementList;
/* 37:   */   }
/* 38:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.StaticInitReturnRewriter
 * JD-Core Version:    0.7.0.1
 */