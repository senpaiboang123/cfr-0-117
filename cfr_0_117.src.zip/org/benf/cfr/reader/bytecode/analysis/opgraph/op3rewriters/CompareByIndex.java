/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*  2:   */ 
/*  3:   */ import java.util.Comparator;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.InstrIndex;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  6:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  7:   */ 
/*  8:   */ public class CompareByIndex
/*  9:   */   implements Comparator<Op03SimpleStatement>
/* 10:   */ {
/* 11:   */   public int compare(Op03SimpleStatement a, Op03SimpleStatement b)
/* 12:   */   {
/* 13:11 */     int res = a.getIndex().compareTo(b.getIndex());
/* 14:12 */     if (res == 0) {
/* 15:13 */       throw new ConfusedCFRException("Can't sort instructions:\n" + a + "\n" + b);
/* 16:   */     }
/* 17:15 */     return res;
/* 18:   */   }
/* 19:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.CompareByIndex
 * JD-Core Version:    0.7.0.1
 */