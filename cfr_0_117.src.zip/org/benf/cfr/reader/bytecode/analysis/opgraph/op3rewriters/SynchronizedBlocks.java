/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*   2:    */ 
/*   3:    */ import java.util.Iterator;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Set;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CatchStatement;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CommentStatement;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.FinallyStatement;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.MonitorEnterStatement;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.MonitorExitStatement;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.Nop;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ReturnStatement;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ThrowStatement;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.TryStatement;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  20:    */ import org.benf.cfr.reader.util.Functional;
/*  21:    */ import org.benf.cfr.reader.util.ListFactory;
/*  22:    */ import org.benf.cfr.reader.util.SetFactory;
/*  23:    */ import org.benf.cfr.reader.util.SetUtil;
/*  24:    */ import org.benf.cfr.reader.util.functors.BinaryProcedure;
/*  25:    */ import org.benf.cfr.reader.util.graph.GraphVisitor;
/*  26:    */ import org.benf.cfr.reader.util.graph.GraphVisitorDFS;
/*  27:    */ 
/*  28:    */ public class SynchronizedBlocks
/*  29:    */ {
/*  30:    */   public static void findSynchronizedBlocks(List<Op03SimpleStatement> statements)
/*  31:    */   {
/*  32: 38 */     List<Op03SimpleStatement> enters = Functional.filter(statements, new TypeFilter(MonitorEnterStatement.class));
/*  33: 43 */     for (Op03SimpleStatement enter : enters)
/*  34:    */     {
/*  35: 44 */       MonitorEnterStatement monitorExitStatement = (MonitorEnterStatement)enter.getStatement();
/*  36:    */       
/*  37: 46 */       findSynchronizedRange(enter, monitorExitStatement.getMonitor());
/*  38:    */     }
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static void findSynchronizedRange(Op03SimpleStatement start, Expression monitor)
/*  42:    */   {
/*  43: 51 */     final Set<Op03SimpleStatement> addToBlock = SetFactory.newSet();
/*  44:    */     
/*  45: 53 */     final Set<Op03SimpleStatement> foundExits = SetFactory.newSet();
/*  46: 54 */     final Set<Op03SimpleStatement> extraNodes = SetFactory.newSet();
/*  47:    */     
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62: 70 */     final Set<BlockIdentifier> leaveExitsMutex = SetFactory.newSet();
/*  63:    */     
/*  64: 72 */     GraphVisitor<Op03SimpleStatement> marker = new GraphVisitorDFS(start.getTargets(), new BinaryProcedure()
/*  65:    */     {
/*  66:    */       public void call(Op03SimpleStatement arg1, GraphVisitor<Op03SimpleStatement> arg2)
/*  67:    */       {
/*  68: 79 */         Statement statement = arg1.getStatement();
/*  69: 81 */         if ((statement instanceof TryStatement))
/*  70:    */         {
/*  71: 82 */           TryStatement tryStatement = (TryStatement)statement;
/*  72: 83 */           Set<Expression> tryMonitors = tryStatement.getMonitors();
/*  73: 84 */           if (tryMonitors.contains(this.val$monitor))
/*  74:    */           {
/*  75: 85 */             leaveExitsMutex.add(tryStatement.getBlockIdentifier());
/*  76: 86 */             List<Op03SimpleStatement> tgts = arg1.getTargets();
/*  77: 87 */             int x = 1;
/*  78: 87 */             for (int len = tgts.size(); x < len; x++)
/*  79:    */             {
/*  80: 88 */               Statement innerS = ((Op03SimpleStatement)tgts.get(x)).getStatement();
/*  81: 89 */               if ((innerS instanceof CatchStatement)) {
/*  82: 90 */                 leaveExitsMutex.add(((CatchStatement)innerS).getCatchBlockIdent());
/*  83: 91 */               } else if ((innerS instanceof FinallyStatement)) {
/*  84: 92 */                 leaveExitsMutex.add(((FinallyStatement)innerS).getFinallyBlockIdent());
/*  85:    */               }
/*  86:    */             }
/*  87:    */           }
/*  88:    */         }
/*  89: 98 */         if (((statement instanceof MonitorExitStatement)) && 
/*  90: 99 */           (this.val$monitor.equals(((MonitorExitStatement)statement).getMonitor())))
/*  91:    */         {
/*  92:100 */           foundExits.add(arg1);
/*  93:101 */           addToBlock.add(arg1);
/*  94:106 */           if (arg1.getTargets().size() == 1)
/*  95:    */           {
/*  96:107 */             arg1 = (Op03SimpleStatement)arg1.getTargets().get(0);
/*  97:108 */             Statement targetStatement = arg1.getStatement();
/*  98:109 */             if (((targetStatement instanceof ReturnStatement)) || ((targetStatement instanceof ThrowStatement)) || ((targetStatement instanceof Nop)) || ((targetStatement instanceof GotoStatement))) {
/*  99:114 */               extraNodes.add(arg1);
/* 100:    */             }
/* 101:    */           }
/* 102:118 */           return;
/* 103:    */         }
/* 104:121 */         addToBlock.add(arg1);
/* 105:122 */         if (SetUtil.hasIntersection(arg1.getBlockIdentifiers(), leaveExitsMutex)) {
/* 106:123 */           for (Op03SimpleStatement tgt : arg1.getTargets()) {
/* 107:124 */             if (SetUtil.hasIntersection(tgt.getBlockIdentifiers(), leaveExitsMutex)) {
/* 108:125 */               arg2.enqueue(tgt);
/* 109:    */             }
/* 110:    */           }
/* 111:    */         } else {
/* 112:129 */           arg2.enqueue(arg1.getTargets());
/* 113:    */         }
/* 114:    */       }
/* 115:133 */     });
/* 116:134 */     marker.process();
/* 117:    */     
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:    */ 
/* 127:    */ 
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:    */ 
/* 134:    */ 
/* 135:153 */     addToBlock.remove(start);
/* 136:    */     
/* 137:    */ 
/* 138:    */ 
/* 139:157 */     Set<Op03SimpleStatement> requiredComments = SetFactory.newSet();
/* 140:158 */     Iterator<Op03SimpleStatement> foundExitIter = foundExits.iterator();
/* 141:159 */     while (foundExitIter.hasNext())
/* 142:    */     {
/* 143:160 */       final Op03SimpleStatement foundExit = (Op03SimpleStatement)foundExitIter.next();
/* 144:161 */       Set<BlockIdentifier> exitBlocks = SetFactory.newSet(foundExit.getBlockIdentifiers());
/* 145:162 */       exitBlocks.removeAll(start.getBlockIdentifiers());
/* 146:163 */       final List<Op03SimpleStatement> added = ListFactory.newList();
/* 147:164 */       GraphVisitor<Op03SimpleStatement> additional = new GraphVisitorDFS(foundExit, new BinaryProcedure()
/* 148:    */       {
/* 149:    */         public void call(Op03SimpleStatement arg1, GraphVisitor<Op03SimpleStatement> arg2)
/* 150:    */         {
/* 151:167 */           if (SetUtil.hasIntersection(this.val$exitBlocks, arg1.getBlockIdentifiers())) {
/* 152:168 */             if (arg1 == foundExit)
/* 153:    */             {
/* 154:169 */               arg2.enqueue(arg1.getTargets());
/* 155:    */             }
/* 156:170 */             else if (addToBlock.add(arg1))
/* 157:    */             {
/* 158:171 */               added.add(arg1);
/* 159:172 */               arg2.enqueue(arg1.getTargets());
/* 160:    */             }
/* 161:    */           }
/* 162:    */         }
/* 163:176 */       });
/* 164:177 */       additional.process();
/* 165:179 */       if (anyOpHasEffect(added))
/* 166:    */       {
/* 167:180 */         requiredComments.add(foundExit);
/* 168:181 */         foundExitIter.remove();
/* 169:    */       }
/* 170:    */     }
/* 171:186 */     MonitorEnterStatement monitorEnterStatement = (MonitorEnterStatement)start.getStatement();
/* 172:187 */     BlockIdentifier blockIdentifier = monitorEnterStatement.getBlockIdentifier();
/* 173:188 */     for (Op03SimpleStatement contained : addToBlock) {
/* 174:189 */       contained.getBlockIdentifiers().add(blockIdentifier);
/* 175:    */     }
/* 176:192 */     for (Op03SimpleStatement exit : foundExits) {
/* 177:193 */       exit.nopOut();
/* 178:    */     }
/* 179:196 */     for (Op03SimpleStatement exit : requiredComments) {
/* 180:197 */       exit.replaceStatement(new CommentStatement("MONITOREXIT " + exit));
/* 181:    */     }
/* 182:204 */     for (Op03SimpleStatement extra : extraNodes)
/* 183:    */     {
/* 184:205 */       boolean allParents = true;
/* 185:206 */       for (Op03SimpleStatement source : extra.getSources()) {
/* 186:207 */         if (!source.getBlockIdentifiers().contains(blockIdentifier)) {
/* 187:208 */           allParents = false;
/* 188:    */         }
/* 189:    */       }
/* 190:211 */       if (allParents) {
/* 191:212 */         extra.getBlockIdentifiers().add(blockIdentifier);
/* 192:    */       }
/* 193:    */     }
/* 194:    */   }
/* 195:    */   
/* 196:    */   private static boolean anyOpHasEffect(List<Op03SimpleStatement> ops)
/* 197:    */   {
/* 198:226 */     for (Op03SimpleStatement op : ops)
/* 199:    */     {
/* 200:227 */       Statement stm = op.getStatement();
/* 201:228 */       Class<?> stmcls = stm.getClass();
/* 202:229 */       if ((stmcls != GotoStatement.class) && 
/* 203:230 */         (stmcls != ThrowStatement.class) && 
/* 204:231 */         (stmcls != CommentStatement.class) && 
/* 205:232 */         (!(stm instanceof ReturnStatement))) {
/* 206:233 */         return true;
/* 207:    */       }
/* 208:    */     }
/* 209:235 */     return false;
/* 210:    */   }
/* 211:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SynchronizedBlocks
 * JD-Core Version:    0.7.0.1
 */