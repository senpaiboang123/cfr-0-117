/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  4:   */ import org.benf.cfr.reader.util.Predicate;
/*  5:   */ 
/*  6:   */ public class TypeFilter<T>
/*  7:   */   implements Predicate<Op03SimpleStatement>
/*  8:   */ {
/*  9:   */   private final Class<T> clazz;
/* 10:   */   private final boolean positive;
/* 11:   */   
/* 12:   */   public TypeFilter(Class<T> clazz)
/* 13:   */   {
/* 14:11 */     this.clazz = clazz;
/* 15:12 */     this.positive = true;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public TypeFilter(Class<T> clazz, boolean positive)
/* 19:   */   {
/* 20:16 */     this.clazz = clazz;
/* 21:17 */     this.positive = positive;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public boolean test(Op03SimpleStatement in)
/* 25:   */   {
/* 26:22 */     return this.positive == this.clazz.isInstance(in.getStatement());
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.TypeFilter
 * JD-Core Version:    0.7.0.1
 */