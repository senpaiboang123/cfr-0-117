/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  6:   */ 
/*  7:   */ public class ExpressionRewriterTransformer
/*  8:   */   implements StructuredStatementTransformer
/*  9:   */ {
/* 10:   */   private final ExpressionRewriter expressionRewriter;
/* 11:   */   
/* 12:   */   public ExpressionRewriterTransformer(ExpressionRewriter expressionRewriter)
/* 13:   */   {
/* 14:11 */     this.expressionRewriter = expressionRewriter;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public StructuredStatement transform(StructuredStatement in, StructuredScope scope)
/* 18:   */   {
/* 19:18 */     in.rewriteExpressions(this.expressionRewriter);
/* 20:19 */     in.transformStructuredChildren(this, scope);
/* 21:20 */     return in;
/* 22:   */   }
/* 23:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.ExpressionRewriterTransformer
 * JD-Core Version:    0.7.0.1
 */