/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.types.DynamicInvokeType;
/*  5:   */ import org.benf.cfr.reader.bytecode.opcode.JVMInstr;
/*  6:   */ import org.benf.cfr.reader.entities.ClassFile;
/*  7:   */ import org.benf.cfr.reader.entities.attributes.AttributeBootstrapMethods;
/*  8:   */ import org.benf.cfr.reader.entities.bootstrap.BootstrapMethodInfo;
/*  9:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/* 10:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryInvokeDynamic;
/* 11:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodRef;
/* 12:   */ 
/* 13:   */ public class GetClassTestLambda
/* 14:   */   implements GetClassTest
/* 15:   */ {
/* 16:18 */   public static GetClassTest INSTANCE = new GetClassTestLambda();
/* 17:   */   
/* 18:   */   public JVMInstr getInstr()
/* 19:   */   {
/* 20:25 */     return JVMInstr.INVOKEDYNAMIC;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public boolean test(ClassFile classFile, Op02WithProcessedDataAndRefs item)
/* 24:   */   {
/* 25:30 */     ConstantPoolEntry[] cpEntries = item.getCpEntries();
/* 26:31 */     ConstantPoolEntryInvokeDynamic invokeDynamic = (ConstantPoolEntryInvokeDynamic)cpEntries[0];
/* 27:   */     
/* 28:   */ 
/* 29:34 */     int idx = invokeDynamic.getBootstrapMethodAttrIndex();
/* 30:   */     
/* 31:36 */     BootstrapMethodInfo bootstrapMethodInfo = classFile.getBootstrapMethods().getBootStrapMethodInfo(idx);
/* 32:37 */     ConstantPoolEntryMethodRef methodRef = bootstrapMethodInfo.getConstantPoolEntryMethodRef();
/* 33:38 */     String methodName = methodRef.getName();
/* 34:   */     
/* 35:40 */     DynamicInvokeType dynamicInvokeType = DynamicInvokeType.lookup(methodName);
/* 36:41 */     if (dynamicInvokeType == DynamicInvokeType.UNKNOWN) {
/* 37:41 */       return false;
/* 38:   */     }
/* 39:43 */     return true;
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters.GetClassTestLambda
 * JD-Core Version:    0.7.0.1
 */