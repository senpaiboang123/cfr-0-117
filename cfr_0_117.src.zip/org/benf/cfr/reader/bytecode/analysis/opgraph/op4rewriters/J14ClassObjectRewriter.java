/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Set;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchSequence;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.Matcher;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.ExpressionRewriterTransformer;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.MiscStatementTools;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AssignmentExpression;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CompOp;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ComparisonOperation;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.TernaryExpression;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral.LiteralType;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StaticVariable;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  26:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.QuotingUtils;
/*  27:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
/*  28:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.ExpressionWildcard;
/*  29:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.StaticVariableWildcard;
/*  30:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  31:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  32:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredCatch;
/*  33:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredReturn;
/*  34:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredThrow;
/*  35:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredTry;
/*  36:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.BeginBlock;
/*  37:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.EndBlock;
/*  38:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  39:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  40:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  41:    */ import org.benf.cfr.reader.bytecode.analysis.types.TypeConstants;
/*  42:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  43:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  44:    */ import org.benf.cfr.reader.entities.AccessFlagMethod;
/*  45:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  46:    */ import org.benf.cfr.reader.entities.ClassFileField;
/*  47:    */ import org.benf.cfr.reader.entities.Method;
/*  48:    */ import org.benf.cfr.reader.state.ClassCache;
/*  49:    */ import org.benf.cfr.reader.state.DCCommonState;
/*  50:    */ import org.benf.cfr.reader.util.ListFactory;
/*  51:    */ import org.benf.cfr.reader.util.SetFactory;
/*  52:    */ import org.benf.cfr.reader.util.functors.NonaryFunction;
/*  53:    */ 
/*  54:    */ public class J14ClassObjectRewriter
/*  55:    */ {
/*  56:    */   private final ClassFile classFile;
/*  57:    */   private final DCCommonState state;
/*  58: 78 */   private static final JavaRefTypeInstance CLASSNOTFOUND_EXCEPTION = JavaRefTypeInstance.createTypeConstant("java.lang.ClassNotFoundException", "ClassNotFoundException", new JavaRefTypeInstance[0]);
/*  59: 79 */   private static final JavaRefTypeInstance NOCLASSDEFFOUND_ERROR = JavaRefTypeInstance.createTypeConstant("java.lang.NoClassDefFoundError", "NoClassDefFoundError", new JavaRefTypeInstance[0]);
/*  60: 80 */   private static final JavaRefTypeInstance CLASS = JavaRefTypeInstance.createTypeConstant("java.lang.Class", "Class", new JavaRefTypeInstance[0]);
/*  61:    */   
/*  62:    */   public J14ClassObjectRewriter(ClassFile classFile, DCCommonState state)
/*  63:    */   {
/*  64: 83 */     this.classFile = classFile;
/*  65: 84 */     this.state = state;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void rewrite()
/*  69:    */   {
/*  70: 94 */     Method method = this.classFile.getSingleMethodByNameOrNull("class$");
/*  71: 95 */     JavaTypeInstance classType = this.classFile.getClassType();
/*  72: 96 */     if (!methodIsClassLookup(method)) {
/*  73: 96 */       return;
/*  74:    */     }
/*  75:102 */     method.hideSynthetic();
/*  76:    */     
/*  77:    */ 
/*  78:105 */     final WildcardMatch wcm = new WildcardMatch();
/*  79:106 */     final WildcardMatch.StaticVariableWildcard staticVariable = wcm.getStaticVariable("classVar", classType, new InferredJavaType(CLASS, InferredJavaType.Source.TEST));
/*  80:107 */     LValueExpression staticExpression = new LValueExpression(staticVariable);
/*  81:108 */     Expression test = new TernaryExpression(new ComparisonOperation(staticExpression, Literal.NULL, CompOp.EQ), new AssignmentExpression(staticVariable, wcm.getStaticFunction("test", classType, TypeConstants.CLASS, null, ListFactory.newList(new Expression[] { wcm.getExpressionWildCard("classString") }))), staticExpression);
/*  82:    */     
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:119 */     final Set<Pair<String, JavaTypeInstance>> hideThese = SetFactory.newSet();
/*  93:120 */     ExpressionRewriter expressionRewriter = new ExpressionWildcardReplacingRewriter(wcm, test, new NonaryFunction()
/*  94:    */     {
/*  95:    */       public Expression invoke()
/*  96:    */       {
/*  97:123 */         Expression string = wcm.getExpressionWildCard("classString").getMatch();
/*  98:124 */         if (!(string instanceof Literal)) {
/*  99:124 */           return null;
/* 100:    */         }
/* 101:125 */         TypedLiteral literal = ((Literal)string).getValue();
/* 102:126 */         if (literal.getType() != TypedLiteral.LiteralType.String) {
/* 103:126 */           return null;
/* 104:    */         }
/* 105:127 */         Expression res = new Literal(TypedLiteral.getClass(J14ClassObjectRewriter.this.state.getClassCache().getRefClassFor(QuotingUtils.unquoteString((String)literal.getValue()))));
/* 106:    */         
/* 107:129 */         StaticVariable found = staticVariable.getMatch();
/* 108:130 */         hideThese.add(Pair.make(found.getFieldName(), found.getInferredJavaType().getJavaTypeInstance()));
/* 109:131 */         return res;
/* 110:    */       }
/* 111:134 */     });
/* 112:135 */     StructuredStatementTransformer transformer = new ExpressionRewriterTransformer(expressionRewriter);
/* 113:140 */     for (ClassFileField field : this.classFile.getFields())
/* 114:    */     {
/* 115:141 */       Expression initialValue = field.getInitialValue();
/* 116:142 */       field.setInitialValue(expressionRewriter.rewriteExpression(initialValue, null, null, ExpressionRewriterFlags.RVALUE));
/* 117:    */     }
/* 118:145 */     for (Method testMethod : this.classFile.getMethods()) {
/* 119:146 */       if (testMethod.hasCodeAttribute()) {
/* 120:147 */         testMethod.getAnalysis().transform(transformer, new StructuredScope());
/* 121:    */       }
/* 122:    */     }
/* 123:151 */     for (Pair<String, JavaTypeInstance> hideThis : hideThese) {
/* 124:    */       try
/* 125:    */       {
/* 126:153 */         ClassFileField fileField = this.classFile.getFieldByName((String)hideThis.getFirst(), (JavaTypeInstance)hideThis.getSecond());
/* 127:154 */         fileField.markHidden();
/* 128:    */       }
/* 129:    */       catch (NoSuchFieldException e) {}
/* 130:    */     }
/* 131:    */   }
/* 132:    */   
/* 133:    */   private boolean methodIsClassLookup(Method method)
/* 134:    */   {
/* 135:161 */     if (method == null) {
/* 136:161 */       return false;
/* 137:    */     }
/* 138:165 */     if (!method.getAccessFlags().contains(AccessFlagMethod.ACC_SYNTHETIC)) {
/* 139:165 */       return false;
/* 140:    */     }
/* 141:166 */     if (!method.hasCodeAttribute()) {
/* 142:166 */       return false;
/* 143:    */     }
/* 144:167 */     List<StructuredStatement> statements = MiscStatementTools.linearise(method.getAnalysis());
/* 145:168 */     if (statements == null) {
/* 146:168 */       return false;
/* 147:    */     }
/* 148:169 */     MatchIterator<StructuredStatement> mi = new MatchIterator(statements);
/* 149:170 */     WildcardMatch wcm1 = new WildcardMatch();
/* 150:    */     
/* 151:172 */     List<LocalVariable> args = method.getMethodPrototype().getComputedParameters();
/* 152:173 */     if (args.size() != 1) {
/* 153:173 */       return false;
/* 154:    */     }
/* 155:174 */     LocalVariable arg = (LocalVariable)args.get(0);
/* 156:175 */     if (!TypeConstants.STRING.equals(arg.getInferredJavaType().getJavaTypeInstance())) {
/* 157:175 */       return false;
/* 158:    */     }
/* 159:177 */     Matcher<StructuredStatement> m = new MatchSequence(new Matcher[] { new BeginBlock(null), new StructuredTry(null, null, null), new BeginBlock(null), new StructuredReturn(wcm1.getStaticFunction("forName", CLASS, null, "forName", new Expression[] { new LValueExpression(arg) }), CLASS), new EndBlock(null), new StructuredCatch(null, null, null, null), new BeginBlock(null), new StructuredThrow(wcm1.getMemberFunction("initCause", "initCause", wcm1.getConstructorSimpleWildcard("nocd", NOCLASSDEFFOUND_ERROR), new Expression[] { wcm1.getExpressionWildCard("throwable") })), new EndBlock(null), new EndBlock(null) });
/* 160:    */     
/* 161:    */ 
/* 162:    */ 
/* 163:    */ 
/* 164:    */ 
/* 165:    */ 
/* 166:    */ 
/* 167:    */ 
/* 168:    */ 
/* 169:    */ 
/* 170:    */ 
/* 171:    */ 
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:196 */     mi.advance();
/* 179:197 */     return m.match(mi, null);
/* 180:    */   }
/* 181:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.J14ClassObjectRewriter
 * JD-Core Version:    0.7.0.1
 */