/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CastExpression;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.AbstractExpressionRewriter;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.types.TypeConstants;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/* 13:   */ 
/* 14:   */ public class BadCastChainRewriter
/* 15:   */   extends AbstractExpressionRewriter
/* 16:   */ {
/* 17:   */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 18:   */   {
/* 19:16 */     expression = super.rewriteExpression(expression, ssaIdentifiers, statementContainer, flags);
/* 20:17 */     if ((expression instanceof CastExpression))
/* 21:   */     {
/* 22:18 */       Expression child = ((CastExpression)expression).getChild();
/* 23:19 */       JavaTypeInstance type = expression.getInferredJavaType().getJavaTypeInstance().getDeGenerifiedType();
/* 24:20 */       JavaTypeInstance childType = child.getInferredJavaType().getJavaTypeInstance().getDeGenerifiedType();
/* 25:21 */       if ((type.isComplexType()) && (childType.isComplexType()) && 
/* 26:22 */         (!childType.correctCanCastTo(type, null))) {
/* 27:23 */         expression = new CastExpression(expression.getInferredJavaType(), new CastExpression(new InferredJavaType(TypeConstants.OBJECT, InferredJavaType.Source.UNKNOWN), child, true));
/* 28:   */       }
/* 29:   */     }
/* 30:31 */     return expression;
/* 31:   */   }
/* 32:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.BadCastChainRewriter
 * JD-Core Version:    0.7.0.1
 */