/*    1:     */ package org.benf.cfr.reader.bytecode.analysis.opgraph;
/*    2:     */ 
/*    3:     */ import java.io.PrintStream;
/*    4:     */ import java.util.Collection;
/*    5:     */ import java.util.Collections;
/*    6:     */ import java.util.Comparator;
/*    7:     */ import java.util.Iterator;
/*    8:     */ import java.util.LinkedList;
/*    9:     */ import java.util.List;
/*   10:     */ import java.util.Map;
/*   11:     */ import java.util.Map.Entry;
/*   12:     */ import java.util.Set;
/*   13:     */ import java.util.Stack;
/*   14:     */ import java.util.logging.Logger;
/*   15:     */ import org.benf.cfr.reader.bytecode.BytecodeMeta;
/*   16:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters.TypeHintRecovery;
/*   17:     */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   18:     */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   19:     */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*   20:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractMemberFunctionInvokation;
/*   21:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithOp;
/*   22:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithmeticMonOperation;
/*   23:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithmeticOperation;
/*   24:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArrayIndex;
/*   25:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArrayLength;
/*   26:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.BooleanExpression;
/*   27:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CastExpression;
/*   28:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CompOp;
/*   29:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ComparisonOperation;
/*   30:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*   31:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.DynamicInvokation;
/*   32:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.InstanceOfExpression;
/*   33:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*   34:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*   35:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.MemberFunctionInvokation;
/*   36:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.NewObject;
/*   37:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.NewObjectArray;
/*   38:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.NewPrimitiveArray;
/*   39:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.StackValue;
/*   40:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.StaticFunctionInvokation;
/*   41:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.SuperFunctionInvokation;
/*   42:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.TernaryExpression;
/*   43:     */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*   44:     */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.ArrayVariable;
/*   45:     */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.FieldVariable;
/*   46:     */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StaticVariable;
/*   47:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.AssignmentSimple;
/*   48:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CatchStatement;
/*   49:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CompoundStatement;
/*   50:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ConstructorStatement;
/*   51:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ExpressionStatement;
/*   52:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement;
/*   53:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.IfStatement;
/*   54:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.JSRCallStatement;
/*   55:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.JSRRetStatement;
/*   56:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.MonitorEnterStatement;
/*   57:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.MonitorExitStatement;
/*   58:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.Nop;
/*   59:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.RawSwitchStatement;
/*   60:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ReturnNothingStatement;
/*   61:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ReturnValueStatement;
/*   62:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ThrowStatement;
/*   63:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.TryStatement;
/*   64:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*   65:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifierFactory;
/*   66:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockType;
/*   67:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*   68:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdent;
/*   69:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifierFactory;
/*   70:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*   71:     */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDelta;
/*   72:     */ import org.benf.cfr.reader.bytecode.analysis.stack.StackEntry;
/*   73:     */ import org.benf.cfr.reader.bytecode.analysis.stack.StackEntryHolder;
/*   74:     */ import org.benf.cfr.reader.bytecode.analysis.stack.StackSim;
/*   75:     */ import org.benf.cfr.reader.bytecode.analysis.types.BindingSuperContainer;
/*   76:     */ import org.benf.cfr.reader.bytecode.analysis.types.DynamicInvokeType;
/*   77:     */ import org.benf.cfr.reader.bytecode.analysis.types.GenericTypeBinder;
/*   78:     */ import org.benf.cfr.reader.bytecode.analysis.types.JavaArrayTypeInstance;
/*   79:     */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericBaseInstance;
/*   80:     */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*   81:     */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*   82:     */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*   83:     */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/*   84:     */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*   85:     */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*   86:     */ import org.benf.cfr.reader.bytecode.analysis.variables.Ident;
/*   87:     */ import org.benf.cfr.reader.bytecode.analysis.variables.Slot;
/*   88:     */ import org.benf.cfr.reader.bytecode.analysis.variables.VariableFactory;
/*   89:     */ import org.benf.cfr.reader.bytecode.analysis.variables.VariableNamerDefault;
/*   90:     */ import org.benf.cfr.reader.bytecode.opcode.DecodedLookupSwitch;
/*   91:     */ import org.benf.cfr.reader.bytecode.opcode.DecodedTableSwitch;
/*   92:     */ import org.benf.cfr.reader.bytecode.opcode.JVMInstr;
/*   93:     */ import org.benf.cfr.reader.entities.AccessFlagMethod;
/*   94:     */ import org.benf.cfr.reader.entities.ClassFile;
/*   95:     */ import org.benf.cfr.reader.entities.Method;
/*   96:     */ import org.benf.cfr.reader.entities.Method.MethodConstructor;
/*   97:     */ import org.benf.cfr.reader.entities.attributes.AttributeBootstrapMethods;
/*   98:     */ import org.benf.cfr.reader.entities.bootstrap.BootstrapMethodInfo;
/*   99:     */ import org.benf.cfr.reader.entities.bootstrap.MethodHandleBehaviour;
/*  100:     */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  101:     */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/*  102:     */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass;
/*  103:     */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryInvokeDynamic;
/*  104:     */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodRef;
/*  105:     */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryNameAndType;
/*  106:     */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryUTF8;
/*  107:     */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolUtils;
/*  108:     */ import org.benf.cfr.reader.entities.exceptions.ExceptionAggregator;
/*  109:     */ import org.benf.cfr.reader.entities.exceptions.ExceptionGroup;
/*  110:     */ import org.benf.cfr.reader.entities.exceptions.ExceptionGroup.Entry;
/*  111:     */ import org.benf.cfr.reader.state.DCCommonState;
/*  112:     */ import org.benf.cfr.reader.util.BinaryPredicate;
/*  113:     */ import org.benf.cfr.reader.util.CannotLoadClassException;
/*  114:     */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  115:     */ import org.benf.cfr.reader.util.DecompilerComments;
/*  116:     */ import org.benf.cfr.reader.util.Functional;
/*  117:     */ import org.benf.cfr.reader.util.ListFactory;
/*  118:     */ import org.benf.cfr.reader.util.MapFactory;
/*  119:     */ import org.benf.cfr.reader.util.Predicate;
/*  120:     */ import org.benf.cfr.reader.util.SetFactory;
/*  121:     */ import org.benf.cfr.reader.util.SetUtil;
/*  122:     */ import org.benf.cfr.reader.util.StackFactory;
/*  123:     */ import org.benf.cfr.reader.util.bytestream.BaseByteData;
/*  124:     */ import org.benf.cfr.reader.util.functors.BinaryProcedure;
/*  125:     */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  126:     */ import org.benf.cfr.reader.util.getopt.Options;
/*  127:     */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*  128:     */ import org.benf.cfr.reader.util.graph.GraphVisitor;
/*  129:     */ import org.benf.cfr.reader.util.graph.GraphVisitorDFS;
/*  130:     */ import org.benf.cfr.reader.util.graph.GraphVisitorFIFO;
/*  131:     */ import org.benf.cfr.reader.util.lambda.LambdaUtils;
/*  132:     */ import org.benf.cfr.reader.util.output.Dumpable;
/*  133:     */ import org.benf.cfr.reader.util.output.Dumper;
/*  134:     */ import org.benf.cfr.reader.util.output.LoggerFactory;
/*  135:     */ import org.benf.cfr.reader.util.output.ToStringDumper;
/*  136:     */ 
/*  137:     */ public class Op02WithProcessedDataAndRefs
/*  138:     */   implements Dumpable, Graph<Op02WithProcessedDataAndRefs>
/*  139:     */ {
/*  140:  52 */   private static final Logger logger = LoggerFactory.create(Op02WithProcessedDataAndRefs.class);
/*  141:     */   private InstrIndex index;
/*  142:     */   private JVMInstr instr;
/*  143:     */   private final int originalRawOffset;
/*  144:     */   private final byte[] rawData;
/*  145:  60 */   private List<BlockIdentifier> containedInTheseBlocks = ListFactory.newList();
/*  146:  61 */   private List<ExceptionGroup> exceptionGroups = ListFactory.newList();
/*  147:  62 */   private List<ExceptionGroup.Entry> catchExceptionGroups = ListFactory.newList();
/*  148:  64 */   private final List<Op02WithProcessedDataAndRefs> targets = ListFactory.newList();
/*  149:  65 */   private final List<Op02WithProcessedDataAndRefs> sources = ListFactory.newList();
/*  150:     */   private final ConstantPool cp;
/*  151:     */   private final ConstantPoolEntry[] cpEntries;
/*  152:  68 */   private long stackDepthBeforeExecution = -1L;
/*  153:     */   private long stackDepthAfterExecution;
/*  154:  70 */   private final List<StackEntryHolder> stackConsumed = ListFactory.newList();
/*  155:  71 */   private final List<StackEntryHolder> stackProduced = ListFactory.newList();
/*  156:  72 */   private StackSim unconsumedJoinedStack = null;
/*  157:  73 */   private boolean hasCatchParent = false;
/*  158:     */   private SSAIdentifiers<Slot> ssaIdentifiers;
/*  159:  76 */   private Map<Integer, Ident> localVariablesBySlot = MapFactory.newLinkedMap();
/*  160:     */   
/*  161:     */   private Op02WithProcessedDataAndRefs(Op02WithProcessedDataAndRefs other)
/*  162:     */   {
/*  163:  79 */     this.instr = other.instr;
/*  164:  80 */     this.rawData = other.rawData;
/*  165:  81 */     this.index = null;
/*  166:  82 */     this.cp = other.cp;
/*  167:  83 */     this.cpEntries = other.cpEntries;
/*  168:  84 */     this.originalRawOffset = other.originalRawOffset;
/*  169:     */   }
/*  170:     */   
/*  171:     */   public Op02WithProcessedDataAndRefs(JVMInstr instr, byte[] rawData, int index, ConstantPool cp, ConstantPoolEntry[] cpEntries, int originalRawOffset)
/*  172:     */   {
/*  173:  88 */     this(instr, rawData, new InstrIndex(index), cp, cpEntries, originalRawOffset);
/*  174:     */   }
/*  175:     */   
/*  176:     */   public Op02WithProcessedDataAndRefs(JVMInstr instr, byte[] rawData, InstrIndex index, ConstantPool cp, ConstantPoolEntry[] cpEntries, int originalRawOffset)
/*  177:     */   {
/*  178:  92 */     this.instr = instr;
/*  179:  93 */     this.rawData = rawData;
/*  180:  94 */     this.index = index;
/*  181:  95 */     this.cp = cp;
/*  182:  96 */     this.cpEntries = cpEntries;
/*  183:  97 */     this.originalRawOffset = originalRawOffset;
/*  184:     */   }
/*  185:     */   
/*  186:     */   public void resetStackInfo()
/*  187:     */   {
/*  188: 101 */     this.stackDepthBeforeExecution = -1L;
/*  189: 102 */     this.stackDepthAfterExecution = -1L;
/*  190: 103 */     this.stackConsumed.clear();
/*  191: 104 */     this.stackProduced.clear();
/*  192: 105 */     this.unconsumedJoinedStack = null;
/*  193:     */   }
/*  194:     */   
/*  195:     */   public InstrIndex getIndex()
/*  196:     */   {
/*  197: 109 */     return this.index;
/*  198:     */   }
/*  199:     */   
/*  200:     */   public void setIndex(InstrIndex index)
/*  201:     */   {
/*  202: 113 */     this.index = index;
/*  203:     */   }
/*  204:     */   
/*  205:     */   public void addTarget(Op02WithProcessedDataAndRefs node)
/*  206:     */   {
/*  207: 117 */     this.targets.add(node);
/*  208:     */   }
/*  209:     */   
/*  210:     */   public void removeTarget(Op02WithProcessedDataAndRefs node)
/*  211:     */   {
/*  212: 121 */     if (!this.targets.remove(node)) {
/*  213: 122 */       throw new ConfusedCFRException("Invalid target, tried to remove " + node + "\nfrom " + this + "\nbut was not a target.");
/*  214:     */     }
/*  215:     */   }
/*  216:     */   
/*  217:     */   public void addSource(Op02WithProcessedDataAndRefs node)
/*  218:     */   {
/*  219: 127 */     this.sources.add(node);
/*  220:     */   }
/*  221:     */   
/*  222:     */   public JVMInstr getInstr()
/*  223:     */   {
/*  224: 131 */     return this.instr;
/*  225:     */   }
/*  226:     */   
/*  227:     */   public void replaceTarget(Op02WithProcessedDataAndRefs oldTarget, Op02WithProcessedDataAndRefs newTarget)
/*  228:     */   {
/*  229: 135 */     int index = this.targets.indexOf(oldTarget);
/*  230: 136 */     if (index == -1) {
/*  231: 136 */       throw new ConfusedCFRException("Invalid target");
/*  232:     */     }
/*  233: 137 */     this.targets.set(index, newTarget);
/*  234:     */   }
/*  235:     */   
/*  236:     */   public void replaceSource(Op02WithProcessedDataAndRefs oldSource, Op02WithProcessedDataAndRefs newSource)
/*  237:     */   {
/*  238: 141 */     int index = this.sources.indexOf(oldSource);
/*  239: 142 */     if (index == -1) {
/*  240: 142 */       throw new ConfusedCFRException("Invalid source");
/*  241:     */     }
/*  242: 143 */     this.sources.set(index, newSource);
/*  243:     */   }
/*  244:     */   
/*  245:     */   public void removeSource(Op02WithProcessedDataAndRefs oldSource)
/*  246:     */   {
/*  247: 147 */     if (!this.sources.remove(oldSource)) {
/*  248: 148 */       throw new ConfusedCFRException("Invalid source");
/*  249:     */     }
/*  250:     */   }
/*  251:     */   
/*  252:     */   public void clearSources()
/*  253:     */   {
/*  254: 153 */     this.sources.clear();
/*  255:     */   }
/*  256:     */   
/*  257:     */   private int getInstrArgByte(int index)
/*  258:     */   {
/*  259: 166 */     return this.rawData[index];
/*  260:     */   }
/*  261:     */   
/*  262:     */   private int getInstrArgU1(int index)
/*  263:     */   {
/*  264: 171 */     int res = this.rawData[index];
/*  265: 172 */     if (res < 0) {
/*  266: 173 */       res = 256 + res;
/*  267:     */     }
/*  268: 175 */     return res;
/*  269:     */   }
/*  270:     */   
/*  271:     */   private int getInstrArgShort(int index)
/*  272:     */   {
/*  273: 179 */     BaseByteData tmp = new BaseByteData(this.rawData);
/*  274: 180 */     return tmp.getS2At(index);
/*  275:     */   }
/*  276:     */   
/*  277:     */   public List<Op02WithProcessedDataAndRefs> getTargets()
/*  278:     */   {
/*  279: 185 */     return this.targets;
/*  280:     */   }
/*  281:     */   
/*  282:     */   public List<Op02WithProcessedDataAndRefs> getSources()
/*  283:     */   {
/*  284: 190 */     return this.sources;
/*  285:     */   }
/*  286:     */   
/*  287:     */   public ConstantPoolEntry[] getCpEntries()
/*  288:     */   {
/*  289: 194 */     return this.cpEntries;
/*  290:     */   }
/*  291:     */   
/*  292:     */   public void populateStackInfo(StackSim stackSim, Method method, LinkedList<Pair<StackSim, Op02WithProcessedDataAndRefs>> next)
/*  293:     */   {
/*  294: 198 */     StackDelta stackDelta = this.instr.getStackDelta(this.rawData, this.cpEntries, stackSim, method);
/*  295: 199 */     if (this.stackDepthBeforeExecution != -1L)
/*  296:     */     {
/*  297: 201 */       if (this.instr == JVMInstr.FAKE_CATCH) {
/*  298: 202 */         return;
/*  299:     */       }
/*  300: 205 */       if (stackSim.getDepth() != this.stackDepthBeforeExecution) {
/*  301: 206 */         throw new ConfusedCFRException("Invalid stack depths @ " + this + " : trying to set " + stackSim.getDepth() + " previously set to " + this.stackDepthBeforeExecution);
/*  302:     */       }
/*  303: 210 */       List<StackEntryHolder> alsoConsumed = ListFactory.newList();
/*  304: 211 */       List<StackEntryHolder> alsoProduced = ListFactory.newList();
/*  305: 212 */       StackSim newStackSim = stackSim.getChange(stackDelta, alsoConsumed, alsoProduced, this);
/*  306: 213 */       if (alsoConsumed.size() != this.stackConsumed.size()) {
/*  307: 214 */         throw new ConfusedCFRException("Unexpected stack sizes on merge");
/*  308:     */       }
/*  309: 216 */       for (int i = 0; i < this.stackConsumed.size(); i++) {
/*  310: 217 */         ((StackEntryHolder)this.stackConsumed.get(i)).mergeWith((StackEntryHolder)alsoConsumed.get(i));
/*  311:     */       }
/*  312: 223 */       if (this.unconsumedJoinedStack != null)
/*  313:     */       {
/*  314: 225 */         long depth = this.unconsumedJoinedStack.getDepth() - alsoProduced.size();
/*  315: 226 */         List<StackEntryHolder> unconsumedEntriesOld = this.unconsumedJoinedStack.getHolders(alsoProduced.size(), depth);
/*  316: 227 */         List<StackEntryHolder> unconsumedEntriesNew = newStackSim.getHolders(alsoProduced.size(), depth);
/*  317: 228 */         for (int i = 0; i < unconsumedEntriesOld.size(); i++) {
/*  318: 229 */           ((StackEntryHolder)unconsumedEntriesOld.get(i)).mergeWith((StackEntryHolder)unconsumedEntriesNew.get(i));
/*  319:     */         }
/*  320:     */       }
/*  321:     */     }
/*  322:     */     else
/*  323:     */     {
/*  324: 235 */       if (this.instr == JVMInstr.FAKE_CATCH) {
/*  325: 236 */         this.stackDepthBeforeExecution = 0L;
/*  326:     */       } else {
/*  327: 238 */         this.stackDepthBeforeExecution = stackSim.getDepth();
/*  328:     */       }
/*  329: 240 */       this.stackDepthAfterExecution = (this.stackDepthBeforeExecution + stackDelta.getChange());
/*  330:     */       
/*  331: 242 */       StackSim newStackSim = stackSim.getChange(stackDelta, this.stackConsumed, this.stackProduced, this);
/*  332: 244 */       if ((this.sources.size() > 1) && (newStackSim.getDepth() > this.stackProduced.size())) {
/*  333: 252 */         this.unconsumedJoinedStack = newStackSim;
/*  334:     */       }
/*  335: 258 */       for (int i = this.targets.size() - 1; i >= 0; i--) {
/*  336: 259 */         next.addFirst(Pair.make(newStackSim, this.targets.get(i)));
/*  337:     */       }
/*  338:     */     }
/*  339:     */   }
/*  340:     */   
/*  341:     */   public ExceptionGroup getSingleExceptionGroup()
/*  342:     */   {
/*  343: 265 */     if (this.exceptionGroups.size() != 1) {
/*  344: 266 */       throw new ConfusedCFRException("Only expecting statement to be tagged with 1 exceptionGroup");
/*  345:     */     }
/*  346: 268 */     return (ExceptionGroup)this.exceptionGroups.iterator().next();
/*  347:     */   }
/*  348:     */   
/*  349:     */   public Dumper dump(Dumper d)
/*  350:     */   {
/*  351: 273 */     for (BlockIdentifier blockIdentifier : this.containedInTheseBlocks) {
/*  352: 274 */       d.print(" " + blockIdentifier);
/*  353:     */     }
/*  354: 276 */     d.print(" " + this.index + " (" + this.originalRawOffset + ") : " + this.instr + "\t Stack:" + this.stackDepthBeforeExecution + "\t");
/*  355: 277 */     d.print("Consumes:[");
/*  356: 278 */     for (StackEntryHolder stackEntryHolder : this.stackConsumed) {
/*  357: 279 */       d.print("" + stackEntryHolder + " ");
/*  358:     */     }
/*  359: 281 */     d.print("] Produces:[");
/*  360: 282 */     for (StackEntryHolder stackEntryHolder : this.stackProduced) {
/*  361: 283 */       d.print("" + stackEntryHolder + " ");
/*  362:     */     }
/*  363: 285 */     d.print("] sources ");
/*  364: 286 */     for (Op02WithProcessedDataAndRefs source : this.sources) {
/*  365: 287 */       d.print(" " + source.index);
/*  366:     */     }
/*  367: 289 */     d.print(" targets ");
/*  368: 290 */     for (Op02WithProcessedDataAndRefs target : this.targets) {
/*  369: 291 */       d.print(" " + target.index);
/*  370:     */     }
/*  371: 293 */     d.print("\n");
/*  372: 294 */     return d;
/*  373:     */   }
/*  374:     */   
/*  375:     */   private static List<Boolean> getNullsByType(List<Expression> expressions)
/*  376:     */   {
/*  377: 298 */     List<Boolean> res = ListFactory.newList(expressions.size());
/*  378: 299 */     for (Expression e : expressions) {
/*  379: 300 */       res.add(Boolean.valueOf(e.getInferredJavaType().getJavaTypeInstance() == RawJavaType.NULL));
/*  380:     */     }
/*  381: 302 */     return res;
/*  382:     */   }
/*  383:     */   
/*  384:     */   private Statement buildInvoke(Method thisCallerMethod)
/*  385:     */   {
/*  386: 306 */     ConstantPoolEntryMethodRef function = (ConstantPoolEntryMethodRef)this.cpEntries[0];
/*  387: 307 */     StackValue object = getStackRValue(this.stackConsumed.size() - 1);
/*  388:     */     
/*  389:     */ 
/*  390:     */ 
/*  391: 311 */     boolean special = false;
/*  392: 312 */     boolean isSuper = false;
/*  393: 313 */     if (this.instr == JVMInstr.INVOKESPECIAL)
/*  394:     */     {
/*  395: 315 */       special = true;
/*  396: 316 */       if (!thisCallerMethod.testAccessFlag(AccessFlagMethod.ACC_STATIC))
/*  397:     */       {
/*  398: 317 */         JavaTypeInstance objType = object.getInferredJavaType().getJavaTypeInstance();
/*  399: 318 */         JavaTypeInstance callType = function.getClassEntry().getTypeInstance();
/*  400: 319 */         ConstantPoolEntryNameAndType nameAndType = function.getNameAndTypeEntry();
/*  401: 320 */         String funcName = nameAndType.getName().getValue();
/*  402: 321 */         boolean typesMatch = callType.equals(objType);
/*  403: 322 */         if (funcName.equals("<init>"))
/*  404:     */         {
/*  405: 323 */           if ((!typesMatch) && (!objType.getRawName().equals("java.lang.Object"))) {
/*  406: 324 */             isSuper = true;
/*  407:     */           }
/*  408:     */         }
/*  409: 328 */         else if (!typesMatch) {
/*  410: 328 */           isSuper = true;
/*  411:     */         }
/*  412:     */       }
/*  413:     */     }
/*  414: 332 */     MethodPrototype methodPrototype = function.getMethodPrototype();
/*  415: 333 */     List<Expression> args = getNStackRValuesAsExpressions(this.stackConsumed.size() - 1);
/*  416:     */     
/*  417:     */ 
/*  418:     */ 
/*  419: 337 */     List<Boolean> nulls = getNullsByType(args);
/*  420:     */     
/*  421:     */ 
/*  422:     */ 
/*  423: 341 */     methodPrototype.tightenArgs(object, args);
/*  424:     */     
/*  425: 343 */     AbstractMemberFunctionInvokation funcCall = isSuper ? new SuperFunctionInvokation(this.cp, function, object, args, nulls) : new MemberFunctionInvokation(this.cp, function, object, special, args, nulls);
/*  426: 357 */     if (object.getInferredJavaType().getJavaTypeInstance() == RawJavaType.NULL)
/*  427:     */     {
/*  428: 358 */       JavaTypeInstance type = methodPrototype.getClassType();
/*  429: 359 */       if (type != null) {
/*  430: 360 */         object.getInferredJavaType().chain(new InferredJavaType(type, InferredJavaType.Source.FUNCTION));
/*  431:     */       }
/*  432:     */     }
/*  433: 380 */     if ((!isSuper) && (function.isInitMethod())) {
/*  434: 381 */       return new ConstructorStatement((MemberFunctionInvokation)funcCall);
/*  435:     */     }
/*  436: 383 */     if (this.stackProduced.size() == 0) {
/*  437: 384 */       return new ExpressionStatement(funcCall);
/*  438:     */     }
/*  439: 386 */     return new AssignmentSimple(getStackLValue(0), funcCall);
/*  440:     */   }
/*  441:     */   
/*  442:     */   private Statement buildInvokeDynamic(Method method, DCCommonState dcCommonState)
/*  443:     */   {
/*  444: 393 */     ConstantPoolEntryInvokeDynamic invokeDynamic = (ConstantPoolEntryInvokeDynamic)this.cpEntries[0];
/*  445:     */     
/*  446: 395 */     ConstantPoolEntryNameAndType nameAndType = invokeDynamic.getNameAndTypeEntry();
/*  447:     */     
/*  448:     */ 
/*  449: 398 */     ConstantPoolEntryUTF8 descriptor = nameAndType.getDescriptor();
/*  450: 399 */     ConstantPoolEntryUTF8 name = nameAndType.getName();
/*  451:     */     
/*  452:     */ 
/*  453: 402 */     MethodPrototype dynamicPrototype = ConstantPoolUtils.parseJavaMethodPrototype(null, null, "", false, Method.MethodConstructor.NOT, descriptor, this.cp, false, false, new VariableNamerDefault());
/*  454:     */     
/*  455: 404 */     int idx = invokeDynamic.getBootstrapMethodAttrIndex();
/*  456:     */     
/*  457: 406 */     BootstrapMethodInfo bootstrapMethodInfo = method.getClassFile().getBootstrapMethods().getBootStrapMethodInfo(idx);
/*  458: 407 */     ConstantPoolEntryMethodRef methodRef = bootstrapMethodInfo.getConstantPoolEntryMethodRef();
/*  459: 408 */     MethodPrototype prototype = methodRef.getMethodPrototype();
/*  460: 409 */     MethodHandleBehaviour bootstrapBehaviour = bootstrapMethodInfo.getMethodHandleBehaviour();
/*  461: 410 */     String methodName = methodRef.getName();
/*  462:     */     
/*  463: 412 */     DynamicInvokeType dynamicInvokeType = DynamicInvokeType.lookup(methodName);
/*  464:     */     List<Expression> callargs;
/*  465: 415 */     switch (18.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$types$DynamicInvokeType[dynamicInvokeType.ordinal()])
/*  466:     */     {
/*  467:     */     case 1: 
/*  468:     */     case 2: 
/*  469: 418 */       callargs = buildInvokeBootstrapArgs(prototype, dynamicPrototype, bootstrapBehaviour, bootstrapMethodInfo, methodRef);
/*  470: 419 */       List<Expression> dynamicArgs = getNStackRValuesAsExpressions(this.stackConsumed.size());
/*  471: 420 */       callargs.addAll(dynamicArgs);
/*  472: 421 */       Expression funcCall = new StaticFunctionInvokation(methodRef, callargs);
/*  473: 422 */       if (this.stackProduced.size() == 0) {
/*  474: 423 */         return new ExpressionStatement(funcCall);
/*  475:     */       }
/*  476: 425 */       return new AssignmentSimple(getStackLValue(0), funcCall);
/*  477:     */     case 3: 
/*  478:     */     case 4: 
/*  479: 430 */       callargs = buildInvokeDynamicMetaFactoryArgs(prototype, dynamicPrototype, bootstrapBehaviour, bootstrapMethodInfo, methodRef);
/*  480: 431 */       break;
/*  481:     */     case 5: 
/*  482:     */     case 6: 
/*  483: 434 */       callargs = buildInvokeDynamicAltMetaFactoryArgs(prototype, dynamicPrototype, bootstrapBehaviour, bootstrapMethodInfo, methodRef);
/*  484: 435 */       break;
/*  485:     */     default: 
/*  486: 437 */       throw new IllegalStateException();
/*  487:     */     }
/*  488: 441 */     Expression strippedType = (Expression)callargs.get(3);
/*  489: 442 */     Expression instantiatedType = (Expression)callargs.get(5);
/*  490:     */     
/*  491:     */ 
/*  492:     */ 
/*  493:     */ 
/*  494: 447 */     JavaTypeInstance callSiteReturnType = dynamicPrototype.getReturnType();
/*  495: 448 */     callSiteReturnType = determineDynamicGeneric(callSiteReturnType, dynamicPrototype, strippedType, instantiatedType, dcCommonState);
/*  496:     */     
/*  497: 450 */     List<Expression> dynamicArgs = getNStackRValuesAsExpressions(this.stackConsumed.size());
/*  498: 451 */     dynamicPrototype.tightenArgs(null, dynamicArgs);
/*  499:     */     
/*  500: 453 */     Expression funcCall = null;
/*  501: 454 */     switch (bootstrapBehaviour)
/*  502:     */     {
/*  503:     */     case INVOKE_STATIC: 
/*  504: 456 */       funcCall = new StaticFunctionInvokation(methodRef, callargs);
/*  505: 457 */       break;
/*  506:     */     case NEW_INVOKE_SPECIAL: 
/*  507:     */     default: 
/*  508: 460 */       throw new UnsupportedOperationException("Only static invoke dynamic calls supported currently. This is " + bootstrapBehaviour);
/*  509:     */     }
/*  510: 463 */     funcCall = new DynamicInvokation(new InferredJavaType(callSiteReturnType, InferredJavaType.Source.OPERATION), funcCall, dynamicArgs);
/*  511: 464 */     if (this.stackProduced.size() == 0) {
/*  512: 465 */       return new ExpressionStatement(funcCall);
/*  513:     */     }
/*  514: 467 */     return new AssignmentSimple(getStackLValue(0), funcCall);
/*  515:     */   }
/*  516:     */   
/*  517:     */   private JavaTypeInstance determineDynamicGeneric(JavaTypeInstance callsiteReturn, MethodPrototype proto, Expression stripped, Expression instantiated, DCCommonState dcCommonState)
/*  518:     */   {
/*  519: 474 */     ClassFile classFile = null;
/*  520:     */     try
/*  521:     */     {
/*  522: 476 */       classFile = dcCommonState.getClassFile(proto.getReturnType());
/*  523:     */     }
/*  524:     */     catch (CannotLoadClassException e) {}
/*  525: 479 */     if (classFile == null) {
/*  526: 479 */       return callsiteReturn;
/*  527:     */     }
/*  528: 482 */     List<Method> methods = Functional.filter(classFile.getMethods(), new Predicate()
/*  529:     */     {
/*  530:     */       public boolean test(Method in)
/*  531:     */       {
/*  532: 485 */         return !in.hasCodeAttribute();
/*  533:     */       }
/*  534:     */     });
/*  535: 488 */     if (methods.size() != 1) {
/*  536: 488 */       return callsiteReturn;
/*  537:     */     }
/*  538: 489 */     Method method = (Method)methods.get(0);
/*  539: 490 */     MethodPrototype genericProto = method.getMethodPrototype();
/*  540:     */     
/*  541: 492 */     MethodPrototype boundProto = LambdaUtils.getLiteralProto(instantiated);
/*  542: 493 */     GenericTypeBinder gtb = genericProto.getTypeBinderForTypes(boundProto.getArgs());
/*  543:     */     
/*  544: 495 */     JavaTypeInstance unboundReturn = genericProto.getReturnType();
/*  545: 496 */     JavaTypeInstance boundReturn = boundProto.getReturnType();
/*  546: 497 */     if ((unboundReturn instanceof JavaGenericBaseInstance))
/*  547:     */     {
/*  548: 498 */       GenericTypeBinder gtb2 = GenericTypeBinder.extractBindings((JavaGenericBaseInstance)unboundReturn, boundReturn);
/*  549: 499 */       gtb = gtb.mergeWith(gtb2, true);
/*  550:     */     }
/*  551: 502 */     JavaTypeInstance classType = classFile.getClassType();
/*  552: 503 */     BindingSuperContainer b = classFile.getBindingSupers();
/*  553: 504 */     classType = b.getBoundSuperForBase(classType);
/*  554: 505 */     if (classType == null) {
/*  555: 505 */       return callsiteReturn;
/*  556:     */     }
/*  557: 507 */     if (!callsiteReturn.getDeGenerifiedType().equals(classType.getDeGenerifiedType())) {
/*  558: 509 */       return callsiteReturn;
/*  559:     */     }
/*  560: 512 */     JavaTypeInstance alternateCallSite = gtb.getBindingFor(classType);
/*  561: 513 */     return alternateCallSite;
/*  562:     */   }
/*  563:     */   
/*  564:     */   private static TypedLiteral getBootstrapArg(ConstantPoolEntry[] bootstrapArguments, int x, ConstantPool cp)
/*  565:     */   {
/*  566: 517 */     ConstantPoolEntry entry = bootstrapArguments[x];
/*  567: 518 */     TypedLiteral typedLiteral = TypedLiteral.getConstantPoolEntry(cp, entry);
/*  568: 519 */     return typedLiteral;
/*  569:     */   }
/*  570:     */   
/*  571:     */   private List<Expression> buildInvokeDynamicAltMetaFactoryArgs(MethodPrototype prototype, MethodPrototype dynamicPrototype, MethodHandleBehaviour bootstrapBehaviour, BootstrapMethodInfo bootstrapMethodInfo, ConstantPoolEntryMethodRef methodRef)
/*  572:     */   {
/*  573: 544 */     List<JavaTypeInstance> argTypes = prototype.getArgs();
/*  574: 545 */     ConstantPoolEntry[] bootstrapArguments = bootstrapMethodInfo.getBootstrapArguments();
/*  575: 546 */     if (bootstrapArguments.length < 4) {
/*  576: 547 */       throw new IllegalStateException("Dynamic invoke arg count mismatch ");
/*  577:     */     }
/*  578: 550 */     List<Expression> callargs = ListFactory.newList();
/*  579: 551 */     Expression nullExp = new Literal(TypedLiteral.getNull());
/*  580: 552 */     callargs.add(nullExp);
/*  581: 553 */     callargs.add(nullExp);
/*  582: 554 */     callargs.add(nullExp);
/*  583:     */     
/*  584:     */ 
/*  585:     */ 
/*  586:     */ 
/*  587: 559 */     TypedLiteral tlMethodType = getBootstrapArg(bootstrapArguments, 0, this.cp);
/*  588: 560 */     TypedLiteral tlImplMethod = getBootstrapArg(bootstrapArguments, 1, this.cp);
/*  589: 561 */     TypedLiteral tlInstantiatedMethodType = getBootstrapArg(bootstrapArguments, 2, this.cp);
/*  590: 562 */     TypedLiteral flags = getBootstrapArg(bootstrapArguments, 3, this.cp);
/*  591:     */     
/*  592: 564 */     callargs.add(new Literal(tlMethodType));
/*  593: 565 */     callargs.add(new Literal(tlImplMethod));
/*  594: 566 */     callargs.add(new Literal(tlInstantiatedMethodType));
/*  595:     */     
/*  596:     */ 
/*  597:     */ 
/*  598:     */ 
/*  599:     */ 
/*  600:     */ 
/*  601:     */ 
/*  602:     */ 
/*  603: 575 */     return callargs;
/*  604:     */   }
/*  605:     */   
/*  606:     */   private List<Expression> buildInvokeBootstrapArgs(MethodPrototype prototype, MethodPrototype dynamicPrototype, MethodHandleBehaviour bootstrapBehaviour, BootstrapMethodInfo bootstrapMethodInfo, ConstantPoolEntryMethodRef methodRef)
/*  607:     */   {
/*  608: 579 */     int ARG_OFFSET = 3;
/*  609: 580 */     List<JavaTypeInstance> argTypes = prototype.getArgs();
/*  610: 581 */     ConstantPoolEntry[] bootstrapArguments = bootstrapMethodInfo.getBootstrapArguments();
/*  611: 582 */     if (bootstrapArguments.length + 3 != argTypes.size()) {
/*  612: 583 */       throw new IllegalStateException("Dynamic invoke arg count mismatch " + bootstrapArguments.length + "(+3) vs " + argTypes.size());
/*  613:     */     }
/*  614: 586 */     List<Expression> callargs = ListFactory.newList();
/*  615: 588 */     for (int x = 0; x < bootstrapArguments.length; x++)
/*  616:     */     {
/*  617: 589 */       JavaTypeInstance expected = (JavaTypeInstance)argTypes.get(3 + x);
/*  618: 590 */       TypedLiteral typedLiteral = getBootstrapArg(bootstrapArguments, x, this.cp);
/*  619: 591 */       if (!expected.equals(typedLiteral.getInferredJavaType().getJavaTypeInstance())) {
/*  620: 592 */         throw new IllegalStateException("Dynamic invoke Expected " + expected + ", got " + typedLiteral);
/*  621:     */       }
/*  622: 594 */       callargs.add(new Literal(typedLiteral));
/*  623:     */     }
/*  624: 597 */     return callargs;
/*  625:     */   }
/*  626:     */   
/*  627:     */   private List<Expression> buildInvokeDynamicMetaFactoryArgs(MethodPrototype prototype, MethodPrototype dynamicPrototype, MethodHandleBehaviour bootstrapBehaviour, BootstrapMethodInfo bootstrapMethodInfo, ConstantPoolEntryMethodRef methodRef)
/*  628:     */   {
/*  629: 602 */     int ARG_OFFSET = 3;
/*  630:     */     
/*  631:     */ 
/*  632:     */ 
/*  633:     */ 
/*  634:     */ 
/*  635:     */ 
/*  636:     */ 
/*  637:     */ 
/*  638:     */ 
/*  639:     */ 
/*  640: 613 */     List<JavaTypeInstance> argTypes = prototype.getArgs();
/*  641: 614 */     ConstantPoolEntry[] bootstrapArguments = bootstrapMethodInfo.getBootstrapArguments();
/*  642: 615 */     if (bootstrapArguments.length + 3 != argTypes.size()) {
/*  643: 616 */       throw new IllegalStateException("Dynamic invoke arg count mismatch " + bootstrapArguments.length + "(+3) vs " + argTypes.size());
/*  644:     */     }
/*  645: 619 */     List<Expression> callargs = ListFactory.newList();
/*  646: 620 */     Expression nullExp = new Literal(TypedLiteral.getNull());
/*  647: 621 */     callargs.add(nullExp);
/*  648: 622 */     callargs.add(nullExp);
/*  649: 623 */     callargs.add(nullExp);
/*  650: 625 */     for (int x = 0; x < bootstrapArguments.length; x++)
/*  651:     */     {
/*  652: 626 */       JavaTypeInstance expected = (JavaTypeInstance)argTypes.get(3 + x);
/*  653: 627 */       TypedLiteral typedLiteral = getBootstrapArg(bootstrapArguments, x, this.cp);
/*  654: 628 */       if (!expected.equals(typedLiteral.getInferredJavaType().getJavaTypeInstance())) {
/*  655: 629 */         throw new IllegalStateException("Dynamic invoke Expected " + expected + ", got " + typedLiteral);
/*  656:     */       }
/*  657: 631 */       callargs.add(new Literal(typedLiteral));
/*  658:     */     }
/*  659: 634 */     return callargs;
/*  660:     */   }
/*  661:     */   
/*  662:     */   public Pair<JavaTypeInstance, Integer> getRetrieveType()
/*  663:     */   {
/*  664: 638 */     JavaTypeInstance type = null;
/*  665: 639 */     switch (18.$SwitchMap$org$benf$cfr$reader$bytecode$opcode$JVMInstr[this.instr.ordinal()])
/*  666:     */     {
/*  667:     */     case 1: 
/*  668:     */     case 2: 
/*  669:     */     case 3: 
/*  670:     */     case 4: 
/*  671:     */     case 5: 
/*  672:     */     case 6: 
/*  673: 646 */       type = RawJavaType.REF;
/*  674: 647 */       break;
/*  675:     */     case 7: 
/*  676:     */     case 8: 
/*  677:     */     case 9: 
/*  678:     */     case 10: 
/*  679:     */     case 11: 
/*  680:     */     case 12: 
/*  681:     */     case 13: 
/*  682:     */     case 14: 
/*  683: 656 */       type = RawJavaType.INT;
/*  684: 657 */       break;
/*  685:     */     case 15: 
/*  686:     */     case 16: 
/*  687:     */     case 17: 
/*  688:     */     case 18: 
/*  689:     */     case 19: 
/*  690:     */     case 20: 
/*  691: 664 */       type = RawJavaType.LONG;
/*  692: 665 */       break;
/*  693:     */     case 21: 
/*  694:     */     case 22: 
/*  695:     */     case 23: 
/*  696:     */     case 24: 
/*  697:     */     case 25: 
/*  698:     */     case 26: 
/*  699: 672 */       type = RawJavaType.DOUBLE;
/*  700: 673 */       break;
/*  701:     */     case 27: 
/*  702:     */     case 28: 
/*  703:     */     case 29: 
/*  704:     */     case 30: 
/*  705:     */     case 31: 
/*  706:     */     case 32: 
/*  707: 680 */       type = RawJavaType.FLOAT;
/*  708: 681 */       break;
/*  709:     */     default: 
/*  710: 683 */       return null;
/*  711:     */     }
/*  712: 685 */     int idx = 0;
/*  713: 686 */     switch (18.$SwitchMap$org$benf$cfr$reader$bytecode$opcode$JVMInstr[this.instr.ordinal()])
/*  714:     */     {
/*  715:     */     case 1: 
/*  716:     */     case 7: 
/*  717:     */     case 13: 
/*  718:     */     case 15: 
/*  719:     */     case 21: 
/*  720:     */     case 27: 
/*  721: 693 */       idx = getInstrArgU1(0);
/*  722: 694 */       break;
/*  723:     */     case 2: 
/*  724:     */     case 8: 
/*  725:     */     case 16: 
/*  726:     */     case 22: 
/*  727:     */     case 28: 
/*  728: 700 */       idx = 0;
/*  729: 701 */       break;
/*  730:     */     case 3: 
/*  731:     */     case 9: 
/*  732:     */     case 17: 
/*  733:     */     case 23: 
/*  734:     */     case 29: 
/*  735: 707 */       idx = 1;
/*  736: 708 */       break;
/*  737:     */     case 4: 
/*  738:     */     case 10: 
/*  739:     */     case 18: 
/*  740:     */     case 24: 
/*  741:     */     case 30: 
/*  742: 714 */       idx = 2;
/*  743: 715 */       break;
/*  744:     */     case 5: 
/*  745:     */     case 11: 
/*  746:     */     case 19: 
/*  747:     */     case 25: 
/*  748:     */     case 31: 
/*  749: 721 */       idx = 3;
/*  750: 722 */       break;
/*  751:     */     case 6: 
/*  752:     */     case 12: 
/*  753:     */     case 20: 
/*  754:     */     case 26: 
/*  755:     */     case 32: 
/*  756: 728 */       idx = getInstrArgShort(1);
/*  757: 729 */       break;
/*  758:     */     case 14: 
/*  759:     */     default: 
/*  760: 731 */       return null;
/*  761:     */     }
/*  762: 733 */     return Pair.make(type, Integer.valueOf(idx));
/*  763:     */   }
/*  764:     */   
/*  765:     */   public Pair<JavaTypeInstance, Integer> getStorageType()
/*  766:     */   {
/*  767: 737 */     JavaTypeInstance type = null;
/*  768: 738 */     switch (18.$SwitchMap$org$benf$cfr$reader$bytecode$opcode$JVMInstr[this.instr.ordinal()])
/*  769:     */     {
/*  770:     */     case 33: 
/*  771:     */     case 34: 
/*  772:     */     case 35: 
/*  773:     */     case 36: 
/*  774:     */     case 37: 
/*  775:     */     case 38: 
/*  776: 745 */       type = RawJavaType.REF;
/*  777: 746 */       break;
/*  778:     */     case 13: 
/*  779:     */     case 14: 
/*  780:     */     case 39: 
/*  781:     */     case 40: 
/*  782:     */     case 41: 
/*  783:     */     case 42: 
/*  784:     */     case 43: 
/*  785:     */     case 44: 
/*  786: 755 */       type = RawJavaType.INT;
/*  787: 756 */       break;
/*  788:     */     case 45: 
/*  789:     */     case 46: 
/*  790:     */     case 47: 
/*  791:     */     case 48: 
/*  792:     */     case 49: 
/*  793:     */     case 50: 
/*  794: 763 */       type = RawJavaType.LONG;
/*  795: 764 */       break;
/*  796:     */     case 51: 
/*  797:     */     case 52: 
/*  798:     */     case 53: 
/*  799:     */     case 54: 
/*  800:     */     case 55: 
/*  801:     */     case 56: 
/*  802: 771 */       type = RawJavaType.DOUBLE;
/*  803: 772 */       break;
/*  804:     */     case 57: 
/*  805:     */     case 58: 
/*  806:     */     case 59: 
/*  807:     */     case 60: 
/*  808:     */     case 61: 
/*  809:     */     case 62: 
/*  810: 779 */       type = RawJavaType.FLOAT;
/*  811: 780 */       break;
/*  812:     */     case 15: 
/*  813:     */     case 16: 
/*  814:     */     case 17: 
/*  815:     */     case 18: 
/*  816:     */     case 19: 
/*  817:     */     case 20: 
/*  818:     */     case 21: 
/*  819:     */     case 22: 
/*  820:     */     case 23: 
/*  821:     */     case 24: 
/*  822:     */     case 25: 
/*  823:     */     case 26: 
/*  824:     */     case 27: 
/*  825:     */     case 28: 
/*  826:     */     case 29: 
/*  827:     */     case 30: 
/*  828:     */     case 31: 
/*  829:     */     case 32: 
/*  830:     */     default: 
/*  831: 782 */       return null;
/*  832:     */     }
/*  833: 784 */     int idx = 0;
/*  834: 785 */     switch (18.$SwitchMap$org$benf$cfr$reader$bytecode$opcode$JVMInstr[this.instr.ordinal()])
/*  835:     */     {
/*  836:     */     case 13: 
/*  837:     */     case 33: 
/*  838:     */     case 39: 
/*  839:     */     case 45: 
/*  840:     */     case 51: 
/*  841:     */     case 57: 
/*  842: 792 */       idx = getInstrArgU1(0);
/*  843: 793 */       break;
/*  844:     */     case 34: 
/*  845:     */     case 40: 
/*  846:     */     case 46: 
/*  847:     */     case 52: 
/*  848:     */     case 58: 
/*  849: 799 */       idx = 0;
/*  850: 800 */       break;
/*  851:     */     case 35: 
/*  852:     */     case 41: 
/*  853:     */     case 47: 
/*  854:     */     case 53: 
/*  855:     */     case 59: 
/*  856: 806 */       idx = 1;
/*  857: 807 */       break;
/*  858:     */     case 36: 
/*  859:     */     case 42: 
/*  860:     */     case 48: 
/*  861:     */     case 54: 
/*  862:     */     case 60: 
/*  863: 813 */       idx = 2;
/*  864: 814 */       break;
/*  865:     */     case 37: 
/*  866:     */     case 43: 
/*  867:     */     case 49: 
/*  868:     */     case 55: 
/*  869:     */     case 61: 
/*  870: 820 */       idx = 3;
/*  871: 821 */       break;
/*  872:     */     case 14: 
/*  873:     */     case 38: 
/*  874:     */     case 44: 
/*  875:     */     case 50: 
/*  876:     */     case 56: 
/*  877:     */     case 62: 
/*  878: 828 */       idx = getInstrArgShort(1);
/*  879: 829 */       break;
/*  880:     */     case 15: 
/*  881:     */     case 16: 
/*  882:     */     case 17: 
/*  883:     */     case 18: 
/*  884:     */     case 19: 
/*  885:     */     case 20: 
/*  886:     */     case 21: 
/*  887:     */     case 22: 
/*  888:     */     case 23: 
/*  889:     */     case 24: 
/*  890:     */     case 25: 
/*  891:     */     case 26: 
/*  892:     */     case 27: 
/*  893:     */     case 28: 
/*  894:     */     case 29: 
/*  895:     */     case 30: 
/*  896:     */     case 31: 
/*  897:     */     case 32: 
/*  898:     */     default: 
/*  899: 831 */       return null;
/*  900:     */     }
/*  901: 833 */     return Pair.make(type, Integer.valueOf(idx));
/*  902:     */   }
/*  903:     */   
/*  904:     */   private Statement mkAssign(VariableFactory variableFactory)
/*  905:     */   {
/*  906: 837 */     Pair<JavaTypeInstance, Integer> storageTypeAndIdx = getStorageType();
/*  907: 838 */     int slot = ((Integer)storageTypeAndIdx.getSecond()).intValue();
/*  908: 839 */     Ident ident = (Ident)this.localVariablesBySlot.get(Integer.valueOf(slot));
/*  909:     */     
/*  910: 841 */     AssignmentSimple res = new AssignmentSimple(variableFactory.localVariable(slot, ident, this.originalRawOffset), getStackRValue(0));
/*  911: 842 */     return res;
/*  912:     */   }
/*  913:     */   
/*  914:     */   private Statement mkRetrieve(VariableFactory variableFactory)
/*  915:     */   {
/*  916: 846 */     Pair<JavaTypeInstance, Integer> storageTypeAndIdx = getRetrieveType();
/*  917: 847 */     int slot = ((Integer)storageTypeAndIdx.getSecond()).intValue();
/*  918: 848 */     Ident ident = (Ident)this.localVariablesBySlot.get(Integer.valueOf(slot));
/*  919:     */     
/*  920: 850 */     return new AssignmentSimple(getStackLValue(0), new LValueExpression(variableFactory.localVariable(slot, ident, this.originalRawOffset)));
/*  921:     */   }
/*  922:     */   
/*  923:     */   private static Expression ensureNonBool(Expression e)
/*  924:     */   {
/*  925: 854 */     InferredJavaType inferredJavaType = e.getInferredJavaType();
/*  926: 855 */     if (inferredJavaType.getRawType() == RawJavaType.BOOLEAN) {
/*  927: 856 */       if (inferredJavaType.getSource() == InferredJavaType.Source.LITERAL) {
/*  928: 857 */         e.getInferredJavaType().useInArithOp(new InferredJavaType(RawJavaType.INT, InferredJavaType.Source.LITERAL), RawJavaType.INT, true);
/*  929:     */       } else {
/*  930: 859 */         e = new TernaryExpression(new BooleanExpression(e), Literal.INT_ONE, Literal.INT_ZERO);
/*  931:     */       }
/*  932:     */     }
/*  933: 862 */     return e;
/*  934:     */   }
/*  935:     */   
/*  936:     */   public Statement createStatement(Method method, VariableFactory variableFactory, BlockIdentifierFactory blockIdentifierFactory, DCCommonState dcCommonState, TypeHintRecovery typeHintRecovery)
/*  937:     */   {
/*  938: 866 */     switch (18.$SwitchMap$org$benf$cfr$reader$bytecode$opcode$JVMInstr[this.instr.ordinal()])
/*  939:     */     {
/*  940:     */     case 1: 
/*  941:     */     case 2: 
/*  942:     */     case 3: 
/*  943:     */     case 4: 
/*  944:     */     case 5: 
/*  945:     */     case 6: 
/*  946:     */     case 7: 
/*  947:     */     case 8: 
/*  948:     */     case 9: 
/*  949:     */     case 10: 
/*  950:     */     case 11: 
/*  951:     */     case 12: 
/*  952:     */     case 15: 
/*  953:     */     case 16: 
/*  954:     */     case 17: 
/*  955:     */     case 18: 
/*  956:     */     case 19: 
/*  957:     */     case 20: 
/*  958:     */     case 21: 
/*  959:     */     case 22: 
/*  960:     */     case 23: 
/*  961:     */     case 24: 
/*  962:     */     case 25: 
/*  963:     */     case 26: 
/*  964:     */     case 27: 
/*  965:     */     case 28: 
/*  966:     */     case 29: 
/*  967:     */     case 30: 
/*  968:     */     case 31: 
/*  969:     */     case 32: 
/*  970: 897 */       return mkRetrieve(variableFactory);
/*  971:     */     case 63: 
/*  972: 899 */       return new AssignmentSimple(getStackLValue(0), new Literal(TypedLiteral.getNull()));
/*  973:     */     case 64: 
/*  974: 901 */       return new AssignmentSimple(getStackLValue(0), new Literal(TypedLiteral.getInt(-1)));
/*  975:     */     case 65: 
/*  976: 903 */       return new AssignmentSimple(getStackLValue(0), new Literal(TypedLiteral.getBoolean(0)));
/*  977:     */     case 66: 
/*  978: 905 */       return new AssignmentSimple(getStackLValue(0), new Literal(TypedLiteral.getBoolean(1)));
/*  979:     */     case 67: 
/*  980: 907 */       return new AssignmentSimple(getStackLValue(0), new Literal(TypedLiteral.getInt(2)));
/*  981:     */     case 68: 
/*  982: 909 */       return new AssignmentSimple(getStackLValue(0), new Literal(TypedLiteral.getInt(3)));
/*  983:     */     case 69: 
/*  984: 911 */       return new AssignmentSimple(getStackLValue(0), new Literal(TypedLiteral.getInt(4)));
/*  985:     */     case 70: 
/*  986: 913 */       return new AssignmentSimple(getStackLValue(0), new Literal(TypedLiteral.getInt(5)));
/*  987:     */     case 71: 
/*  988: 915 */       return new AssignmentSimple(getStackLValue(0), new Literal(TypedLiteral.getLong(0L)));
/*  989:     */     case 72: 
/*  990: 917 */       return new AssignmentSimple(getStackLValue(0), new Literal(TypedLiteral.getLong(1L)));
/*  991:     */     case 73: 
/*  992: 919 */       return new AssignmentSimple(getStackLValue(0), new Literal(TypedLiteral.getFloat(0.0F)));
/*  993:     */     case 74: 
/*  994: 921 */       return new AssignmentSimple(getStackLValue(0), new Literal(TypedLiteral.getDouble(0.0D)));
/*  995:     */     case 75: 
/*  996: 923 */       return new AssignmentSimple(getStackLValue(0), new Literal(TypedLiteral.getFloat(1.0F)));
/*  997:     */     case 76: 
/*  998: 925 */       return new AssignmentSimple(getStackLValue(0), new Literal(TypedLiteral.getDouble(1.0D)));
/*  999:     */     case 77: 
/* 1000: 927 */       return new AssignmentSimple(getStackLValue(0), new Literal(TypedLiteral.getFloat(2.0F)));
/* 1001:     */     case 78: 
/* 1002: 929 */       return new AssignmentSimple(getStackLValue(0), new Literal(TypedLiteral.getInt(this.rawData[0])));
/* 1003:     */     case 79: 
/* 1004: 931 */       return new AssignmentSimple(getStackLValue(0), new Literal(TypedLiteral.getInt(getInstrArgShort(0))));
/* 1005:     */     case 33: 
/* 1006:     */     case 34: 
/* 1007:     */     case 35: 
/* 1008:     */     case 36: 
/* 1009:     */     case 37: 
/* 1010:     */     case 38: 
/* 1011:     */     case 39: 
/* 1012:     */     case 40: 
/* 1013:     */     case 41: 
/* 1014:     */     case 42: 
/* 1015:     */     case 43: 
/* 1016:     */     case 44: 
/* 1017:     */     case 45: 
/* 1018:     */     case 46: 
/* 1019:     */     case 47: 
/* 1020:     */     case 48: 
/* 1021:     */     case 49: 
/* 1022:     */     case 50: 
/* 1023:     */     case 51: 
/* 1024:     */     case 52: 
/* 1025:     */     case 53: 
/* 1026:     */     case 54: 
/* 1027:     */     case 55: 
/* 1028:     */     case 56: 
/* 1029:     */     case 57: 
/* 1030:     */     case 58: 
/* 1031:     */     case 59: 
/* 1032:     */     case 60: 
/* 1033:     */     case 61: 
/* 1034:     */     case 62: 
/* 1035: 962 */       return mkAssign(variableFactory);
/* 1036:     */     case 80: 
/* 1037: 964 */       return new AssignmentSimple(getStackLValue(0), new NewObject(this.cpEntries[0]));
/* 1038:     */     case 81: 
/* 1039: 966 */       return new AssignmentSimple(getStackLValue(0), new NewPrimitiveArray(getStackRValue(0), this.rawData[0]));
/* 1040:     */     case 82: 
/* 1041: 968 */       List<Expression> tmp = ListFactory.newList();
/* 1042: 969 */       tmp.add(getStackRValue(0));
/* 1043:     */       
/* 1044:     */ 
/* 1045:     */ 
/* 1046:     */ 
/* 1047: 974 */       ConstantPoolEntryClass clazz = (ConstantPoolEntryClass)this.cpEntries[0];
/* 1048: 975 */       JavaTypeInstance innerInstance = clazz.getTypeInstance();
/* 1049:     */       
/* 1050: 977 */       JavaTypeInstance resultInstance = new JavaArrayTypeInstance(1, innerInstance);
/* 1051:     */       
/* 1052: 979 */       return new AssignmentSimple(getStackLValue(0), new NewObjectArray(tmp, resultInstance));
/* 1053:     */     case 83: 
/* 1054: 982 */       int numDims = this.rawData[2];
/* 1055:     */       
/* 1056:     */ 
/* 1057: 985 */       ConstantPoolEntryClass clazz = (ConstantPoolEntryClass)this.cpEntries[0];
/* 1058: 986 */       JavaTypeInstance innerInstance = clazz.getTypeInstance();
/* 1059:     */       
/* 1060: 988 */       JavaTypeInstance resultInstance = innerInstance;
/* 1061:     */       
/* 1062: 990 */       return new AssignmentSimple(getStackLValue(0), new NewObjectArray(getNStackRValuesAsExpressions(numDims), resultInstance));
/* 1063:     */     case 84: 
/* 1064: 993 */       return new AssignmentSimple(getStackLValue(0), new ArrayLength(getStackRValue(0)));
/* 1065:     */     case 85: 
/* 1066:     */     case 86: 
/* 1067:     */     case 87: 
/* 1068:     */     case 88: 
/* 1069:     */     case 89: 
/* 1070:     */     case 90: 
/* 1071:     */     case 91: 
/* 1072:     */     case 92: 
/* 1073:1002 */       return new AssignmentSimple(getStackLValue(0), new ArrayIndex(getStackRValue(1), getStackRValue(0)));
/* 1074:     */     case 93: 
/* 1075:     */     case 94: 
/* 1076:     */     case 95: 
/* 1077:     */     case 96: 
/* 1078:     */     case 97: 
/* 1079:     */     case 98: 
/* 1080:     */     case 99: 
/* 1081:     */     case 100: 
/* 1082:1011 */       return new AssignmentSimple(new ArrayVariable(new ArrayIndex(getStackRValue(2), getStackRValue(1))), getStackRValue(0));
/* 1083:     */     case 101: 
/* 1084:     */     case 102: 
/* 1085:     */     case 103: 
/* 1086:     */     case 104: 
/* 1087:     */     case 105: 
/* 1088:     */     case 106: 
/* 1089:     */     case 107: 
/* 1090:     */     case 108: 
/* 1091:     */     case 109: 
/* 1092:     */     case 110: 
/* 1093:     */     case 111: 
/* 1094:     */     case 112: 
/* 1095:     */     case 113: 
/* 1096:     */     case 114: 
/* 1097:     */     case 115: 
/* 1098:     */     case 116: 
/* 1099:     */     case 117: 
/* 1100:     */     case 118: 
/* 1101:     */     case 119: 
/* 1102:     */     case 120: 
/* 1103:     */     case 121: 
/* 1104:     */     case 122: 
/* 1105:     */     case 123: 
/* 1106:     */     case 124: 
/* 1107:     */     case 125: 
/* 1108:     */     case 126: 
/* 1109:     */     case 127: 
/* 1110:     */     case 128: 
/* 1111:     */     case 129: 
/* 1112:     */     case 130: 
/* 1113:     */     case 131: 
/* 1114:     */     case 132: 
/* 1115:     */     case 133: 
/* 1116:     */     case 134: 
/* 1117:1046 */       Expression lhs = getStackRValue(1);
/* 1118:1047 */       Expression rhs = getStackRValue(0);
/* 1119:1048 */       Expression op = new ArithmeticOperation(lhs, rhs, ArithOp.getOpFor(this.instr));
/* 1120:1049 */       return new AssignmentSimple(getStackLValue(0), op);
/* 1121:     */     case 135: 
/* 1122:     */     case 136: 
/* 1123:     */     case 137: 
/* 1124:1054 */       Expression lhs = getStackRValue(1);
/* 1125:1055 */       Expression rhs = getStackRValue(0);
/* 1126:1056 */       if ((lhs.getInferredJavaType().getJavaTypeInstance() == RawJavaType.BOOLEAN) && (rhs.getInferredJavaType().getJavaTypeInstance() == RawJavaType.BOOLEAN))
/* 1127:     */       {
/* 1128:1058 */         Expression op = new ArithmeticOperation(lhs, rhs, ArithOp.getOpFor(this.instr));
/* 1129:1059 */         return new AssignmentSimple(getStackLValue(0), op);
/* 1130:     */       }
/* 1131:1061 */       ArithOp arithop = ArithOp.getOpFor(this.instr);
/* 1132:1062 */       InferredJavaType.useInArithOp(lhs.getInferredJavaType(), rhs.getInferredJavaType(), arithop);
/* 1133:1063 */       Expression op = new ArithmeticOperation(new InferredJavaType(RawJavaType.INT, InferredJavaType.Source.EXPRESSION, true), lhs, rhs, arithop);
/* 1134:1064 */       return new AssignmentSimple(getStackLValue(0), op);
/* 1135:     */     case 138: 
/* 1136:     */     case 139: 
/* 1137:     */     case 140: 
/* 1138:     */     case 141: 
/* 1139:     */     case 142: 
/* 1140:     */     case 143: 
/* 1141:     */     case 144: 
/* 1142:     */     case 145: 
/* 1143:     */     case 146: 
/* 1144:     */     case 147: 
/* 1145:     */     case 148: 
/* 1146:     */     case 149: 
/* 1147:     */     case 150: 
/* 1148:     */     case 151: 
/* 1149:     */     case 152: 
/* 1150:1081 */       LValue lValue = getStackLValue(0);
/* 1151:1082 */       lValue.getInferredJavaType().useAsWithCast(this.instr.getRawJavaType());
/* 1152:1083 */       return new AssignmentSimple(lValue, getStackRValue(0));
/* 1153:     */     case 153: 
/* 1154:1086 */       return new AssignmentSimple(getStackLValue(0), new InstanceOfExpression(getStackRValue(0), this.cpEntries[0]));
/* 1155:     */     case 154: 
/* 1156:1088 */       ConstantPoolEntryClass castTarget = (ConstantPoolEntryClass)this.cpEntries[0];
/* 1157:1089 */       JavaTypeInstance tgtJavaType = castTarget.getTypeInstance();
/* 1158:1090 */       JavaTypeInstance srcJavaType = getStackRValue(0).getInferredJavaType().getJavaTypeInstance();
/* 1159:     */       
/* 1160:     */ 
/* 1161:1093 */       Expression rhs = getStackRValue(0);
/* 1162:1094 */       if (!tgtJavaType.equals(srcJavaType.getDeGenerifiedType()))
/* 1163:     */       {
/* 1164:1097 */         InferredJavaType castType = new InferredJavaType(tgtJavaType, InferredJavaType.Source.EXPRESSION, true);
/* 1165:1098 */         rhs = new CastExpression(castType, getStackRValue(0));
/* 1166:     */       }
/* 1167:1100 */       return new AssignmentSimple(getStackLValue(0), rhs);
/* 1168:     */     case 155: 
/* 1169:1103 */       ConstantPoolEntryMethodRef function = (ConstantPoolEntryMethodRef)this.cpEntries[0];
/* 1170:1104 */       MethodPrototype methodPrototype = function.getMethodPrototype();
/* 1171:1105 */       List<Expression> args = getNStackRValuesAsExpressions(this.stackConsumed.size());
/* 1172:1106 */       methodPrototype.tightenArgs(null, args);
/* 1173:     */       
/* 1174:     */ 
/* 1175:1109 */       StaticFunctionInvokation funcCall = new StaticFunctionInvokation(function, args);
/* 1176:1110 */       if (this.stackProduced.size() == 0) {
/* 1177:1111 */         return new ExpressionStatement(funcCall);
/* 1178:     */       }
/* 1179:1113 */       InferredJavaType type = funcCall.getInferredJavaType();
/* 1180:1114 */       type.setTaggedBytecodeLocation(this.originalRawOffset);
/* 1181:1115 */       typeHintRecovery.improve(type);
/* 1182:1116 */       return new AssignmentSimple(getStackLValue(0), funcCall);
/* 1183:     */     case 156: 
/* 1184:1122 */       return buildInvokeDynamic(method, dcCommonState);
/* 1185:     */     case 157: 
/* 1186:     */     case 158: 
/* 1187:     */     case 159: 
/* 1188:1131 */       return buildInvoke(method);
/* 1189:     */     case 160: 
/* 1190:1134 */       return new ReturnNothingStatement();
/* 1191:     */     case 161: 
/* 1192:     */     case 162: 
/* 1193:     */     case 163: 
/* 1194:     */     case 164: 
/* 1195:     */     case 165: 
/* 1196:     */     case 166: 
/* 1197:     */     case 167: 
/* 1198:     */     case 168: 
/* 1199:1143 */       ConditionalExpression conditionalExpression = new ComparisonOperation(getStackRValue(1), getStackRValue(0), CompOp.getOpFor(this.instr));
/* 1200:1144 */       return new IfStatement(conditionalExpression);
/* 1201:     */     case 169: 
/* 1202:1147 */       ConditionalExpression conditionalExpression = new ComparisonOperation(getStackRValue(0), new Literal(TypedLiteral.getNull()), CompOp.NE);
/* 1203:1148 */       return new IfStatement(conditionalExpression);
/* 1204:     */     case 170: 
/* 1205:1151 */       ConditionalExpression conditionalExpression = new ComparisonOperation(getStackRValue(0), new Literal(TypedLiteral.getNull()), CompOp.EQ);
/* 1206:1152 */       return new IfStatement(conditionalExpression);
/* 1207:     */     case 171: 
/* 1208:     */     case 172: 
/* 1209:1156 */       ConditionalExpression conditionalExpression = new ComparisonOperation(getStackRValue(0), new Literal(TypedLiteral.getBoolean(0)), CompOp.getOpFor(this.instr));
/* 1210:1157 */       return new IfStatement(conditionalExpression);
/* 1211:     */     case 173: 
/* 1212:     */     case 174: 
/* 1213:     */     case 175: 
/* 1214:     */     case 176: 
/* 1215:1163 */       ConditionalExpression conditionalExpression = new ComparisonOperation(getStackRValue(0), new Literal(TypedLiteral.getInt(0)), CompOp.getOpFor(this.instr));
/* 1216:1164 */       return new IfStatement(conditionalExpression);
/* 1217:     */     case 177: 
/* 1218:     */     case 178: 
/* 1219:1168 */       return new CompoundStatement(new Statement[] { new AssignmentSimple(getStackLValue(0), new Literal(TypedLiteral.getInt(this.originalRawOffset))), new JSRCallStatement() });
/* 1220:     */     case 179: 
/* 1221:1174 */       int slot = getInstrArgU1(0);
/* 1222:     */       
/* 1223:1176 */       Expression retVal = new LValueExpression(variableFactory.localVariable(slot, (Ident)this.localVariablesBySlot.get(Integer.valueOf(slot)), this.originalRawOffset));
/* 1224:1177 */       return new JSRRetStatement(retVal);
/* 1225:     */     case 180: 
/* 1226:     */     case 181: 
/* 1227:1181 */       return new GotoStatement();
/* 1228:     */     case 182: 
/* 1229:1183 */       return new ThrowStatement(getStackRValue(0));
/* 1230:     */     case 183: 
/* 1231:     */     case 184: 
/* 1232:     */     case 185: 
/* 1233:     */     case 186: 
/* 1234:     */     case 187: 
/* 1235:1189 */       Expression retVal = getStackRValue(0);
/* 1236:1190 */       JavaTypeInstance tgtType = variableFactory.getReturn();
/* 1237:1191 */       retVal.getInferredJavaType().useAsWithoutCasting(tgtType);
/* 1238:1192 */       return new ReturnValueStatement(retVal, tgtType);
/* 1239:     */     case 188: 
/* 1240:1195 */       Expression fieldExpression = new LValueExpression(new FieldVariable(getStackRValue(0), this.cpEntries[0]));
/* 1241:1196 */       return new AssignmentSimple(getStackLValue(0), fieldExpression);
/* 1242:     */     case 189: 
/* 1243:1199 */       return new AssignmentSimple(getStackLValue(0), new LValueExpression(new StaticVariable(this.cpEntries[0])));
/* 1244:     */     case 190: 
/* 1245:1201 */       return new AssignmentSimple(new StaticVariable(this.cpEntries[0]), getStackRValue(0));
/* 1246:     */     case 191: 
/* 1247:1203 */       return new AssignmentSimple(new FieldVariable(getStackRValue(1), this.cpEntries[0]), getStackRValue(0));
/* 1248:     */     case 192: 
/* 1249:1205 */       Statement s1 = new AssignmentSimple(getStackLValue(0), getStackRValue(1));
/* 1250:1206 */       Statement s2 = new AssignmentSimple(getStackLValue(1), getStackRValue(0));
/* 1251:1207 */       return new CompoundStatement(new Statement[] { s1, s2 });
/* 1252:     */     case 193: 
/* 1253:1210 */       Statement s1 = new AssignmentSimple(getStackLValue(0), getStackRValue(0));
/* 1254:1211 */       Statement s2 = new AssignmentSimple(getStackLValue(1), getStackRValue(0));
/* 1255:1212 */       return new CompoundStatement(new Statement[] { s1, s2 });
/* 1256:     */     case 194: 
/* 1257:1215 */       Statement s1 = new AssignmentSimple(getStackLValue(0), getStackRValue(0));
/* 1258:1216 */       Statement s2 = new AssignmentSimple(getStackLValue(1), getStackRValue(1));
/* 1259:1217 */       Statement s3 = new AssignmentSimple(getStackLValue(2), getStackRValue(0));
/* 1260:1218 */       return new CompoundStatement(new Statement[] { s1, s2, s3 });
/* 1261:     */     case 195: 
/* 1262:1221 */       if (((StackEntryHolder)this.stackConsumed.get(1)).getStackEntry().getType().getComputationCategory() == 2)
/* 1263:     */       {
/* 1264:1223 */         Statement s1 = new AssignmentSimple(getStackLValue(0), getStackRValue(0));
/* 1265:1224 */         Statement s2 = new AssignmentSimple(getStackLValue(1), getStackRValue(1));
/* 1266:1225 */         Statement s3 = new AssignmentSimple(getStackLValue(2), getStackRValue(0));
/* 1267:1226 */         return new CompoundStatement(new Statement[] { s1, s2, s3 });
/* 1268:     */       }
/* 1269:1229 */       Statement s1 = new AssignmentSimple(getStackLValue(0), getStackRValue(0));
/* 1270:1230 */       Statement s2 = new AssignmentSimple(getStackLValue(1), getStackRValue(1));
/* 1271:1231 */       Statement s3 = new AssignmentSimple(getStackLValue(2), getStackRValue(2));
/* 1272:1232 */       Statement s4 = new AssignmentSimple(getStackLValue(3), getStackRValue(0));
/* 1273:1233 */       return new CompoundStatement(new Statement[] { s1, s2, s3, s4 });
/* 1274:     */     case 196: 
/* 1275:1237 */       if (((StackEntryHolder)this.stackConsumed.get(0)).getStackEntry().getType().getComputationCategory() == 2)
/* 1276:     */       {
/* 1277:1239 */         Statement s1 = new AssignmentSimple(getStackLValue(0), getStackRValue(0));
/* 1278:1240 */         Statement s2 = new AssignmentSimple(getStackLValue(1), getStackRValue(0));
/* 1279:1241 */         return new CompoundStatement(new Statement[] { s1, s2 });
/* 1280:     */       }
/* 1281:1244 */       Statement s1 = new AssignmentSimple(getStackLValue(0), getStackRValue(0));
/* 1282:1245 */       Statement s2 = new AssignmentSimple(getStackLValue(1), getStackRValue(1));
/* 1283:1246 */       Statement s3 = new AssignmentSimple(getStackLValue(2), getStackRValue(0));
/* 1284:1247 */       Statement s4 = new AssignmentSimple(getStackLValue(3), getStackRValue(1));
/* 1285:1248 */       return new CompoundStatement(new Statement[] { s1, s2, s3, s4 });
/* 1286:     */     case 197: 
/* 1287:1252 */       if (((StackEntryHolder)this.stackConsumed.get(0)).getStackEntry().getType().getComputationCategory() == 2)
/* 1288:     */       {
/* 1289:1254 */         Statement s1 = new AssignmentSimple(getStackLValue(0), getStackRValue(0));
/* 1290:1255 */         Statement s2 = new AssignmentSimple(getStackLValue(1), getStackRValue(1));
/* 1291:1256 */         Statement s3 = new AssignmentSimple(getStackLValue(2), getStackRValue(0));
/* 1292:1257 */         return new CompoundStatement(new Statement[] { s1, s2, s3 });
/* 1293:     */       }
/* 1294:1260 */       Statement s1 = new AssignmentSimple(getStackLValue(0), getStackRValue(0));
/* 1295:1261 */       Statement s2 = new AssignmentSimple(getStackLValue(1), getStackRValue(1));
/* 1296:1262 */       Statement s3 = new AssignmentSimple(getStackLValue(2), getStackRValue(2));
/* 1297:1263 */       Statement s4 = new AssignmentSimple(getStackLValue(3), getStackRValue(0));
/* 1298:1264 */       Statement s5 = new AssignmentSimple(getStackLValue(4), getStackRValue(1));
/* 1299:1265 */       return new CompoundStatement(new Statement[] { s1, s2, s3, s4, s5 });
/* 1300:     */     case 198: 
/* 1301:1269 */       if (((StackEntryHolder)this.stackConsumed.get(0)).getStackEntry().getType().getComputationCategory() == 2)
/* 1302:     */       {
/* 1303:1270 */         if (((StackEntryHolder)this.stackConsumed.get(1)).getStackEntry().getType().getComputationCategory() == 2)
/* 1304:     */         {
/* 1305:1272 */           Statement s1 = new AssignmentSimple(getStackLValue(0), getStackRValue(0));
/* 1306:1273 */           Statement s2 = new AssignmentSimple(getStackLValue(1), getStackRValue(1));
/* 1307:1274 */           Statement s3 = new AssignmentSimple(getStackLValue(2), getStackRValue(0));
/* 1308:1275 */           return new CompoundStatement(new Statement[] { s1, s2, s3 });
/* 1309:     */         }
/* 1310:1278 */         Statement s1 = new AssignmentSimple(getStackLValue(0), getStackRValue(0));
/* 1311:1279 */         Statement s2 = new AssignmentSimple(getStackLValue(1), getStackRValue(1));
/* 1312:1280 */         Statement s3 = new AssignmentSimple(getStackLValue(2), getStackRValue(2));
/* 1313:1281 */         Statement s4 = new AssignmentSimple(getStackLValue(3), getStackRValue(0));
/* 1314:1282 */         return new CompoundStatement(new Statement[] { s1, s2, s3, s4 });
/* 1315:     */       }
/* 1316:1285 */       if (((StackEntryHolder)this.stackConsumed.get(2)).getStackEntry().getType().getComputationCategory() == 2)
/* 1317:     */       {
/* 1318:1287 */         Statement s1 = new AssignmentSimple(getStackLValue(0), getStackRValue(0));
/* 1319:1288 */         Statement s2 = new AssignmentSimple(getStackLValue(1), getStackRValue(1));
/* 1320:1289 */         Statement s3 = new AssignmentSimple(getStackLValue(2), getStackRValue(2));
/* 1321:1290 */         Statement s4 = new AssignmentSimple(getStackLValue(3), getStackRValue(0));
/* 1322:1291 */         Statement s5 = new AssignmentSimple(getStackLValue(4), getStackRValue(1));
/* 1323:1292 */         return new CompoundStatement(new Statement[] { s1, s2, s3, s4, s5 });
/* 1324:     */       }
/* 1325:1295 */       Statement s1 = new AssignmentSimple(getStackLValue(0), getStackRValue(0));
/* 1326:1296 */       Statement s2 = new AssignmentSimple(getStackLValue(1), getStackRValue(1));
/* 1327:1297 */       Statement s3 = new AssignmentSimple(getStackLValue(2), getStackRValue(2));
/* 1328:1298 */       Statement s4 = new AssignmentSimple(getStackLValue(3), getStackRValue(3));
/* 1329:1299 */       Statement s5 = new AssignmentSimple(getStackLValue(4), getStackRValue(0));
/* 1330:1300 */       Statement s6 = new AssignmentSimple(getStackLValue(5), getStackRValue(1));
/* 1331:1301 */       return new CompoundStatement(new Statement[] { s1, s2, s3, s4, s5, s6 });
/* 1332:     */     case 199: 
/* 1333:     */     case 200: 
/* 1334:     */     case 201: 
/* 1335:1308 */       return new AssignmentSimple(getStackLValue(0), new Literal(TypedLiteral.getConstantPoolEntry(this.cp, this.cpEntries[0])));
/* 1336:     */     case 202: 
/* 1337:1310 */       return new MonitorEnterStatement(getStackRValue(0), blockIdentifierFactory.getNextBlockIdentifier(BlockType.MONITOR));
/* 1338:     */     case 203: 
/* 1339:1312 */       return new MonitorExitStatement(getStackRValue(0));
/* 1340:     */     case 204: 
/* 1341:1314 */       return new TryStatement(getSingleExceptionGroup());
/* 1342:     */     case 205: 
/* 1343:1316 */       return new CatchStatement(this.catchExceptionGroups, getStackLValue(0));
/* 1344:     */     case 206: 
/* 1345:1318 */       return new Nop();
/* 1346:     */     case 207: 
/* 1347:1321 */       return new ExpressionStatement(getStackRValue(0));
/* 1348:     */     case 208: 
/* 1349:1323 */       if (((StackEntryHolder)this.stackConsumed.get(0)).getStackEntry().getType().getComputationCategory() == 2) {
/* 1350:1324 */         return new ExpressionStatement(getStackRValue(0));
/* 1351:     */       }
/* 1352:1327 */       Statement s1 = new ExpressionStatement(getStackRValue(0));
/* 1353:1328 */       Statement s2 = new ExpressionStatement(getStackRValue(1));
/* 1354:1329 */       return new CompoundStatement(new Statement[] { s1, s2 });
/* 1355:     */     case 209: 
/* 1356:1332 */       return new RawSwitchStatement(ensureNonBool(getStackRValue(0)), new DecodedTableSwitch(this.rawData, this.originalRawOffset));
/* 1357:     */     case 210: 
/* 1358:1334 */       return new RawSwitchStatement(ensureNonBool(getStackRValue(0)), new DecodedLookupSwitch(this.rawData, this.originalRawOffset));
/* 1359:     */     case 13: 
/* 1360:1336 */       int variableIndex = getInstrArgU1(0);
/* 1361:1337 */       int incrAmount = getInstrArgByte(1);
/* 1362:1338 */       ArithOp op = ArithOp.PLUS;
/* 1363:1339 */       if (incrAmount < 0)
/* 1364:     */       {
/* 1365:1340 */         incrAmount = -incrAmount;
/* 1366:1341 */         op = ArithOp.MINUS;
/* 1367:     */       }
/* 1368:1345 */       LValue lvalue = variableFactory.localVariable(variableIndex, (Ident)this.localVariablesBySlot.get(Integer.valueOf(variableIndex)), this.originalRawOffset);
/* 1369:1346 */       return new AssignmentSimple(lvalue, new ArithmeticOperation(new LValueExpression(lvalue), new Literal(TypedLiteral.getInt(incrAmount)), op));
/* 1370:     */     case 14: 
/* 1371:1350 */       int variableIndex = getInstrArgShort(1);
/* 1372:1351 */       int incrAmount = getInstrArgShort(3);
/* 1373:1352 */       ArithOp op = ArithOp.PLUS;
/* 1374:1353 */       if (incrAmount < 0)
/* 1375:     */       {
/* 1376:1354 */         incrAmount = -incrAmount;
/* 1377:1355 */         op = ArithOp.MINUS;
/* 1378:     */       }
/* 1379:1359 */       LValue lvalue = variableFactory.localVariable(variableIndex, (Ident)this.localVariablesBySlot.get(Integer.valueOf(variableIndex)), this.originalRawOffset);
/* 1380:     */       
/* 1381:1361 */       return new AssignmentSimple(lvalue, new ArithmeticOperation(new LValueExpression(lvalue), new Literal(TypedLiteral.getInt(incrAmount)), op));
/* 1382:     */     case 211: 
/* 1383:     */     case 212: 
/* 1384:     */     case 213: 
/* 1385:     */     case 214: 
/* 1386:1369 */       return new AssignmentSimple(getStackLValue(0), new ArithmeticMonOperation(getStackRValue(0), ArithOp.MINUS));
/* 1387:     */     }
/* 1388:1373 */     throw new ConfusedCFRException("Not implemented - conversion to statement from " + this.instr);
/* 1389:     */   }
/* 1390:     */   
/* 1391:     */   private StackValue getStackRValue(int idx)
/* 1392:     */   {
/* 1393:1378 */     StackEntryHolder stackEntryHolder = (StackEntryHolder)this.stackConsumed.get(idx);
/* 1394:1379 */     StackEntry stackEntry = stackEntryHolder.getStackEntry();
/* 1395:1380 */     stackEntry.incrementUsage();
/* 1396:1381 */     return new StackValue(stackEntry.getLValue());
/* 1397:     */   }
/* 1398:     */   
/* 1399:     */   private LValue getStackLValue(int idx)
/* 1400:     */   {
/* 1401:1385 */     StackEntryHolder stackEntryHolder = (StackEntryHolder)this.stackProduced.get(idx);
/* 1402:1386 */     StackEntry stackEntry = stackEntryHolder.getStackEntry();
/* 1403:1387 */     return stackEntry.getLValue();
/* 1404:     */   }
/* 1405:     */   
/* 1406:     */   private List<Expression> getNStackRValuesAsExpressions(int count)
/* 1407:     */   {
/* 1408:1391 */     List<Expression> res = ListFactory.newList();
/* 1409:1392 */     for (int i = count - 1; i >= 0; i--) {
/* 1410:1393 */       res.add(getStackRValue(i));
/* 1411:     */     }
/* 1412:1395 */     return res;
/* 1413:     */   }
/* 1414:     */   
/* 1415:     */   public String toString()
/* 1416:     */   {
/* 1417:1400 */     return "" + this.index + " : " + this.instr;
/* 1418:     */   }
/* 1419:     */   
/* 1420:     */   public static void populateStackInfo(List<Op02WithProcessedDataAndRefs> op2list, Method method)
/* 1421:     */   {
/* 1422:1406 */     for (Op02WithProcessedDataAndRefs op : op2list) {
/* 1423:1407 */       op.resetStackInfo();
/* 1424:     */     }
/* 1425:1411 */     LinkedList<Pair<StackSim, Op02WithProcessedDataAndRefs>> toProcess = ListFactory.newLinkedList();
/* 1426:1412 */     toProcess.add(Pair.make(new StackSim(), op2list.get(0)));
/* 1427:     */     try
/* 1428:     */     {
/* 1429:1414 */       while (!toProcess.isEmpty())
/* 1430:     */       {
/* 1431:1415 */         Pair<StackSim, Op02WithProcessedDataAndRefs> next = (Pair)toProcess.removeFirst();
/* 1432:1416 */         Op02WithProcessedDataAndRefs o2 = (Op02WithProcessedDataAndRefs)next.getSecond();
/* 1433:1417 */         StackSim stackSim = (StackSim)next.getFirst();
/* 1434:1418 */         o2.populateStackInfo(stackSim, method, toProcess);
/* 1435:     */       }
/* 1436:     */     }
/* 1437:     */     catch (ConfusedCFRException e)
/* 1438:     */     {
/* 1439:1421 */       Dumper dmp = new ToStringDumper();
/* 1440:1422 */       dmp.print("----[known stack info]------------\n\n");
/* 1441:1423 */       for (Op02WithProcessedDataAndRefs op : op2list) {
/* 1442:1424 */         op.dump(dmp);
/* 1443:     */       }
/* 1444:1426 */       System.err.print(dmp.toString());
/* 1445:1427 */       throw e;
/* 1446:     */     }
/* 1447:     */   }
/* 1448:     */   
/* 1449:     */   public static void unlinkUnreachable(List<Op02WithProcessedDataAndRefs> op2list)
/* 1450:     */   {
/* 1451:1434 */     Set<Op02WithProcessedDataAndRefs> reached = SetFactory.newSet();
/* 1452:1435 */     GraphVisitor<Op02WithProcessedDataAndRefs> reachableVisitor = new GraphVisitorDFS(op2list.get(0), new BinaryProcedure()
/* 1453:     */     {
/* 1454:     */       public void call(Op02WithProcessedDataAndRefs arg1, GraphVisitor<Op02WithProcessedDataAndRefs> arg2)
/* 1455:     */       {
/* 1456:1440 */         this.val$reached.add(arg1);
/* 1457:1441 */         for (Op02WithProcessedDataAndRefs target : arg1.getTargets()) {
/* 1458:1442 */           arg2.enqueue(target);
/* 1459:     */         }
/* 1460:     */       }
/* 1461:1445 */     });
/* 1462:1446 */     reachableVisitor.process();
/* 1463:1451 */     for (Op02WithProcessedDataAndRefs op : op2list) {
/* 1464:1452 */       if (!reached.contains(op))
/* 1465:     */       {
/* 1466:1455 */         for (Op02WithProcessedDataAndRefs target : op.targets) {
/* 1467:1456 */           target.removeSource(op);
/* 1468:     */         }
/* 1469:1458 */         op.instr = JVMInstr.NOP;
/* 1470:1459 */         op.targets.clear();
/* 1471:     */       }
/* 1472:     */     }
/* 1473:     */   }
/* 1474:     */   
/* 1475:     */   public void nop()
/* 1476:     */   {
/* 1477:1465 */     this.instr = JVMInstr.NOP;
/* 1478:     */   }
/* 1479:     */   
/* 1480:     */   public void swap()
/* 1481:     */   {
/* 1482:1469 */     this.instr = JVMInstr.SWAP;
/* 1483:     */   }
/* 1484:     */   
/* 1485:     */   private void collectLocallyMutatedVariables(SSAIdentifierFactory<Slot> ssaIdentifierFactory)
/* 1486:     */   {
/* 1487:1473 */     Pair<JavaTypeInstance, Integer> storage = getStorageType();
/* 1488:1474 */     if (storage != null)
/* 1489:     */     {
/* 1490:1475 */       this.ssaIdentifiers = new SSAIdentifiers(new Slot((JavaTypeInstance)storage.getFirst(), ((Integer)storage.getSecond()).intValue()), ssaIdentifierFactory);
/* 1491:1476 */       return;
/* 1492:     */     }
/* 1493:1479 */     this.ssaIdentifiers = new SSAIdentifiers();
/* 1494:     */   }
/* 1495:     */   
/* 1496:     */   private static void assignSSAIdentifiers(SSAIdentifierFactory<Slot> ssaIdentifierFactory, Method method, DecompilerComments comments, List<Op02WithProcessedDataAndRefs> statements, BytecodeMeta bytecodeMeta, Options options)
/* 1497:     */   {
/* 1498:1484 */     assignSSAIdentifiersInner(ssaIdentifierFactory, method, statements, bytecodeMeta, options);
/* 1499:     */     
/* 1500:     */ 
/* 1501:     */ 
/* 1502:     */ 
/* 1503:     */ 
/* 1504:1490 */     Map<Integer, JavaTypeInstance> missing = MapFactory.newTreeMap();
/* 1505:1492 */     for (Op02WithProcessedDataAndRefs op02 : statements)
/* 1506:     */     {
/* 1507:1493 */       Pair<JavaTypeInstance, Integer> load = op02.getRetrieveType();
/* 1508:1494 */       if (load != null)
/* 1509:     */       {
/* 1510:1496 */         SSAIdent ident = op02.ssaIdentifiers.getSSAIdentOnExit(new Slot((JavaTypeInstance)load.getFirst(), ((Integer)load.getSecond()).intValue()));
/* 1511:1497 */         if (ident == null) {
/* 1512:1498 */           missing.put(load.getSecond(), load.getFirst());
/* 1513:     */         }
/* 1514:     */       }
/* 1515:     */     }
/* 1516:1502 */     if (missing.isEmpty()) {
/* 1517:1502 */       return;
/* 1518:     */     }
/* 1519:1504 */     if (!method.getConstructorFlag().isConstructor()) {
/* 1520:1505 */       throw new IllegalStateException("Invisible function parameters on a non-constructor");
/* 1521:     */     }
/* 1522:1512 */     method.getMethodPrototype().setSyntheticConstructorParameters(method.getConstructorFlag(), comments, missing);
/* 1523:     */     
/* 1524:1514 */     assignSSAIdentifiersInner(ssaIdentifierFactory, method, statements, bytecodeMeta, options);
/* 1525:     */   }
/* 1526:     */   
/* 1527:     */   public static void assignSSAIdentifiersInner(SSAIdentifierFactory<Slot> ssaIdentifierFactory, Method method, List<Op02WithProcessedDataAndRefs> statements, BytecodeMeta bytecodeMeta, Options options)
/* 1528:     */   {
/* 1529:1527 */     Map<Slot, SSAIdent> idents = method.getMethodPrototype().collectInitialSlotUsage(method.getConstructorFlag(), ssaIdentifierFactory);
/* 1530:1529 */     for (Op02WithProcessedDataAndRefs statement : statements) {
/* 1531:1530 */       statement.collectLocallyMutatedVariables(ssaIdentifierFactory);
/* 1532:     */     }
/* 1533:1532 */     ((Op02WithProcessedDataAndRefs)statements.get(0)).ssaIdentifiers = new SSAIdentifiers(idents);
/* 1534:     */     
/* 1535:1534 */     Set<Integer> livenessClashes = bytecodeMeta.getLivenessClashes();
/* 1536:     */     
/* 1537:1536 */     BinaryPredicate<Slot, Slot> testSlot = new BinaryPredicate()
/* 1538:     */     {
/* 1539:     */       public boolean test(Slot a, Slot b)
/* 1540:     */       {
/* 1541:1539 */         StackType t1 = a.getJavaTypeInstance().getStackType();
/* 1542:1540 */         StackType t2 = b.getJavaTypeInstance().getStackType();
/* 1543:1541 */         if (t1 == t2)
/* 1544:     */         {
/* 1545:1542 */           if (t1.isClosed()) {
/* 1546:1542 */             return true;
/* 1547:     */           }
/* 1548:1543 */           if (this.val$livenessClashes.isEmpty()) {
/* 1549:1543 */             return true;
/* 1550:     */           }
/* 1551:1544 */           if (this.val$livenessClashes.contains(Integer.valueOf(a.getIdx()))) {
/* 1552:1545 */             return false;
/* 1553:     */           }
/* 1554:1547 */           return true;
/* 1555:     */         }
/* 1556:1549 */         return false;
/* 1557:     */       }
/* 1558:1552 */     };
/* 1559:1553 */     BinaryPredicate<Slot, Slot> always = new BinaryPredicate()
/* 1560:     */     {
/* 1561:     */       public boolean test(Slot a, Slot b)
/* 1562:     */       {
/* 1563:1556 */         return false;
/* 1564:     */       }
/* 1565:1559 */     };
/* 1566:1560 */     LinkedList<Op02WithProcessedDataAndRefs> toProcess = ListFactory.newLinkedList();
/* 1567:1561 */     toProcess.addAll(statements);
/* 1568:1562 */     while (!toProcess.isEmpty())
/* 1569:     */     {
/* 1570:1563 */       Op02WithProcessedDataAndRefs statement = (Op02WithProcessedDataAndRefs)toProcess.remove();
/* 1571:1564 */       SSAIdentifiers<Slot> ssaIdentifiers = statement.ssaIdentifiers;
/* 1572:1565 */       boolean changed = false;
/* 1573:     */       
/* 1574:     */ 
/* 1575:1568 */       BinaryPredicate<Slot, Slot> test = testSlot;
/* 1576:1569 */       if (statement.hasCatchParent) {
/* 1577:1569 */         test = always;
/* 1578:     */       }
/* 1579:1570 */       for (Op02WithProcessedDataAndRefs source : statement.getSources()) {
/* 1580:1571 */         if (ssaIdentifiers.mergeWith(source.ssaIdentifiers, test)) {
/* 1581:1572 */           changed = true;
/* 1582:     */         }
/* 1583:     */       }
/* 1584:1576 */       if (changed) {
/* 1585:1577 */         toProcess.addAll(statement.getTargets());
/* 1586:     */       }
/* 1587:     */     }
/* 1588:     */   }
/* 1589:     */   
/* 1590:     */   private static void removeUnusedSSAIdentifiers(SSAIdentifierFactory<Slot> ssaIdentifierFactory, Method method, List<Op02WithProcessedDataAndRefs> op2list)
/* 1591:     */   {
/* 1592:1600 */     List<Op02WithProcessedDataAndRefs> endPoints = ListFactory.newList();
/* 1593:1601 */     GraphVisitor<Op02WithProcessedDataAndRefs> gv = new GraphVisitorDFS(op2list.get(0), new BinaryProcedure()
/* 1594:     */     {
/* 1595:     */       public void call(Op02WithProcessedDataAndRefs arg1, GraphVisitor<Op02WithProcessedDataAndRefs> arg2)
/* 1596:     */       {
/* 1597:1606 */         if (arg1.getTargets().isEmpty()) {
/* 1598:1607 */           this.val$endPoints.add(arg1);
/* 1599:     */         } else {
/* 1600:1609 */           arg2.enqueue(arg1.getTargets());
/* 1601:     */         }
/* 1602:     */       }
/* 1603:1612 */     });
/* 1604:1613 */     gv.process();
/* 1605:     */     
/* 1606:     */ 
/* 1607:     */ 
/* 1608:1617 */     Set<Op02WithProcessedDataAndRefs> seenOnce = SetFactory.newSet();
/* 1609:1618 */     Set<Op02WithProcessedDataAndRefs> toProcessContent = SetFactory.newSet();
/* 1610:1619 */     LinkedList<Op02WithProcessedDataAndRefs> toProcess = ListFactory.newLinkedList();
/* 1611:     */     
/* 1612:1621 */     toProcess.addAll(endPoints);
/* 1613:1622 */     toProcessContent.addAll(endPoints);
/* 1614:     */     
/* 1615:1624 */     SSAIdentifiers<Slot> initial = new SSAIdentifiers(((Op02WithProcessedDataAndRefs)op2list.get(0)).ssaIdentifiers);
/* 1616:     */     
/* 1617:1626 */     List<Op02WithProcessedDataAndRefs> storeWithoutRead = ListFactory.newList();
/* 1618:1627 */     while (!toProcess.isEmpty())
/* 1619:     */     {
/* 1620:1628 */       Op02WithProcessedDataAndRefs node = (Op02WithProcessedDataAndRefs)toProcess.removeFirst();
/* 1621:1629 */       toProcessContent.remove(node);
/* 1622:     */       
/* 1623:1631 */       Pair<JavaTypeInstance, Integer> retrieved = node.getRetrieveType();
/* 1624:1632 */       Pair<JavaTypeInstance, Integer> stored = node.getStorageType();
/* 1625:     */       
/* 1626:     */ 
/* 1627:     */ 
/* 1628:     */ 
/* 1629:1637 */       SSAIdentifiers<Slot> ssaIdents = node.ssaIdentifiers;
/* 1630:     */       
/* 1631:1639 */       Map<Slot, SSAIdent> idents = ssaIdents.getKnownIdentifiersOnExit();
/* 1632:1640 */       Iterator<Map.Entry<Slot, SSAIdent>> iterator = idents.entrySet().iterator();
/* 1633:1641 */       while (iterator.hasNext())
/* 1634:     */       {
/* 1635:1642 */         Map.Entry<Slot, SSAIdent> entry = (Map.Entry)iterator.next();
/* 1636:1643 */         Slot slot = (Slot)entry.getKey();
/* 1637:1644 */         SSAIdent thisIdent = (SSAIdent)entry.getValue();
/* 1638:     */         
/* 1639:     */ 
/* 1640:     */ 
/* 1641:     */ 
/* 1642:1649 */         boolean used = false;
/* 1643:1650 */         if ((retrieved != null) && (((Integer)retrieved.getSecond()).intValue() == slot.getIdx())) {
/* 1644:1651 */           used = true;
/* 1645:     */         }
/* 1646:1653 */         if (!used) {
/* 1647:1654 */           for (Op02WithProcessedDataAndRefs target : node.targets) {
/* 1648:1655 */             if (target.ssaIdentifiers.getSSAIdentOnEntry(slot) != null)
/* 1649:     */             {
/* 1650:1656 */               used = true;
/* 1651:1657 */               break;
/* 1652:     */             }
/* 1653:     */           }
/* 1654:     */         }
/* 1655:1666 */         if ((!used) && 
/* 1656:1667 */           (stored != null)) {
/* 1657:1671 */           for (Op02WithProcessedDataAndRefs source : node.sources)
/* 1658:     */           {
/* 1659:1672 */             SSAIdent sourceIdent = source.ssaIdentifiers.getSSAIdentOnExit(slot);
/* 1660:1673 */             if ((sourceIdent != null) && (thisIdent.isSuperSet(sourceIdent)))
/* 1661:     */             {
/* 1662:1674 */               used = true;
/* 1663:1675 */               break;
/* 1664:     */             }
/* 1665:     */           }
/* 1666:     */         }
/* 1667:1681 */         if (!used)
/* 1668:     */         {
/* 1669:1682 */           for (Op02WithProcessedDataAndRefs source : node.sources) {
/* 1670:1683 */             if (!toProcessContent.contains(source))
/* 1671:     */             {
/* 1672:1684 */               toProcessContent.add(source);
/* 1673:1685 */               toProcess.add(source);
/* 1674:1686 */               seenOnce.add(source);
/* 1675:     */             }
/* 1676:     */           }
/* 1677:1689 */           if ((stored != null) && (((Integer)stored.getSecond()).intValue() == slot.getIdx())) {
/* 1678:1690 */             storeWithoutRead.add(node);
/* 1679:     */           }
/* 1680:1692 */           iterator.remove();
/* 1681:1693 */           ssaIdents.removeEntryIdent(slot);
/* 1682:     */         }
/* 1683:     */         else
/* 1684:     */         {
/* 1685:1698 */           for (Op02WithProcessedDataAndRefs source : node.sources) {
/* 1686:1699 */             if ((!seenOnce.contains(source)) && 
/* 1687:1700 */               (!toProcessContent.contains(source)))
/* 1688:     */             {
/* 1689:1701 */               toProcessContent.add(source);
/* 1690:1702 */               toProcess.add(source);
/* 1691:1703 */               seenOnce.add(source);
/* 1692:     */             }
/* 1693:     */           }
/* 1694:     */         }
/* 1695:     */       }
/* 1696:     */     }
/* 1697:1711 */     for (Op02WithProcessedDataAndRefs store : storeWithoutRead)
/* 1698:     */     {
/* 1699:1712 */       Pair<JavaTypeInstance, Integer> storage = store.getStorageType();
/* 1700:1713 */       Slot slot = new Slot((JavaTypeInstance)storage.getFirst(), ((Integer)storage.getSecond()).intValue());
/* 1701:1714 */       SSAIdent ident = ssaIdentifierFactory.getIdent(slot);
/* 1702:1715 */       store.ssaIdentifiers.setKnownIdentifierOnExit(slot, ident);
/* 1703:     */     }
/* 1704:1717 */     ((Op02WithProcessedDataAndRefs)op2list.get(0)).ssaIdentifiers.mergeWith(initial);
/* 1705:     */   }
/* 1706:     */   
/* 1707:     */   public static void discoverStorageLiveness(Method method, DecompilerComments comments, List<Op02WithProcessedDataAndRefs> op2list, BytecodeMeta bytecodeMeta, Options options)
/* 1708:     */   {
/* 1709:1721 */     SSAIdentifierFactory<Slot> ssaIdentifierFactory = new SSAIdentifierFactory(new UnaryFunction()
/* 1710:     */     {
/* 1711:     */       public Object invoke(Slot arg)
/* 1712:     */       {
/* 1713:1724 */         return arg.getJavaTypeInstance().getStackType();
/* 1714:     */       }
/* 1715:1727 */     });
/* 1716:1728 */     assignSSAIdentifiers(ssaIdentifierFactory, method, comments, op2list, bytecodeMeta, options);
/* 1717:     */     
/* 1718:1730 */     removeUnusedSSAIdentifiers(ssaIdentifierFactory, method, op2list);
/* 1719:     */     
/* 1720:     */ 
/* 1721:     */ 
/* 1722:     */ 
/* 1723:     */ 
/* 1724:     */ 
/* 1725:1737 */     Map<Slot, Map<SSAIdent, Set<SSAIdent>>> identChain = MapFactory.newLinkedLazyMap(new UnaryFunction()
/* 1726:     */     {
/* 1727:     */       public Map<SSAIdent, Set<SSAIdent>> invoke(Slot arg)
/* 1728:     */       {
/* 1729:1741 */         MapFactory.newLinkedLazyMap(new UnaryFunction()
/* 1730:     */         {
/* 1731:     */           public Set<SSAIdent> invoke(SSAIdent arg)
/* 1732:     */           {
/* 1733:1744 */             return SetFactory.newOrderedSet();
/* 1734:     */           }
/* 1735:     */         });
/* 1736:     */       }
/* 1737:1750 */     });
/* 1738:1751 */     Map<Slot, Set<SSAIdent>> poisoned = MapFactory.newLazyMap(new UnaryFunction()
/* 1739:     */     {
/* 1740:     */       public Set<SSAIdent> invoke(Slot arg)
/* 1741:     */       {
/* 1742:1755 */         return SetFactory.newSet();
/* 1743:     */       }
/* 1744:1759 */     });
/* 1745:1760 */     final Set<Integer> livenessClashes = bytecodeMeta.getLivenessClashes();
/* 1746:1762 */     for (Iterator i$ = op2list.iterator(); i$.hasNext();)
/* 1747:     */     {
/* 1748:1762 */       op = (Op02WithProcessedDataAndRefs)i$.next();
/* 1749:1763 */       SSAIdentifiers<Slot> identifiers = op.ssaIdentifiers;
/* 1750:1765 */       if (op.hasCatchParent)
/* 1751:     */       {
/* 1752:1766 */         Set<Slot> fixedHereSet = identifiers.getFixedHere();
/* 1753:1767 */         if (!fixedHereSet.isEmpty()) {
/* 1754:1768 */           for (Slot fixedHere : fixedHereSet)
/* 1755:     */           {
/* 1756:1769 */             SSAIdent finalIdent = identifiers.getSSAIdentOnExit(fixedHere);
/* 1757:     */             
/* 1758:1771 */             ((Set)poisoned.get(fixedHere)).add(finalIdent);
/* 1759:     */           }
/* 1760:     */         }
/* 1761:     */       }
/* 1762:1776 */       Map<Slot, SSAIdent> identMap = identifiers.getKnownIdentifiersOnExit();
/* 1763:1777 */       for (Map.Entry<Slot, SSAIdent> entry : identMap.entrySet())
/* 1764:     */       {
/* 1765:1778 */         thisSlot = (Slot)entry.getKey();
/* 1766:     */         
/* 1767:1780 */         thisIdents = (SSAIdent)entry.getValue();
/* 1768:1781 */         Map<SSAIdent, Set<SSAIdent>> map = (Map)identChain.get(thisSlot);
/* 1769:     */         
/* 1770:     */ 
/* 1771:1784 */         thisNextSet = (Set)map.get(thisIdents);
/* 1772:1786 */         for (Op02WithProcessedDataAndRefs tgt : op.getTargets())
/* 1773:     */         {
/* 1774:1787 */           SSAIdent nextIdents = tgt.ssaIdentifiers.getSSAIdentOnExit(thisSlot);
/* 1775:1788 */           if ((nextIdents != null) && (nextIdents.isSuperSet(thisIdents))) {
/* 1776:1789 */             thisNextSet.add(nextIdents);
/* 1777:     */           }
/* 1778:     */         }
/* 1779:     */       }
/* 1780:     */     }
/* 1781:     */     Op02WithProcessedDataAndRefs op;
/* 1782:     */     Slot thisSlot;
/* 1783:     */     SSAIdent thisIdents;
/* 1784:     */     Set<SSAIdent> thisNextSet;
/* 1785:1795 */     final Map<Pair<Slot, SSAIdent>, Ident> combinedMap = MapFactory.newLinkedMap();
/* 1786:     */     
/* 1787:1797 */     IdentFactory identFactory = new IdentFactory(null);
/* 1788:1798 */     for (Map.Entry<Slot, Set<SSAIdent>> entry : poisoned.entrySet())
/* 1789:     */     {
/* 1790:1799 */       Slot slot = (Slot)entry.getKey();
/* 1791:1800 */       map = (Map)identChain.get(slot);
/* 1792:1801 */       for (SSAIdent key : (Set)entry.getValue()) {
/* 1793:1802 */         ((Set)map.get(key)).clear();
/* 1794:     */       }
/* 1795:     */     }
/* 1796:     */     Map<SSAIdent, Set<SSAIdent>> map;
/* 1797:1806 */     for (Map.Entry<Slot, Map<SSAIdent, Set<SSAIdent>>> entry : identChain.entrySet())
/* 1798:     */     {
/* 1799:1810 */       slot = (Slot)entry.getKey();
/* 1800:     */       
/* 1801:     */ 
/* 1802:     */ 
/* 1803:     */ 
/* 1804:     */ 
/* 1805:     */ 
/* 1806:     */ 
/* 1807:1818 */       downMap = (Map)entry.getValue();
/* 1808:1819 */       upMap = createReverseMap(downMap);
/* 1809:1820 */       Set<SSAIdent> keys = SetFactory.newOrderedSet();
/* 1810:1821 */       keys.addAll(downMap.keySet());
/* 1811:1822 */       keys.addAll(upMap.keySet());
/* 1812:1826 */       for (SSAIdent key : keys)
/* 1813:     */       {
/* 1814:1827 */         final Pair<Slot, SSAIdent> slotkey = Pair.make(slot, key);
/* 1815:1828 */         if (!combinedMap.containsKey(slotkey))
/* 1816:     */         {
/* 1817:1829 */           final Ident thisIdent = identFactory.getNextIdent(slot.getIdx());
/* 1818:1830 */           GraphVisitor<SSAIdent> gv = new GraphVisitorDFS(key, new BinaryProcedure()
/* 1819:     */           {
/* 1820:     */             public void call(SSAIdent arg1, GraphVisitor<SSAIdent> arg2)
/* 1821:     */             {
/* 1822:1833 */               Pair<Slot, SSAIdent> innerslotkey = Pair.make(this.val$slot, arg1);
/* 1823:1835 */               if ((livenessClashes.contains(Integer.valueOf(this.val$slot.getIdx()))) && 
/* 1824:1836 */                 (!innerslotkey.equals(slotkey)))
/* 1825:     */               {
/* 1826:1837 */                 StackType s1 = ((Slot)innerslotkey.getFirst()).getJavaTypeInstance().getStackType();
/* 1827:1838 */                 StackType s2 = ((Slot)slotkey.getFirst()).getJavaTypeInstance().getStackType();
/* 1828:1839 */                 if ((s1 != s2) || (!s1.isClosed())) {
/* 1829:1840 */                   return;
/* 1830:     */                 }
/* 1831:     */               }
/* 1832:1844 */               if (combinedMap.containsKey(innerslotkey)) {
/* 1833:1844 */                 return;
/* 1834:     */               }
/* 1835:1845 */               combinedMap.put(innerslotkey, thisIdent);
/* 1836:1846 */               arg2.enqueue((Collection)downMap.get(arg1));
/* 1837:1847 */               arg2.enqueue((Collection)upMap.get(arg1));
/* 1838:     */             }
/* 1839:1849 */           });
/* 1840:1850 */           gv.process();
/* 1841:     */         }
/* 1842:     */       }
/* 1843:     */     }
/* 1844:     */     Slot slot;
/* 1845:     */     final Map<SSAIdent, Set<SSAIdent>> downMap;
/* 1846:     */     final Map<SSAIdent, Set<SSAIdent>> upMap;
/* 1847:1857 */     for (Op02WithProcessedDataAndRefs op2 : op2list) {
/* 1848:1858 */       op2.mapSSASlots(combinedMap);
/* 1849:     */     }
/* 1850:1861 */     method.getMethodPrototype().computeParameters(method.getConstructorFlag(), ((Op02WithProcessedDataAndRefs)op2list.get(0)).localVariablesBySlot);
/* 1851:     */   }
/* 1852:     */   
/* 1853:     */   private void mapSSASlots(Map<Pair<Slot, SSAIdent>, Ident> identmap)
/* 1854:     */   {
/* 1855:1865 */     Map<Slot, SSAIdent> knownIdents = this.ssaIdentifiers.getKnownIdentifiersOnExit();
/* 1856:1866 */     for (Map.Entry<Slot, SSAIdent> entry : knownIdents.entrySet())
/* 1857:     */     {
/* 1858:1867 */       Ident ident = (Ident)identmap.get(Pair.make(entry.getKey(), entry.getValue()));
/* 1859:1868 */       if (ident == null) {
/* 1860:1869 */         throw new IllegalStateException("Null ident");
/* 1861:     */       }
/* 1862:1871 */       this.localVariablesBySlot.put(Integer.valueOf(((Slot)entry.getKey()).getIdx()), ident);
/* 1863:     */     }
/* 1864:     */   }
/* 1865:     */   
/* 1866:     */   private static class IdentFactory
/* 1867:     */   {
/* 1868:1876 */     int nextIdx = 0;
/* 1869:     */     
/* 1870:     */     public Ident getNextIdent(int slot)
/* 1871:     */     {
/* 1872:1879 */       return new Ident(slot, this.nextIdx++);
/* 1873:     */     }
/* 1874:     */   }
/* 1875:     */   
/* 1876:     */   private static Map<SSAIdent, Set<SSAIdent>> createReverseMap(Map<SSAIdent, Set<SSAIdent>> downMap)
/* 1877:     */   {
/* 1878:1884 */     Map<SSAIdent, Set<SSAIdent>> res = MapFactory.newLinkedLazyMap(new UnaryFunction()
/* 1879:     */     {
/* 1880:     */       public Set<SSAIdent> invoke(SSAIdent arg)
/* 1881:     */       {
/* 1882:1887 */         return SetFactory.newOrderedSet();
/* 1883:     */       }
/* 1884:     */     });
/* 1885:1890 */     for (Map.Entry<SSAIdent, Set<SSAIdent>> entry : downMap.entrySet())
/* 1886:     */     {
/* 1887:1891 */       revValue = (SSAIdent)entry.getKey();
/* 1888:1892 */       Set<SSAIdent> revKeys = (Set)entry.getValue();
/* 1889:1893 */       for (SSAIdent revKey : revKeys) {
/* 1890:1894 */         ((Set)res.get(revKey)).add(revValue);
/* 1891:     */       }
/* 1892:     */     }
/* 1893:     */     SSAIdent revValue;
/* 1894:1897 */     return res;
/* 1895:     */   }
/* 1896:     */   
/* 1897:     */   public static List<Op03SimpleStatement> convertToOp03List(List<Op02WithProcessedDataAndRefs> op2list, Method method, final VariableFactory variableFactory, final BlockIdentifierFactory blockIdentifierFactory, final DCCommonState dcCommonState, final TypeHintRecovery typeHintRecovery)
/* 1898:     */   {
/* 1899:1909 */     final List<Op03SimpleStatement> op03SimpleParseNodesTmp = ListFactory.newList();
/* 1900:     */     
/* 1901:     */ 
/* 1902:     */ 
/* 1903:1913 */     final GraphConversionHelper<Op02WithProcessedDataAndRefs, Op03SimpleStatement> conversionHelper = new GraphConversionHelper();
/* 1904:     */     
/* 1905:     */ 
/* 1906:     */ 
/* 1907:     */ 
/* 1908:1918 */     GraphVisitor<Op02WithProcessedDataAndRefs> o2Converter = new GraphVisitorFIFO(op2list.get(0), new BinaryProcedure()
/* 1909:     */     {
/* 1910:     */       public void call(Op02WithProcessedDataAndRefs arg1, GraphVisitor<Op02WithProcessedDataAndRefs> arg2)
/* 1911:     */       {
/* 1912:1922 */         Op03SimpleStatement res = new Op03SimpleStatement(arg1, arg1.createStatement(this.val$method, variableFactory, blockIdentifierFactory, dcCommonState, typeHintRecovery));
/* 1913:1923 */         conversionHelper.registerOriginalAndNew(arg1, res);
/* 1914:1924 */         op03SimpleParseNodesTmp.add(res);
/* 1915:1925 */         for (Op02WithProcessedDataAndRefs target : arg1.getTargets()) {
/* 1916:1926 */           arg2.enqueue(target);
/* 1917:     */         }
/* 1918:     */       }
/* 1919:1930 */     });
/* 1920:1931 */     o2Converter.process();
/* 1921:1932 */     conversionHelper.patchUpRelations();
/* 1922:     */     
/* 1923:1934 */     return op03SimpleParseNodesTmp;
/* 1924:     */   }
/* 1925:     */   
/* 1926:     */   private static class ExceptionTempStatement
/* 1927:     */     implements Comparable<ExceptionTempStatement>
/* 1928:     */   {
/* 1929:     */     private final ExceptionGroup triggeringGroup;
/* 1930:     */     private final Op02WithProcessedDataAndRefs op;
/* 1931:     */     private final boolean isTry;
/* 1932:     */     
/* 1933:     */     private ExceptionTempStatement(ExceptionGroup triggeringGroup, Op02WithProcessedDataAndRefs op)
/* 1934:     */     {
/* 1935:1943 */       this.triggeringGroup = triggeringGroup;
/* 1936:1944 */       this.op = op;
/* 1937:1945 */       this.isTry = (op.instr == JVMInstr.FAKE_TRY);
/* 1938:     */     }
/* 1939:     */     
/* 1940:     */     public ExceptionGroup getTriggeringGroup()
/* 1941:     */     {
/* 1942:1949 */       return this.triggeringGroup;
/* 1943:     */     }
/* 1944:     */     
/* 1945:     */     public Op02WithProcessedDataAndRefs getOp()
/* 1946:     */     {
/* 1947:1953 */       return this.op;
/* 1948:     */     }
/* 1949:     */     
/* 1950:     */     public boolean isTry()
/* 1951:     */     {
/* 1952:1957 */       return this.isTry;
/* 1953:     */     }
/* 1954:     */     
/* 1955:     */     public int compareTo(ExceptionTempStatement other)
/* 1956:     */     {
/* 1957:1965 */       if (other == this) {
/* 1958:1965 */         return 0;
/* 1959:     */       }
/* 1960:1966 */       int startCompare = this.triggeringGroup.getBytecodeIndexFrom() - other.triggeringGroup.getBytecodeIndexFrom();
/* 1961:1967 */       if (startCompare != 0) {
/* 1962:1967 */         return startCompare;
/* 1963:     */       }
/* 1964:1968 */       int endCompare = this.triggeringGroup.getByteCodeIndexTo() - other.triggeringGroup.getByteCodeIndexTo();
/* 1965:1969 */       return 0 - endCompare;
/* 1966:     */     }
/* 1967:     */     
/* 1968:     */     public String toString()
/* 1969:     */     {
/* 1970:1975 */       return this.op.toString();
/* 1971:     */     }
/* 1972:     */   }
/* 1973:     */   
/* 1974:     */   private static Op02WithProcessedDataAndRefs adjustOrdering(Map<InstrIndex, List<ExceptionTempStatement>> insertions, Op02WithProcessedDataAndRefs infrontOf, ExceptionGroup exceptionGroup, Op02WithProcessedDataAndRefs newNode)
/* 1975:     */   {
/* 1976:1988 */     InstrIndex idxInfrontOf = infrontOf.getIndex();
/* 1977:1989 */     List<ExceptionTempStatement> collides = (List)insertions.get(idxInfrontOf);
/* 1978:1990 */     ExceptionTempStatement exceptionTempStatement = new ExceptionTempStatement(exceptionGroup, newNode, null);
/* 1979:1991 */     if (collides.isEmpty())
/* 1980:     */     {
/* 1981:1992 */       collides.add(exceptionTempStatement);
/* 1982:1993 */       return infrontOf;
/* 1983:     */     }
/* 1984:1996 */     logger.finer("Adding " + newNode + " ident " + exceptionGroup.getTryBlockIdentifier());
/* 1985:1997 */     logger.finer("Already have " + collides);
/* 1986:     */     
/* 1987:     */ 
/* 1988:     */ 
/* 1989:2001 */     int insertionPos = Collections.binarySearch(collides, exceptionTempStatement);
/* 1990:2002 */     if (insertionPos >= 0) {
/* 1991:2004 */       insertionPos++;
/* 1992:     */     } else {
/* 1993:2006 */       insertionPos = -(insertionPos + 1);
/* 1994:     */     }
/* 1995:2008 */     if (insertionPos == 0)
/* 1996:     */     {
/* 1997:2009 */       collides.add(0, exceptionTempStatement);
/* 1998:     */       
/* 1999:2011 */       throw new ConfusedCFRException("EEk.");
/* 2000:     */     }
/* 2001:2015 */     logger.finer("Insertion position = " + insertionPos);
/* 2002:     */     Op02WithProcessedDataAndRefs afterThis;
/* 2003:     */     Op02WithProcessedDataAndRefs afterThis;
/* 2004:2017 */     if (insertionPos == collides.size())
/* 2005:     */     {
/* 2006:2018 */       collides.add(exceptionTempStatement);
/* 2007:2019 */       afterThis = infrontOf;
/* 2008:     */     }
/* 2009:     */     else
/* 2010:     */     {
/* 2011:2021 */       afterThis = ((ExceptionTempStatement)collides.get(insertionPos)).getOp();
/* 2012:2022 */       collides.add(insertionPos, exceptionTempStatement);
/* 2013:     */     }
/* 2014:2025 */     for (ExceptionTempStatement ets : collides) {
/* 2015:2027 */       ets.getOp().setIndex(infrontOf.getIndex().justBefore());
/* 2016:     */     }
/* 2017:2029 */     return afterThis;
/* 2018:     */   }
/* 2019:     */   
/* 2020:     */   private static void tidyMultipleInsertionIdentifiers(Collection<List<ExceptionTempStatement>> etsList)
/* 2021:     */   {
/* 2022:2033 */     for (List<ExceptionTempStatement> ets : etsList) {
/* 2023:2037 */       if (ets.size() > 1) {
/* 2024:2039 */         for (int idx = 0; idx < ets.size(); idx++)
/* 2025:     */         {
/* 2026:2040 */           ExceptionTempStatement et = (ExceptionTempStatement)ets.get(idx);
/* 2027:2041 */           if (et.isTry())
/* 2028:     */           {
/* 2029:2042 */             BlockIdentifier tryGroup = et.triggeringGroup.getTryBlockIdentifier();
/* 2030:2043 */             logger.finer("Removing try group identifier " + tryGroup + " idx " + idx);
/* 2031:2044 */             for (int idx2 = 0; idx2 < idx; idx2++)
/* 2032:     */             {
/* 2033:2045 */               logger.finest("" + ((ExceptionTempStatement)ets.get(idx2)).getOp());
/* 2034:2046 */               logger.finest("" + ((ExceptionTempStatement)ets.get(idx2)).getOp().containedInTheseBlocks + " -->");
/* 2035:2047 */               ((ExceptionTempStatement)ets.get(idx2)).getOp().containedInTheseBlocks.remove(tryGroup);
/* 2036:2048 */               logger.finest("" + ((ExceptionTempStatement)ets.get(idx2)).getOp().containedInTheseBlocks);
/* 2037:     */             }
/* 2038:     */           }
/* 2039:     */         }
/* 2040:     */       }
/* 2041:     */     }
/* 2042:     */   }
/* 2043:     */   
/* 2044:     */   private static int getLastIndex(Map<Integer, Integer> lutByOffset, int op2count, long codeLength, int offset)
/* 2045:     */   {
/* 2046:2056 */     Integer iinclusiveLastIndex = (Integer)lutByOffset.get(Integer.valueOf(offset));
/* 2047:2057 */     if (iinclusiveLastIndex == null) {
/* 2048:2058 */       if (offset == codeLength) {
/* 2049:2059 */         iinclusiveLastIndex = Integer.valueOf(op2count - 1);
/* 2050:     */       } else {
/* 2051:2061 */         throw new ConfusedCFRException("Last index of " + offset + " is not a valid entry into the code block");
/* 2052:     */       }
/* 2053:     */     }
/* 2054:2064 */     return iinclusiveLastIndex.intValue();
/* 2055:     */   }
/* 2056:     */   
/* 2057:     */   private static boolean nextTarget(Op02WithProcessedDataAndRefs op, int idx, List<Op02WithProcessedDataAndRefs> op2list)
/* 2058:     */   {
/* 2059:2104 */     if (op.getTargets().size() != 1) {
/* 2060:2104 */       return false;
/* 2061:     */     }
/* 2062:2105 */     Op02WithProcessedDataAndRefs target = (Op02WithProcessedDataAndRefs)op.getTargets().get(0);
/* 2063:2106 */     if (idx + 1 >= op2list.size()) {
/* 2064:2106 */       return false;
/* 2065:     */     }
/* 2066:2107 */     if (target != op2list.get(idx + 1)) {
/* 2067:2107 */       return false;
/* 2068:     */     }
/* 2069:2108 */     return true;
/* 2070:     */   }
/* 2071:     */   
/* 2072:     */   public static List<Op02WithProcessedDataAndRefs> insertExceptionBlocks(List<Op02WithProcessedDataAndRefs> op2list, ExceptionAggregator exceptions, Map<Integer, Integer> lutByOffset, ConstantPool cp, long codeLength, DCCommonState dcCommonState, Options options)
/* 2073:     */   {
/* 2074:2147 */     int originalInstrCount = op2list.size();
/* 2075:2149 */     if (exceptions.getExceptionsGroups().isEmpty()) {
/* 2076:2149 */       return op2list;
/* 2077:     */     }
/* 2078:2151 */     Map<InstrIndex, List<ExceptionTempStatement>> insertions = MapFactory.newLazyMap(new UnaryFunction()
/* 2079:     */     {
/* 2080:     */       public List<Op02WithProcessedDataAndRefs.ExceptionTempStatement> invoke(InstrIndex ignore)
/* 2081:     */       {
/* 2082:2155 */         return ListFactory.newList();
/* 2083:     */       }
/* 2084:     */     });
/* 2085:2161 */     for (ExceptionGroup exceptionGroup : exceptions.getExceptionsGroups())
/* 2086:     */     {
/* 2087:2162 */       BlockIdentifier tryBlockIdentifier = exceptionGroup.getTryBlockIdentifier();
/* 2088:2163 */       int originalIndex = ((Integer)lutByOffset.get(Integer.valueOf(exceptionGroup.getBytecodeIndexFrom()))).intValue();
/* 2089:2164 */       int exclusiveLastIndex = getLastIndex(lutByOffset, originalInstrCount, codeLength, exceptionGroup.getByteCodeIndexTo());
/* 2090:2167 */       for (int x = originalIndex; x < exclusiveLastIndex; x++) {
/* 2091:2168 */         ((Op02WithProcessedDataAndRefs)op2list.get(x)).containedInTheseBlocks.add(tryBlockIdentifier);
/* 2092:     */       }
/* 2093:     */     }
/* 2094:2176 */     for (ExceptionGroup exceptionGroup : exceptions.getExceptionsGroups())
/* 2095:     */     {
/* 2096:2178 */       List<ExceptionGroup.Entry> rawes = exceptionGroup.getEntries();
/* 2097:2179 */       int originalIndex = ((Integer)lutByOffset.get(Integer.valueOf(exceptionGroup.getBytecodeIndexFrom()))).intValue();
/* 2098:2180 */       Op02WithProcessedDataAndRefs startInstruction = (Op02WithProcessedDataAndRefs)op2list.get(originalIndex);
/* 2099:     */       
/* 2100:2182 */       int inclusiveLastIndex = getLastIndex(lutByOffset, originalInstrCount, codeLength, exceptionGroup.getByteCodeIndexTo());
/* 2101:2183 */       Op02WithProcessedDataAndRefs lastTryInstruction = (Op02WithProcessedDataAndRefs)op2list.get(inclusiveLastIndex);
/* 2102:     */       
/* 2103:     */ 
/* 2104:2186 */       List<Pair<Op02WithProcessedDataAndRefs, ExceptionGroup.Entry>> handlerTargets = ListFactory.newList();
/* 2105:2187 */       for (ExceptionGroup.Entry exceptionEntry : rawes)
/* 2106:     */       {
/* 2107:2188 */         short handler = exceptionEntry.getBytecodeIndexHandler();
/* 2108:2189 */         int handlerIndex = ((Integer)lutByOffset.get(Integer.valueOf(handler))).intValue();
/* 2109:2190 */         if (handlerIndex <= originalIndex) {
/* 2110:2195 */           if (!((Boolean)options.getOption(OptionsImpl.LENIENT)).booleanValue()) {
/* 2111:2196 */             throw new ConfusedCFRException("Back jump on a try block " + exceptionEntry);
/* 2112:     */           }
/* 2113:     */         }
/* 2114:2199 */         Op02WithProcessedDataAndRefs handerTarget = (Op02WithProcessedDataAndRefs)op2list.get(handlerIndex);
/* 2115:2200 */         handlerTargets.add(Pair.make(handerTarget, exceptionEntry));
/* 2116:     */       }
/* 2117:2205 */       Op02WithProcessedDataAndRefs tryOp = new Op02WithProcessedDataAndRefs(JVMInstr.FAKE_TRY, null, startInstruction.getIndex().justBefore(), cp, null, -1);
/* 2118:     */       
/* 2119:     */ 
/* 2120:2208 */       startInstruction = adjustOrdering(insertions, startInstruction, exceptionGroup, tryOp);
/* 2121:2209 */       tryOp.containedInTheseBlocks.addAll(startInstruction.containedInTheseBlocks);
/* 2122:2210 */       tryOp.containedInTheseBlocks.remove(exceptionGroup.getTryBlockIdentifier());
/* 2123:2211 */       tryOp.exceptionGroups.add(exceptionGroup);
/* 2124:     */       
/* 2125:     */ 
/* 2126:     */ 
/* 2127:     */ 
/* 2128:     */ 
/* 2129:     */ 
/* 2130:2218 */       List<Op02WithProcessedDataAndRefs> removeThese = ListFactory.newList();
/* 2131:2219 */       for (Op02WithProcessedDataAndRefs source : startInstruction.getSources()) {
/* 2132:2223 */         if ((!startInstruction.getIndex().isBackJumpFrom(source.getIndex())) || (lastTryInstruction.getIndex().isBackJumpFrom(source.getIndex())))
/* 2133:     */         {
/* 2134:2227 */           source.replaceTarget(startInstruction, tryOp);
/* 2135:2228 */           removeThese.add(source);
/* 2136:2229 */           tryOp.addSource(source);
/* 2137:     */         }
/* 2138:     */       }
/* 2139:2232 */       for (Op02WithProcessedDataAndRefs remove : removeThese) {
/* 2140:2233 */         startInstruction.removeSource(remove);
/* 2141:     */       }
/* 2142:2241 */       for (Pair<Op02WithProcessedDataAndRefs, ExceptionGroup.Entry> catchTargets : handlerTargets)
/* 2143:     */       {
/* 2144:2242 */         Op02WithProcessedDataAndRefs tryTarget = (Op02WithProcessedDataAndRefs)catchTargets.getFirst();
/* 2145:     */         
/* 2146:     */ 
/* 2147:     */ 
/* 2148:2246 */         List<Op02WithProcessedDataAndRefs> tryTargetSources = tryTarget.getSources();
/* 2149:2247 */         Op02WithProcessedDataAndRefs preCatchOp = null;
/* 2150:     */         
/* 2151:2249 */         boolean addFakeCatch = false;
/* 2152:2251 */         if (tryTargetSources.isEmpty())
/* 2153:     */         {
/* 2154:2252 */           addFakeCatch = true;
/* 2155:     */         }
/* 2156:     */         else
/* 2157:     */         {
/* 2158:2262 */           for (Op02WithProcessedDataAndRefs source : tryTargetSources) {
/* 2159:2263 */             if (source.getInstr() == JVMInstr.FAKE_CATCH) {
/* 2160:2264 */               preCatchOp = source;
/* 2161:2266 */             } else if (!((Boolean)options.getOption(OptionsImpl.LENIENT)).booleanValue()) {
/* 2162:2267 */               throw new ConfusedCFRException("non catch before exception catch block");
/* 2163:     */             }
/* 2164:     */           }
/* 2165:2271 */           if (preCatchOp == null) {
/* 2166:2272 */             addFakeCatch = true;
/* 2167:     */           }
/* 2168:     */         }
/* 2169:2276 */         if (addFakeCatch)
/* 2170:     */         {
/* 2171:2277 */           ExceptionGroup.Entry entry = (ExceptionGroup.Entry)catchTargets.getSecond();
/* 2172:2278 */           byte[] data = null;
/* 2173:2279 */           if (entry.isJustThrowable()) {
/* 2174:2280 */             data = new byte[0];
/* 2175:     */           }
/* 2176:2284 */           preCatchOp = new Op02WithProcessedDataAndRefs(JVMInstr.FAKE_CATCH, data, tryTarget.getIndex().justBefore(), cp, null, -1);
/* 2177:2285 */           tryTarget = adjustOrdering(insertions, tryTarget, exceptionGroup, preCatchOp);
/* 2178:2286 */           preCatchOp.containedInTheseBlocks.addAll(tryTarget.getContainedInTheseBlocks());
/* 2179:2287 */           preCatchOp.addTarget(tryTarget);
/* 2180:2288 */           if (JVMInstr.isAStore(tryTarget.getInstr())) {
/* 2181:2288 */             tryTarget.hasCatchParent = true;
/* 2182:     */           }
/* 2183:2289 */           tryTarget.addSource(preCatchOp);
/* 2184:2290 */           op2list.add(preCatchOp);
/* 2185:     */         }
/* 2186:2293 */         if (preCatchOp == null) {
/* 2187:2294 */           throw new IllegalStateException("Bad precatch op state.");
/* 2188:     */         }
/* 2189:2296 */         preCatchOp.addSource(tryOp);
/* 2190:2297 */         tryOp.addTarget(preCatchOp);
/* 2191:2298 */         preCatchOp.catchExceptionGroups.add(catchTargets.getSecond());
/* 2192:     */       }
/* 2193:2300 */       tryOp.targets.add(0, startInstruction);
/* 2194:2301 */       startInstruction.addSource(tryOp);
/* 2195:2302 */       op2list.add(tryOp);
/* 2196:2304 */       if (tryOp.sources.isEmpty()) {
/* 2197:2305 */         x = 1;
/* 2198:     */       }
/* 2199:     */     }
/* 2200:     */     int x;
/* 2201:2315 */     for (ExceptionGroup exceptionGroup : exceptions.getExceptionsGroups())
/* 2202:     */     {
/* 2203:2316 */       BlockIdentifier tryBlockIdentifier = exceptionGroup.getTryBlockIdentifier();
/* 2204:2317 */       int beforeLastIndex = getLastIndex(lutByOffset, originalInstrCount, codeLength, exceptionGroup.getByteCodeIndexTo()) - 1;
/* 2205:     */       
/* 2206:2319 */       Op02WithProcessedDataAndRefs lastStatement = (Op02WithProcessedDataAndRefs)op2list.get(beforeLastIndex);
/* 2207:2320 */       Set<BlockIdentifier> blocks = SetFactory.newSet(lastStatement.containedInTheseBlocks);
/* 2208:2321 */       int x = beforeLastIndex + 1;
/* 2209:2322 */       if ((lastStatement.targets.size() == 1) && (op2list.get(x) == lastStatement.targets.get(0)))
/* 2210:     */       {
/* 2211:2323 */         Op02WithProcessedDataAndRefs next = (Op02WithProcessedDataAndRefs)op2list.get(x);
/* 2212:2324 */         boolean bOk = true;
/* 2213:2325 */         if (next.sources.size() > 1) {
/* 2214:2326 */           for (Op02WithProcessedDataAndRefs source : next.sources)
/* 2215:     */           {
/* 2216:2327 */             Set<BlockIdentifier> blocks2 = SetFactory.newSet(source.containedInTheseBlocks);
/* 2217:2328 */             if (!blocks.equals(blocks2)) {
/* 2218:2328 */               bOk = false;
/* 2219:     */             }
/* 2220:     */           }
/* 2221:     */         }
/* 2222:2332 */         Set<BlockIdentifier> blocksWithoutTry = SetFactory.newSet(blocks);
/* 2223:2333 */         blocksWithoutTry.remove(tryBlockIdentifier);
/* 2224:2334 */         if (bOk) {
/* 2225:2335 */           switch (18.$SwitchMap$org$benf$cfr$reader$bytecode$opcode$JVMInstr[next.instr.ordinal()])
/* 2226:     */           {
/* 2227:     */           case 160: 
/* 2228:     */           case 180: 
/* 2229:     */           case 181: 
/* 2230:     */           case 183: 
/* 2231:     */           case 184: 
/* 2232:     */           case 185: 
/* 2233:     */           case 186: 
/* 2234:     */           case 187: 
/* 2235:2344 */             Set<BlockIdentifier> blocks2 = SetFactory.newSet(next.containedInTheseBlocks);
/* 2236:2345 */             if (blocksWithoutTry.equals(blocks2)) {
/* 2237:2346 */               next.containedInTheseBlocks.add(tryBlockIdentifier);
/* 2238:     */             }
/* 2239:     */             break;
/* 2240:     */           }
/* 2241:     */         }
/* 2242:     */       }
/* 2243:     */     }
/* 2244:2359 */     tidyMultipleInsertionIdentifiers(insertions.values());
/* 2245:2360 */     return op2list;
/* 2246:     */   }
/* 2247:     */   
/* 2248:     */   public List<BlockIdentifier> getContainedInTheseBlocks()
/* 2249:     */   {
/* 2250:2364 */     return this.containedInTheseBlocks;
/* 2251:     */   }
/* 2252:     */   
/* 2253:     */   private static boolean isJSR(Op02WithProcessedDataAndRefs op)
/* 2254:     */   {
/* 2255:2407 */     JVMInstr instr = op.instr;
/* 2256:2408 */     return (instr == JVMInstr.JSR) || (instr == JVMInstr.JSR_W);
/* 2257:     */   }
/* 2258:     */   
/* 2259:     */   private static boolean isRET(Op02WithProcessedDataAndRefs op)
/* 2260:     */   {
/* 2261:2412 */     JVMInstr instr = op.instr;
/* 2262:2413 */     return (instr == JVMInstr.RET) || (instr == JVMInstr.RET_WIDE);
/* 2263:     */   }
/* 2264:     */   
/* 2265:     */   public static boolean processJSR(List<Op02WithProcessedDataAndRefs> ops)
/* 2266:     */   {
/* 2267:2434 */     List<Op02WithProcessedDataAndRefs> jsrInstrs = justJSRs(ops);
/* 2268:2435 */     if (jsrInstrs.isEmpty()) {
/* 2269:2435 */       return false;
/* 2270:     */     }
/* 2271:2436 */     processJSRs(jsrInstrs, ops);
/* 2272:2437 */     return true;
/* 2273:     */   }
/* 2274:     */   
/* 2275:     */   private static List<Op02WithProcessedDataAndRefs> justJSRs(List<Op02WithProcessedDataAndRefs> ops)
/* 2276:     */   {
/* 2277:2441 */     List<Op02WithProcessedDataAndRefs> jsrInstrs = Functional.filter(ops, new Predicate()
/* 2278:     */     {
/* 2279:     */       public boolean test(Op02WithProcessedDataAndRefs in)
/* 2280:     */       {
/* 2281:2444 */         return Op02WithProcessedDataAndRefs.isJSR(in);
/* 2282:     */       }
/* 2283:2446 */     });
/* 2284:2447 */     return jsrInstrs;
/* 2285:     */   }
/* 2286:     */   
/* 2287:     */   private static boolean processJSRs(List<Op02WithProcessedDataAndRefs> jsrs, List<Op02WithProcessedDataAndRefs> ops)
/* 2288:     */   {
/* 2289:2454 */     boolean result = false;
/* 2290:2455 */     for (Op02WithProcessedDataAndRefs jsr : jsrs) {
/* 2291:2457 */       result |= SimulateJSR(jsr, ops);
/* 2292:     */     }
/* 2293:2459 */     if (result) {
/* 2294:2459 */       jsrs = justJSRs(jsrs);
/* 2295:     */     }
/* 2296:2465 */     Map<Op02WithProcessedDataAndRefs, List<Op02WithProcessedDataAndRefs>> targets = Functional.groupToMapBy(jsrs, new UnaryFunction()
/* 2297:     */     {
/* 2298:     */       public Op02WithProcessedDataAndRefs invoke(Op02WithProcessedDataAndRefs arg)
/* 2299:     */       {
/* 2300:2468 */         return (Op02WithProcessedDataAndRefs)arg.getTargets().get(0);
/* 2301:     */       }
/* 2302:2470 */     });
/* 2303:2471 */     Set<Op02WithProcessedDataAndRefs> inlineCandidates = SetFactory.newSet();
/* 2304:2472 */     for (Op02WithProcessedDataAndRefs target : targets.keySet())
/* 2305:     */     {
/* 2306:2473 */       GraphVisitor<Op02WithProcessedDataAndRefs> gv = new GraphVisitorDFS(target.getTargets(), new BinaryProcedure()
/* 2307:     */       {
/* 2308:     */         public void call(Op02WithProcessedDataAndRefs arg1, GraphVisitor<Op02WithProcessedDataAndRefs> arg2)
/* 2309:     */         {
/* 2310:2476 */           if (Op02WithProcessedDataAndRefs.isRET(arg1)) {
/* 2311:2477 */             return;
/* 2312:     */           }
/* 2313:2479 */           if (arg1 == this.val$target)
/* 2314:     */           {
/* 2315:2480 */             arg2.abort();
/* 2316:2481 */             return;
/* 2317:     */           }
/* 2318:2483 */           arg2.enqueue(arg1.getTargets());
/* 2319:     */         }
/* 2320:2485 */       });
/* 2321:2486 */       gv.process();
/* 2322:2487 */       if (!gv.wasAborted())
/* 2323:     */       {
/* 2324:2489 */         Set<Op02WithProcessedDataAndRefs> nodes = SetFactory.newSet(gv.getVisitedNodes());
/* 2325:     */         
/* 2326:     */ 
/* 2327:     */ 
/* 2328:     */ 
/* 2329:     */ 
/* 2330:     */ 
/* 2331:     */ 
/* 2332:2497 */         nodes.add(target);
/* 2333:2499 */         if (!SetUtil.hasIntersection(inlineCandidates, nodes))
/* 2334:     */         {
/* 2335:2503 */           inlineCandidates.addAll(nodes);
/* 2336:     */           
/* 2337:2505 */           inlineJSR(target, nodes, ops);
/* 2338:2506 */           result = true;
/* 2339:     */         }
/* 2340:     */       }
/* 2341:     */     }
/* 2342:2515 */     for (Op02WithProcessedDataAndRefs jsr : jsrs) {
/* 2343:2516 */       if (isJSR(jsr))
/* 2344:     */       {
/* 2345:2517 */         final Op02WithProcessedDataAndRefs target = (Op02WithProcessedDataAndRefs)jsr.targets.get(0);
/* 2346:2518 */         List<Op02WithProcessedDataAndRefs> sources = (List)targets.get(target);
/* 2347:2519 */         if ((sources != null) && (sources.size() <= 1))
/* 2348:     */         {
/* 2349:2522 */           List<Op02WithProcessedDataAndRefs> rets = ListFactory.newList();
/* 2350:2523 */           GraphVisitor<Op02WithProcessedDataAndRefs> gv = new GraphVisitorDFS(target.getTargets(), new BinaryProcedure()
/* 2351:     */           {
/* 2352:     */             public void call(Op02WithProcessedDataAndRefs arg1, GraphVisitor<Op02WithProcessedDataAndRefs> arg2)
/* 2353:     */             {
/* 2354:2526 */               if (Op02WithProcessedDataAndRefs.isRET(arg1))
/* 2355:     */               {
/* 2356:2527 */                 this.val$rets.add(arg1);
/* 2357:2528 */                 return;
/* 2358:     */               }
/* 2359:2530 */               if (arg1 == target) {
/* 2360:2531 */                 return;
/* 2361:     */               }
/* 2362:2533 */               arg2.enqueue(arg1.getTargets());
/* 2363:     */             }
/* 2364:2535 */           });
/* 2365:2536 */           gv.process();
/* 2366:     */           
/* 2367:2538 */           int idx = ops.indexOf(jsr) + 1;
/* 2368:2539 */           if (idx < ops.size())
/* 2369:     */           {
/* 2370:2540 */             Op02WithProcessedDataAndRefs afterJsr = (Op02WithProcessedDataAndRefs)ops.get(idx);
/* 2371:2542 */             for (Op02WithProcessedDataAndRefs ret : rets)
/* 2372:     */             {
/* 2373:2543 */               ret.instr = JVMInstr.GOTO;
/* 2374:2544 */               ret.targets.clear();
/* 2375:2545 */               ret.addTarget(afterJsr);
/* 2376:2546 */               afterJsr.addSource(ret);
/* 2377:     */             }
/* 2378:2548 */             inlineReplaceJSR(jsr, ops);
/* 2379:     */           }
/* 2380:     */         }
/* 2381:     */       }
/* 2382:     */     }
/* 2383:2554 */     for (Op02WithProcessedDataAndRefs jsr : jsrs) {
/* 2384:2555 */       if (isJSR(jsr)) {
/* 2385:2559 */         inlineReplaceJSR(jsr, ops);
/* 2386:     */       }
/* 2387:     */     }
/* 2388:2563 */     return result;
/* 2389:     */   }
/* 2390:     */   
/* 2391:     */   private static boolean SimulateJSR(Op02WithProcessedDataAndRefs start, List<Op02WithProcessedDataAndRefs> ops)
/* 2392:     */   {
/* 2393:2569 */     Op02WithProcessedDataAndRefs currInstr = start;
/* 2394:2570 */     Stack<Op02WithProcessedDataAndRefs> stackJumpLocs = StackFactory.newStack();
/* 2395:2571 */     Map<Integer, Op02WithProcessedDataAndRefs> stackJumpLocLocals = MapFactory.newMap();
/* 2396:2572 */     List<Op02WithProcessedDataAndRefs> processed = ListFactory.newList();
/* 2397:2573 */     Op02WithProcessedDataAndRefs afterThis = null;
/* 2398:     */     do
/* 2399:     */     {
/* 2400:2577 */       switch (currInstr.getInstr())
/* 2401:     */       {
/* 2402:     */       case JSR_W: 
/* 2403:     */       case JSR: 
/* 2404:2580 */         stackJumpLocs.push(currInstr);
/* 2405:2581 */         break;
/* 2406:     */       case GOTO: 
/* 2407:     */       case GOTO_W: 
/* 2408:     */       case NOP: 
/* 2409:     */         break;
/* 2410:     */       case ASTORE_0: 
/* 2411:2587 */         if (stackJumpLocs.empty()) {
/* 2412:2587 */           return false;
/* 2413:     */         }
/* 2414:2588 */         stackJumpLocLocals.put(Integer.valueOf(0), stackJumpLocs.pop());
/* 2415:2589 */         break;
/* 2416:     */       case ASTORE_1: 
/* 2417:2591 */         if (stackJumpLocs.empty()) {
/* 2418:2591 */           return false;
/* 2419:     */         }
/* 2420:2592 */         stackJumpLocLocals.put(Integer.valueOf(1), stackJumpLocs.pop());
/* 2421:2593 */         break;
/* 2422:     */       case ASTORE_2: 
/* 2423:2595 */         if (stackJumpLocs.empty()) {
/* 2424:2595 */           return false;
/* 2425:     */         }
/* 2426:2596 */         stackJumpLocLocals.put(Integer.valueOf(2), stackJumpLocs.pop());
/* 2427:2597 */         break;
/* 2428:     */       case ASTORE_3: 
/* 2429:2599 */         if (stackJumpLocs.empty()) {
/* 2430:2599 */           return false;
/* 2431:     */         }
/* 2432:2600 */         stackJumpLocLocals.put(Integer.valueOf(2), stackJumpLocs.pop());
/* 2433:2601 */         break;
/* 2434:     */       case ASTORE: 
/* 2435:2603 */         if (stackJumpLocs.empty()) {
/* 2436:2603 */           return false;
/* 2437:     */         }
/* 2438:2604 */         stackJumpLocLocals.put(Integer.valueOf(currInstr.getInstrArgU1(0)), stackJumpLocs.pop());
/* 2439:2605 */         break;
/* 2440:     */       case ASTORE_WIDE: 
/* 2441:2607 */         if (stackJumpLocs.empty()) {
/* 2442:2607 */           return false;
/* 2443:     */         }
/* 2444:2608 */         stackJumpLocLocals.put(Integer.valueOf(currInstr.getInstrArgShort(1)), stackJumpLocs.pop());
/* 2445:2609 */         break;
/* 2446:     */       case POP: 
/* 2447:2611 */         if (stackJumpLocs.empty()) {
/* 2448:2611 */           return false;
/* 2449:     */         }
/* 2450:2612 */         stackJumpLocs.pop();
/* 2451:2613 */         break;
/* 2452:     */       case POP2: 
/* 2453:2615 */         if (stackJumpLocs.size() < 2) {
/* 2454:2615 */           return false;
/* 2455:     */         }
/* 2456:2616 */         stackJumpLocs.pop();
/* 2457:2617 */         stackJumpLocs.pop();
/* 2458:2618 */         break;
/* 2459:     */       case DUP: 
/* 2460:2620 */         if (stackJumpLocs.empty()) {
/* 2461:2620 */           return false;
/* 2462:     */         }
/* 2463:2621 */         Op02WithProcessedDataAndRefs tmp = (Op02WithProcessedDataAndRefs)stackJumpLocs.pop();
/* 2464:2622 */         stackJumpLocs.push(tmp);
/* 2465:2623 */         stackJumpLocs.push(tmp);
/* 2466:2624 */         break;
/* 2467:     */       case SWAP: 
/* 2468:2626 */         if (stackJumpLocs.size() < 2) {
/* 2469:2626 */           return false;
/* 2470:     */         }
/* 2471:2628 */         Op02WithProcessedDataAndRefs tmp1 = (Op02WithProcessedDataAndRefs)stackJumpLocs.pop();
/* 2472:2629 */         Op02WithProcessedDataAndRefs tmp2 = (Op02WithProcessedDataAndRefs)stackJumpLocs.pop();
/* 2473:2630 */         stackJumpLocs.push(tmp1);
/* 2474:2631 */         stackJumpLocs.push(tmp2);
/* 2475:     */         
/* 2476:2633 */         break;
/* 2477:     */       case RET: 
/* 2478:     */       case RET_WIDE: 
/* 2479:2636 */         int idx = currInstr.getInstr() == JVMInstr.RET ? currInstr.getInstrArgU1(0) : currInstr.getInstrArgShort(1);
/* 2480:2637 */         afterThis = (Op02WithProcessedDataAndRefs)stackJumpLocLocals.get(Integer.valueOf(idx));
/* 2481:2638 */         if (afterThis == null) {
/* 2482:2638 */           return false;
/* 2483:     */         }
/* 2484:     */         break;
/* 2485:     */       default: 
/* 2486:2642 */         return false;
/* 2487:     */       }
/* 2488:2644 */       processed.add(currInstr);
/* 2489:2645 */       if (afterThis != null) {
/* 2490:     */         break;
/* 2491:     */       }
/* 2492:2646 */       if (currInstr.targets.size() != 1) {
/* 2493:2646 */         return false;
/* 2494:     */       }
/* 2495:2647 */       currInstr = (Op02WithProcessedDataAndRefs)currInstr.targets.get(0);
/* 2496:2648 */     } while (currInstr.sources.size() == 1);
/* 2497:2648 */     return false;
/* 2498:2657 */     if (afterThis == start)
/* 2499:     */     {
/* 2500:2658 */       Op02WithProcessedDataAndRefs[] remaining = (Op02WithProcessedDataAndRefs[])stackJumpLocs.toArray(new Op02WithProcessedDataAndRefs[stackJumpLocs.size()]);
/* 2501:     */       
/* 2502:     */ 
/* 2503:2661 */       int remainIdx = 0;
/* 2504:2662 */       List<Op02WithProcessedDataAndRefs> canGoto = ListFactory.newList();
/* 2505:     */       
/* 2506:2664 */       int x = 1;
/* 2507:2664 */       for (int len = processed.size(); x < len; x++)
/* 2508:     */       {
/* 2509:2665 */         Op02WithProcessedDataAndRefs node = (Op02WithProcessedDataAndRefs)processed.get(x);
/* 2510:2666 */         if ((isJSR(node)) && 
/* 2511:2667 */           (remainIdx < remaining.length) && (node == remaining[remainIdx])) {
/* 2512:2668 */           remainIdx++;
/* 2513:     */         } else {
/* 2514:2672 */           canGoto.add(node);
/* 2515:     */         }
/* 2516:     */       }
/* 2517:2675 */       if (remainIdx != remaining.length) {
/* 2518:2675 */         return false;
/* 2519:     */       }
/* 2520:2676 */       for (Op02WithProcessedDataAndRefs remove : canGoto) {
/* 2521:2677 */         remove.instr = JVMInstr.GOTO;
/* 2522:     */       }
/* 2523:2680 */       int idxStart = ops.indexOf(start);
/* 2524:2681 */       Op02WithProcessedDataAndRefs afterStart = (Op02WithProcessedDataAndRefs)ops.get(idxStart + 1);
/* 2525:2682 */       start.instr = JVMInstr.GOTO;
/* 2526:2683 */       currInstr.instr = JVMInstr.GOTO;
/* 2527:2684 */       currInstr.addTarget(afterStart);
/* 2528:2685 */       afterStart.addSource(currInstr);
/* 2529:     */       
/* 2530:     */ 
/* 2531:     */ 
/* 2532:2689 */       return true;
/* 2533:     */     }
/* 2534:2691 */     return false;
/* 2535:     */   }
/* 2536:     */   
/* 2537:     */   private static void inlineReplaceJSR(Op02WithProcessedDataAndRefs jsrCall, List<Op02WithProcessedDataAndRefs> ops)
/* 2538:     */   {
/* 2539:2695 */     Op02WithProcessedDataAndRefs jsrTarget = (Op02WithProcessedDataAndRefs)jsrCall.getTargets().get(0);
/* 2540:     */     
/* 2541:2697 */     Op02WithProcessedDataAndRefs newGoto = new Op02WithProcessedDataAndRefs(JVMInstr.GOTO, null, jsrCall.getIndex().justAfter(), jsrCall.cp, null, -1);
/* 2542:     */     
/* 2543:     */ 
/* 2544:     */ 
/* 2545:     */ 
/* 2546:     */ 
/* 2547:     */ 
/* 2548:2704 */     jsrTarget.removeSource(jsrCall);
/* 2549:2705 */     jsrCall.removeTarget(jsrTarget);
/* 2550:2706 */     newGoto.addTarget(jsrTarget);
/* 2551:2707 */     newGoto.addSource(jsrCall);
/* 2552:2708 */     jsrCall.addTarget(newGoto);
/* 2553:2709 */     jsrTarget.addSource(newGoto);
/* 2554:2710 */     jsrCall.instr = JVMInstr.ACONST_NULL;
/* 2555:2711 */     int jsrIdx = ops.indexOf(jsrCall);
/* 2556:2712 */     ops.add(jsrIdx + 1, newGoto);
/* 2557:     */   }
/* 2558:     */   
/* 2559:     */   private static void inlineJSR(Op02WithProcessedDataAndRefs start, Set<Op02WithProcessedDataAndRefs> nodes, List<Op02WithProcessedDataAndRefs> ops)
/* 2560:     */   {
/* 2561:2717 */     List<Op02WithProcessedDataAndRefs> instrs = ListFactory.newList(nodes);
/* 2562:2718 */     Collections.sort(instrs, new Comparator()
/* 2563:     */     {
/* 2564:     */       public int compare(Op02WithProcessedDataAndRefs o1, Op02WithProcessedDataAndRefs o2)
/* 2565:     */       {
/* 2566:2721 */         return o1.getIndex().compareTo(o2.getIndex());
/* 2567:     */       }
/* 2568:2723 */     });
/* 2569:2724 */     ops.removeAll(instrs);
/* 2570:     */     
/* 2571:2726 */     List<Op02WithProcessedDataAndRefs> sources = ListFactory.newList(start.getSources());
/* 2572:     */     
/* 2573:     */ 
/* 2574:     */ 
/* 2575:     */ 
/* 2576:     */ 
/* 2577:2732 */     Op02WithProcessedDataAndRefs newStart = new Op02WithProcessedDataAndRefs(JVMInstr.ACONST_NULL, null, start.getIndex().justBefore(), start.cp, null, -1);
/* 2578:     */     
/* 2579:     */ 
/* 2580:     */ 
/* 2581:     */ 
/* 2582:     */ 
/* 2583:     */ 
/* 2584:2739 */     instrs.add(0, newStart);
/* 2585:2740 */     start.getSources().clear();
/* 2586:2741 */     start.addSource(newStart);
/* 2587:2742 */     newStart.addTarget(start);
/* 2588:2744 */     for (Op02WithProcessedDataAndRefs source : sources)
/* 2589:     */     {
/* 2590:2746 */       source.removeTarget(start);
/* 2591:     */       
/* 2592:     */ 
/* 2593:2749 */       List<Op02WithProcessedDataAndRefs> instrCopy = copyBlock(instrs, source.getIndex());
/* 2594:     */       
/* 2595:     */ 
/* 2596:2752 */       int idx = ops.indexOf(source) + 1;
/* 2597:     */       Op02WithProcessedDataAndRefs retTgt;
/* 2598:2753 */       if (idx < ops.size())
/* 2599:     */       {
/* 2600:2754 */         retTgt = (Op02WithProcessedDataAndRefs)ops.get(idx);
/* 2601:2755 */         for (Op02WithProcessedDataAndRefs op : instrCopy) {
/* 2602:2756 */           if (isRET(op))
/* 2603:     */           {
/* 2604:2757 */             op.instr = JVMInstr.GOTO;
/* 2605:2758 */             op.addTarget(retTgt);
/* 2606:2759 */             retTgt.addSource(op);
/* 2607:     */           }
/* 2608:     */         }
/* 2609:     */       }
/* 2610:2766 */       source.instr = JVMInstr.NOP;
/* 2611:2767 */       int sourceIdx = ops.indexOf(source);
/* 2612:2768 */       ops.addAll(sourceIdx + 1, instrCopy);
/* 2613:2769 */       Op02WithProcessedDataAndRefs blockStart = (Op02WithProcessedDataAndRefs)instrCopy.get(0);
/* 2614:2770 */       blockStart.addSource(source);
/* 2615:2771 */       source.addTarget(blockStart);
/* 2616:     */     }
/* 2617:     */   }
/* 2618:     */   
/* 2619:     */   private static List<Op02WithProcessedDataAndRefs> copyBlock(List<Op02WithProcessedDataAndRefs> orig, InstrIndex afterThis)
/* 2620:     */   {
/* 2621:2776 */     List<Op02WithProcessedDataAndRefs> output = ListFactory.newList(orig.size());
/* 2622:2777 */     Map<Op02WithProcessedDataAndRefs, Op02WithProcessedDataAndRefs> fromTo = MapFactory.newMap();
/* 2623:2778 */     for (Op02WithProcessedDataAndRefs in : orig)
/* 2624:     */     {
/* 2625:2779 */       Op02WithProcessedDataAndRefs copy = new Op02WithProcessedDataAndRefs(in);
/* 2626:2780 */       afterThis = afterThis.justAfter();
/* 2627:2781 */       copy.index = afterThis;
/* 2628:2782 */       fromTo.put(in, copy);
/* 2629:2783 */       output.add(copy);
/* 2630:     */     }
/* 2631:2785 */     int x = 0;
/* 2632:2785 */     for (int len = orig.size(); x < len; x++)
/* 2633:     */     {
/* 2634:2786 */       Op02WithProcessedDataAndRefs in = (Op02WithProcessedDataAndRefs)orig.get(x);
/* 2635:2787 */       Op02WithProcessedDataAndRefs copy = (Op02WithProcessedDataAndRefs)output.get(x);
/* 2636:2788 */       copy.exceptionGroups = ListFactory.newList(in.exceptionGroups);
/* 2637:2789 */       copy.containedInTheseBlocks = ListFactory.newList(in.containedInTheseBlocks);
/* 2638:2790 */       copy.catchExceptionGroups = ListFactory.newList(in.catchExceptionGroups);
/* 2639:     */       
/* 2640:     */ 
/* 2641:2793 */       tieUpRelations(copy.getSources(), in.getSources(), fromTo);
/* 2642:2794 */       tieUpRelations(copy.getTargets(), in.getTargets(), fromTo);
/* 2643:     */     }
/* 2644:2796 */     return output;
/* 2645:     */   }
/* 2646:     */   
/* 2647:     */   private static void tieUpRelations(List<Op02WithProcessedDataAndRefs> out, List<Op02WithProcessedDataAndRefs> in, Map<Op02WithProcessedDataAndRefs, Op02WithProcessedDataAndRefs> map)
/* 2648:     */   {
/* 2649:2800 */     out.clear();
/* 2650:2801 */     for (Op02WithProcessedDataAndRefs i : in)
/* 2651:     */     {
/* 2652:2802 */       Op02WithProcessedDataAndRefs mapped = (Op02WithProcessedDataAndRefs)map.get(i);
/* 2653:2803 */       if (mapped == null) {
/* 2654:2804 */         throw new ConfusedCFRException("Missing node tying up JSR block");
/* 2655:     */       }
/* 2656:2806 */       out.add(mapped);
/* 2657:     */     }
/* 2658:     */   }
/* 2659:     */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs
 * JD-Core Version:    0.7.0.1
 */