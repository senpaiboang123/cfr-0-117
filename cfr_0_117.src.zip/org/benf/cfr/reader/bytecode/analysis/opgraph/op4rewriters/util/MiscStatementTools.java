/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.Block;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredComment;
/*  9:   */ import org.benf.cfr.reader.util.ListFactory;
/* 10:   */ import org.benf.cfr.reader.util.annotation.Nullable;
/* 11:   */ 
/* 12:   */ public class MiscStatementTools
/* 13:   */ {
/* 14:   */   public static List<Op04StructuredStatement> getBlockStatements(Op04StructuredStatement code)
/* 15:   */   {
/* 16:15 */     StructuredStatement topCode = code.getStatement();
/* 17:16 */     if (!(topCode instanceof Block)) {
/* 18:16 */       return null;
/* 19:   */     }
/* 20:18 */     Block block = (Block)topCode;
/* 21:19 */     List<Op04StructuredStatement> statements = block.getBlockStatements();
/* 22:20 */     return statements;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public static boolean isDeadCode(Op04StructuredStatement code)
/* 26:   */   {
/* 27:24 */     List<Op04StructuredStatement> statements = getBlockStatements(code);
/* 28:25 */     if (statements == null) {
/* 29:25 */       return false;
/* 30:   */     }
/* 31:26 */     for (Op04StructuredStatement statement : statements) {
/* 32:27 */       if (!(statement.getStatement() instanceof StructuredComment)) {
/* 33:27 */         return false;
/* 34:   */       }
/* 35:   */     }
/* 36:29 */     return true;
/* 37:   */   }
/* 38:   */   
/* 39:   */   @Nullable
/* 40:   */   public static List<StructuredStatement> linearise(Op04StructuredStatement root)
/* 41:   */   {
/* 42:34 */     List<StructuredStatement> structuredStatements = ListFactory.newList();
/* 43:   */     try
/* 44:   */     {
/* 45:37 */       root.linearizeStatementsInto(structuredStatements);
/* 46:   */     }
/* 47:   */     catch (UnsupportedOperationException e)
/* 48:   */     {
/* 49:40 */       return null;
/* 50:   */     }
/* 51:42 */     return structuredStatements;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public static void applyExpressionRewriter(Op04StructuredStatement root, ExpressionRewriter expressionRewriter)
/* 55:   */   {
/* 56:46 */     List<StructuredStatement> statements = linearise(root);
/* 57:47 */     if (statements == null) {
/* 58:47 */       return;
/* 59:   */     }
/* 60:48 */     for (StructuredStatement statement : statements) {
/* 61:49 */       statement.rewriteExpressions(expressionRewriter);
/* 62:   */     }
/* 63:   */   }
/* 64:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.MiscStatementTools
 * JD-Core Version:    0.7.0.1
 */