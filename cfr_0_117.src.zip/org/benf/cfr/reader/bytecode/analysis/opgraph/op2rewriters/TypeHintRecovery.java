package org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters;

import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;

public abstract interface TypeHintRecovery
{
  public abstract void improve(InferredJavaType paramInferredJavaType);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters.TypeHintRecovery
 * JD-Core Version:    0.7.0.1
 */