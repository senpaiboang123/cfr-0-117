/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.types.InnerClassInfo;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  6:   */ import org.benf.cfr.reader.bytecode.opcode.JVMInstr;
/*  7:   */ import org.benf.cfr.reader.entities.ClassFile;
/*  8:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass;
/*  9:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodRef;
/* 10:   */ 
/* 11:   */ public class GetClassTestInnerConstructor
/* 12:   */   implements GetClassTest
/* 13:   */ {
/* 14:18 */   public static GetClassTest INSTANCE = new GetClassTestInnerConstructor();
/* 15:   */   
/* 16:   */   public JVMInstr getInstr()
/* 17:   */   {
/* 18:25 */     return JVMInstr.INVOKESPECIAL;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public boolean test(ClassFile classFile, Op02WithProcessedDataAndRefs item)
/* 22:   */   {
/* 23:30 */     ConstantPoolEntryMethodRef function = (ConstantPoolEntryMethodRef)item.getCpEntries()[0];
/* 24:31 */     if (!function.getName().equals("<init>")) {
/* 25:31 */       return false;
/* 26:   */     }
/* 27:32 */     JavaTypeInstance initType = function.getClassEntry().getTypeInstance();
/* 28:33 */     InnerClassInfo innerClassInfo = initType.getInnerClassHereInfo();
/* 29:34 */     if (!innerClassInfo.isInnerClass()) {
/* 30:34 */       return false;
/* 31:   */     }
/* 32:35 */     return true;
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters.GetClassTestInnerConstructor
 * JD-Core Version:    0.7.0.1
 */