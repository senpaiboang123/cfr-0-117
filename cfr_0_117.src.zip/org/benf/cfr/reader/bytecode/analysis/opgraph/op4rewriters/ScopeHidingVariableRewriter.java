/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Set;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.VariableNameTidier;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.MiscStatementTools;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.variables.NamedVariable;
/* 13:   */ import org.benf.cfr.reader.entities.ClassFileField;
/* 14:   */ import org.benf.cfr.reader.entities.Method;
/* 15:   */ import org.benf.cfr.reader.state.ClassCache;
/* 16:   */ import org.benf.cfr.reader.util.ListFactory;
/* 17:   */ import org.benf.cfr.reader.util.SetFactory;
/* 18:   */ 
/* 19:   */ public class ScopeHidingVariableRewriter
/* 20:   */   implements Op04Rewriter
/* 21:   */ {
/* 22:   */   private final Method method;
/* 23:   */   private final ClassCache classCache;
/* 24:38 */   private final Set<String> outerNames = SetFactory.newSet();
/* 25:39 */   private final Set<String> usedNames = SetFactory.newSet();
/* 26:43 */   private List<LocalVariable> collisions = ListFactory.newList();
/* 27:   */   
/* 28:   */   public ScopeHidingVariableRewriter(List<ClassFileField> fieldVariables, Method method, ClassCache classCache)
/* 29:   */   {
/* 30:46 */     this.method = method;
/* 31:47 */     this.classCache = classCache;
/* 32:48 */     MethodPrototype prototype = method.getMethodPrototype();
/* 33:49 */     for (ClassFileField field : fieldVariables)
/* 34:   */     {
/* 35:50 */       String fieldName = field.getFieldName();
/* 36:51 */       this.outerNames.add(fieldName);
/* 37:52 */       this.usedNames.add(fieldName);
/* 38:   */     }
/* 39:54 */     if (prototype.parametersComputed()) {
/* 40:55 */       for (LocalVariable localVariable : prototype.getComputedParameters()) {
/* 41:56 */         checkCollision(localVariable);
/* 42:   */       }
/* 43:   */     }
/* 44:   */   }
/* 45:   */   
/* 46:   */   private void checkCollision(LocalVariable localVariable)
/* 47:   */   {
/* 48:62 */     String name = localVariable.getName().getStringName();
/* 49:63 */     if (this.outerNames.contains(name)) {
/* 50:63 */       this.collisions.add(localVariable);
/* 51:   */     }
/* 52:64 */     this.usedNames.add(name);
/* 53:   */   }
/* 54:   */   
/* 55:   */   public void rewrite(Op04StructuredStatement root)
/* 56:   */   {
/* 57:69 */     List<StructuredStatement> structuredStatements = MiscStatementTools.linearise(root);
/* 58:70 */     if (structuredStatements == null) {
/* 59:70 */       return;
/* 60:   */     }
/* 61:72 */     for (StructuredStatement definition : structuredStatements)
/* 62:   */     {
/* 63:73 */       List<LValue> createdHere = definition.findCreatedHere();
/* 64:74 */       if (createdHere != null) {
/* 65:76 */         for (LValue lValue : createdHere) {
/* 66:77 */           if ((lValue instanceof LocalVariable)) {
/* 67:78 */             checkCollision((LocalVariable)lValue);
/* 68:   */           }
/* 69:   */         }
/* 70:   */       }
/* 71:   */     }
/* 72:83 */     if (this.collisions.isEmpty()) {
/* 73:83 */       return;
/* 74:   */     }
/* 75:85 */     VariableNameTidier variableNameTidier = new VariableNameTidier(this.method, this.classCache);
/* 76:86 */     variableNameTidier.renameToAvoidHiding(this.usedNames, this.collisions);
/* 77:   */   }
/* 78:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.ScopeHidingVariableRewriter
 * JD-Core Version:    0.7.0.1
 */