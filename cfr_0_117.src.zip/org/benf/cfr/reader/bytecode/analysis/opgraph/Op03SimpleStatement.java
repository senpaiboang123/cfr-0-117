/*    1:     */ package org.benf.cfr.reader.bytecode.analysis.opgraph;
/*    2:     */ 
/*    3:     */ import java.util.Collections;
/*    4:     */ import java.util.Iterator;
/*    5:     */ import java.util.LinkedList;
/*    6:     */ import java.util.List;
/*    7:     */ import java.util.Map;
/*    8:     */ import java.util.Set;
/*    9:     */ import java.util.logging.Logger;
/*   10:     */ import org.benf.cfr.reader.bytecode.AnonymousClassUsage;
/*   11:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner;
/*   12:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.CompareByIndex;
/*   13:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LinearScannedBlock;
/*   14:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc;
/*   15:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.GraphVisitorBlockReachable;
/*   16:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.IsBackJumpTo;
/*   17:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.NarrowingTypeRewriter;
/*   18:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.StatementEquivalenceConstraint;
/*   19:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.TypeFilter;
/*   20:     */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   21:     */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   22:     */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*   23:     */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   24:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractAssignmentExpression;
/*   25:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractMutatingAssignmentExpression;
/*   26:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithOp;
/*   27:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithmeticOperation;
/*   28:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithmeticPostMutationOperation;
/*   29:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AssignmentExpression;
/*   30:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.BoolOp;
/*   31:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.BooleanExpression;
/*   32:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.BooleanOperation;
/*   33:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*   34:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*   35:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*   36:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.StackValue;
/*   37:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.TernaryExpression;
/*   38:     */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*   39:     */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*   40:     */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.AbstractExpressionRewriter;
/*   41:     */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   42:     */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ConditionalSimplifyingRewriter;
/*   43:     */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*   44:     */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*   45:     */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.StackVarToLocalRewriter;
/*   46:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.AbstractAssignment;
/*   47:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.AnonBreakTarget;
/*   48:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.AssignmentPreMutation;
/*   49:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.AssignmentSimple;
/*   50:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CaseStatement;
/*   51:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CatchStatement;
/*   52:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CommentStatement;
/*   53:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.DoStatement;
/*   54:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ExpressionStatement;
/*   55:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.FinallyStatement;
/*   56:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement;
/*   57:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.IfExitingStatement;
/*   58:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.IfStatement;
/*   59:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.JumpingStatement;
/*   60:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.MonitorExitStatement;
/*   61:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.MonitorStatement;
/*   62:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.Nop;
/*   63:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ReturnStatement;
/*   64:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.SwitchStatement;
/*   65:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ThrowStatement;
/*   66:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.TryStatement;
/*   67:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.WhileStatement;
/*   68:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*   69:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifierFactory;
/*   70:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockType;
/*   71:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.CreationCollector;
/*   72:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.JumpType;
/*   73:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentAndAliasCondenser;
/*   74:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentExpressionRewriter;
/*   75:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*   76:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollectorSimple;
/*   77:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*   78:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdent;
/*   79:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifierFactory;
/*   80:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifierUtils;
/*   81:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*   82:     */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
/*   83:     */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.LValueWildcard;
/*   84:     */ import org.benf.cfr.reader.bytecode.analysis.stack.StackEntry;
/*   85:     */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*   86:     */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*   87:     */ import org.benf.cfr.reader.bytecode.analysis.types.TypeConstants;
/*   88:     */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*   89:     */ import org.benf.cfr.reader.entities.Method;
/*   90:     */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/*   91:     */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheckImpl;
/*   92:     */ import org.benf.cfr.reader.entities.exceptions.ExceptionGroup.Entry;
/*   93:     */ import org.benf.cfr.reader.state.DCCommonState;
/*   94:     */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*   95:     */ import org.benf.cfr.reader.util.Functional;
/*   96:     */ import org.benf.cfr.reader.util.ListFactory;
/*   97:     */ import org.benf.cfr.reader.util.MapFactory;
/*   98:     */ import org.benf.cfr.reader.util.Predicate;
/*   99:     */ import org.benf.cfr.reader.util.SetFactory;
/*  100:     */ import org.benf.cfr.reader.util.SetUtil;
/*  101:     */ import org.benf.cfr.reader.util.Troolean;
/*  102:     */ import org.benf.cfr.reader.util.functors.BinaryProcedure;
/*  103:     */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  104:     */ import org.benf.cfr.reader.util.getopt.Options;
/*  105:     */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*  106:     */ import org.benf.cfr.reader.util.graph.GraphVisitor;
/*  107:     */ import org.benf.cfr.reader.util.graph.GraphVisitorDFS;
/*  108:     */ import org.benf.cfr.reader.util.output.Dumpable;
/*  109:     */ import org.benf.cfr.reader.util.output.Dumper;
/*  110:     */ import org.benf.cfr.reader.util.output.LoggerFactory;
/*  111:     */ 
/*  112:     */ public class Op03SimpleStatement
/*  113:     */   implements MutableGraph<Op03SimpleStatement>, Dumpable, StatementContainer<Statement>, IndexedStatement
/*  114:     */ {
/*  115:  35 */   private static final Logger logger = LoggerFactory.create(Op03SimpleStatement.class);
/*  116:  37 */   private final List<Op03SimpleStatement> sources = ListFactory.newList();
/*  117:  38 */   private final List<Op03SimpleStatement> targets = ListFactory.newList();
/*  118:     */   private Op03SimpleStatement linearlyPrevious;
/*  119:     */   private Op03SimpleStatement linearlyNext;
/*  120:     */   private boolean isNop;
/*  121:     */   private InstrIndex index;
/*  122:     */   private Statement containedStatement;
/*  123:     */   private SSAIdentifiers<LValue> ssaIdentifiers;
/*  124:     */   private BlockIdentifier thisComparisonBlock;
/*  125:     */   private BlockIdentifier firstStatementInThisBlock;
/*  126:  58 */   private final Set<BlockIdentifier> containedInBlocks = SetFactory.newSet();
/*  127:     */   
/*  128:     */   public Op03SimpleStatement(Op02WithProcessedDataAndRefs original, Statement statement)
/*  129:     */   {
/*  130:  61 */     this.containedStatement = statement;
/*  131:  62 */     this.isNop = false;
/*  132:  63 */     this.index = original.getIndex();
/*  133:  64 */     this.ssaIdentifiers = new SSAIdentifiers();
/*  134:  65 */     this.containedInBlocks.addAll(original.getContainedInTheseBlocks());
/*  135:  66 */     statement.setContainer(this);
/*  136:     */   }
/*  137:     */   
/*  138:     */   public Op03SimpleStatement(Set<BlockIdentifier> containedIn, Statement statement, InstrIndex index)
/*  139:     */   {
/*  140:  70 */     this.containedStatement = statement;
/*  141:  71 */     this.isNop = false;
/*  142:  72 */     this.index = index;
/*  143:  73 */     this.ssaIdentifiers = new SSAIdentifiers();
/*  144:  74 */     this.containedInBlocks.addAll(containedIn);
/*  145:  75 */     statement.setContainer(this);
/*  146:     */   }
/*  147:     */   
/*  148:     */   public Op03SimpleStatement(Set<BlockIdentifier> containedIn, Statement statement, SSAIdentifiers<LValue> ssaIdentifiers, InstrIndex index)
/*  149:     */   {
/*  150:  79 */     this.containedStatement = statement;
/*  151:  80 */     this.isNop = false;
/*  152:  81 */     this.index = index;
/*  153:  82 */     this.ssaIdentifiers = new SSAIdentifiers(ssaIdentifiers);
/*  154:  83 */     this.containedInBlocks.addAll(containedIn);
/*  155:  84 */     statement.setContainer(this);
/*  156:     */   }
/*  157:     */   
/*  158:     */   public List<Op03SimpleStatement> getSources()
/*  159:     */   {
/*  160:  90 */     return this.sources;
/*  161:     */   }
/*  162:     */   
/*  163:     */   public List<Op03SimpleStatement> getTargets()
/*  164:     */   {
/*  165:  95 */     return this.targets;
/*  166:     */   }
/*  167:     */   
/*  168:     */   public void setLinearlyNext(Op03SimpleStatement linearlyNext)
/*  169:     */   {
/*  170:  99 */     this.linearlyNext = linearlyNext;
/*  171:     */   }
/*  172:     */   
/*  173:     */   public Op03SimpleStatement getLinearlyPrevious()
/*  174:     */   {
/*  175: 103 */     return this.linearlyPrevious;
/*  176:     */   }
/*  177:     */   
/*  178:     */   public void setLinearlyPrevious(Op03SimpleStatement linearlyPrevious)
/*  179:     */   {
/*  180: 107 */     this.linearlyPrevious = linearlyPrevious;
/*  181:     */   }
/*  182:     */   
/*  183:     */   public BlockIdentifier getFirstStatementInThisBlock()
/*  184:     */   {
/*  185: 111 */     return this.firstStatementInThisBlock;
/*  186:     */   }
/*  187:     */   
/*  188:     */   public void setFirstStatementInThisBlock(BlockIdentifier firstStatementInThisBlock)
/*  189:     */   {
/*  190: 115 */     this.firstStatementInThisBlock = firstStatementInThisBlock;
/*  191:     */   }
/*  192:     */   
/*  193:     */   public void addSource(Op03SimpleStatement source)
/*  194:     */   {
/*  195: 120 */     if (source == null) {
/*  196: 120 */       throw new ConfusedCFRException("Null source being added.");
/*  197:     */     }
/*  198: 121 */     this.sources.add(source);
/*  199:     */   }
/*  200:     */   
/*  201:     */   public void addTarget(Op03SimpleStatement target)
/*  202:     */   {
/*  203: 126 */     this.targets.add(target);
/*  204:     */   }
/*  205:     */   
/*  206:     */   public Statement getStatement()
/*  207:     */   {
/*  208: 131 */     return this.containedStatement;
/*  209:     */   }
/*  210:     */   
/*  211:     */   public Statement getTargetStatement(int idx)
/*  212:     */   {
/*  213: 136 */     if (this.targets.size() <= idx) {
/*  214: 137 */       throw new ConfusedCFRException("Trying to get invalid target " + idx);
/*  215:     */     }
/*  216: 139 */     Op03SimpleStatement target = (Op03SimpleStatement)this.targets.get(idx);
/*  217: 140 */     Statement statement = target.getStatement();
/*  218: 141 */     if (statement == null) {
/*  219: 141 */       throw new ConfusedCFRException("Invalid target statement");
/*  220:     */     }
/*  221: 142 */     return statement;
/*  222:     */   }
/*  223:     */   
/*  224:     */   public void replaceStatement(Statement newStatement)
/*  225:     */   {
/*  226: 147 */     newStatement.setContainer(this);
/*  227: 148 */     this.containedStatement = newStatement;
/*  228:     */   }
/*  229:     */   
/*  230:     */   private void markAgreedNop()
/*  231:     */   {
/*  232: 152 */     this.isNop = true;
/*  233:     */   }
/*  234:     */   
/*  235:     */   public void nopOut()
/*  236:     */   {
/*  237: 158 */     if (this.isNop) {
/*  238: 159 */       return;
/*  239:     */     }
/*  240: 162 */     if (this.targets.isEmpty())
/*  241:     */     {
/*  242: 163 */       for (Op03SimpleStatement source : this.sources) {
/*  243: 164 */         source.removeTarget(this);
/*  244:     */       }
/*  245: 166 */       this.sources.clear();
/*  246: 167 */       this.containedStatement = new Nop();
/*  247: 168 */       this.containedStatement.setContainer(this);
/*  248: 169 */       markAgreedNop();
/*  249: 170 */       return;
/*  250:     */     }
/*  251: 173 */     if (this.targets.size() != 1) {
/*  252: 174 */       throw new ConfusedCFRException("Trying to nopOut a node with multiple targets");
/*  253:     */     }
/*  254: 176 */     this.containedStatement = new Nop();
/*  255: 177 */     this.containedStatement.setContainer(this);
/*  256:     */     
/*  257: 179 */     Op03SimpleStatement target = (Op03SimpleStatement)this.targets.get(0);
/*  258: 180 */     for (Op03SimpleStatement source : this.sources) {
/*  259: 181 */       source.replaceTarget(this, target);
/*  260:     */     }
/*  261: 184 */     target.replaceSingleSourceWith(this, this.sources);
/*  262: 185 */     this.sources.clear();
/*  263: 186 */     this.targets.clear();
/*  264: 187 */     markAgreedNop();
/*  265:     */   }
/*  266:     */   
/*  267:     */   public void nopOutConditional()
/*  268:     */   {
/*  269: 199 */     this.containedStatement = new Nop();
/*  270: 200 */     this.containedStatement.setContainer(this);
/*  271: 201 */     for (int i = 1; i < this.targets.size(); i++)
/*  272:     */     {
/*  273: 202 */       Op03SimpleStatement dropTarget = (Op03SimpleStatement)this.targets.get(i);
/*  274: 203 */       dropTarget.removeSource(this);
/*  275:     */     }
/*  276: 206 */     Op03SimpleStatement target = (Op03SimpleStatement)this.targets.get(0);
/*  277: 207 */     this.targets.clear();
/*  278: 208 */     this.targets.add(target);
/*  279: 209 */     for (Op03SimpleStatement source : this.sources) {
/*  280: 210 */       source.replaceTarget(this, target);
/*  281:     */     }
/*  282: 213 */     target.replaceSingleSourceWith(this, this.sources);
/*  283: 214 */     this.sources.clear();
/*  284: 215 */     this.targets.clear();
/*  285: 216 */     markAgreedNop();
/*  286:     */   }
/*  287:     */   
/*  288:     */   public void clear()
/*  289:     */   {
/*  290: 220 */     for (Op03SimpleStatement source : this.sources) {
/*  291: 221 */       if (source.getTargets().contains(this)) {
/*  292: 222 */         source.removeTarget(this);
/*  293:     */       }
/*  294:     */     }
/*  295: 225 */     this.sources.clear();
/*  296: 226 */     for (Op03SimpleStatement target : this.targets) {
/*  297: 227 */       if (target.getSources().contains(this)) {
/*  298: 228 */         target.removeSource(this);
/*  299:     */       }
/*  300:     */     }
/*  301: 231 */     this.targets.clear();
/*  302: 232 */     nopOut();
/*  303:     */   }
/*  304:     */   
/*  305:     */   public SSAIdentifiers<LValue> getSSAIdentifiers()
/*  306:     */   {
/*  307: 237 */     return this.ssaIdentifiers;
/*  308:     */   }
/*  309:     */   
/*  310:     */   public Set<BlockIdentifier> getBlockIdentifiers()
/*  311:     */   {
/*  312: 242 */     return this.containedInBlocks;
/*  313:     */   }
/*  314:     */   
/*  315:     */   public BlockIdentifier getBlockStarted()
/*  316:     */   {
/*  317: 247 */     return this.firstStatementInThisBlock;
/*  318:     */   }
/*  319:     */   
/*  320:     */   public Set<BlockIdentifier> getBlocksEnded()
/*  321:     */   {
/*  322: 255 */     if (this.linearlyPrevious == null) {
/*  323: 255 */       return SetFactory.newSet();
/*  324:     */     }
/*  325: 256 */     Set<BlockIdentifier> in = SetFactory.newSet(this.linearlyPrevious.getBlockIdentifiers());
/*  326: 257 */     in.removeAll(getBlockIdentifiers());
/*  327: 258 */     Iterator<BlockIdentifier> iterator = in.iterator();
/*  328: 259 */     while (iterator.hasNext())
/*  329:     */     {
/*  330: 260 */       BlockIdentifier blockIdentifier = (BlockIdentifier)iterator.next();
/*  331: 261 */       if (!blockIdentifier.getBlockType().isBreakable()) {
/*  332: 261 */         iterator.remove();
/*  333:     */       }
/*  334:     */     }
/*  335: 263 */     return in;
/*  336:     */   }
/*  337:     */   
/*  338:     */   public Op03SimpleStatement getLinearlyNext()
/*  339:     */   {
/*  340: 267 */     return this.linearlyNext;
/*  341:     */   }
/*  342:     */   
/*  343:     */   public void copyBlockInformationFrom(StatementContainer other)
/*  344:     */   {
/*  345: 272 */     Op03SimpleStatement other3 = (Op03SimpleStatement)other;
/*  346: 273 */     this.containedInBlocks.addAll(other.getBlockIdentifiers());
/*  347: 277 */     if (this.firstStatementInThisBlock == null) {
/*  348: 277 */       this.firstStatementInThisBlock = other3.firstStatementInThisBlock;
/*  349:     */     }
/*  350:     */   }
/*  351:     */   
/*  352:     */   public boolean isAgreedNop()
/*  353:     */   {
/*  354: 282 */     return this.isNop;
/*  355:     */   }
/*  356:     */   
/*  357:     */   public void replaceBlockIfIn(BlockIdentifier oldB, BlockIdentifier newB)
/*  358:     */   {
/*  359: 286 */     if (this.containedInBlocks.remove(oldB)) {
/*  360: 287 */       this.containedInBlocks.add(newB);
/*  361:     */     }
/*  362:     */   }
/*  363:     */   
/*  364:     */   public void replaceTarget(Op03SimpleStatement oldTarget, Op03SimpleStatement newTarget)
/*  365:     */   {
/*  366: 292 */     int index = this.targets.indexOf(oldTarget);
/*  367: 293 */     if (index == -1) {
/*  368: 294 */       throw new ConfusedCFRException("Invalid target");
/*  369:     */     }
/*  370: 296 */     this.targets.set(index, newTarget);
/*  371:     */   }
/*  372:     */   
/*  373:     */   private void replaceSingleSourceWith(Op03SimpleStatement oldSource, List<Op03SimpleStatement> newSources)
/*  374:     */   {
/*  375: 300 */     if (!this.sources.remove(oldSource)) {
/*  376: 301 */       throw new ConfusedCFRException("Invalid source");
/*  377:     */     }
/*  378: 303 */     this.sources.addAll(newSources);
/*  379:     */   }
/*  380:     */   
/*  381:     */   public void replaceSource(Op03SimpleStatement oldSource, Op03SimpleStatement newSource)
/*  382:     */   {
/*  383: 307 */     int index = this.sources.indexOf(oldSource);
/*  384: 308 */     if (index == -1) {
/*  385: 309 */       throw new ConfusedCFRException("Invalid source");
/*  386:     */     }
/*  387: 311 */     this.sources.set(index, newSource);
/*  388:     */   }
/*  389:     */   
/*  390:     */   public void removeSource(Op03SimpleStatement oldSource)
/*  391:     */   {
/*  392: 315 */     if (!this.sources.remove(oldSource)) {
/*  393: 316 */       throw new ConfusedCFRException("Invalid source, tried to remove " + oldSource + "\nfrom " + this + "\nbut was not a source.");
/*  394:     */     }
/*  395:     */   }
/*  396:     */   
/*  397:     */   public void removeTarget(Op03SimpleStatement oldTarget)
/*  398:     */   {
/*  399: 321 */     if ((this.containedStatement instanceof GotoStatement)) {
/*  400: 322 */       throw new ConfusedCFRException("Removing goto target");
/*  401:     */     }
/*  402: 324 */     if (!this.targets.remove(oldTarget)) {
/*  403: 325 */       throw new ConfusedCFRException("Invalid target, tried to remove " + oldTarget + "\nfrom " + this + "\nbut was not a target.");
/*  404:     */     }
/*  405:     */   }
/*  406:     */   
/*  407:     */   public void removeGotoTarget(Op03SimpleStatement oldTarget)
/*  408:     */   {
/*  409: 330 */     if (!this.targets.remove(oldTarget)) {
/*  410: 331 */       throw new ConfusedCFRException("Invalid target, tried to remove " + oldTarget + "\nfrom " + this + "\nbut was not a target.");
/*  411:     */     }
/*  412:     */   }
/*  413:     */   
/*  414:     */   private LValue getCreatedLValue()
/*  415:     */   {
/*  416: 336 */     return this.containedStatement.getCreatedLValue();
/*  417:     */   }
/*  418:     */   
/*  419:     */   public InstrIndex getIndex()
/*  420:     */   {
/*  421: 341 */     return this.index;
/*  422:     */   }
/*  423:     */   
/*  424:     */   public void setIndex(InstrIndex index)
/*  425:     */   {
/*  426: 345 */     this.index = index;
/*  427:     */   }
/*  428:     */   
/*  429:     */   public BlockIdentifier getThisComparisonBlock()
/*  430:     */   {
/*  431: 349 */     return this.thisComparisonBlock;
/*  432:     */   }
/*  433:     */   
/*  434:     */   public void clearThisComparisonBlock()
/*  435:     */   {
/*  436: 353 */     this.thisComparisonBlock = null;
/*  437:     */   }
/*  438:     */   
/*  439:     */   public void markBlockStatement(BlockIdentifier blockIdentifier, Op03SimpleStatement lastInBlock, Op03SimpleStatement blockEnd, List<Op03SimpleStatement> statements)
/*  440:     */   {
/*  441: 359 */     if (this.thisComparisonBlock != null) {
/*  442: 360 */       throw new ConfusedCFRException("Statement marked as the start of multiple blocks");
/*  443:     */     }
/*  444: 362 */     this.thisComparisonBlock = blockIdentifier;
/*  445: 363 */     switch (10.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$utils$BlockType[blockIdentifier.getBlockType().ordinal()])
/*  446:     */     {
/*  447:     */     case 1: 
/*  448: 365 */       IfStatement ifStatement = (IfStatement)this.containedStatement;
/*  449: 366 */       ifStatement.replaceWithWhileLoopStart(blockIdentifier);
/*  450: 367 */       Op03SimpleStatement whileEndTarget = (Op03SimpleStatement)this.targets.get(1);
/*  451:     */       
/*  452:     */ 
/*  453:     */ 
/*  454:     */ 
/*  455:     */ 
/*  456: 373 */       boolean pullOutJump = this.index.isBackJumpTo(whileEndTarget);
/*  457: 374 */       if (!pullOutJump) {
/*  458: 377 */         if (statements.indexOf(lastInBlock) != statements.indexOf(blockEnd) - 1) {
/*  459: 378 */           pullOutJump = true;
/*  460:     */         }
/*  461:     */       }
/*  462: 381 */       if (pullOutJump)
/*  463:     */       {
/*  464: 382 */         Set<BlockIdentifier> backJumpContainedIn = SetFactory.newSet(this.containedInBlocks);
/*  465: 383 */         backJumpContainedIn.remove(blockIdentifier);
/*  466: 384 */         Op03SimpleStatement backJump = new Op03SimpleStatement(backJumpContainedIn, new GotoStatement(), blockEnd.index.justBefore());
/*  467: 385 */         whileEndTarget.replaceSource(this, backJump);
/*  468: 386 */         replaceTarget(whileEndTarget, backJump);
/*  469: 387 */         backJump.addSource(this);
/*  470: 388 */         backJump.addTarget(whileEndTarget);
/*  471:     */         
/*  472:     */ 
/*  473:     */ 
/*  474: 392 */         int insertAfter = statements.indexOf(blockEnd) - 1;
/*  475: 393 */         while (!((Op03SimpleStatement)statements.get(insertAfter)).containedInBlocks.containsAll(this.containedInBlocks)) {
/*  476: 394 */           insertAfter--;
/*  477:     */         }
/*  478: 396 */         backJump.index = ((Op03SimpleStatement)statements.get(insertAfter)).index.justAfter();
/*  479: 397 */         statements.add(insertAfter + 1, backJump);
/*  480:     */       }
/*  481: 398 */       break;
/*  482:     */     case 2: 
/*  483: 402 */       this.containedStatement.getContainer().replaceStatement(new WhileStatement(null, blockIdentifier));
/*  484: 403 */       break;
/*  485:     */     case 3: 
/*  486: 406 */       IfStatement ifStatement = (IfStatement)this.containedStatement;
/*  487: 407 */       ifStatement.replaceWithWhileLoopEnd(blockIdentifier);
/*  488: 408 */       break;
/*  489:     */     case 4: 
/*  490:     */     case 5: 
/*  491: 412 */       throw new ConfusedCFRException("Shouldn't be marking the comparison of an IF");
/*  492:     */     default: 
/*  493: 414 */       throw new ConfusedCFRException("Don't know how to start a block like this");
/*  494:     */     }
/*  495:     */   }
/*  496:     */   
/*  497:     */   public void markFirstStatementInBlock(BlockIdentifier blockIdentifier)
/*  498:     */   {
/*  499: 419 */     if ((this.firstStatementInThisBlock != null) && (this.firstStatementInThisBlock != blockIdentifier)) {
/*  500: 420 */       throw new ConfusedCFRException("Statement already marked as first in another block");
/*  501:     */     }
/*  502: 422 */     this.firstStatementInThisBlock = blockIdentifier;
/*  503:     */   }
/*  504:     */   
/*  505:     */   public void markBlock(BlockIdentifier blockIdentifier)
/*  506:     */   {
/*  507: 426 */     this.containedInBlocks.add(blockIdentifier);
/*  508:     */   }
/*  509:     */   
/*  510:     */   public void collect(LValueAssignmentAndAliasCondenser lValueAssigmentCollector)
/*  511:     */   {
/*  512: 430 */     this.containedStatement.collectLValueAssignments(lValueAssigmentCollector);
/*  513:     */   }
/*  514:     */   
/*  515:     */   public void condense(LValueRewriter lValueRewriter)
/*  516:     */   {
/*  517: 434 */     this.containedStatement.replaceSingleUsageLValues(lValueRewriter, this.ssaIdentifiers);
/*  518:     */   }
/*  519:     */   
/*  520:     */   public void rewrite(ExpressionRewriter expressionRewriter)
/*  521:     */   {
/*  522: 438 */     this.containedStatement.rewriteExpressions(expressionRewriter, this.ssaIdentifiers);
/*  523:     */   }
/*  524:     */   
/*  525:     */   private void findCreation(CreationCollector creationCollector)
/*  526:     */   {
/*  527: 442 */     this.containedStatement.collectObjectCreation(creationCollector);
/*  528:     */   }
/*  529:     */   
/*  530:     */   private void simplifyConditional()
/*  531:     */   {
/*  532: 446 */     if ((this.containedStatement instanceof IfStatement))
/*  533:     */     {
/*  534: 447 */       IfStatement ifStatement = (IfStatement)this.containedStatement;
/*  535: 448 */       ifStatement.simplifyCondition();
/*  536:     */     }
/*  537:     */   }
/*  538:     */   
/*  539:     */   public class GraphVisitorCallee
/*  540:     */     implements BinaryProcedure<Op03SimpleStatement, GraphVisitor<Op03SimpleStatement>>
/*  541:     */   {
/*  542:     */     private final List<Op03SimpleStatement> reachableNodes;
/*  543:     */     
/*  544:     */     public GraphVisitorCallee()
/*  545:     */     {
/*  546: 456 */       this.reachableNodes = reachableNodes;
/*  547:     */     }
/*  548:     */     
/*  549:     */     public void call(Op03SimpleStatement node, GraphVisitor<Op03SimpleStatement> graphVisitor)
/*  550:     */     {
/*  551: 461 */       this.reachableNodes.add(node);
/*  552: 462 */       for (Op03SimpleStatement target : node.targets) {
/*  553: 463 */         graphVisitor.enqueue(target);
/*  554:     */       }
/*  555:     */     }
/*  556:     */   }
/*  557:     */   
/*  558:     */   private boolean needsLabel()
/*  559:     */   {
/*  560: 471 */     if (this.sources.size() > 1) {
/*  561: 471 */       return true;
/*  562:     */     }
/*  563: 472 */     if (this.sources.size() == 0) {
/*  564: 472 */       return false;
/*  565:     */     }
/*  566: 473 */     Op03SimpleStatement source = (Op03SimpleStatement)this.sources.get(0);
/*  567: 474 */     return !source.getIndex().directlyPreceeds(getIndex());
/*  568:     */   }
/*  569:     */   
/*  570:     */   public String getLabel()
/*  571:     */   {
/*  572: 479 */     return getIndex().toString();
/*  573:     */   }
/*  574:     */   
/*  575:     */   public void dumpInner(Dumper dumper)
/*  576:     */   {
/*  577: 483 */     if (needsLabel()) {
/*  578: 483 */       dumper.print(getLabel() + ":\n");
/*  579:     */     }
/*  580: 484 */     for (BlockIdentifier blockIdentifier : this.containedInBlocks) {
/*  581: 485 */       dumper.print(blockIdentifier + " ");
/*  582:     */     }
/*  583: 488 */     getStatement().dump(dumper);
/*  584:     */   }
/*  585:     */   
/*  586:     */   public static void dumpAll(List<Op03SimpleStatement> statements, Dumper dumper)
/*  587:     */   {
/*  588: 492 */     for (Op03SimpleStatement statement : statements) {
/*  589: 493 */       statement.dumpInner(dumper);
/*  590:     */     }
/*  591:     */   }
/*  592:     */   
/*  593:     */   public Dumper dump(Dumper dumper)
/*  594:     */   {
/*  595: 499 */     dumper.print("**********\n");
/*  596: 500 */     List<Op03SimpleStatement> reachableNodes = ListFactory.newList();
/*  597: 501 */     GraphVisitorCallee graphVisitorCallee = new GraphVisitorCallee(reachableNodes);
/*  598: 502 */     GraphVisitor<Op03SimpleStatement> visitor = new GraphVisitorDFS(this, graphVisitorCallee);
/*  599: 503 */     visitor.process();
/*  600:     */     try
/*  601:     */     {
/*  602: 506 */       Collections.sort(reachableNodes, new CompareByIndex());
/*  603:     */     }
/*  604:     */     catch (ConfusedCFRException e)
/*  605:     */     {
/*  606: 508 */       dumper.print("CONFUSED!" + e);
/*  607:     */     }
/*  608: 510 */     for (Op03SimpleStatement op : reachableNodes) {
/*  609: 511 */       op.dumpInner(dumper);
/*  610:     */     }
/*  611: 513 */     dumper.print("**********\n");
/*  612: 514 */     return dumper;
/*  613:     */   }
/*  614:     */   
/*  615:     */   public Op04StructuredStatement getStructuredStatementPlaceHolder()
/*  616:     */   {
/*  617: 518 */     return new Op04StructuredStatement(this.index, this.containedInBlocks, this.containedStatement.getStructuredStatement());
/*  618:     */   }
/*  619:     */   
/*  620:     */   public boolean isCompound()
/*  621:     */   {
/*  622: 525 */     return this.containedStatement.isCompound();
/*  623:     */   }
/*  624:     */   
/*  625:     */   public List<Op03SimpleStatement> splitCompound()
/*  626:     */   {
/*  627: 529 */     List<Op03SimpleStatement> result = ListFactory.newList();
/*  628: 530 */     List<Statement> innerStatements = this.containedStatement.getCompoundParts();
/*  629: 531 */     InstrIndex nextIndex = this.index.justAfter();
/*  630: 532 */     for (Statement statement : innerStatements)
/*  631:     */     {
/*  632: 533 */       result.add(new Op03SimpleStatement(this.containedInBlocks, statement, nextIndex));
/*  633: 534 */       nextIndex = nextIndex.justAfter();
/*  634:     */     }
/*  635: 536 */     ((Op03SimpleStatement)result.get(0)).firstStatementInThisBlock = this.firstStatementInThisBlock;
/*  636: 537 */     Op03SimpleStatement previous = null;
/*  637: 538 */     for (Op03SimpleStatement statement : result)
/*  638:     */     {
/*  639: 539 */       if (previous != null)
/*  640:     */       {
/*  641: 540 */         statement.addSource(previous);
/*  642: 541 */         previous.addTarget(statement);
/*  643:     */       }
/*  644: 543 */       previous = statement;
/*  645:     */     }
/*  646: 545 */     Op03SimpleStatement newStart = (Op03SimpleStatement)result.get(0);
/*  647: 546 */     Op03SimpleStatement newEnd = previous;
/*  648: 547 */     for (Op03SimpleStatement source : this.sources)
/*  649:     */     {
/*  650: 548 */       source.replaceTarget(this, newStart);
/*  651: 549 */       newStart.addSource(source);
/*  652:     */     }
/*  653: 551 */     for (Op03SimpleStatement target : this.targets)
/*  654:     */     {
/*  655: 552 */       target.replaceSource(this, newEnd);
/*  656: 553 */       newEnd.addTarget(target);
/*  657:     */     }
/*  658: 555 */     this.containedStatement = new Nop();
/*  659: 556 */     this.sources.clear();
/*  660: 557 */     this.targets.clear();
/*  661: 558 */     markAgreedNop();
/*  662: 559 */     return result;
/*  663:     */   }
/*  664:     */   
/*  665:     */   private void collectLocallyMutatedVariables(SSAIdentifierFactory<LValue> ssaIdentifierFactory)
/*  666:     */   {
/*  667: 565 */     this.ssaIdentifiers = this.containedStatement.collectLocallyMutatedVariables(ssaIdentifierFactory);
/*  668:     */   }
/*  669:     */   
/*  670:     */   public void forceSSAIdentifiers(SSAIdentifiers<LValue> newIdentifiers)
/*  671:     */   {
/*  672: 569 */     this.ssaIdentifiers = newIdentifiers;
/*  673:     */   }
/*  674:     */   
/*  675:     */   public static void assignSSAIdentifiers(Method method, List<Op03SimpleStatement> statements)
/*  676:     */   {
/*  677: 580 */     SSAIdentifierFactory<LValue> ssaIdentifierFactory = new SSAIdentifierFactory(null);
/*  678:     */     
/*  679: 582 */     List<LocalVariable> params = method.getMethodPrototype().getComputedParameters();
/*  680: 583 */     Map<LValue, SSAIdent> initialSSAValues = MapFactory.newMap();
/*  681: 584 */     for (LocalVariable param : params) {
/*  682: 585 */       initialSSAValues.put(param, ssaIdentifierFactory.getIdent(param));
/*  683:     */     }
/*  684: 587 */     SSAIdentifiers<LValue> initialIdents = new SSAIdentifiers(initialSSAValues);
/*  685: 589 */     for (Op03SimpleStatement statement : statements) {
/*  686: 590 */       statement.collectLocallyMutatedVariables(ssaIdentifierFactory);
/*  687:     */     }
/*  688: 593 */     Op03SimpleStatement entry = (Op03SimpleStatement)statements.get(0);
/*  689:     */     
/*  690: 595 */     LinkedList<Op03SimpleStatement> toProcess = ListFactory.newLinkedList();
/*  691: 596 */     toProcess.addAll(statements);
/*  692: 597 */     while (!toProcess.isEmpty())
/*  693:     */     {
/*  694: 598 */       Op03SimpleStatement statement = (Op03SimpleStatement)toProcess.remove();
/*  695: 599 */       SSAIdentifiers<LValue> ssaIdentifiers = statement.ssaIdentifiers;
/*  696: 600 */       boolean changed = false;
/*  697: 601 */       if ((statement == entry) && 
/*  698: 602 */         (ssaIdentifiers.mergeWith(initialIdents))) {
/*  699: 602 */         changed = true;
/*  700:     */       }
/*  701: 604 */       for (Op03SimpleStatement source : statement.getSources()) {
/*  702: 605 */         if (ssaIdentifiers.mergeWith(source.ssaIdentifiers)) {
/*  703: 605 */           changed = true;
/*  704:     */         }
/*  705:     */       }
/*  706: 608 */       if (changed) {
/*  707: 609 */         toProcess.addAll(statement.getTargets());
/*  708:     */       }
/*  709:     */     }
/*  710:     */   }
/*  711:     */   
/*  712:     */   public static void condenseLValueChain1(List<Op03SimpleStatement> statements)
/*  713:     */   {
/*  714: 628 */     for (Op03SimpleStatement statement : statements)
/*  715:     */     {
/*  716: 629 */       Statement stm = statement.getStatement();
/*  717: 630 */       if (((stm instanceof AssignmentSimple)) && 
/*  718: 631 */         (statement.getTargets().size() == 1))
/*  719:     */       {
/*  720: 632 */         Op03SimpleStatement statement2 = (Op03SimpleStatement)statement.getTargets().get(0);
/*  721: 633 */         if (statement2.getSources().size() == 1)
/*  722:     */         {
/*  723: 636 */           Statement stm2 = statement2.getStatement();
/*  724: 637 */           if ((stm2 instanceof AssignmentSimple)) {
/*  725: 638 */             applyLValueSwap((AssignmentSimple)stm, (AssignmentSimple)stm2, statement, statement2);
/*  726:     */           }
/*  727:     */         }
/*  728:     */       }
/*  729:     */     }
/*  730:     */   }
/*  731:     */   
/*  732:     */   public static void applyLValueSwap(AssignmentSimple a1, AssignmentSimple a2, Op03SimpleStatement stm1, Op03SimpleStatement stm2)
/*  733:     */   {
/*  734: 647 */     Expression r1 = a1.getRValue();
/*  735: 648 */     Expression r2 = a2.getRValue();
/*  736: 649 */     if (!r1.equals(r2)) {
/*  737: 649 */       return;
/*  738:     */     }
/*  739: 650 */     LValue l1 = a1.getCreatedLValue();
/*  740: 651 */     LValue l2 = a2.getCreatedLValue();
/*  741: 653 */     if (((l1 instanceof StackSSALabel)) && (!(l2 instanceof StackSSALabel)))
/*  742:     */     {
/*  743: 654 */       stm1.replaceStatement(a2);
/*  744: 655 */       stm2.replaceStatement(new AssignmentSimple(l1, new LValueExpression(l2)));
/*  745:     */     }
/*  746:     */   }
/*  747:     */   
/*  748:     */   public static void condenseLValueChain2(List<Op03SimpleStatement> statements)
/*  749:     */   {
/*  750: 661 */     for (Op03SimpleStatement statement : statements)
/*  751:     */     {
/*  752: 662 */       Statement stm = statement.getStatement();
/*  753: 663 */       if (((stm instanceof AssignmentSimple)) && 
/*  754: 664 */         (statement.getTargets().size() == 1))
/*  755:     */       {
/*  756: 665 */         Op03SimpleStatement statement2 = (Op03SimpleStatement)statement.getTargets().get(0);
/*  757: 666 */         if (statement2.getSources().size() == 1)
/*  758:     */         {
/*  759: 669 */           Statement stm2 = statement2.getStatement();
/*  760: 670 */           if ((stm2 instanceof AssignmentSimple)) {
/*  761: 671 */             applyLValueCondense((AssignmentSimple)stm, (AssignmentSimple)stm2, statement, statement2);
/*  762:     */           }
/*  763:     */         }
/*  764:     */       }
/*  765:     */     }
/*  766:     */   }
/*  767:     */   
/*  768:     */   public static void applyLValueCondense(AssignmentSimple a1, AssignmentSimple a2, Op03SimpleStatement stm1, Op03SimpleStatement stm2)
/*  769:     */   {
/*  770: 680 */     Expression r1 = a1.getRValue();
/*  771: 681 */     Expression r2 = a2.getRValue();
/*  772: 682 */     LValue l1 = a1.getCreatedLValue();
/*  773: 683 */     LValue l2 = a2.getCreatedLValue();
/*  774: 684 */     if (!r2.equals(new LValueExpression(l1))) {
/*  775: 684 */       return;
/*  776:     */     }
/*  777: 687 */     Expression newRhs = null;
/*  778: 688 */     if (((r1 instanceof ArithmeticOperation)) && (((ArithmeticOperation)r1).isMutationOf(l1)))
/*  779:     */     {
/*  780: 689 */       ArithmeticOperation ar1 = (ArithmeticOperation)r1;
/*  781: 690 */       AbstractMutatingAssignmentExpression me = ar1.getMutationOf(l1);
/*  782: 691 */       newRhs = me;
/*  783:     */     }
/*  784: 694 */     if (newRhs == null) {
/*  785: 694 */       newRhs = new AssignmentExpression(l1, r1);
/*  786:     */     }
/*  787: 698 */     if (newRhs.getInferredJavaType().getJavaTypeInstance() != l2.getInferredJavaType().getJavaTypeInstance()) {
/*  788: 699 */       return;
/*  789:     */     }
/*  790: 702 */     stm2.replaceStatement(new AssignmentSimple(l2, newRhs));
/*  791: 703 */     stm1.nopOut();
/*  792:     */   }
/*  793:     */   
/*  794:     */   private static void replacePostChangeAssignment(Op03SimpleStatement statement)
/*  795:     */   {
/*  796: 717 */     AssignmentSimple assignmentSimple = (AssignmentSimple)statement.containedStatement;
/*  797: 718 */     LValue postIncLValue = assignmentSimple.getCreatedLValue();
/*  798: 720 */     if (statement.sources.size() != 1) {
/*  799: 720 */       return;
/*  800:     */     }
/*  801: 722 */     Op03SimpleStatement prior = (Op03SimpleStatement)statement.sources.get(0);
/*  802: 723 */     Statement statementPrior = prior.getStatement();
/*  803: 724 */     if (!(statementPrior instanceof AssignmentSimple)) {
/*  804: 724 */       return;
/*  805:     */     }
/*  806: 726 */     AssignmentSimple assignmentSimplePrior = (AssignmentSimple)statementPrior;
/*  807: 727 */     LValue tmp = assignmentSimplePrior.getCreatedLValue();
/*  808: 728 */     if (!(tmp instanceof StackSSALabel)) {
/*  809: 728 */       return;
/*  810:     */     }
/*  811: 730 */     if (!assignmentSimplePrior.getRValue().equals(new LValueExpression(postIncLValue))) {
/*  812: 730 */       return;
/*  813:     */     }
/*  814: 732 */     StackSSALabel tmpStackVar = (StackSSALabel)tmp;
/*  815: 733 */     Expression stackValue = new StackValue(tmpStackVar);
/*  816: 734 */     Expression incrRValue = assignmentSimple.getRValue();
/*  817: 736 */     if (!(incrRValue instanceof ArithmeticOperation)) {
/*  818: 736 */       return;
/*  819:     */     }
/*  820: 737 */     ArithmeticOperation arithOp = (ArithmeticOperation)incrRValue;
/*  821: 738 */     ArithOp op = arithOp.getOp();
/*  822: 739 */     if ((!op.equals(ArithOp.PLUS)) && (!op.equals(ArithOp.MINUS))) {
/*  823: 739 */       return;
/*  824:     */     }
/*  825: 741 */     Expression lhs = arithOp.getLhs();
/*  826: 742 */     Expression rhs = arithOp.getRhs();
/*  827: 743 */     if (stackValue.equals(lhs))
/*  828:     */     {
/*  829: 744 */       if (Literal.equalsAnyOne(rhs)) {}
/*  830:     */     }
/*  831: 745 */     else if (stackValue.equals(rhs))
/*  832:     */     {
/*  833: 746 */       if (!Literal.equalsAnyOne(lhs)) {
/*  834: 746 */         return;
/*  835:     */       }
/*  836: 747 */       if (!op.equals(ArithOp.MINUS)) {}
/*  837:     */     }
/*  838:     */     else
/*  839:     */     {
/*  840: 749 */       return;
/*  841:     */     }
/*  842: 752 */     ArithmeticPostMutationOperation postMutationOperation = new ArithmeticPostMutationOperation(postIncLValue, op);
/*  843: 753 */     prior.nopOut();
/*  844: 754 */     statement.replaceStatement(new AssignmentSimple(tmp, postMutationOperation));
/*  845:     */   }
/*  846:     */   
/*  847:     */   private static boolean replacePreChangeAssignment(Op03SimpleStatement statement)
/*  848:     */   {
/*  849: 761 */     AssignmentSimple assignmentSimple = (AssignmentSimple)statement.containedStatement;
/*  850:     */     
/*  851: 763 */     LValue lValue = assignmentSimple.getCreatedLValue();
/*  852:     */     
/*  853:     */ 
/*  854: 766 */     Expression rValue = assignmentSimple.getRValue();
/*  855: 767 */     if (!(rValue instanceof ArithmeticOperation)) {
/*  856: 767 */       return false;
/*  857:     */     }
/*  858: 770 */     ArithmeticOperation arithmeticOperation = (ArithmeticOperation)rValue;
/*  859: 771 */     if (!arithmeticOperation.isMutationOf(lValue)) {
/*  860: 771 */       return false;
/*  861:     */     }
/*  862: 774 */     AbstractMutatingAssignmentExpression mutationOperation = arithmeticOperation.getMutationOf(lValue);
/*  863:     */     
/*  864: 776 */     AssignmentPreMutation res = new AssignmentPreMutation(lValue, mutationOperation);
/*  865: 777 */     statement.replaceStatement(res);
/*  866: 778 */     return true;
/*  867:     */   }
/*  868:     */   
/*  869:     */   public static void replacePrePostChangeAssignments(List<Op03SimpleStatement> statements)
/*  870:     */   {
/*  871: 782 */     List<Op03SimpleStatement> assignments = Functional.filter(statements, new TypeFilter(AssignmentSimple.class));
/*  872: 783 */     for (Op03SimpleStatement assignment : assignments) {
/*  873: 784 */       if (!replacePreChangeAssignment(assignment)) {
/*  874: 785 */         replacePostChangeAssignment(assignment);
/*  875:     */       }
/*  876:     */     }
/*  877:     */   }
/*  878:     */   
/*  879:     */   private static boolean eliminateCatchTemporary(Op03SimpleStatement catchh)
/*  880:     */   {
/*  881: 790 */     if (catchh.targets.size() != 1) {
/*  882: 790 */       return false;
/*  883:     */     }
/*  884: 791 */     Op03SimpleStatement maybeAssign = (Op03SimpleStatement)catchh.targets.get(0);
/*  885:     */     
/*  886: 793 */     CatchStatement catchStatement = (CatchStatement)catchh.getStatement();
/*  887: 794 */     LValue catching = catchStatement.getCreatedLValue();
/*  888: 796 */     if (!(catching instanceof StackSSALabel)) {
/*  889: 796 */       return false;
/*  890:     */     }
/*  891: 797 */     StackSSALabel catchingSSA = (StackSSALabel)catching;
/*  892: 798 */     if (catchingSSA.getStackEntry().getUsageCount() != 1L) {
/*  893: 798 */       return false;
/*  894:     */     }
/*  895: 800 */     while ((maybeAssign.getStatement() instanceof TryStatement)) {
/*  896: 802 */       maybeAssign = (Op03SimpleStatement)maybeAssign.targets.get(0);
/*  897:     */     }
/*  898: 804 */     WildcardMatch match = new WildcardMatch();
/*  899: 805 */     if (!match.match(new AssignmentSimple(match.getLValueWildCard("caught"), new StackValue(catchingSSA)), maybeAssign.getStatement())) {
/*  900: 807 */       return false;
/*  901:     */     }
/*  902: 811 */     catchh.replaceStatement(new CatchStatement(catchStatement.getExceptions(), match.getLValueWildCard("caught").getMatch()));
/*  903: 812 */     maybeAssign.nopOut();
/*  904: 813 */     return true;
/*  905:     */   }
/*  906:     */   
/*  907:     */   public static List<Op03SimpleStatement> eliminateCatchTemporaries(List<Op03SimpleStatement> statements)
/*  908:     */   {
/*  909: 817 */     List<Op03SimpleStatement> catches = Functional.filter(statements, new TypeFilter(CatchStatement.class));
/*  910: 818 */     boolean effect = false;
/*  911: 819 */     for (Op03SimpleStatement catchh : catches) {
/*  912: 820 */       effect |= eliminateCatchTemporary(catchh);
/*  913:     */     }
/*  914: 822 */     if (effect) {
/*  915: 824 */       statements = Cleaner.removeUnreachableCode(statements, false);
/*  916:     */     }
/*  917: 826 */     return statements;
/*  918:     */   }
/*  919:     */   
/*  920:     */   public static void removePointlessExpressionStatements(List<Op03SimpleStatement> statements)
/*  921:     */   {
/*  922: 831 */     List<Op03SimpleStatement> exrps = Functional.filter(statements, new TypeFilter(ExpressionStatement.class));
/*  923: 832 */     for (Op03SimpleStatement esc : exrps)
/*  924:     */     {
/*  925: 833 */       ExpressionStatement es = (ExpressionStatement)esc.getStatement();
/*  926: 834 */       Expression expression = es.getExpression();
/*  927: 835 */       if (((expression instanceof LValueExpression)) || ((expression instanceof StackValue)) || ((expression instanceof Literal))) {
/*  928: 838 */         esc.nopOut();
/*  929:     */       }
/*  930:     */     }
/*  931: 841 */     List<Op03SimpleStatement> sas = Functional.filter(statements, new TypeFilter(AssignmentSimple.class));
/*  932: 842 */     for (Op03SimpleStatement ass : sas)
/*  933:     */     {
/*  934: 843 */       AssignmentSimple assignmentSimple = (AssignmentSimple)ass.containedStatement;
/*  935: 844 */       LValue lValue = assignmentSimple.getCreatedLValue();
/*  936: 845 */       Expression rValue = assignmentSimple.getRValue();
/*  937: 846 */       if (rValue.getClass() == LValueExpression.class)
/*  938:     */       {
/*  939: 847 */         LValueExpression lValueExpression = (LValueExpression)rValue;
/*  940: 848 */         if (lValueExpression.getLValue().equals(lValue)) {
/*  941: 849 */           ass.nopOut();
/*  942:     */         }
/*  943:     */       }
/*  944:     */     }
/*  945:     */   }
/*  946:     */   
/*  947:     */   private static class UsageWatcher
/*  948:     */     extends AbstractExpressionRewriter
/*  949:     */   {
/*  950:     */     private final LValue needle;
/*  951: 858 */     boolean found = false;
/*  952:     */     
/*  953:     */     private UsageWatcher(LValue needle)
/*  954:     */     {
/*  955: 861 */       this.needle = needle;
/*  956:     */     }
/*  957:     */     
/*  958:     */     public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  959:     */     {
/*  960: 866 */       if (this.needle.equals(lValue)) {
/*  961: 866 */         this.found = true;
/*  962:     */       }
/*  963: 867 */       return super.rewriteExpression(lValue, ssaIdentifiers, statementContainer, flags);
/*  964:     */     }
/*  965:     */     
/*  966:     */     public boolean isFound()
/*  967:     */     {
/*  968: 871 */       return this.found;
/*  969:     */     }
/*  970:     */   }
/*  971:     */   
/*  972:     */   private static void pushPreChangeBack(Op03SimpleStatement preChange)
/*  973:     */   {
/*  974: 890 */     AssignmentPreMutation mutation = (AssignmentPreMutation)preChange.containedStatement;
/*  975: 891 */     Op03SimpleStatement current = preChange;
/*  976:     */     
/*  977: 893 */     LValue mutatedLValue = mutation.getCreatedLValue();
/*  978: 894 */     Expression lvalueExpression = new LValueExpression(mutatedLValue);
/*  979: 895 */     UsageWatcher usageWatcher = new UsageWatcher(mutatedLValue, null);
/*  980:     */     for (;;)
/*  981:     */     {
/*  982: 898 */       List<Op03SimpleStatement> sources = current.getSources();
/*  983: 899 */       if (sources.size() != 1) {
/*  984: 899 */         return;
/*  985:     */       }
/*  986: 901 */       current = (Op03SimpleStatement)sources.get(0);
/*  987:     */       
/*  988:     */ 
/*  989:     */ 
/*  990:     */ 
/*  991: 906 */       Statement innerStatement = current.getStatement();
/*  992: 907 */       if ((innerStatement instanceof AssignmentSimple))
/*  993:     */       {
/*  994: 908 */         AssignmentSimple assignmentSimple = (AssignmentSimple)innerStatement;
/*  995: 909 */         if (assignmentSimple.getRValue().equals(lvalueExpression))
/*  996:     */         {
/*  997: 910 */           LValue tgt = assignmentSimple.getCreatedLValue();
/*  998:     */           
/*  999:     */ 
/* 1000:     */ 
/* 1001: 914 */           SSAIdentifiers preChangeIdents = preChange.getSSAIdentifiers();
/* 1002: 915 */           SSAIdentifiers assignIdents = current.getSSAIdentifiers();
/* 1003: 916 */           if (!preChangeIdents.isValidReplacement(tgt, assignIdents)) {
/* 1004: 917 */             return;
/* 1005:     */           }
/* 1006: 919 */           assignIdents.setKnownIdentifierOnExit(mutatedLValue, preChangeIdents.getSSAIdentOnExit(mutatedLValue));
/* 1007: 920 */           current.replaceStatement(new AssignmentSimple(tgt, mutation.getPostMutation()));
/* 1008: 921 */           preChange.nopOut();
/* 1009: 922 */           return;
/* 1010:     */         }
/* 1011:     */       }
/* 1012: 925 */       current.rewrite(usageWatcher);
/* 1013: 926 */       if (usageWatcher.isFound()) {
/* 1014: 930 */         return;
/* 1015:     */       }
/* 1016:     */     }
/* 1017:     */   }
/* 1018:     */   
/* 1019:     */   private static class StatementCanBePostMutation
/* 1020:     */     implements Predicate<Op03SimpleStatement>
/* 1021:     */   {
/* 1022:     */     public boolean test(Op03SimpleStatement in)
/* 1023:     */     {
/* 1024: 938 */       AssignmentPreMutation assignmentPreMutation = (AssignmentPreMutation)in.getStatement();
/* 1025: 939 */       LValue lValue = assignmentPreMutation.getCreatedLValue();
/* 1026: 940 */       return (assignmentPreMutation.isSelfMutatingOp1(lValue, ArithOp.PLUS)) || (assignmentPreMutation.isSelfMutatingOp1(lValue, ArithOp.MINUS));
/* 1027:     */     }
/* 1028:     */   }
/* 1029:     */   
/* 1030:     */   public static void pushPreChangeBack(List<Op03SimpleStatement> statements)
/* 1031:     */   {
/* 1032: 946 */     List<Op03SimpleStatement> assignments = Functional.filter(statements, new TypeFilter(AssignmentPreMutation.class));
/* 1033: 947 */     assignments = Functional.filter(assignments, new StatementCanBePostMutation(null));
/* 1034: 948 */     if (assignments.isEmpty()) {
/* 1035: 948 */       return;
/* 1036:     */     }
/* 1037: 950 */     for (Op03SimpleStatement assignment : assignments) {
/* 1038: 951 */       pushPreChangeBack(assignment);
/* 1039:     */     }
/* 1040:     */   }
/* 1041:     */   
/* 1042:     */   public static void condenseConstruction(DCCommonState state, Method method, List<Op03SimpleStatement> statements, AnonymousClassUsage anonymousClassUsage)
/* 1043:     */   {
/* 1044: 969 */     CreationCollector creationCollector = new CreationCollector(anonymousClassUsage);
/* 1045: 970 */     for (Op03SimpleStatement statement : statements) {
/* 1046: 971 */       statement.findCreation(creationCollector);
/* 1047:     */     }
/* 1048: 973 */     creationCollector.condenseConstructions(method, state);
/* 1049:     */   }
/* 1050:     */   
/* 1051:     */   public static boolean condenseConditionals(List<Op03SimpleStatement> statements)
/* 1052:     */   {
/* 1053:1009 */     boolean effect = false;
/* 1054:1010 */     for (int x = 0; x < statements.size(); x++)
/* 1055:     */     {
/* 1056:1011 */       boolean retry = false;
/* 1057:     */       do
/* 1058:     */       {
/* 1059:1013 */         retry = false;
/* 1060:1014 */         Op03SimpleStatement op03SimpleStatement = (Op03SimpleStatement)statements.get(x);
/* 1061:     */         
/* 1062:     */ 
/* 1063:1017 */         Statement inner = op03SimpleStatement.getStatement();
/* 1064:1018 */         if ((inner instanceof IfStatement))
/* 1065:     */         {
/* 1066:1019 */           Op03SimpleStatement fallThrough = (Op03SimpleStatement)op03SimpleStatement.getTargets().get(0);
/* 1067:1020 */           Op03SimpleStatement taken = (Op03SimpleStatement)op03SimpleStatement.getTargets().get(1);
/* 1068:1021 */           Statement fallthroughInner = fallThrough.getStatement();
/* 1069:1022 */           Statement takenInner = taken.getStatement();
/* 1070:     */           
/* 1071:1024 */           boolean takenJumpBy1 = (x < statements.size() - 2) && (statements.get(x + 2) == taken);
/* 1072:1026 */           if ((fallthroughInner instanceof IfStatement))
/* 1073:     */           {
/* 1074:1027 */             Op03SimpleStatement sndIf = fallThrough;
/* 1075:1028 */             Op03SimpleStatement sndTaken = (Op03SimpleStatement)sndIf.getTargets().get(1);
/* 1076:1029 */             Op03SimpleStatement sndFallThrough = (Op03SimpleStatement)sndIf.getTargets().get(0);
/* 1077:     */             
/* 1078:1031 */             retry = condenseIfs(op03SimpleStatement, sndIf, taken, sndTaken, sndFallThrough, false);
/* 1079:     */           }
/* 1080:1036 */           else if ((fallthroughInner.getClass() == GotoStatement.class) && (takenJumpBy1) && ((takenInner instanceof IfStatement)))
/* 1081:     */           {
/* 1082:1046 */             Op03SimpleStatement negatedTaken = (Op03SimpleStatement)fallThrough.getTargets().get(0);
/* 1083:1047 */             Op03SimpleStatement sndIf = (Op03SimpleStatement)statements.get(x + 2);
/* 1084:1048 */             Op03SimpleStatement sndTaken = (Op03SimpleStatement)sndIf.getTargets().get(1);
/* 1085:1049 */             Op03SimpleStatement sndFallThrough = (Op03SimpleStatement)sndIf.getTargets().get(0);
/* 1086:     */             
/* 1087:1051 */             retry = condenseIfs(op03SimpleStatement, sndIf, negatedTaken, sndTaken, sndFallThrough, true);
/* 1088:     */           }
/* 1089:1060 */           if (retry)
/* 1090:     */           {
/* 1091:1061 */             effect = true;
/* 1092:     */             do
/* 1093:     */             {
/* 1094:1063 */               x--;
/* 1095:1064 */             } while ((((Op03SimpleStatement)statements.get(x)).isAgreedNop()) && (x > 0));
/* 1096:     */           }
/* 1097:     */         }
/* 1098:1066 */       } while (retry);
/* 1099:     */     }
/* 1100:1068 */     return effect;
/* 1101:     */   }
/* 1102:     */   
/* 1103:     */   private static boolean condenseIfs(Op03SimpleStatement if1, Op03SimpleStatement if2, Op03SimpleStatement taken1, Op03SimpleStatement taken2, Op03SimpleStatement fall2, boolean negated1)
/* 1104:     */   {
/* 1105:1085 */     if (if2.sources.size() != 1) {
/* 1106:1086 */       return false;
/* 1107:     */     }
/* 1108:     */     boolean negate1;
/* 1109:1092 */     if (taken1 == fall2)
/* 1110:     */     {
/* 1111:1093 */       BoolOp resOp = BoolOp.AND;
/* 1112:1094 */       negate1 = true;
/* 1113:     */     }
/* 1114:     */     else
/* 1115:     */     {
/* 1116:     */       boolean negate1;
/* 1117:1095 */       if (taken1 == taken2)
/* 1118:     */       {
/* 1119:1096 */         BoolOp resOp = BoolOp.OR;
/* 1120:1097 */         negate1 = false;
/* 1121:     */       }
/* 1122:     */       else
/* 1123:     */       {
/* 1124:1099 */         Statement fall2stm = fall2.getStatement();
/* 1125:     */         boolean negate1;
/* 1126:1100 */         if ((fall2stm.getClass() == GotoStatement.class) && (fall2.getTargets().get(0) == taken1))
/* 1127:     */         {
/* 1128:1101 */           BoolOp resOp = BoolOp.AND;
/* 1129:1102 */           negate1 = true;
/* 1130:     */         }
/* 1131:     */         else
/* 1132:     */         {
/* 1133:1104 */           return false;
/* 1134:     */         }
/* 1135:     */       }
/* 1136:     */     }
/* 1137:     */     boolean negate1;
/* 1138:     */     BoolOp resOp;
/* 1139:1108 */     ConditionalExpression cond1 = ((IfStatement)if1.getStatement()).getCondition();
/* 1140:1109 */     ConditionalExpression cond2 = ((IfStatement)if2.getStatement()).getCondition();
/* 1141:1110 */     if (negated1) {
/* 1142:1111 */       negate1 = !negate1;
/* 1143:     */     }
/* 1144:1113 */     if (negate1) {
/* 1145:1113 */       cond1 = cond1.getNegated();
/* 1146:     */     }
/* 1147:1114 */     ConditionalExpression combined = new BooleanOperation(cond1, cond2, resOp);
/* 1148:1115 */     combined = combined.simplify();
/* 1149:     */     
/* 1150:     */ 
/* 1151:1118 */     if2.replaceStatement(new IfStatement(combined));
/* 1152:1121 */     for (Op03SimpleStatement target1 : if1.getTargets()) {
/* 1153:1122 */       target1.removeSource(if1);
/* 1154:     */     }
/* 1155:1124 */     if1.targets.clear();
/* 1156:1125 */     for (Op03SimpleStatement source1 : if2.getSources()) {
/* 1157:1126 */       source1.removeGotoTarget(if2);
/* 1158:     */     }
/* 1159:1128 */     if2.sources.clear();
/* 1160:1129 */     if1.targets.add(if2);
/* 1161:1130 */     if2.sources.add(if1);
/* 1162:     */     
/* 1163:1132 */     if1.nopOutConditional();
/* 1164:     */     
/* 1165:1134 */     return true;
/* 1166:     */   }
/* 1167:     */   
/* 1168:     */   public static void simplifyConditionals(List<Op03SimpleStatement> statements, boolean aggressive)
/* 1169:     */   {
/* 1170:1138 */     for (Op03SimpleStatement statement : statements) {
/* 1171:1139 */       statement.simplifyConditional();
/* 1172:     */     }
/* 1173:     */     ExpressionRewriter conditionalSimplifier;
/* 1174:1143 */     if (aggressive)
/* 1175:     */     {
/* 1176:1144 */       conditionalSimplifier = new ConditionalSimplifyingRewriter();
/* 1177:1145 */       for (Op03SimpleStatement statement : statements) {
/* 1178:1146 */         statement.rewrite(conditionalSimplifier);
/* 1179:     */       }
/* 1180:     */     }
/* 1181:     */   }
/* 1182:     */   
/* 1183:     */   public static boolean condenseConditionals2(List<Op03SimpleStatement> statements)
/* 1184:     */   {
/* 1185:1153 */     List<Op03SimpleStatement> ifStatements = Functional.filter(statements, new TypeFilter(IfStatement.class));
/* 1186:1154 */     boolean result = false;
/* 1187:1155 */     for (Op03SimpleStatement ifStatement : ifStatements) {
/* 1188:1157 */       if (condenseConditional2_type1(ifStatement, statements)) {
/* 1189:1158 */         result = true;
/* 1190:1159 */       } else if (condenseConditional2_type2(ifStatement, statements)) {
/* 1191:1160 */         result = true;
/* 1192:     */       }
/* 1193:     */     }
/* 1194:1163 */     return result;
/* 1195:     */   }
/* 1196:     */   
/* 1197:     */   private static boolean normalizeDupAssigns_type1(Op03SimpleStatement stm)
/* 1198:     */   {
/* 1199:1175 */     Statement inner1 = stm.getStatement();
/* 1200:1176 */     if (!(inner1 instanceof AssignmentSimple)) {
/* 1201:1176 */       return false;
/* 1202:     */     }
/* 1203:1177 */     List<Op03SimpleStatement> tgts = stm.getTargets();
/* 1204:1178 */     if (tgts.size() != 1) {
/* 1205:1178 */       return false;
/* 1206:     */     }
/* 1207:1179 */     Op03SimpleStatement next = (Op03SimpleStatement)tgts.get(0);
/* 1208:1180 */     Statement inner2 = next.getStatement();
/* 1209:1181 */     if (!(inner2 instanceof AssignmentSimple)) {
/* 1210:1181 */       return false;
/* 1211:     */     }
/* 1212:1183 */     if (next.getTargets().size() != 1) {
/* 1213:1183 */       return false;
/* 1214:     */     }
/* 1215:1184 */     Op03SimpleStatement after = (Op03SimpleStatement)next.getTargets().get(0);
/* 1216:1185 */     if (!(after.getStatement() instanceof IfStatement)) {
/* 1217:1185 */       return false;
/* 1218:     */     }
/* 1219:1187 */     AssignmentSimple a1 = (AssignmentSimple)inner1;
/* 1220:1188 */     AssignmentSimple a2 = (AssignmentSimple)inner2;
/* 1221:     */     
/* 1222:1190 */     LValue l1 = a1.getCreatedLValue();
/* 1223:1191 */     LValue l2 = a2.getCreatedLValue();
/* 1224:1192 */     Expression r1 = a1.getRValue();
/* 1225:1193 */     Expression r2 = a2.getRValue();
/* 1226:1195 */     if (!(r2 instanceof StackValue)) {
/* 1227:1195 */       return false;
/* 1228:     */     }
/* 1229:1196 */     StackSSALabel s2 = ((StackValue)r2).getStackValue();
/* 1230:1197 */     if (!l1.equals(s2)) {
/* 1231:1197 */       return false;
/* 1232:     */     }
/* 1233:1198 */     next.nopOut();
/* 1234:     */     
/* 1235:1200 */     stm.ssaIdentifiers = next.ssaIdentifiers;
/* 1236:1201 */     stm.replaceStatement(new AssignmentSimple(l1, new AssignmentExpression(l2, r1)));
/* 1237:1202 */     return true;
/* 1238:     */   }
/* 1239:     */   
/* 1240:     */   public static boolean normalizeDupAssigns(List<Op03SimpleStatement> statements)
/* 1241:     */   {
/* 1242:1206 */     List<Op03SimpleStatement> assignStatements = Functional.filter(statements, new TypeFilter(AssignmentSimple.class));
/* 1243:1207 */     boolean result = false;
/* 1244:1208 */     for (Op03SimpleStatement assign : assignStatements) {
/* 1245:1209 */       if (normalizeDupAssigns_type1(assign)) {
/* 1246:1210 */         result = true;
/* 1247:     */       }
/* 1248:     */     }
/* 1249:1213 */     return result;
/* 1250:     */   }
/* 1251:     */   
/* 1252:     */   private static void replaceReturningIf(Op03SimpleStatement ifStatement, boolean aggressive)
/* 1253:     */   {
/* 1254:1217 */     if (ifStatement.containedStatement.getClass() != IfStatement.class) {
/* 1255:1217 */       return;
/* 1256:     */     }
/* 1257:1218 */     IfStatement innerIf = (IfStatement)ifStatement.containedStatement;
/* 1258:1219 */     Op03SimpleStatement tgt = (Op03SimpleStatement)ifStatement.getTargets().get(1);
/* 1259:1220 */     Op03SimpleStatement origtgt = tgt;
/* 1260:1221 */     boolean requireJustOneSource = !aggressive;
/* 1261:     */     for (;;)
/* 1262:     */     {
/* 1263:1223 */       Op03SimpleStatement next = Misc.followNopGoto(tgt, requireJustOneSource, aggressive);
/* 1264:1224 */       if (next == tgt) {
/* 1265:     */         break;
/* 1266:     */       }
/* 1267:1225 */       tgt = next;
/* 1268:     */     }
/* 1269:1227 */     Statement tgtStatement = tgt.containedStatement;
/* 1270:1228 */     if ((tgtStatement instanceof ReturnStatement)) {
/* 1271:1229 */       ifStatement.replaceStatement(new IfExitingStatement(innerIf.getCondition(), tgtStatement));
/* 1272:     */     } else {
/* 1273:1231 */       return;
/* 1274:     */     }
/* 1275:1233 */     origtgt.removeSource(ifStatement);
/* 1276:1234 */     ifStatement.removeTarget(origtgt);
/* 1277:     */   }
/* 1278:     */   
/* 1279:     */   private static void replaceReturningGoto(Op03SimpleStatement gotoStatement, boolean aggressive)
/* 1280:     */   {
/* 1281:1238 */     if (gotoStatement.containedStatement.getClass() != GotoStatement.class) {
/* 1282:1238 */       return;
/* 1283:     */     }
/* 1284:1239 */     Op03SimpleStatement tgt = (Op03SimpleStatement)gotoStatement.getTargets().get(0);
/* 1285:1240 */     Op03SimpleStatement origtgt = tgt;
/* 1286:1241 */     boolean requireJustOneSource = !aggressive;
/* 1287:     */     for (;;)
/* 1288:     */     {
/* 1289:1243 */       Op03SimpleStatement next = Misc.followNopGoto(tgt, requireJustOneSource, aggressive);
/* 1290:1244 */       if (next == tgt) {
/* 1291:     */         break;
/* 1292:     */       }
/* 1293:1245 */       tgt = next;
/* 1294:     */     }
/* 1295:1247 */     Statement tgtStatement = tgt.containedStatement;
/* 1296:1248 */     if ((tgtStatement instanceof ReturnStatement)) {
/* 1297:1249 */       gotoStatement.replaceStatement(tgtStatement);
/* 1298:     */     } else {
/* 1299:1251 */       return;
/* 1300:     */     }
/* 1301:1253 */     origtgt.removeSource(gotoStatement);
/* 1302:1254 */     gotoStatement.removeTarget(origtgt);
/* 1303:     */   }
/* 1304:     */   
/* 1305:     */   public static void replaceReturningIfs(List<Op03SimpleStatement> statements, boolean aggressive)
/* 1306:     */   {
/* 1307:1258 */     List<Op03SimpleStatement> ifStatements = Functional.filter(statements, new TypeFilter(IfStatement.class));
/* 1308:1259 */     for (Op03SimpleStatement ifStatement : ifStatements) {
/* 1309:1260 */       replaceReturningIf(ifStatement, aggressive);
/* 1310:     */     }
/* 1311:     */   }
/* 1312:     */   
/* 1313:     */   public static void propagateToReturn2(Method method, List<Op03SimpleStatement> statements)
/* 1314:     */   {
/* 1315:1265 */     boolean success = false;
/* 1316:1266 */     for (Op03SimpleStatement stm : statements)
/* 1317:     */     {
/* 1318:1267 */       Statement inner = stm.getStatement();
/* 1319:1269 */       if ((inner instanceof ReturnStatement)) {
/* 1320:1279 */         success |= pushReturnBack(method, stm);
/* 1321:     */       }
/* 1322:     */     }
/* 1323:1282 */     if (success) {
/* 1324:1282 */       replaceReturningIfs(statements, true);
/* 1325:     */     }
/* 1326:     */   }
/* 1327:     */   
/* 1328:     */   private static boolean pushReturnBack(Method method, Op03SimpleStatement returnStm)
/* 1329:     */   {
/* 1330:1287 */     ReturnStatement returnStatement = (ReturnStatement)returnStm.getStatement();
/* 1331:1288 */     List<Op03SimpleStatement> replaceWithReturn = ListFactory.newList();
/* 1332:     */     
/* 1333:1290 */     new GraphVisitorDFS(returnStm.getSources(), new BinaryProcedure()
/* 1334:     */     {
/* 1335:     */       public void call(Op03SimpleStatement arg1, GraphVisitor<Op03SimpleStatement> arg2)
/* 1336:     */       {
/* 1337:1293 */         Class<?> clazz = arg1.getStatement().getClass();
/* 1338:1294 */         if ((clazz == CommentStatement.class) || (clazz == Nop.class) || (clazz == DoStatement.class))
/* 1339:     */         {
/* 1340:1297 */           arg2.enqueue(arg1.getSources());
/* 1341:     */         }
/* 1342:1298 */         else if (clazz == WhileStatement.class)
/* 1343:     */         {
/* 1344:1300 */           WhileStatement whileStatement = (WhileStatement)arg1.getStatement();
/* 1345:1301 */           if (whileStatement.getCondition() == null)
/* 1346:     */           {
/* 1347:1302 */             arg2.enqueue(arg1.getSources());
/* 1348:1303 */             this.val$replaceWithReturn.add(arg1);
/* 1349:     */           }
/* 1350:     */         }
/* 1351:1305 */         else if (clazz == GotoStatement.class)
/* 1352:     */         {
/* 1353:1306 */           arg2.enqueue(arg1.getSources());
/* 1354:1307 */           this.val$replaceWithReturn.add(arg1);
/* 1355:     */         }
/* 1356:     */       }
/* 1357:     */     }).process();
/* 1358:1312 */     if (replaceWithReturn.isEmpty()) {
/* 1359:1312 */       return false;
/* 1360:     */     }
/* 1361:1314 */     CloneHelper cloneHelper = new CloneHelper();
/* 1362:1315 */     for (Op03SimpleStatement remove : replaceWithReturn)
/* 1363:     */     {
/* 1364:1316 */       remove.replaceStatement((Statement)returnStatement.deepClone(cloneHelper));
/* 1365:1317 */       for (Op03SimpleStatement tgt : remove.getTargets()) {
/* 1366:1318 */         tgt.removeSource(remove);
/* 1367:     */       }
/* 1368:1320 */       remove.targets.clear();
/* 1369:     */     }
/* 1370:1323 */     return true;
/* 1371:     */   }
/* 1372:     */   
/* 1373:     */   private static boolean condenseConditional2_type2(Op03SimpleStatement ifStatement, List<Op03SimpleStatement> allStatements)
/* 1374:     */   {
/* 1375:1331 */     Statement innerStatement = ifStatement.getStatement();
/* 1376:1332 */     if (!(innerStatement instanceof IfStatement)) {
/* 1377:1332 */       return false;
/* 1378:     */     }
/* 1379:1333 */     IfStatement innerIf = (IfStatement)innerStatement;
/* 1380:1334 */     Op03SimpleStatement tgt1 = (Op03SimpleStatement)ifStatement.targets.get(0);
/* 1381:1335 */     Op03SimpleStatement tgt2 = (Op03SimpleStatement)ifStatement.targets.get(1);
/* 1382:1336 */     if (tgt1.sources.size() != 1) {
/* 1383:1336 */       return false;
/* 1384:     */     }
/* 1385:1337 */     if (tgt2.sources.size() != 1) {
/* 1386:1337 */       return false;
/* 1387:     */     }
/* 1388:1338 */     if (tgt1.targets.size() != 1) {
/* 1389:1338 */       return false;
/* 1390:     */     }
/* 1391:1339 */     if (tgt2.targets.size() != 1) {
/* 1392:1339 */       return false;
/* 1393:     */     }
/* 1394:1340 */     Op03SimpleStatement evTgt = (Op03SimpleStatement)tgt1.targets.get(0);
/* 1395:1341 */     evTgt = Misc.followNopGoto(evTgt, true, false);
/* 1396:1342 */     Op03SimpleStatement oneSource = tgt1;
/* 1397:1343 */     if ((!evTgt.sources.contains(oneSource)) && (!evTgt.sources.contains(oneSource = (Op03SimpleStatement)oneSource.targets.get(0)))) {
/* 1398:1344 */       return false;
/* 1399:     */     }
/* 1400:1346 */     if (evTgt.sources.size() < 2) {
/* 1401:1346 */       return false;
/* 1402:     */     }
/* 1403:1347 */     if (tgt2.targets.get(0) != evTgt) {
/* 1404:1347 */       return false;
/* 1405:     */     }
/* 1406:1348 */     Statement stm1 = tgt1.getStatement();
/* 1407:1349 */     Statement stm2 = tgt2.getStatement();
/* 1408:1350 */     if ((!(stm1 instanceof AssignmentSimple)) || (!(stm2 instanceof AssignmentSimple))) {
/* 1409:1351 */       return false;
/* 1410:     */     }
/* 1411:1353 */     AssignmentSimple a1 = (AssignmentSimple)stm1;
/* 1412:1354 */     AssignmentSimple a2 = (AssignmentSimple)stm2;
/* 1413:1355 */     LValue lv = a1.getCreatedLValue();
/* 1414:1356 */     if (!lv.equals(a2.getCreatedLValue())) {
/* 1415:1356 */       return false;
/* 1416:     */     }
/* 1417:1357 */     Expression e1 = a1.getRValue();
/* 1418:1358 */     Expression e2 = a2.getRValue();
/* 1419:1359 */     ConditionalExpression condition = innerIf.getCondition().getNegated();
/* 1420:1360 */     condition = condition.simplify();
/* 1421:1361 */     ifStatement.replaceStatement(new AssignmentSimple(lv, new TernaryExpression(condition, a1.getRValue(), a2.getRValue())));
/* 1422:1362 */     oneSource.replaceStatement(new Nop());
/* 1423:1363 */     oneSource.removeTarget(evTgt);
/* 1424:1364 */     tgt2.replaceStatement(new Nop());
/* 1425:1365 */     tgt2.removeTarget(evTgt);
/* 1426:1366 */     evTgt.removeSource(oneSource);
/* 1427:1367 */     evTgt.removeSource(tgt2);
/* 1428:1368 */     evTgt.sources.add(ifStatement);
/* 1429:1369 */     for (Op03SimpleStatement tgt : ifStatement.targets) {
/* 1430:1370 */       tgt.removeSource(ifStatement);
/* 1431:     */     }
/* 1432:1372 */     ifStatement.targets.clear();
/* 1433:1373 */     ifStatement.addTarget(evTgt);
/* 1434:1374 */     tgt1.replaceStatement(new Nop());
/* 1435:1376 */     if ((lv instanceof StackSSALabel)) {
/* 1436:1377 */       ((StackSSALabel)lv).getStackEntry().decSourceCount();
/* 1437:     */     }
/* 1438:1379 */     return true;
/* 1439:     */   }
/* 1440:     */   
/* 1441:     */   private static boolean condenseConditional2_type1(Op03SimpleStatement ifStatement, List<Op03SimpleStatement> allStatements)
/* 1442:     */   {
/* 1443:1400 */     if (!(ifStatement.containedStatement instanceof IfStatement)) {
/* 1444:1400 */       return false;
/* 1445:     */     }
/* 1446:1402 */     Op03SimpleStatement taken1 = (Op03SimpleStatement)ifStatement.getTargets().get(1);
/* 1447:1403 */     Op03SimpleStatement nottaken1 = (Op03SimpleStatement)ifStatement.getTargets().get(0);
/* 1448:1404 */     if (!(nottaken1.containedStatement instanceof IfStatement)) {
/* 1449:1404 */       return false;
/* 1450:     */     }
/* 1451:1405 */     Op03SimpleStatement ifStatement2 = nottaken1;
/* 1452:1406 */     Op03SimpleStatement taken2 = (Op03SimpleStatement)ifStatement2.getTargets().get(1);
/* 1453:1407 */     Op03SimpleStatement nottaken2 = (Op03SimpleStatement)ifStatement2.getTargets().get(0);
/* 1454:1408 */     Op03SimpleStatement nottaken2Immed = nottaken2;
/* 1455:1409 */     if (nottaken2Immed.sources.size() != 1) {
/* 1456:1409 */       return false;
/* 1457:     */     }
/* 1458:1410 */     Op03SimpleStatement notTaken2Source = ifStatement2;
/* 1459:1411 */     nottaken2 = Misc.followNopGotoChain(nottaken2, true, false);
/* 1460:     */     for (;;)
/* 1461:     */     {
/* 1462:1413 */       Op03SimpleStatement nontaken2rewrite = Misc.followNopGoto(nottaken2, true, false);
/* 1463:1414 */       if (nontaken2rewrite == nottaken2) {
/* 1464:     */         break;
/* 1465:     */       }
/* 1466:1415 */       notTaken2Source = nottaken2;
/* 1467:1416 */       nottaken2 = nontaken2rewrite;
/* 1468:     */     }
/* 1469:1418 */     if (!(taken1.containedStatement instanceof IfStatement)) {
/* 1470:1418 */       return false;
/* 1471:     */     }
/* 1472:1419 */     if (taken1.sources.size() != 1) {
/* 1473:1419 */       return false;
/* 1474:     */     }
/* 1475:1420 */     Op03SimpleStatement ifStatement3 = taken1;
/* 1476:1421 */     Op03SimpleStatement taken3 = (Op03SimpleStatement)ifStatement3.getTargets().get(1);
/* 1477:1422 */     Op03SimpleStatement nottaken3 = (Op03SimpleStatement)ifStatement3.getTargets().get(0);
/* 1478:1423 */     Op03SimpleStatement nottaken3Immed = nottaken3;
/* 1479:1424 */     Op03SimpleStatement notTaken3Source = ifStatement3;
/* 1480:     */     for (;;)
/* 1481:     */     {
/* 1482:1426 */       Op03SimpleStatement nontaken3rewrite = Misc.followNopGoto(nottaken3, true, false);
/* 1483:1427 */       if (nontaken3rewrite == nottaken3) {
/* 1484:     */         break;
/* 1485:     */       }
/* 1486:1428 */       notTaken3Source = nottaken3;
/* 1487:1429 */       nottaken3 = nontaken3rewrite;
/* 1488:     */     }
/* 1489:1433 */     if (nottaken2 != nottaken3) {
/* 1490:1437 */       if ((nottaken2.getStatement() instanceof ReturnStatement))
/* 1491:     */       {
/* 1492:1438 */         if (!nottaken2.getStatement().equivalentUnder(nottaken3.getStatement(), new StatementEquivalenceConstraint(nottaken2, nottaken3))) {
/* 1493:1439 */           return false;
/* 1494:     */         }
/* 1495:     */       }
/* 1496:     */       else {
/* 1497:1442 */         return false;
/* 1498:     */       }
/* 1499:     */     }
/* 1500:1445 */     if (taken2 != taken3) {
/* 1501:1445 */       return false;
/* 1502:     */     }
/* 1503:1451 */     IfStatement if1 = (IfStatement)ifStatement.containedStatement;
/* 1504:1452 */     IfStatement if2 = (IfStatement)ifStatement2.containedStatement;
/* 1505:1453 */     IfStatement if3 = (IfStatement)ifStatement3.containedStatement;
/* 1506:     */     
/* 1507:1455 */     ConditionalExpression newCond = new BooleanExpression(new TernaryExpression(if1.getCondition().getNegated().simplify(), if2.getCondition().getNegated().simplify(), if3.getCondition().getNegated().simplify())).getNegated();
/* 1508:     */     
/* 1509:     */ 
/* 1510:     */ 
/* 1511:     */ 
/* 1512:     */ 
/* 1513:     */ 
/* 1514:     */ 
/* 1515:     */ 
/* 1516:     */ 
/* 1517:1465 */     ifStatement.replaceTarget(taken1, taken3);
/* 1518:1466 */     taken3.addSource(ifStatement);
/* 1519:1467 */     taken3.removeSource(ifStatement2);
/* 1520:1468 */     taken3.removeSource(ifStatement3);
/* 1521:     */     
/* 1522:1470 */     nottaken1.sources.remove(ifStatement);
/* 1523:1471 */     nottaken2Immed.replaceSource(ifStatement2, ifStatement);
/* 1524:1472 */     ifStatement.replaceTarget(nottaken1, nottaken2Immed);
/* 1525:     */     
/* 1526:     */ 
/* 1527:1475 */     nottaken3.removeSource(notTaken3Source);
/* 1528:     */     
/* 1529:1477 */     ifStatement2.replaceStatement(new Nop());
/* 1530:1478 */     ifStatement3.replaceStatement(new Nop());
/* 1531:1479 */     ifStatement2.removeTarget(taken3);
/* 1532:1480 */     ifStatement3.removeTarget(taken3);
/* 1533:     */     
/* 1534:1482 */     ifStatement.replaceStatement(new IfStatement(newCond));
/* 1535:1487 */     if ((nottaken2Immed.sources.size() == 1) && 
/* 1536:1488 */       (((Op03SimpleStatement)nottaken2Immed.sources.get(0)).getIndex().isBackJumpFrom(nottaken2Immed)) && 
/* 1537:1489 */       (nottaken2Immed.containedStatement.getClass() == GotoStatement.class))
/* 1538:     */     {
/* 1539:1490 */       Op03SimpleStatement nottaken2ImmedTgt = (Op03SimpleStatement)nottaken2Immed.targets.get(0);
/* 1540:1491 */       int idx = allStatements.indexOf(nottaken2Immed);
/* 1541:1492 */       int idx2 = idx + 1;
/* 1542:     */       Op03SimpleStatement next;
/* 1543:     */       for (;;)
/* 1544:     */       {
/* 1545:1494 */         next = (Op03SimpleStatement)allStatements.get(idx2);
/* 1546:1495 */         if (!(next.containedStatement instanceof Nop)) {
/* 1547:     */           break;
/* 1548:     */         }
/* 1549:1496 */         idx2++;
/* 1550:     */       }
/* 1551:1499 */       if (next == nottaken2ImmedTgt)
/* 1552:     */       {
/* 1553:1501 */         nottaken2ImmedTgt.replaceSource(nottaken2Immed, ifStatement);
/* 1554:1502 */         ifStatement.replaceTarget(nottaken2Immed, nottaken2ImmedTgt);
/* 1555:     */       }
/* 1556:     */     }
/* 1557:1510 */     return true;
/* 1558:     */   }
/* 1559:     */   
/* 1560:     */   private static boolean appropriateForIfAssignmentCollapse1(Op03SimpleStatement statement)
/* 1561:     */   {
/* 1562:1519 */     boolean extraCondSeen = false;
/* 1563:1520 */     boolean preCondAssignmentSeen = false;
/* 1564:1521 */     while (statement.sources.size() == 1)
/* 1565:     */     {
/* 1566:1522 */       Op03SimpleStatement source = (Op03SimpleStatement)statement.sources.get(0);
/* 1567:1525 */       if (statement.getIndex().isBackJumpFrom(source)) {
/* 1568:     */         break;
/* 1569:     */       }
/* 1570:1526 */       Statement contained = source.containedStatement;
/* 1571:1527 */       if ((contained instanceof AbstractAssignment))
/* 1572:     */       {
/* 1573:1528 */         preCondAssignmentSeen |= !extraCondSeen;
/* 1574:     */       }
/* 1575:     */       else
/* 1576:     */       {
/* 1577:1529 */         if (!(contained instanceof IfStatement)) {
/* 1578:     */           break;
/* 1579:     */         }
/* 1580:1530 */         extraCondSeen = true;
/* 1581:     */       }
/* 1582:1534 */       statement = source;
/* 1583:     */     }
/* 1584:1536 */     if (!preCondAssignmentSeen) {
/* 1585:1536 */       return false;
/* 1586:     */     }
/* 1587:1539 */     if (extraCondSeen) {
/* 1588:1539 */       return false;
/* 1589:     */     }
/* 1590:1541 */     InstrIndex statementIndex = statement.getIndex();
/* 1591:1542 */     for (Op03SimpleStatement source : statement.sources) {
/* 1592:1543 */       if (statementIndex.isBackJumpFrom(source)) {
/* 1593:1543 */         return true;
/* 1594:     */       }
/* 1595:     */     }
/* 1596:1545 */     return false;
/* 1597:     */   }
/* 1598:     */   
/* 1599:     */   private static boolean appropriateForIfAssignmentCollapse2(Op03SimpleStatement statement)
/* 1600:     */   {
/* 1601:1549 */     boolean extraCondSeen = false;
/* 1602:1550 */     boolean preCondAssignmentSeen = false;
/* 1603:1551 */     while (statement.sources.size() == 1)
/* 1604:     */     {
/* 1605:1552 */       Op03SimpleStatement source = (Op03SimpleStatement)statement.sources.get(0);
/* 1606:1553 */       if (source.getTargets().size() != 1) {
/* 1607:     */         break;
/* 1608:     */       }
/* 1609:1554 */       Statement contained = source.containedStatement;
/* 1610:1555 */       if ((contained instanceof AbstractAssignment)) {
/* 1611:1556 */         preCondAssignmentSeen = true;
/* 1612:     */       }
/* 1613:1558 */       statement = source;
/* 1614:     */     }
/* 1615:1560 */     if (!preCondAssignmentSeen) {
/* 1616:1560 */       return false;
/* 1617:     */     }
/* 1618:1561 */     return true;
/* 1619:     */   }
/* 1620:     */   
/* 1621:     */   private static void collapseAssignmentsIntoConditional(Op03SimpleStatement ifStatement, boolean testEclipse)
/* 1622:     */   {
/* 1623:1571 */     if ((!appropriateForIfAssignmentCollapse1(ifStatement)) && (!appropriateForIfAssignmentCollapse2(ifStatement))) {
/* 1624:1572 */       return;
/* 1625:     */     }
/* 1626:1573 */     IfStatement innerIf = (IfStatement)ifStatement.containedStatement;
/* 1627:1574 */     ConditionalExpression conditionalExpression = innerIf.getCondition();
/* 1628:     */     
/* 1629:     */ 
/* 1630:     */ 
/* 1631:     */ 
/* 1632:     */ 
/* 1633:     */ 
/* 1634:     */ 
/* 1635:     */ 
/* 1636:     */ 
/* 1637:     */ 
/* 1638:     */ 
/* 1639:     */ 
/* 1640:     */ 
/* 1641:     */ 
/* 1642:     */ 
/* 1643:     */ 
/* 1644:     */ 
/* 1645:     */ 
/* 1646:     */ 
/* 1647:     */ 
/* 1648:     */ 
/* 1649:     */ 
/* 1650:1597 */     boolean eclipseHeuristic = (testEclipse) && (((Op03SimpleStatement)ifStatement.getTargets().get(1)).getIndex().isBackJumpFrom(ifStatement));
/* 1651:1598 */     if (!eclipseHeuristic)
/* 1652:     */     {
/* 1653:1599 */       Op03SimpleStatement statement = ifStatement;
/* 1654:1600 */       Set<Op03SimpleStatement> visited = SetFactory.newSet();
/* 1655:     */       Statement opStatement;
/* 1656:     */       do
/* 1657:     */       {
/* 1658:     */         InstrIndex statementIndex;
/* 1659:1603 */         if (statement.sources.size() > 1)
/* 1660:     */         {
/* 1661:1607 */           statementIndex = statement.index;
/* 1662:1608 */           for (Op03SimpleStatement source : statement.sources) {
/* 1663:1609 */             if (statementIndex.isBackJumpFrom(source)) {
/* 1664:     */               break label232;
/* 1665:     */             }
/* 1666:     */           }
/* 1667:     */         }
/* 1668:1614 */         if (statement.sources.isEmpty()) {
/* 1669:     */           break;
/* 1670:     */         }
/* 1671:1617 */         statement = (Op03SimpleStatement)statement.sources.get(0);
/* 1672:1618 */         if (!visited.add(statement)) {
/* 1673:1619 */           return;
/* 1674:     */         }
/* 1675:1621 */         opStatement = statement.getStatement();
/* 1676:1622 */         if ((opStatement instanceof IfStatement)) {
/* 1677:     */           break;
/* 1678:     */         }
/* 1679:1623 */       } while (((opStatement instanceof Nop)) || 
/* 1680:1624 */         ((opStatement instanceof AbstractAssignment)));
/* 1681:1625 */       return;
/* 1682:     */     }
/* 1683:     */     label232:
/* 1684:1630 */     Op03SimpleStatement previousSource = null;
/* 1685:1631 */     while (ifStatement.sources.size() == 1)
/* 1686:     */     {
/* 1687:1632 */       Op03SimpleStatement source = (Op03SimpleStatement)ifStatement.sources.get(0);
/* 1688:1633 */       if (source == previousSource) {
/* 1689:1633 */         return;
/* 1690:     */       }
/* 1691:1634 */       previousSource = source;
/* 1692:1635 */       if (!(source.containedStatement instanceof AbstractAssignment)) {
/* 1693:1635 */         return;
/* 1694:     */       }
/* 1695:1636 */       LValue lValue = source.getCreatedLValue();
/* 1696:1637 */       if ((lValue instanceof StackSSALabel)) {
/* 1697:1637 */         return;
/* 1698:     */       }
/* 1699:1640 */       LValueUsageCollectorSimple lvc = new LValueUsageCollectorSimple();
/* 1700:     */       
/* 1701:     */ 
/* 1702:1643 */       conditionalExpression.collectUsedLValues(lvc);
/* 1703:1644 */       if (!lvc.isUsed(lValue)) {
/* 1704:1644 */         return;
/* 1705:     */       }
/* 1706:1645 */       AbstractAssignment assignment = (AbstractAssignment)source.containedStatement;
/* 1707:     */       
/* 1708:1647 */       AbstractAssignmentExpression assignmentExpression = assignment.getInliningExpression();
/* 1709:1648 */       LValueUsageCollectorSimple assignmentLVC = new LValueUsageCollectorSimple();
/* 1710:1649 */       assignmentExpression.collectUsedLValues(assignmentLVC);
/* 1711:1650 */       Set<LValue> used = SetFactory.newSet(assignmentLVC.getUsedLValues());
/* 1712:1651 */       used.remove(lValue);
/* 1713:1652 */       Set<LValue> usedComparison = SetFactory.newSet(lvc.getUsedLValues());
/* 1714:     */       
/* 1715:     */ 
/* 1716:     */ 
/* 1717:     */ 
/* 1718:     */ 
/* 1719:1658 */       SSAIdentifiers<LValue> beforeSSA = source.getSSAIdentifiers();
/* 1720:1659 */       SSAIdentifiers<LValue> afterSSA = ifStatement.getSSAIdentifiers();
/* 1721:     */       
/* 1722:1661 */       Set<LValue> intersection = SetUtil.intersectionOrNull(used, usedComparison);
/* 1723:1662 */       if (intersection != null) {
/* 1724:1664 */         for (LValue intersect : intersection) {
/* 1725:1665 */           if (!afterSSA.isValidReplacement(intersect, beforeSSA)) {
/* 1726:1666 */             return;
/* 1727:     */           }
/* 1728:     */         }
/* 1729:     */       }
/* 1730:1671 */       if (!afterSSA.isValidReplacement(lValue, beforeSSA)) {
/* 1731:1671 */         return;
/* 1732:     */       }
/* 1733:1672 */       LValueAssignmentExpressionRewriter rewriter = new LValueAssignmentExpressionRewriter(lValue, assignmentExpression, source);
/* 1734:1673 */       Expression replacement = rewriter.rewriteExpression(conditionalExpression, ifStatement.getSSAIdentifiers(), ifStatement, ExpressionRewriterFlags.LVALUE);
/* 1735:1674 */       if (replacement == null) {
/* 1736:1674 */         return;
/* 1737:     */       }
/* 1738:1675 */       if (!(replacement instanceof ConditionalExpression)) {
/* 1739:1675 */         return;
/* 1740:     */       }
/* 1741:1676 */       innerIf.setCondition((ConditionalExpression)replacement);
/* 1742:     */     }
/* 1743:     */   }
/* 1744:     */   
/* 1745:     */   public static void collapseAssignmentsIntoConditionals(List<Op03SimpleStatement> statements, Options options)
/* 1746:     */   {
/* 1747:1698 */     List<Op03SimpleStatement> ifStatements = Functional.filter(statements, new TypeFilter(IfStatement.class));
/* 1748:1699 */     boolean testEclipse = ((Boolean)options.getOption(OptionsImpl.ECLIPSE)).booleanValue();
/* 1749:1700 */     for (Op03SimpleStatement statement : ifStatements) {
/* 1750:1701 */       collapseAssignmentsIntoConditional(statement, testEclipse);
/* 1751:     */     }
/* 1752:     */   }
/* 1753:     */   
/* 1754:     */   private static boolean movableJump(JumpType jumpType)
/* 1755:     */   {
/* 1756:1707 */     switch (10.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$utils$JumpType[jumpType.ordinal()])
/* 1757:     */     {
/* 1758:     */     case 1: 
/* 1759:     */     case 2: 
/* 1760:     */     case 3: 
/* 1761:1711 */       return false;
/* 1762:     */     }
/* 1763:1713 */     return true;
/* 1764:     */   }
/* 1765:     */   
/* 1766:     */   public static void removePointlessJumps(List<Op03SimpleStatement> statements)
/* 1767:     */   {
/* 1768:1734 */     int size = statements.size() - 1;
/* 1769:1735 */     for (int x = 0; x < size - 1; x++)
/* 1770:     */     {
/* 1771:1736 */       Op03SimpleStatement a = (Op03SimpleStatement)statements.get(x);
/* 1772:1737 */       Op03SimpleStatement b = (Op03SimpleStatement)statements.get(x + 1);
/* 1773:1738 */       if ((a.containedStatement.getClass() == GotoStatement.class) && (b.containedStatement.getClass() == GotoStatement.class) && (a.targets.get(0) == b.targets.get(0)) && (a.getBlockIdentifiers().equals(b.getBlockIdentifiers())))
/* 1774:     */       {
/* 1775:1744 */         Op03SimpleStatement realTgt = (Op03SimpleStatement)a.targets.get(0);
/* 1776:1745 */         realTgt.removeSource(a);
/* 1777:1746 */         a.replaceTarget(realTgt, b);
/* 1778:1747 */         b.addSource(a);
/* 1779:1748 */         a.nopOut();
/* 1780:     */       }
/* 1781:     */     }
/* 1782:1754 */     for (int x = 0; x < size - 1; x++)
/* 1783:     */     {
/* 1784:1755 */       Op03SimpleStatement maybeJump = (Op03SimpleStatement)statements.get(x);
/* 1785:1756 */       if ((maybeJump.containedStatement.getClass() == GotoStatement.class) && (maybeJump.getJumpType() != JumpType.BREAK) && (maybeJump.targets.size() == 1) && (maybeJump.targets.get(0) == statements.get(x + 1))) {
/* 1786:1761 */         if (maybeJump.getBlockIdentifiers().equals(((Op03SimpleStatement)statements.get(x + 1)).getBlockIdentifiers()))
/* 1787:     */         {
/* 1788:1762 */           maybeJump.nopOut();
/* 1789:     */         }
/* 1790:     */         else
/* 1791:     */         {
/* 1792:1765 */           Set<BlockIdentifier> changes = SetUtil.difference(maybeJump.getBlockIdentifiers(), ((Op03SimpleStatement)statements.get(x + 1)).getBlockIdentifiers());
/* 1793:1766 */           boolean ok = true;
/* 1794:1767 */           for (BlockIdentifier change : changes) {
/* 1795:1768 */             if (change.getBlockType().isLoop())
/* 1796:     */             {
/* 1797:1769 */               ok = false;
/* 1798:1770 */               break;
/* 1799:     */             }
/* 1800:     */           }
/* 1801:1773 */           if (ok) {
/* 1802:1774 */             maybeJump.nopOut();
/* 1803:     */           }
/* 1804:     */         }
/* 1805:     */       }
/* 1806:     */     }
/* 1807:1780 */     for (Op03SimpleStatement statement : statements)
/* 1808:     */     {
/* 1809:1781 */       Statement innerStatement = statement.getStatement();
/* 1810:1782 */       if (((innerStatement instanceof JumpingStatement)) && (statement.getSources().size() == 1) && (statement.getTargets().size() == 1))
/* 1811:     */       {
/* 1812:1785 */         Op03SimpleStatement prior = (Op03SimpleStatement)statement.getSources().get(0);
/* 1813:1786 */         Statement innerPrior = prior.getStatement();
/* 1814:1787 */         if ((innerPrior instanceof JumpingStatement))
/* 1815:     */         {
/* 1816:1788 */           JumpingStatement jumpInnerPrior = (JumpingStatement)innerPrior;
/* 1817:1789 */           Statement jumpingInnerPriorTarget = jumpInnerPrior.getJumpTarget();
/* 1818:1790 */           if ((jumpingInnerPriorTarget == innerStatement) && (movableJump(jumpInnerPrior.getJumpType()))) {
/* 1819:1792 */             statement.nopOut();
/* 1820:     */           }
/* 1821:     */         }
/* 1822:     */       }
/* 1823:     */     }
/* 1824:1801 */     for (int x = statements.size() - 1; x >= 0; x--)
/* 1825:     */     {
/* 1826:1802 */       Op03SimpleStatement statement = (Op03SimpleStatement)statements.get(x);
/* 1827:1803 */       Statement innerStatement = statement.getStatement();
/* 1828:1804 */       if (innerStatement.getClass() == GotoStatement.class)
/* 1829:     */       {
/* 1830:1805 */         GotoStatement innerGoto = (GotoStatement)innerStatement;
/* 1831:1806 */         if (innerGoto.getJumpType() != JumpType.BREAK)
/* 1832:     */         {
/* 1833:1807 */           Op03SimpleStatement target = (Op03SimpleStatement)statement.targets.get(0);
/* 1834:1808 */           Op03SimpleStatement ultimateTarget = Misc.followNopGotoChain(target, false, false);
/* 1835:1809 */           if (target != ultimateTarget)
/* 1836:     */           {
/* 1837:1810 */             ultimateTarget = maybeMoveTarget(ultimateTarget, statement, statements);
/* 1838:1811 */             target.removeSource(statement);
/* 1839:1812 */             statement.replaceTarget(target, ultimateTarget);
/* 1840:1813 */             ultimateTarget.addSource(statement);
/* 1841:     */           }
/* 1842:     */         }
/* 1843:     */       }
/* 1844:1815 */       else if (innerStatement.getClass() == IfStatement.class)
/* 1845:     */       {
/* 1846:1816 */         IfStatement ifStatement = (IfStatement)innerStatement;
/* 1847:1817 */         if (movableJump(ifStatement.getJumpType()))
/* 1848:     */         {
/* 1849:1818 */           Op03SimpleStatement target = (Op03SimpleStatement)statement.targets.get(1);
/* 1850:1819 */           Op03SimpleStatement ultimateTarget = Misc.followNopGotoChain(target, false, false);
/* 1851:1820 */           if (target != ultimateTarget)
/* 1852:     */           {
/* 1853:1821 */             ultimateTarget = maybeMoveTarget(ultimateTarget, statement, statements);
/* 1854:1822 */             target.removeSource(statement);
/* 1855:1823 */             statement.replaceTarget(target, ultimateTarget);
/* 1856:1824 */             ultimateTarget.addSource(statement);
/* 1857:     */           }
/* 1858:     */         }
/* 1859:     */       }
/* 1860:     */     }
/* 1861:     */   }
/* 1862:     */   
/* 1863:     */   private static void extractExceptionJumps(Op03SimpleStatement tryi, List<Op03SimpleStatement> in)
/* 1864:     */   {
/* 1865:1856 */     List<Op03SimpleStatement> tryTargets = tryi.getTargets();
/* 1866:     */     
/* 1867:     */ 
/* 1868:     */ 
/* 1869:     */ 
/* 1870:1861 */     Op03SimpleStatement uniqueForwardTarget = null;
/* 1871:1862 */     Set<BlockIdentifier> relevantBlocks = SetFactory.newSet();
/* 1872:1863 */     Op03SimpleStatement lastEnd = null;
/* 1873:1864 */     int lpidx = 0;
/* 1874:1865 */     for (Op03SimpleStatement tgt : tryTargets)
/* 1875:     */     {
/* 1876:1866 */       BlockIdentifier block = getBlockStart((lpidx++ == 0 ? tryi : tgt).getStatement());
/* 1877:1867 */       if (block == null) {
/* 1878:1867 */         return;
/* 1879:     */       }
/* 1880:1868 */       relevantBlocks.add(block);
/* 1881:1869 */       Op03SimpleStatement lastStatement = getLastContiguousBlockStatement(block, in, tgt);
/* 1882:1870 */       if (lastStatement == null) {
/* 1883:1870 */         return;
/* 1884:     */       }
/* 1885:1871 */       if (lastStatement.getStatement().getClass() == GotoStatement.class)
/* 1886:     */       {
/* 1887:1872 */         Op03SimpleStatement lastTgt = (Op03SimpleStatement)lastStatement.getTargets().get(0);
/* 1888:1873 */         if (uniqueForwardTarget == null) {
/* 1889:1874 */           uniqueForwardTarget = lastTgt;
/* 1890:1875 */         } else if (uniqueForwardTarget != lastTgt) {
/* 1891:1875 */           return;
/* 1892:     */         }
/* 1893:     */       }
/* 1894:1877 */       lastEnd = lastStatement;
/* 1895:     */     }
/* 1896:1879 */     if (uniqueForwardTarget == null) {
/* 1897:1879 */       return;
/* 1898:     */     }
/* 1899:1884 */     if (!uniqueForwardTarget.getBlockIdentifiers().equals(tryi.getBlockIdentifiers())) {
/* 1900:1884 */       return;
/* 1901:     */     }
/* 1902:1891 */     int idx = in.indexOf(lastEnd);
/* 1903:1892 */     if (idx >= in.size() - 1) {
/* 1904:1892 */       return;
/* 1905:     */     }
/* 1906:1893 */     Op03SimpleStatement next = (Op03SimpleStatement)in.get(idx + 1);
/* 1907:1894 */     if (next == uniqueForwardTarget) {
/* 1908:1895 */       return;
/* 1909:     */     }
/* 1910:1898 */     for (Op03SimpleStatement source : next.getSources()) {
/* 1911:1899 */       if (SetUtil.hasIntersection(source.getBlockIdentifiers(), relevantBlocks)) {
/* 1912:1901 */         return;
/* 1913:     */       }
/* 1914:     */     }
/* 1915:1904 */     List<Op03SimpleStatement> blockSources = ListFactory.newLinkedList();
/* 1916:1905 */     for (Op03SimpleStatement source : uniqueForwardTarget.getSources()) {
/* 1917:1906 */       if (SetUtil.hasIntersection(source.getBlockIdentifiers(), relevantBlocks)) {
/* 1918:1907 */         blockSources.add(source);
/* 1919:     */       }
/* 1920:     */     }
/* 1921:1910 */     Op03SimpleStatement indirect = new Op03SimpleStatement(next.getBlockIdentifiers(), new GotoStatement(), next.getIndex().justBefore());
/* 1922:1911 */     for (Op03SimpleStatement source : blockSources)
/* 1923:     */     {
/* 1924:1912 */       Statement srcStatement = source.getStatement();
/* 1925:1913 */       if ((srcStatement instanceof GotoStatement)) {
/* 1926:1914 */         ((GotoStatement)srcStatement).setJumpType(JumpType.GOTO_OUT_OF_TRY);
/* 1927:     */       }
/* 1928:1916 */       uniqueForwardTarget.removeSource(source);
/* 1929:1917 */       source.replaceTarget(uniqueForwardTarget, indirect);
/* 1930:1918 */       indirect.addSource(source);
/* 1931:     */     }
/* 1932:1920 */     indirect.addTarget(uniqueForwardTarget);
/* 1933:1921 */     uniqueForwardTarget.addSource(indirect);
/* 1934:1922 */     in.add(idx + 1, indirect);
/* 1935:     */   }
/* 1936:     */   
/* 1937:     */   private static BlockIdentifier getBlockStart(Statement statement)
/* 1938:     */   {
/* 1939:1926 */     Class<?> clazz = statement.getClass();
/* 1940:1927 */     if (clazz == TryStatement.class)
/* 1941:     */     {
/* 1942:1928 */       TryStatement tryStatement = (TryStatement)statement;
/* 1943:1929 */       return tryStatement.getBlockIdentifier();
/* 1944:     */     }
/* 1945:1930 */     if (clazz == CatchStatement.class)
/* 1946:     */     {
/* 1947:1931 */       CatchStatement catchStatement = (CatchStatement)statement;
/* 1948:1932 */       return catchStatement.getCatchBlockIdent();
/* 1949:     */     }
/* 1950:1933 */     if (clazz == FinallyStatement.class)
/* 1951:     */     {
/* 1952:1934 */       FinallyStatement finallyStatement = (FinallyStatement)statement;
/* 1953:1935 */       return finallyStatement.getFinallyBlockIdent();
/* 1954:     */     }
/* 1955:1937 */     return null;
/* 1956:     */   }
/* 1957:     */   
/* 1958:     */   public static void extractExceptionJumps(List<Op03SimpleStatement> in)
/* 1959:     */   {
/* 1960:1941 */     List<Op03SimpleStatement> tries = Functional.filter(in, new TypeFilter(TryStatement.class));
/* 1961:1942 */     for (Op03SimpleStatement tryi : tries) {
/* 1962:1943 */       extractExceptionJumps(tryi, in);
/* 1963:     */     }
/* 1964:     */   }
/* 1965:     */   
/* 1966:     */   public static void extractAssertionJumps(List<Op03SimpleStatement> in)
/* 1967:     */   {
/* 1968:1961 */     WildcardMatch wcm = new WildcardMatch();
/* 1969:1962 */     Statement assertionError = new ThrowStatement(wcm.getConstructorSimpleWildcard("exception", TypeConstants.ASSERTION_ERROR));
/* 1970:     */     
/* 1971:1964 */     int x = 0;
/* 1972:1964 */     for (int len = in.size(); x < len; x++)
/* 1973:     */     {
/* 1974:1965 */       Op03SimpleStatement ostm = (Op03SimpleStatement)in.get(x);
/* 1975:1966 */       Statement stm = ostm.getStatement();
/* 1976:1967 */       if (stm.getClass() == IfStatement.class)
/* 1977:     */       {
/* 1978:1968 */         IfStatement ifStatement = (IfStatement)stm;
/* 1979:1969 */         if (ifStatement.getJumpType() != JumpType.GOTO)
/* 1980:     */         {
/* 1981:1970 */           Op03SimpleStatement next = (Op03SimpleStatement)in.get(x + 1);
/* 1982:1971 */           if (next.getSources().size() == 1)
/* 1983:     */           {
/* 1984:1972 */             wcm.reset();
/* 1985:1973 */             if ((assertionError.equals(next.getStatement())) && 
/* 1986:1974 */               (ostm.getBlockIdentifiers().equals(next.getBlockIdentifiers())))
/* 1987:     */             {
/* 1988:1975 */               GotoStatement reJumpStm = new GotoStatement();
/* 1989:1976 */               reJumpStm.setJumpType(ifStatement.getJumpType());
/* 1990:1977 */               Op03SimpleStatement reJump = new Op03SimpleStatement(ostm.getBlockIdentifiers(), reJumpStm, next.getIndex().justAfter());
/* 1991:1978 */               in.add(x + 2, reJump);
/* 1992:1979 */               Op03SimpleStatement origTarget = (Op03SimpleStatement)ostm.getTargets().get(1);
/* 1993:1980 */               ostm.replaceTarget(origTarget, reJump);
/* 1994:1981 */               reJump.addSource(ostm);
/* 1995:1982 */               origTarget.replaceSource(ostm, reJump);
/* 1996:1983 */               reJump.addTarget(origTarget);
/* 1997:1984 */               ifStatement.setJumpType(JumpType.GOTO);
/* 1998:1985 */               len++;
/* 1999:     */             }
/* 2000:     */           }
/* 2001:     */         }
/* 2002:     */       }
/* 2003:     */     }
/* 2004:     */   }
/* 2005:     */   
/* 2006:     */   private static LinearScannedBlock getLinearScannedBlock(List<Op03SimpleStatement> statements, int idx, Op03SimpleStatement stm, BlockIdentifier blockIdentifier, boolean prefix)
/* 2007:     */   {
/* 2008:1991 */     Set<Op03SimpleStatement> found = SetFactory.newSet();
/* 2009:1992 */     int nextIdx = idx + (prefix ? 1 : 0);
/* 2010:1993 */     if (prefix) {
/* 2011:1993 */       found.add(stm);
/* 2012:     */     }
/* 2013:1994 */     int cnt = statements.size();
/* 2014:     */     do
/* 2015:     */     {
/* 2016:1996 */       Op03SimpleStatement nstm = (Op03SimpleStatement)statements.get(nextIdx);
/* 2017:1997 */       if (!nstm.getBlockIdentifiers().contains(blockIdentifier)) {
/* 2018:     */         break;
/* 2019:     */       }
/* 2020:1998 */       found.add(nstm);
/* 2021:1999 */       nextIdx++;
/* 2022:2000 */     } while (nextIdx < cnt);
/* 2023:2001 */     Set<Op03SimpleStatement> reachable = Misc.GraphVisitorBlockReachable.getBlockReachable(stm, blockIdentifier);
/* 2024:2002 */     if (!reachable.equals(found)) {
/* 2025:2002 */       return null;
/* 2026:     */     }
/* 2027:2003 */     nextIdx--;
/* 2028:2004 */     if (reachable.isEmpty()) {
/* 2029:2004 */       return null;
/* 2030:     */     }
/* 2031:2005 */     return new LinearScannedBlock(stm, (Op03SimpleStatement)statements.get(nextIdx), idx, nextIdx);
/* 2032:     */   }
/* 2033:     */   
/* 2034:     */   private static class SingleExceptionAddressing
/* 2035:     */   {
/* 2036:     */     BlockIdentifier tryBlockIdent;
/* 2037:     */     BlockIdentifier catchBlockIdent;
/* 2038:     */     LinearScannedBlock tryBlock;
/* 2039:     */     LinearScannedBlock catchBlock;
/* 2040:     */     
/* 2041:     */     private SingleExceptionAddressing(BlockIdentifier tryBlockIdent, BlockIdentifier catchBlockIdent, LinearScannedBlock tryBlock, LinearScannedBlock catchBlock)
/* 2042:     */     {
/* 2043:2015 */       this.tryBlockIdent = tryBlockIdent;
/* 2044:2016 */       this.catchBlockIdent = catchBlockIdent;
/* 2045:2017 */       this.tryBlock = tryBlock;
/* 2046:2018 */       this.catchBlock = catchBlock;
/* 2047:     */     }
/* 2048:     */   }
/* 2049:     */   
/* 2050:     */   private static SingleExceptionAddressing getSingleTryCatch(Op03SimpleStatement trystm, List<Op03SimpleStatement> statements)
/* 2051:     */   {
/* 2052:2023 */     int idx = statements.indexOf(trystm);
/* 2053:2024 */     TryStatement tryStatement = (TryStatement)trystm.getStatement();
/* 2054:2025 */     BlockIdentifier tryBlockIdent = tryStatement.getBlockIdentifier();
/* 2055:2026 */     LinearScannedBlock tryBlock = getLinearScannedBlock(statements, idx, trystm, tryBlockIdent, true);
/* 2056:2027 */     if (tryBlock == null) {
/* 2057:2027 */       return null;
/* 2058:     */     }
/* 2059:2028 */     Op03SimpleStatement catchs = (Op03SimpleStatement)trystm.getTargets().get(1);
/* 2060:2029 */     Statement testCatch = catchs.getStatement();
/* 2061:2030 */     if (!(testCatch instanceof CatchStatement)) {
/* 2062:2030 */       return null;
/* 2063:     */     }
/* 2064:2031 */     CatchStatement catchStatement = (CatchStatement)testCatch;
/* 2065:2032 */     BlockIdentifier catchBlockIdent = catchStatement.getCatchBlockIdent();
/* 2066:2033 */     LinearScannedBlock catchBlock = getLinearScannedBlock(statements, statements.indexOf(catchs), catchs, catchBlockIdent, true);
/* 2067:2034 */     if (catchBlock == null) {
/* 2068:2034 */       return null;
/* 2069:     */     }
/* 2070:2036 */     if (!catchBlock.isAfter(tryBlock)) {
/* 2071:2036 */       return null;
/* 2072:     */     }
/* 2073:2038 */     return new SingleExceptionAddressing(tryBlockIdent, catchBlockIdent, tryBlock, catchBlock, null);
/* 2074:     */   }
/* 2075:     */   
/* 2076:     */   private static boolean extractExceptionMiddle(Op03SimpleStatement trystm, List<Op03SimpleStatement> statements, SingleExceptionAddressing trycatch)
/* 2077:     */   {
/* 2078:2042 */     LinearScannedBlock tryBlock = trycatch.tryBlock;
/* 2079:2043 */     LinearScannedBlock catchBlock = trycatch.catchBlock;
/* 2080:2044 */     BlockIdentifier tryBlockIdent = trycatch.tryBlockIdent;
/* 2081:2045 */     BlockIdentifier catchBlockIdent = trycatch.catchBlockIdent;
/* 2082:     */     
/* 2083:     */ 
/* 2084:     */ 
/* 2085:     */ 
/* 2086:     */ 
/* 2087:2051 */     int catchLast = catchBlock.getIdxLast();
/* 2088:2052 */     if (catchLast < statements.size() - 1)
/* 2089:     */     {
/* 2090:2053 */       Op03SimpleStatement afterCatchBlock = (Op03SimpleStatement)statements.get(catchLast + 1);
/* 2091:2054 */       for (Op03SimpleStatement source : afterCatchBlock.getSources()) {
/* 2092:2055 */         if (source.getBlockIdentifiers().contains(catchBlockIdent)) {
/* 2093:2055 */           return false;
/* 2094:     */         }
/* 2095:     */       }
/* 2096:     */     }
/* 2097:2059 */     if (catchBlock.immediatelyFollows(tryBlock)) {
/* 2098:2059 */       return false;
/* 2099:     */     }
/* 2100:2061 */     Set<BlockIdentifier> expected = trystm.getBlockIdentifiers();
/* 2101:     */     
/* 2102:     */ 
/* 2103:     */ 
/* 2104:     */ 
/* 2105:     */ 
/* 2106:2067 */     Set<Op03SimpleStatement> middle = SetFactory.newSet();
/* 2107:2068 */     List<Op03SimpleStatement> toMove = ListFactory.newList();
/* 2108:2069 */     for (int x = tryBlock.getIdxLast() + 1; x < catchBlock.getIdxFirst(); x++)
/* 2109:     */     {
/* 2110:2070 */       Op03SimpleStatement stm = (Op03SimpleStatement)statements.get(x);
/* 2111:2071 */       middle.add(stm);
/* 2112:2072 */       toMove.add(stm);
/* 2113:     */     }
/* 2114:     */     Op03SimpleStatement stm;
/* 2115:2074 */     for (int x = tryBlock.getIdxLast() + 1; x < catchBlock.getIdxFirst(); x++)
/* 2116:     */     {
/* 2117:2075 */       stm = (Op03SimpleStatement)statements.get(x);
/* 2118:2076 */       if (!stm.getBlockIdentifiers().containsAll(expected)) {
/* 2119:2077 */         return false;
/* 2120:     */       }
/* 2121:2079 */       for (Op03SimpleStatement source : stm.getSources()) {
/* 2122:2080 */         if (source.getIndex().isBackJumpTo(stm))
/* 2123:     */         {
/* 2124:2081 */           Set<BlockIdentifier> sourceBlocks = source.getBlockIdentifiers();
/* 2125:2082 */           if ((!sourceBlocks.contains(tryBlockIdent)) && (!sourceBlocks.contains(catchBlockIdent))) {
/* 2126:2083 */             return false;
/* 2127:     */           }
/* 2128:     */         }
/* 2129:     */       }
/* 2130:     */     }
/* 2131:2088 */     InstrIndex afterIdx = catchBlock.getLast().getIndex().justAfter();
/* 2132:2089 */     for (Op03SimpleStatement move : toMove)
/* 2133:     */     {
/* 2134:2090 */       move.setIndex(afterIdx);
/* 2135:2091 */       afterIdx = afterIdx.justAfter();
/* 2136:     */     }
/* 2137:2093 */     return true;
/* 2138:     */   }
/* 2139:     */   
/* 2140:     */   private static void extractCatchEnd(Op03SimpleStatement trystm, List<Op03SimpleStatement> statements, SingleExceptionAddressing trycatch)
/* 2141:     */   {
/* 2142:2105 */     LinearScannedBlock tryBlock = trycatch.tryBlock;
/* 2143:2106 */     BlockIdentifier tryBlockIdent = trycatch.tryBlockIdent;
/* 2144:2107 */     BlockIdentifier catchBlockIdent = trycatch.catchBlockIdent;
/* 2145:2108 */     Op03SimpleStatement possibleAfterBlock = null;
/* 2146:2113 */     if (trycatch.catchBlock.getIdxLast() < statements.size() - 1)
/* 2147:     */     {
/* 2148:2114 */       Op03SimpleStatement afterCatch = (Op03SimpleStatement)statements.get(trycatch.catchBlock.getIdxLast() + 1);
/* 2149:2115 */       for (Op03SimpleStatement source : afterCatch.getSources()) {
/* 2150:2116 */         if (source.getBlockIdentifiers().contains(tryBlockIdent)) {
/* 2151:2116 */           return;
/* 2152:     */         }
/* 2153:     */       }
/* 2154:     */     }
/* 2155:2119 */     for (int x = tryBlock.getIdxFirst() + 1; x <= tryBlock.getIdxLast(); x++)
/* 2156:     */     {
/* 2157:2120 */       List<Op03SimpleStatement> targets = ((Op03SimpleStatement)statements.get(x)).getTargets();
/* 2158:2121 */       for (Op03SimpleStatement target : targets) {
/* 2159:2122 */         if (target.getBlockIdentifiers().contains(catchBlockIdent)) {
/* 2160:2123 */           if (possibleAfterBlock == null) {
/* 2161:2124 */             possibleAfterBlock = target;
/* 2162:2126 */           } else if (target != possibleAfterBlock) {
/* 2163:2126 */             return;
/* 2164:     */           }
/* 2165:     */         }
/* 2166:     */       }
/* 2167:     */     }
/* 2168:2131 */     if (possibleAfterBlock == null) {
/* 2169:2131 */       return;
/* 2170:     */     }
/* 2171:2136 */     Set<BlockIdentifier> tryStartBlocks = trycatch.tryBlock.getFirst().getBlockIdentifiers();
/* 2172:2137 */     Set<BlockIdentifier> possibleBlocks = possibleAfterBlock.getBlockIdentifiers();
/* 2173:2138 */     if (possibleBlocks.size() != tryStartBlocks.size() + 1) {
/* 2174:2138 */       return;
/* 2175:     */     }
/* 2176:2140 */     if (!possibleBlocks.containsAll(tryStartBlocks)) {
/* 2177:2140 */       return;
/* 2178:     */     }
/* 2179:2141 */     if (!possibleBlocks.contains(catchBlockIdent)) {
/* 2180:2141 */       return;
/* 2181:     */     }
/* 2182:2146 */     int possibleIdx = statements.indexOf(possibleAfterBlock);
/* 2183:2147 */     LinearScannedBlock unmarkBlock = getLinearScannedBlock(statements, possibleIdx, possibleAfterBlock, catchBlockIdent, false);
/* 2184:2148 */     if (unmarkBlock == null) {
/* 2185:2148 */       return;
/* 2186:     */     }
/* 2187:2149 */     for (int x = unmarkBlock.getIdxFirst(); x <= unmarkBlock.getIdxLast(); x++) {
/* 2188:2150 */       ((Op03SimpleStatement)statements.get(x)).getBlockIdentifiers().remove(catchBlockIdent);
/* 2189:     */     }
/* 2190:     */   }
/* 2191:     */   
/* 2192:     */   public static void extractExceptionMiddle(List<Op03SimpleStatement> in)
/* 2193:     */   {
/* 2194:2170 */     List<Op03SimpleStatement> tryStatements = Functional.filter(in, new ExactTypeFilter(TryStatement.class));
/* 2195:2171 */     if (tryStatements.isEmpty()) {
/* 2196:2171 */       return;
/* 2197:     */     }
/* 2198:2172 */     Collections.reverse(tryStatements);
/* 2199:2173 */     for (Op03SimpleStatement tryStatement : tryStatements) {
/* 2200:2174 */       if (tryStatement.getTargets().size() == 2)
/* 2201:     */       {
/* 2202:2175 */         SingleExceptionAddressing trycatch = getSingleTryCatch(tryStatement, in);
/* 2203:2176 */         if (trycatch != null)
/* 2204:     */         {
/* 2205:2177 */           if (extractExceptionMiddle(tryStatement, in, trycatch))
/* 2206:     */           {
/* 2207:2180 */             Cleaner.sortAndRenumberInPlace(in);
/* 2208:2181 */             trycatch.tryBlock.reindex(in);
/* 2209:2182 */             trycatch.catchBlock.reindex(in);
/* 2210:     */           }
/* 2211:2184 */           extractCatchEnd(tryStatement, in, trycatch);
/* 2212:     */         }
/* 2213:     */       }
/* 2214:     */     }
/* 2215:     */   }
/* 2216:     */   
/* 2217:     */   private static Op03SimpleStatement maybeMoveTarget(Op03SimpleStatement expectedRetarget, Op03SimpleStatement source, List<Op03SimpleStatement> statements)
/* 2218:     */   {
/* 2219:2193 */     if (expectedRetarget.getBlockIdentifiers().equals(source.getBlockIdentifiers())) {
/* 2220:2193 */       return expectedRetarget;
/* 2221:     */     }
/* 2222:2195 */     int startIdx = statements.indexOf(expectedRetarget);
/* 2223:2196 */     int idx = startIdx;
/* 2224:2197 */     Op03SimpleStatement maybe = null;
/* 2225:2198 */     while ((idx > 0) && ((((Op03SimpleStatement)statements.get(--idx)).getStatement() instanceof TryStatement)))
/* 2226:     */     {
/* 2227:2199 */       maybe = (Op03SimpleStatement)statements.get(idx);
/* 2228:2200 */       if (maybe.getBlockIdentifiers().equals(source.getBlockIdentifiers())) {
/* 2229:     */         break;
/* 2230:     */       }
/* 2231:     */     }
/* 2232:2202 */     if (maybe == null) {
/* 2233:2202 */       return expectedRetarget;
/* 2234:     */     }
/* 2235:2203 */     return maybe;
/* 2236:     */   }
/* 2237:     */   
/* 2238:     */   public static void rewriteNegativeJumps(List<Op03SimpleStatement> statements, boolean requireChainedConditional)
/* 2239:     */   {
/* 2240:2239 */     List<Op03SimpleStatement> removeThese = ListFactory.newList();
/* 2241:2240 */     for (int x = 0; x < statements.size() - 2; x++)
/* 2242:     */     {
/* 2243:2241 */       Op03SimpleStatement aStatement = (Op03SimpleStatement)statements.get(x);
/* 2244:2242 */       Statement innerAStatement = aStatement.getStatement();
/* 2245:2243 */       if ((innerAStatement instanceof IfStatement))
/* 2246:     */       {
/* 2247:2244 */         Op03SimpleStatement zStatement = (Op03SimpleStatement)statements.get(x + 1);
/* 2248:2245 */         Op03SimpleStatement xStatement = (Op03SimpleStatement)statements.get(x + 2);
/* 2249:2247 */         if ((!requireChainedConditional) || 
/* 2250:2248 */           ((xStatement.getStatement() instanceof IfStatement))) {
/* 2251:2251 */           if ((aStatement.targets.get(0) == zStatement) && (aStatement.targets.get(1) == xStatement))
/* 2252:     */           {
/* 2253:2254 */             Statement innerZStatement = zStatement.getStatement();
/* 2254:2255 */             if (innerZStatement.getClass() == GotoStatement.class)
/* 2255:     */             {
/* 2256:2257 */               Op03SimpleStatement yStatement = (Op03SimpleStatement)zStatement.targets.get(0);
/* 2257:     */               
/* 2258:     */ 
/* 2259:2260 */               aStatement.replaceTarget(xStatement, yStatement);
/* 2260:2261 */               aStatement.replaceTarget(zStatement, xStatement);
/* 2261:     */               
/* 2262:2263 */               yStatement.replaceSource(zStatement, aStatement);
/* 2263:2264 */               zStatement.sources.clear();
/* 2264:2265 */               zStatement.targets.clear();
/* 2265:2266 */               zStatement.containedStatement = new Nop();
/* 2266:2267 */               removeThese.add(zStatement);
/* 2267:     */               
/* 2268:2269 */               IfStatement innerAIfStatement = (IfStatement)innerAStatement;
/* 2269:2270 */               innerAIfStatement.negateCondition();
/* 2270:     */             }
/* 2271:     */           }
/* 2272:     */         }
/* 2273:     */       }
/* 2274:     */     }
/* 2275:2275 */     statements.removeAll(removeThese);
/* 2276:     */   }
/* 2277:     */   
/* 2278:     */   private static boolean isDirectParentWithoutPassing(Op03SimpleStatement child, Op03SimpleStatement parent, Op03SimpleStatement barrier)
/* 2279:     */   {
/* 2280:2283 */     LinkedList<Op03SimpleStatement> tests = ListFactory.newLinkedList();
/* 2281:2284 */     Set<Op03SimpleStatement> seen = SetFactory.newSet();
/* 2282:2285 */     tests.add(child);
/* 2283:2286 */     seen.add(child);
/* 2284:2287 */     boolean hitParent = false;
/* 2285:2288 */     while (!tests.isEmpty())
/* 2286:     */     {
/* 2287:2289 */       Op03SimpleStatement node = (Op03SimpleStatement)tests.removeFirst();
/* 2288:2290 */       if (node != barrier) {
/* 2289:2291 */         if (node == parent)
/* 2290:     */         {
/* 2291:2292 */           hitParent = true;
/* 2292:     */         }
/* 2293:     */         else
/* 2294:     */         {
/* 2295:2295 */           List<Op03SimpleStatement> localParents = node.getSources();
/* 2296:2296 */           for (Op03SimpleStatement localParent : localParents) {
/* 2297:2297 */             if (seen.add(localParent)) {
/* 2298:2298 */               tests.add(localParent);
/* 2299:     */             }
/* 2300:     */           }
/* 2301:     */         }
/* 2302:     */       }
/* 2303:     */     }
/* 2304:2302 */     return hitParent;
/* 2305:     */   }
/* 2306:     */   
/* 2307:     */   private static Op03SimpleStatement getForInvariant(Op03SimpleStatement start, LValue invariant, BlockIdentifier whileLoop)
/* 2308:     */   {
/* 2309:2309 */     Op03SimpleStatement current = start;
/* 2310:2310 */     while (current.containedInBlocks.contains(whileLoop))
/* 2311:     */     {
/* 2312:2311 */       if ((current.containedStatement instanceof AbstractAssignment))
/* 2313:     */       {
/* 2314:2312 */         AbstractAssignment assignment = (AbstractAssignment)current.containedStatement;
/* 2315:2313 */         LValue assigned = assignment.getCreatedLValue();
/* 2316:2314 */         if ((invariant.equals(assigned)) && 
/* 2317:2315 */           (assignment.isSelfMutatingOperation())) {
/* 2318:2315 */           return current;
/* 2319:     */         }
/* 2320:     */       }
/* 2321:2318 */       if (current.sources.size() > 1) {
/* 2322:     */         break;
/* 2323:     */       }
/* 2324:2319 */       Op03SimpleStatement next = (Op03SimpleStatement)current.sources.get(0);
/* 2325:2320 */       if (!current.index.isBackJumpTo(next)) {
/* 2326:     */         break;
/* 2327:     */       }
/* 2328:2321 */       current = next;
/* 2329:     */     }
/* 2330:2323 */     throw new ConfusedCFRException("Shouldn't be able to get here.");
/* 2331:     */   }
/* 2332:     */   
/* 2333:     */   private static Set<LValue> findForInvariants(Op03SimpleStatement start, BlockIdentifier whileLoop)
/* 2334:     */   {
/* 2335:2327 */     Set<LValue> res = SetFactory.newOrderedSet();
/* 2336:2328 */     Op03SimpleStatement current = start;
/* 2337:2329 */     while (current.containedInBlocks.contains(whileLoop))
/* 2338:     */     {
/* 2339:2337 */       if ((current.containedStatement instanceof AbstractAssignment))
/* 2340:     */       {
/* 2341:2338 */         AbstractAssignment assignment = (AbstractAssignment)current.containedStatement;
/* 2342:2339 */         if (assignment.isSelfMutatingOperation()) {
/* 2343:2340 */           res.add(assignment.getCreatedLValue());
/* 2344:     */         }
/* 2345:     */       }
/* 2346:2343 */       if (current.sources.size() > 1) {
/* 2347:     */         break;
/* 2348:     */       }
/* 2349:2344 */       Op03SimpleStatement next = (Op03SimpleStatement)current.sources.get(0);
/* 2350:2345 */       if (!current.index.isBackJumpTo(next)) {
/* 2351:     */         break;
/* 2352:     */       }
/* 2353:2346 */       current = next;
/* 2354:     */     }
/* 2355:2348 */     return res;
/* 2356:     */   }
/* 2357:     */   
/* 2358:     */   public static Op03SimpleStatement findMovableAssignment(Op03SimpleStatement start, LValue lValue)
/* 2359:     */   {
/* 2360:2352 */     Op03SimpleStatement current = Misc.findSingleBackSource(start);
/* 2361:2353 */     if (current == null) {
/* 2362:2354 */       return null;
/* 2363:     */     }
/* 2364:     */     do
/* 2365:     */     {
/* 2366:2357 */       if ((current.containedStatement instanceof AssignmentSimple))
/* 2367:     */       {
/* 2368:2358 */         AssignmentSimple assignmentSimple = (AssignmentSimple)current.containedStatement;
/* 2369:2359 */         if (assignmentSimple.getCreatedLValue().equals(lValue))
/* 2370:     */         {
/* 2371:2361 */           Expression rhs = assignmentSimple.getRValue();
/* 2372:2362 */           LValueUsageCollectorSimple lValueUsageCollector = new LValueUsageCollectorSimple();
/* 2373:2363 */           rhs.collectUsedLValues(lValueUsageCollector);
/* 2374:2364 */           if (SSAIdentifierUtils.isMovableUnder(lValueUsageCollector.getUsedLValues(), lValue, start.ssaIdentifiers, current.ssaIdentifiers)) {
/* 2375:2365 */             return current;
/* 2376:     */           }
/* 2377:2367 */           logger.info("** incompatible sources");
/* 2378:2368 */           return null;
/* 2379:     */         }
/* 2380:     */       }
/* 2381:2372 */       if (current.sources.size() != 1)
/* 2382:     */       {
/* 2383:2373 */         logger.info("** too many sources");
/* 2384:2374 */         return null;
/* 2385:     */       }
/* 2386:2376 */       current = (Op03SimpleStatement)current.sources.get(0);
/* 2387:2377 */     } while (current != null);
/* 2388:2378 */     return null;
/* 2389:     */   }
/* 2390:     */   
/* 2391:     */   private static List<Op03SimpleStatement> getMutations(List<Op03SimpleStatement> backSources, LValue loopVariable, BlockIdentifier whileBlockIdentifier)
/* 2392:     */   {
/* 2393:2386 */     List<Op03SimpleStatement> mutations = ListFactory.newList();
/* 2394:2387 */     for (Op03SimpleStatement source : backSources)
/* 2395:     */     {
/* 2396:2388 */       Op03SimpleStatement incrStatement = getForInvariant(source, loopVariable, whileBlockIdentifier);
/* 2397:2389 */       mutations.add(incrStatement);
/* 2398:     */     }
/* 2399:2392 */     Op03SimpleStatement baseline = (Op03SimpleStatement)mutations.get(0);
/* 2400:2393 */     for (Op03SimpleStatement incrStatement : mutations) {
/* 2401:2395 */       if (!baseline.equals(incrStatement))
/* 2402:     */       {
/* 2403:2396 */         logger.info("Incompatible constant mutations.");
/* 2404:2397 */         return null;
/* 2405:     */       }
/* 2406:     */     }
/* 2407:2400 */     return mutations;
/* 2408:     */   }
/* 2409:     */   
/* 2410:     */   private static void rewriteWhileAsFor(Op03SimpleStatement statement, List<Op03SimpleStatement> statements, boolean aggcapture)
/* 2411:     */   {
/* 2412:2405 */     List<Op03SimpleStatement> backSources = Functional.filter(statement.sources, new Misc.IsBackJumpTo(statement.index));
/* 2413:     */     
/* 2414:     */ 
/* 2415:     */ 
/* 2416:2409 */     WhileStatement whileStatement = (WhileStatement)statement.containedStatement;
/* 2417:2410 */     ConditionalExpression condition = whileStatement.getCondition();
/* 2418:2411 */     Set<LValue> loopVariablePossibilities = condition.getLoopLValues();
/* 2419:2413 */     if (loopVariablePossibilities.isEmpty())
/* 2420:     */     {
/* 2421:2414 */       logger.info("No loop variable possibilities\n");
/* 2422:2415 */       return;
/* 2423:     */     }
/* 2424:2418 */     BlockIdentifier whileBlockIdentifier = whileStatement.getBlockIdentifier();
/* 2425:     */     
/* 2426:     */ 
/* 2427:     */ 
/* 2428:2422 */     Set<LValue> reverseOrderedMutatedPossibilities = null;
/* 2429:2423 */     for (Op03SimpleStatement source : backSources)
/* 2430:     */     {
/* 2431:2424 */       Set<LValue> incrPoss = findForInvariants(source, whileBlockIdentifier);
/* 2432:2425 */       if (reverseOrderedMutatedPossibilities == null) {
/* 2433:2426 */         reverseOrderedMutatedPossibilities = incrPoss;
/* 2434:     */       } else {
/* 2435:2428 */         reverseOrderedMutatedPossibilities.retainAll(incrPoss);
/* 2436:     */       }
/* 2437:2431 */       if (reverseOrderedMutatedPossibilities.isEmpty())
/* 2438:     */       {
/* 2439:2432 */         logger.info("No invariant possibilities on source\n");
/* 2440:2433 */         return;
/* 2441:     */       }
/* 2442:     */     }
/* 2443:2436 */     if ((reverseOrderedMutatedPossibilities == null) || (reverseOrderedMutatedPossibilities.isEmpty()))
/* 2444:     */     {
/* 2445:2437 */       logger.info("No invariant intersection\n");
/* 2446:2438 */       return;
/* 2447:     */     }
/* 2448:2440 */     loopVariablePossibilities.retainAll(reverseOrderedMutatedPossibilities);
/* 2449:2442 */     if (loopVariablePossibilities.isEmpty())
/* 2450:     */     {
/* 2451:2443 */       logger.info("No invariant intersection\n");
/* 2452:2444 */       return;
/* 2453:     */     }
/* 2454:2447 */     Op03SimpleStatement loopVariableOp = null;
/* 2455:2448 */     LValue loopVariable = null;
/* 2456:2449 */     for (LValue loopVariablePoss : loopVariablePossibilities)
/* 2457:     */     {
/* 2458:2455 */       Op03SimpleStatement initialValue = findMovableAssignment(statement, loopVariablePoss);
/* 2459:2456 */       if ((initialValue != null) && (
/* 2460:2457 */         (loopVariableOp == null) || (initialValue.getIndex().isBackJumpTo(loopVariableOp))))
/* 2461:     */       {
/* 2462:2458 */         loopVariableOp = initialValue;
/* 2463:2459 */         loopVariable = loopVariablePoss;
/* 2464:     */       }
/* 2465:     */     }
/* 2466:2463 */     if (loopVariable == null) {
/* 2467:2463 */       return;
/* 2468:     */     }
/* 2469:2464 */     AssignmentSimple initalAssignmentSimple = null;
/* 2470:     */     
/* 2471:     */ 
/* 2472:2467 */     List<AbstractAssignmentExpression> postUpdates = ListFactory.newList();
/* 2473:2468 */     List<List<Op03SimpleStatement>> usedMutatedPossibilities = ListFactory.newList();
/* 2474:2469 */     boolean usesLoopVar = false;
/* 2475:2470 */     for (LValue otherMutant : reverseOrderedMutatedPossibilities)
/* 2476:     */     {
/* 2477:2471 */       List<Op03SimpleStatement> othermutations = getMutations(backSources, otherMutant, whileBlockIdentifier);
/* 2478:2472 */       if (othermutations != null)
/* 2479:     */       {
/* 2480:2477 */         if ((!loopVariablePossibilities.contains(otherMutant)) && 
/* 2481:2478 */           (!aggcapture)) {
/* 2482:     */           break;
/* 2483:     */         }
/* 2484:2480 */         if (otherMutant.equals(loopVariable)) {
/* 2485:2480 */           usesLoopVar = true;
/* 2486:     */         }
/* 2487:2482 */         AbstractAssignmentExpression postUpdate2 = ((AbstractAssignment)((Op03SimpleStatement)othermutations.get(0)).getStatement()).getInliningExpression();
/* 2488:2483 */         postUpdates.add(postUpdate2);
/* 2489:2484 */         usedMutatedPossibilities.add(othermutations);
/* 2490:     */       }
/* 2491:     */     }
/* 2492:2486 */     if (!usesLoopVar) {
/* 2493:2486 */       return;
/* 2494:     */     }
/* 2495:2488 */     Collections.reverse(postUpdates);
/* 2496:2489 */     for (List<Op03SimpleStatement> lst : usedMutatedPossibilities) {
/* 2497:2490 */       for (Op03SimpleStatement op : lst) {
/* 2498:2491 */         op.nopOut();
/* 2499:     */       }
/* 2500:     */     }
/* 2501:2495 */     if (loopVariableOp != null)
/* 2502:     */     {
/* 2503:2496 */       initalAssignmentSimple = (AssignmentSimple)loopVariableOp.containedStatement;
/* 2504:2497 */       loopVariableOp.nopOut();
/* 2505:     */     }
/* 2506:2500 */     whileBlockIdentifier.setBlockType(BlockType.FORLOOP);
/* 2507:     */     
/* 2508:2502 */     whileStatement.replaceWithForLoop(initalAssignmentSimple, postUpdates);
/* 2509:2504 */     for (Iterator i$ = backSources.iterator(); i$.hasNext();)
/* 2510:     */     {
/* 2511:2504 */       source = (Op03SimpleStatement)i$.next();
/* 2512:2505 */       if (source.containedInBlocks.contains(whileBlockIdentifier))
/* 2513:     */       {
/* 2514:2509 */         List<Op03SimpleStatement> ssources = ListFactory.newList(source.getSources());
/* 2515:2510 */         for (Op03SimpleStatement ssource : ssources) {
/* 2516:2511 */           if (ssource.containedInBlocks.contains(whileBlockIdentifier))
/* 2517:     */           {
/* 2518:2512 */             Statement sstatement = ssource.getStatement();
/* 2519:2513 */             if ((sstatement instanceof JumpingStatement))
/* 2520:     */             {
/* 2521:2514 */               JumpingStatement jumpingStatement = (JumpingStatement)sstatement;
/* 2522:2515 */               if (jumpingStatement.getJumpTarget().getContainer() == source)
/* 2523:     */               {
/* 2524:2516 */                 ((JumpingStatement)sstatement).setJumpType(JumpType.CONTINUE);
/* 2525:2517 */                 ssource.replaceTarget(source, statement);
/* 2526:2518 */                 statement.addSource(ssource);
/* 2527:2519 */                 source.removeSource(ssource);
/* 2528:     */               }
/* 2529:     */             }
/* 2530:     */           }
/* 2531:     */         }
/* 2532:     */       }
/* 2533:     */     }
/* 2534:     */     Op03SimpleStatement source;
/* 2535:     */   }
/* 2536:     */   
/* 2537:     */   public static void rewriteWhilesAsFors(Options options, List<Op03SimpleStatement> statements)
/* 2538:     */   {
/* 2539:2530 */     List<Op03SimpleStatement> whileStarts = Functional.filter(statements, new Predicate()
/* 2540:     */     {
/* 2541:     */       public boolean test(Op03SimpleStatement in)
/* 2542:     */       {
/* 2543:2533 */         return ((in.containedStatement instanceof WhileStatement)) && (((WhileStatement)in.containedStatement).getBlockIdentifier().getBlockType() == BlockType.WHILELOOP);
/* 2544:     */       }
/* 2545:2535 */     });
/* 2546:2536 */     boolean aggcapture = options.getOption(OptionsImpl.FOR_LOOP_CAPTURE) == Troolean.TRUE;
/* 2547:2537 */     for (Op03SimpleStatement whileStart : whileStarts) {
/* 2548:2538 */       rewriteWhileAsFor(whileStart, statements, aggcapture);
/* 2549:     */     }
/* 2550:     */   }
/* 2551:     */   
/* 2552:     */   private static void rewriteDoWhileTruePredAsWhile(Op03SimpleStatement end, List<Op03SimpleStatement> statements)
/* 2553:     */   {
/* 2554:2543 */     WhileStatement whileStatement = (WhileStatement)end.getStatement();
/* 2555:2544 */     if (null != whileStatement.getCondition()) {
/* 2556:2544 */       return;
/* 2557:     */     }
/* 2558:2549 */     List<Op03SimpleStatement> endTargets = end.getTargets();
/* 2559:2550 */     if (endTargets.size() != 1) {
/* 2560:2550 */       return;
/* 2561:     */     }
/* 2562:2552 */     Op03SimpleStatement loopStart = (Op03SimpleStatement)endTargets.get(0);
/* 2563:2553 */     Statement loopBodyStartStatement = loopStart.getStatement();
/* 2564:     */     
/* 2565:     */ 
/* 2566:     */ 
/* 2567:     */ 
/* 2568:     */ 
/* 2569:2559 */     BlockIdentifier whileBlockIdentifier = whileStatement.getBlockIdentifier();
/* 2570:     */     
/* 2571:2561 */     Op03SimpleStatement doStart = null;
/* 2572:2562 */     for (Op03SimpleStatement source : loopStart.getSources())
/* 2573:     */     {
/* 2574:2563 */       Statement statement = source.getStatement();
/* 2575:2564 */       if (statement.getClass() == DoStatement.class)
/* 2576:     */       {
/* 2577:2565 */         DoStatement doStatement = (DoStatement)statement;
/* 2578:2566 */         if (doStatement.getBlockIdentifier() == whileBlockIdentifier)
/* 2579:     */         {
/* 2580:2567 */           doStart = source;
/* 2581:2568 */           break;
/* 2582:     */         }
/* 2583:     */       }
/* 2584:     */     }
/* 2585:2572 */     if (doStart == null) {
/* 2586:2572 */       return;
/* 2587:     */     }
/* 2588:2577 */     if (loopBodyStartStatement.getClass() == IfStatement.class) {
/* 2589:2578 */       return;
/* 2590:     */     }
/* 2591:2579 */     if (loopBodyStartStatement.getClass() == IfExitingStatement.class)
/* 2592:     */     {
/* 2593:2580 */       IfExitingStatement ifExitingStatement = (IfExitingStatement)loopBodyStartStatement;
/* 2594:2581 */       Statement exitStatement = ifExitingStatement.getExitStatement();
/* 2595:2582 */       ConditionalExpression conditionalExpression = ifExitingStatement.getCondition();
/* 2596:2583 */       WhileStatement replacementWhile = new WhileStatement(conditionalExpression.getNegated(), whileBlockIdentifier);
/* 2597:2584 */       GotoStatement endGoto = new GotoStatement();
/* 2598:2585 */       endGoto.setJumpType(JumpType.CONTINUE);
/* 2599:2586 */       end.replaceStatement(endGoto);
/* 2600:2587 */       Op03SimpleStatement after = new Op03SimpleStatement(doStart.getBlockIdentifiers(), exitStatement, end.getIndex().justAfter());
/* 2601:     */       
/* 2602:2589 */       int endIdx = statements.indexOf(end);
/* 2603:2590 */       if (endIdx < statements.size() - 2)
/* 2604:     */       {
/* 2605:2591 */         Op03SimpleStatement shuffled = (Op03SimpleStatement)statements.get(endIdx + 1);
/* 2606:2592 */         for (Op03SimpleStatement shuffledSource : shuffled.sources) {
/* 2607:2593 */           if ((shuffledSource.getStatement() instanceof JumpingStatement))
/* 2608:     */           {
/* 2609:2594 */             JumpingStatement jumpingStatement = (JumpingStatement)shuffledSource.getStatement();
/* 2610:2595 */             if (jumpingStatement.getJumpType() == JumpType.BREAK) {
/* 2611:2596 */               jumpingStatement.setJumpType(JumpType.GOTO);
/* 2612:     */             }
/* 2613:     */           }
/* 2614:     */         }
/* 2615:     */       }
/* 2616:2601 */       statements.add(endIdx + 1, after);
/* 2617:     */       
/* 2618:2603 */       doStart.addTarget(after);
/* 2619:2604 */       after.addSource(doStart);
/* 2620:2605 */       doStart.replaceStatement(replacementWhile);
/* 2621:     */       
/* 2622:     */ 
/* 2623:     */ 
/* 2624:2609 */       Op03SimpleStatement afterLoopStart = (Op03SimpleStatement)loopStart.getTargets().get(0);
/* 2625:2610 */       doStart.replaceTarget(loopStart, afterLoopStart);
/* 2626:2611 */       afterLoopStart.replaceSource(loopStart, doStart);
/* 2627:2612 */       loopStart.removeSource(doStart);
/* 2628:2613 */       loopStart.removeTarget(afterLoopStart);
/* 2629:2614 */       for (Op03SimpleStatement otherSource : loopStart.getSources())
/* 2630:     */       {
/* 2631:2615 */         otherSource.replaceTarget(loopStart, doStart);
/* 2632:2616 */         doStart.addSource(otherSource);
/* 2633:     */       }
/* 2634:2618 */       loopStart.getSources().clear();
/* 2635:2619 */       loopStart.nopOut();
/* 2636:2620 */       whileBlockIdentifier.setBlockType(BlockType.WHILELOOP);
/* 2637:2621 */       return;
/* 2638:     */     }
/* 2639:     */   }
/* 2640:     */   
/* 2641:     */   public static void rewriteDoWhileTruePredAsWhile(List<Op03SimpleStatement> statements)
/* 2642:     */   {
/* 2643:2628 */     List<Op03SimpleStatement> doWhileEnds = Functional.filter(statements, new Predicate()
/* 2644:     */     {
/* 2645:     */       public boolean test(Op03SimpleStatement in)
/* 2646:     */       {
/* 2647:2631 */         return ((in.containedStatement instanceof WhileStatement)) && (((WhileStatement)in.containedStatement).getBlockIdentifier().getBlockType() == BlockType.UNCONDITIONALDOLOOP);
/* 2648:     */       }
/* 2649:     */     });
/* 2650:2635 */     if (doWhileEnds.isEmpty()) {
/* 2651:2635 */       return;
/* 2652:     */     }
/* 2653:2637 */     for (Op03SimpleStatement whileEnd : doWhileEnds) {
/* 2654:2638 */       rewriteDoWhileTruePredAsWhile(whileEnd, statements);
/* 2655:     */     }
/* 2656:     */   }
/* 2657:     */   
/* 2658:     */   public static void rewriteBreakStatements(List<Op03SimpleStatement> statements)
/* 2659:     */   {
/* 2660:2643 */     Cleaner.reindexInPlace(statements);
/* 2661:2645 */     for (Op03SimpleStatement statement : statements)
/* 2662:     */     {
/* 2663:2646 */       Statement innerStatement = statement.getStatement();
/* 2664:2647 */       if ((innerStatement instanceof JumpingStatement))
/* 2665:     */       {
/* 2666:2648 */         JumpingStatement jumpingStatement = (JumpingStatement)innerStatement;
/* 2667:2653 */         if (jumpingStatement.getJumpType().isUnknown())
/* 2668:     */         {
/* 2669:2654 */           Statement targetInnerStatement = jumpingStatement.getJumpTarget();
/* 2670:2655 */           Op03SimpleStatement targetStatement = (Op03SimpleStatement)targetInnerStatement.getContainer();
/* 2671:2657 */           if (targetStatement.thisComparisonBlock != null)
/* 2672:     */           {
/* 2673:2658 */             BlockType blockType = targetStatement.thisComparisonBlock.getBlockType();
/* 2674:2659 */             switch (blockType)
/* 2675:     */             {
/* 2676:     */             }
/* 2677:2663 */             if (BlockIdentifier.blockIsOneOf(targetStatement.thisComparisonBlock, statement.containedInBlocks))
/* 2678:     */             {
/* 2679:2664 */               jumpingStatement.setJumpType(JumpType.CONTINUE);
/* 2680:2665 */               continue;
/* 2681:     */             }
/* 2682:     */           }
/* 2683:2670 */           if ((targetStatement.getBlockStarted() != null) && (targetStatement.getBlockStarted().getBlockType() == BlockType.UNCONDITIONALDOLOOP)) {
/* 2684:2672 */             if (BlockIdentifier.blockIsOneOf(targetStatement.getBlockStarted(), statement.containedInBlocks))
/* 2685:     */             {
/* 2686:2673 */               jumpingStatement.setJumpType(JumpType.CONTINUE);
/* 2687:2674 */               continue;
/* 2688:     */             }
/* 2689:     */           }
/* 2690:2677 */           Set<BlockIdentifier> blocksEnded = targetStatement.getBlocksEnded();
/* 2691:2678 */           if (!blocksEnded.isEmpty())
/* 2692:     */           {
/* 2693:2679 */             BlockIdentifier outermostContainedIn = BlockIdentifier.getOutermostContainedIn(blocksEnded, statement.containedInBlocks);
/* 2694:2681 */             if (outermostContainedIn != null) {
/* 2695:2682 */               jumpingStatement.setJumpType(JumpType.BREAK);
/* 2696:     */             }
/* 2697:     */           }
/* 2698:     */         }
/* 2699:     */       }
/* 2700:     */     }
/* 2701:     */   }
/* 2702:     */   
/* 2703:     */   private static boolean classifyTryCatchLeaveGoto(Op03SimpleStatement gotoStm, Set<BlockIdentifier> blocks, int idx, Set<BlockIdentifier> tryBlockIdents, Map<BlockIdentifier, Op03SimpleStatement> tryStatementsByBlock, Map<BlockIdentifier, List<BlockIdentifier>> catchStatementByBlock, List<Op03SimpleStatement> in)
/* 2704:     */   {
/* 2705:2697 */     if (idx >= in.size() - 1) {
/* 2706:2697 */       return false;
/* 2707:     */     }
/* 2708:2699 */     GotoStatement gotoStatement = (GotoStatement)gotoStm.getStatement();
/* 2709:     */     
/* 2710:2701 */     Set<BlockIdentifier> tryBlocks = SetUtil.intersectionOrNull(blocks, tryBlockIdents);
/* 2711:2702 */     if (tryBlocks == null) {
/* 2712:2702 */       return false;
/* 2713:     */     }
/* 2714:2705 */     Op03SimpleStatement after = (Op03SimpleStatement)in.get(idx + 1);
/* 2715:2706 */     Set<BlockIdentifier> afterBlocks = SetUtil.intersectionOrNull(after.getBlockIdentifiers(), tryBlockIdents);
/* 2716:2708 */     if (afterBlocks != null) {
/* 2717:2708 */       tryBlocks.removeAll(afterBlocks);
/* 2718:     */     }
/* 2719:2709 */     if (tryBlocks.size() != 1) {
/* 2720:2709 */       return false;
/* 2721:     */     }
/* 2722:2710 */     BlockIdentifier left = (BlockIdentifier)tryBlocks.iterator().next();
/* 2723:     */     
/* 2724:     */ 
/* 2725:     */ 
/* 2726:2714 */     Op03SimpleStatement tryStatement = (Op03SimpleStatement)tryStatementsByBlock.get(left);
/* 2727:2715 */     if (tryStatement == null) {
/* 2728:2715 */       return false;
/* 2729:     */     }
/* 2730:2717 */     List<BlockIdentifier> catchForThis = (List)catchStatementByBlock.get(left);
/* 2731:2718 */     if (catchForThis == null) {
/* 2732:2718 */       return false;
/* 2733:     */     }
/* 2734:2726 */     Op03SimpleStatement gotoTgt = (Op03SimpleStatement)gotoStm.getTargets().get(0);
/* 2735:2727 */     Set<BlockIdentifier> gotoTgtIdents = gotoTgt.getBlockIdentifiers();
/* 2736:2728 */     if (SetUtil.hasIntersection(gotoTgtIdents, catchForThis)) {
/* 2737:2728 */       return false;
/* 2738:     */     }
/* 2739:2729 */     int idxtgt = in.indexOf(gotoTgt);
/* 2740:2730 */     if (idxtgt == 0) {
/* 2741:2730 */       return false;
/* 2742:     */     }
/* 2743:2731 */     Op03SimpleStatement prev = (Op03SimpleStatement)in.get(idxtgt - 1);
/* 2744:2732 */     if (!SetUtil.hasIntersection(prev.getBlockIdentifiers(), catchForThis)) {
/* 2745:2732 */       return false;
/* 2746:     */     }
/* 2747:2734 */     gotoStatement.setJumpType(JumpType.GOTO_OUT_OF_TRY);
/* 2748:2735 */     return true;
/* 2749:     */   }
/* 2750:     */   
/* 2751:     */   private static boolean classifyTryLeaveGoto(Op03SimpleStatement gotoStm, int idx, Set<BlockIdentifier> tryBlockIdents, Map<BlockIdentifier, Op03SimpleStatement> tryStatementsByBlock, Map<BlockIdentifier, List<BlockIdentifier>> catchStatementByBlock, List<Op03SimpleStatement> in)
/* 2752:     */   {
/* 2753:2739 */     Set<BlockIdentifier> blocks = gotoStm.getBlockIdentifiers();
/* 2754:2740 */     return classifyTryCatchLeaveGoto(gotoStm, blocks, idx, tryBlockIdents, tryStatementsByBlock, catchStatementByBlock, in);
/* 2755:     */   }
/* 2756:     */   
/* 2757:     */   private static boolean classifyCatchLeaveGoto(Op03SimpleStatement gotoStm, int idx, Set<BlockIdentifier> tryBlockIdents, Map<BlockIdentifier, Op03SimpleStatement> tryStatementsByBlock, Map<BlockIdentifier, List<BlockIdentifier>> catchStatementByBlock, Map<BlockIdentifier, Set<BlockIdentifier>> catchBlockToTryBlocks, List<Op03SimpleStatement> in)
/* 2758:     */   {
/* 2759:2744 */     Set<BlockIdentifier> inBlocks = gotoStm.getBlockIdentifiers();
/* 2760:     */     
/* 2761:     */ 
/* 2762:     */ 
/* 2763:     */ 
/* 2764:2749 */     Set<BlockIdentifier> blocks = SetFactory.newOrderedSet();
/* 2765:2750 */     for (BlockIdentifier block : inBlocks) {
/* 2766:2753 */       if (catchBlockToTryBlocks.containsKey(block))
/* 2767:     */       {
/* 2768:2754 */         Set<BlockIdentifier> catchToTries = (Set)catchBlockToTryBlocks.get(block);
/* 2769:2755 */         blocks.addAll(catchToTries);
/* 2770:     */       }
/* 2771:     */     }
/* 2772:2759 */     return classifyTryCatchLeaveGoto(gotoStm, blocks, idx, tryBlockIdents, tryStatementsByBlock, catchStatementByBlock, in);
/* 2773:     */   }
/* 2774:     */   
/* 2775:     */   public static boolean classifyGotos(List<Op03SimpleStatement> in)
/* 2776:     */   {
/* 2777:2764 */     boolean result = false;
/* 2778:2765 */     List<Pair<Op03SimpleStatement, Integer>> gotos = ListFactory.newList();
/* 2779:2766 */     Map<BlockIdentifier, Op03SimpleStatement> tryStatementsByBlock = MapFactory.newMap();
/* 2780:2767 */     Map<BlockIdentifier, List<BlockIdentifier>> catchStatementsByBlock = MapFactory.newMap();
/* 2781:2768 */     Map<BlockIdentifier, Set<BlockIdentifier>> catchToTries = MapFactory.newLazyMap(new UnaryFunction()
/* 2782:     */     {
/* 2783:     */       public Set<BlockIdentifier> invoke(BlockIdentifier arg)
/* 2784:     */       {
/* 2785:2771 */         return SetFactory.newOrderedSet();
/* 2786:     */       }
/* 2787:2773 */     });
/* 2788:2774 */     int x = 0;
/* 2789:2774 */     for (int len = in.size(); x < len; x++)
/* 2790:     */     {
/* 2791:2775 */       Op03SimpleStatement stm = (Op03SimpleStatement)in.get(x);
/* 2792:2776 */       Statement statement = stm.getStatement();
/* 2793:2777 */       Class<?> clz = statement.getClass();
/* 2794:2778 */       if (clz == TryStatement.class)
/* 2795:     */       {
/* 2796:2779 */         TryStatement tryStatement = (TryStatement)statement;
/* 2797:2780 */         BlockIdentifier tryBlockIdent = tryStatement.getBlockIdentifier();
/* 2798:2781 */         tryStatementsByBlock.put(tryBlockIdent, stm);
/* 2799:2782 */         List<Op03SimpleStatement> targets = stm.getTargets();
/* 2800:2783 */         List<BlockIdentifier> catchBlocks = ListFactory.newList();
/* 2801:2784 */         catchStatementsByBlock.put(tryStatement.getBlockIdentifier(), catchBlocks);
/* 2802:2785 */         int y = 1;
/* 2803:2785 */         for (int len2 = targets.size(); y < len2; y++)
/* 2804:     */         {
/* 2805:2786 */           Statement statement2 = ((Op03SimpleStatement)targets.get(y)).getStatement();
/* 2806:2787 */           if (statement2.getClass() == CatchStatement.class)
/* 2807:     */           {
/* 2808:2788 */             BlockIdentifier catchBlockIdent = ((CatchStatement)statement2).getCatchBlockIdent();
/* 2809:2789 */             catchBlocks.add(catchBlockIdent);
/* 2810:2790 */             ((Set)catchToTries.get(catchBlockIdent)).add(tryBlockIdent);
/* 2811:     */           }
/* 2812:     */         }
/* 2813:     */       }
/* 2814:2793 */       else if (clz == GotoStatement.class)
/* 2815:     */       {
/* 2816:2794 */         GotoStatement gotoStatement = (GotoStatement)statement;
/* 2817:2795 */         if (gotoStatement.getJumpType().isUnknown()) {
/* 2818:2796 */           gotos.add(Pair.make(stm, Integer.valueOf(x)));
/* 2819:     */         }
/* 2820:     */       }
/* 2821:     */     }
/* 2822:2803 */     if (!tryStatementsByBlock.isEmpty()) {
/* 2823:2804 */       for (Pair<Op03SimpleStatement, Integer> goto_ : gotos)
/* 2824:     */       {
/* 2825:2805 */         Op03SimpleStatement stm = (Op03SimpleStatement)goto_.getFirst();
/* 2826:2806 */         int idx = ((Integer)goto_.getSecond()).intValue();
/* 2827:2807 */         if ((classifyTryLeaveGoto(stm, idx, tryStatementsByBlock.keySet(), tryStatementsByBlock, catchStatementsByBlock, in)) || (classifyCatchLeaveGoto(stm, idx, tryStatementsByBlock.keySet(), tryStatementsByBlock, catchStatementsByBlock, catchToTries, in))) {
/* 2828:2809 */           result = true;
/* 2829:     */         }
/* 2830:     */       }
/* 2831:     */     }
/* 2832:2813 */     return result;
/* 2833:     */   }
/* 2834:     */   
/* 2835:     */   public static boolean classifyAnonymousBlockGotos(List<Op03SimpleStatement> in)
/* 2836:     */   {
/* 2837:2817 */     boolean result = false;
/* 2838:2822 */     for (Op03SimpleStatement statement : in)
/* 2839:     */     {
/* 2840:2823 */       Statement inner = statement.getStatement();
/* 2841:2824 */       if ((inner instanceof JumpingStatement))
/* 2842:     */       {
/* 2843:2825 */         JumpingStatement jumpingStatement = (JumpingStatement)inner;
/* 2844:2826 */         JumpType jumpType = jumpingStatement.getJumpType();
/* 2845:2827 */         if (jumpType == JumpType.GOTO)
/* 2846:     */         {
/* 2847:2828 */           Op03SimpleStatement targetStatement = (Op03SimpleStatement)jumpingStatement.getJumpTarget().getContainer();
/* 2848:2829 */           boolean isForwardJump = targetStatement.getIndex().isBackJumpTo(statement);
/* 2849:2830 */           if (isForwardJump)
/* 2850:     */           {
/* 2851:2831 */             Set<BlockIdentifier> targetBlocks = targetStatement.getBlockIdentifiers();
/* 2852:2832 */             Set<BlockIdentifier> srcBlocks = statement.getBlockIdentifiers();
/* 2853:2833 */             if ((targetBlocks.size() < srcBlocks.size()) && (srcBlocks.containsAll(targetBlocks)))
/* 2854:     */             {
/* 2855:2837 */               srcBlocks = Functional.filterSet(srcBlocks, new Predicate()
/* 2856:     */               {
/* 2857:     */                 public boolean test(BlockIdentifier in)
/* 2858:     */                 {
/* 2859:2840 */                   BlockType blockType = in.getBlockType();
/* 2860:2841 */                   if (blockType == BlockType.CASE) {
/* 2861:2841 */                     return false;
/* 2862:     */                   }
/* 2863:2842 */                   if (blockType == BlockType.SWITCH) {
/* 2864:2842 */                     return false;
/* 2865:     */                   }
/* 2866:2843 */                   return true;
/* 2867:     */                 }
/* 2868:     */               });
/* 2869:2846 */               if ((targetBlocks.size() < srcBlocks.size()) && (srcBlocks.containsAll(targetBlocks)))
/* 2870:     */               {
/* 2871:2853 */                 jumpingStatement.setJumpType(JumpType.BREAK_ANONYMOUS);
/* 2872:2854 */                 result = true;
/* 2873:     */               }
/* 2874:     */             }
/* 2875:     */           }
/* 2876:     */         }
/* 2877:     */       }
/* 2878:     */     }
/* 2879:2861 */     return result;
/* 2880:     */   }
/* 2881:     */   
/* 2882:     */   public static Op04StructuredStatement createInitialStructuredBlock(List<Op03SimpleStatement> statements)
/* 2883:     */   {
/* 2884:2865 */     GraphConversionHelper<Op03SimpleStatement, Op04StructuredStatement> conversionHelper = new GraphConversionHelper();
/* 2885:2866 */     List<Op04StructuredStatement> containers = ListFactory.newList();
/* 2886:2867 */     for (Op03SimpleStatement statement : statements)
/* 2887:     */     {
/* 2888:2868 */       Op04StructuredStatement unstructuredStatement = statement.getStructuredStatementPlaceHolder();
/* 2889:2869 */       containers.add(unstructuredStatement);
/* 2890:2870 */       conversionHelper.registerOriginalAndNew(statement, unstructuredStatement);
/* 2891:     */     }
/* 2892:2872 */     conversionHelper.patchUpRelations();
/* 2893:     */     
/* 2894:     */ 
/* 2895:     */ 
/* 2896:     */ 
/* 2897:2877 */     return Op04StructuredStatement.buildNestedBlocks(containers);
/* 2898:     */   }
/* 2899:     */   
/* 2900:     */   public static List<Op03SimpleStatement> pushThroughGoto(Method method, List<Op03SimpleStatement> statements)
/* 2901:     */   {
/* 2902:2902 */     List<Op03SimpleStatement> pathtests = Functional.filter(statements, new ExactTypeFilter(GotoStatement.class));
/* 2903:2903 */     boolean success = false;
/* 2904:2904 */     for (Op03SimpleStatement gotostm : pathtests) {
/* 2905:2905 */       if ((((Op03SimpleStatement)gotostm.getTargets().get(0)).getIndex().isBackJumpTo(gotostm)) && 
/* 2906:2906 */         (pushThroughGoto(method, gotostm, statements))) {
/* 2907:2907 */         success = true;
/* 2908:     */       }
/* 2909:     */     }
/* 2910:2911 */     if (success)
/* 2911:     */     {
/* 2912:2912 */       statements = Cleaner.sortAndRenumber(statements);
/* 2913:     */       
/* 2914:     */ 
/* 2915:     */ 
/* 2916:2916 */       rewriteNegativeJumps(statements, false);
/* 2917:2917 */       rewriteNegativeJumps(statements, false);
/* 2918:     */     }
/* 2919:2919 */     return statements;
/* 2920:     */   }
/* 2921:     */   
/* 2922:     */   private static boolean moveable(Statement statement)
/* 2923:     */   {
/* 2924:2923 */     Class<?> clazz = statement.getClass();
/* 2925:2924 */     if (clazz == Nop.class) {
/* 2926:2924 */       return true;
/* 2927:     */     }
/* 2928:2925 */     if (clazz == AssignmentSimple.class) {
/* 2929:2925 */       return true;
/* 2930:     */     }
/* 2931:2926 */     if (clazz == CommentStatement.class) {
/* 2932:2926 */       return true;
/* 2933:     */     }
/* 2934:2927 */     if (clazz == ExpressionStatement.class) {
/* 2935:2927 */       return true;
/* 2936:     */     }
/* 2937:2928 */     if (clazz == IfExitingStatement.class) {
/* 2938:2928 */       return true;
/* 2939:     */     }
/* 2940:2929 */     return false;
/* 2941:     */   }
/* 2942:     */   
/* 2943:     */   private static boolean pushThroughGoto(Method method, Op03SimpleStatement forwardGoto, List<Op03SimpleStatement> statements)
/* 2944:     */   {
/* 2945:2934 */     if (forwardGoto.sources.size() != 1) {
/* 2946:2934 */       return false;
/* 2947:     */     }
/* 2948:2936 */     Op03SimpleStatement tgt = (Op03SimpleStatement)forwardGoto.getTargets().get(0);
/* 2949:2937 */     int idx = statements.indexOf(tgt);
/* 2950:2938 */     if (idx == 0) {
/* 2951:2938 */       return false;
/* 2952:     */     }
/* 2953:2939 */     Op03SimpleStatement before = (Op03SimpleStatement)statements.get(idx - 1);
/* 2954:2941 */     if (tgt.getSources().contains(before)) {
/* 2955:2941 */       return false;
/* 2956:     */     }
/* 2957:2942 */     if (tgt.getSources().size() != 1) {
/* 2958:2942 */       return false;
/* 2959:     */     }
/* 2960:2944 */     InstrIndex beforeTgt = tgt.getIndex().justBefore();
/* 2961:2945 */     Op03SimpleStatement last = forwardGoto;
/* 2962:     */     
/* 2963:     */ 
/* 2964:     */ 
/* 2965:     */ 
/* 2966:     */ 
/* 2967:     */ 
/* 2968:     */ 
/* 2969:     */ 
/* 2970:     */ 
/* 2971:     */ 
/* 2972:     */ 
/* 2973:     */ 
/* 2974:     */ 
/* 2975:     */ 
/* 2976:     */ 
/* 2977:     */ 
/* 2978:2962 */     Predicate isLoopBlock = new Predicate()
/* 2979:     */     {
/* 2980:     */       public boolean test(BlockIdentifier in)
/* 2981:     */       {
/* 2982:2953 */         BlockType blockType = in.getBlockType();
/* 2983:2954 */         switch (Op03SimpleStatement.10.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$utils$BlockType[blockType.ordinal()])
/* 2984:     */         {
/* 2985:     */         case 1: 
/* 2986:     */         case 3: 
/* 2987:2957 */           return true;
/* 2988:     */         }
/* 2989:2959 */         return false;
/* 2990:     */       }
/* 2991:2962 */     };
/* 2992:2963 */     Set<BlockIdentifier> beforeLoopBlocks = SetFactory.newSet(Functional.filterSet(before.getBlockIdentifiers(), isLoopBlock));
/* 2993:2964 */     Set<BlockIdentifier> tgtLoopBlocks = SetFactory.newSet(Functional.filterSet(tgt.getBlockIdentifiers(), isLoopBlock));
/* 2994:2965 */     if (!beforeLoopBlocks.equals(tgtLoopBlocks)) {
/* 2995:2965 */       return false;
/* 2996:     */     }
/* 2997:2968 */     before.getBlockIdentifiers();
/* 2998:     */     
/* 2999:     */ 
/* 3000:     */ 
/* 3001:     */ 
/* 3002:     */ 
/* 3003:     */ 
/* 3004:     */ 
/* 3005:     */ 
/* 3006:     */ 
/* 3007:     */ 
/* 3008:     */ 
/* 3009:     */ 
/* 3010:     */ 
/* 3011:     */ 
/* 3012:     */ 
/* 3013:2984 */     Predicate<BlockIdentifier> exceptionFilter = new Predicate()
/* 3014:     */     {
/* 3015:     */       public boolean test(BlockIdentifier in)
/* 3016:     */       {
/* 3017:2973 */         BlockType blockType = in.getBlockType();
/* 3018:2974 */         switch (Op03SimpleStatement.10.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$utils$BlockType[blockType.ordinal()])
/* 3019:     */         {
/* 3020:     */         case 6: 
/* 3021:     */         case 7: 
/* 3022:     */         case 8: 
/* 3023:     */         case 9: 
/* 3024:2979 */           return true;
/* 3025:     */         }
/* 3026:2981 */         return false;
/* 3027:     */       }
/* 3028:2985 */     };
/* 3029:2986 */     Set<BlockIdentifier> exceptionBlocks = SetFactory.newSet(Functional.filterSet(tgt.getBlockIdentifiers(), exceptionFilter));
/* 3030:2987 */     int nextCandidateIdx = statements.indexOf(forwardGoto) - 1;
/* 3031:     */     
/* 3032:2989 */     Op03SimpleStatement lastTarget = tgt;
/* 3033:2990 */     Set<Op03SimpleStatement> seen = SetFactory.newSet();
/* 3034:2991 */     boolean success = false;
/* 3035:     */     for (;;)
/* 3036:     */     {
/* 3037:2993 */       Op03SimpleStatement tryMoveThis = (Op03SimpleStatement)forwardGoto.sources.get(0);
/* 3038:2995 */       if (!moveable(tryMoveThis.getStatement())) {
/* 3039:2995 */         return success;
/* 3040:     */       }
/* 3041:2997 */       if (!seen.add(tryMoveThis)) {
/* 3042:2997 */         return success;
/* 3043:     */       }
/* 3044:2999 */       if (statements.get(nextCandidateIdx) != tryMoveThis) {
/* 3045:2999 */         return success;
/* 3046:     */       }
/* 3047:3000 */       if (tryMoveThis.targets.size() != 1) {
/* 3048:3000 */         return success;
/* 3049:     */       }
/* 3050:3002 */       boolean abortNext = tryMoveThis.sources.size() != 1;
/* 3051:     */       
/* 3052:3004 */       Set<BlockIdentifier> moveEB = SetFactory.newSet(Functional.filterSet(forwardGoto.getBlockIdentifiers(), exceptionFilter));
/* 3053:3005 */       if (!moveEB.equals(exceptionBlocks)) {
/* 3054:3005 */         return success;
/* 3055:     */       }
/* 3056:3008 */       forwardGoto.sources.clear();
/* 3057:3009 */       for (Op03SimpleStatement beforeTryMove : tryMoveThis.sources)
/* 3058:     */       {
/* 3059:3010 */         beforeTryMove.replaceTarget(tryMoveThis, forwardGoto);
/* 3060:3011 */         forwardGoto.sources.add(beforeTryMove);
/* 3061:     */       }
/* 3062:3013 */       tryMoveThis.sources.clear();
/* 3063:3014 */       tryMoveThis.sources.add(forwardGoto);
/* 3064:3015 */       forwardGoto.replaceTarget(lastTarget, tryMoveThis);
/* 3065:3016 */       tryMoveThis.replaceTarget(forwardGoto, lastTarget);
/* 3066:3017 */       lastTarget.replaceSource(forwardGoto, tryMoveThis);
/* 3067:     */       
/* 3068:3019 */       tryMoveThis.index = beforeTgt;
/* 3069:3020 */       beforeTgt = beforeTgt.justBefore();
/* 3070:     */       
/* 3071:3022 */       tryMoveThis.containedInBlocks.clear();
/* 3072:3023 */       tryMoveThis.containedInBlocks.addAll(lastTarget.containedInBlocks);
/* 3073:3024 */       lastTarget = tryMoveThis;
/* 3074:3025 */       nextCandidateIdx--;
/* 3075:3026 */       success = true;
/* 3076:3027 */       if (abortNext) {
/* 3077:3027 */         return success;
/* 3078:     */       }
/* 3079:     */     }
/* 3080:     */   }
/* 3081:     */   
/* 3082:     */   public static void eclipseLoopPass(List<Op03SimpleStatement> statements)
/* 3083:     */   {
/* 3084:3062 */     boolean effect = false;
/* 3085:3063 */     int x = 0;
/* 3086:3063 */     for (int len = statements.size() - 1; x < len; x++)
/* 3087:     */     {
/* 3088:3064 */       Op03SimpleStatement statement = (Op03SimpleStatement)statements.get(x);
/* 3089:3065 */       Statement inr = statement.getStatement();
/* 3090:3066 */       if (inr.getClass() == GotoStatement.class)
/* 3091:     */       {
/* 3092:3068 */         Op03SimpleStatement target = (Op03SimpleStatement)statement.getTargets().get(0);
/* 3093:3069 */         if (target != statement) {
/* 3094:3071 */           if (!target.getIndex().isBackJumpFrom(statement))
/* 3095:     */           {
/* 3096:3072 */             Statement tgtInr = target.getStatement();
/* 3097:3073 */             if (tgtInr.getClass() == IfStatement.class)
/* 3098:     */             {
/* 3099:3074 */               IfStatement ifStatement = (IfStatement)tgtInr;
/* 3100:     */               
/* 3101:3076 */               Op03SimpleStatement bodyStart = (Op03SimpleStatement)statements.get(x + 1);
/* 3102:3077 */               if (bodyStart == ifStatement.getJumpTarget().getContainer())
/* 3103:     */               {
/* 3104:3079 */                 for (Op03SimpleStatement source : target.getSources())
/* 3105:     */                 {
/* 3106:3080 */                   InstrIndex sourceIdx = source.getIndex();
/* 3107:3081 */                   if ((sourceIdx.isBackJumpFrom(statement)) || (sourceIdx.isBackJumpTo(target))) {}
/* 3108:     */                 }
/* 3109:3084 */                 Op03SimpleStatement afterTest = (Op03SimpleStatement)target.getTargets().get(0);
/* 3110:     */                 
/* 3111:     */ 
/* 3112:     */ 
/* 3113:     */ 
/* 3114:3089 */                 IfStatement topTest = new IfStatement(ifStatement.getCondition().getNegated().simplify());
/* 3115:3090 */                 statement.replaceStatement(topTest);
/* 3116:3091 */                 statement.replaceTarget(target, bodyStart);
/* 3117:3092 */                 bodyStart.addSource(statement);
/* 3118:3093 */                 statement.addTarget(afterTest);
/* 3119:3094 */                 afterTest.replaceSource(target, statement);
/* 3120:3095 */                 target.replaceStatement(new Nop());
/* 3121:3096 */                 target.removeSource(statement);
/* 3122:3097 */                 target.removeTarget(afterTest);
/* 3123:3098 */                 target.replaceTarget(bodyStart, statement);
/* 3124:3099 */                 target.replaceStatement(new GotoStatement());
/* 3125:3100 */                 bodyStart.removeSource(target);
/* 3126:3101 */                 statement.addSource(target);
/* 3127:     */                 
/* 3128:3103 */                 effect = true;
/* 3129:     */               }
/* 3130:     */             }
/* 3131:     */           }
/* 3132:     */         }
/* 3133:     */       }
/* 3134:     */     }
/* 3135:3106 */     if (effect) {
/* 3136:3107 */       removePointlessJumps(statements);
/* 3137:     */     }
/* 3138:     */   }
/* 3139:     */   
/* 3140:     */   public JumpType getJumpType()
/* 3141:     */   {
/* 3142:3113 */     if ((this.containedStatement instanceof JumpingStatement)) {
/* 3143:3114 */       return ((JumpingStatement)this.containedStatement).getJumpType();
/* 3144:     */     }
/* 3145:3116 */     return JumpType.NONE;
/* 3146:     */   }
/* 3147:     */   
/* 3148:     */   public static class ExactTypeFilter<T>
/* 3149:     */     implements Predicate<Op03SimpleStatement>
/* 3150:     */   {
/* 3151:     */     private final Class<T> clazz;
/* 3152:     */     private final boolean positive;
/* 3153:     */     
/* 3154:     */     public ExactTypeFilter(Class<T> clazz)
/* 3155:     */     {
/* 3156:3125 */       this.clazz = clazz;
/* 3157:3126 */       this.positive = true;
/* 3158:     */     }
/* 3159:     */     
/* 3160:     */     public ExactTypeFilter(Class<T> clazz, boolean positive)
/* 3161:     */     {
/* 3162:3130 */       this.clazz = clazz;
/* 3163:3131 */       this.positive = positive;
/* 3164:     */     }
/* 3165:     */     
/* 3166:     */     public boolean test(Op03SimpleStatement in)
/* 3167:     */     {
/* 3168:3136 */       return this.positive == (this.clazz == in.containedStatement.getClass());
/* 3169:     */     }
/* 3170:     */   }
/* 3171:     */   
/* 3172:     */   public static List<Op03SimpleStatement> removeUselessNops(List<Op03SimpleStatement> in)
/* 3173:     */   {
/* 3174:3142 */     Functional.filter(in, new Predicate()
/* 3175:     */     {
/* 3176:     */       public boolean test(Op03SimpleStatement in)
/* 3177:     */       {
/* 3178:3145 */         return (!in.sources.isEmpty()) || (!in.targets.isEmpty());
/* 3179:     */       }
/* 3180:     */     });
/* 3181:     */   }
/* 3182:     */   
/* 3183:     */   public static List<Op03SimpleStatement> rewriteWith(List<Op03SimpleStatement> in, ExpressionRewriter expressionRewriter)
/* 3184:     */   {
/* 3185:3151 */     for (Op03SimpleStatement op03SimpleStatement : in) {
/* 3186:3152 */       op03SimpleStatement.rewrite(expressionRewriter);
/* 3187:     */     }
/* 3188:3154 */     return in;
/* 3189:     */   }
/* 3190:     */   
/* 3191:     */   private static void combineTryCatchBlocks(Op03SimpleStatement tryStatement, List<Op03SimpleStatement> statements, BlockIdentifierFactory blockIdentifierFactory)
/* 3192:     */   {
/* 3193:3159 */     Set<Op03SimpleStatement> allStatements = SetFactory.newSet();
/* 3194:3160 */     TryStatement innerTryStatement = (TryStatement)tryStatement.getStatement();
/* 3195:     */     
/* 3196:3162 */     allStatements.addAll(Misc.GraphVisitorBlockReachable.getBlockReachable(tryStatement, innerTryStatement.getBlockIdentifier()));
/* 3197:3165 */     for (Op03SimpleStatement target : tryStatement.getTargets()) {
/* 3198:3166 */       if ((target.containedStatement instanceof CatchStatement))
/* 3199:     */       {
/* 3200:3167 */         CatchStatement catchStatement = (CatchStatement)target.containedStatement;
/* 3201:3168 */         allStatements.addAll(Misc.GraphVisitorBlockReachable.getBlockReachable(target, catchStatement.getCatchBlockIdent()));
/* 3202:     */       }
/* 3203:     */     }
/* 3204:3177 */     Set<BlockIdentifier> tryBlocks = tryStatement.containedInBlocks;
/* 3205:3178 */     tryBlocks = SetFactory.newSet(Functional.filter(tryBlocks, new Predicate()
/* 3206:     */     {
/* 3207:     */       public boolean test(BlockIdentifier in)
/* 3208:     */       {
/* 3209:3181 */         return (in.getBlockType() == BlockType.TRYBLOCK) || (in.getBlockType() == BlockType.CATCHBLOCK);
/* 3210:     */       }
/* 3211:     */     }));
/* 3212:3184 */     if (tryBlocks.isEmpty()) {
/* 3213:3184 */       return;
/* 3214:     */     }
/* 3215:3185 */     for (Op03SimpleStatement statement : allStatements)
/* 3216:     */     {
/* 3217:3186 */       for (BlockIdentifier ident : tryBlocks) {
/* 3218:3187 */         if ((!statement.containedInBlocks.contains(ident)) && (statement.sources.contains(statement.linearlyPrevious)) && (statement.linearlyPrevious.containedInBlocks.contains(ident))) {
/* 3219:3188 */           statement.addPossibleExitFor(ident);
/* 3220:     */         }
/* 3221:     */       }
/* 3222:3191 */       statement.containedInBlocks.addAll(tryBlocks);
/* 3223:     */     }
/* 3224:     */   }
/* 3225:     */   
/* 3226:3195 */   private Set<BlockIdentifier> possibleExitsFor = null;
/* 3227:     */   
/* 3228:     */   private void addPossibleExitFor(BlockIdentifier ident)
/* 3229:     */   {
/* 3230:3197 */     if (this.possibleExitsFor == null) {
/* 3231:3197 */       this.possibleExitsFor = SetFactory.newSet();
/* 3232:     */     }
/* 3233:3198 */     this.possibleExitsFor.add(ident);
/* 3234:     */   }
/* 3235:     */   
/* 3236:     */   public boolean isPossibleExitFor(BlockIdentifier ident)
/* 3237:     */   {
/* 3238:3201 */     return (this.possibleExitsFor != null) && (this.possibleExitsFor.contains(ident));
/* 3239:     */   }
/* 3240:     */   
/* 3241:     */   public static void combineTryCatchBlocks(List<Op03SimpleStatement> in, BlockIdentifierFactory blockIdentifierFactory)
/* 3242:     */   {
/* 3243:3207 */     List<Op03SimpleStatement> tries = Functional.filter(in, new TypeFilter(TryStatement.class));
/* 3244:3208 */     for (Op03SimpleStatement tryStatement : tries) {
/* 3245:3209 */       combineTryCatchBlocks(tryStatement, in, blockIdentifierFactory);
/* 3246:     */     }
/* 3247:     */   }
/* 3248:     */   
/* 3249:     */   private static void combineTryCatchEnds(Op03SimpleStatement tryStatement, List<Op03SimpleStatement> in)
/* 3250:     */   {
/* 3251:3216 */     TryStatement innerTryStatement = (TryStatement)tryStatement.getStatement();
/* 3252:3217 */     List<Op03SimpleStatement> lastStatements = ListFactory.newList();
/* 3253:3218 */     lastStatements.add(getLastContiguousBlockStatement(innerTryStatement.getBlockIdentifier(), in, tryStatement));
/* 3254:3219 */     int x = 1;
/* 3255:3219 */     for (int len = tryStatement.targets.size(); x < len; x++)
/* 3256:     */     {
/* 3257:3220 */       Op03SimpleStatement statementContainer = (Op03SimpleStatement)tryStatement.targets.get(x);
/* 3258:3221 */       Statement statement = statementContainer.getStatement();
/* 3259:3222 */       if ((statement instanceof CatchStatement))
/* 3260:     */       {
/* 3261:3223 */         lastStatements.add(getLastContiguousBlockStatement(((CatchStatement)statement).getCatchBlockIdent(), in, statementContainer));
/* 3262:     */       }
/* 3263:     */       else
/* 3264:     */       {
/* 3265:3224 */         if ((statement instanceof FinallyStatement)) {
/* 3266:3225 */           return;
/* 3267:     */         }
/* 3268:3228 */         return;
/* 3269:     */       }
/* 3270:     */     }
/* 3271:3231 */     if (lastStatements.size() <= 1) {
/* 3272:3231 */       return;
/* 3273:     */     }
/* 3274:3232 */     for (Op03SimpleStatement last : lastStatements)
/* 3275:     */     {
/* 3276:3233 */       if (last == null) {
/* 3277:3233 */         return;
/* 3278:     */       }
/* 3279:3234 */       if (last.getStatement().getClass() != GotoStatement.class) {
/* 3280:3235 */         return;
/* 3281:     */       }
/* 3282:     */     }
/* 3283:3238 */     Op03SimpleStatement target = (Op03SimpleStatement)((Op03SimpleStatement)lastStatements.get(0)).getTargets().get(0);
/* 3284:3239 */     for (Op03SimpleStatement last : lastStatements) {
/* 3285:3240 */       if (last.getTargets().get(0) != target) {
/* 3286:3240 */         return;
/* 3287:     */       }
/* 3288:     */     }
/* 3289:3243 */     Op03SimpleStatement finalStatement = (Op03SimpleStatement)lastStatements.get(lastStatements.size() - 1);
/* 3290:3244 */     int beforeTgt = in.indexOf(finalStatement);
/* 3291:3245 */     Op03SimpleStatement proxy = new Op03SimpleStatement(tryStatement.getBlockIdentifiers(), new GotoStatement(), finalStatement.getIndex().justAfter());
/* 3292:3246 */     in.add(beforeTgt + 1, proxy);
/* 3293:3247 */     proxy.addTarget(target);
/* 3294:3248 */     target.addSource(proxy);
/* 3295:     */     
/* 3296:     */ 
/* 3297:3251 */     Set<Op03SimpleStatement> seen = SetFactory.newSet();
/* 3298:3252 */     for (Op03SimpleStatement last : lastStatements) {
/* 3299:3253 */       if (seen.add(last))
/* 3300:     */       {
/* 3301:3254 */         GotoStatement gotoStatement = (GotoStatement)last.containedStatement;
/* 3302:3255 */         gotoStatement.setJumpType(JumpType.END_BLOCK);
/* 3303:3256 */         last.replaceTarget(target, proxy);
/* 3304:3257 */         target.removeSource(last);
/* 3305:3258 */         proxy.addSource(last);
/* 3306:     */       }
/* 3307:     */     }
/* 3308:     */   }
/* 3309:     */   
/* 3310:     */   private static void rewriteTryBackJump(Op03SimpleStatement stm)
/* 3311:     */   {
/* 3312:3263 */     InstrIndex idx = stm.getIndex();
/* 3313:3264 */     TryStatement tryStatement = (TryStatement)stm.getStatement();
/* 3314:3265 */     Op03SimpleStatement firstbody = (Op03SimpleStatement)stm.getTargets().get(0);
/* 3315:3266 */     BlockIdentifier blockIdentifier = tryStatement.getBlockIdentifier();
/* 3316:3267 */     Iterator<Op03SimpleStatement> sourceIter = stm.sources.iterator();
/* 3317:3268 */     while (sourceIter.hasNext())
/* 3318:     */     {
/* 3319:3269 */       Op03SimpleStatement source = (Op03SimpleStatement)sourceIter.next();
/* 3320:3270 */       if ((idx.isBackJumpFrom(source)) && 
/* 3321:3271 */         (source.getBlockIdentifiers().contains(blockIdentifier)))
/* 3322:     */       {
/* 3323:3272 */         source.replaceTarget(stm, firstbody);
/* 3324:3273 */         firstbody.addSource(source);
/* 3325:3274 */         sourceIter.remove();
/* 3326:     */       }
/* 3327:     */     }
/* 3328:     */   }
/* 3329:     */   
/* 3330:     */   public static void rewriteTryBackJumps(List<Op03SimpleStatement> in)
/* 3331:     */   {
/* 3332:3285 */     List<Op03SimpleStatement> tries = Functional.filter(in, new TypeFilter(TryStatement.class));
/* 3333:3286 */     for (Op03SimpleStatement trystm : tries) {
/* 3334:3287 */       rewriteTryBackJump(trystm);
/* 3335:     */     }
/* 3336:     */   }
/* 3337:     */   
/* 3338:     */   public static void combineTryCatchEnds(List<Op03SimpleStatement> in)
/* 3339:     */   {
/* 3340:3292 */     List<Op03SimpleStatement> tries = Functional.filter(in, new TypeFilter(TryStatement.class));
/* 3341:3293 */     for (Op03SimpleStatement tryStatement : tries) {
/* 3342:3294 */       combineTryCatchEnds(tryStatement, in);
/* 3343:     */     }
/* 3344:     */   }
/* 3345:     */   
/* 3346:     */   private static Op03SimpleStatement insertBlockPadding(String comment, Op03SimpleStatement insertAfter, Op03SimpleStatement insertBefore, BlockIdentifier blockIdentifier, List<Op03SimpleStatement> statements)
/* 3347:     */   {
/* 3348:3307 */     Op03SimpleStatement between = new Op03SimpleStatement(insertAfter.getBlockIdentifiers(), new CommentStatement(comment), insertAfter.getIndex().justAfter());
/* 3349:3308 */     insertAfter.replaceTarget(insertBefore, between);
/* 3350:3309 */     insertBefore.replaceSource(insertAfter, between);
/* 3351:3310 */     between.addSource(insertAfter);
/* 3352:3311 */     between.addTarget(insertBefore);
/* 3353:3312 */     between.getBlockIdentifiers().add(blockIdentifier);
/* 3354:3313 */     statements.add(between);
/* 3355:3314 */     return between;
/* 3356:     */   }
/* 3357:     */   
/* 3358:     */   private static void identifyCatchBlock(Op03SimpleStatement start, BlockIdentifier blockIdentifier, List<Op03SimpleStatement> statements)
/* 3359:     */   {
/* 3360:3321 */     Set<Op03SimpleStatement> knownMembers = SetFactory.newSet();
/* 3361:3322 */     Set<Op03SimpleStatement> seen = SetFactory.newSet();
/* 3362:3323 */     seen.add(start);
/* 3363:3324 */     knownMembers.add(start);
/* 3364:     */     
/* 3365:     */ 
/* 3366:     */ 
/* 3367:     */ 
/* 3368:     */ 
/* 3369:     */ 
/* 3370:     */ 
/* 3371:     */ 
/* 3372:     */ 
/* 3373:     */ 
/* 3374:     */ 
/* 3375:     */ 
/* 3376:     */ 
/* 3377:     */ 
/* 3378:     */ 
/* 3379:     */ 
/* 3380:3341 */     LinkedList<Op03SimpleStatement> pendingPossibilities = ListFactory.newLinkedList();
/* 3381:3342 */     if (start.targets.size() != 1) {
/* 3382:3343 */       throw new ConfusedCFRException("Catch statement with multiple targets");
/* 3383:     */     }
/* 3384:3345 */     for (Op03SimpleStatement target : start.targets)
/* 3385:     */     {
/* 3386:3346 */       pendingPossibilities.add(target);
/* 3387:3347 */       seen.add(target);
/* 3388:     */     }
/* 3389:3350 */     Map<Op03SimpleStatement, Set<Op03SimpleStatement>> allows = MapFactory.newLazyMap(new UnaryFunction()
/* 3390:     */     {
/* 3391:     */       public Set<Op03SimpleStatement> invoke(Op03SimpleStatement ignore)
/* 3392:     */       {
/* 3393:3353 */         return SetFactory.newSet();
/* 3394:     */       }
/* 3395:3355 */     });
/* 3396:3356 */     int sinceDefinite = 0;
/* 3397:3357 */     while ((!pendingPossibilities.isEmpty()) && (sinceDefinite <= pendingPossibilities.size()))
/* 3398:     */     {
/* 3399:3358 */       Op03SimpleStatement maybe = (Op03SimpleStatement)pendingPossibilities.removeFirst();
/* 3400:3359 */       boolean definite = true;
/* 3401:3360 */       for (Op03SimpleStatement source : maybe.sources) {
/* 3402:3361 */         if (!knownMembers.contains(source)) {
/* 3403:3366 */           if (!source.getIndex().isBackJumpTo(maybe))
/* 3404:     */           {
/* 3405:3367 */             definite = false;
/* 3406:3368 */             ((Set)allows.get(source)).add(maybe);
/* 3407:     */           }
/* 3408:     */         }
/* 3409:     */       }
/* 3410:3372 */       if (definite)
/* 3411:     */       {
/* 3412:3373 */         sinceDefinite = 0;
/* 3413:     */         
/* 3414:3375 */         knownMembers.add(maybe);
/* 3415:3376 */         Set<Op03SimpleStatement> allowedBy = (Set)allows.get(maybe);
/* 3416:3377 */         pendingPossibilities.addAll(allowedBy);
/* 3417:     */         
/* 3418:3379 */         allowedBy.clear();
/* 3419:3383 */         for (Op03SimpleStatement target : maybe.targets) {
/* 3420:3385 */           if (!seen.contains(target))
/* 3421:     */           {
/* 3422:3386 */             seen.add(target);
/* 3423:3387 */             if (target.getIndex().isBackJumpTo(start)) {
/* 3424:3388 */               pendingPossibilities.add(target);
/* 3425:     */             }
/* 3426:     */           }
/* 3427:     */         }
/* 3428:     */       }
/* 3429:     */       else
/* 3430:     */       {
/* 3431:3396 */         sinceDefinite++;
/* 3432:3397 */         pendingPossibilities.add(maybe);
/* 3433:     */       }
/* 3434:     */     }
/* 3435:3405 */     knownMembers.remove(start);
/* 3436:3406 */     if (knownMembers.isEmpty())
/* 3437:     */     {
/* 3438:3407 */       List<Op03SimpleStatement> targets = start.getTargets();
/* 3439:3409 */       if (targets.size() != 1) {
/* 3440:3409 */         throw new ConfusedCFRException("Synthetic catch block has multiple targets");
/* 3441:     */       }
/* 3442:3410 */       knownMembers.add(insertBlockPadding("empty catch block", start, (Op03SimpleStatement)targets.get(0), blockIdentifier, statements));
/* 3443:     */     }
/* 3444:3420 */     List<Op03SimpleStatement> knownMemberList = ListFactory.newList(knownMembers);
/* 3445:3421 */     Collections.sort(knownMemberList, new CompareByIndex());
/* 3446:     */     
/* 3447:3423 */     List<Op03SimpleStatement> truncatedKnownMembers = ListFactory.newList();
/* 3448:3424 */     int x = statements.indexOf(knownMemberList.get(0));
/* 3449:3425 */     List<Op03SimpleStatement> flushNops = ListFactory.newList();
/* 3450:3426 */     for (int l = statements.size(); x < l; x++)
/* 3451:     */     {
/* 3452:3427 */       Op03SimpleStatement statement = (Op03SimpleStatement)statements.get(x);
/* 3453:3428 */       if (statement.isAgreedNop())
/* 3454:     */       {
/* 3455:3429 */         flushNops.add(statement);
/* 3456:     */       }
/* 3457:     */       else
/* 3458:     */       {
/* 3459:3432 */         if (!knownMembers.contains(statement)) {
/* 3460:     */           break;
/* 3461:     */         }
/* 3462:3433 */         truncatedKnownMembers.add(statement);
/* 3463:3434 */         if (!flushNops.isEmpty())
/* 3464:     */         {
/* 3465:3435 */           truncatedKnownMembers.addAll(flushNops);
/* 3466:3436 */           flushNops.clear();
/* 3467:     */         }
/* 3468:     */       }
/* 3469:     */     }
/* 3470:3440 */     for (Op03SimpleStatement inBlock : truncatedKnownMembers) {
/* 3471:3441 */       inBlock.containedInBlocks.add(blockIdentifier);
/* 3472:     */     }
/* 3473:3447 */     Op03SimpleStatement first = (Op03SimpleStatement)start.getTargets().get(0);
/* 3474:3448 */     first.markFirstStatementInBlock(blockIdentifier);
/* 3475:     */   }
/* 3476:     */   
/* 3477:     */   public static void identifyCatchBlocks(List<Op03SimpleStatement> in, BlockIdentifierFactory blockIdentifierFactory)
/* 3478:     */   {
/* 3479:3464 */     List<Op03SimpleStatement> catchStarts = Functional.filter(in, new TypeFilter(CatchStatement.class));
/* 3480:3465 */     for (Op03SimpleStatement catchStart : catchStarts)
/* 3481:     */     {
/* 3482:3466 */       CatchStatement catchStatement = (CatchStatement)catchStart.containedStatement;
/* 3483:3467 */       if (catchStatement.getCatchBlockIdent() == null)
/* 3484:     */       {
/* 3485:3468 */         BlockIdentifier blockIdentifier = blockIdentifierFactory.getNextBlockIdentifier(BlockType.CATCHBLOCK);
/* 3486:3469 */         catchStatement.setCatchBlockIdent(blockIdentifier);
/* 3487:3470 */         identifyCatchBlock(catchStart, blockIdentifier, in);
/* 3488:     */       }
/* 3489:     */     }
/* 3490:     */   }
/* 3491:     */   
/* 3492:     */   private static void extendCatchBlock(Op03SimpleStatement catchStart, List<Op03SimpleStatement> in)
/* 3493:     */   {
/* 3494:3481 */     int idx = in.indexOf(catchStart);
/* 3495:3482 */     CatchStatement catchStatement = (CatchStatement)catchStart.getStatement();
/* 3496:3483 */     BlockIdentifier blockIdentifier = catchStatement.getCatchBlockIdent();
/* 3497:3484 */     if (catchStart.getTargets().size() != 1) {
/* 3498:3484 */       return;
/* 3499:     */     }
/* 3500:3485 */     idx++;
/* 3501:3486 */     Op03SimpleStatement next = (Op03SimpleStatement)in.get(idx);
/* 3502:3487 */     if (next != catchStart.getTargets().get(0)) {
/* 3503:3487 */       return;
/* 3504:     */     }
/* 3505:3488 */     int tot = in.size();
/* 3506:3489 */     while ((idx < tot) && (((Op03SimpleStatement)in.get(idx)).getBlockIdentifiers().contains(blockIdentifier))) {
/* 3507:3490 */       idx++;
/* 3508:     */     }
/* 3509:3492 */     if (idx >= tot) {
/* 3510:3492 */       return;
/* 3511:     */     }
/* 3512:3497 */     Op03SimpleStatement prev = (Op03SimpleStatement)in.get(idx - 1);
/* 3513:3498 */     Set<BlockIdentifier> identifiers = prev.getBlockIdentifiers();
/* 3514:3499 */     while (idx < tot)
/* 3515:     */     {
/* 3516:3500 */       Op03SimpleStatement stm = (Op03SimpleStatement)in.get(idx);
/* 3517:3501 */       if (stm.getBlockIdentifiers().size() != identifiers.size() - 1) {
/* 3518:3501 */         return;
/* 3519:     */       }
/* 3520:3502 */       List<BlockIdentifier> diff = SetUtil.differenceAtakeBtoList(identifiers, stm.getBlockIdentifiers());
/* 3521:3503 */       if (diff.size() != 1) {
/* 3522:3503 */         return;
/* 3523:     */       }
/* 3524:3504 */       if (diff.get(0) != blockIdentifier) {
/* 3525:3504 */         return;
/* 3526:     */       }
/* 3527:3508 */       if (stm.getTargets().size() > 1) {
/* 3528:3508 */         return;
/* 3529:     */       }
/* 3530:3509 */       for (Op03SimpleStatement source : stm.getSources()) {
/* 3531:3510 */         if (!source.getBlockIdentifiers().contains(blockIdentifier)) {
/* 3532:3510 */           return;
/* 3533:     */         }
/* 3534:     */       }
/* 3535:3512 */       if (!stm.getSources().contains(prev)) {
/* 3536:3512 */         return;
/* 3537:     */       }
/* 3538:3514 */       stm.getBlockIdentifiers().add(blockIdentifier);
/* 3539:3515 */       prev = stm;
/* 3540:     */     }
/* 3541:     */   }
/* 3542:     */   
/* 3543:     */   public static void extendCatchBlocks(List<Op03SimpleStatement> in)
/* 3544:     */   {
/* 3545:3524 */     List<Op03SimpleStatement> catchStarts = Functional.filter(in, new TypeFilter(CatchStatement.class));
/* 3546:3525 */     for (Op03SimpleStatement catchStart : catchStarts)
/* 3547:     */     {
/* 3548:3526 */       CatchStatement catchStatement = (CatchStatement)catchStart.containedStatement;
/* 3549:3527 */       if (catchStatement.getCatchBlockIdent() != null) {
/* 3550:3528 */         extendCatchBlock(catchStart, in);
/* 3551:     */       }
/* 3552:     */     }
/* 3553:     */   }
/* 3554:     */   
/* 3555:     */   private static Op03SimpleStatement getLastContiguousBlockStatement(BlockIdentifier blockIdentifier, List<Op03SimpleStatement> in, Op03SimpleStatement preBlock)
/* 3556:     */   {
/* 3557:3537 */     if (preBlock.targets.isEmpty()) {
/* 3558:3537 */       return null;
/* 3559:     */     }
/* 3560:3538 */     Op03SimpleStatement currentStatement = (Op03SimpleStatement)preBlock.targets.get(0);
/* 3561:3539 */     int x = in.indexOf(currentStatement);
/* 3562:3541 */     if (!currentStatement.getBlockIdentifiers().contains(blockIdentifier)) {
/* 3563:3541 */       return null;
/* 3564:     */     }
/* 3565:3543 */     Op03SimpleStatement last = currentStatement;
/* 3566:3544 */     while (currentStatement.getBlockIdentifiers().contains(blockIdentifier))
/* 3567:     */     {
/* 3568:3545 */       x++;
/* 3569:3546 */       if (x >= in.size()) {
/* 3570:     */         break;
/* 3571:     */       }
/* 3572:3549 */       last = currentStatement;
/* 3573:3550 */       currentStatement = (Op03SimpleStatement)in.get(x);
/* 3574:     */     }
/* 3575:3552 */     return last;
/* 3576:     */   }
/* 3577:     */   
/* 3578:     */   private static void extendTryBlock(Op03SimpleStatement tryStatement, List<Op03SimpleStatement> in, DCCommonState dcCommonState)
/* 3579:     */   {
/* 3580:3559 */     TryStatement tryStatementInner = (TryStatement)tryStatement.getStatement();
/* 3581:3560 */     BlockIdentifier tryBlockIdent = tryStatementInner.getBlockIdentifier();
/* 3582:     */     
/* 3583:3562 */     Op03SimpleStatement currentStatement = (Op03SimpleStatement)tryStatement.targets.get(0);
/* 3584:3563 */     int x = in.indexOf(currentStatement);
/* 3585:3565 */     while (currentStatement.getBlockIdentifiers().contains(tryBlockIdent))
/* 3586:     */     {
/* 3587:3566 */       x++;
/* 3588:3567 */       if (x >= in.size()) {
/* 3589:3568 */         return;
/* 3590:     */       }
/* 3591:3570 */       currentStatement = (Op03SimpleStatement)in.get(x);
/* 3592:     */     }
/* 3593:3578 */     Set<JavaRefTypeInstance> caught = SetFactory.newSet();
/* 3594:3579 */     List<Op03SimpleStatement> targets = tryStatement.targets;
/* 3595:3580 */     int i = 1;
/* 3596:3580 */     for (int len = targets.size(); i < len; i++)
/* 3597:     */     {
/* 3598:3581 */       Statement statement = ((Op03SimpleStatement)targets.get(i)).getStatement();
/* 3599:3582 */       if ((statement instanceof CatchStatement))
/* 3600:     */       {
/* 3601:3583 */         CatchStatement catchStatement = (CatchStatement)statement;
/* 3602:3584 */         List<ExceptionGroup.Entry> exceptions = catchStatement.getExceptions();
/* 3603:3585 */         for (ExceptionGroup.Entry entry : exceptions) {
/* 3604:3586 */           caught.add(entry.getCatchType());
/* 3605:     */         }
/* 3606:     */       }
/* 3607:     */     }
/* 3608:3590 */     ExceptionCheck exceptionCheck = new ExceptionCheckImpl(dcCommonState, caught);
/* 3609:3593 */     while (!currentStatement.getStatement().canThrow(exceptionCheck))
/* 3610:     */     {
/* 3611:3594 */       Set<BlockIdentifier> validBlocks = SetFactory.newSet();
/* 3612:3595 */       validBlocks.add(tryBlockIdent);
/* 3613:3596 */       int i = 1;
/* 3614:3596 */       for (int len = tryStatement.targets.size(); i < len; i++)
/* 3615:     */       {
/* 3616:3597 */         Op03SimpleStatement tgt = (Op03SimpleStatement)tryStatement.targets.get(i);
/* 3617:3598 */         Statement tgtStatement = tgt.getStatement();
/* 3618:3599 */         if ((tgtStatement instanceof CatchStatement)) {
/* 3619:3600 */           validBlocks.add(((CatchStatement)tgtStatement).getCatchBlockIdent());
/* 3620:3601 */         } else if ((tgtStatement instanceof FinallyStatement)) {
/* 3621:3602 */           validBlocks.add(((FinallyStatement)tgtStatement).getFinallyBlockIdent());
/* 3622:     */         } else {
/* 3623:3604 */           return;
/* 3624:     */         }
/* 3625:     */       }
/* 3626:3608 */       boolean foundSource = false;
/* 3627:3609 */       for (Op03SimpleStatement source : currentStatement.sources)
/* 3628:     */       {
/* 3629:3610 */         if (!SetUtil.hasIntersection(validBlocks, source.getBlockIdentifiers())) {
/* 3630:3610 */           return;
/* 3631:     */         }
/* 3632:3611 */         if (source.getBlockIdentifiers().contains(tryBlockIdent)) {
/* 3633:3611 */           foundSource = true;
/* 3634:     */         }
/* 3635:     */       }
/* 3636:3614 */       if (!foundSource) {
/* 3637:3614 */         return;
/* 3638:     */       }
/* 3639:3619 */       currentStatement.getBlockIdentifiers().add(tryBlockIdent);
/* 3640:     */       
/* 3641:3621 */       x++;
/* 3642:3622 */       if (x >= in.size()) {
/* 3643:     */         break;
/* 3644:     */       }
/* 3645:3623 */       Op03SimpleStatement nextStatement = (Op03SimpleStatement)in.get(x);
/* 3646:3624 */       if (!currentStatement.getTargets().contains(nextStatement)) {
/* 3647:3626 */         for (Op03SimpleStatement source : nextStatement.getSources()) {
/* 3648:3627 */           if (!source.getBlockIdentifiers().contains(tryBlockIdent)) {
/* 3649:     */             return;
/* 3650:     */           }
/* 3651:     */         }
/* 3652:     */       }
/* 3653:3630 */       currentStatement = nextStatement;
/* 3654:     */     }
/* 3655:     */   }
/* 3656:     */   
/* 3657:     */   public static void extendTryBlocks(DCCommonState dcCommonState, List<Op03SimpleStatement> in)
/* 3658:     */   {
/* 3659:3635 */     List<Op03SimpleStatement> tries = Functional.filter(in, new TypeFilter(TryStatement.class));
/* 3660:3636 */     for (Op03SimpleStatement tryStatement : tries) {
/* 3661:3637 */       extendTryBlock(tryStatement, in, dcCommonState);
/* 3662:     */     }
/* 3663:     */   }
/* 3664:     */   
/* 3665:     */   public static List<Op03SimpleStatement> removeRedundantTries(List<Op03SimpleStatement> statements)
/* 3666:     */   {
/* 3667:3642 */     List<Op03SimpleStatement> tryStarts = Functional.filter(statements, new TypeFilter(TryStatement.class));
/* 3668:     */     
/* 3669:     */ 
/* 3670:     */ 
/* 3671:     */ 
/* 3672:     */ 
/* 3673:3648 */     boolean effect = false;
/* 3674:3649 */     Collections.reverse(tryStarts);
/* 3675:3650 */     LinkedList<Op03SimpleStatement> starts = ListFactory.newLinkedList();
/* 3676:3651 */     starts.addAll(tryStarts);
/* 3677:3652 */     while (!starts.isEmpty())
/* 3678:     */     {
/* 3679:3653 */       Op03SimpleStatement trys = (Op03SimpleStatement)starts.removeFirst();
/* 3680:3654 */       Statement stm = trys.getStatement();
/* 3681:3655 */       if ((stm instanceof TryStatement))
/* 3682:     */       {
/* 3683:3656 */         TryStatement tryStatement = (TryStatement)stm;
/* 3684:3657 */         BlockIdentifier tryBlock = tryStatement.getBlockIdentifier();
/* 3685:3658 */         if ((trys.targets.isEmpty()) || (!((Op03SimpleStatement)trys.targets.get(0)).getBlockIdentifiers().contains(tryBlock)))
/* 3686:     */         {
/* 3687:3660 */           Op03SimpleStatement codeTarget = (Op03SimpleStatement)trys.targets.get(0);
/* 3688:3662 */           for (Op03SimpleStatement target : trys.targets) {
/* 3689:3663 */             target.removeSource(trys);
/* 3690:     */           }
/* 3691:3665 */           trys.targets.clear();
/* 3692:3666 */           for (Op03SimpleStatement source : trys.sources)
/* 3693:     */           {
/* 3694:3667 */             source.replaceTarget(trys, codeTarget);
/* 3695:3668 */             codeTarget.addSource(source);
/* 3696:     */           }
/* 3697:3670 */           trys.sources.clear();
/* 3698:3671 */           effect = true;
/* 3699:     */         }
/* 3700:     */       }
/* 3701:     */     }
/* 3702:3675 */     if (effect)
/* 3703:     */     {
/* 3704:3676 */       statements = Cleaner.removeUnreachableCode(statements, false);
/* 3705:3677 */       statements = Cleaner.sortAndRenumber(statements);
/* 3706:     */     }
/* 3707:3680 */     return statements;
/* 3708:     */   }
/* 3709:     */   
/* 3710:     */   private static boolean verifyLinearBlock(Op03SimpleStatement current, BlockIdentifier block, int num)
/* 3711:     */   {
/* 3712:3684 */     while (num >= 0)
/* 3713:     */     {
/* 3714:3685 */       if (num > 0)
/* 3715:     */       {
/* 3716:3686 */         if (((current.getStatement() instanceof Nop)) && (current.targets.size() == 0)) {
/* 3717:     */           break;
/* 3718:     */         }
/* 3719:3689 */         if (current.targets.size() != 1) {
/* 3720:3690 */           return false;
/* 3721:     */         }
/* 3722:3692 */         if (!current.containedInBlocks.contains(block)) {
/* 3723:3693 */           return false;
/* 3724:     */         }
/* 3725:3695 */         current = (Op03SimpleStatement)current.targets.get(0);
/* 3726:     */       }
/* 3727:3697 */       else if (!current.containedInBlocks.contains(block))
/* 3728:     */       {
/* 3729:3698 */         return false;
/* 3730:     */       }
/* 3731:3701 */       num--;
/* 3732:     */     }
/* 3733:3704 */     for (Op03SimpleStatement target : current.targets) {
/* 3734:3705 */       if (target.containedInBlocks.contains(block)) {
/* 3735:3706 */         return false;
/* 3736:     */       }
/* 3737:     */     }
/* 3738:3709 */     return true;
/* 3739:     */   }
/* 3740:     */   
/* 3741:     */   private static boolean removeSynchronizedCatchBlock(Op03SimpleStatement start, List<Op03SimpleStatement> statements)
/* 3742:     */   {
/* 3743:3721 */     BlockIdentifier block = start.firstStatementInThisBlock;
/* 3744:3723 */     if (start.sources.size() != 1) {
/* 3745:3723 */       return false;
/* 3746:     */     }
/* 3747:3724 */     Op03SimpleStatement catchStatementContainer = (Op03SimpleStatement)start.sources.get(0);
/* 3748:3726 */     if (catchStatementContainer.sources.size() != 1) {
/* 3749:3726 */       return false;
/* 3750:     */     }
/* 3751:3727 */     Statement catchOrFinally = catchStatementContainer.containedStatement;
/* 3752:3728 */     boolean isFinally = false;
/* 3753:3729 */     if ((catchOrFinally instanceof CatchStatement))
/* 3754:     */     {
/* 3755:3730 */       CatchStatement catchStatement = (CatchStatement)catchStatementContainer.containedStatement;
/* 3756:3731 */       List<ExceptionGroup.Entry> exceptions = catchStatement.getExceptions();
/* 3757:3732 */       if (exceptions.size() != 1) {
/* 3758:3732 */         return false;
/* 3759:     */       }
/* 3760:3733 */       ExceptionGroup.Entry exception = (ExceptionGroup.Entry)exceptions.get(0);
/* 3761:3735 */       if (!exception.isJustThrowable()) {
/* 3762:3735 */         return false;
/* 3763:     */       }
/* 3764:     */     }
/* 3765:3736 */     else if ((catchOrFinally instanceof FinallyStatement))
/* 3766:     */     {
/* 3767:3737 */       isFinally = true;
/* 3768:     */     }
/* 3769:     */     else
/* 3770:     */     {
/* 3771:3739 */       return false;
/* 3772:     */     }
/* 3773:3743 */     if (!verifyLinearBlock(start, block, 2)) {
/* 3774:3744 */       return false;
/* 3775:     */     }
/* 3776:     */     Op03SimpleStatement rethrow;
/* 3777:     */     Op03SimpleStatement variableAss;
/* 3778:     */     Op03SimpleStatement monitorExit;
/* 3779:     */     Op03SimpleStatement rethrow;
/* 3780:3751 */     if (isFinally)
/* 3781:     */     {
/* 3782:3752 */       Op03SimpleStatement monitorExit = start;
/* 3783:3753 */       Op03SimpleStatement variableAss = null;
/* 3784:3754 */       rethrow = null;
/* 3785:     */     }
/* 3786:     */     else
/* 3787:     */     {
/* 3788:3756 */       variableAss = start;
/* 3789:3757 */       monitorExit = (Op03SimpleStatement)start.targets.get(0);
/* 3790:3758 */       rethrow = (Op03SimpleStatement)monitorExit.targets.get(0);
/* 3791:     */     }
/* 3792:3761 */     WildcardMatch wildcardMatch = new WildcardMatch();
/* 3793:3763 */     if ((!isFinally) && 
/* 3794:3764 */       (!wildcardMatch.match(new AssignmentSimple(wildcardMatch.getLValueWildCard("var"), wildcardMatch.getExpressionWildCard("e")), variableAss.containedStatement))) {
/* 3795:3767 */       return false;
/* 3796:     */     }
/* 3797:3771 */     if (!wildcardMatch.match(new MonitorExitStatement(wildcardMatch.getExpressionWildCard("lock")), monitorExit.containedStatement)) {
/* 3798:3774 */       return false;
/* 3799:     */     }
/* 3800:3777 */     if ((!isFinally) && 
/* 3801:3778 */       (!wildcardMatch.match(new ThrowStatement(new LValueExpression(wildcardMatch.getLValueWildCard("var"))), rethrow.containedStatement))) {
/* 3802:3780 */       return false;
/* 3803:     */     }
/* 3804:3783 */     Op03SimpleStatement tryStatementContainer = (Op03SimpleStatement)catchStatementContainer.sources.get(0);
/* 3805:3785 */     if (isFinally)
/* 3806:     */     {
/* 3807:3786 */       MonitorExitStatement monitorExitStatement = (MonitorExitStatement)monitorExit.getStatement();
/* 3808:3787 */       TryStatement tryStatement = (TryStatement)tryStatementContainer.getStatement();
/* 3809:3788 */       tryStatement.addExitMutex(monitorExitStatement.getMonitor());
/* 3810:     */     }
/* 3811:3796 */     tryStatementContainer.removeTarget(catchStatementContainer);
/* 3812:3797 */     catchStatementContainer.removeSource(tryStatementContainer);
/* 3813:3798 */     catchStatementContainer.nopOut();
/* 3814:3799 */     if (!isFinally) {
/* 3815:3800 */       variableAss.nopOut();
/* 3816:     */     }
/* 3817:3802 */     monitorExit.nopOut();
/* 3818:3803 */     if (!isFinally)
/* 3819:     */     {
/* 3820:3804 */       for (Op03SimpleStatement target : rethrow.targets)
/* 3821:     */       {
/* 3822:3805 */         target.removeSource(rethrow);
/* 3823:3806 */         rethrow.removeTarget(target);
/* 3824:     */       }
/* 3825:3808 */       rethrow.nopOut();
/* 3826:     */     }
/* 3827:     */     BlockIdentifier tryBlock;
/* 3828:3815 */     if ((tryStatementContainer.targets.size() == 1) && (!isFinally))
/* 3829:     */     {
/* 3830:3816 */       TryStatement tryStatement = (TryStatement)tryStatementContainer.containedStatement;
/* 3831:3817 */       tryBlock = tryStatement.getBlockIdentifier();
/* 3832:3818 */       tryStatementContainer.nopOut();
/* 3833:3822 */       for (Op03SimpleStatement statement : statements) {
/* 3834:3823 */         statement.containedInBlocks.remove(tryBlock);
/* 3835:     */       }
/* 3836:     */     }
/* 3837:3826 */     return true;
/* 3838:     */   }
/* 3839:     */   
/* 3840:     */   public static void commentMonitors(List<Op03SimpleStatement> statements)
/* 3841:     */   {
/* 3842:3830 */     List<Op03SimpleStatement> monitors = Functional.filter(statements, new TypeFilter(MonitorStatement.class));
/* 3843:3831 */     if (monitors.isEmpty()) {
/* 3844:3831 */       return;
/* 3845:     */     }
/* 3846:3832 */     for (Op03SimpleStatement monitor : monitors) {
/* 3847:3833 */       monitor.replaceStatement(new CommentStatement(monitor.getStatement()));
/* 3848:     */     }
/* 3849:3840 */     for (Iterator i$ = monitors.iterator(); i$.hasNext();)
/* 3850:     */     {
/* 3851:3840 */       monitor = (Op03SimpleStatement)i$.next();
/* 3852:     */       
/* 3853:     */ 
/* 3854:     */ 
/* 3855:3844 */       target = (Op03SimpleStatement)monitor.getTargets().get(0);
/* 3856:3845 */       monitorLast = SetFactory.newSet(monitor.getBlockIdentifiers());
/* 3857:3846 */       monitorLast.removeAll(target.getBlockIdentifiers());
/* 3858:3847 */       if (!monitorLast.isEmpty()) {
/* 3859:3848 */         for (Op03SimpleStatement source : ListFactory.newList(monitor.sources))
/* 3860:     */         {
/* 3861:3849 */           Set<BlockIdentifier> sourceBlocks = source.getBlockIdentifiers();
/* 3862:3850 */           if (!sourceBlocks.containsAll(monitorLast))
/* 3863:     */           {
/* 3864:3854 */             source.replaceTarget(monitor, target);
/* 3865:3855 */             monitor.removeSource(source);
/* 3866:3856 */             target.addSource(source);
/* 3867:     */           }
/* 3868:     */         }
/* 3869:     */       }
/* 3870:     */     }
/* 3871:     */     Op03SimpleStatement monitor;
/* 3872:     */     Op03SimpleStatement target;
/* 3873:     */     Set<BlockIdentifier> monitorLast;
/* 3874:     */   }
/* 3875:     */   
/* 3876:     */   public static void removeSynchronizedCatchBlocks(Options options, List<Op03SimpleStatement> in)
/* 3877:     */   {
/* 3878:3884 */     if (!((Boolean)options.getOption(OptionsImpl.TIDY_MONITORS)).booleanValue()) {
/* 3879:3884 */       return;
/* 3880:     */     }
/* 3881:3886 */     List<Op03SimpleStatement> catchStarts = Functional.filter(in, new FindBlockStarts(BlockType.CATCHBLOCK));
/* 3882:3887 */     if (catchStarts.isEmpty()) {
/* 3883:3887 */       return;
/* 3884:     */     }
/* 3885:3888 */     boolean effect = false;
/* 3886:3889 */     for (Op03SimpleStatement catchStart : catchStarts) {
/* 3887:3890 */       effect = (removeSynchronizedCatchBlock(catchStart, in)) || (effect);
/* 3888:     */     }
/* 3889:3892 */     if (effect) {
/* 3890:3893 */       removePointlessJumps(in);
/* 3891:     */     }
/* 3892:     */   }
/* 3893:     */   
/* 3894:     */   private static final class FindBlockStarts
/* 3895:     */     implements Predicate<Op03SimpleStatement>
/* 3896:     */   {
/* 3897:     */     private final BlockType blockType;
/* 3898:     */     
/* 3899:     */     public FindBlockStarts(BlockType blockType)
/* 3900:     */     {
/* 3901:3901 */       this.blockType = blockType;
/* 3902:     */     }
/* 3903:     */     
/* 3904:     */     public boolean test(Op03SimpleStatement in)
/* 3905:     */     {
/* 3906:3906 */       BlockIdentifier blockIdentifier = in.firstStatementInThisBlock;
/* 3907:3907 */       if (blockIdentifier == null) {
/* 3908:3907 */         return false;
/* 3909:     */       }
/* 3910:3908 */       return blockIdentifier.getBlockType() == this.blockType;
/* 3911:     */     }
/* 3912:     */   }
/* 3913:     */   
/* 3914:     */   private static void optimiseForTypes(Op03SimpleStatement statement)
/* 3915:     */   {
/* 3916:3913 */     IfStatement ifStatement = (IfStatement)statement.containedStatement;
/* 3917:3914 */     ifStatement.optimiseForTypes();
/* 3918:     */   }
/* 3919:     */   
/* 3920:     */   public static void optimiseForTypes(List<Op03SimpleStatement> statements)
/* 3921:     */   {
/* 3922:3918 */     List<Op03SimpleStatement> conditionals = Functional.filter(statements, new TypeFilter(IfStatement.class));
/* 3923:3919 */     for (Op03SimpleStatement conditional : conditionals) {
/* 3924:3920 */       optimiseForTypes(conditional);
/* 3925:     */     }
/* 3926:     */   }
/* 3927:     */   
/* 3928:     */   public static void rejoinBlocks(List<Op03SimpleStatement> statements)
/* 3929:     */   {
/* 3930:3929 */     Set<BlockIdentifier> lastBlocks = SetFactory.newSet();
/* 3931:3930 */     Set<BlockIdentifier> haveLeft = SetFactory.newSet();
/* 3932:     */     
/* 3933:     */ 
/* 3934:3933 */     Set<BlockIdentifier> blackListed = SetFactory.newSet();
/* 3935:     */     
/* 3936:3935 */     int x = 0;
/* 3937:3935 */     for (int len = statements.size(); x < len; x++)
/* 3938:     */     {
/* 3939:3936 */       Op03SimpleStatement stm = (Op03SimpleStatement)statements.get(x);
/* 3940:3937 */       Statement stmInner = stm.getStatement();
/* 3941:3938 */       if ((stmInner instanceof CatchStatement))
/* 3942:     */       {
/* 3943:3939 */         CatchStatement catchStatement = (CatchStatement)stmInner;
/* 3944:3940 */         for (ExceptionGroup.Entry entry : catchStatement.getExceptions()) {
/* 3945:3941 */           blackListed.add(entry.getTryBlockIdentifier());
/* 3946:     */         }
/* 3947:     */       }
/* 3948:3945 */       Set<BlockIdentifier> blocks = stm.getBlockIdentifiers();
/* 3949:3946 */       blocks.removeAll(blackListed);
/* 3950:3948 */       for (BlockIdentifier ident : blocks) {
/* 3951:3954 */         if (haveLeft.contains(ident)) {
/* 3952:3956 */           for (int y = x - 1; y >= 0; y--)
/* 3953:     */           {
/* 3954:3957 */             Op03SimpleStatement backFill = (Op03SimpleStatement)statements.get(y);
/* 3955:3958 */             if (!backFill.getBlockIdentifiers().add(ident)) {
/* 3956:     */               break;
/* 3957:     */             }
/* 3958:     */           }
/* 3959:     */         }
/* 3960:     */       }
/* 3961:3962 */       for (BlockIdentifier wasIn : lastBlocks) {
/* 3962:3963 */         if (!blocks.contains(wasIn)) {
/* 3963:3963 */           haveLeft.add(wasIn);
/* 3964:     */         }
/* 3965:     */       }
/* 3966:3965 */       lastBlocks = blocks;
/* 3967:     */     }
/* 3968:     */   }
/* 3969:     */   
/* 3970:     */   public static void rejoinBlocks2(List<Op03SimpleStatement> statements)
/* 3971:     */   {
/* 3972:3974 */     Map<BlockIdentifier, Integer> lastSeen = MapFactory.newMap();
/* 3973:3975 */     int x = 0;
/* 3974:3975 */     for (int len = statements.size(); x < len; x++)
/* 3975:     */     {
/* 3976:3976 */       Op03SimpleStatement stm = (Op03SimpleStatement)statements.get(x);
/* 3977:3977 */       for (BlockIdentifier identifier : stm.getBlockIdentifiers())
/* 3978:     */       {
/* 3979:3979 */         Integer prev = (Integer)lastSeen.get(identifier);
/* 3980:3980 */         if ((prev != null) && (prev.intValue() < x - 1)) {
/* 3981:3981 */           for (int y = prev.intValue() + 1; y < x; y++) {
/* 3982:3982 */             ((Op03SimpleStatement)statements.get(y)).getBlockIdentifiers().add(identifier);
/* 3983:     */           }
/* 3984:     */         }
/* 3985:3985 */         lastSeen.put(identifier, Integer.valueOf(x));
/* 3986:     */       }
/* 3987:     */     }
/* 3988:     */   }
/* 3989:     */   
/* 3990:     */   private static void removePointlessSwitchDefault(Op03SimpleStatement swtch)
/* 3991:     */   {
/* 3992:3991 */     SwitchStatement switchStatement = (SwitchStatement)swtch.getStatement();
/* 3993:3992 */     BlockIdentifier switchBlock = switchStatement.getSwitchBlock();
/* 3994:3996 */     if (swtch.getTargets().size() <= 1) {
/* 3995:3996 */       return;
/* 3996:     */     }
/* 3997:3997 */     for (Op03SimpleStatement tgt : swtch.getTargets())
/* 3998:     */     {
/* 3999:3998 */       Statement statement = tgt.getStatement();
/* 4000:3999 */       if ((statement instanceof CaseStatement))
/* 4001:     */       {
/* 4002:4000 */         CaseStatement caseStatement = (CaseStatement)statement;
/* 4003:4001 */         if ((caseStatement.getSwitchBlock() == switchBlock) && 
/* 4004:4002 */           (caseStatement.isDefault()))
/* 4005:     */         {
/* 4006:4003 */           if (tgt.targets.size() != 1) {
/* 4007:4003 */             return;
/* 4008:     */           }
/* 4009:4004 */           Op03SimpleStatement afterTgt = (Op03SimpleStatement)tgt.targets.get(0);
/* 4010:4005 */           if (afterTgt.containedInBlocks.contains(switchBlock)) {
/* 4011:4006 */             return;
/* 4012:     */           }
/* 4013:4009 */           tgt.nopOut();
/* 4014:4010 */           return;
/* 4015:     */         }
/* 4016:     */       }
/* 4017:     */     }
/* 4018:     */   }
/* 4019:     */   
/* 4020:     */   public static void removePointlessSwitchDefaults(List<Op03SimpleStatement> statements)
/* 4021:     */   {
/* 4022:4019 */     List<Op03SimpleStatement> switches = Functional.filter(statements, new TypeFilter(SwitchStatement.class));
/* 4023:4021 */     for (Op03SimpleStatement swtch : switches) {
/* 4024:4022 */       removePointlessSwitchDefault(swtch);
/* 4025:     */     }
/* 4026:     */   }
/* 4027:     */   
/* 4028:     */   public static List<Op03SimpleStatement> convertIndirectTryLeavesToAnonymousBreaks(List<Op03SimpleStatement> statements)
/* 4029:     */   {
/* 4030:4027 */     Set<BlockIdentifier> blocksToRemoveCompletely = SetFactory.newSet();
/* 4031:4029 */     for (Op03SimpleStatement in : statements)
/* 4032:     */     {
/* 4033:4030 */       Statement statement = in.getStatement();
/* 4034:4031 */       if ((statement instanceof IfStatement))
/* 4035:     */       {
/* 4036:4032 */         IfStatement ifStatement = (IfStatement)statement;
/* 4037:4033 */         if (!ifStatement.hasElseBlock())
/* 4038:     */         {
/* 4039:4034 */           Op03SimpleStatement afterIf = (Op03SimpleStatement)in.targets.get(1);
/* 4040:4035 */           Statement indirect = afterIf.getStatement();
/* 4041:4036 */           if (indirect.getClass() == GotoStatement.class)
/* 4042:     */           {
/* 4043:4037 */             GotoStatement gotoStatement = (GotoStatement)indirect;
/* 4044:4038 */             if (gotoStatement.getJumpType() == JumpType.GOTO_OUT_OF_TRY)
/* 4045:     */             {
/* 4046:4039 */               Op03SimpleStatement eventualTarget = (Op03SimpleStatement)afterIf.targets.get(0);
/* 4047:4040 */               ifStatement.setJumpType(JumpType.BREAK_ANONYMOUS);
/* 4048:4041 */               in.replaceTarget(afterIf, eventualTarget);
/* 4049:4042 */               afterIf.removeSource(in);
/* 4050:4043 */               eventualTarget.addSource(in);
/* 4051:4044 */               blocksToRemoveCompletely.add(ifStatement.getKnownIfBlock());
/* 4052:4045 */               ifStatement.setKnownBlocks(null, null);
/* 4053:     */             }
/* 4054:     */           }
/* 4055:     */         }
/* 4056:     */       }
/* 4057:     */     }
/* 4058:4048 */     if (blocksToRemoveCompletely.isEmpty()) {
/* 4059:4048 */       return statements;
/* 4060:     */     }
/* 4061:4050 */     for (Op03SimpleStatement stm : statements) {
/* 4062:4051 */       stm.getBlockIdentifiers().removeAll(blocksToRemoveCompletely);
/* 4063:     */     }
/* 4064:4053 */     statements = Cleaner.removeUnreachableCode(statements, false);
/* 4065:4054 */     return statements;
/* 4066:     */   }
/* 4067:     */   
/* 4068:     */   public static void labelAnonymousBlocks(List<Op03SimpleStatement> statements, BlockIdentifierFactory blockIdentifierFactory)
/* 4069:     */   {
/* 4070:4058 */     List<Op03SimpleStatement> anonBreaks = Functional.filter(statements, new Predicate()
/* 4071:     */     {
/* 4072:     */       public boolean test(Op03SimpleStatement in)
/* 4073:     */       {
/* 4074:4061 */         Statement statement = in.getStatement();
/* 4075:4062 */         if (!(statement instanceof JumpingStatement)) {
/* 4076:4062 */           return false;
/* 4077:     */         }
/* 4078:4063 */         JumpType jumpType = ((JumpingStatement)statement).getJumpType();
/* 4079:4064 */         return jumpType == JumpType.BREAK_ANONYMOUS;
/* 4080:     */       }
/* 4081:     */     });
/* 4082:4067 */     if (anonBreaks.isEmpty()) {
/* 4083:4067 */       return;
/* 4084:     */     }
/* 4085:4072 */     Set<Op03SimpleStatement> targets = SetFactory.newOrderedSet();
/* 4086:4073 */     for (Op03SimpleStatement anonBreak : anonBreaks)
/* 4087:     */     {
/* 4088:4074 */       JumpingStatement jumpingStatement = (JumpingStatement)anonBreak.getStatement();
/* 4089:4075 */       targets.add((Op03SimpleStatement)jumpingStatement.getJumpTarget().getContainer());
/* 4090:     */     }
/* 4091:4078 */     int idx = 0;
/* 4092:4079 */     for (Op03SimpleStatement target : targets)
/* 4093:     */     {
/* 4094:4080 */       BlockIdentifier blockIdentifier = blockIdentifierFactory.getNextBlockIdentifier(BlockType.ANONYMOUS);
/* 4095:4081 */       InstrIndex targetIndex = target.getIndex();
/* 4096:4082 */       Op03SimpleStatement anonTarget = new Op03SimpleStatement(target.getBlockIdentifiers(), new AnonBreakTarget(blockIdentifier), targetIndex.justBefore());
/* 4097:     */       
/* 4098:4084 */       List<Op03SimpleStatement> sources = ListFactory.newList(target.getSources());
/* 4099:4085 */       for (Op03SimpleStatement source : sources) {
/* 4100:4086 */         if (targetIndex.isBackJumpTo(source))
/* 4101:     */         {
/* 4102:4087 */           target.removeSource(source);
/* 4103:4088 */           source.replaceTarget(target, anonTarget);
/* 4104:4089 */           anonTarget.addSource(source);
/* 4105:     */         }
/* 4106:     */       }
/* 4107:4092 */       target.addSource(anonTarget);
/* 4108:4093 */       anonTarget.addTarget(target);
/* 4109:4094 */       int pos = statements.indexOf(target);
/* 4110:4095 */       statements.add(pos, anonTarget);
/* 4111:     */     }
/* 4112:     */   }
/* 4113:     */   
/* 4114:     */   public static void replaceStackVarsWithLocals(List<Op03SimpleStatement> statements)
/* 4115:     */   {
/* 4116:4100 */     StackVarToLocalRewriter rewriter = new StackVarToLocalRewriter();
/* 4117:4101 */     for (Op03SimpleStatement statement : statements) {
/* 4118:4102 */       statement.rewrite(rewriter);
/* 4119:     */     }
/* 4120:     */   }
/* 4121:     */   
/* 4122:     */   public static void narrowAssignmentTypes(Method method, List<Op03SimpleStatement> statements)
/* 4123:     */   {
/* 4124:4107 */     NarrowingTypeRewriter narrowingTypeRewriter = new NarrowingTypeRewriter();
/* 4125:4108 */     narrowingTypeRewriter.rewrite(method, statements);
/* 4126:     */   }
/* 4127:     */   
/* 4128:     */   public String toString()
/* 4129:     */   {
/* 4130:4113 */     Set<Integer> blockIds = SetFactory.newSet();
/* 4131:4114 */     for (BlockIdentifier b : this.containedInBlocks) {
/* 4132:4115 */       blockIds.add(Integer.valueOf(b.getIndex()));
/* 4133:     */     }
/* 4134:4117 */     return "" + blockIds + " " + this.index + " : " + this.containedStatement;
/* 4135:     */   }
/* 4136:     */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement
 * JD-Core Version:    0.7.0.1
 */