/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.MemberFunctionInvokation;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.MemberFunctionInvokationWildcard;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredComment;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredExpressionStatement;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/* 13:   */ import org.benf.cfr.reader.entities.Method;
/* 14:   */ 
/* 15:   */ public class ConstructorUtils
/* 16:   */ {
/* 17:   */   public static MethodPrototype getDelegatingPrototype(Method constructor)
/* 18:   */   {
/* 19:18 */     List<Op04StructuredStatement> statements = MiscStatementTools.getBlockStatements(constructor.getAnalysis());
/* 20:19 */     if (statements == null) {
/* 21:19 */       return null;
/* 22:   */     }
/* 23:20 */     for (Op04StructuredStatement statement : statements)
/* 24:   */     {
/* 25:21 */       StructuredStatement structuredStatement = statement.getStatement();
/* 26:22 */       if (!(structuredStatement instanceof StructuredComment))
/* 27:   */       {
/* 28:23 */         if (!(structuredStatement instanceof StructuredExpressionStatement)) {
/* 29:23 */           return null;
/* 30:   */         }
/* 31:24 */         StructuredExpressionStatement structuredExpressionStatement = (StructuredExpressionStatement)structuredStatement;
/* 32:   */         
/* 33:26 */         WildcardMatch wcm1 = new WildcardMatch();
/* 34:27 */         StructuredStatement test = new StructuredExpressionStatement(wcm1.getMemberFunction("m", null, true, new LValueExpression(wcm1.getLValueWildCard("o")), (List)null), false);
/* 35:28 */         if (test.equals(structuredExpressionStatement))
/* 36:   */         {
/* 37:29 */           MemberFunctionInvokation m = wcm1.getMemberFunction("m").getMatch();
/* 38:30 */           MethodPrototype prototype = m.getMethodPrototype();
/* 39:31 */           return prototype;
/* 40:   */         }
/* 41:33 */         return null;
/* 42:   */       }
/* 43:   */     }
/* 44:35 */     return null;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public static boolean isDelegating(Method constructor)
/* 48:   */   {
/* 49:39 */     return getDelegatingPrototype(constructor) != null;
/* 50:   */   }
/* 51:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.ConstructorUtils
 * JD-Core Version:    0.7.0.1
 */