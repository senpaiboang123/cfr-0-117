/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*   2:    */ 
/*   3:    */ import java.util.LinkedList;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Map;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.AbstractMatchResultIterator;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.CollectMatch;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.KleenePlus;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.KleeneStar;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchSequence;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.Matcher;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.ResetAfterTest;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.MiscStatementTools;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.BooleanExpression;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CastExpression;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.NotOperation;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral.LiteralType;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  26:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
/*  27:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.ExpressionWildcard;
/*  28:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.ListWildcard;
/*  29:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  30:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.AbstractStructuredStatement;
/*  31:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.Block;
/*  32:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredAssignment;
/*  33:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredBreak;
/*  34:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredCase;
/*  35:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredIf;
/*  36:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredSwitch;
/*  37:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.BeginBlock;
/*  38:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.EndBlock;
/*  39:    */ import org.benf.cfr.reader.bytecode.analysis.types.TypeConstants;
/*  40:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  41:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  42:    */ import org.benf.cfr.reader.util.ClassFileVersion;
/*  43:    */ import org.benf.cfr.reader.util.ListFactory;
/*  44:    */ import org.benf.cfr.reader.util.MapFactory;
/*  45:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  46:    */ import org.benf.cfr.reader.util.getopt.Options;
/*  47:    */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*  48:    */ 
/*  49:    */ public class SwitchStringRewriter
/*  50:    */   implements Op04Rewriter
/*  51:    */ {
/*  52:    */   private final Options options;
/*  53:    */   private final ClassFileVersion classFileVersion;
/*  54:    */   
/*  55:    */   public SwitchStringRewriter(Options options, ClassFileVersion classFileVersion)
/*  56:    */   {
/*  57: 34 */     this.options = options;
/*  58: 35 */     this.classFileVersion = classFileVersion;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void rewrite(Op04StructuredStatement root)
/*  62:    */   {
/*  63: 40 */     if (!((Boolean)this.options.getOption(OptionsImpl.STRING_SWITCH, this.classFileVersion)).booleanValue()) {
/*  64: 40 */       return;
/*  65:    */     }
/*  66: 42 */     List<StructuredStatement> structuredStatements = MiscStatementTools.linearise(root);
/*  67: 43 */     if (structuredStatements == null) {
/*  68: 43 */       return;
/*  69:    */     }
/*  70: 47 */     MatchIterator<StructuredStatement> mi = new MatchIterator(structuredStatements);
/*  71:    */     
/*  72: 49 */     WildcardMatch wcm1 = new WildcardMatch();
/*  73: 50 */     WildcardMatch wcm2 = new WildcardMatch();
/*  74: 51 */     WildcardMatch wcm3 = new WildcardMatch();
/*  75:    */     
/*  76: 53 */     Matcher<StructuredStatement> m = new ResetAfterTest(wcm1, new MatchSequence(new Matcher[] { new CollectMatch("ass1", new StructuredAssignment(wcm1.getLValueWildCard("stringobject"), wcm1.getExpressionWildCard("originalstring"))), new CollectMatch("ass2", new StructuredAssignment(wcm1.getLValueWildCard("intermed"), wcm1.getExpressionWildCard("defaultintermed"))), new CollectMatch("switch1", new StructuredSwitch(wcm1.getMemberFunction("switch", "hashCode", new LValueExpression(wcm1.getLValueWildCard("stringobject"))), null, wcm1.getBlockIdentifier("switchblock"))), new BeginBlock(null), new KleenePlus(new ResetAfterTest(wcm2, new MatchSequence(new Matcher[] { new StructuredCase(wcm2.getList("hashvals"), null, null, wcm2.getBlockIdentifier("case")), new BeginBlock(null), new KleeneStar(new ResetAfterTest(wcm3, new MatchSequence(new Matcher[] { new StructuredIf(new BooleanExpression(wcm3.getMemberFunction("collision", "equals", new LValueExpression(wcm1.getLValueWildCard("stringobject")), new Expression[] { wcm3.getExpressionWildCard("stringvalue") })), null), new BeginBlock(null), new StructuredAssignment(wcm1.getLValueWildCard("intermed"), wcm3.getExpressionWildCard("case2id")), new StructuredBreak(wcm1.getBlockIdentifier("switchblock"), true), new EndBlock(null) }))), new StructuredIf(new NotOperation(new BooleanExpression(wcm2.getMemberFunction("anticollision", "equals", new LValueExpression(wcm1.getLValueWildCard("stringobject")), new Expression[] { wcm2.getExpressionWildCard("stringvalue") }))), null), new StructuredBreak(wcm1.getBlockIdentifier("switchblock"), true), new StructuredAssignment(wcm1.getLValueWildCard("intermed"), wcm2.getExpressionWildCard("case2id")), new KleeneStar(new StructuredBreak(wcm1.getBlockIdentifier("switchblock"), true)), new EndBlock(null) }))), new EndBlock(null), new CollectMatch("switch2", new StructuredSwitch(new LValueExpression(wcm1.getLValueWildCard("intermed")), null, wcm1.getBlockIdentifier("switchblock2"))) }));
/*  77:    */     
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115: 92 */     SwitchStringMatchResultCollector matchResultCollector = new SwitchStringMatchResultCollector(wcm1, wcm2, wcm3, null);
/* 116: 93 */     while (mi.hasNext())
/* 117:    */     {
/* 118: 94 */       mi.advance();
/* 119: 95 */       matchResultCollector.clear();
/* 120: 96 */       if (m.match(mi, matchResultCollector))
/* 121:    */       {
/* 122: 97 */         StructuredSwitch firstSwitch = (StructuredSwitch)matchResultCollector.getStatementByName("switch1");
/* 123: 98 */         StructuredSwitch secondSwitch = (StructuredSwitch)matchResultCollector.getStatementByName("switch2");
/* 124:    */         
/* 125:100 */         StructuredSwitch replacement = rewriteSwitch(secondSwitch, matchResultCollector);
/* 126:101 */         secondSwitch.getContainer().replaceContainedStatement(replacement);
/* 127:102 */         firstSwitch.getContainer().nopThis();
/* 128:103 */         ((AbstractStructuredStatement)matchResultCollector.getStatementByName("ass1")).getContainer().nopThis();
/* 129:104 */         ((AbstractStructuredStatement)matchResultCollector.getStatementByName("ass2")).getContainer().nopThis();
/* 130:    */         
/* 131:    */ 
/* 132:    */ 
/* 133:108 */         mi.rewind1();
/* 134:    */       }
/* 135:    */     }
/* 136:    */   }
/* 137:    */   
/* 138:    */   private StructuredSwitch rewriteSwitch(StructuredSwitch original, SwitchStringMatchResultCollector matchResultCollector)
/* 139:    */   {
/* 140:115 */     Op04StructuredStatement body = original.getBody();
/* 141:116 */     BlockIdentifier blockIdentifier = original.getBlockIdentifier();
/* 142:    */     
/* 143:118 */     StructuredStatement inner = body.getStatement();
/* 144:119 */     if (!(inner instanceof Block)) {
/* 145:120 */       throw new FailedRewriteException("Switch body is not a block, is a " + inner.getClass());
/* 146:    */     }
/* 147:123 */     Block block = (Block)inner;
/* 148:    */     
/* 149:125 */     Map<Integer, List<String>> replacements = matchResultCollector.getValidatedHashes();
/* 150:126 */     List<Op04StructuredStatement> caseStatements = block.getBlockStatements();
/* 151:127 */     LinkedList<Op04StructuredStatement> tgt = ListFactory.newLinkedList();
/* 152:    */     
/* 153:129 */     InferredJavaType typeOfSwitch = matchResultCollector.getStringExpression().getInferredJavaType();
/* 154:130 */     for (Op04StructuredStatement op04StructuredStatement : caseStatements)
/* 155:    */     {
/* 156:131 */       inner = op04StructuredStatement.getStatement();
/* 157:132 */       if (!(inner instanceof StructuredCase)) {
/* 158:133 */         throw new FailedRewriteException("Block member is not a case, it's a " + inner.getClass());
/* 159:    */       }
/* 160:135 */       StructuredCase structuredCase = (StructuredCase)inner;
/* 161:136 */       List<Expression> values = structuredCase.getValues();
/* 162:137 */       List<Expression> transformedValues = ListFactory.newList();
/* 163:139 */       for (Expression value : values)
/* 164:    */       {
/* 165:140 */         Integer i = getInt(value);
/* 166:141 */         List<String> replacementStrings = (List)replacements.get(i);
/* 167:142 */         if (replacementStrings == null) {
/* 168:143 */           throw new FailedRewriteException("No replacements for " + i);
/* 169:    */         }
/* 170:145 */         for (String s : replacementStrings) {
/* 171:146 */           transformedValues.add(new Literal(TypedLiteral.getString(s)));
/* 172:    */         }
/* 173:    */       }
/* 174:150 */       StructuredCase replacementStructuredCase = new StructuredCase(transformedValues, typeOfSwitch, structuredCase.getBody(), structuredCase.getBlockIdentifier());
/* 175:151 */       tgt.add(new Op04StructuredStatement(replacementStructuredCase));
/* 176:    */     }
/* 177:153 */     Block newBlock = new Block(tgt, true);
/* 178:    */     
/* 179:155 */     Expression switchOn = matchResultCollector.getStringExpression();
/* 180:159 */     if (switchOn.equals(Literal.NULL)) {
/* 181:160 */       switchOn = new CastExpression(new InferredJavaType(TypeConstants.STRING, InferredJavaType.Source.EXPRESSION), switchOn, true);
/* 182:    */     }
/* 183:163 */     return new StructuredSwitch(switchOn, new Op04StructuredStatement(newBlock), blockIdentifier);
/* 184:    */   }
/* 185:    */   
/* 186:    */   private static class SwitchStringMatchResultCollector
/* 187:    */     extends AbstractMatchResultIterator
/* 188:    */   {
/* 189:    */     private final WildcardMatch wholeBlock;
/* 190:    */     private final WildcardMatch caseStatement;
/* 191:    */     private final WildcardMatch hashCollision;
/* 192:176 */     private Expression stringExpression = null;
/* 193:177 */     private final List<Pair<String, Integer>> pendingHashCode = ListFactory.newList();
/* 194:178 */     private final Map<Integer, List<String>> validatedHashes = MapFactory.newLazyMap(new UnaryFunction()
/* 195:    */     {
/* 196:    */       public List<String> invoke(Integer arg)
/* 197:    */       {
/* 198:181 */         return ListFactory.newList();
/* 199:    */       }
/* 200:178 */     });
/* 201:184 */     private final Map<String, StructuredStatement> collectedStatements = MapFactory.newMap();
/* 202:    */     
/* 203:    */     private SwitchStringMatchResultCollector(WildcardMatch wholeBlock, WildcardMatch caseStatement, WildcardMatch hashCollision)
/* 204:    */     {
/* 205:188 */       this.wholeBlock = wholeBlock;
/* 206:189 */       this.caseStatement = caseStatement;
/* 207:190 */       this.hashCollision = hashCollision;
/* 208:    */     }
/* 209:    */     
/* 210:    */     public void clear()
/* 211:    */     {
/* 212:195 */       this.stringExpression = null;
/* 213:196 */       this.pendingHashCode.clear();
/* 214:197 */       this.validatedHashes.clear();
/* 215:198 */       this.collectedStatements.clear();
/* 216:    */     }
/* 217:    */     
/* 218:    */     public void collectStatement(String name, StructuredStatement statement)
/* 219:    */     {
/* 220:203 */       this.collectedStatements.put(name, statement);
/* 221:    */     }
/* 222:    */     
/* 223:    */     public void collectMatches(String name, WildcardMatch wcm)
/* 224:    */     {
/* 225:208 */       if (wcm == this.wholeBlock)
/* 226:    */       {
/* 227:209 */         Expression stringObject = wcm.getExpressionWildCard("originalstring").getMatch();
/* 228:210 */         this.stringExpression = stringObject;
/* 229:    */       }
/* 230:211 */       else if (wcm == this.caseStatement)
/* 231:    */       {
/* 232:212 */         List<Expression> hashvals = wcm.getList("hashvals").getMatch();
/* 233:213 */         Expression case2id = wcm.getExpressionWildCard("case2id").getMatch();
/* 234:214 */         Expression stringValue = wcm.getExpressionWildCard("stringvalue").getMatch();
/* 235:215 */         this.pendingHashCode.add(Pair.make(SwitchStringRewriter.getString(stringValue), SwitchStringRewriter.getInt(case2id)));
/* 236:216 */         processPendingWithHashCode(hashvals);
/* 237:    */       }
/* 238:217 */       else if (wcm == this.hashCollision)
/* 239:    */       {
/* 240:219 */         Expression case2id = wcm.getExpressionWildCard("case2id").getMatch();
/* 241:220 */         Expression stringValue = wcm.getExpressionWildCard("stringvalue").getMatch();
/* 242:221 */         this.pendingHashCode.add(Pair.make(SwitchStringRewriter.getString(stringValue), SwitchStringRewriter.getInt(case2id)));
/* 243:    */       }
/* 244:    */       else
/* 245:    */       {
/* 246:223 */         throw new IllegalStateException();
/* 247:    */       }
/* 248:    */     }
/* 249:    */     
/* 250:    */     void processPendingWithHashCode(List<Expression> hashVals)
/* 251:    */     {
/* 252:228 */       for (Pair<String, Integer> pair : this.pendingHashCode) {
/* 253:229 */         ((List)this.validatedHashes.get(pair.getSecond())).add(pair.getFirst());
/* 254:    */       }
/* 255:231 */       this.pendingHashCode.clear();
/* 256:    */     }
/* 257:    */     
/* 258:    */     public Expression getStringExpression()
/* 259:    */     {
/* 260:235 */       return this.stringExpression;
/* 261:    */     }
/* 262:    */     
/* 263:    */     public Map<Integer, List<String>> getValidatedHashes()
/* 264:    */     {
/* 265:239 */       return this.validatedHashes;
/* 266:    */     }
/* 267:    */     
/* 268:    */     public StructuredStatement getStatementByName(String name)
/* 269:    */     {
/* 270:243 */       StructuredStatement structuredStatement = (StructuredStatement)this.collectedStatements.get(name);
/* 271:244 */       if (structuredStatement == null) {
/* 272:244 */         throw new IllegalArgumentException("No collected statement " + name);
/* 273:    */       }
/* 274:245 */       return structuredStatement;
/* 275:    */     }
/* 276:    */   }
/* 277:    */   
/* 278:    */   static String getString(Expression e)
/* 279:    */   {
/* 280:250 */     if (!(e instanceof Literal)) {
/* 281:251 */       throw new TooOptimisticMatchException(null);
/* 282:    */     }
/* 283:253 */     Literal l = (Literal)e;
/* 284:254 */     TypedLiteral typedLiteral = l.getValue();
/* 285:255 */     if (typedLiteral.getType() != TypedLiteral.LiteralType.String) {
/* 286:256 */       throw new TooOptimisticMatchException(null);
/* 287:    */     }
/* 288:258 */     String s = (String)typedLiteral.getValue();
/* 289:259 */     return s;
/* 290:    */   }
/* 291:    */   
/* 292:    */   static Integer getInt(Expression e)
/* 293:    */   {
/* 294:264 */     if (!(e instanceof Literal)) {
/* 295:265 */       throw new TooOptimisticMatchException(null);
/* 296:    */     }
/* 297:267 */     Literal l = (Literal)e;
/* 298:268 */     TypedLiteral typedLiteral = l.getValue();
/* 299:269 */     if (typedLiteral.getType() != TypedLiteral.LiteralType.Integer) {
/* 300:270 */       throw new TooOptimisticMatchException(null);
/* 301:    */     }
/* 302:272 */     return (Integer)typedLiteral.getValue();
/* 303:    */   }
/* 304:    */   
/* 305:    */   private static class TooOptimisticMatchException
/* 306:    */     extends IllegalStateException
/* 307:    */   {}
/* 308:    */   
/* 309:    */   private static class FailedRewriteException
/* 310:    */     extends IllegalStateException
/* 311:    */   {
/* 312:    */     public FailedRewriteException(String s)
/* 313:    */     {
/* 314:280 */       super();
/* 315:    */     }
/* 316:    */   }
/* 317:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter
 * JD-Core Version:    0.7.0.1
 */