/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*   2:    */ 
/*   3:    */ import java.util.Collections;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Set;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.InstrIndex;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.JumpingStatement;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.WhileStatement;
/*  12:    */ import org.benf.cfr.reader.util.ListFactory;
/*  13:    */ import org.benf.cfr.reader.util.SetFactory;
/*  14:    */ import org.benf.cfr.reader.util.functors.BinaryProcedure;
/*  15:    */ import org.benf.cfr.reader.util.graph.GraphVisitor;
/*  16:    */ import org.benf.cfr.reader.util.graph.GraphVisitorDFS;
/*  17:    */ 
/*  18:    */ public class Cleaner
/*  19:    */ {
/*  20:    */   public static List<Op03SimpleStatement> removeUnreachableCode(List<Op03SimpleStatement> statements, final boolean checkBackJumps)
/*  21:    */   {
/*  22: 20 */     Set<Op03SimpleStatement> reachable = SetFactory.newSet();
/*  23: 21 */     reachable.add(statements.get(0));
/*  24: 22 */     GraphVisitor<Op03SimpleStatement> gv = new GraphVisitorDFS(statements.get(0), new BinaryProcedure()
/*  25:    */     {
/*  26:    */       public void call(Op03SimpleStatement arg1, GraphVisitor<Op03SimpleStatement> arg2)
/*  27:    */       {
/*  28: 25 */         this.val$reachable.add(arg1);
/*  29:    */         
/*  30:    */ 
/*  31:    */ 
/*  32: 29 */         arg2.enqueue(arg1.getTargets());
/*  33: 30 */         for (Op03SimpleStatement source : arg1.getSources()) {
/*  34: 34 */           if (!source.getTargets().contains(arg1)) {
/*  35: 35 */             throw new IllegalStateException("Inconsistent graph " + source + " does not have a target of " + arg1);
/*  36:    */           }
/*  37:    */         }
/*  38: 38 */         for (Op03SimpleStatement test : arg1.getTargets())
/*  39:    */         {
/*  40: 40 */           Statement argContained = arg1.getStatement();
/*  41: 41 */           if ((checkBackJumps) && 
/*  42: 42 */             (!(argContained instanceof JumpingStatement)) && (!(argContained instanceof WhileStatement)) && 
/*  43: 43 */             (test.getIndex().isBackJumpFrom(arg1))) {
/*  44: 44 */             throw new IllegalStateException("Backjump on non jumping statement " + arg1);
/*  45:    */           }
/*  46: 48 */           if (!test.getSources().contains(arg1)) {
/*  47: 49 */             throw new IllegalStateException("Inconsistent graph " + test + " does not have a source " + arg1);
/*  48:    */           }
/*  49:    */         }
/*  50:    */       }
/*  51: 53 */     });
/*  52: 54 */     gv.process();
/*  53:    */     
/*  54: 56 */     List<Op03SimpleStatement> result = ListFactory.newList();
/*  55: 57 */     for (Op03SimpleStatement statement : statements) {
/*  56: 58 */       if (reachable.contains(statement)) {
/*  57: 59 */         result.add(statement);
/*  58:    */       }
/*  59:    */     }
/*  60: 63 */     for (Iterator i$ = result.iterator(); i$.hasNext();)
/*  61:    */     {
/*  62: 63 */       res1 = (Op03SimpleStatement)i$.next();
/*  63: 64 */       List<Op03SimpleStatement> sources = ListFactory.newList(res1.getSources());
/*  64: 65 */       for (Op03SimpleStatement source : sources) {
/*  65: 66 */         if (!reachable.contains(source)) {
/*  66: 67 */           res1.removeSource(source);
/*  67:    */         }
/*  68:    */       }
/*  69:    */     }
/*  70:    */     Op03SimpleStatement res1;
/*  71: 71 */     return result;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public static List<Op03SimpleStatement> sortAndRenumber(List<Op03SimpleStatement> statements)
/*  75:    */   {
/*  76: 78 */     boolean nonNopSeen = false;
/*  77: 79 */     List<Op03SimpleStatement> result = ListFactory.newList();
/*  78: 80 */     for (Op03SimpleStatement statement : statements)
/*  79:    */     {
/*  80: 81 */       boolean thisIsNop = statement.isAgreedNop();
/*  81: 82 */       if (!nonNopSeen)
/*  82:    */       {
/*  83: 83 */         result.add(statement);
/*  84: 84 */         if (!thisIsNop) {
/*  85: 84 */           nonNopSeen = true;
/*  86:    */         }
/*  87:    */       }
/*  88: 86 */       else if (!thisIsNop)
/*  89:    */       {
/*  90: 87 */         result.add(statement);
/*  91:    */       }
/*  92:    */     }
/*  93: 92 */     sortAndRenumberInPlace(result);
/*  94: 93 */     return result;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static void sortAndRenumberFromInPlace(List<Op03SimpleStatement> statements, InstrIndex start)
/*  98:    */   {
/*  99: 97 */     Collections.sort(statements, new CompareByIndex());
/* 100: 98 */     for (Op03SimpleStatement statement : statements)
/* 101:    */     {
/* 102: 99 */       statement.setIndex(start);
/* 103:100 */       start = start.justAfter();
/* 104:    */     }
/* 105:    */   }
/* 106:    */   
/* 107:    */   public static void sortAndRenumberInPlace(List<Op03SimpleStatement> statements)
/* 108:    */   {
/* 109:107 */     Collections.sort(statements, new CompareByIndex());
/* 110:108 */     reindexInPlace(statements);
/* 111:    */   }
/* 112:    */   
/* 113:    */   public static void reindexInPlace(List<Op03SimpleStatement> statements)
/* 114:    */   {
/* 115:112 */     int newIndex = 0;
/* 116:113 */     Op03SimpleStatement prev = null;
/* 117:114 */     for (Op03SimpleStatement statement : statements)
/* 118:    */     {
/* 119:115 */       statement.setLinearlyPrevious(prev);
/* 120:116 */       statement.setLinearlyNext(null);
/* 121:117 */       if (prev != null) {
/* 122:117 */         prev.setLinearlyNext(statement);
/* 123:    */       }
/* 124:118 */       statement.setIndex(new InstrIndex(newIndex++));
/* 125:119 */       prev = statement;
/* 126:    */     }
/* 127:    */   }
/* 128:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner
 * JD-Core Version:    0.7.0.1
 */