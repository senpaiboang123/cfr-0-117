/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.Block;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredComment;
/*  7:   */ import org.benf.cfr.reader.entities.ClassFile;
/*  8:   */ import org.benf.cfr.reader.entities.Method;
/*  9:   */ 
/* 10:   */ public class DeadMethodRemover
/* 11:   */ {
/* 12:   */   public static void removeDeadMethod(ClassFile classFile, Method method)
/* 13:   */   {
/* 14:13 */     Op04StructuredStatement code = method.getAnalysis();
/* 15:14 */     StructuredStatement statement = code.getStatement();
/* 16:15 */     if (!(statement instanceof Block)) {
/* 17:15 */       return;
/* 18:   */     }
/* 19:17 */     Block block = (Block)statement;
/* 20:18 */     for (Op04StructuredStatement inner : block.getBlockStatements())
/* 21:   */     {
/* 22:19 */       StructuredStatement innerStatement = inner.getStatement();
/* 23:20 */       if (!(innerStatement instanceof StructuredComment)) {
/* 24:21 */         return;
/* 25:   */       }
/* 26:   */     }
/* 27:25 */     classFile.removePointlessMethod(method);
/* 28:   */   }
/* 29:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.DeadMethodRemover
 * JD-Core Version:    0.7.0.1
 */