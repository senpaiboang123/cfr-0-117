/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*   2:    */ 
/*   3:    */ import java.util.LinkedList;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Map;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.ConstructorUtils;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.MiscStatementTools;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.SuperFunctionInvokation;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.FieldVariable;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StaticVariable;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollectorSimple;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredAssignment;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredComment;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredDefinition;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredExpressionStatement;
/*  21:    */ import org.benf.cfr.reader.entities.AccessFlag;
/*  22:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  23:    */ import org.benf.cfr.reader.entities.ClassFileField;
/*  24:    */ import org.benf.cfr.reader.entities.Field;
/*  25:    */ import org.benf.cfr.reader.entities.Method;
/*  26:    */ import org.benf.cfr.reader.util.Functional;
/*  27:    */ import org.benf.cfr.reader.util.ListFactory;
/*  28:    */ import org.benf.cfr.reader.util.MapFactory;
/*  29:    */ import org.benf.cfr.reader.util.Predicate;
/*  30:    */ 
/*  31:    */ public class NonStaticLifter
/*  32:    */ {
/*  33:    */   private final ClassFile classFile;
/*  34:    */   
/*  35:    */   public NonStaticLifter(ClassFile classFile)
/*  36:    */   {
/*  37: 35 */     this.classFile = classFile;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public void liftNonStatics()
/*  41:    */   {
/*  42: 41 */     LinkedList<ClassFileField> classFileFields = new LinkedList(Functional.filter(this.classFile.getFields(), new Predicate()
/*  43:    */     {
/*  44:    */       public boolean test(ClassFileField in)
/*  45:    */       {
/*  46: 44 */         if (in.getField().testAccessFlag(AccessFlag.ACC_STATIC)) {
/*  47: 44 */           return false;
/*  48:    */         }
/*  49: 45 */         if (in.getField().testAccessFlag(AccessFlag.ACC_SYNTHETIC)) {
/*  50: 45 */           return false;
/*  51:    */         }
/*  52: 48 */         return true;
/*  53:    */       }
/*  54:    */     }));
/*  55: 51 */     if (classFileFields.isEmpty()) {
/*  56: 51 */       return;
/*  57:    */     }
/*  58: 52 */     Map<String, Pair<Integer, ClassFileField>> fieldMap = MapFactory.newMap();
/*  59: 53 */     int x = 0;
/*  60: 53 */     for (int len = classFileFields.size(); x < len; x++)
/*  61:    */     {
/*  62: 54 */       ClassFileField classFileField = (ClassFileField)classFileFields.get(x);
/*  63: 55 */       fieldMap.put(classFileField.getField().getFieldName(), Pair.make(Integer.valueOf(x), classFileField));
/*  64:    */     }
/*  65: 58 */     List<Method> constructors = Functional.filter(this.classFile.getConstructors(), new Predicate()
/*  66:    */     {
/*  67:    */       public boolean test(Method in)
/*  68:    */       {
/*  69: 61 */         return !ConstructorUtils.isDelegating(in);
/*  70:    */       }
/*  71: 68 */     });
/*  72: 69 */     List<List<Op04StructuredStatement>> constructorCodeList = ListFactory.newList();
/*  73: 70 */     int minSize = 2147483647;
/*  74: 71 */     for (Method constructor : constructors)
/*  75:    */     {
/*  76: 72 */       List<Op04StructuredStatement> blockStatements = MiscStatementTools.getBlockStatements(constructor.getAnalysis());
/*  77: 73 */       if (blockStatements == null) {
/*  78: 73 */         return;
/*  79:    */       }
/*  80: 74 */       blockStatements = Functional.filter(blockStatements, new Predicate()
/*  81:    */       {
/*  82:    */         public boolean test(Op04StructuredStatement in)
/*  83:    */         {
/*  84: 77 */           StructuredStatement stm = in.getStatement();
/*  85: 80 */           if ((stm instanceof StructuredComment)) {
/*  86: 80 */             return false;
/*  87:    */           }
/*  88: 81 */           if ((stm instanceof StructuredDefinition)) {
/*  89: 81 */             return false;
/*  90:    */           }
/*  91: 82 */           return true;
/*  92:    */         }
/*  93:    */       });
/*  94: 85 */       if (blockStatements.isEmpty()) {
/*  95: 85 */         return;
/*  96:    */       }
/*  97: 91 */       StructuredStatement superTest = ((Op04StructuredStatement)blockStatements.get(0)).getStatement();
/*  98: 92 */       if ((superTest instanceof StructuredExpressionStatement))
/*  99:    */       {
/* 100: 93 */         Expression expression = ((StructuredExpressionStatement)superTest).getExpression();
/* 101: 94 */         if ((expression instanceof SuperFunctionInvokation)) {
/* 102: 94 */           blockStatements.remove(0);
/* 103:    */         }
/* 104:    */       }
/* 105: 97 */       constructorCodeList.add(blockStatements);
/* 106: 98 */       if (blockStatements.size() < minSize) {
/* 107: 98 */         minSize = blockStatements.size();
/* 108:    */       }
/* 109:    */     }
/* 110:101 */     if (constructorCodeList.isEmpty()) {
/* 111:101 */       return;
/* 112:    */     }
/* 113:106 */     int numConstructors = constructorCodeList.size();
/* 114:107 */     List<Op04StructuredStatement> constructorCode = (List)constructorCodeList.get(0);
/* 115:108 */     for (int x = 0; x < minSize; x++)
/* 116:    */     {
/* 117:109 */       if (constructorCode.isEmpty()) {
/* 118:109 */         return;
/* 119:    */       }
/* 120:110 */       StructuredStatement s1 = ((Op04StructuredStatement)constructorCode.get(x)).getStatement();
/* 121:111 */       for (int y = 1; y < numConstructors; y++)
/* 122:    */       {
/* 123:112 */         StructuredStatement sOther = ((Op04StructuredStatement)((List)constructorCodeList.get(y)).get(x)).getStatement();
/* 124:113 */         if (!s1.equals(sOther)) {
/* 125:113 */           return;
/* 126:    */         }
/* 127:    */       }
/* 128:120 */       if (!(s1 instanceof StructuredAssignment)) {
/* 129:120 */         return;
/* 130:    */       }
/* 131:121 */       StructuredAssignment structuredAssignment = (StructuredAssignment)s1;
/* 132:122 */       LValue lValue = structuredAssignment.getLvalue();
/* 133:123 */       if (!(lValue instanceof FieldVariable)) {
/* 134:123 */         return;
/* 135:    */       }
/* 136:124 */       if (!fromThisClass((FieldVariable)lValue)) {
/* 137:124 */         return;
/* 138:    */       }
/* 139:129 */       if (!tryLift((FieldVariable)lValue, structuredAssignment.getRvalue(), fieldMap)) {
/* 140:130 */         return;
/* 141:    */       }
/* 142:132 */       for (List<Op04StructuredStatement> constructorCodeLst1 : constructorCodeList) {
/* 143:133 */         ((Op04StructuredStatement)constructorCodeLst1.get(x)).nopOut();
/* 144:    */       }
/* 145:    */     }
/* 146:    */   }
/* 147:    */   
/* 148:    */   private boolean fromThisClass(FieldVariable fv)
/* 149:    */   {
/* 150:141 */     return fv.getOwningClassType().equals(this.classFile.getClassType());
/* 151:    */   }
/* 152:    */   
/* 153:    */   private boolean tryLift(FieldVariable lValue, Expression rValue, Map<String, Pair<Integer, ClassFileField>> fieldMap)
/* 154:    */   {
/* 155:145 */     Pair<Integer, ClassFileField> thisField = (Pair)fieldMap.get(lValue.getFieldName());
/* 156:146 */     if (thisField == null) {
/* 157:146 */       return false;
/* 158:    */     }
/* 159:147 */     ClassFileField classFileField = (ClassFileField)thisField.getSecond();
/* 160:148 */     int thisIdx = ((Integer)thisField.getFirst()).intValue();
/* 161:149 */     LValueUsageCollectorSimple usageCollector = new LValueUsageCollectorSimple();
/* 162:150 */     rValue.collectUsedLValues(usageCollector);
/* 163:151 */     for (LValue usedLValue : usageCollector.getUsedLValues()) {
/* 164:152 */       if (!(usedLValue instanceof StaticVariable)) {
/* 165:156 */         if ((usedLValue instanceof FieldVariable))
/* 166:    */         {
/* 167:158 */           FieldVariable usedFieldVariable = (FieldVariable)usedLValue;
/* 168:159 */           if (!fromThisClass(usedFieldVariable)) {
/* 169:159 */             return false;
/* 170:    */           }
/* 171:160 */           Pair<Integer, ClassFileField> usedField = (Pair)fieldMap.get(usedFieldVariable.getFieldName());
/* 172:161 */           if (usedField == null) {
/* 173:161 */             return false;
/* 174:    */           }
/* 175:162 */           ClassFileField usedClassFileField = (ClassFileField)usedField.getSecond();
/* 176:163 */           int usedIdx = ((Integer)usedField.getFirst()).intValue();
/* 177:164 */           if (usedIdx >= thisIdx) {
/* 178:164 */             return false;
/* 179:    */           }
/* 180:165 */           if (usedClassFileField.getInitialValue() == null) {
/* 181:165 */             return false;
/* 182:    */           }
/* 183:    */         }
/* 184:    */         else
/* 185:    */         {
/* 186:169 */           return false;
/* 187:    */         }
/* 188:    */       }
/* 189:    */     }
/* 190:172 */     classFileField.setInitialValue(rValue);
/* 191:173 */     return true;
/* 192:    */   }
/* 193:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.NonStaticLifter
 * JD-Core Version:    0.7.0.1
 */