/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Set;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CaseStatement;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockType;
/*  9:   */ import org.benf.cfr.reader.util.Functional;
/* 10:   */ import org.benf.cfr.reader.util.Predicate;
/* 11:   */ import org.benf.cfr.reader.util.SetUtil;
/* 12:   */ 
/* 13:   */ public class SwitchUtils
/* 14:   */ {
/* 15:   */   public static void checkFixNewCase(Op03SimpleStatement possCaseItem, Op03SimpleStatement possCase)
/* 16:   */   {
/* 17:16 */     if (possCase.getStatement().getClass() != CaseStatement.class) {
/* 18:16 */       return;
/* 19:   */     }
/* 20:17 */     List<BlockIdentifier> idents = SetUtil.differenceAtakeBtoList(possCaseItem.getBlockIdentifiers(), possCase.getBlockIdentifiers());
/* 21:18 */     idents = Functional.filter(idents, new Predicate()
/* 22:   */     {
/* 23:   */       public boolean test(BlockIdentifier in)
/* 24:   */       {
/* 25:21 */         return in.getBlockType() == BlockType.CASE;
/* 26:   */       }
/* 27:   */     });
/* 28:24 */     if (idents.isEmpty())
/* 29:   */     {
/* 30:25 */       BlockIdentifier blockIdentifier = ((CaseStatement)possCase.getStatement()).getCaseBlock();
/* 31:26 */       possCaseItem.getBlockIdentifiers().add(blockIdentifier);
/* 32:   */     }
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchUtils
 * JD-Core Version:    0.7.0.1
 */