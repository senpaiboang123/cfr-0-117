/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.BytecodeMeta;
/*   5:    */ import org.benf.cfr.reader.bytecode.BytecodeMeta.CodeInfoFlag;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CastExpression;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CompOp;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ComparisonOperation;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CatchStatement;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ExpressionStatement;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.IfStatement;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.TryStatement;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.LValueWildcard;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.types.BindingSuperContainer;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.types.TypeConstants;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  26:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  27:    */ import org.benf.cfr.reader.util.ListFactory;
/*  28:    */ 
/*  29:    */ public class SuppressionRewriter
/*  30:    */ {
/*  31:    */   public static List<Op03SimpleStatement> rewrite(List<Op03SimpleStatement> statements, BytecodeMeta bytecodeMeta)
/*  32:    */   {
/*  33: 47 */     if (!bytecodeMeta.has(BytecodeMeta.CodeInfoFlag.USES_EXCEPTIONS)) {
/*  34: 47 */       return statements;
/*  35:    */     }
/*  36: 49 */     boolean acted = false;
/*  37: 50 */     for (int x = statements.size() - 1; x >= 0; x--)
/*  38:    */     {
/*  39: 51 */       Op03SimpleStatement stm = (Op03SimpleStatement)statements.get(x);
/*  40: 52 */       if ((stm.getStatement() instanceof TryStatement)) {
/*  41: 53 */         acted |= testSuppressedClose(stm, x, statements);
/*  42:    */       }
/*  43:    */     }
/*  44: 56 */     if (acted) {
/*  45: 57 */       statements = Cleaner.removeUnreachableCode(statements, true);
/*  46:    */     }
/*  47: 59 */     return statements;
/*  48:    */   }
/*  49:    */   
/*  50:    */   private static boolean testSuppressedClose(Op03SimpleStatement tryStm, int idx, List<Op03SimpleStatement> lst)
/*  51:    */   {
/*  52: 64 */     if (tryStm.getSources().size() != 1) {
/*  53: 64 */       return false;
/*  54:    */     }
/*  55: 66 */     List<Op03SimpleStatement> tryTargets = tryStm.getTargets();
/*  56: 67 */     if (tryTargets.size() != 2) {
/*  57: 67 */       return false;
/*  58:    */     }
/*  59: 69 */     Op03SimpleStatement testClose = (Op03SimpleStatement)lst.get(idx + 1);
/*  60: 70 */     if (testClose != tryTargets.get(0)) {
/*  61: 70 */       return false;
/*  62:    */     }
/*  63: 72 */     WildcardMatch wcm = new WildcardMatch();
/*  64: 73 */     Statement testCloseStatement = new ExpressionStatement(wcm.getMemberFunction("close", "close", new LValueExpression(wcm.getLValueWildCard("object"))));
/*  65: 74 */     if (!testCloseStatement.equals(testClose.getStatement())) {
/*  66: 74 */       return false;
/*  67:    */     }
/*  68: 76 */     LValue object = wcm.getLValueWildCard("object").getMatch();
/*  69: 77 */     if (!(object instanceof LocalVariable)) {
/*  70: 77 */       return false;
/*  71:    */     }
/*  72: 78 */     BindingSuperContainer bindingSuperContainer = object.getInferredJavaType().getJavaTypeInstance().getBindingSupers();
/*  73: 79 */     if (bindingSuperContainer == null) {
/*  74: 79 */       return false;
/*  75:    */     }
/*  76: 80 */     if (!bindingSuperContainer.containsBase(TypeConstants.CLOSEABLE)) {
/*  77: 80 */       return false;
/*  78:    */     }
/*  79: 83 */     List<Op03SimpleStatement> tgt2 = testClose.getTargets();
/*  80: 84 */     Op03SimpleStatement testGoto = (Op03SimpleStatement)lst.get(idx + 2);
/*  81: 85 */     if (testGoto != tgt2.get(0)) {
/*  82: 85 */       return false;
/*  83:    */     }
/*  84: 87 */     Op03SimpleStatement testCatch = (Op03SimpleStatement)lst.get(idx + 3);
/*  85: 88 */     if (testCatch != tryTargets.get(1)) {
/*  86: 88 */       return false;
/*  87:    */     }
/*  88: 90 */     if (!(testCatch.getStatement() instanceof CatchStatement)) {
/*  89: 90 */       return false;
/*  90:    */     }
/*  91: 91 */     CatchStatement catchStatement = (CatchStatement)testCatch.getStatement();
/*  92: 92 */     LValue caught = catchStatement.getCreatedLValue();
/*  93:    */     
/*  94: 94 */     Op03SimpleStatement testSuppressed = (Op03SimpleStatement)lst.get(idx + 4);
/*  95: 95 */     if (testSuppressed != testCatch.getTargets().get(0)) {
/*  96: 95 */       return false;
/*  97:    */     }
/*  98: 97 */     Statement suppression = new ExpressionStatement(wcm.getMemberFunction("suppress", "addSuppressed", false, new LValueExpression(wcm.getLValueWildCard("suppressor")), ListFactory.newList(new Expression[] { new CastExpression(new InferredJavaType(TypeConstants.THROWABLE, InferredJavaType.Source.EXPRESSION), new LValueExpression(caught)) })));
/*  99:105 */     if (!suppression.equals(testSuppressed.getStatement())) {
/* 100:105 */       return false;
/* 101:    */     }
/* 102:107 */     Op03SimpleStatement testGoto2 = (Op03SimpleStatement)lst.get(idx + 5);
/* 103:108 */     if (testGoto2 != testSuppressed.getTargets().get(0)) {
/* 104:108 */       return false;
/* 105:    */     }
/* 106:109 */     if (!testGoto2.getStatement().equals(testGoto.getStatement())) {
/* 107:109 */       return false;
/* 108:    */     }
/* 109:110 */     Op03SimpleStatement testGotoTarget = (Op03SimpleStatement)testGoto.getTargets().get(0);
/* 110:    */     
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:116 */     Op03SimpleStatement secondClose = (Op03SimpleStatement)lst.get(idx + 6);
/* 116:117 */     if (!secondClose.getStatement().equals(testClose.getStatement())) {
/* 117:117 */       return false;
/* 118:    */     }
/* 119:119 */     if (!((Op03SimpleStatement)secondClose.getTargets().get(0)).equals(testGotoTarget)) {
/* 120:119 */       return false;
/* 121:    */     }
/* 122:120 */     if (lst.get(idx + 7) != testGotoTarget) {
/* 123:120 */       return false;
/* 124:    */     }
/* 125:123 */     Op03SimpleStatement testIf = (Op03SimpleStatement)lst.get(idx - 1);
/* 126:124 */     Statement testIfStatement = new IfStatement(new ComparisonOperation(new LValueExpression(wcm.getLValueWildCard("suppressor")), Literal.NULL, CompOp.EQ));
/* 127:125 */     if (!testIfStatement.equals(testIf.getStatement())) {
/* 128:125 */       return false;
/* 129:    */     }
/* 130:126 */     List<Op03SimpleStatement> testIfTargets = testIf.getTargets();
/* 131:127 */     if (testIfTargets.get(0) != tryStm) {
/* 132:127 */       return false;
/* 133:    */     }
/* 134:128 */     if (testIfTargets.get(1) != secondClose) {
/* 135:128 */       return false;
/* 136:    */     }
/* 137:129 */     if (secondClose.getSources().size() != 1) {
/* 138:129 */       return false;
/* 139:    */     }
/* 140:136 */     List<Op03SimpleStatement> sources = testIf.getSources();
/* 141:137 */     testGotoTarget.removeSource(testGoto);
/* 142:138 */     testGotoTarget.removeSource(testGoto2);
/* 143:139 */     for (Op03SimpleStatement source : sources)
/* 144:    */     {
/* 145:140 */       source.replaceTarget(testIf, secondClose);
/* 146:141 */       secondClose.addSource(source);
/* 147:    */     }
/* 148:145 */     return true;
/* 149:    */   }
/* 150:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SuppressionRewriter
 * JD-Core Version:    0.7.0.1
 */