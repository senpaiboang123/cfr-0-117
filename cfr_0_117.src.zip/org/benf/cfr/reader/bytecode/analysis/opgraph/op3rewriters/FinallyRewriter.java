/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Set;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CatchStatement;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.FinallyStatement;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.TryStatement;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifierFactory;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.finalhelp.FinalAnalyzer;
/* 13:   */ import org.benf.cfr.reader.entities.Method;
/* 14:   */ import org.benf.cfr.reader.util.Functional;
/* 15:   */ import org.benf.cfr.reader.util.Predicate;
/* 16:   */ import org.benf.cfr.reader.util.SetFactory;
/* 17:   */ import org.benf.cfr.reader.util.getopt.Options;
/* 18:   */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/* 19:   */ 
/* 20:   */ public class FinallyRewriter
/* 21:   */ {
/* 22:   */   public static void identifyFinally(Options options, Method method, List<Op03SimpleStatement> in, BlockIdentifierFactory blockIdentifierFactory)
/* 23:   */   {
/* 24:23 */     if (!((Boolean)options.getOption(OptionsImpl.DECODE_FINALLY)).booleanValue()) {
/* 25:23 */       return;
/* 26:   */     }
/* 27:28 */     Set<Op03SimpleStatement> analysedTries = SetFactory.newSet();
/* 28:   */     boolean continueLoop;
/* 29:   */     do
/* 30:   */     {
/* 31:31 */       List<Op03SimpleStatement> tryStarts = Functional.filter(in, new Predicate()
/* 32:   */       {
/* 33:   */         public boolean test(Op03SimpleStatement in)
/* 34:   */         {
/* 35:34 */           if (((in.getStatement() instanceof TryStatement)) && (!this.val$analysedTries.contains(in))) {
/* 36:35 */             return true;
/* 37:   */           }
/* 38:36 */           return false;
/* 39:   */         }
/* 40:   */       });
/* 41:39 */       for (Op03SimpleStatement tryS : tryStarts) {
/* 42:40 */         FinalAnalyzer.identifyFinally(method, tryS, in, blockIdentifierFactory, analysedTries);
/* 43:   */       }
/* 44:45 */       continueLoop = !tryStarts.isEmpty();
/* 45:46 */     } while (continueLoop);
/* 46:   */   }
/* 47:   */   
/* 48:   */   public static Set<BlockIdentifier> getBlocksAffectedByFinally(List<Op03SimpleStatement> statements)
/* 49:   */   {
/* 50:50 */     Set<BlockIdentifier> res = SetFactory.newSet();
/* 51:51 */     for (Op03SimpleStatement stm : statements) {
/* 52:52 */       if ((stm.getStatement() instanceof TryStatement))
/* 53:   */       {
/* 54:53 */         TryStatement tryStatement = (TryStatement)stm.getStatement();
/* 55:54 */         Set<BlockIdentifier> newBlocks = SetFactory.newSet();
/* 56:55 */         boolean found = false;
/* 57:56 */         newBlocks.add(tryStatement.getBlockIdentifier());
/* 58:57 */         for (Op03SimpleStatement tgt : stm.getTargets())
/* 59:   */         {
/* 60:58 */           Statement inr = tgt.getStatement();
/* 61:59 */           if ((inr instanceof CatchStatement)) {
/* 62:60 */             newBlocks.add(((CatchStatement)inr).getCatchBlockIdent());
/* 63:   */           }
/* 64:62 */           if ((tgt.getStatement() instanceof FinallyStatement)) {
/* 65:63 */             found = true;
/* 66:   */           }
/* 67:   */         }
/* 68:66 */         if (found) {
/* 69:66 */           res.addAll(newBlocks);
/* 70:   */         }
/* 71:   */       }
/* 72:   */     }
/* 73:69 */     return res;
/* 74:   */   }
/* 75:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.FinallyRewriter
 * JD-Core Version:    0.7.0.1
 */