/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Set;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CastExpression;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.SuperFunctionInvokation;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.ExpressionWildcard;
/* 12:   */ import org.benf.cfr.reader.util.ListFactory;
/* 13:   */ import org.benf.cfr.reader.util.SetFactory;
/* 14:   */ 
/* 15:   */ public class EnumSuperRewriter
/* 16:   */   extends RedundantSuperRewriter
/* 17:   */ {
/* 18:   */   protected List<Expression> getSuperArgs(WildcardMatch wcm)
/* 19:   */   {
/* 20:18 */     List<Expression> res = ListFactory.newList();
/* 21:19 */     res.add(wcm.getExpressionWildCard("enum_a"));
/* 22:20 */     res.add(wcm.getExpressionWildCard("enum_b"));
/* 23:21 */     return res;
/* 24:   */   }
/* 25:   */   
/* 26:   */   private static LValue getLValue(WildcardMatch wcm, String name)
/* 27:   */   {
/* 28:25 */     Expression e = wcm.getExpressionWildCard(name).getMatch();
/* 29:26 */     while ((e instanceof CastExpression)) {
/* 30:27 */       e = ((CastExpression)e).getChild();
/* 31:   */     }
/* 32:29 */     if (!(e instanceof LValueExpression)) {
/* 33:30 */       throw new IllegalStateException();
/* 34:   */     }
/* 35:32 */     return ((LValueExpression)e).getLValue();
/* 36:   */   }
/* 37:   */   
/* 38:   */   protected Set<LValue> getDeclarationsToNop(WildcardMatch wcm)
/* 39:   */   {
/* 40:36 */     Set<LValue> res = SetFactory.newSet();
/* 41:37 */     res.add(getLValue(wcm, "enum_a"));
/* 42:38 */     res.add(getLValue(wcm, "enum_b"));
/* 43:39 */     return res;
/* 44:   */   }
/* 45:   */   
/* 46:   */   protected boolean canBeNopped(SuperFunctionInvokation superInvokation)
/* 47:   */   {
/* 48:44 */     return true;
/* 49:   */   }
/* 50:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.EnumSuperRewriter
 * JD-Core Version:    0.7.0.1
 */