/*    1:     */ package org.benf.cfr.reader.bytecode.analysis.opgraph;
/*    2:     */ 
/*    3:     */ import java.util.Collections;
/*    4:     */ import java.util.IdentityHashMap;
/*    5:     */ import java.util.Iterator;
/*    6:     */ import java.util.LinkedHashSet;
/*    7:     */ import java.util.List;
/*    8:     */ import java.util.Map;
/*    9:     */ import java.util.Map.Entry;
/*   10:     */ import java.util.Set;
/*   11:     */ import java.util.TreeSet;
/*   12:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner;
/*   13:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.IsForwardJumpTo;
/*   14:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.TypeFilter;
/*   15:     */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*   16:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*   17:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CaseStatement;
/*   18:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CatchStatement;
/*   19:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.FinallyStatement;
/*   20:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement;
/*   21:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.IfStatement;
/*   22:     */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.TryStatement;
/*   23:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*   24:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifierFactory;
/*   25:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockType;
/*   26:     */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*   27:     */ import org.benf.cfr.reader.entities.Method;
/*   28:     */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheckSimple;
/*   29:     */ import org.benf.cfr.reader.entities.exceptions.ExceptionGroup.Entry;
/*   30:     */ import org.benf.cfr.reader.util.DecompilerComment;
/*   31:     */ import org.benf.cfr.reader.util.DecompilerComments;
/*   32:     */ import org.benf.cfr.reader.util.Functional;
/*   33:     */ import org.benf.cfr.reader.util.Functional.NotNull;
/*   34:     */ import org.benf.cfr.reader.util.ListFactory;
/*   35:     */ import org.benf.cfr.reader.util.MapFactory;
/*   36:     */ import org.benf.cfr.reader.util.SetFactory;
/*   37:     */ import org.benf.cfr.reader.util.SetUtil;
/*   38:     */ import org.benf.cfr.reader.util.Troolean;
/*   39:     */ import org.benf.cfr.reader.util.functors.BinaryProcedure;
/*   40:     */ import org.benf.cfr.reader.util.getopt.Options;
/*   41:     */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*   42:     */ import org.benf.cfr.reader.util.graph.GraphVisitor;
/*   43:     */ import org.benf.cfr.reader.util.graph.GraphVisitorDFS;
/*   44:     */ 
/*   45:     */ public class Op03Blocks
/*   46:     */ {
/*   47:     */   private static <T> T getSingle(Set<T> in)
/*   48:     */   {
/*   49:  27 */     return in.iterator().next();
/*   50:     */   }
/*   51:     */   
/*   52:     */   private static List<Block3> doTopSort(List<Block3> in)
/*   53:     */   {
/*   54:  36 */     LinkedHashSet<Block3> allBlocks = new LinkedHashSet();
/*   55:  37 */     allBlocks.addAll(in);
/*   56:     */     
/*   57:     */ 
/*   58:     */ 
/*   59:     */ 
/*   60:     */ 
/*   61:     */ 
/*   62:     */ 
/*   63:     */ 
/*   64:  46 */     Set<Block3> ready = new TreeSet();
/*   65:  47 */     ready.add(in.get(0));
/*   66:     */     
/*   67:  49 */     List<Block3> output = ListFactory.newList(in.size());
/*   68:     */     
/*   69:  51 */     Block3 last = null;
/*   70:  52 */     while (!allBlocks.isEmpty())
/*   71:     */     {
/*   72:  53 */       Block3 next = null;
/*   73:  54 */       if (!ready.isEmpty())
/*   74:     */       {
/*   75:  58 */         next = (Block3)getSingle(ready);
/*   76:  59 */         ready.remove(next);
/*   77:     */       }
/*   78:     */       else
/*   79:     */       {
/*   80:  64 */         next = (Block3)getSingle(allBlocks);
/*   81:     */       }
/*   82:  66 */       last = next;
/*   83:     */       
/*   84:  68 */       allBlocks.remove(next);
/*   85:  69 */       output.add(next);
/*   86:  70 */       Set<BlockIdentifier> fromSet = next.getEnd().getBlockIdentifiers();
/*   87:  71 */       Set<Block3> notReadyInThis = null;
/*   88:  72 */       for (Block3 child : next.targets)
/*   89:     */       {
/*   90:  73 */         child.sources.remove(next);
/*   91:  74 */         if (child.sources.isEmpty())
/*   92:     */         {
/*   93:  75 */           if (allBlocks.contains(child)) {
/*   94:  76 */             ready.add(child);
/*   95:     */           }
/*   96:     */         }
/*   97:  79 */         else if (child.getStart().getBlockIdentifiers().equals(fromSet))
/*   98:     */         {
/*   99:  80 */           if (notReadyInThis == null) {
/*  100:  80 */             notReadyInThis = new TreeSet();
/*  101:     */           }
/*  102:  81 */           notReadyInThis.add(child);
/*  103:     */         }
/*  104:     */       }
/*  105:  89 */       if (!ready.isEmpty())
/*  106:     */       {
/*  107:  90 */         Block3 probnext = (Block3)getSingle(ready);
/*  108:     */         
/*  109:  92 */         Set<BlockIdentifier> probNextBlocks = probnext.getStart().getBlockIdentifiers();
/*  110:  96 */         if ((fromSet.containsAll(probNextBlocks)) && (!probNextBlocks.equals(fromSet)) && 
/*  111:  97 */           (notReadyInThis != null) && (!notReadyInThis.isEmpty()))
/*  112:     */         {
/*  113:  98 */           Block3 forceChild = (Block3)getSingle(notReadyInThis);
/*  114:  99 */           if (allBlocks.contains(forceChild))
/*  115:     */           {
/*  116: 104 */             boolean canForce = true;
/*  117: 105 */             for (Block3 forceSource : forceChild.sources) {
/*  118: 106 */               if ((forceChild.startIndex.isBackJumpFrom(forceSource.startIndex)) && 
/*  119: 107 */                 (!forceSource.getStart().getBlockIdentifiers().containsAll(fromSet)))
/*  120:     */               {
/*  121: 108 */                 canForce = false;
/*  122: 109 */                 break;
/*  123:     */               }
/*  124:     */             }
/*  125: 113 */             if (canForce)
/*  126:     */             {
/*  127: 114 */               forceChild.sources.clear();
/*  128: 115 */               ready.add(forceChild);
/*  129:     */             }
/*  130:     */           }
/*  131:     */         }
/*  132:     */       }
/*  133:     */     }
/*  134: 122 */     return output;
/*  135:     */   }
/*  136:     */   
/*  137:     */   private static void apply0TargetBlockHeuristic(List<Block3> blocks)
/*  138:     */   {
/*  139: 130 */     for (int idx = blocks.size() - 1; idx >= 0; idx--)
/*  140:     */     {
/*  141: 131 */       Block3 block = (Block3)blocks.get(idx);
/*  142: 132 */       if (block.targets.isEmpty())
/*  143:     */       {
/*  144: 133 */         boolean move = false;
/*  145: 134 */         Block3 lastSource = block;
/*  146: 135 */         for (Block3 source : block.sources) {
/*  147: 136 */           if (lastSource.compareTo(source) < 0)
/*  148:     */           {
/*  149: 137 */             move = true;
/*  150: 138 */             lastSource = source;
/*  151:     */           }
/*  152:     */         }
/*  153: 141 */         if (move)
/*  154:     */         {
/*  155: 146 */           if (idx > 0)
/*  156:     */           {
/*  157: 147 */             Block3 fallThrough = (Block3)blocks.get(idx - 1);
/*  158: 148 */             if ((block.sources.contains(fallThrough)) && (lastSource != fallThrough))
/*  159:     */             {
/*  160: 149 */               Op03SimpleStatement lastop = fallThrough.getEnd();
/*  161: 150 */               if (lastop.getStatement().fallsToNext()) {
/*  162:     */                 continue;
/*  163:     */               }
/*  164:     */             }
/*  165:     */           }
/*  166: 155 */           block.startIndex = lastSource.startIndex.justAfter();
/*  167: 156 */           blocks.add(blocks.indexOf(lastSource) + 1, block);
/*  168: 157 */           blocks.remove(idx);
/*  169:     */         }
/*  170:     */       }
/*  171:     */     }
/*  172:     */   }
/*  173:     */   
/*  174:     */   private static void removeAliases(Set<BlockIdentifier> in, Map<BlockIdentifier, BlockIdentifier> aliases)
/*  175:     */   {
/*  176: 174 */     Set<BlockIdentifier> toRemove = SetFactory.newSet();
/*  177: 175 */     for (BlockIdentifier i : in)
/*  178:     */     {
/*  179: 176 */       BlockIdentifier alias = (BlockIdentifier)aliases.get(i);
/*  180: 177 */       if ((alias != null) && 
/*  181: 178 */         (in.contains(alias)))
/*  182:     */       {
/*  183: 179 */         toRemove.add(i);
/*  184: 180 */         toRemove.add(alias);
/*  185:     */       }
/*  186:     */     }
/*  187: 184 */     in.removeAll(toRemove);
/*  188:     */   }
/*  189:     */   
/*  190:     */   private static Map<BlockIdentifier, BlockIdentifier> getTryBlockAliases(List<Op03SimpleStatement> statements)
/*  191:     */   {
/*  192: 188 */     Map<BlockIdentifier, BlockIdentifier> tryBlockAliases = MapFactory.newMap();
/*  193: 189 */     List<Op03SimpleStatement> catchStatements = Functional.filter(statements, new TypeFilter(CatchStatement.class));
/*  194: 191 */     for (Op03SimpleStatement catchStatementCtr : catchStatements)
/*  195:     */     {
/*  196: 192 */       CatchStatement catchStatement = (CatchStatement)catchStatementCtr.getStatement();
/*  197: 193 */       List<ExceptionGroup.Entry> caught = catchStatement.getExceptions();
/*  198: 197 */       if (!caught.isEmpty())
/*  199:     */       {
/*  200: 198 */         ExceptionGroup.Entry first = (ExceptionGroup.Entry)caught.get(0);
/*  201: 199 */         JavaRefTypeInstance catchType = first.getCatchType();
/*  202: 200 */         tryBlockMain = first.getTryBlockIdentifier();
/*  203:     */         
/*  204: 202 */         List<BlockIdentifier> possibleAliases = ListFactory.newList();
/*  205: 203 */         int x = 1;
/*  206: 203 */         for (int len = caught.size();; x++)
/*  207:     */         {
/*  208: 203 */           if (x >= len) {
/*  209:     */             break label180;
/*  210:     */           }
/*  211: 204 */           ExceptionGroup.Entry entry = (ExceptionGroup.Entry)caught.get(x);
/*  212: 205 */           if (!entry.getCatchType().equals(catchType)) {
/*  213:     */             break;
/*  214:     */           }
/*  215: 206 */           BlockIdentifier tryBlockIdent = entry.getTryBlockIdentifier();
/*  216: 207 */           possibleAliases.add(tryBlockIdent);
/*  217:     */         }
/*  218: 210 */         Iterator i$ = catchStatementCtr.getSources().iterator();
/*  219:     */         for (;;)
/*  220:     */         {
/*  221: 210 */           if (!i$.hasNext()) {
/*  222:     */             break label235;
/*  223:     */           }
/*  224: 210 */           Op03SimpleStatement source = (Op03SimpleStatement)i$.next();
/*  225: 211 */           if (source.getBlockIdentifiers().contains(tryBlockMain)) {
/*  226:     */             break;
/*  227:     */           }
/*  228:     */         }
/*  229: 214 */         for (BlockIdentifier alias : possibleAliases)
/*  230:     */         {
/*  231: 215 */           BlockIdentifier last = (BlockIdentifier)tryBlockAliases.put(alias, tryBlockMain);
/*  232: 216 */           if ((last != null) && (last != tryBlockMain)) {
/*  233: 218 */             a = 1;
/*  234:     */           }
/*  235:     */         }
/*  236:     */       }
/*  237:     */     }
/*  238:     */     BlockIdentifier tryBlockMain;
/*  239:     */     label180:
/*  240:     */     label235:
/*  241:     */     int a;
/*  242: 222 */     return tryBlockAliases;
/*  243:     */   }
/*  244:     */   
/*  245:     */   private static void applyKnownBlocksHeuristic(Method method, List<Block3> blocks, Map<BlockIdentifier, BlockIdentifier> tryBlockAliases)
/*  246:     */   {
/*  247: 232 */     Map<BlockIdentifier, Block3> lastByBlock = MapFactory.newMap();
/*  248: 233 */     for (Iterator i$ = blocks.iterator(); i$.hasNext();)
/*  249:     */     {
/*  250: 233 */       block = (Block3)i$.next();
/*  251: 234 */       for (BlockIdentifier blockIdentifier : block.getStart().getBlockIdentifiers()) {
/*  252: 235 */         lastByBlock.put(blockIdentifier, block);
/*  253:     */       }
/*  254:     */     }
/*  255:     */     Block3 block;
/*  256: 239 */     Block3 linPrev = null;
/*  257: 240 */     for (Block3 block : blocks)
/*  258:     */     {
/*  259: 241 */       Op03SimpleStatement start = block.getStart();
/*  260: 242 */       Set<BlockIdentifier> startIdents = start.getBlockIdentifiers();
/*  261: 243 */       boolean needLinPrev = false;
/*  262:     */       BlockIdentifier newTryBlock;
/*  263: 245 */       if (block.sources.contains(linPrev))
/*  264:     */       {
/*  265: 246 */         Block3 source = linPrev;
/*  266: 247 */         Set<BlockIdentifier> endIdents = source.getEnd().getBlockIdentifiers();
/*  267: 248 */         if (!endIdents.equals(startIdents))
/*  268:     */         {
/*  269: 256 */           Set<BlockIdentifier> diffs = SetUtil.difference(endIdents, startIdents);
/*  270:     */           
/*  271:     */ 
/*  272:     */ 
/*  273: 260 */           newTryBlock = null;
/*  274: 261 */           if ((block.getStart().getStatement() instanceof TryStatement))
/*  275:     */           {
/*  276: 262 */             newTryBlock = ((TryStatement)block.getStart().getStatement()).getBlockIdentifier();
/*  277: 263 */             if (!diffs.add(newTryBlock)) {
/*  278: 263 */               newTryBlock = null;
/*  279:     */             }
/*  280:     */           }
/*  281: 266 */           removeAliases(diffs, tryBlockAliases);
/*  282: 268 */           for (BlockIdentifier blk : diffs) {
/*  283: 269 */             if ((blk.getBlockType() != BlockType.CASE) && (blk.getBlockType() != BlockType.SWITCH) && 
/*  284:     */             
/*  285: 271 */               (blk != newTryBlock)) {
/*  286: 272 */               needLinPrev = true;
/*  287:     */             }
/*  288:     */           }
/*  289:     */         }
/*  290:     */       }
/*  291: 278 */       if (needLinPrev)
/*  292:     */       {
/*  293: 279 */         if (linPrev != null)
/*  294:     */         {
/*  295: 280 */           block.addSource(linPrev);
/*  296: 281 */           linPrev.addTarget(block);
/*  297:     */         }
/*  298:     */       }
/*  299:     */       else
/*  300:     */       {
/*  301: 284 */         Op03SimpleStatement blockStart = block.getStart();
/*  302: 285 */         Statement statement = blockStart.getStatement();
/*  303: 287 */         if ((statement instanceof FinallyStatement)) {
/*  304: 288 */           for (Block3 source : ListFactory.newList(block.sources))
/*  305:     */           {
/*  306: 289 */             Statement last = source.getEnd().getStatement();
/*  307: 290 */             if ((last instanceof TryStatement))
/*  308:     */             {
/*  309: 291 */               TryStatement tryStatement = (TryStatement)last;
/*  310: 292 */               Block3 lastDep = (Block3)lastByBlock.get(tryStatement.getBlockIdentifier());
/*  311: 293 */               if (lastDep != null)
/*  312:     */               {
/*  313: 294 */                 block.addSource(lastDep);
/*  314: 295 */                 lastDep.addTarget(block);
/*  315:     */               }
/*  316:     */             }
/*  317:     */           }
/*  318:     */         }
/*  319:     */       }
/*  320: 301 */       linPrev = block;
/*  321:     */     }
/*  322:     */   }
/*  323:     */   
/*  324:     */   private static List<Block3> buildBasicBlocks(Method method, List<Op03SimpleStatement> statements)
/*  325:     */   {
/*  326: 309 */     final List<Block3> blocks = ListFactory.newList();
/*  327: 310 */     Map<Op03SimpleStatement, Block3> starts = MapFactory.newMap();
/*  328: 311 */     final Map<Op03SimpleStatement, Block3> ends = MapFactory.newMap();
/*  329:     */     
/*  330: 313 */     GraphVisitor<Op03SimpleStatement> gv = new GraphVisitorDFS(statements.get(0), new BinaryProcedure()
/*  331:     */     {
/*  332:     */       public void call(Op03SimpleStatement arg1, GraphVisitor<Op03SimpleStatement> arg2)
/*  333:     */       {
/*  334: 316 */         Op03Blocks.Block3 block = new Op03Blocks.Block3(arg1);
/*  335: 317 */         this.val$starts.put(arg1, block);
/*  336: 318 */         while (arg1.getTargets().size() == 1)
/*  337:     */         {
/*  338: 319 */           Op03SimpleStatement next = (Op03SimpleStatement)arg1.getTargets().get(0);
/*  339: 320 */           if ((next.getSources().size() != 1) || (!arg1.getBlockIdentifiers().equals(next.getBlockIdentifiers()))) {
/*  340:     */             break;
/*  341:     */           }
/*  342: 321 */           arg1 = next;
/*  343: 322 */           block.append(arg1);
/*  344:     */         }
/*  345: 327 */         blocks.add(block);
/*  346: 328 */         ends.put(arg1, block);
/*  347: 329 */         arg2.enqueue(arg1.getTargets());
/*  348:     */       }
/*  349: 331 */     });
/*  350: 332 */     gv.process();
/*  351: 333 */     Collections.sort(blocks);
/*  352: 335 */     for (Block3 block : blocks)
/*  353:     */     {
/*  354: 336 */       Op03SimpleStatement start = block.getStart();
/*  355: 337 */       List<Op03SimpleStatement> prevList = start.getSources();
/*  356: 338 */       List<Block3> prevBlocks = ListFactory.newList(prevList.size());
/*  357: 339 */       for (Op03SimpleStatement prev : prevList)
/*  358:     */       {
/*  359: 340 */         Block3 prevEnd = (Block3)ends.get(prev);
/*  360: 341 */         if (prevEnd == null) {
/*  361: 342 */           throw new IllegalStateException("Topological sort failed, explicitly disable");
/*  362:     */         }
/*  363: 344 */         prevBlocks.add(prevEnd);
/*  364:     */       }
/*  365: 347 */       Op03SimpleStatement end = block.getEnd();
/*  366: 348 */       List<Op03SimpleStatement> afterList = end.getTargets();
/*  367: 349 */       List<Block3> postBlocks = ListFactory.newList(afterList.size());
/*  368: 350 */       for (Op03SimpleStatement after : afterList) {
/*  369: 351 */         postBlocks.add(starts.get(after));
/*  370:     */       }
/*  371: 354 */       block.addSources(prevBlocks);
/*  372: 355 */       block.addTargets(postBlocks);
/*  373: 357 */       if ((end.getStatement() instanceof TryStatement))
/*  374:     */       {
/*  375: 358 */         depends = ListFactory.newList();
/*  376: 359 */         for (Block3 tgt : postBlocks)
/*  377:     */         {
/*  378: 360 */           tgt.addSources(depends);
/*  379: 361 */           for (Block3 depend : depends) {
/*  380: 362 */             depend.addTarget(tgt);
/*  381:     */           }
/*  382: 364 */           depends.add(tgt);
/*  383:     */         }
/*  384:     */       }
/*  385:     */     }
/*  386:     */     List<Block3> depends;
/*  387: 368 */     return blocks;
/*  388:     */   }
/*  389:     */   
/*  390:     */   private static boolean detectMoves(List<Block3> blocks, Options options)
/*  391:     */   {
/*  392: 389 */     Map<Op03SimpleStatement, Block3> opLocations = MapFactory.newIdentityMap();
/*  393: 390 */     Map<Block3, Integer> idxLut = MapFactory.newIdentityMap();
/*  394: 391 */     int i = 0;
/*  395:     */     Block3 blk;
/*  396: 391 */     for (int len = blocks.size(); i < len; i++)
/*  397:     */     {
/*  398: 392 */       blk = (Block3)blocks.get(i);
/*  399: 393 */       idxLut.put(blk, Integer.valueOf(i));
/*  400: 394 */       for (Op03SimpleStatement stm : blk.getContent()) {
/*  401: 395 */         opLocations.put(stm, blk);
/*  402:     */       }
/*  403:     */     }
/*  404: 399 */     BlockIdentifierFactory blockIdentifierFactory = new BlockIdentifierFactory();
/*  405: 400 */     List<Set<BlockIdentifier>> blockMembers = ListFactory.newList();
/*  406: 401 */     int i = 0;
/*  407: 401 */     for (int len = blocks.size(); i < len; i++) {
/*  408: 402 */       blockMembers.add(SetFactory.newSet());
/*  409:     */     }
/*  410: 404 */     Map<BlockIdentifier, Block3> firstByBlock = MapFactory.newMap();
/*  411: 405 */     Map<BlockIdentifier, Block3> lastByBlock = MapFactory.newMap();
/*  412: 406 */     int i = 0;
/*  413: 406 */     for (int len = blocks.size(); i < len; i++)
/*  414:     */     {
/*  415: 407 */       Block3 block = (Block3)blocks.get(i);
/*  416: 408 */       Block3 lastBackJump = block.getLastUnconditionalBackjumpToHere(idxLut);
/*  417: 409 */       if (lastBackJump != null)
/*  418:     */       {
/*  419: 410 */         BlockIdentifier bid = blockIdentifierFactory.getNextBlockIdentifier(BlockType.DOLOOP);
/*  420: 411 */         int x = i + 1;
/*  421: 411 */         for (int last = ((Integer)idxLut.get(lastBackJump)).intValue(); x <= last; x++) {
/*  422: 412 */           ((Set)blockMembers.get(x)).add(bid);
/*  423:     */         }
/*  424: 414 */         firstByBlock.put(bid, block);
/*  425: 415 */         lastByBlock.put(bid, lastBackJump);
/*  426:     */       }
/*  427:     */     }
/*  428: 424 */     boolean effect = false;
/*  429: 425 */     if (options.getOption(OptionsImpl.FORCE_TOPSORT_EXTRA) == Troolean.TRUE)
/*  430:     */     {
/*  431: 427 */       int i = 0;
/*  432:     */       Block3 block;
/*  433:     */       Set<BlockIdentifier> inThese;
/*  434: 427 */       for (int len = blocks.size(); i < len; i++)
/*  435:     */       {
/*  436: 428 */         block = (Block3)blocks.get(i);
/*  437: 429 */         if (block.targets.isEmpty())
/*  438:     */         {
/*  439: 430 */           inThese = (Set)blockMembers.get(i);
/*  440: 431 */           if (!inThese.isEmpty()) {
/*  441: 432 */             for (Block3 source : block.originalSources)
/*  442:     */             {
/*  443: 433 */               int j = ((Integer)idxLut.get(source)).intValue();
/*  444: 434 */               if (j < i)
/*  445:     */               {
/*  446: 435 */                 Set<BlockIdentifier> sourceInThese = (Set)blockMembers.get(j);
/*  447: 436 */                 if (!sourceInThese.containsAll(inThese))
/*  448:     */                 {
/*  449: 442 */                   Set<BlockIdentifier> tmp = SetFactory.newSet(inThese);
/*  450: 443 */                   tmp.removeAll(sourceInThese);
/*  451: 444 */                   List<Block3> newSources = ListFactory.newList();
/*  452: 445 */                   for (BlockIdentifier jumpedInto : tmp) {
/*  453: 446 */                     if (firstByBlock.get(jumpedInto) != block) {
/*  454: 447 */                       newSources.add(lastByBlock.get(jumpedInto));
/*  455:     */                     }
/*  456:     */                   }
/*  457: 450 */                   if (!newSources.isEmpty())
/*  458:     */                   {
/*  459: 451 */                     block.addSources(newSources);
/*  460: 452 */                     effect = true;
/*  461: 453 */                     break;
/*  462:     */                   }
/*  463:     */                 }
/*  464:     */               }
/*  465:     */             }
/*  466:     */           }
/*  467:     */         }
/*  468:     */       }
/*  469:     */     }
/*  470:     */     else
/*  471:     */     {
/*  472: 462 */       for (Map.Entry<BlockIdentifier, Block3> entry : firstByBlock.entrySet())
/*  473:     */       {
/*  474: 463 */         BlockIdentifier ident = (BlockIdentifier)entry.getKey();
/*  475: 464 */         Block3 block = (Block3)entry.getValue();
/*  476: 465 */         Op03SimpleStatement first = block.getStart();
/*  477: 466 */         Statement statement = first.getStatement();
/*  478: 467 */         if ((statement instanceof IfStatement))
/*  479:     */         {
/*  480: 468 */           List<Op03SimpleStatement> tgts = first.getTargets();
/*  481: 469 */           if (tgts.size() == 2)
/*  482:     */           {
/*  483: 471 */             Op03SimpleStatement tgt = (Op03SimpleStatement)tgts.get(1);
/*  484: 472 */             Block3 blktgt = (Block3)opLocations.get(tgt);
/*  485: 473 */             if ((((Set)blockMembers.get(((Integer)idxLut.get(blktgt)).intValue())).contains(ident)) && 
/*  486: 474 */               (lastByBlock.get(ident) != blktgt))
/*  487:     */             {
/*  488: 476 */               Set<Block3> origSources = SetFactory.newSet(blktgt.originalSources);
/*  489: 477 */               origSources.remove(block);
/*  490: 478 */               Iterator i$ = origSources.iterator();
/*  491:     */               for (;;)
/*  492:     */               {
/*  493: 478 */                 if (!i$.hasNext()) {
/*  494:     */                   break label928;
/*  495:     */                 }
/*  496: 478 */                 Block3 src = (Block3)i$.next();
/*  497: 479 */                 if (((((Set)blockMembers.get(((Integer)idxLut.get(src)).intValue())).contains(ident)) && (src.startIndex.isBackJumpFrom(blktgt.startIndex))) || (src.startIndex.isBackJumpFrom(block.startIndex)))
/*  498:     */                 {
/*  499: 482 */                   blktgt.addSource((Block3)lastByBlock.get(ident));
/*  500: 483 */                   effect = true;
/*  501: 484 */                   break;
/*  502:     */                 }
/*  503:     */               }
/*  504:     */             }
/*  505:     */           }
/*  506:     */         }
/*  507:     */       }
/*  508:     */     }
/*  509:     */     label928:
/*  510: 491 */     if (effect) {
/*  511: 492 */       for (Block3 block : blocks) {
/*  512: 493 */         block.copySources();
/*  513:     */       }
/*  514:     */     }
/*  515: 496 */     return effect;
/*  516:     */   }
/*  517:     */   
/*  518:     */   private static void stripTryBlockAliases(List<Op03SimpleStatement> out, Map<BlockIdentifier, BlockIdentifier> tryBlockAliases)
/*  519:     */   {
/*  520: 501 */     List<Op03SimpleStatement> remove = ListFactory.newList();
/*  521:     */     
/*  522: 503 */     int x = 1;
/*  523: 503 */     for (int len = out.size(); x < len; x++)
/*  524:     */     {
/*  525: 504 */       Op03SimpleStatement s = (Op03SimpleStatement)out.get(x);
/*  526: 505 */       if (s.getStatement().getClass() == TryStatement.class)
/*  527:     */       {
/*  528: 510 */         TryStatement tryStatement = (TryStatement)s.getStatement();
/*  529: 511 */         BlockIdentifier tryBlock = tryStatement.getBlockIdentifier();
/*  530: 512 */         Op03SimpleStatement prev = (Op03SimpleStatement)out.get(x - 1);
/*  531: 513 */         BlockIdentifier alias = (BlockIdentifier)tryBlockAliases.get(tryBlock);
/*  532: 514 */         if (alias != null) {
/*  533: 516 */           if (prev.getBlockIdentifiers().contains(alias)) {
/*  534: 516 */             remove.add(s);
/*  535:     */           }
/*  536:     */         }
/*  537:     */       }
/*  538:     */     }
/*  539: 519 */     if (remove.isEmpty()) {
/*  540: 519 */       return;
/*  541:     */     }
/*  542: 520 */     for (Op03SimpleStatement removeThis : remove)
/*  543:     */     {
/*  544: 521 */       TryStatement removeTry = (TryStatement)removeThis.getStatement();
/*  545: 522 */       blockIdentifier = removeTry.getBlockIdentifier();
/*  546: 523 */       alias = (BlockIdentifier)tryBlockAliases.get(blockIdentifier);
/*  547:     */       
/*  548:     */ 
/*  549:     */ 
/*  550:     */ 
/*  551: 528 */       List<Op03SimpleStatement> targets = removeThis.getTargets();
/*  552: 529 */       Op03SimpleStatement naturalTarget = (Op03SimpleStatement)targets.get(0);
/*  553: 530 */       for (Op03SimpleStatement target : targets) {
/*  554: 531 */         target.removeSource(removeThis);
/*  555:     */       }
/*  556: 533 */       for (Op03SimpleStatement source : removeThis.getSources())
/*  557:     */       {
/*  558: 534 */         source.replaceTarget(removeThis, naturalTarget);
/*  559: 535 */         naturalTarget.addSource(source);
/*  560:     */       }
/*  561: 537 */       removeThis.clear();
/*  562: 538 */       for (Op03SimpleStatement statement : out) {
/*  563: 539 */         statement.replaceBlockIfIn(blockIdentifier, alias);
/*  564:     */       }
/*  565:     */     }
/*  566:     */     BlockIdentifier blockIdentifier;
/*  567:     */     BlockIdentifier alias;
/*  568:     */   }
/*  569:     */   
/*  570:     */   public static List<Op03SimpleStatement> combineTryBlocks(Method method, List<Op03SimpleStatement> statements)
/*  571:     */   {
/*  572: 545 */     Map<BlockIdentifier, BlockIdentifier> tryBlockAliases = getTryBlockAliases(statements);
/*  573: 546 */     stripTryBlockAliases(statements, tryBlockAliases);
/*  574: 547 */     return Cleaner.removeUnreachableCode(statements, true);
/*  575:     */   }
/*  576:     */   
/*  577:     */   private static boolean canCombineBlockSets(Block3 from, Block3 to)
/*  578:     */   {
/*  579: 552 */     Set<BlockIdentifier> fromBlocks = from.getStart().getBlockIdentifiers();
/*  580: 553 */     Set<BlockIdentifier> toBlocks = to.getStart().getBlockIdentifiers();
/*  581: 555 */     if (fromBlocks.equals(toBlocks)) {
/*  582: 555 */       return true;
/*  583:     */     }
/*  584: 558 */     fromBlocks = from.getEnd().getBlockIdentifiers();
/*  585: 559 */     if (fromBlocks.equals(toBlocks)) {
/*  586: 559 */       return true;
/*  587:     */     }
/*  588: 561 */     if (fromBlocks.size() == toBlocks.size() - 1)
/*  589:     */     {
/*  590: 562 */       Statement stm = from.getEnd().getStatement();
/*  591: 563 */       if ((stm instanceof CaseStatement))
/*  592:     */       {
/*  593: 564 */         BlockIdentifier caseBlock = ((CaseStatement)stm).getCaseBlock();
/*  594: 565 */         List<BlockIdentifier> diff = SetUtil.differenceAtakeBtoList(toBlocks, fromBlocks);
/*  595: 566 */         if ((diff.size() == 1) && (diff.get(0) == caseBlock)) {
/*  596: 566 */           return true;
/*  597:     */         }
/*  598:     */       }
/*  599:     */     }
/*  600: 569 */     return false;
/*  601:     */   }
/*  602:     */   
/*  603:     */   private static List<Block3> sanitiseBlocks(Method method, List<Block3> blocks)
/*  604:     */   {
/*  605: 574 */     for (Block3 block : blocks)
/*  606:     */     {
/*  607: 575 */       block.sources.remove(block);
/*  608: 576 */       block.targets.remove(block);
/*  609:     */     }
/*  610: 578 */     return blocks;
/*  611:     */   }
/*  612:     */   
/*  613:     */   private static List<Block3> invertJoinZeroTargetJumps(Method method, List<Block3> blocks)
/*  614:     */   {
/*  615: 600 */     Map<Op03SimpleStatement, Block3> seenPrevBlock = MapFactory.newMap();
/*  616: 601 */     boolean effect = false;
/*  617: 602 */     int x = 0;
/*  618: 602 */     for (int len = blocks.size(); x < len; x++)
/*  619:     */     {
/*  620: 603 */       Block3 block = (Block3)blocks.get(x);
/*  621: 610 */       if ((block.sources.size() == 1) && (block.targets.size() == 0))
/*  622:     */       {
/*  623: 611 */         if (x > 0) {
/*  624: 611 */           seenPrevBlock.put(block.getStart(), blocks.get(x - 1));
/*  625:     */         }
/*  626: 613 */         Block3 source = (Block3)getSingle(block.sources);
/*  627:     */         
/*  628:     */ 
/*  629:     */ 
/*  630: 617 */         Op03SimpleStatement sourceEnd = source.getEnd();
/*  631: 618 */         Statement statement = sourceEnd.getStatement();
/*  632: 619 */         if (statement.getClass() == IfStatement.class)
/*  633:     */         {
/*  634: 620 */           IfStatement ifStatement = (IfStatement)statement;
/*  635:     */           
/*  636: 622 */           List<Op03SimpleStatement> targets = sourceEnd.getTargets();
/*  637: 623 */           if (targets.size() == 2)
/*  638:     */           {
/*  639: 624 */             Op03SimpleStatement taken = (Op03SimpleStatement)targets.get(1);
/*  640: 625 */             if (taken == block.getStart()) {
/*  641: 627 */               if (sourceEnd.getBlockIdentifiers().equals(taken.getBlockIdentifiers()))
/*  642:     */               {
/*  643: 628 */                 Op03SimpleStatement notTaken = (Op03SimpleStatement)targets.get(0);
/*  644:     */                 
/*  645:     */ 
/*  646: 631 */                 Block3 notTakenPrevBlock = (Block3)seenPrevBlock.get(notTaken);
/*  647: 632 */                 if (notTakenPrevBlock != source)
/*  648:     */                 {
/*  649: 635 */                   ifStatement.setCondition(ifStatement.getCondition().getNegated());
/*  650:     */                   
/*  651: 637 */                   source.getContent().addAll(block.getContent());
/*  652: 638 */                   block.getContent().clear();
/*  653: 639 */                   block.sources.clear();
/*  654: 640 */                   source.targets.remove(block);
/*  655:     */                   
/*  656:     */ 
/*  657: 643 */                   Op03SimpleStatement newGoto = new Op03SimpleStatement(sourceEnd.getBlockIdentifiers(), new GotoStatement(), sourceEnd.getIndex().justAfter());
/*  658: 644 */                   source.getContent().add(newGoto);
/*  659:     */                   
/*  660:     */ 
/*  661: 647 */                   sourceEnd.replaceTarget(taken, newGoto);
/*  662: 648 */                   sourceEnd.replaceTarget(notTaken, taken);
/*  663:     */                   
/*  664: 650 */                   notTaken.replaceSource(sourceEnd, newGoto);
/*  665: 651 */                   newGoto.addSource(sourceEnd);
/*  666: 652 */                   newGoto.addTarget(notTaken);
/*  667:     */                   
/*  668: 654 */                   blocks.set(x, null);
/*  669: 655 */                   effect = true;
/*  670:     */                 }
/*  671:     */               }
/*  672:     */             }
/*  673:     */           }
/*  674:     */         }
/*  675:     */       }
/*  676:     */     }
/*  677: 658 */     if (effect) {
/*  678: 659 */       blocks = Functional.filter(blocks, new Functional.NotNull());
/*  679:     */     }
/*  680: 661 */     return blocks;
/*  681:     */   }
/*  682:     */   
/*  683:     */   private static List<Block3> combineNeighbouringBlocks(Method method, List<Block3> blocks)
/*  684:     */   {
/*  685: 665 */     boolean reloop = false;
/*  686:     */     do
/*  687:     */     {
/*  688: 667 */       blocks = combineNeighbouringBlocksPass1(method, blocks);
/*  689: 668 */       reloop = moveSingleOutOrderBlocks(method, blocks);
/*  690: 669 */     } while (reloop);
/*  691: 671 */     return blocks;
/*  692:     */   }
/*  693:     */   
/*  694:     */   private static List<Block3> combineSingleCaseBackBlock(Method method, List<Block3> blocks)
/*  695:     */   {
/*  696: 679 */     IdentityHashMap<Block3, Integer> idx = new IdentityHashMap();
/*  697:     */     
/*  698: 681 */     boolean effect = false;
/*  699: 682 */     int x = 0;
/*  700: 682 */     for (int len = blocks.size(); x < len; x++)
/*  701:     */     {
/*  702: 683 */       Block3 block = (Block3)blocks.get(x);
/*  703: 684 */       idx.put(block, Integer.valueOf(x));
/*  704: 685 */       if ((block.targets.size() == 1) && (block.content.size() == 2))
/*  705:     */       {
/*  706: 686 */         Block3 target = (Block3)getSingle(block.targets);
/*  707: 687 */         Integer tgtIdx = (Integer)idx.get(target);
/*  708: 688 */         if ((tgtIdx != null) && 
/*  709: 689 */           (target.sources.size() == 1))
/*  710:     */         {
/*  711: 690 */           List<Op03SimpleStatement> content = block.content;
/*  712: 691 */           if ((((Op03SimpleStatement)content.get(0)).getStatement().getClass() == CaseStatement.class) && 
/*  713: 692 */             (((Op03SimpleStatement)content.get(1)).getStatement().getClass() == GotoStatement.class))
/*  714:     */           {
/*  715: 693 */             Set<BlockIdentifier> containedIn = ((Op03SimpleStatement)content.get(1)).getBlockIdentifiers();
/*  716:     */             
/*  717: 695 */             content = target.getContent();
/*  718: 696 */             for (Op03SimpleStatement statement : content) {
/*  719: 697 */               statement.getBlockIdentifiers().addAll(containedIn);
/*  720:     */             }
/*  721: 699 */             block.content.addAll(content);
/*  722: 700 */             target.sources.remove(block);
/*  723: 701 */             block.targets.remove(target);
/*  724: 702 */             for (Block3 tgt2 : target.targets)
/*  725:     */             {
/*  726: 703 */               tgt2.sources.remove(target);
/*  727: 704 */               tgt2.sources.add(block);
/*  728: 705 */               block.targets.add(tgt2);
/*  729: 706 */               tgt2.resetSources();
/*  730:     */             }
/*  731: 708 */             target.targets.clear();
/*  732: 709 */             blocks.set(tgtIdx.intValue(), null);
/*  733: 710 */             effect = true;
/*  734:     */           }
/*  735:     */         }
/*  736:     */       }
/*  737:     */     }
/*  738: 713 */     if (effect) {
/*  739: 714 */       blocks = Functional.filter(blocks, new Functional.NotNull());
/*  740:     */     }
/*  741: 716 */     return blocks;
/*  742:     */   }
/*  743:     */   
/*  744:     */   static boolean moveSingleOutOrderBlocks(Method method, List<Block3> blocks)
/*  745:     */   {
/*  746: 732 */     IdentityHashMap<Block3, Integer> idx = new IdentityHashMap();
/*  747: 733 */     int x = 0;
/*  748: 733 */     for (int len = blocks.size(); x < len; x++) {
/*  749: 734 */       idx.put(blocks.get(x), Integer.valueOf(x));
/*  750:     */     }
/*  751: 737 */     boolean effect = false;
/*  752: 738 */     int x = 0;
/*  753:     */     label515:
/*  754: 738 */     for (int len = blocks.size(); x < len; x++)
/*  755:     */     {
/*  756: 739 */       Block3 block = (Block3)blocks.get(x);
/*  757: 740 */       if ((block.sources.size() == 1) && (block.targets.size() == 1))
/*  758:     */       {
/*  759: 741 */         Block3 source = (Block3)getSingle(block.sources);
/*  760: 742 */         Block3 target = (Block3)getSingle(block.targets);
/*  761: 743 */         int idxsrc = ((Integer)idx.get(source)).intValue();
/*  762: 744 */         int idxtgt = ((Integer)idx.get(target)).intValue();
/*  763: 746 */         if ((idxsrc == idxtgt - 1) && (idxtgt < x))
/*  764:     */         {
/*  765: 749 */           List<Op03SimpleStatement> statements = source.getContent();
/*  766:     */           
/*  767: 751 */           Op03SimpleStatement prev = null;
/*  768: 752 */           for (int y = statements.size() - 1; y >= 0; y--)
/*  769:     */           {
/*  770: 753 */             Op03SimpleStatement stm = (Op03SimpleStatement)statements.get(y);
/*  771: 754 */             Statement statement = stm.getStatement();
/*  772: 755 */             if (!statement.fallsToNext())
/*  773:     */             {
/*  774: 757 */               List<Op03SimpleStatement> stmTargets = stm.getTargets();
/*  775: 758 */               if ((stmTargets.size() != 2) || (stmTargets.get(0) != prev)) {
/*  776:     */                 break label515;
/*  777:     */               }
/*  778: 758 */               if (stmTargets.get(1) == block.getStart()) {
/*  779:     */                 break;
/*  780:     */               }
/*  781:     */               break label515;
/*  782:     */             }
/*  783: 764 */             prev = stm;
/*  784:     */           }
/*  785: 767 */           if (!canCombineBlockSets(source, block))
/*  786:     */           {
/*  787: 769 */             Set<BlockIdentifier> srcBlocks = source.getEnd().getBlockIdentifiers();
/*  788: 770 */             Set<BlockIdentifier> midBlocks = block.getStart().getBlockIdentifiers();
/*  789: 771 */             if (srcBlocks.size() == midBlocks.size() + 1)
/*  790:     */             {
/*  791: 773 */               List<BlockIdentifier> diff = SetUtil.differenceAtakeBtoList(srcBlocks, midBlocks);
/*  792: 774 */               if (diff.size() == 1)
/*  793:     */               {
/*  794: 775 */                 BlockIdentifier blk = (BlockIdentifier)diff.get(0);
/*  795: 776 */                 if (blk.getBlockType() == BlockType.TRYBLOCK)
/*  796:     */                 {
/*  797: 778 */                   for (Op03SimpleStatement op : block.getContent()) {
/*  798: 779 */                     if (op.getStatement().canThrow(ExceptionCheckSimple.INSTANCE)) {
/*  799:     */                       break label515;
/*  800:     */                     }
/*  801:     */                   }
/*  802: 781 */                   block.getStart().markBlock(blk);
/*  803:     */                 }
/*  804:     */               }
/*  805:     */             }
/*  806:     */           }
/*  807:     */           else
/*  808:     */           {
/*  809: 787 */             blocks.remove(x);
/*  810: 788 */             int curridx = blocks.indexOf(source);
/*  811: 789 */             blocks.add(curridx + 1, block);
/*  812: 790 */             block.startIndex = source.startIndex.justAfter();
/*  813: 791 */             patch(source, block);
/*  814:     */             
/*  815: 793 */             effect = true;
/*  816:     */           }
/*  817:     */         }
/*  818:     */       }
/*  819:     */     }
/*  820: 797 */     return effect;
/*  821:     */   }
/*  822:     */   
/*  823:     */   private static List<Block3> combineNeighbouringBlocksPass1(Method method, List<Block3> blocks)
/*  824:     */   {
/*  825: 801 */     Block3 curr = (Block3)blocks.get(0);
/*  826: 802 */     int curridx = 0;
/*  827:     */     
/*  828: 804 */     int i = 1;
/*  829: 804 */     for (int len = blocks.size(); i < len; i++)
/*  830:     */     {
/*  831: 805 */       Block3 next = (Block3)blocks.get(i);
/*  832: 806 */       if (next != null)
/*  833:     */       {
/*  834: 809 */         if ((next.sources.size() == 1) && (getSingle(next.sources) == curr) && (next.getStart().getSources().contains(curr.getEnd()))) {
/*  835: 811 */           if (canCombineBlockSets(curr, next))
/*  836:     */           {
/*  837: 813 */             Op03SimpleStatement lastCurr = curr.getEnd();
/*  838: 814 */             Op03SimpleStatement firstNext = next.getStart();
/*  839: 815 */             if ((lastCurr.getStatement().getClass() == GotoStatement.class) && (!lastCurr.getTargets().isEmpty()) && (lastCurr.getTargets().get(0) == firstNext)) {
/*  840: 816 */               lastCurr.nopOut();
/*  841:     */             }
/*  842: 820 */             curr.content.addAll(next.content);
/*  843: 821 */             curr.targets.remove(next);
/*  844: 822 */             for (Block3 target : next.targets)
/*  845:     */             {
/*  846: 823 */               target.sources.remove(next);
/*  847: 824 */               target.sources.add(curr);
/*  848:     */             }
/*  849: 826 */             next.sources.clear();
/*  850: 827 */             curr.targets.addAll(next.targets);
/*  851: 828 */             next.targets.clear();
/*  852: 829 */             curr.sources.remove(curr);
/*  853: 830 */             curr.targets.remove(curr);
/*  854: 831 */             blocks.set(i, null);
/*  855: 834 */             for (int j = curridx - 1; j >= 0; j--)
/*  856:     */             {
/*  857: 835 */               Block3 tmp = (Block3)blocks.get(j);
/*  858: 836 */               if (tmp != null)
/*  859:     */               {
/*  860: 837 */                 curr = tmp;
/*  861: 838 */                 curridx = j;
/*  862: 839 */                 i = j;
/*  863: 840 */                 break;
/*  864:     */               }
/*  865:     */             }
/*  866: 843 */             continue;
/*  867:     */           }
/*  868:     */         }
/*  869: 847 */         curr = next;
/*  870: 848 */         curridx = i;
/*  871:     */       }
/*  872:     */     }
/*  873: 850 */     for (Block3 block : blocks) {
/*  874: 851 */       if (block != null) {
/*  875: 851 */         block.resetSources();
/*  876:     */       }
/*  877:     */     }
/*  878: 853 */     return Functional.filter(blocks, new Functional.NotNull());
/*  879:     */   }
/*  880:     */   
/*  881:     */   public static List<Op03SimpleStatement> topologicalSort(Method method, List<Op03SimpleStatement> statements, DecompilerComments comments, Options options)
/*  882:     */   {
/*  883: 858 */     List<Block3> blocks = buildBasicBlocks(method, statements);
/*  884:     */     
/*  885: 860 */     apply0TargetBlockHeuristic(blocks);
/*  886:     */     
/*  887: 862 */     Map<BlockIdentifier, BlockIdentifier> tryBlockAliases = getTryBlockAliases(statements);
/*  888: 863 */     applyKnownBlocksHeuristic(method, blocks, tryBlockAliases);
/*  889:     */     
/*  890: 865 */     blocks = sanitiseBlocks(method, blocks);
/*  891: 866 */     blocks = invertJoinZeroTargetJumps(method, blocks);
/*  892: 867 */     blocks = combineNeighbouringBlocks(method, blocks);
/*  893:     */     
/*  894:     */ 
/*  895:     */ 
/*  896:     */ 
/*  897: 872 */     blocks = combineSingleCaseBackBlock(method, blocks);
/*  898:     */     
/*  899: 874 */     blocks = doTopSort(blocks);
/*  900: 881 */     if (detectMoves(blocks, options))
/*  901:     */     {
/*  902: 882 */       Collections.sort(blocks);
/*  903: 883 */       blocks = doTopSort(blocks);
/*  904:     */     }
/*  905: 890 */     int i = 0;
/*  906: 890 */     for (int len = blocks.size(); i < len - 1; i++)
/*  907:     */     {
/*  908: 891 */       Block3 thisBlock = (Block3)blocks.get(i);
/*  909: 892 */       Block3 nextBlock = (Block3)blocks.get(i + 1);
/*  910: 893 */       patch(thisBlock, nextBlock);
/*  911:     */     }
/*  912: 896 */     patch((Block3)blocks.get(blocks.size() - 1), null);
/*  913:     */     
/*  914:     */ 
/*  915:     */ 
/*  916:     */ 
/*  917: 901 */     List<Op03SimpleStatement> outStatements = ListFactory.newList();
/*  918: 902 */     for (Block3 outBlock : blocks) {
/*  919: 903 */       outStatements.addAll(outBlock.getContent());
/*  920:     */     }
/*  921: 906 */     Cleaner.reindexInPlace(outStatements);
/*  922:     */     
/*  923:     */ 
/*  924:     */ 
/*  925:     */ 
/*  926: 911 */     boolean patched = false;
/*  927: 912 */     int x = 0;
/*  928: 912 */     for (int origLen = outStatements.size() - 1; x < origLen; x++)
/*  929:     */     {
/*  930: 913 */       Op03SimpleStatement stm = (Op03SimpleStatement)outStatements.get(x);
/*  931: 914 */       if (stm.getStatement().getClass() == IfStatement.class)
/*  932:     */       {
/*  933: 915 */         List<Op03SimpleStatement> targets = stm.getTargets();
/*  934: 916 */         Op03SimpleStatement next = (Op03SimpleStatement)outStatements.get(x + 1);
/*  935: 917 */         if (targets.get(0) != next) {
/*  936: 919 */           if (targets.get(1) == next)
/*  937:     */           {
/*  938: 920 */             IfStatement ifStatement = (IfStatement)stm.getStatement();
/*  939: 921 */             ifStatement.setCondition(ifStatement.getCondition().getNegated().simplify());
/*  940: 922 */             Op03SimpleStatement a = (Op03SimpleStatement)targets.get(0);
/*  941: 923 */             Op03SimpleStatement b = (Op03SimpleStatement)targets.get(1);
/*  942: 924 */             targets.set(0, b);
/*  943: 925 */             targets.set(1, a);
/*  944:     */           }
/*  945:     */           else
/*  946:     */           {
/*  947: 927 */             patched = true;
/*  948:     */             
/*  949: 929 */             Op03SimpleStatement extra = new Op03SimpleStatement(stm.getBlockIdentifiers(), new GotoStatement(), stm.getSSAIdentifiers(), stm.getIndex().justAfter());
/*  950: 930 */             Op03SimpleStatement target0 = (Op03SimpleStatement)targets.get(0);
/*  951: 931 */             extra.addSource(stm);
/*  952: 932 */             extra.addTarget(target0);
/*  953: 933 */             stm.replaceTarget(target0, extra);
/*  954: 934 */             target0.replaceSource(stm, extra);
/*  955: 935 */             outStatements.add(extra);
/*  956:     */           }
/*  957:     */         }
/*  958:     */       }
/*  959:     */     }
/*  960: 940 */     if (patched) {
/*  961: 941 */       outStatements = Cleaner.sortAndRenumber(outStatements);
/*  962:     */     }
/*  963: 944 */     stripTryBlockAliases(outStatements, tryBlockAliases);
/*  964: 950 */     if ((((Boolean)options.getOption(OptionsImpl.ALLOW_CORRECTING)).booleanValue()) && 
/*  965: 951 */       (stripBackExceptions(outStatements))) {
/*  966: 952 */       comments.addComment(DecompilerComment.TRY_BACKEDGE_REMOVED);
/*  967:     */     }
/*  968: 956 */     return Cleaner.removeUnreachableCode(outStatements, true);
/*  969:     */   }
/*  970:     */   
/*  971:     */   private static boolean stripBackExceptions(List<Op03SimpleStatement> statements)
/*  972:     */   {
/*  973: 960 */     boolean res = false;
/*  974: 961 */     List<Op03SimpleStatement> tryStatements = Functional.filter(statements, new Op03SimpleStatement.ExactTypeFilter(TryStatement.class));
/*  975: 962 */     for (Op03SimpleStatement statement : tryStatements)
/*  976:     */     {
/*  977: 963 */       TryStatement tryStatement = (TryStatement)statement.getStatement();
/*  978: 965 */       if (!statement.getTargets().isEmpty())
/*  979:     */       {
/*  980: 966 */         Op03SimpleStatement fallThrough = (Op03SimpleStatement)statement.getTargets().get(0);
/*  981: 967 */         List<Op03SimpleStatement> backTargets = Functional.filter(statement.getTargets(), new Misc.IsForwardJumpTo(statement.getIndex()));
/*  982: 968 */         boolean thisRes = false;
/*  983: 969 */         for (Op03SimpleStatement backTarget : backTargets)
/*  984:     */         {
/*  985: 970 */           Statement backTargetStatement = backTarget.getStatement();
/*  986: 971 */           if (backTargetStatement.getClass() == CatchStatement.class)
/*  987:     */           {
/*  988: 972 */             CatchStatement catchStatement = (CatchStatement)backTargetStatement;
/*  989: 973 */             catchStatement.getExceptions().removeAll(tryStatement.getEntries());
/*  990: 974 */             backTarget.removeSource(statement);
/*  991: 975 */             statement.removeTarget(backTarget);
/*  992: 976 */             thisRes = true;
/*  993:     */           }
/*  994:     */         }
/*  995: 982 */         if (thisRes)
/*  996:     */         {
/*  997: 983 */           res = true;
/*  998: 984 */           List<Op03SimpleStatement> remainingTargets = statement.getTargets();
/*  999: 985 */           if ((remainingTargets.size() == 1) && (remainingTargets.get(0) == fallThrough)) {
/* 1000: 986 */             statement.nopOut();
/* 1001:     */           }
/* 1002:     */         }
/* 1003:     */       }
/* 1004:     */     }
/* 1005: 990 */     return res;
/* 1006:     */   }
/* 1007:     */   
/* 1008:     */   private static void patch(Block3 a, Block3 b)
/* 1009:     */   {
/* 1010: 998 */     List<Op03SimpleStatement> content = a.content;
/* 1011: 999 */     Op03SimpleStatement last = (Op03SimpleStatement)content.get(content.size() - 1);
/* 1012:1000 */     Statement statement = last.getStatement();
/* 1013:1002 */     if ((last.getTargets().isEmpty()) || (!statement.fallsToNext())) {
/* 1014:1002 */       return;
/* 1015:     */     }
/* 1016:1005 */     Op03SimpleStatement fallThroughTarget = (Op03SimpleStatement)last.getTargets().get(0);
/* 1017:1006 */     if ((b != null) && (fallThroughTarget == b.getStart())) {
/* 1018:1006 */       return;
/* 1019:     */     }
/* 1020:1012 */     Op03SimpleStatement newGoto = new Op03SimpleStatement(last.getBlockIdentifiers(), new GotoStatement(), last.getIndex().justAfter());
/* 1021:1013 */     a.append(newGoto);
/* 1022:1014 */     last.replaceTarget(fallThroughTarget, newGoto);
/* 1023:1015 */     newGoto.addSource(last);
/* 1024:1016 */     newGoto.addTarget(fallThroughTarget);
/* 1025:1017 */     fallThroughTarget.replaceSource(last, newGoto);
/* 1026:     */   }
/* 1027:     */   
/* 1028:     */   private static class Block3
/* 1029:     */     implements Comparable<Block3>
/* 1030:     */   {
/* 1031:     */     InstrIndex startIndex;
/* 1032:1022 */     List<Op03SimpleStatement> content = ListFactory.newList();
/* 1033:1023 */     Set<Block3> sources = new LinkedHashSet();
/* 1034:1025 */     Set<Block3> originalSources = new LinkedHashSet();
/* 1035:1026 */     Set<Block3> targets = new LinkedHashSet();
/* 1036:     */     
/* 1037:     */     public Block3(Op03SimpleStatement s)
/* 1038:     */     {
/* 1039:1030 */       this.startIndex = s.getIndex();
/* 1040:1031 */       this.content.add(s);
/* 1041:     */     }
/* 1042:     */     
/* 1043:     */     public void append(Op03SimpleStatement s)
/* 1044:     */     {
/* 1045:1035 */       this.content.add(s);
/* 1046:     */     }
/* 1047:     */     
/* 1048:     */     public Op03SimpleStatement getStart()
/* 1049:     */     {
/* 1050:1039 */       return (Op03SimpleStatement)this.content.get(0);
/* 1051:     */     }
/* 1052:     */     
/* 1053:     */     public Op03SimpleStatement getEnd()
/* 1054:     */     {
/* 1055:1043 */       return (Op03SimpleStatement)this.content.get(this.content.size() - 1);
/* 1056:     */     }
/* 1057:     */     
/* 1058:     */     public void addSources(List<Block3> sources)
/* 1059:     */     {
/* 1060:1047 */       for (Block3 source : sources) {
/* 1061:1048 */         if (source == null) {
/* 1062:1049 */           throw new IllegalStateException();
/* 1063:     */         }
/* 1064:     */       }
/* 1065:1052 */       this.sources.addAll(sources);
/* 1066:1053 */       this.originalSources.addAll(sources);
/* 1067:     */     }
/* 1068:     */     
/* 1069:     */     public void addSource(Block3 source)
/* 1070:     */     {
/* 1071:1057 */       this.sources.add(source);
/* 1072:1058 */       this.originalSources.add(source);
/* 1073:     */     }
/* 1074:     */     
/* 1075:     */     public void setTargets(List<Block3> targets)
/* 1076:     */     {
/* 1077:1062 */       this.targets.clear();
/* 1078:1063 */       this.targets.addAll(targets);
/* 1079:     */     }
/* 1080:     */     
/* 1081:     */     public void addTargets(List<Block3> targets)
/* 1082:     */     {
/* 1083:1067 */       for (Block3 source : targets) {
/* 1084:1068 */         if (source == null) {
/* 1085:1069 */           throw new IllegalStateException();
/* 1086:     */         }
/* 1087:     */       }
/* 1088:1072 */       this.targets.addAll(targets);
/* 1089:     */     }
/* 1090:     */     
/* 1091:     */     public void addTarget(Block3 source)
/* 1092:     */     {
/* 1093:1077 */       this.targets.add(source);
/* 1094:     */     }
/* 1095:     */     
/* 1096:     */     public int compareTo(Block3 other)
/* 1097:     */     {
/* 1098:1083 */       return this.startIndex.compareTo(other.startIndex);
/* 1099:     */     }
/* 1100:     */     
/* 1101:     */     public String toString()
/* 1102:     */     {
/* 1103:1088 */       return "(" + this.content.size() + ")[" + this.sources.size() + "/" + this.originalSources.size() + "," + this.targets.size() + "] " + this.startIndex + getStart().toString();
/* 1104:     */     }
/* 1105:     */     
/* 1106:     */     private List<Op03SimpleStatement> getContent()
/* 1107:     */     {
/* 1108:1092 */       return this.content;
/* 1109:     */     }
/* 1110:     */     
/* 1111:     */     public void copySources()
/* 1112:     */     {
/* 1113:1096 */       this.sources.clear();
/* 1114:1097 */       this.sources.addAll(this.originalSources);
/* 1115:     */     }
/* 1116:     */     
/* 1117:     */     public void resetSources()
/* 1118:     */     {
/* 1119:1101 */       this.originalSources.clear();
/* 1120:1102 */       this.originalSources.addAll(this.sources);
/* 1121:     */     }
/* 1122:     */     
/* 1123:     */     public Block3 getLastUnconditionalBackjumpToHere(Map<Block3, Integer> idxLut)
/* 1124:     */     {
/* 1125:1106 */       int thisIdx = ((Integer)idxLut.get(this)).intValue();
/* 1126:1107 */       int best = -1;
/* 1127:1108 */       Block3 bestSource = null;
/* 1128:1109 */       for (Block3 source : this.originalSources) {
/* 1129:1110 */         if (source.getEnd().getStatement().getClass() == GotoStatement.class)
/* 1130:     */         {
/* 1131:1111 */           int idxSource = ((Integer)idxLut.get(source)).intValue();
/* 1132:1112 */           if ((idxSource > best) && (idxSource > thisIdx))
/* 1133:     */           {
/* 1134:1113 */             bestSource = source;
/* 1135:1114 */             best = idxSource;
/* 1136:     */           }
/* 1137:     */         }
/* 1138:     */       }
/* 1139:1118 */       return bestSource;
/* 1140:     */     }
/* 1141:     */   }
/* 1142:     */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.Op03Blocks
 * JD-Core Version:    0.7.0.1
 */