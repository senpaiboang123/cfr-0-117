/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  5:   */ 
/*  6:   */ public class LinearScannedBlock
/*  7:   */ {
/*  8:   */   private Op03SimpleStatement first;
/*  9:   */   private Op03SimpleStatement last;
/* 10:   */   private int idxFirst;
/* 11:   */   private int idxLast;
/* 12:   */   
/* 13:   */   public LinearScannedBlock(Op03SimpleStatement first, Op03SimpleStatement last, int idxFirst, int idxLast)
/* 14:   */   {
/* 15:14 */     this.first = first;
/* 16:15 */     this.last = last;
/* 17:16 */     this.idxFirst = idxFirst;
/* 18:17 */     this.idxLast = idxLast;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public Op03SimpleStatement getFirst()
/* 22:   */   {
/* 23:21 */     return this.first;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public Op03SimpleStatement getLast()
/* 27:   */   {
/* 28:25 */     return this.last;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public int getIdxFirst()
/* 32:   */   {
/* 33:29 */     return this.idxFirst;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public int getIdxLast()
/* 37:   */   {
/* 38:33 */     return this.idxLast;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public boolean isAfter(LinearScannedBlock other)
/* 42:   */   {
/* 43:37 */     return this.idxFirst > other.idxLast;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public boolean immediatelyFollows(LinearScannedBlock other)
/* 47:   */   {
/* 48:41 */     return this.idxFirst == other.idxLast + 1;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public void reindex(List<Op03SimpleStatement> in)
/* 52:   */   {
/* 53:49 */     if (in.get(this.idxFirst) != this.first) {
/* 54:49 */       this.idxFirst = in.indexOf(this.first);
/* 55:   */     }
/* 56:50 */     if (in.get(this.idxLast) != this.last) {
/* 57:50 */       this.idxLast = in.indexOf(this.last);
/* 58:   */     }
/* 59:   */   }
/* 60:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LinearScannedBlock
 * JD-Core Version:    0.7.0.1
 */