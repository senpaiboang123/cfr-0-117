/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph;
/*  2:   */ 
/*  3:   */ import java.util.Map;
/*  4:   */ import java.util.Map.Entry;
/*  5:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  6:   */ import org.benf.cfr.reader.util.MapFactory;
/*  7:   */ 
/*  8:   */ public class GraphConversionHelper<X extends Graph<X>, Y extends MutableGraph<Y>>
/*  9:   */ {
/* 10:   */   private final Map<X, Y> correspondance;
/* 11:   */   
/* 12:   */   public GraphConversionHelper()
/* 13:   */   {
/* 14:12 */     this.correspondance = MapFactory.newMap();
/* 15:   */   }
/* 16:   */   
/* 17:   */   private Y findEntry(X key, X orig, String dbg)
/* 18:   */   {
/* 19:16 */     Y value = (MutableGraph)this.correspondance.get(key);
/* 20:17 */     if (value == null) {
/* 21:18 */       throw new ConfusedCFRException("Missing key when tying up graph " + key + ", was " + dbg + " of " + orig);
/* 22:   */     }
/* 23:19 */     return value;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void patchUpRelations()
/* 27:   */   {
/* 28:23 */     for (Map.Entry<X, Y> entry : this.correspondance.entrySet())
/* 29:   */     {
/* 30:24 */       orig = (Graph)entry.getKey();
/* 31:25 */       newnode = (MutableGraph)entry.getValue();
/* 32:27 */       for (X source : orig.getSources()) {
/* 33:28 */         newnode.addSource(findEntry(source, orig, "source"));
/* 34:   */       }
/* 35:31 */       for (X target : orig.getTargets()) {
/* 36:32 */         newnode.addTarget(findEntry(target, orig, "target"));
/* 37:   */       }
/* 38:   */     }
/* 39:   */     X orig;
/* 40:   */     Y newnode;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public void registerOriginalAndNew(X original, Y newnode)
/* 44:   */   {
/* 45:38 */     this.correspondance.put(original, newnode);
/* 46:   */   }
/* 47:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.GraphConversionHelper
 * JD-Core Version:    0.7.0.1
 */