/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.BoxingHelper;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractMemberFunctionInvokation;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CastExpression;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.MemberFunctionInvokation;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.StaticFunctionInvokation;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface.BoxingProcessor;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.GenericTypeBinder;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  25:    */ import org.benf.cfr.reader.entities.classfilehelpers.OverloadMethodSet;
/*  26:    */ 
/*  27:    */ public class PrimitiveBoxingRewriter
/*  28:    */   implements ExpressionRewriter
/*  29:    */ {
/*  30:    */   public void handleStatement(StatementContainer statementContainer)
/*  31:    */   {
/*  32: 31 */     Object statement = statementContainer.getStatement();
/*  33: 32 */     if ((statement instanceof BoxingProcessor)) {
/*  34: 33 */       ((BoxingProcessor)statement).rewriteBoxing(this);
/*  35:    */     }
/*  36:    */   }
/*  37:    */   
/*  38:    */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  39:    */   {
/*  40: 42 */     if ((expression instanceof BoxingProcessor))
/*  41:    */     {
/*  42: 43 */       BoxingProcessor boxingProcessor = (BoxingProcessor)expression;
/*  43: 44 */       if (boxingProcessor.rewriteBoxing(this))
/*  44:    */       {
/*  45: 45 */         boxingProcessor.applyNonArgExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/*  46: 46 */         return expression;
/*  47:    */       }
/*  48:    */     }
/*  49: 49 */     expression = expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/*  50: 50 */     return expression;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public ConditionalExpression rewriteExpression(ConditionalExpression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  54:    */   {
/*  55: 55 */     if ((expression instanceof BoxingProcessor))
/*  56:    */     {
/*  57: 56 */       BoxingProcessor boxingProcessor = (BoxingProcessor)expression;
/*  58: 57 */       if (boxingProcessor.rewriteBoxing(this))
/*  59:    */       {
/*  60: 58 */         boxingProcessor.applyNonArgExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/*  61: 59 */         return expression;
/*  62:    */       }
/*  63:    */     }
/*  64: 62 */     Expression res = expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/*  65: 63 */     return (ConditionalExpression)res;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  69:    */   {
/*  70: 77 */     return lValue;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public StackSSALabel rewriteExpression(StackSSALabel lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  74:    */   {
/*  75: 82 */     return lValue;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public Expression sugarParameterBoxing(Expression in, int argIdx, OverloadMethodSet possibleMethods, GenericTypeBinder gtb, MethodPrototype methodPrototype)
/*  79:    */   {
/*  80: 88 */     Expression res = in;
/*  81: 89 */     InferredJavaType outerCastType = null;
/*  82: 90 */     Expression res1 = null;
/*  83: 91 */     if ((in instanceof CastExpression))
/*  84:    */     {
/*  85: 92 */       boolean wasRaw = true;
/*  86: 93 */       if (methodPrototype != null)
/*  87:    */       {
/*  88: 94 */         List<JavaTypeInstance> argTypes = methodPrototype.getArgs();
/*  89: 95 */         if (argIdx <= argTypes.size() - 1) {
/*  90: 96 */           wasRaw = argTypes.get(argIdx) instanceof RawJavaType;
/*  91:    */         }
/*  92:    */       }
/*  93: 99 */       outerCastType = in.getInferredJavaType();
/*  94:100 */       res = CastExpression.removeImplicitOuterType(res, gtb, wasRaw);
/*  95:101 */       res1 = res;
/*  96:    */     }
/*  97:104 */     if ((res instanceof MemberFunctionInvokation)) {
/*  98:105 */       res = BoxingHelper.sugarUnboxing((MemberFunctionInvokation)res);
/*  99:106 */     } else if ((res instanceof StaticFunctionInvokation)) {
/* 100:107 */       res = BoxingHelper.sugarBoxing((StaticFunctionInvokation)res);
/* 101:    */     }
/* 102:109 */     if (res == in) {
/* 103:109 */       return in;
/* 104:    */     }
/* 105:110 */     if (!possibleMethods.callsCorrectMethod(res, argIdx, gtb))
/* 106:    */     {
/* 107:111 */       if ((outerCastType != null) && 
/* 108:112 */         (res.getInferredJavaType().getJavaTypeInstance().impreciseCanCastTo(outerCastType.getJavaTypeInstance(), gtb)))
/* 109:    */       {
/* 110:113 */         res = new CastExpression(outerCastType, res);
/* 111:114 */         if (possibleMethods.callsCorrectMethod(res, argIdx, gtb)) {
/* 112:115 */           return res;
/* 113:    */         }
/* 114:    */       }
/* 115:119 */       if ((res1 != null) && (possibleMethods.callsCorrectMethod(res1, argIdx, gtb))) {
/* 116:120 */         return res1;
/* 117:    */       }
/* 118:122 */       return in;
/* 119:    */     }
/* 120:124 */     return res;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public void removeRedundantCastOnly(List<Expression> mutableIn)
/* 124:    */   {
/* 125:129 */     int x = 0;
/* 126:129 */     for (int len = mutableIn.size(); x < len; x++) {
/* 127:130 */       mutableIn.set(x, removeRedundantCastOnly((Expression)mutableIn.get(x)));
/* 128:    */     }
/* 129:    */   }
/* 130:    */   
/* 131:    */   public Expression removeRedundantCastOnly(Expression in)
/* 132:    */   {
/* 133:135 */     if ((in instanceof CastExpression))
/* 134:    */     {
/* 135:136 */       if (((CastExpression)in).isForced()) {
/* 136:136 */         return in;
/* 137:    */       }
/* 138:137 */       JavaTypeInstance castType = in.getInferredJavaType().getJavaTypeInstance();
/* 139:138 */       JavaTypeInstance childType = ((CastExpression)in).getChild().getInferredJavaType().getJavaTypeInstance();
/* 140:139 */       if (castType.equals(childType)) {
/* 141:140 */         return removeRedundantCastOnly(((CastExpression)in).getChild());
/* 142:    */       }
/* 143:    */     }
/* 144:143 */     return in;
/* 145:    */   }
/* 146:    */   
/* 147:    */   public Expression sugarNonParameterBoxing(Expression in, JavaTypeInstance tgtType)
/* 148:    */   {
/* 149:147 */     boolean expectingPrim = tgtType instanceof RawJavaType;
/* 150:148 */     Expression res = in;
/* 151:149 */     boolean recast = false;
/* 152:150 */     if (((in instanceof CastExpression)) && (((CastExpression)in).couldBeImplicit((GenericTypeBinder)null)))
/* 153:    */     {
/* 154:152 */       res = ((CastExpression)in).getChild();
/* 155:156 */       if ((Literal.NULL.equals(res)) && (!tgtType.isObject())) {
/* 156:156 */         return in;
/* 157:    */       }
/* 158:157 */       recast = !(tgtType instanceof RawJavaType);
/* 159:    */     }
/* 160:158 */     else if ((in instanceof MemberFunctionInvokation))
/* 161:    */     {
/* 162:159 */       res = BoxingHelper.sugarUnboxing((MemberFunctionInvokation)in);
/* 163:    */     }
/* 164:160 */     else if ((in instanceof StaticFunctionInvokation))
/* 165:    */     {
/* 166:161 */       res = BoxingHelper.sugarBoxing((StaticFunctionInvokation)in);
/* 167:    */     }
/* 168:163 */     if (res == in) {
/* 169:163 */       return in;
/* 170:    */     }
/* 171:164 */     if (!res.getInferredJavaType().getJavaTypeInstance().implicitlyCastsTo(in.getInferredJavaType().getJavaTypeInstance(), null)) {
/* 172:165 */       return in;
/* 173:    */     }
/* 174:177 */     if (!res.getInferredJavaType().getJavaTypeInstance().impreciseCanCastTo(tgtType, null)) {
/* 175:178 */       return in;
/* 176:    */     }
/* 177:180 */     res = sugarNonParameterBoxing(res, tgtType);
/* 178:181 */     if (recast)
/* 179:    */     {
/* 180:182 */       CastExpression cast = (CastExpression)in;
/* 181:183 */       if ((!cast.isForced()) && 
/* 182:184 */         ((cast.getInferredJavaType().getJavaTypeInstance() instanceof RawJavaType)) && 
/* 183:185 */         ((res.getInferredJavaType().getJavaTypeInstance() instanceof JavaRefTypeInstance))) {
/* 184:187 */         res = new CastExpression(cast.getInferredJavaType(), res);
/* 185:    */       }
/* 186:    */     }
/* 187:192 */     return res;
/* 188:    */   }
/* 189:    */   
/* 190:    */   public Expression sugarUnboxing(Expression in)
/* 191:    */   {
/* 192:196 */     if ((in instanceof MemberFunctionInvokation)) {
/* 193:197 */       return BoxingHelper.sugarUnboxing((MemberFunctionInvokation)in);
/* 194:    */     }
/* 195:199 */     return in;
/* 196:    */   }
/* 197:    */   
/* 198:    */   public boolean isUnboxedType(Expression in)
/* 199:    */   {
/* 200:204 */     JavaTypeInstance type = in.getInferredJavaType().getJavaTypeInstance();
/* 201:205 */     if (!(type instanceof RawJavaType)) {
/* 202:205 */       return false;
/* 203:    */     }
/* 204:206 */     if ((in instanceof AbstractMemberFunctionInvokation)) {
/* 205:206 */       return false;
/* 206:    */     }
/* 207:207 */     RawJavaType rawJavaType = (RawJavaType)type;
/* 208:208 */     return rawJavaType.isUsableType();
/* 209:    */   }
/* 210:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.PrimitiveBoxingRewriter
 * JD-Core Version:    0.7.0.1
 */