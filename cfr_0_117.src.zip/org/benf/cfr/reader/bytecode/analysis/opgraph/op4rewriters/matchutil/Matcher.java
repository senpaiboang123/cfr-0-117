package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil;

public abstract interface Matcher<T>
{
  public abstract boolean match(MatchIterator<T> paramMatchIterator, MatchResultCollector paramMatchResultCollector);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.Matcher
 * JD-Core Version:    0.7.0.1
 */