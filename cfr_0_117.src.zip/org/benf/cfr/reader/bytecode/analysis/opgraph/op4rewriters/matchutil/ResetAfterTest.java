/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  5:   */ 
/*  6:   */ public class ResetAfterTest
/*  7:   */   implements Matcher<StructuredStatement>
/*  8:   */ {
/*  9:   */   private final WildcardMatch wildcardMatch;
/* 10:   */   private final Matcher<StructuredStatement> inner;
/* 11:   */   private final String name;
/* 12:   */   
/* 13:   */   public ResetAfterTest(WildcardMatch wildcardMatch, Matcher<StructuredStatement> inner)
/* 14:   */   {
/* 15:12 */     this(wildcardMatch, "", inner);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public ResetAfterTest(WildcardMatch wildcardMatch, String name, Matcher<StructuredStatement> inner)
/* 19:   */   {
/* 20:16 */     this.inner = inner;
/* 21:17 */     this.wildcardMatch = wildcardMatch;
/* 22:18 */     this.name = name;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 26:   */   {
/* 27:23 */     boolean result = this.inner.match(matchIterator, matchResultCollector);
/* 28:24 */     if (result) {
/* 29:24 */       matchResultCollector.collectMatches(this.name, this.wildcardMatch);
/* 30:   */     }
/* 31:25 */     this.wildcardMatch.reset();
/* 32:26 */     return result;
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.ResetAfterTest
 * JD-Core Version:    0.7.0.1
 */