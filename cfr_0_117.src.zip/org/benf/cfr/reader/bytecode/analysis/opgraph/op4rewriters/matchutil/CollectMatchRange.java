/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  4:   */ 
/*  5:   */ public class CollectMatchRange
/*  6:   */   implements Matcher<StructuredStatement>
/*  7:   */ {
/*  8:   */   private final Matcher<StructuredStatement> inner;
/*  9:   */   private final String name;
/* 10:   */   
/* 11:   */   public CollectMatchRange(String name, Matcher<StructuredStatement> inner)
/* 12:   */   {
/* 13:10 */     this.inner = inner;
/* 14:11 */     this.name = name;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 18:   */   {
/* 19:16 */     MatchIterator<StructuredStatement> orig = matchIterator.copy();
/* 20:17 */     boolean res = this.inner.match(matchIterator, matchResultCollector);
/* 21:18 */     if (res)
/* 22:   */     {
/* 23:19 */       MatchIterator<StructuredStatement> end = matchIterator.copy();
/* 24:20 */       matchResultCollector.collectStatementRange(this.name, orig, end);
/* 25:   */     }
/* 26:22 */     return res;
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.CollectMatchRange
 * JD-Core Version:    0.7.0.1
 */