/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*   2:    */ 
/*   3:    */ import java.util.Collections;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Set;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.InstrIndex;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CaseStatement;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.IfStatement;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.JumpingStatement;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.RawSwitchStatement;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.SwitchStatement;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifierFactory;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockType;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.JumpType;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  25:    */ import org.benf.cfr.reader.bytecode.opcode.DecodedSwitch;
/*  26:    */ import org.benf.cfr.reader.bytecode.opcode.DecodedSwitchEntry;
/*  27:    */ import org.benf.cfr.reader.entities.Method;
/*  28:    */ import org.benf.cfr.reader.util.CannotPerformDecode;
/*  29:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  30:    */ import org.benf.cfr.reader.util.Functional;
/*  31:    */ import org.benf.cfr.reader.util.ListFactory;
/*  32:    */ import org.benf.cfr.reader.util.MapFactory;
/*  33:    */ import org.benf.cfr.reader.util.SetFactory;
/*  34:    */ import org.benf.cfr.reader.util.SetUtil;
/*  35:    */ import org.benf.cfr.reader.util.functors.BinaryProcedure;
/*  36:    */ import org.benf.cfr.reader.util.getopt.Options;
/*  37:    */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*  38:    */ import org.benf.cfr.reader.util.graph.GraphVisitor;
/*  39:    */ import org.benf.cfr.reader.util.graph.GraphVisitorDFS;
/*  40:    */ 
/*  41:    */ public class SwitchReplacer
/*  42:    */ {
/*  43:    */   public static void replaceRawSwitches(Method method, List<Op03SimpleStatement> in, BlockIdentifierFactory blockIdentifierFactory, Options options)
/*  44:    */   {
/*  45: 29 */     List<Op03SimpleStatement> switchStatements = Functional.filter(in, new TypeFilter(RawSwitchStatement.class));
/*  46:    */     
/*  47: 31 */     List<Op03SimpleStatement> switches = ListFactory.newList();
/*  48: 32 */     for (Op03SimpleStatement switchStatement : switchStatements)
/*  49:    */     {
/*  50: 33 */       Op03SimpleStatement switchToProcess = replaceRawSwitch(method, switchStatement, in, blockIdentifierFactory);
/*  51: 34 */       if (switchToProcess != null) {
/*  52: 34 */         switches.add(switchToProcess);
/*  53:    */       }
/*  54:    */     }
/*  55: 37 */     Collections.sort(in, new CompareByIndex());
/*  56:    */     
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80: 62 */     boolean pullCodeIntoCase = ((Boolean)options.getOption(OptionsImpl.PULL_CODE_CASE)).booleanValue();
/*  81: 63 */     for (Op03SimpleStatement switchStatement : switches)
/*  82:    */     {
/*  83: 65 */       examineSwitchContiguity(switchStatement, in, pullCodeIntoCase);
/*  84: 66 */       moveJumpsToCaseStatements(switchStatement, in);
/*  85: 67 */       moveJumpsToTerminalIfEmpty(switchStatement, in);
/*  86:    */     }
/*  87:    */   }
/*  88:    */   
/*  89:    */   public static Op03SimpleStatement replaceRawSwitch(Method method, Op03SimpleStatement swatch, List<Op03SimpleStatement> in, BlockIdentifierFactory blockIdentifierFactory)
/*  90:    */   {
/*  91: 73 */     List<Op03SimpleStatement> targets = swatch.getTargets();
/*  92: 74 */     RawSwitchStatement switchStatement = (RawSwitchStatement)swatch.getStatement();
/*  93: 75 */     DecodedSwitch switchData = switchStatement.getSwitchData();
/*  94: 76 */     BlockIdentifier switchBlockIdentifier = blockIdentifierFactory.getNextBlockIdentifier(BlockType.SWITCH);
/*  95:    */     
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99: 81 */     Op03SimpleStatement oneTarget = (Op03SimpleStatement)targets.get(0);
/* 100: 82 */     boolean mismatch = false;
/* 101: 83 */     for (int x = 1; x < targets.size(); x++)
/* 102:    */     {
/* 103: 84 */       Op03SimpleStatement target = (Op03SimpleStatement)targets.get(x);
/* 104: 85 */       if (target != oneTarget)
/* 105:    */       {
/* 106: 86 */         mismatch = true;
/* 107: 87 */         break;
/* 108:    */       }
/* 109:    */     }
/* 110: 90 */     if (!mismatch)
/* 111:    */     {
/* 112:100 */       int idx = in.indexOf(swatch);
/* 113:101 */       if ((idx + 1 >= in.size()) || (oneTarget != in.get(idx + 1)))
/* 114:    */       {
/* 115:103 */         swatch.replaceStatement(new GotoStatement());
/* 116:104 */         return null;
/* 117:    */       }
/* 118:107 */       swatch.replaceStatement(switchStatement.getSwitchStatement(switchBlockIdentifier));
/* 119:108 */       BlockIdentifier defBlock = blockIdentifierFactory.getNextBlockIdentifier(BlockType.CASE);
/* 120:109 */       Op03SimpleStatement defStm = new Op03SimpleStatement(swatch.getBlockIdentifiers(), new CaseStatement(ListFactory.newList(), switchStatement.getSwitchOn().getInferredJavaType(), switchBlockIdentifier, defBlock), swatch.getIndex().justAfter());
/* 121:    */       
/* 122:    */ 
/* 123:    */ 
/* 124:113 */       swatch.replaceTarget(oneTarget, defStm);
/* 125:114 */       oneTarget.replaceSource(swatch, defStm);
/* 126:115 */       defStm.addSource(swatch);
/* 127:116 */       defStm.addTarget(oneTarget);
/* 128:117 */       defStm.getBlockIdentifiers().add(switchBlockIdentifier);
/* 129:118 */       in.add(defStm);
/* 130:119 */       return null;
/* 131:    */     }
/* 132:127 */     List<DecodedSwitchEntry> entries = switchData.getJumpTargets();
/* 133:128 */     InferredJavaType caseType = switchStatement.getSwitchOn().getInferredJavaType();
/* 134:129 */     Map<InstrIndex, Op03SimpleStatement> firstPrev = MapFactory.newMap();
/* 135:    */     
/* 136:131 */     InstrIndex nextIntermed = swatch.getIndex().justAfter();
/* 137:132 */     int x = 0;
/* 138:132 */     for (int len = targets.size(); x < len; x++)
/* 139:    */     {
/* 140:133 */       Op03SimpleStatement target = (Op03SimpleStatement)targets.get(x);
/* 141:134 */       InstrIndex tindex = target.getIndex();
/* 142:135 */       if (firstPrev.containsKey(tindex)) {
/* 143:136 */         target = (Op03SimpleStatement)firstPrev.get(tindex);
/* 144:    */       }
/* 145:138 */       List<Expression> expression = ListFactory.newList();
/* 146:    */       
/* 147:    */ 
/* 148:141 */       List<Integer> vals = ((DecodedSwitchEntry)entries.get(x)).getValue();
/* 149:142 */       for (Integer val : vals) {
/* 150:143 */         if (val != null) {
/* 151:144 */           expression.add(new Literal(TypedLiteral.getInt(val.intValue())));
/* 152:    */         }
/* 153:    */       }
/* 154:147 */       Set<BlockIdentifier> blocks = SetFactory.newSet(target.getBlockIdentifiers());
/* 155:148 */       blocks.add(switchBlockIdentifier);
/* 156:149 */       BlockIdentifier caseIdentifier = blockIdentifierFactory.getNextBlockIdentifier(BlockType.CASE);
/* 157:150 */       Op03SimpleStatement caseStatement = new Op03SimpleStatement(blocks, new CaseStatement(expression, caseType, switchBlockIdentifier, caseIdentifier), target.getIndex().justBefore());
/* 158:    */       
/* 159:    */ 
/* 160:153 */       Iterator<Op03SimpleStatement> iterator = target.getSources().iterator();
/* 161:154 */       while (iterator.hasNext())
/* 162:    */       {
/* 163:155 */         Op03SimpleStatement source = (Op03SimpleStatement)iterator.next();
/* 164:156 */         if ((!swatch.getIndex().isBackJumpTo(source)) && 
/* 165:    */         
/* 166:    */ 
/* 167:159 */           (!source.getIndex().isBackJumpTo(target)))
/* 168:    */         {
/* 169:162 */           source.replaceTarget(target, caseStatement);
/* 170:163 */           caseStatement.addSource(source);
/* 171:164 */           iterator.remove();
/* 172:    */         }
/* 173:    */       }
/* 174:166 */       if (caseStatement.getSources().isEmpty())
/* 175:    */       {
/* 176:169 */         caseStatement.setIndex(nextIntermed);
/* 177:170 */         nextIntermed = nextIntermed.justAfter();
/* 178:171 */         Op03SimpleStatement intermediateGoto = new Op03SimpleStatement(blocks, new GotoStatement(), nextIntermed);
/* 179:172 */         nextIntermed = nextIntermed.justAfter();
/* 180:173 */         intermediateGoto.addSource(caseStatement);
/* 181:174 */         intermediateGoto.addTarget(target);
/* 182:175 */         caseStatement.addTarget(intermediateGoto);
/* 183:176 */         target.replaceSource(swatch, intermediateGoto);
/* 184:177 */         swatch.replaceTarget(target, caseStatement);
/* 185:178 */         caseStatement.addSource(swatch);
/* 186:179 */         in.add(caseStatement);
/* 187:180 */         in.add(intermediateGoto);
/* 188:    */       }
/* 189:    */       else
/* 190:    */       {
/* 191:183 */         target.addSource(caseStatement);
/* 192:184 */         caseStatement.addTarget(target);
/* 193:185 */         in.add(caseStatement);
/* 194:186 */         firstPrev.put(tindex, caseStatement);
/* 195:    */       }
/* 196:    */     }
/* 197:189 */     Cleaner.sortAndRenumberInPlace(in);
/* 198:    */     
/* 199:    */ 
/* 200:    */ 
/* 201:    */ 
/* 202:    */ 
/* 203:    */ 
/* 204:    */ 
/* 205:    */ 
/* 206:    */ 
/* 207:    */ 
/* 208:    */ 
/* 209:    */ 
/* 210:    */ 
/* 211:    */ 
/* 212:    */ 
/* 213:    */ 
/* 214:    */ 
/* 215:    */ 
/* 216:208 */     buildSwitchCases(swatch, targets, switchBlockIdentifier, in);
/* 217:    */     
/* 218:210 */     swatch.replaceStatement(switchStatement.getSwitchStatement(switchBlockIdentifier));
/* 219:    */     
/* 220:    */ 
/* 221:    */ 
/* 222:214 */     Collections.sort(swatch.getTargets(), new CompareByIndex());
/* 223:    */     
/* 224:216 */     return swatch;
/* 225:    */   }
/* 226:    */   
/* 227:    */   private static void buildSwitchCases(Op03SimpleStatement swatch, List<Op03SimpleStatement> targets, BlockIdentifier switchBlockIdentifier, List<Op03SimpleStatement> in)
/* 228:    */   {
/* 229:220 */     Set<BlockIdentifier> caseIdentifiers = SetFactory.newSet();
/* 230:    */     
/* 231:    */ 
/* 232:    */ 
/* 233:    */ 
/* 234:    */ 
/* 235:    */ 
/* 236:    */ 
/* 237:228 */     Set<Op03SimpleStatement> caseTargets = SetFactory.newSet(targets);
/* 238:    */     
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:    */ 
/* 243:234 */     Map<Op03SimpleStatement, InstrIndex> lastStatementBefore = MapFactory.newMap();
/* 244:235 */     for (Op03SimpleStatement target : targets)
/* 245:    */     {
/* 246:236 */       CaseStatement caseStatement = (CaseStatement)target.getStatement();
/* 247:237 */       BlockIdentifier caseBlock = caseStatement.getCaseBlock();
/* 248:239 */       if (!caseStatement.isDefault()) {
/* 249:240 */         target.markBlock(switchBlockIdentifier);
/* 250:    */       }
/* 251:243 */       NodeReachable nodeReachable = new NodeReachable(caseTargets, target, swatch, null);
/* 252:244 */       GraphVisitor<Op03SimpleStatement> gv = new GraphVisitorDFS(target, nodeReachable);
/* 253:245 */       gv.process();
/* 254:    */       
/* 255:247 */       List<Op03SimpleStatement> backReachable = Functional.filter(nodeReachable.reaches, new Misc.IsForwardJumpTo(target.getIndex()));
/* 256:248 */       if ((!backReachable.isEmpty()) && 
/* 257:    */       
/* 258:250 */         (backReachable.size() == 1))
/* 259:    */       {
/* 260:255 */         Op03SimpleStatement backTarget = (Op03SimpleStatement)backReachable.get(0);
/* 261:    */         
/* 262:    */ 
/* 263:    */ 
/* 264:    */ 
/* 265:    */ 
/* 266:    */ 
/* 267:    */ 
/* 268:263 */         boolean contiguous = blockIsContiguous(in, target, nodeReachable.inBlock);
/* 269:264 */         if (target.getSources().size() != 1)
/* 270:    */         {
/* 271:269 */           if (contiguous) {
/* 272:270 */             for (Op03SimpleStatement reachable : nodeReachable.inBlock)
/* 273:    */             {
/* 274:271 */               reachable.markBlock(switchBlockIdentifier);
/* 275:274 */               if ((!caseTargets.contains(reachable)) && 
/* 276:275 */                 (!SetUtil.hasIntersection(reachable.getBlockIdentifiers(), caseIdentifiers))) {
/* 277:276 */                 reachable.markBlock(caseBlock);
/* 278:    */               }
/* 279:    */             }
/* 280:    */           }
/* 281:    */         }
/* 282:283 */         else if (contiguous)
/* 283:    */         {
/* 284:289 */           InstrIndex prev = (InstrIndex)lastStatementBefore.get(backTarget);
/* 285:290 */           if (prev == null) {
/* 286:291 */             prev = backTarget.getIndex().justBefore();
/* 287:    */           }
/* 288:293 */           int idx = in.indexOf(target) + nodeReachable.inBlock.size() - 1;
/* 289:294 */           int i = 0;
/* 290:294 */           for (int len = nodeReachable.inBlock.size(); i < len; idx--)
/* 291:    */           {
/* 292:295 */             ((Op03SimpleStatement)in.get(idx)).setIndex(prev);
/* 293:296 */             prev = prev.justBefore();i++;
/* 294:    */           }
/* 295:298 */           lastStatementBefore.put(backTarget, prev);
/* 296:    */         }
/* 297:    */       }
/* 298:    */     }
/* 299:    */   }
/* 300:    */   
/* 301:    */   public static void rebuildSwitches(List<Op03SimpleStatement> statements, Options options)
/* 302:    */   {
/* 303:305 */     List<Op03SimpleStatement> switchStatements = Functional.filter(statements, new TypeFilter(SwitchStatement.class));
/* 304:313 */     for (Op03SimpleStatement switchStatement : switchStatements)
/* 305:    */     {
/* 306:314 */       SwitchStatement switchStatementInr = (SwitchStatement)switchStatement.getStatement();
/* 307:315 */       allBlocks = SetFactory.newSet();
/* 308:316 */       allBlocks.add(switchStatementInr.getSwitchBlock());
/* 309:317 */       for (Op03SimpleStatement target : switchStatement.getTargets())
/* 310:    */       {
/* 311:318 */         Statement stmTgt = target.getStatement();
/* 312:319 */         if ((stmTgt instanceof CaseStatement)) {
/* 313:320 */           allBlocks.add(((CaseStatement)stmTgt).getCaseBlock());
/* 314:    */         }
/* 315:    */       }
/* 316:323 */       for (Op03SimpleStatement stm : statements) {
/* 317:324 */         stm.getBlockIdentifiers().removeAll(allBlocks);
/* 318:    */       }
/* 319:    */     }
/* 320:    */     Set<BlockIdentifier> allBlocks;
/* 321:327 */     for (Op03SimpleStatement switchStatement : switchStatements)
/* 322:    */     {
/* 323:328 */       SwitchStatement switchStatementInr = (SwitchStatement)switchStatement.getStatement();
/* 324:329 */       buildSwitchCases(switchStatement, switchStatement.getTargets(), switchStatementInr.getSwitchBlock(), statements);
/* 325:    */     }
/* 326:331 */     boolean pullCodeIntoCase = ((Boolean)options.getOption(OptionsImpl.PULL_CODE_CASE)).booleanValue();
/* 327:332 */     for (Op03SimpleStatement switchStatement : switchStatements)
/* 328:    */     {
/* 329:334 */       examineSwitchContiguity(switchStatement, statements, pullCodeIntoCase);
/* 330:335 */       moveJumpsToTerminalIfEmpty(switchStatement, statements);
/* 331:    */     }
/* 332:    */   }
/* 333:    */   
/* 334:    */   private static boolean blockIsContiguous(List<Op03SimpleStatement> in, Op03SimpleStatement start, Set<Op03SimpleStatement> blockContent)
/* 335:    */   {
/* 336:341 */     int idx = in.indexOf(start);
/* 337:342 */     int len = blockContent.size();
/* 338:343 */     if (idx + blockContent.size() > in.size()) {
/* 339:343 */       return false;
/* 340:    */     }
/* 341:344 */     for (int found = 1; found < len; idx++)
/* 342:    */     {
/* 343:345 */       Op03SimpleStatement next = (Op03SimpleStatement)in.get(idx);
/* 344:346 */       if (!blockContent.contains(next)) {
/* 345:347 */         return false;
/* 346:    */       }
/* 347:344 */       found++;
/* 348:    */     }
/* 349:350 */     return true;
/* 350:    */   }
/* 351:    */   
/* 352:    */   private static boolean examineSwitchContiguity(Op03SimpleStatement switchStatement, List<Op03SimpleStatement> statements, boolean pullCodeIntoCase)
/* 353:    */   {
/* 354:357 */     Set<Op03SimpleStatement> forwardTargets = SetFactory.newSet();
/* 355:    */     
/* 356:    */ 
/* 357:360 */     List<Op03SimpleStatement> targets = ListFactory.newList(switchStatement.getTargets());
/* 358:361 */     Collections.sort(targets, new CompareByIndex());
/* 359:    */     
/* 360:363 */     int idxFirstCase = statements.indexOf(targets.get(0));
/* 361:365 */     if (idxFirstCase != statements.indexOf(switchStatement) + 1) {
/* 362:366 */       throw new ConfusedCFRException("First case is not immediately after switch.");
/* 363:    */     }
/* 364:369 */     BlockIdentifier switchBlock = ((SwitchStatement)switchStatement.getStatement()).getSwitchBlock();
/* 365:370 */     int indexLastInLastBlock = 0;
/* 366:373 */     for (int x = 0; x < targets.size() - 1; x++)
/* 367:    */     {
/* 368:374 */       Op03SimpleStatement thisCase = (Op03SimpleStatement)targets.get(x);
/* 369:375 */       Op03SimpleStatement nextCase = (Op03SimpleStatement)targets.get(x + 1);
/* 370:376 */       int indexThisCase = statements.indexOf(thisCase);
/* 371:377 */       int indexNextCase = statements.indexOf(nextCase);
/* 372:378 */       InstrIndex nextCaseIndex = nextCase.getIndex();
/* 373:    */       
/* 374:380 */       Statement maybeCaseStatement = thisCase.getStatement();
/* 375:381 */       if ((maybeCaseStatement instanceof CaseStatement))
/* 376:    */       {
/* 377:382 */         CaseStatement caseStatement = (CaseStatement)maybeCaseStatement;
/* 378:383 */         BlockIdentifier caseBlock = caseStatement.getCaseBlock();
/* 379:    */         
/* 380:385 */         int indexLastInThis = Misc.getFarthestReachableInRange(statements, indexThisCase, indexNextCase);
/* 381:386 */         if (indexLastInThis != indexNextCase - 1) {}
/* 382:390 */         indexLastInLastBlock = indexLastInThis;
/* 383:391 */         for (int y = indexThisCase + 1; y <= indexLastInThis; y++)
/* 384:    */         {
/* 385:392 */           Op03SimpleStatement statement = (Op03SimpleStatement)statements.get(y);
/* 386:393 */           statement.markBlock(caseBlock);
/* 387:394 */           statement.markBlock(switchBlock);
/* 388:395 */           if (statement.getJumpType().isUnknown()) {
/* 389:396 */             for (Op03SimpleStatement innerTarget : statement.getTargets())
/* 390:    */             {
/* 391:397 */               innerTarget = Misc.followNopGoto(innerTarget, false, false);
/* 392:398 */               if ((nextCaseIndex.isBackJumpFrom(innerTarget)) && 
/* 393:399 */                 (!innerTarget.getBlockIdentifiers().contains(switchBlock))) {
/* 394:400 */                 forwardTargets.add(innerTarget);
/* 395:    */               }
/* 396:    */             }
/* 397:    */           }
/* 398:    */         }
/* 399:407 */         if (pullCodeIntoCase)
/* 400:    */         {
/* 401:417 */           Op03SimpleStatement lastStatement = (Op03SimpleStatement)statements.get(indexLastInThis);
/* 402:423 */           if (lastStatement.getStatement().getClass() == GotoStatement.class)
/* 403:    */           {
/* 404:424 */             Set<BlockIdentifier> others = SetFactory.newSet(new BlockIdentifier[] { caseBlock, switchBlock });
/* 405:425 */             Op03SimpleStatement last = lastStatement;
/* 406:426 */             Op03SimpleStatement tgt = (Op03SimpleStatement)last.getTargets().get(0);
/* 407:427 */             InstrIndex moveTo = last.getIndex().justAfter();
/* 408:428 */             while ((tgt.getSources().size() == 1) && (tgt.getTargets().size() == 1) && (SetUtil.difference(lastStatement.getBlockIdentifiers(), tgt.getBlockIdentifiers()).equals(others)))
/* 409:    */             {
/* 410:429 */               tgt.setIndex(moveTo);
/* 411:430 */               moveTo = moveTo.justAfter();
/* 412:431 */               tgt.getBlockIdentifiers().addAll(others);
/* 413:432 */               last = tgt;
/* 414:433 */               tgt = (Op03SimpleStatement)last.getTargets().get(0);
/* 415:    */             }
/* 416:435 */             if ((last != lastStatement) && 
/* 417:436 */               (last.getStatement().getClass() != GotoStatement.class))
/* 418:    */             {
/* 419:440 */               Op03SimpleStatement newGoto = new Op03SimpleStatement(last.getBlockIdentifiers(), new GotoStatement(), moveTo);
/* 420:441 */               Op03SimpleStatement originalTgt = (Op03SimpleStatement)last.getTargets().get(0);
/* 421:442 */               last.replaceTarget(originalTgt, newGoto);
/* 422:443 */               originalTgt.replaceSource(last, newGoto);
/* 423:444 */               newGoto.addTarget(originalTgt);
/* 424:445 */               newGoto.addSource(last);
/* 425:446 */               statements.add(newGoto);
/* 426:    */             }
/* 427:    */           }
/* 428:    */         }
/* 429:    */       }
/* 430:    */     }
/* 431:456 */     Op03SimpleStatement lastCase = (Op03SimpleStatement)targets.get(targets.size() - 1);
/* 432:457 */     int indexLastCase = statements.indexOf(lastCase);
/* 433:458 */     int breakTarget = -1;
/* 434:459 */     BlockIdentifier caseBlock = null;
/* 435:460 */     int indexLastInThis = 0;
/* 436:461 */     boolean retieEnd = false;
/* 437:462 */     if (!forwardTargets.isEmpty())
/* 438:    */     {
/* 439:463 */       List<Op03SimpleStatement> lstFwdTargets = ListFactory.newList(forwardTargets);
/* 440:464 */       Collections.sort(lstFwdTargets, new CompareByIndex());
/* 441:465 */       Op03SimpleStatement afterCaseGuess = (Op03SimpleStatement)lstFwdTargets.get(0);
/* 442:466 */       int indexAfterCase = statements.indexOf(afterCaseGuess);
/* 443:    */       
/* 444:468 */       CaseStatement caseStatement = (CaseStatement)lastCase.getStatement();
/* 445:469 */       caseBlock = caseStatement.getCaseBlock();
/* 446:    */       try
/* 447:    */       {
/* 448:472 */         indexLastInThis = Misc.getFarthestReachableInRange(statements, indexLastCase, indexAfterCase);
/* 449:    */       }
/* 450:    */       catch (CannotPerformDecode e)
/* 451:    */       {
/* 452:474 */         forwardTargets.clear();
/* 453:    */       }
/* 454:476 */       if (indexLastInThis != indexAfterCase - 1) {
/* 455:477 */         retieEnd = true;
/* 456:    */       }
/* 457:    */     }
/* 458:480 */     if (forwardTargets.isEmpty())
/* 459:    */     {
/* 460:481 */       for (int y = idxFirstCase; y <= indexLastInLastBlock; y++)
/* 461:    */       {
/* 462:482 */         Op03SimpleStatement statement = (Op03SimpleStatement)statements.get(y);
/* 463:483 */         statement.markBlock(switchBlock);
/* 464:    */       }
/* 465:485 */       if (indexLastCase != indexLastInLastBlock + 1) {
/* 466:486 */         throw new ConfusedCFRException("Extractable last case doesn't follow previous");
/* 467:    */       }
/* 468:488 */       lastCase.markBlock(switchBlock);
/* 469:489 */       breakTarget = indexLastCase + 1;
/* 470:    */     }
/* 471:    */     else
/* 472:    */     {
/* 473:491 */       for (int y = indexLastCase + 1; y <= indexLastInThis; y++)
/* 474:    */       {
/* 475:492 */         Op03SimpleStatement statement = (Op03SimpleStatement)statements.get(y);
/* 476:493 */         statement.markBlock(caseBlock);
/* 477:    */       }
/* 478:495 */       for (int y = idxFirstCase; y <= indexLastInThis; y++)
/* 479:    */       {
/* 480:496 */         Op03SimpleStatement statement = (Op03SimpleStatement)statements.get(y);
/* 481:497 */         statement.markBlock(switchBlock);
/* 482:    */       }
/* 483:499 */       breakTarget = indexLastInThis + 1;
/* 484:    */     }
/* 485:501 */     Op03SimpleStatement breakStatementTarget = (Op03SimpleStatement)statements.get(breakTarget);
/* 486:503 */     if (retieEnd)
/* 487:    */     {
/* 488:504 */       Op03SimpleStatement lastInThis = (Op03SimpleStatement)statements.get(indexLastInThis);
/* 489:505 */       if (lastInThis.getStatement().getClass() == GotoStatement.class)
/* 490:    */       {
/* 491:507 */         Set<BlockIdentifier> blockIdentifiers = SetFactory.newSet(lastInThis.getBlockIdentifiers());
/* 492:508 */         blockIdentifiers.remove(caseBlock);
/* 493:509 */         blockIdentifiers.remove(switchBlock);
/* 494:510 */         Op03SimpleStatement retie = new Op03SimpleStatement(blockIdentifiers, new GotoStatement(), lastInThis.getIndex().justAfter());
/* 495:511 */         Op03SimpleStatement target = (Op03SimpleStatement)lastInThis.getTargets().get(0);
/* 496:512 */         Iterator<Op03SimpleStatement> iterator = target.getSources().iterator();
/* 497:513 */         while (iterator.hasNext())
/* 498:    */         {
/* 499:514 */           Op03SimpleStatement source = (Op03SimpleStatement)iterator.next();
/* 500:515 */           if (source.getBlockIdentifiers().contains(switchBlock))
/* 501:    */           {
/* 502:516 */             iterator.remove();
/* 503:517 */             retie.addSource(source);
/* 504:518 */             source.replaceTarget(target, retie);
/* 505:    */           }
/* 506:    */         }
/* 507:521 */         if (!retie.getSources().isEmpty())
/* 508:    */         {
/* 509:522 */           retie.addTarget(target);
/* 510:523 */           target.addSource(retie);
/* 511:524 */           statements.add(breakTarget, retie);
/* 512:525 */           breakStatementTarget = retie;
/* 513:    */         }
/* 514:    */       }
/* 515:    */     }
/* 516:536 */     if (breakStatementTarget.getBlockIdentifiers().contains(switchBlock)) {
/* 517:536 */       return true;
/* 518:    */     }
/* 519:542 */     Set<Op03SimpleStatement> sources = Misc.followNopGotoBackwards(breakStatementTarget);
/* 520:548 */     for (Op03SimpleStatement breakSource : sources) {
/* 521:549 */       if ((breakSource.getBlockIdentifiers().contains(switchBlock)) && 
/* 522:550 */         (breakSource.getJumpType().isUnknown()))
/* 523:    */       {
/* 524:554 */         JumpingStatement jumpingStatement = (JumpingStatement)breakSource.getStatement();
/* 525:    */         
/* 526:    */ 
/* 527:    */ 
/* 528:    */ 
/* 529:559 */         Op03SimpleStatement originalTarget = null;
/* 530:560 */         if (jumpingStatement.getClass() == IfStatement.class)
/* 531:    */         {
/* 532:561 */           if (breakSource.getTargets().size() != 2) {
/* 533:    */             continue;
/* 534:    */           }
/* 535:562 */           originalTarget = (Op03SimpleStatement)breakSource.getTargets().get(1);
/* 536:    */         }
/* 537:    */         else
/* 538:    */         {
/* 539:564 */           if (breakSource.getTargets().size() != 1) {
/* 540:    */             continue;
/* 541:    */           }
/* 542:565 */           originalTarget = (Op03SimpleStatement)breakSource.getTargets().get(0);
/* 543:    */         }
/* 544:567 */         if (originalTarget != breakStatementTarget)
/* 545:    */         {
/* 546:569 */           breakSource.replaceTarget(originalTarget, breakStatementTarget);
/* 547:570 */           originalTarget.removeSource(breakSource);
/* 548:571 */           breakStatementTarget.addSource(breakSource);
/* 549:    */         }
/* 550:574 */         ((JumpingStatement)breakSource.getStatement()).setJumpType(JumpType.BREAK);
/* 551:    */       }
/* 552:    */     }
/* 553:579 */     return true;
/* 554:    */   }
/* 555:    */   
/* 556:    */   private static void moveJumpsToCaseStatements(Op03SimpleStatement switchStatement, List<Op03SimpleStatement> statements)
/* 557:    */   {
/* 558:588 */     SwitchStatement switchStmt = (SwitchStatement)switchStatement.getStatement();
/* 559:589 */     BlockIdentifier switchBlock = switchStmt.getSwitchBlock();
/* 560:591 */     for (Op03SimpleStatement caseStatement : switchStatement.getTargets()) {
/* 561:593 */       if ((caseStatement.getStatement() instanceof CaseStatement))
/* 562:    */       {
/* 563:594 */         CaseStatement caseStmt = (CaseStatement)caseStatement.getStatement();
/* 564:595 */         if (switchBlock == caseStmt.getSwitchBlock())
/* 565:    */         {
/* 566:596 */           BlockIdentifier caseBlock = caseStmt.getCaseBlock();
/* 567:    */           
/* 568:598 */           Op03SimpleStatement target = (Op03SimpleStatement)caseStatement.getTargets().get(0);
/* 569:    */           
/* 570:600 */           Iterator<Op03SimpleStatement> targetSourceIt = target.getSources().iterator();
/* 571:601 */           while (targetSourceIt.hasNext())
/* 572:    */           {
/* 573:602 */             Op03SimpleStatement src = (Op03SimpleStatement)targetSourceIt.next();
/* 574:603 */             if (src != caseStatement)
/* 575:    */             {
/* 576:604 */               Set<BlockIdentifier> blockIdentifiers = src.getBlockIdentifiers();
/* 577:605 */               if ((!blockIdentifiers.contains(caseBlock)) && 
/* 578:606 */                 (blockIdentifiers.contains(switchBlock)))
/* 579:    */               {
/* 580:610 */                 targetSourceIt.remove();
/* 581:611 */                 src.replaceTarget(target, caseStatement);
/* 582:612 */                 caseStatement.addSource(src);
/* 583:    */               }
/* 584:    */             }
/* 585:    */           }
/* 586:    */         }
/* 587:    */       }
/* 588:    */     }
/* 589:    */   }
/* 590:    */   
/* 591:    */   private static void moveJumpsToTerminalIfEmpty(Op03SimpleStatement switchStatement, List<Op03SimpleStatement> statements)
/* 592:    */   {
/* 593:634 */     SwitchStatement swatch = (SwitchStatement)switchStatement.getStatement();
/* 594:635 */     Op03SimpleStatement lastTgt = (Op03SimpleStatement)switchStatement.getTargets().get(switchStatement.getTargets().size() - 1);
/* 595:636 */     BlockIdentifier switchBlock = swatch.getSwitchBlock();
/* 596:637 */     if (!lastTgt.getBlockIdentifiers().contains(switchBlock)) {
/* 597:637 */       return;
/* 598:    */     }
/* 599:638 */     if (lastTgt.getTargets().size() != 1) {
/* 600:638 */       return;
/* 601:    */     }
/* 602:639 */     if (lastTgt.getSources().size() == 1) {
/* 603:639 */       return;
/* 604:    */     }
/* 605:640 */     Op03SimpleStatement following = (Op03SimpleStatement)lastTgt.getTargets().get(0);
/* 606:642 */     if (following.getBlockIdentifiers().contains(switchBlock)) {
/* 607:642 */       return;
/* 608:    */     }
/* 609:645 */     List<Op03SimpleStatement> forwardJumpSources = Functional.filter(lastTgt.getSources(), new Misc.IsForwardJumpTo(lastTgt.getIndex()));
/* 610:646 */     if (forwardJumpSources.size() <= 1) {
/* 611:646 */       return;
/* 612:    */     }
/* 613:648 */     int idx = statements.indexOf(lastTgt);
/* 614:649 */     if (idx == 0) {
/* 615:649 */       return;
/* 616:    */     }
/* 617:650 */     Op03SimpleStatement justBefore = (Op03SimpleStatement)statements.get(idx - 1);
/* 618:651 */     if (idx >= statements.size() - 1) {
/* 619:651 */       return;
/* 620:    */     }
/* 621:652 */     if (statements.get(idx + 1) != following) {
/* 622:652 */       return;
/* 623:    */     }
/* 624:656 */     for (Op03SimpleStatement forwardJumpSource : forwardJumpSources) {
/* 625:657 */       if ((forwardJumpSource != switchStatement) && (forwardJumpSource != justBefore))
/* 626:    */       {
/* 627:659 */         forwardJumpSource.replaceTarget(lastTgt, following);
/* 628:660 */         lastTgt.removeSource(forwardJumpSource);
/* 629:661 */         following.addSource(forwardJumpSource);
/* 630:    */         
/* 631:    */ 
/* 632:    */ 
/* 633:    */ 
/* 634:666 */         Statement forwardJump = forwardJumpSource.getStatement();
/* 635:667 */         if ((forwardJump instanceof JumpingStatement))
/* 636:    */         {
/* 637:668 */           JumpingStatement jumpingStatement = (JumpingStatement)forwardJump;
/* 638:669 */           JumpType jumpType = jumpingStatement.getJumpType();
/* 639:670 */           if (jumpType.isUnknown()) {
/* 640:671 */             jumpingStatement.setJumpType(JumpType.BREAK);
/* 641:    */           }
/* 642:    */         }
/* 643:    */       }
/* 644:    */     }
/* 645:    */   }
/* 646:    */   
/* 647:    */   private static class NodeReachable
/* 648:    */     implements BinaryProcedure<Op03SimpleStatement, GraphVisitor<Op03SimpleStatement>>
/* 649:    */   {
/* 650:    */     private final Set<Op03SimpleStatement> otherCases;
/* 651:    */     private final Op03SimpleStatement switchStatement;
/* 652:    */     private final Op03SimpleStatement start;
/* 653:687 */     private final List<Op03SimpleStatement> reaches = ListFactory.newList();
/* 654:688 */     private final Set<Op03SimpleStatement> inBlock = SetFactory.newSet();
/* 655:    */     
/* 656:    */     private NodeReachable(Set<Op03SimpleStatement> otherCases, Op03SimpleStatement start, Op03SimpleStatement switchStatement)
/* 657:    */     {
/* 658:691 */       this.otherCases = otherCases;
/* 659:692 */       this.switchStatement = switchStatement;
/* 660:693 */       this.start = start;
/* 661:    */     }
/* 662:    */     
/* 663:    */     public void call(Op03SimpleStatement arg1, GraphVisitor<Op03SimpleStatement> arg2)
/* 664:    */     {
/* 665:698 */       if (arg1 == this.switchStatement) {
/* 666:699 */         return;
/* 667:    */       }
/* 668:701 */       if (arg1.getIndex().isBackJumpFrom(this.start)) {
/* 669:703 */         if (arg1.getIndex().isBackJumpFrom(this.switchStatement)) {
/* 670:703 */           return;
/* 671:    */         }
/* 672:    */       }
/* 673:705 */       if ((arg1 != this.start) && (this.otherCases.contains(arg1)))
/* 674:    */       {
/* 675:706 */         this.reaches.add(arg1);
/* 676:707 */         return;
/* 677:    */       }
/* 678:709 */       this.inBlock.add(arg1);
/* 679:710 */       arg2.enqueue(arg1.getTargets());
/* 680:    */     }
/* 681:    */   }
/* 682:    */   
/* 683:    */   public static void tidyOverExtendedDefault(List<Op03SimpleStatement> statements)
/* 684:    */   {
/* 685:721 */     List<Op03SimpleStatement> switchStatements = Functional.filter(statements, new TypeFilter(SwitchStatement.class));
/* 686:722 */     for (Op03SimpleStatement switchst : switchStatements) {
/* 687:723 */       switchStatement = (SwitchStatement)switchst.getStatement();
/* 688:    */     }
/* 689:    */     SwitchStatement switchStatement;
/* 690:    */   }
/* 691:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer
 * JD-Core Version:    0.7.0.1
 */