/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph;
/*   2:    */ 
/*   3:    */ import java.util.LinkedList;
/*   4:    */ 
/*   5:    */ public class InstrIndex
/*   6:    */   implements Comparable<InstrIndex>
/*   7:    */ {
/*   8:    */   private final int index;
/*   9:    */   private TempRelatives tempList;
/*  10:    */   
/*  11:    */   public InstrIndex(int index)
/*  12:    */   {
/*  13: 11 */     this.index = index;
/*  14:    */     
/*  15: 13 */     this.tempList = null;
/*  16:    */   }
/*  17:    */   
/*  18:    */   private InstrIndex(int index, TempRelatives tempList)
/*  19:    */   {
/*  20: 17 */     this.index = index;
/*  21: 18 */     this.tempList = tempList;
/*  22:    */   }
/*  23:    */   
/*  24:    */   private int idx()
/*  25:    */   {
/*  26: 22 */     if (this.tempList == null) {
/*  27: 22 */       return 0;
/*  28:    */     }
/*  29: 23 */     return this.tempList.indexOf(this);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public String toString()
/*  33:    */   {
/*  34: 28 */     int subidx = idx();
/*  35: 29 */     return "lbl" + this.index + (subidx == 0 ? "" : new StringBuilder().append(".").append(subidx).toString());
/*  36:    */   }
/*  37:    */   
/*  38:    */   public int compareTo(InstrIndex other)
/*  39:    */   {
/*  40: 34 */     int a = this.index - other.index;
/*  41: 35 */     if (a != 0) {
/*  42: 35 */       return a;
/*  43:    */     }
/*  44: 36 */     if (this.tempList != other.tempList) {
/*  45: 37 */       throw new IllegalStateException("Bad templists");
/*  46:    */     }
/*  47: 39 */     a = idx() - other.idx();
/*  48: 40 */     return a;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public boolean equals(Object o)
/*  52:    */   {
/*  53: 46 */     return super.equals(o);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public int hashCode()
/*  57:    */   {
/*  58: 51 */     return super.hashCode();
/*  59:    */   }
/*  60:    */   
/*  61:    */   private void mkTempList()
/*  62:    */   {
/*  63: 55 */     if (this.tempList == null) {
/*  64: 56 */       this.tempList = new TempRelatives(this);
/*  65:    */     }
/*  66:    */   }
/*  67:    */   
/*  68:    */   public InstrIndex justBefore()
/*  69:    */   {
/*  70: 61 */     mkTempList();
/*  71: 62 */     InstrIndex res = new InstrIndex(this.index, this.tempList);
/*  72: 63 */     this.tempList.before(this, res);
/*  73: 64 */     return res;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public InstrIndex justAfter()
/*  77:    */   {
/*  78: 68 */     mkTempList();
/*  79: 69 */     InstrIndex res = new InstrIndex(this.index, this.tempList);
/*  80: 70 */     this.tempList.after(this, res);
/*  81: 71 */     return res;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public boolean directlyPreceeds(InstrIndex other)
/*  85:    */   {
/*  86: 75 */     return this.index == other.index - 1;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public boolean isBackJumpTo(IndexedStatement other)
/*  90:    */   {
/*  91: 79 */     return isBackJumpTo(other.getIndex());
/*  92:    */   }
/*  93:    */   
/*  94:    */   public boolean isBackJumpTo(InstrIndex other)
/*  95:    */   {
/*  96: 83 */     return other.compareTo(this) < 0;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public boolean isBackJumpFrom(IndexedStatement other)
/* 100:    */   {
/* 101: 87 */     return !isBackJumpTo(other);
/* 102:    */   }
/* 103:    */   
/* 104:    */   public boolean isBackJumpFrom(InstrIndex other)
/* 105:    */   {
/* 106: 91 */     return !isBackJumpTo(other);
/* 107:    */   }
/* 108:    */   
/* 109:    */   private static class TempRelatives
/* 110:    */   {
/* 111: 96 */     private final LinkedList<InstrIndex> rels = new LinkedList();
/* 112:    */     
/* 113:    */     public TempRelatives(InstrIndex start)
/* 114:    */     {
/* 115: 99 */       this.rels.add(start);
/* 116:    */     }
/* 117:    */     
/* 118:    */     public int indexOf(InstrIndex i)
/* 119:    */     {
/* 120:103 */       return this.rels.indexOf(i);
/* 121:    */     }
/* 122:    */     
/* 123:    */     public void before(InstrIndex than, InstrIndex isBefore)
/* 124:    */     {
/* 125:107 */       int idx = this.rels.indexOf(than);
/* 126:108 */       this.rels.add(idx, isBefore);
/* 127:    */     }
/* 128:    */     
/* 129:    */     public void after(InstrIndex than, InstrIndex isBefore)
/* 130:    */     {
/* 131:112 */       int idx = this.rels.indexOf(than);
/* 132:113 */       this.rels.add(idx + 1, isBefore);
/* 133:    */     }
/* 134:    */   }
/* 135:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.InstrIndex
 * JD-Core Version:    0.7.0.1
 */