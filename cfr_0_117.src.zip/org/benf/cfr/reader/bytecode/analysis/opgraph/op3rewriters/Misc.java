/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Set;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.InstrIndex;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.ExpressionReplacingRewriter;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.NOPSearchingExpressionRewriter;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AssignmentExpression;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CaseStatement;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.IfStatement;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.JSRRetStatement;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.JumpingStatement;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.MonitorExitStatement;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.Nop;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.WhileStatement;
/*  26:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  27:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  28:    */ import org.benf.cfr.reader.util.CannotPerformDecode;
/*  29:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  30:    */ import org.benf.cfr.reader.util.Functional;
/*  31:    */ import org.benf.cfr.reader.util.ListFactory;
/*  32:    */ import org.benf.cfr.reader.util.MapFactory;
/*  33:    */ import org.benf.cfr.reader.util.Predicate;
/*  34:    */ import org.benf.cfr.reader.util.SetFactory;
/*  35:    */ import org.benf.cfr.reader.util.functors.BinaryProcedure;
/*  36:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  37:    */ import org.benf.cfr.reader.util.graph.GraphVisitor;
/*  38:    */ import org.benf.cfr.reader.util.graph.GraphVisitorDFS;
/*  39:    */ 
/*  40:    */ public class Misc
/*  41:    */ {
/*  42:    */   public static void flattenCompoundStatements(List<Op03SimpleStatement> statements)
/*  43:    */   {
/*  44: 28 */     List<Op03SimpleStatement> newStatements = ListFactory.newList();
/*  45: 29 */     for (Op03SimpleStatement statement : statements) {
/*  46: 30 */       if (statement.isCompound()) {
/*  47: 31 */         newStatements.addAll(statement.splitCompound());
/*  48:    */       }
/*  49:    */     }
/*  50: 34 */     statements.addAll(newStatements);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static class IsForwardJumpTo
/*  54:    */     implements Predicate<Op03SimpleStatement>
/*  55:    */   {
/*  56:    */     private final InstrIndex thisIndex;
/*  57:    */     
/*  58:    */     public IsForwardJumpTo(InstrIndex thisIndex)
/*  59:    */     {
/*  60: 41 */       this.thisIndex = thisIndex;
/*  61:    */     }
/*  62:    */     
/*  63:    */     public boolean test(Op03SimpleStatement in)
/*  64:    */     {
/*  65: 46 */       return this.thisIndex.isBackJumpTo(in);
/*  66:    */     }
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static class IsBackJumpTo
/*  70:    */     implements Predicate<Op03SimpleStatement>
/*  71:    */   {
/*  72:    */     private final InstrIndex thisIndex;
/*  73:    */     
/*  74:    */     public IsBackJumpTo(InstrIndex thisIndex)
/*  75:    */     {
/*  76: 55 */       this.thisIndex = thisIndex;
/*  77:    */     }
/*  78:    */     
/*  79:    */     public boolean test(Op03SimpleStatement in)
/*  80:    */     {
/*  81: 60 */       return this.thisIndex.isBackJumpFrom(in);
/*  82:    */     }
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static class HasBackJump
/*  86:    */     implements Predicate<Op03SimpleStatement>
/*  87:    */   {
/*  88:    */     public boolean test(Op03SimpleStatement in)
/*  89:    */     {
/*  90: 67 */       InstrIndex inIndex = in.getIndex();
/*  91: 68 */       List<Op03SimpleStatement> targets = in.getTargets();
/*  92: 69 */       for (Op03SimpleStatement target : targets) {
/*  93: 70 */         if (target.getIndex().compareTo(inIndex) <= 0)
/*  94:    */         {
/*  95: 71 */           Statement statement = in.getStatement();
/*  96: 72 */           if (!(statement instanceof JumpingStatement))
/*  97:    */           {
/*  98: 73 */             if (((statement instanceof JSRRetStatement)) || ((statement instanceof WhileStatement))) {
/*  99: 75 */               return false;
/* 100:    */             }
/* 101: 77 */             throw new ConfusedCFRException("Invalid back jump on " + statement);
/* 102:    */           }
/* 103: 79 */           return true;
/* 104:    */         }
/* 105:    */       }
/* 106: 83 */       return false;
/* 107:    */     }
/* 108:    */   }
/* 109:    */   
/* 110:    */   public static class GetBackJump
/* 111:    */     implements UnaryFunction<Op03SimpleStatement, Op03SimpleStatement>
/* 112:    */   {
/* 113:    */     public Op03SimpleStatement invoke(Op03SimpleStatement in)
/* 114:    */     {
/* 115: 90 */       InstrIndex inIndex = in.getIndex();
/* 116: 91 */       List<Op03SimpleStatement> targets = in.getTargets();
/* 117: 92 */       for (Op03SimpleStatement target : targets) {
/* 118: 93 */         if (target.getIndex().compareTo(inIndex) <= 0) {
/* 119: 94 */           return target;
/* 120:    */         }
/* 121:    */       }
/* 122: 97 */       throw new ConfusedCFRException("No back index.");
/* 123:    */     }
/* 124:    */   }
/* 125:    */   
/* 126:    */   private static class GraphVisitorReachableInThese
/* 127:    */     implements BinaryProcedure<Op03SimpleStatement, GraphVisitor<Op03SimpleStatement>>
/* 128:    */   {
/* 129:    */     private final Set<Integer> reachable;
/* 130:    */     private final Map<Op03SimpleStatement, Integer> instrToIdx;
/* 131:    */     
/* 132:    */     public GraphVisitorReachableInThese(Set<Integer> reachable, Map<Op03SimpleStatement, Integer> instrToIdx)
/* 133:    */     {
/* 134:107 */       this.reachable = reachable;
/* 135:108 */       this.instrToIdx = instrToIdx;
/* 136:    */     }
/* 137:    */     
/* 138:    */     public void call(Op03SimpleStatement node, GraphVisitor<Op03SimpleStatement> graphVisitor)
/* 139:    */     {
/* 140:113 */       Integer idx = (Integer)this.instrToIdx.get(node);
/* 141:114 */       if (idx == null) {
/* 142:114 */         return;
/* 143:    */       }
/* 144:115 */       this.reachable.add(idx);
/* 145:116 */       for (Op03SimpleStatement target : node.getTargets()) {
/* 146:117 */         graphVisitor.enqueue(target);
/* 147:    */       }
/* 148:    */     }
/* 149:    */   }
/* 150:    */   
/* 151:    */   public static int getFarthestReachableInRange(List<Op03SimpleStatement> statements, int start, int afterEnd)
/* 152:    */   {
/* 153:124 */     Map<Op03SimpleStatement, Integer> instrToIdx = MapFactory.newMap();
/* 154:125 */     for (int x = start; x < afterEnd; x++)
/* 155:    */     {
/* 156:126 */       Op03SimpleStatement statement = (Op03SimpleStatement)statements.get(x);
/* 157:127 */       instrToIdx.put(statement, Integer.valueOf(x));
/* 158:    */     }
/* 159:130 */     Set<Integer> reachableNodes = SetFactory.newSortedSet();
/* 160:131 */     GraphVisitorReachableInThese graphVisitorCallee = new GraphVisitorReachableInThese(reachableNodes, instrToIdx);
/* 161:132 */     GraphVisitor<Op03SimpleStatement> visitor = new GraphVisitorDFS(statements.get(start), graphVisitorCallee);
/* 162:133 */     visitor.process();
/* 163:    */     
/* 164:135 */     int first = start;
/* 165:136 */     int last = -1;
/* 166:137 */     boolean foundLast = false;
/* 167:139 */     for (int x = first; x < afterEnd; x++) {
/* 168:140 */       if ((reachableNodes.contains(Integer.valueOf(x))) || (((Op03SimpleStatement)statements.get(x)).isAgreedNop()))
/* 169:    */       {
/* 170:141 */         if (foundLast) {
/* 171:143 */           throw new CannotPerformDecode("reachable test BLOCK was exited and re-entered.");
/* 172:    */         }
/* 173:    */       }
/* 174:    */       else
/* 175:    */       {
/* 176:146 */         if (!foundLast) {
/* 177:147 */           last = x - 1;
/* 178:    */         }
/* 179:149 */         foundLast = true;
/* 180:    */       }
/* 181:    */     }
/* 182:152 */     if (last == -1) {
/* 183:152 */       last = afterEnd - 1;
/* 184:    */     }
/* 185:153 */     return last;
/* 186:    */   }
/* 187:    */   
/* 188:    */   public static Set<Op03SimpleStatement> followNopGotoBackwards(Op03SimpleStatement eventualtarget)
/* 189:    */   {
/* 190:161 */     Set<Op03SimpleStatement> result = SetFactory.newSet();
/* 191:    */     
/* 192:163 */     new GraphVisitorDFS(eventualtarget, new BinaryProcedure()
/* 193:    */     {
/* 194:    */       public void call(Op03SimpleStatement arg1, GraphVisitor<Op03SimpleStatement> arg2)
/* 195:    */       {
/* 196:166 */         for (Op03SimpleStatement source : arg1.getSources())
/* 197:    */         {
/* 198:167 */           Statement statement = source.getStatement();
/* 199:168 */           Class clazz = statement.getClass();
/* 200:169 */           if ((clazz == Nop.class) || (clazz == CaseStatement.class))
/* 201:    */           {
/* 202:171 */             arg2.enqueue(source);
/* 203:    */           }
/* 204:172 */           else if (clazz == GotoStatement.class)
/* 205:    */           {
/* 206:173 */             this.val$result.add(source);
/* 207:174 */             arg2.enqueue(source);
/* 208:    */           }
/* 209:175 */           else if ((clazz == IfStatement.class) && 
/* 210:176 */             (source.getTargets().size() == 2) && (source.getTargets().get(1) == arg2))
/* 211:    */           {
/* 212:178 */             this.val$result.add(source);
/* 213:    */           }
/* 214:    */         }
/* 215:    */       }
/* 216:184 */     }).process();
/* 217:185 */     return result;
/* 218:    */   }
/* 219:    */   
/* 220:    */   public static Op03SimpleStatement followNopGoto(Op03SimpleStatement in, boolean requireJustOneSource, boolean aggressive)
/* 221:    */   {
/* 222:190 */     if (in == null) {
/* 223:191 */       return null;
/* 224:    */     }
/* 225:193 */     if ((requireJustOneSource) && (in.getSources().size() != 1)) {
/* 226:193 */       return in;
/* 227:    */     }
/* 228:194 */     if (in.getTargets().size() != 1) {
/* 229:194 */       return in;
/* 230:    */     }
/* 231:195 */     Statement statement = in.getStatement();
/* 232:196 */     if (((statement instanceof Nop)) || ((statement instanceof GotoStatement)) || ((aggressive) && ((statement instanceof CaseStatement))) || ((aggressive) && ((statement instanceof MonitorExitStatement)))) {
/* 233:201 */       in = (Op03SimpleStatement)in.getTargets().get(0);
/* 234:    */     }
/* 235:203 */     return in;
/* 236:    */   }
/* 237:    */   
/* 238:    */   public static Op03SimpleStatement followNopGotoChain(Op03SimpleStatement in, boolean requireJustOneSource, boolean skipLabels)
/* 239:    */   {
/* 240:207 */     if (in == null) {
/* 241:207 */       return null;
/* 242:    */     }
/* 243:208 */     Set<Op03SimpleStatement> seen = SetFactory.newSet();
/* 244:    */     for (;;)
/* 245:    */     {
/* 246:210 */       if (!seen.add(in)) {
/* 247:210 */         return in;
/* 248:    */       }
/* 249:211 */       Op03SimpleStatement next = followNopGoto(in, requireJustOneSource, skipLabels);
/* 250:212 */       if (next == in) {
/* 251:212 */         return in;
/* 252:    */       }
/* 253:213 */       in = next;
/* 254:    */     }
/* 255:    */   }
/* 256:    */   
/* 257:    */   public static void markWholeBlock(List<Op03SimpleStatement> statements, BlockIdentifier blockIdentifier)
/* 258:    */   {
/* 259:218 */     Op03SimpleStatement start = (Op03SimpleStatement)statements.get(0);
/* 260:219 */     start.markFirstStatementInBlock(blockIdentifier);
/* 261:220 */     for (Op03SimpleStatement statement : statements) {
/* 262:221 */       statement.markBlock(blockIdentifier);
/* 263:    */     }
/* 264:    */   }
/* 265:    */   
/* 266:    */   public static boolean findHiddenIter(Statement statement, LValue lValue, Expression rValue, Set<Expression> poison)
/* 267:    */   {
/* 268:227 */     AssignmentExpression needle = new AssignmentExpression(lValue, rValue);
/* 269:228 */     NOPSearchingExpressionRewriter finder = new NOPSearchingExpressionRewriter(needle, poison);
/* 270:    */     
/* 271:230 */     statement.rewriteExpressions(finder, statement.getContainer().getSSAIdentifiers());
/* 272:231 */     return finder.isFound();
/* 273:    */   }
/* 274:    */   
/* 275:    */   public static void replaceHiddenIter(Statement statement, LValue lValue, Expression rValue)
/* 276:    */   {
/* 277:235 */     AssignmentExpression needle = new AssignmentExpression(lValue, rValue);
/* 278:236 */     ExpressionReplacingRewriter finder = new ExpressionReplacingRewriter(needle, new LValueExpression(lValue));
/* 279:    */     
/* 280:238 */     statement.rewriteExpressions(finder, statement.getContainer().getSSAIdentifiers());
/* 281:    */   }
/* 282:    */   
/* 283:    */   public static Op03SimpleStatement findSingleBackSource(Op03SimpleStatement start)
/* 284:    */   {
/* 285:242 */     List<Op03SimpleStatement> startSources = Functional.filter(start.getSources(), new IsForwardJumpTo(start.getIndex()));
/* 286:243 */     if (startSources.size() != 1) {
/* 287:244 */       return null;
/* 288:    */     }
/* 289:246 */     return (Op03SimpleStatement)startSources.get(0);
/* 290:    */   }
/* 291:    */   
/* 292:    */   public static BlockIdentifier findOuterBlock(BlockIdentifier b1, BlockIdentifier b2, List<Op03SimpleStatement> statements)
/* 293:    */   {
/* 294:251 */     for (Op03SimpleStatement s : statements)
/* 295:    */     {
/* 296:252 */       Set<BlockIdentifier> contained = s.getBlockIdentifiers();
/* 297:253 */       if (contained.contains(b1))
/* 298:    */       {
/* 299:254 */         if (!contained.contains(b2)) {
/* 300:255 */           return b1;
/* 301:    */         }
/* 302:    */       }
/* 303:257 */       else if (contained.contains(b2)) {
/* 304:258 */         return b2;
/* 305:    */       }
/* 306:    */     }
/* 307:264 */     return b1;
/* 308:    */   }
/* 309:    */   
/* 310:    */   public static class GraphVisitorBlockReachable
/* 311:    */     implements BinaryProcedure<Op03SimpleStatement, GraphVisitor<Op03SimpleStatement>>
/* 312:    */   {
/* 313:    */     private final Op03SimpleStatement start;
/* 314:    */     private final BlockIdentifier blockIdentifier;
/* 315:272 */     private final Set<Op03SimpleStatement> found = SetFactory.newSet();
/* 316:273 */     private final Set<Op03SimpleStatement> exits = SetFactory.newSet();
/* 317:    */     
/* 318:    */     private GraphVisitorBlockReachable(Op03SimpleStatement start, BlockIdentifier blockIdentifier)
/* 319:    */     {
/* 320:276 */       this.start = start;
/* 321:277 */       this.blockIdentifier = blockIdentifier;
/* 322:    */     }
/* 323:    */     
/* 324:    */     public void call(Op03SimpleStatement arg1, GraphVisitor<Op03SimpleStatement> arg2)
/* 325:    */     {
/* 326:282 */       if ((arg1 == this.start) || (arg1.getBlockIdentifiers().contains(this.blockIdentifier)))
/* 327:    */       {
/* 328:283 */         this.found.add(arg1);
/* 329:    */         Op03SimpleStatement target;
/* 330:284 */         for (Iterator i$ = arg1.getTargets().iterator(); i$.hasNext(); arg2.enqueue(target)) {
/* 331:284 */           target = (Op03SimpleStatement)i$.next();
/* 332:    */         }
/* 333:    */       }
/* 334:    */       else
/* 335:    */       {
/* 336:286 */         this.exits.add(arg1);
/* 337:    */       }
/* 338:    */     }
/* 339:    */     
/* 340:    */     public Set<Op03SimpleStatement> privGetBlockReachable()
/* 341:    */     {
/* 342:291 */       GraphVisitorDFS<Op03SimpleStatement> reachableInBlock = new GraphVisitorDFS(this.start, this);
/* 343:    */       
/* 344:    */ 
/* 345:    */ 
/* 346:295 */       reachableInBlock.process();
/* 347:296 */       return this.found;
/* 348:    */     }
/* 349:    */     
/* 350:    */     public static Set<Op03SimpleStatement> getBlockReachable(Op03SimpleStatement start, BlockIdentifier blockIdentifier)
/* 351:    */     {
/* 352:300 */       GraphVisitorBlockReachable r = new GraphVisitorBlockReachable(start, blockIdentifier);
/* 353:301 */       return r.privGetBlockReachable();
/* 354:    */     }
/* 355:    */     
/* 356:    */     public Pair<Set<Op03SimpleStatement>, Set<Op03SimpleStatement>> privGetBlockReachableAndExits()
/* 357:    */     {
/* 358:305 */       GraphVisitorDFS<Op03SimpleStatement> reachableInBlock = new GraphVisitorDFS(this.start, this);
/* 359:    */       
/* 360:    */ 
/* 361:    */ 
/* 362:309 */       reachableInBlock.process();
/* 363:310 */       return Pair.make(this.found, this.exits);
/* 364:    */     }
/* 365:    */     
/* 366:    */     public static Pair<Set<Op03SimpleStatement>, Set<Op03SimpleStatement>> getBlockReachableAndExits(Op03SimpleStatement start, BlockIdentifier blockIdentifier)
/* 367:    */     {
/* 368:314 */       GraphVisitorBlockReachable r = new GraphVisitorBlockReachable(start, blockIdentifier);
/* 369:315 */       return r.privGetBlockReachableAndExits();
/* 370:    */     }
/* 371:    */   }
/* 372:    */   
/* 373:    */   public static Set<Op03SimpleStatement> collectAllSources(Collection<Op03SimpleStatement> statements)
/* 374:    */   {
/* 375:322 */     Set<Op03SimpleStatement> result = SetFactory.newSet();
/* 376:323 */     for (Op03SimpleStatement statement : statements) {
/* 377:324 */       result.addAll(statement.getSources());
/* 378:    */     }
/* 379:326 */     return result;
/* 380:    */   }
/* 381:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc
 * JD-Core Version:    0.7.0.1
 */