/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*  2:   */ 
/*  3:   */ import java.util.Iterator;
/*  4:   */ import java.util.LinkedList;
/*  5:   */ import java.util.List;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.MiscStatementTools;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StaticVariable;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredAssignment;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredComment;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 14:   */ import org.benf.cfr.reader.entities.AccessFlag;
/* 15:   */ import org.benf.cfr.reader.entities.ClassFile;
/* 16:   */ import org.benf.cfr.reader.entities.ClassFileField;
/* 17:   */ import org.benf.cfr.reader.entities.Field;
/* 18:   */ import org.benf.cfr.reader.entities.Method;
/* 19:   */ import org.benf.cfr.reader.util.Functional;
/* 20:   */ import org.benf.cfr.reader.util.Predicate;
/* 21:   */ 
/* 22:   */ public class StaticLifter
/* 23:   */ {
/* 24:   */   private final ClassFile classFile;
/* 25:   */   
/* 26:   */   public StaticLifter(ClassFile classFile)
/* 27:   */   {
/* 28:26 */     this.classFile = classFile;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void liftStatics(Method staticInit)
/* 32:   */   {
/* 33:32 */     LinkedList<ClassFileField> classFileFields = new LinkedList(Functional.filter(this.classFile.getFields(), new Predicate()
/* 34:   */     {
/* 35:   */       public boolean test(ClassFileField in)
/* 36:   */       {
/* 37:35 */         if (!in.getField().testAccessFlag(AccessFlag.ACC_STATIC)) {
/* 38:35 */           return false;
/* 39:   */         }
/* 40:36 */         if (in.getField().testAccessFlag(AccessFlag.ACC_SYNTHETIC)) {
/* 41:36 */           return false;
/* 42:   */         }
/* 43:37 */         if (in.getInitialValue() != null) {
/* 44:37 */           return false;
/* 45:   */         }
/* 46:38 */         return true;
/* 47:   */       }
/* 48:   */     }));
/* 49:41 */     if (classFileFields.isEmpty()) {
/* 50:41 */       return;
/* 51:   */     }
/* 52:52 */     List<Op04StructuredStatement> statements = MiscStatementTools.getBlockStatements(staticInit.getAnalysis());
/* 53:53 */     if (statements == null) {
/* 54:53 */       return;
/* 55:   */     }
/* 56:58 */     Iterator<Op04StructuredStatement> iterator = statements.iterator();
/* 57:59 */     while (iterator.hasNext())
/* 58:   */     {
/* 59:60 */       Op04StructuredStatement statement = (Op04StructuredStatement)iterator.next();
/* 60:61 */       StructuredStatement structuredStatement = statement.getStatement();
/* 61:62 */       if (!(structuredStatement instanceof StructuredComment))
/* 62:   */       {
/* 63:63 */         if (!(structuredStatement instanceof StructuredAssignment)) {
/* 64:   */           break;
/* 65:   */         }
/* 66:65 */         StructuredAssignment assignment = (StructuredAssignment)structuredStatement;
/* 67:66 */         if (!liftStatic(assignment, classFileFields)) {
/* 68:66 */           return;
/* 69:   */         }
/* 70:   */       }
/* 71:   */     }
/* 72:   */   }
/* 73:   */   
/* 74:   */   private boolean liftStatic(StructuredAssignment assignment, LinkedList<ClassFileField> classFileFields)
/* 75:   */   {
/* 76:71 */     LValue lValue = assignment.getLvalue();
/* 77:72 */     if (!(lValue instanceof StaticVariable)) {
/* 78:72 */       return false;
/* 79:   */     }
/* 80:73 */     StaticVariable fieldVariable = (StaticVariable)lValue;
/* 81:   */     ClassFileField field;
/* 82:   */     try
/* 83:   */     {
/* 84:76 */       field = this.classFile.getFieldByName(fieldVariable.getFieldName(), fieldVariable.getInferredJavaType().getJavaTypeInstance());
/* 85:   */     }
/* 86:   */     catch (NoSuchFieldException e)
/* 87:   */     {
/* 88:78 */       return false;
/* 89:   */     }
/* 90:80 */     if (classFileFields.isEmpty()) {
/* 91:80 */       return false;
/* 92:   */     }
/* 93:81 */     if (field != classFileFields.getFirst()) {
/* 94:81 */       return false;
/* 95:   */     }
/* 96:82 */     classFileFields.removeFirst();
/* 97:85 */     if (field.getInitialValue() != null) {
/* 98:85 */       return false;
/* 99:   */     }
/* :0:87 */     field.setInitialValue(assignment.getRvalue());
/* :1:88 */     assignment.getContainer().nopOut();
/* :2:89 */     return true;
/* :3:   */   }
/* :4:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.StaticLifter
 * JD-Core Version:    0.7.0.1
 */