/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.MiscStatementTools;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.NewAnonymousArray;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface.FunctionProcessor;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.GenericTypeBinder;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  21:    */ import org.benf.cfr.reader.entities.classfilehelpers.OverloadMethodSet;
/*  22:    */ import org.benf.cfr.reader.util.ListFactory;
/*  23:    */ 
/*  24:    */ public class VarArgsRewriter
/*  25:    */   implements Op04Rewriter, ExpressionRewriter
/*  26:    */ {
/*  27:    */   public void rewrite(Op04StructuredStatement root)
/*  28:    */   {
/*  29: 30 */     List<StructuredStatement> structuredStatements = MiscStatementTools.linearise(root);
/*  30: 31 */     if (structuredStatements == null) {
/*  31: 31 */       return;
/*  32:    */     }
/*  33: 40 */     for (StructuredStatement statement : structuredStatements) {
/*  34: 41 */       statement.rewriteExpressions(this);
/*  35:    */     }
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void handleStatement(StatementContainer statementContainer) {}
/*  39:    */   
/*  40:    */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  41:    */   {
/*  42: 54 */     if ((expression instanceof FunctionProcessor)) {
/*  43: 55 */       ((FunctionProcessor)expression).rewriteVarArgs(this);
/*  44:    */     }
/*  45: 57 */     return expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public ConditionalExpression rewriteExpression(ConditionalExpression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  49:    */   {
/*  50: 62 */     Expression res = expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/*  51: 63 */     return (ConditionalExpression)res;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  55:    */   {
/*  56: 74 */     return lValue;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public StackSSALabel rewriteExpression(StackSSALabel lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  60:    */   {
/*  61: 79 */     return lValue;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void rewriteVarArgsArg(OverloadMethodSet overloadMethodSet, MethodPrototype methodPrototype, List<Expression> args, GenericTypeBinder gtb)
/*  65:    */   {
/*  66: 83 */     if (!methodPrototype.isVarArgs()) {
/*  67: 83 */       return;
/*  68:    */     }
/*  69: 84 */     if (args.size() != methodPrototype.getArgs().size()) {
/*  70: 84 */       return;
/*  71:    */     }
/*  72: 85 */     int last = args.size() - 1;
/*  73: 86 */     Expression lastArg = (Expression)args.get(args.size() - 1);
/*  74: 87 */     if (!(lastArg instanceof NewAnonymousArray)) {
/*  75: 87 */       return;
/*  76:    */     }
/*  77: 88 */     List<Expression> args2 = ListFactory.newList(args);
/*  78: 89 */     args2.remove(last);
/*  79: 90 */     NewAnonymousArray newAnonymousArray = (NewAnonymousArray)lastArg;
/*  80:    */     
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84: 95 */     List<Expression> anonVals = newAnonymousArray.getValues();
/*  85: 96 */     if (anonVals.size() == 1)
/*  86:    */     {
/*  87: 97 */       Literal nullLit = new Literal(TypedLiteral.getNull());
/*  88: 98 */       if (((Expression)anonVals.get(0)).equals(nullLit)) {
/*  89: 98 */         return;
/*  90:    */       }
/*  91:    */     }
/*  92:101 */     args2.addAll(newAnonymousArray.getValues());
/*  93:102 */     boolean correct = overloadMethodSet.callsCorrectEntireMethod(args2, gtb);
/*  94:103 */     if (correct)
/*  95:    */     {
/*  96:104 */       args.clear();
/*  97:105 */       args.addAll(args2);
/*  98:    */     }
/*  99:107 */     int x = 1;
/* 100:    */   }
/* 101:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.VarArgsRewriter
 * JD-Core Version:    0.7.0.1
 */