/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*  2:   */ 
/*  3:   */ import java.util.Set;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.AbstractExpressionRewriter;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  9:   */ 
/* 10:   */ public class NOPSearchingExpressionRewriter
/* 11:   */   extends AbstractExpressionRewriter
/* 12:   */ {
/* 13:   */   private final Expression needle;
/* 14:   */   private final Set<Expression> poison;
/* 15:15 */   transient boolean found = false;
/* 16:16 */   transient boolean poisoned = false;
/* 17:   */   
/* 18:   */   public NOPSearchingExpressionRewriter(Expression needle, Set<Expression> poison)
/* 19:   */   {
/* 20:19 */     this.needle = needle;
/* 21:20 */     this.poison = poison;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 25:   */   {
/* 26:25 */     if ((!this.found) && 
/* 27:26 */       (this.needle.equals(expression)))
/* 28:   */     {
/* 29:27 */       this.found = true;
/* 30:28 */       return expression;
/* 31:   */     }
/* 32:31 */     if (this.poison.contains(expression)) {
/* 33:32 */       this.poisoned = true;
/* 34:   */     }
/* 35:34 */     return expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 36:   */   }
/* 37:   */   
/* 38:   */   public boolean isFound()
/* 39:   */   {
/* 40:38 */     return (this.found) && (!this.poisoned);
/* 41:   */   }
/* 42:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.NOPSearchingExpressionRewriter
 * JD-Core Version:    0.7.0.1
 */