/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  4:   */ 
/*  5:   */ public class MatchOneOf
/*  6:   */   implements Matcher<StructuredStatement>
/*  7:   */ {
/*  8:   */   private final Matcher<StructuredStatement>[] matchers;
/*  9:   */   
/* 10:   */   public MatchOneOf(Matcher<StructuredStatement>... matchers)
/* 11:   */   {
/* 12:13 */     this.matchers = matchers;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 16:   */   {
/* 17:19 */     for (Matcher<StructuredStatement> matcher : this.matchers)
/* 18:   */     {
/* 19:20 */       MatchIterator<StructuredStatement> mi = matchIterator.copy();
/* 20:21 */       if (matcher.match(mi, matchResultCollector))
/* 21:   */       {
/* 22:22 */         matchIterator.advanceTo(mi);
/* 23:23 */         return true;
/* 24:   */       }
/* 25:   */     }
/* 26:26 */     return false;
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchOneOf
 * JD-Core Version:    0.7.0.1
 */