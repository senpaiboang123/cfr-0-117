/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters;
/*   2:    */ 
/*   3:    */ import java.util.Iterator;
/*   4:    */ import java.util.List;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*   8:    */ import org.benf.cfr.reader.bytecode.opcode.JVMInstr;
/*   9:    */ 
/*  10:    */ public class Op02RedundantStoreRewriter
/*  11:    */ {
/*  12: 12 */   private static final Op02RedundantStoreRewriter INSTANCE = new Op02RedundantStoreRewriter();
/*  13:    */   
/*  14:    */   private void rewriteInstrs(List<Op02WithProcessedDataAndRefs> instrs, int maxLocals)
/*  15:    */   {
/*  16: 51 */     int[] laststore = new int[maxLocals];
/*  17: 52 */     int[] lastload = new int[maxLocals];
/*  18: 53 */     int[] loadsSinceStore = new int[maxLocals];
/*  19: 54 */     int lastCutOff = 0;
/*  20: 55 */     int nopCount = 0;
/*  21: 56 */     int x = 0;
/*  22: 56 */     for (int maxm1 = instrs.size() - 1; x < maxm1; x++)
/*  23:    */     {
/*  24: 57 */       Op02WithProcessedDataAndRefs instr = (Op02WithProcessedDataAndRefs)instrs.get(x);
/*  25: 58 */       List<Op02WithProcessedDataAndRefs> targets = instr.getTargets();
/*  26: 59 */       List<Op02WithProcessedDataAndRefs> sources = instr.getSources();
/*  27: 60 */       if ((sources.size() != 1) || (targets.size() != 1) || (targets.get(0) != instrs.get(x + 1)) || (!instr.getContainedInTheseBlocks().isEmpty()))
/*  28:    */       {
/*  29: 61 */         lastCutOff = x;
/*  30:    */       }
/*  31:    */       else
/*  32:    */       {
/*  33: 64 */         JVMInstr jvmInstr = instr.getInstr();
/*  34: 65 */         Pair<JavaTypeInstance, Integer> stored = instr.getStorageType();
/*  35: 70 */         if (stored != null)
/*  36:    */         {
/*  37: 71 */           if ((jvmInstr == JVMInstr.IINC) || (jvmInstr == JVMInstr.IINC_WIDE))
/*  38:    */           {
/*  39: 73 */             lastCutOff = x;
/*  40:    */           }
/*  41:    */           else
/*  42:    */           {
/*  43: 76 */             int storeidx = ((Integer)stored.getSecond()).intValue();
/*  44: 81 */             if ((laststore[storeidx] > lastCutOff) && (lastload[storeidx] > lastCutOff) && (loadsSinceStore[storeidx] == 1))
/*  45:    */             {
/*  46: 82 */               int lastloadidx = lastload[storeidx];
/*  47: 83 */               int laststoreidx = laststore[storeidx];
/*  48: 84 */               if (lastloadidx == laststoreidx + 1)
/*  49:    */               {
/*  50: 85 */                 ((Op02WithProcessedDataAndRefs)instrs.get(laststoreidx)).nop();
/*  51: 86 */                 ((Op02WithProcessedDataAndRefs)instrs.get(lastloadidx)).nop();
/*  52: 87 */                 nopCount += 2;
/*  53:    */               }
/*  54: 88 */               else if (lastloadidx == laststoreidx + 2)
/*  55:    */               {
/*  56: 89 */                 ((Op02WithProcessedDataAndRefs)instrs.get(laststoreidx)).nop();
/*  57: 90 */                 ((Op02WithProcessedDataAndRefs)instrs.get(lastloadidx)).swap();
/*  58: 91 */                 nopCount++;
/*  59:    */               }
/*  60:    */             }
/*  61: 95 */             laststore[storeidx] = x;
/*  62: 96 */             loadsSinceStore[storeidx] = 0;
/*  63:    */           }
/*  64:    */         }
/*  65:    */         else
/*  66:    */         {
/*  67: 99 */           Pair<JavaTypeInstance, Integer> fetched = instr.getRetrieveType();
/*  68:100 */           if (fetched != null)
/*  69:    */           {
/*  70:101 */             int fetchidx = ((Integer)fetched.getSecond()).intValue();
/*  71:102 */             if (laststore[fetchidx] <= lastCutOff) {
/*  72:102 */               loadsSinceStore[fetchidx] = 0;
/*  73:    */             }
/*  74:103 */             loadsSinceStore[fetchidx] += 1;
/*  75:104 */             lastload[fetchidx] = x;
/*  76:    */           }
/*  77:    */         }
/*  78:    */       }
/*  79:    */     }
/*  80:108 */     if (nopCount > 0)
/*  81:    */     {
/*  82:109 */       Iterator<Op02WithProcessedDataAndRefs> iterator = instrs.iterator();
/*  83:110 */       iterator.next();
/*  84:111 */       while (iterator.hasNext())
/*  85:    */       {
/*  86:112 */         Op02WithProcessedDataAndRefs instr = (Op02WithProcessedDataAndRefs)iterator.next();
/*  87:113 */         if (instr.getInstr() == JVMInstr.NOP)
/*  88:    */         {
/*  89:114 */           List<Op02WithProcessedDataAndRefs> targets = instr.getTargets();
/*  90:115 */           if (targets.size() == 1)
/*  91:    */           {
/*  92:116 */             Op02WithProcessedDataAndRefs target = (Op02WithProcessedDataAndRefs)targets.get(0);
/*  93:117 */             targets.clear();
/*  94:118 */             target.removeSource(instr);
/*  95:119 */             List<Op02WithProcessedDataAndRefs> sources = instr.getSources();
/*  96:120 */             for (Op02WithProcessedDataAndRefs source : sources)
/*  97:    */             {
/*  98:121 */               source.replaceTarget(instr, target);
/*  99:122 */               target.addSource(source);
/* 100:    */             }
/* 101:124 */             iterator.remove();
/* 102:    */           }
/* 103:    */         }
/* 104:    */       }
/* 105:    */     }
/* 106:    */   }
/* 107:    */   
/* 108:    */   public static void rewrite(List<Op02WithProcessedDataAndRefs> instrs, int maxLocals)
/* 109:    */   {
/* 110:132 */     INSTANCE.rewriteInstrs(instrs, maxLocals);
/* 111:    */   }
/* 112:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters.Op02RedundantStoreRewriter
 * JD-Core Version:    0.7.0.1
 */