/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.AbstractExpressionRewriter;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 11:   */ 
/* 12:   */ public class NullTypedLValueRewriter
/* 13:   */   extends AbstractExpressionRewriter
/* 14:   */ {
/* 15:   */   public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 16:   */   {
/* 17:15 */     InferredJavaType inferredJavaType = lValue.getInferredJavaType();
/* 18:16 */     JavaTypeInstance javaTypeInstance = inferredJavaType.getJavaTypeInstance();
/* 19:17 */     if ((javaTypeInstance == RawJavaType.NULL) || (javaTypeInstance == RawJavaType.VOID)) {
/* 20:18 */       inferredJavaType.applyKnownBaseType();
/* 21:   */     }
/* 22:20 */     return lValue;
/* 23:   */   }
/* 24:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.NullTypedLValueRewriter
 * JD-Core Version:    0.7.0.1
 */