/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Map;
/*   5:    */ import java.util.Map.Entry;
/*   6:    */ import java.util.Set;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.AbstractMatchResultIterator;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.CollectMatch;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.KleenePlus;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchOneOf;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchSequence;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.Matcher;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.ResetAfterTest;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractConstructorInvokation;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractNewArray;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationAnonymousInner;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationSimple;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.NewAnonymousArray;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  26:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StaticVariable;
/*  27:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  28:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.QuotingUtils;
/*  29:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
/*  30:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.ConstructorInvokationAnonymousInnerWildcard;
/*  31:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.ConstructorInvokationSimpleWildcard;
/*  32:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.NewArrayWildcard;
/*  33:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.StaticVariableWildcard;
/*  34:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  35:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredAssignment;
/*  36:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredComment;
/*  37:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.BeginBlock;
/*  38:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaArrayTypeInstance;
/*  39:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericRefTypeInstance;
/*  40:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  41:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  42:    */ import org.benf.cfr.reader.bytecode.analysis.types.TypeConstants;
/*  43:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  44:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  45:    */ import org.benf.cfr.reader.entities.AccessFlag;
/*  46:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  47:    */ import org.benf.cfr.reader.entities.ClassFileField;
/*  48:    */ import org.benf.cfr.reader.entities.Field;
/*  49:    */ import org.benf.cfr.reader.entities.Method;
/*  50:    */ import org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumperEnum;
/*  51:    */ import org.benf.cfr.reader.state.DCCommonState;
/*  52:    */ import org.benf.cfr.reader.util.ClassFileVersion;
/*  53:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  54:    */ import org.benf.cfr.reader.util.Functional;
/*  55:    */ import org.benf.cfr.reader.util.ListFactory;
/*  56:    */ import org.benf.cfr.reader.util.MapFactory;
/*  57:    */ import org.benf.cfr.reader.util.Predicate;
/*  58:    */ import org.benf.cfr.reader.util.SetFactory;
/*  59:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  60:    */ import org.benf.cfr.reader.util.getopt.Options;
/*  61:    */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*  62:    */ import org.benf.cfr.reader.util.output.IllegalIdentifierReplacement;
/*  63:    */ 
/*  64:    */ public class EnumClassRewriter
/*  65:    */ {
/*  66:    */   private final ClassFile classFile;
/*  67:    */   private final JavaTypeInstance classType;
/*  68:    */   private final DCCommonState state;
/*  69:    */   private final InferredJavaType clazzIJT;
/*  70:    */   private final Options options;
/*  71:    */   
/*  72:    */   public static void rewriteEnumClass(ClassFile classFile, DCCommonState state)
/*  73:    */   {
/*  74: 37 */     Options options = state.getOptions();
/*  75: 38 */     ClassFileVersion classFileVersion = classFile.getClassFileVersion();
/*  76: 40 */     if (!((Boolean)options.getOption(OptionsImpl.ENUM_SUGAR, classFileVersion)).booleanValue()) {
/*  77: 40 */       return;
/*  78:    */     }
/*  79: 42 */     JavaTypeInstance classType = classFile.getClassType();
/*  80: 43 */     JavaTypeInstance baseType = classFile.getBaseClassType();
/*  81:    */     
/*  82: 45 */     JavaTypeInstance enumType = TypeConstants.ENUM;
/*  83: 47 */     if (!baseType.equals(enumType))
/*  84:    */     {
/*  85: 48 */       if (!(baseType instanceof JavaGenericRefTypeInstance)) {
/*  86: 48 */         return;
/*  87:    */       }
/*  88: 49 */       JavaGenericRefTypeInstance genericBaseType = (JavaGenericRefTypeInstance)baseType;
/*  89: 50 */       if (!genericBaseType.getDeGenerifiedType().equals(enumType)) {
/*  90: 50 */         return;
/*  91:    */       }
/*  92: 52 */       List<JavaTypeInstance> boundTypes = genericBaseType.getGenericTypes();
/*  93: 53 */       if ((boundTypes == null) || (boundTypes.size() != 1)) {
/*  94: 53 */         return;
/*  95:    */       }
/*  96: 54 */       if (!((JavaTypeInstance)boundTypes.get(0)).equals(classType)) {
/*  97: 54 */         return;
/*  98:    */       }
/*  99:    */     }
/* 100: 57 */     EnumClassRewriter c = new EnumClassRewriter(classFile, classType, state);
/* 101: 58 */     c.rewrite();
/* 102:    */   }
/* 103:    */   
/* 104:    */   public EnumClassRewriter(ClassFile classFile, JavaTypeInstance classType, DCCommonState state)
/* 105:    */   {
/* 106: 69 */     this.classFile = classFile;
/* 107: 70 */     this.classType = classType;
/* 108: 71 */     this.state = state;
/* 109: 72 */     this.options = state.getOptions();
/* 110: 73 */     this.clazzIJT = new InferredJavaType(classType, InferredJavaType.Source.UNKNOWN, true);
/* 111:    */   }
/* 112:    */   
/* 113:    */   private boolean rewrite()
/* 114:    */   {
/* 115: 84 */     Method staticInit = null;
/* 116:    */     try
/* 117:    */     {
/* 118: 86 */       staticInit = (Method)this.classFile.getMethodByName("<clinit>").get(0);
/* 119:    */     }
/* 120:    */     catch (NoSuchMethodException e)
/* 121:    */     {
/* 122: 89 */       throw new ConfusedCFRException("No static init method on enum");
/* 123:    */     }
/* 124: 92 */     Op04StructuredStatement staticInitCode = staticInit.getAnalysis();
/* 125: 93 */     if (!staticInitCode.isFullyStructured()) {
/* 126: 93 */       return false;
/* 127:    */     }
/* 128: 94 */     EnumInitMatchCollector initMatchCollector = analyseStaticMethod(staticInitCode);
/* 129: 95 */     if (initMatchCollector == null) {
/* 130: 95 */       return false;
/* 131:    */     }
/* 132:100 */     Method valueOf = null;
/* 133:101 */     Method values = null;
/* 134:    */     try
/* 135:    */     {
/* 136:103 */       valueOf = (Method)this.classFile.getMethodByName("valueOf").get(0);
/* 137:104 */       values = (Method)this.classFile.getMethodByName("values").get(0);
/* 138:    */     }
/* 139:    */     catch (NoSuchMethodException e)
/* 140:    */     {
/* 141:106 */       return false;
/* 142:    */     }
/* 143:108 */     valueOf.hideSynthetic();
/* 144:109 */     values.hideSynthetic();
/* 145:110 */     for (ClassFileField field : initMatchCollector.getMatchedHideTheseFields()) {
/* 146:111 */       field.markHidden();
/* 147:    */     }
/* 148:114 */     Map<StaticVariable, CollectedEnumData<? extends AbstractConstructorInvokation>> entryMap = initMatchCollector.getEntryMap();
/* 149:115 */     CollectedEnumData<NewAnonymousArray> matchedArray = initMatchCollector.getMatchedArray();
/* 150:119 */     for (CollectedEnumData<?> entry : entryMap.values()) {
/* 151:120 */       entry.getContainer().nopOut();
/* 152:    */     }
/* 153:122 */     matchedArray.getContainer().nopOut();
/* 154:    */     
/* 155:    */ 
/* 156:    */ 
/* 157:    */ 
/* 158:127 */     List<Method> constructors = this.classFile.getConstructors();
/* 159:128 */     EnumSuperRewriter enumSuperRewriter = new EnumSuperRewriter();
/* 160:129 */     for (Method constructor : constructors) {
/* 161:130 */       enumSuperRewriter.rewrite(constructor.getAnalysis());
/* 162:    */     }
/* 163:133 */     List<Pair<StaticVariable, AbstractConstructorInvokation>> entries = ListFactory.newList();
/* 164:134 */     for (Map.Entry<StaticVariable, CollectedEnumData<? extends AbstractConstructorInvokation>> entry : entryMap.entrySet()) {
/* 165:135 */       entries.add(Pair.make(entry.getKey(), ((CollectedEnumData)entry.getValue()).getData()));
/* 166:    */     }
/* 167:137 */     this.classFile.setDumpHelper(new ClassFileDumperEnum(this.state, entries));
/* 168:    */     
/* 169:    */ 
/* 170:    */ 
/* 171:    */ 
/* 172:    */ 
/* 173:143 */     boolean rename_members = ((Boolean)this.options.getOption(OptionsImpl.RENAME_ENUM_MEMBERS)).booleanValue();
/* 174:    */     Set<String> fieldNames;
/* 175:145 */     if (rename_members)
/* 176:    */     {
/* 177:147 */       fieldNames = SetFactory.newSet(Functional.map(this.classFile.getFields(), new UnaryFunction()
/* 178:    */       {
/* 179:    */         public String invoke(ClassFileField arg)
/* 180:    */         {
/* 181:150 */           return arg.getFieldName();
/* 182:    */         }
/* 183:153 */       }));
/* 184:154 */       List<Pair<StaticVariable, String>> renames = ListFactory.newList();
/* 185:156 */       for (Pair<StaticVariable, AbstractConstructorInvokation> entry : entries)
/* 186:    */       {
/* 187:157 */         StaticVariable sv = (StaticVariable)entry.getFirst();
/* 188:158 */         AbstractConstructorInvokation aci = (AbstractConstructorInvokation)entry.getSecond();
/* 189:159 */         String name = sv.getFieldName();
/* 190:    */         
/* 191:    */ 
/* 192:    */ 
/* 193:    */ 
/* 194:164 */         Expression expectedNameExp = (Expression)aci.getArgs().get(0);
/* 195:165 */         String expectedName = name;
/* 196:166 */         if ((expectedNameExp.getInferredJavaType().getJavaTypeInstance() == TypeConstants.STRING) && 
/* 197:167 */           ((expectedNameExp instanceof Literal)))
/* 198:    */         {
/* 199:168 */           Object expectedValue = ((Literal)expectedNameExp).getValue().getValue();
/* 200:169 */           if ((expectedValue instanceof String)) {
/* 201:170 */             expectedName = QuotingUtils.unquoteString((String)expectedValue);
/* 202:    */           }
/* 203:    */         }
/* 204:175 */         if ((!name.equals(expectedName)) && 
/* 205:176 */           (!IllegalIdentifierReplacement.isIllegal(expectedName))) {
/* 206:177 */           renames.add(Pair.make(sv, expectedName));
/* 207:    */         }
/* 208:    */       }
/* 209:182 */       for (Pair<StaticVariable, String> rename : renames)
/* 210:    */       {
/* 211:183 */         String newName = (String)rename.getSecond();
/* 212:184 */         StaticVariable sv = (StaticVariable)rename.getFirst();
/* 213:185 */         if (fieldNames.contains(newName))
/* 214:    */         {
/* 215:186 */           this.classFile.addComment("Tried to rename field '" + sv.getFieldName() + "' to '" + newName + "' but it's alread used.");
/* 216:    */         }
/* 217:    */         else
/* 218:    */         {
/* 219:189 */           fieldNames.remove(sv.getFieldName());
/* 220:190 */           fieldNames.add(newName);
/* 221:191 */           sv.getClassFileField().overrideName(newName);
/* 222:    */         }
/* 223:    */       }
/* 224:    */     }
/* 225:195 */     return true;
/* 226:    */   }
/* 227:    */   
/* 228:    */   private EnumInitMatchCollector analyseStaticMethod(Op04StructuredStatement statement)
/* 229:    */   {
/* 230:203 */     List<StructuredStatement> statements = ListFactory.newList();
/* 231:204 */     statement.linearizeStatementsInto(statements);
/* 232:    */     
/* 233:    */ 
/* 234:207 */     statements = Functional.filter(statements, new Predicate()
/* 235:    */     {
/* 236:    */       public boolean test(StructuredStatement in)
/* 237:    */       {
/* 238:210 */         return !(in instanceof StructuredComment);
/* 239:    */       }
/* 240:213 */     });
/* 241:214 */     WildcardMatch wcm = new WildcardMatch();
/* 242:    */     
/* 243:216 */     InferredJavaType clazzIJT = new InferredJavaType(this.classType, InferredJavaType.Source.UNKNOWN, true);
/* 244:217 */     JavaTypeInstance arrayType = new JavaArrayTypeInstance(1, this.classType);
/* 245:218 */     InferredJavaType clazzAIJT = new InferredJavaType(arrayType, InferredJavaType.Source.UNKNOWN, true);
/* 246:219 */     Matcher<StructuredStatement> matcher = new MatchSequence(new Matcher[] { new BeginBlock(null), new KleenePlus(new MatchOneOf(new Matcher[] { new ResetAfterTest(wcm, new CollectMatch("entry", new StructuredAssignment(wcm.getStaticVariable("e", this.classType, clazzIJT), wcm.getConstructorSimpleWildcard("c", this.classType)))), new ResetAfterTest(wcm, new CollectMatch("entryderived", new StructuredAssignment(wcm.getStaticVariable("e2", this.classType, clazzIJT, false), wcm.getConstructorAnonymousWildcard("c2", null)))) })), new ResetAfterTest(wcm, new CollectMatch("values", new StructuredAssignment(wcm.getStaticVariable("v", this.classType, clazzAIJT), wcm.getNewArrayWildCard("v", 0, Integer.valueOf(1))))) });
/* 247:    */     
/* 248:    */ 
/* 249:    */ 
/* 250:    */ 
/* 251:    */ 
/* 252:    */ 
/* 253:    */ 
/* 254:    */ 
/* 255:    */ 
/* 256:    */ 
/* 257:230 */     MatchIterator<StructuredStatement> mi = new MatchIterator(statements);
/* 258:231 */     EnumInitMatchCollector matchCollector = new EnumInitMatchCollector(wcm, null);
/* 259:    */     
/* 260:233 */     mi.advance();
/* 261:234 */     if (!matcher.match(mi, matchCollector)) {
/* 262:235 */       return null;
/* 263:    */     }
/* 264:238 */     if (!matchCollector.isValid()) {
/* 265:238 */       return null;
/* 266:    */     }
/* 267:239 */     return matchCollector;
/* 268:    */   }
/* 269:    */   
/* 270:    */   private static class CollectedEnumData<T>
/* 271:    */   {
/* 272:    */     private final Op04StructuredStatement container;
/* 273:    */     private final T data;
/* 274:    */     
/* 275:    */     private CollectedEnumData(Op04StructuredStatement container, T data)
/* 276:    */     {
/* 277:247 */       this.container = container;
/* 278:248 */       this.data = data;
/* 279:    */     }
/* 280:    */     
/* 281:    */     private Op04StructuredStatement getContainer()
/* 282:    */     {
/* 283:252 */       return this.container;
/* 284:    */     }
/* 285:    */     
/* 286:    */     private T getData()
/* 287:    */     {
/* 288:256 */       return this.data;
/* 289:    */     }
/* 290:    */   }
/* 291:    */   
/* 292:    */   private class EnumInitMatchCollector
/* 293:    */     extends AbstractMatchResultIterator
/* 294:    */   {
/* 295:    */     private final WildcardMatch wcm;
/* 296:263 */     private final Map<StaticVariable, EnumClassRewriter.CollectedEnumData<? extends AbstractConstructorInvokation>> entryMap = MapFactory.newLinkedMap();
/* 297:    */     private EnumClassRewriter.CollectedEnumData<NewAnonymousArray> matchedArray;
/* 298:265 */     private List<ClassFileField> matchedHideTheseFields = ListFactory.newList();
/* 299:    */     
/* 300:    */     private EnumInitMatchCollector(WildcardMatch wcm)
/* 301:    */     {
/* 302:268 */       this.wcm = wcm;
/* 303:    */     }
/* 304:    */     
/* 305:    */     public void clear() {}
/* 306:    */     
/* 307:    */     public void collectStatement(String name, StructuredStatement statement)
/* 308:    */     {
/* 309:278 */       if (name.equals("entry"))
/* 310:    */       {
/* 311:279 */         StaticVariable staticVariable = this.wcm.getStaticVariable("e").getMatch();
/* 312:280 */         ConstructorInvokationSimple constructorInvokation = this.wcm.getConstructorSimpleWildcard("c").getMatch();
/* 313:281 */         this.entryMap.put(staticVariable, new EnumClassRewriter.CollectedEnumData(statement.getContainer(), constructorInvokation, null));
/* 314:282 */         return;
/* 315:    */       }
/* 316:285 */       if (name.equals("entryderived"))
/* 317:    */       {
/* 318:286 */         StaticVariable staticVariable = this.wcm.getStaticVariable("e2").getMatch();
/* 319:287 */         ConstructorInvokationAnonymousInner constructorInvokation = this.wcm.getConstructorAnonymousWildcard("c2").getMatch();
/* 320:288 */         this.entryMap.put(staticVariable, new EnumClassRewriter.CollectedEnumData(statement.getContainer(), constructorInvokation, null));
/* 321:289 */         return;
/* 322:    */       }
/* 323:292 */       if (name.equals("values"))
/* 324:    */       {
/* 325:293 */         AbstractNewArray abstractNewArray = this.wcm.getNewArrayWildCard("v").getMatch();
/* 326:295 */         if ((abstractNewArray instanceof NewAnonymousArray)) {
/* 327:296 */           this.matchedArray = new EnumClassRewriter.CollectedEnumData(statement.getContainer(), (NewAnonymousArray)abstractNewArray, null);
/* 328:    */         }
/* 329:298 */         return;
/* 330:    */       }
/* 331:    */     }
/* 332:    */     
/* 333:    */     public void collectMatches(String name, WildcardMatch wcm) {}
/* 334:    */     
/* 335:    */     boolean isValid()
/* 336:    */     {
/* 337:312 */       List<ClassFileField> fields = EnumClassRewriter.this.classFile.getFields();
/* 338:313 */       for (ClassFileField classFileField : fields)
/* 339:    */       {
/* 340:314 */         Field field = classFileField.getField();
/* 341:315 */         JavaTypeInstance fieldType = field.getJavaTypeInstance();
/* 342:316 */         boolean isStatic = field.testAccessFlag(AccessFlag.ACC_STATIC);
/* 343:317 */         boolean isEnum = field.testAccessFlag(AccessFlag.ACC_ENUM);
/* 344:318 */         boolean expected = (isStatic) && (isEnum) && (fieldType.equals(EnumClassRewriter.this.classType));
/* 345:319 */         StaticVariable tmp = new StaticVariable(EnumClassRewriter.this.clazzIJT, EnumClassRewriter.this.classType, field.getFieldName());
/* 346:320 */         if (expected != this.entryMap.containsKey(tmp)) {
/* 347:321 */           return false;
/* 348:    */         }
/* 349:323 */         if (expected) {
/* 350:324 */           this.matchedHideTheseFields.add(classFileField);
/* 351:    */         }
/* 352:    */       }
/* 353:327 */       List<Expression> values = ((NewAnonymousArray)EnumClassRewriter.CollectedEnumData.access$400(this.matchedArray)).getValues();
/* 354:328 */       if (values.size() != this.entryMap.size()) {
/* 355:329 */         return false;
/* 356:    */       }
/* 357:331 */       for (Expression value : values)
/* 358:    */       {
/* 359:332 */         if (!(value instanceof LValueExpression)) {
/* 360:333 */           return false;
/* 361:    */         }
/* 362:335 */         LValueExpression lValueExpression = (LValueExpression)value;
/* 363:336 */         LValue lvalue = lValueExpression.getLValue();
/* 364:337 */         if (!(lvalue instanceof StaticVariable)) {
/* 365:338 */           return false;
/* 366:    */         }
/* 367:340 */         StaticVariable staticVariable = (StaticVariable)lvalue;
/* 368:341 */         if (!this.entryMap.containsKey(staticVariable)) {
/* 369:342 */           return false;
/* 370:    */         }
/* 371:    */       }
/* 372:345 */       LValue valuesArray = ((StructuredAssignment)EnumClassRewriter.CollectedEnumData.access$300(this.matchedArray).getStatement()).getLvalue();
/* 373:346 */       if (!(valuesArray instanceof StaticVariable)) {
/* 374:347 */         return false;
/* 375:    */       }
/* 376:349 */       StaticVariable valuesArrayStatic = (StaticVariable)valuesArray;
/* 377:    */       try
/* 378:    */       {
/* 379:351 */         ClassFileField valuesField = EnumClassRewriter.this.classFile.getFieldByName(valuesArrayStatic.getFieldName(), valuesArrayStatic.getInferredJavaType().getJavaTypeInstance());
/* 380:352 */         if (!valuesField.getField().testAccessFlag(AccessFlag.ACC_STATIC)) {
/* 381:353 */           return false;
/* 382:    */         }
/* 383:355 */         this.matchedHideTheseFields.add(valuesField);
/* 384:    */       }
/* 385:    */       catch (NoSuchFieldException e)
/* 386:    */       {
/* 387:357 */         return false;
/* 388:    */       }
/* 389:359 */       return true;
/* 390:    */     }
/* 391:    */     
/* 392:    */     private List<ClassFileField> getMatchedHideTheseFields()
/* 393:    */     {
/* 394:363 */       return this.matchedHideTheseFields;
/* 395:    */     }
/* 396:    */     
/* 397:    */     private Map<StaticVariable, EnumClassRewriter.CollectedEnumData<? extends AbstractConstructorInvokation>> getEntryMap()
/* 398:    */     {
/* 399:367 */       return this.entryMap;
/* 400:    */     }
/* 401:    */     
/* 402:    */     private EnumClassRewriter.CollectedEnumData<NewAnonymousArray> getMatchedArray()
/* 403:    */     {
/* 404:371 */       return this.matchedArray;
/* 405:    */     }
/* 406:    */   }
/* 407:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.EnumClassRewriter
 * JD-Core Version:    0.7.0.1
 */