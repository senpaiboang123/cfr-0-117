/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*   2:    */ 
/*   3:    */ import java.util.Collections;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Set;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.InstrIndex;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.TernaryExpression;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.AssignmentSimple;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CaseStatement;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CommentStatement;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.IfStatement;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.Nop;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifierFactory;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockType;
/*  26:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.JumpType;
/*  27:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  28:    */ import org.benf.cfr.reader.bytecode.analysis.stack.StackEntry;
/*  29:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  30:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  31:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  32:    */ import org.benf.cfr.reader.util.Functional;
/*  33:    */ import org.benf.cfr.reader.util.ListFactory;
/*  34:    */ import org.benf.cfr.reader.util.Predicate;
/*  35:    */ import org.benf.cfr.reader.util.SetFactory;
/*  36:    */ import org.benf.cfr.reader.util.SetUtil;
/*  37:    */ import org.benf.cfr.reader.util.Troolean;
/*  38:    */ 
/*  39:    */ public class ConditionalRewriter
/*  40:    */ {
/*  41:    */   private static class IsForwardIf
/*  42:    */     implements Predicate<Op03SimpleStatement>
/*  43:    */   {
/*  44:    */     public boolean test(Op03SimpleStatement in)
/*  45:    */     {
/*  46: 29 */       if (!(in.getStatement() instanceof IfStatement)) {
/*  47: 29 */         return false;
/*  48:    */       }
/*  49: 30 */       IfStatement ifStatement = (IfStatement)in.getStatement();
/*  50: 31 */       if (!ifStatement.getJumpType().isUnknown()) {
/*  51: 31 */         return false;
/*  52:    */       }
/*  53: 32 */       if (((Op03SimpleStatement)in.getTargets().get(1)).getIndex().compareTo(in.getIndex()) <= 0) {
/*  54: 32 */         return false;
/*  55:    */       }
/*  56: 33 */       return true;
/*  57:    */     }
/*  58:    */   }
/*  59:    */   
/*  60:    */   public static void identifyNonjumpingConditionals(List<Op03SimpleStatement> statements, BlockIdentifierFactory blockIdentifierFactory)
/*  61:    */   {
/*  62: 38 */     boolean success = false;
/*  63: 39 */     Set<Op03SimpleStatement> ignoreTheseJumps = SetFactory.newSet();
/*  64:    */     do
/*  65:    */     {
/*  66: 41 */       success = false;
/*  67: 42 */       List<Op03SimpleStatement> forwardIfs = Functional.filter(statements, new IsForwardIf(null));
/*  68: 43 */       Collections.reverse(forwardIfs);
/*  69: 44 */       for (Op03SimpleStatement forwardIf : forwardIfs) {
/*  70: 45 */         if ((considerAsTrivialIf(forwardIf, statements, blockIdentifierFactory, ignoreTheseJumps)) || (considerAsSimpleIf(forwardIf, statements, blockIdentifierFactory, ignoreTheseJumps)) || (considerAsDexIf(forwardIf, statements, blockIdentifierFactory, ignoreTheseJumps))) {
/*  71: 48 */           success = true;
/*  72:    */         }
/*  73:    */       }
/*  74: 51 */     } while (success);
/*  75:    */   }
/*  76:    */   
/*  77:    */   private static boolean considerAsTrivialIf(Op03SimpleStatement ifStatement, List<Op03SimpleStatement> statements, BlockIdentifierFactory blockIdentifierFactory, Set<Op03SimpleStatement> ignoreTheseJumps)
/*  78:    */   {
/*  79: 55 */     Op03SimpleStatement takenTarget = (Op03SimpleStatement)ifStatement.getTargets().get(1);
/*  80: 56 */     Op03SimpleStatement notTakenTarget = (Op03SimpleStatement)ifStatement.getTargets().get(0);
/*  81: 57 */     int idxTaken = statements.indexOf(takenTarget);
/*  82: 58 */     int idxNotTaken = statements.indexOf(notTakenTarget);
/*  83: 59 */     if (idxTaken != idxNotTaken + 1) {
/*  84: 59 */       return false;
/*  85:    */     }
/*  86: 60 */     if ((takenTarget.getStatement().getClass() != GotoStatement.class) || (notTakenTarget.getStatement().getClass() != GotoStatement.class) || (takenTarget.getTargets().get(0) != notTakenTarget.getTargets().get(0))) {
/*  87: 63 */       return false;
/*  88:    */     }
/*  89: 65 */     notTakenTarget.replaceStatement(new CommentStatement("empty if block"));
/*  90:    */     
/*  91:    */ 
/*  92: 68 */     return false;
/*  93:    */   }
/*  94:    */   
/*  95:    */   private static boolean considerAsDexIf(Op03SimpleStatement ifStatement, List<Op03SimpleStatement> statements, BlockIdentifierFactory blockIdentifierFactory, Set<Op03SimpleStatement> ignoreTheseJumps)
/*  96:    */   {
/*  97: 98 */     Statement innerStatement = ifStatement.getStatement();
/*  98: 99 */     if (innerStatement.getClass() != IfStatement.class) {
/*  99:100 */       return false;
/* 100:    */     }
/* 101:102 */     IfStatement innerIfStatement = (IfStatement)innerStatement;
/* 102:    */     
/* 103:104 */     int startIdx = statements.indexOf(ifStatement);
/* 104:105 */     int bidx = statements.indexOf(ifStatement.getTargets().get(1));
/* 105:106 */     if (bidx <= startIdx) {
/* 106:106 */       return false;
/* 107:    */     }
/* 108:107 */     InstrIndex startIndex = ifStatement.getIndex();
/* 109:108 */     InstrIndex bIndex = ((Op03SimpleStatement)ifStatement.getTargets().get(1)).getIndex();
/* 110:109 */     if (startIndex.compareTo(bIndex) >= 0) {
/* 111:110 */       return false;
/* 112:    */     }
/* 113:113 */     int aidx = startIdx + 1;
/* 114:    */     
/* 115:115 */     int cidx = findOverIdx(bidx, statements);
/* 116:116 */     if (cidx == -1) {
/* 117:116 */       return false;
/* 118:    */     }
/* 119:118 */     int didx = findOverIdx(cidx, statements);
/* 120:119 */     if (didx == -1) {
/* 121:119 */       return false;
/* 122:    */     }
/* 123:121 */     if (didx <= cidx) {
/* 124:121 */       return false;
/* 125:    */     }
/* 126:123 */     Set<Op03SimpleStatement> permittedSources = SetFactory.newSet(new Op03SimpleStatement[] { ifStatement });
/* 127:124 */     if (!isRangeOnlyReachable(aidx, bidx, cidx, statements, permittedSources)) {
/* 128:124 */       return false;
/* 129:    */     }
/* 130:125 */     if (!isRangeOnlyReachable(bidx, cidx, didx, statements, permittedSources)) {
/* 131:125 */       return false;
/* 132:    */     }
/* 133:131 */     List<Op03SimpleStatement> alist = statements.subList(aidx, bidx);
/* 134:132 */     List<Op03SimpleStatement> blist = statements.subList(bidx, cidx);
/* 135:    */     
/* 136:    */ 
/* 137:    */ 
/* 138:    */ 
/* 139:137 */     ((Op03SimpleStatement)alist.get(alist.size() - 1)).nopOut();
/* 140:    */     
/* 141:139 */     List<Op03SimpleStatement> ifTargets = ifStatement.getTargets();
/* 142:    */     
/* 143:141 */     Op03SimpleStatement tgtA = (Op03SimpleStatement)ifTargets.get(0);
/* 144:142 */     Op03SimpleStatement tgtB = (Op03SimpleStatement)ifTargets.get(1);
/* 145:143 */     ifTargets.set(0, tgtB);
/* 146:144 */     ifTargets.set(1, tgtA);
/* 147:145 */     innerIfStatement.setCondition(innerIfStatement.getCondition().getNegated().simplify());
/* 148:    */     
/* 149:147 */     List<Op03SimpleStatement> acopy = ListFactory.newList(alist);
/* 150:148 */     blist.addAll(acopy);
/* 151:149 */     alist = statements.subList(aidx, bidx);
/* 152:150 */     alist.clear();
/* 153:    */     
/* 154:152 */     Cleaner.reindexInPlace(statements);
/* 155:    */     
/* 156:154 */     return true;
/* 157:    */   }
/* 158:    */   
/* 159:    */   private static int findOverIdx(int startNext, List<Op03SimpleStatement> statements)
/* 160:    */   {
/* 161:162 */     Op03SimpleStatement next = (Op03SimpleStatement)statements.get(startNext);
/* 162:    */     
/* 163:164 */     Op03SimpleStatement cStatement = null;
/* 164:165 */     for (int gSearch = startNext - 1; gSearch >= 0; gSearch--)
/* 165:    */     {
/* 166:166 */       Op03SimpleStatement stm = (Op03SimpleStatement)statements.get(gSearch);
/* 167:167 */       Statement s = stm.getStatement();
/* 168:168 */       if (!(s instanceof Nop))
/* 169:    */       {
/* 170:169 */         if (s.getClass() == GotoStatement.class)
/* 171:    */         {
/* 172:170 */           Op03SimpleStatement tgtC = (Op03SimpleStatement)stm.getTargets().get(0);
/* 173:171 */           if (tgtC.getIndex().isBackJumpFrom(next)) {
/* 174:171 */             return -1;
/* 175:    */           }
/* 176:172 */           cStatement = tgtC;
/* 177:173 */           break;
/* 178:    */         }
/* 179:175 */         return -1;
/* 180:    */       }
/* 181:    */     }
/* 182:177 */     if (cStatement == null) {
/* 183:177 */       return -1;
/* 184:    */     }
/* 185:178 */     int cidx = statements.indexOf(cStatement);
/* 186:179 */     return cidx;
/* 187:    */   }
/* 188:    */   
/* 189:    */   private static boolean isRangeOnlyReachable(int startIdx, int endIdx, int tgtIdx, List<Op03SimpleStatement> statements, Set<Op03SimpleStatement> permittedSources)
/* 190:    */   {
/* 191:194 */     Set<Op03SimpleStatement> reachable = SetFactory.newSet();
/* 192:195 */     Op03SimpleStatement startStatement = (Op03SimpleStatement)statements.get(startIdx);
/* 193:196 */     Op03SimpleStatement endStatement = (Op03SimpleStatement)statements.get(endIdx);
/* 194:197 */     Op03SimpleStatement tgtStatement = (Op03SimpleStatement)statements.get(tgtIdx);
/* 195:198 */     InstrIndex startIndex = startStatement.getIndex();
/* 196:199 */     InstrIndex endIndex = endStatement.getIndex();
/* 197:200 */     InstrIndex finalTgtIndex = tgtStatement.getIndex();
/* 198:    */     
/* 199:202 */     reachable.add(statements.get(startIdx));
/* 200:203 */     boolean foundEnd = false;
/* 201:204 */     for (int idx = startIdx; idx < endIdx; idx++)
/* 202:    */     {
/* 203:205 */       Op03SimpleStatement stm = (Op03SimpleStatement)statements.get(idx);
/* 204:206 */       if (!reachable.contains(stm)) {
/* 205:207 */         return false;
/* 206:    */       }
/* 207:211 */       for (Op03SimpleStatement source : stm.getSources())
/* 208:    */       {
/* 209:212 */         InstrIndex sourceIndex = source.getIndex();
/* 210:213 */         if ((sourceIndex.compareTo(startIndex) < 0) && 
/* 211:214 */           (!permittedSources.contains(source))) {
/* 212:215 */           return false;
/* 213:    */         }
/* 214:218 */         if (sourceIndex.compareTo(endIndex) >= 0) {
/* 215:219 */           return false;
/* 216:    */         }
/* 217:    */       }
/* 218:222 */       for (Op03SimpleStatement target : stm.getTargets())
/* 219:    */       {
/* 220:223 */         InstrIndex tgtIndex = target.getIndex();
/* 221:224 */         if (tgtIndex.compareTo(startIndex) < 0) {
/* 222:225 */           return false;
/* 223:    */         }
/* 224:227 */         if (tgtIndex.compareTo(endIndex) >= 0) {
/* 225:228 */           if (tgtIndex == finalTgtIndex) {
/* 226:229 */             foundEnd = true;
/* 227:    */           } else {
/* 228:231 */             return false;
/* 229:    */           }
/* 230:    */         }
/* 231:234 */         reachable.add(target);
/* 232:    */       }
/* 233:    */     }
/* 234:237 */     return foundEnd;
/* 235:    */   }
/* 236:    */   
/* 237:    */   private static boolean detectAndRemarkJumpIntoOther(Set<BlockIdentifier> blocksAtStart, Set<BlockIdentifier> blocksAtEnd, Op03SimpleStatement realEnd, Op03SimpleStatement ifStatement)
/* 238:    */   {
/* 239:258 */     if (blocksAtEnd.size() != blocksAtStart.size() + 1) {
/* 240:258 */       return false;
/* 241:    */     }
/* 242:260 */     List<BlockIdentifier> diff = SetUtil.differenceAtakeBtoList(blocksAtEnd, blocksAtStart);
/* 243:261 */     BlockIdentifier testBlock = (BlockIdentifier)diff.get(0);
/* 244:262 */     if (testBlock.getBlockType() != BlockType.SIMPLE_IF_TAKEN) {
/* 245:262 */       return false;
/* 246:    */     }
/* 247:267 */     List<Op03SimpleStatement> realEndTargets = realEnd.getTargets();
/* 248:268 */     if ((realEndTargets.size() != 1) || (((Op03SimpleStatement)realEndTargets.get(0)).getLinearlyPrevious() != realEnd)) {
/* 249:268 */       return false;
/* 250:    */     }
/* 251:270 */     Op03SimpleStatement afterRealEnd = (Op03SimpleStatement)realEndTargets.get(0);
/* 252:271 */     List<Op03SimpleStatement> areSources = afterRealEnd.getSources();
/* 253:272 */     if (areSources.size() != 2) {
/* 254:272 */       return false;
/* 255:    */     }
/* 256:273 */     Op03SimpleStatement other = areSources.get(0) == realEnd ? (Op03SimpleStatement)areSources.get(1) : (Op03SimpleStatement)areSources.get(0);
/* 257:    */     
/* 258:    */ 
/* 259:276 */     Statement otherStatement = other.getStatement();
/* 260:277 */     if (!other.getIndex().isBackJumpTo(ifStatement)) {
/* 261:277 */       return false;
/* 262:    */     }
/* 263:279 */     if (!(otherStatement instanceof IfStatement)) {
/* 264:279 */       return false;
/* 265:    */     }
/* 266:281 */     Pair<BlockIdentifier, BlockIdentifier> knownBlocks = ((IfStatement)otherStatement).getBlocks();
/* 267:282 */     if ((knownBlocks.getFirst() != testBlock) || (knownBlocks.getSecond() != null)) {
/* 268:282 */       return false;
/* 269:    */     }
/* 270:284 */     ((IfStatement)otherStatement).setJumpType(JumpType.BREAK_ANONYMOUS);
/* 271:    */     
/* 272:286 */     Op03SimpleStatement current = other.getLinearlyNext();
/* 273:287 */     while ((current != null) && (current.getBlockIdentifiers().contains(testBlock)))
/* 274:    */     {
/* 275:288 */       current.getBlockIdentifiers().remove(testBlock);
/* 276:289 */       current = current.getLinearlyNext();
/* 277:    */     }
/* 278:291 */     return true;
/* 279:    */   }
/* 280:    */   
/* 281:    */   private static boolean considerAsSimpleIf(Op03SimpleStatement ifStatement, List<Op03SimpleStatement> statements, BlockIdentifierFactory blockIdentifierFactory, Set<Op03SimpleStatement> ignoreTheseJumps)
/* 282:    */   {
/* 283:310 */     Op03SimpleStatement takenTarget = (Op03SimpleStatement)ifStatement.getTargets().get(1);
/* 284:311 */     Op03SimpleStatement notTakenTarget = (Op03SimpleStatement)ifStatement.getTargets().get(0);
/* 285:312 */     int idxTaken = statements.indexOf(takenTarget);
/* 286:313 */     int idxNotTaken = statements.indexOf(notTakenTarget);
/* 287:314 */     IfStatement innerIfStatement = (IfStatement)ifStatement.getStatement();
/* 288:    */     
/* 289:316 */     Set<Op03SimpleStatement> ignoreLocally = SetFactory.newSet();
/* 290:    */     
/* 291:318 */     boolean takenAction = false;
/* 292:    */     
/* 293:320 */     int idxCurrent = idxNotTaken;
/* 294:321 */     if (idxCurrent > idxTaken) {
/* 295:321 */       return false;
/* 296:    */     }
/* 297:323 */     int idxEnd = idxTaken;
/* 298:324 */     int maybeElseEndIdx = -1;
/* 299:325 */     Op03SimpleStatement maybeElseEnd = null;
/* 300:326 */     boolean maybeSimpleIfElse = false;
/* 301:327 */     boolean extractCommonEnd = false;
/* 302:328 */     GotoStatement leaveIfBranchGoto = null;
/* 303:329 */     Op03SimpleStatement leaveIfBranchHolder = null;
/* 304:330 */     List<Op03SimpleStatement> ifBranch = ListFactory.newList();
/* 305:331 */     List<Op03SimpleStatement> elseBranch = null;
/* 306:    */     
/* 307:    */ 
/* 308:334 */     Set<BlockIdentifier> blocksAtStart = ifStatement.getBlockIdentifiers();
/* 309:335 */     if (idxCurrent == idxEnd)
/* 310:    */     {
/* 311:338 */       Op03SimpleStatement taken = new Op03SimpleStatement(blocksAtStart, new CommentStatement("empty if block"), notTakenTarget.getIndex().justBefore());
/* 312:339 */       taken.addSource(ifStatement);
/* 313:340 */       taken.addTarget(notTakenTarget);
/* 314:341 */       Op03SimpleStatement emptyTarget = (Op03SimpleStatement)ifStatement.getTargets().get(0);
/* 315:342 */       if (notTakenTarget != emptyTarget) {
/* 316:343 */         notTakenTarget.addSource(taken);
/* 317:    */       }
/* 318:345 */       emptyTarget.replaceSource(ifStatement, taken);
/* 319:346 */       ifStatement.getTargets().set(0, taken);
/* 320:347 */       statements.add(idxTaken, taken);
/* 321:    */       
/* 322:349 */       BlockIdentifier ifBlockLabel = blockIdentifierFactory.getNextBlockIdentifier(BlockType.SIMPLE_IF_TAKEN);
/* 323:350 */       taken.markFirstStatementInBlock(ifBlockLabel);
/* 324:    */       
/* 325:352 */       taken.getBlockIdentifiers().add(ifBlockLabel);
/* 326:353 */       innerIfStatement.setKnownBlocks(ifBlockLabel, null);
/* 327:354 */       innerIfStatement.setJumpType(JumpType.GOTO_OUT_OF_IF);
/* 328:355 */       return true;
/* 329:    */     }
/* 330:357 */     Set<Op03SimpleStatement> validForwardParents = SetFactory.newSet();
/* 331:358 */     validForwardParents.add(ifStatement);
/* 332:    */     
/* 333:    */ 
/* 334:    */ 
/* 335:    */ 
/* 336:    */ 
/* 337:364 */     Op03SimpleStatement stmtLastBlock = (Op03SimpleStatement)statements.get(idxTaken - 1);
/* 338:365 */     Op03SimpleStatement stmtLastBlockRewrite = null;
/* 339:366 */     Statement stmtLastBlockInner = stmtLastBlock.getStatement();
/* 340:367 */     if (stmtLastBlockInner.getClass() == GotoStatement.class) {
/* 341:368 */       stmtLastBlockRewrite = stmtLastBlock;
/* 342:    */     }
/* 343:    */     do
/* 344:    */     {
/* 345:372 */       Op03SimpleStatement statementCurrent = (Op03SimpleStatement)statements.get(idxCurrent);
/* 346:373 */       boolean currentParent = false;
/* 347:374 */       if (idxCurrent > 0)
/* 348:    */       {
/* 349:375 */         Op03SimpleStatement currentPrev = (Op03SimpleStatement)statements.get(idxCurrent - 1);
/* 350:376 */         if ((currentPrev.getTargets().contains(statementCurrent)) && (currentPrev.getStatement().fallsToNext())) {
/* 351:376 */           currentParent = true;
/* 352:    */         }
/* 353:    */       }
/* 354:381 */       InstrIndex currentIndex = statementCurrent.getIndex();
/* 355:382 */       if (!currentParent) {
/* 356:383 */         for (Op03SimpleStatement source : statementCurrent.getSources()) {
/* 357:384 */           if ((currentIndex.isBackJumpTo(source)) && 
/* 358:385 */             (!validForwardParents.contains(source)))
/* 359:    */           {
/* 360:399 */             Op03SimpleStatement newJump = new Op03SimpleStatement(ifStatement.getBlockIdentifiers(), new GotoStatement(), statementCurrent.getIndex().justBefore());
/* 361:400 */             if (statementCurrent != ifStatement.getTargets().get(0))
/* 362:    */             {
/* 363:401 */               Op03SimpleStatement oldTarget = (Op03SimpleStatement)ifStatement.getTargets().get(1);
/* 364:402 */               newJump.addTarget(oldTarget);
/* 365:403 */               newJump.addSource(ifStatement);
/* 366:404 */               ifStatement.replaceTarget(oldTarget, newJump);
/* 367:405 */               oldTarget.replaceSource(ifStatement, newJump);
/* 368:406 */               statements.add(idxCurrent, newJump);
/* 369:407 */               return true;
/* 370:    */             }
/* 371:    */           }
/* 372:    */         }
/* 373:    */       }
/* 374:413 */       validForwardParents.add(statementCurrent);
/* 375:    */       
/* 376:415 */       ifBranch.add(statementCurrent);
/* 377:416 */       JumpType jumpType = statementCurrent.getJumpType();
/* 378:417 */       if ((jumpType.isUnknown()) && (!ignoreTheseJumps.contains(statementCurrent))) {
/* 379:433 */         if (idxCurrent == idxTaken - 1)
/* 380:    */         {
/* 381:434 */           Statement mGotoStatement = statementCurrent.getStatement();
/* 382:435 */           if (mGotoStatement.getClass() != GotoStatement.class) {
/* 383:435 */             return false;
/* 384:    */           }
/* 385:436 */           GotoStatement gotoStatement = (GotoStatement)mGotoStatement;
/* 386:    */           
/* 387:438 */           maybeElseEnd = (Op03SimpleStatement)statementCurrent.getTargets().get(0);
/* 388:439 */           maybeElseEndIdx = statements.indexOf(maybeElseEnd);
/* 389:440 */           if (maybeElseEnd.getIndex().compareTo(takenTarget.getIndex()) <= 0) {
/* 390:441 */             return false;
/* 391:    */           }
/* 392:443 */           leaveIfBranchHolder = statementCurrent;
/* 393:444 */           leaveIfBranchGoto = gotoStatement;
/* 394:445 */           maybeSimpleIfElse = true;
/* 395:    */         }
/* 396:    */         else
/* 397:    */         {
/* 398:447 */           if (stmtLastBlockRewrite == null)
/* 399:    */           {
/* 400:448 */             Op03SimpleStatement tgtContainer = (Op03SimpleStatement)statementCurrent.getTargets().get(0);
/* 401:449 */             if (tgtContainer == takenTarget)
/* 402:    */             {
/* 403:451 */               idxCurrent++;
/* 404:452 */               continue;
/* 405:    */             }
/* 406:455 */             return false;
/* 407:    */           }
/* 408:459 */           List<Op03SimpleStatement> targets = statementCurrent.getTargets();
/* 409:    */           
/* 410:461 */           Op03SimpleStatement eventualTarget = (Op03SimpleStatement)stmtLastBlockRewrite.getTargets().get(0);
/* 411:462 */           boolean found = false;
/* 412:463 */           for (int x = 0; x < targets.size(); x++)
/* 413:    */           {
/* 414:464 */             Op03SimpleStatement target = (Op03SimpleStatement)targets.get(x);
/* 415:465 */             if ((target == eventualTarget) && (target != stmtLastBlockRewrite))
/* 416:    */             {
/* 417:468 */               targets.set(x, stmtLastBlockRewrite);
/* 418:469 */               stmtLastBlockRewrite.addSource(statementCurrent);
/* 419:471 */               if (eventualTarget.getSources().contains(stmtLastBlockRewrite)) {
/* 420:472 */                 eventualTarget.removeSource(statementCurrent);
/* 421:    */               } else {
/* 422:474 */                 eventualTarget.replaceSource(statementCurrent, stmtLastBlockRewrite);
/* 423:    */               }
/* 424:477 */               found = true;
/* 425:    */             }
/* 426:    */           }
/* 427:481 */           return found;
/* 428:    */         }
/* 429:    */       }
/* 430:484 */       idxCurrent++;
/* 431:485 */     } while (idxCurrent != idxEnd);
/* 432:489 */     if (maybeSimpleIfElse)
/* 433:    */     {
/* 434:491 */       elseBranch = ListFactory.newList();
/* 435:492 */       idxCurrent = idxTaken;
/* 436:493 */       idxEnd = maybeElseEndIdx;
/* 437:    */       do
/* 438:    */       {
/* 439:495 */         Op03SimpleStatement statementCurrent = (Op03SimpleStatement)statements.get(idxCurrent);
/* 440:496 */         elseBranch.add(statementCurrent);
/* 441:497 */         JumpType jumpType = statementCurrent.getJumpType();
/* 442:498 */         if (jumpType.isUnknown())
/* 443:    */         {
/* 444:504 */           Statement mGotoStatement = statementCurrent.getStatement();
/* 445:505 */           if (mGotoStatement.getClass() != GotoStatement.class) {
/* 446:505 */             return false;
/* 447:    */           }
/* 448:506 */           GotoStatement gotoStatement = (GotoStatement)mGotoStatement;
/* 449:508 */           if (statementCurrent.getTargets().get(0) == maybeElseEnd)
/* 450:    */           {
/* 451:509 */             idxEnd = idxCurrent;
/* 452:510 */             idxCurrent--;
/* 453:    */             
/* 454:    */ 
/* 455:    */ 
/* 456:514 */             leaveIfBranchHolder.replaceTarget(maybeElseEnd, statementCurrent);
/* 457:515 */             statementCurrent.addSource(leaveIfBranchHolder);
/* 458:516 */             maybeElseEnd.removeSource(leaveIfBranchHolder);
/* 459:517 */             elseBranch.remove(statementCurrent);
/* 460:518 */             takenAction = true;
/* 461:    */           }
/* 462:    */           else
/* 463:    */           {
/* 464:520 */             return false;
/* 465:    */           }
/* 466:    */         }
/* 467:523 */         idxCurrent++;
/* 468:524 */       } while (idxCurrent != idxEnd);
/* 469:    */     }
/* 470:527 */     Op03SimpleStatement realEnd = (Op03SimpleStatement)statements.get(idxEnd);
/* 471:528 */     Set<BlockIdentifier> blocksAtEnd = realEnd.getBlockIdentifiers();
/* 472:532 */     if ((!blocksAtStart.containsAll(blocksAtEnd)) || (blocksAtEnd.size() != blocksAtStart.size())) {
/* 473:538 */       if (blocksAtStart.size() == blocksAtEnd.size() + 1)
/* 474:    */       {
/* 475:539 */         List<BlockIdentifier> change = SetUtil.differenceAtakeBtoList(blocksAtStart, blocksAtEnd);
/* 476:541 */         if ((change.size() == 1) && (((BlockIdentifier)change.get(0)).getBlockType() == BlockType.CASE) && ((takenTarget.getStatement() instanceof CaseStatement)) && 
/* 477:    */         
/* 478:    */ 
/* 479:544 */           (stmtLastBlock.getBlockIdentifiers().contains(change.get(0)))) {}
/* 480:    */       }
/* 481:552 */       else if (!detectAndRemarkJumpIntoOther(blocksAtStart, blocksAtEnd, realEnd, ifStatement))
/* 482:    */       {
/* 483:554 */         return takenAction;
/* 484:    */       }
/* 485:    */     }
/* 486:558 */     DiscoveredTernary ternary = testForTernary(ifBranch, elseBranch, leaveIfBranchHolder);
/* 487:559 */     if (ternary != null)
/* 488:    */     {
/* 489:    */       Op03SimpleStatement statement;
/* 490:561 */       for (Iterator i$ = ifBranch.iterator(); i$.hasNext(); statement.nopOut()) {
/* 491:561 */         statement = (Op03SimpleStatement)i$.next();
/* 492:    */       }
/* 493:    */       Op03SimpleStatement statement;
/* 494:562 */       for (Iterator i$ = elseBranch.iterator(); i$.hasNext(); statement.nopOut()) {
/* 495:562 */         statement = (Op03SimpleStatement)i$.next();
/* 496:    */       }
/* 497:564 */       ifStatement.forceSSAIdentifiers(leaveIfBranchHolder.getSSAIdentifiers());
/* 498:    */       
/* 499:    */ 
/* 500:    */ 
/* 501:    */ 
/* 502:569 */       ConditionalExpression conditionalExpression = innerIfStatement.getCondition().getNegated().simplify();
/* 503:570 */       Expression rhs = ternary.isPointlessBoolean() ? conditionalExpression : new TernaryExpression(conditionalExpression, ternary.e1, ternary.e2);
/* 504:    */       
/* 505:    */ 
/* 506:    */ 
/* 507:    */ 
/* 508:    */ 
/* 509:576 */       ifStatement.replaceStatement(new AssignmentSimple(ternary.lValue, rhs));
/* 510:583 */       if ((ternary.lValue instanceof StackSSALabel))
/* 511:    */       {
/* 512:584 */         StackSSALabel stackSSALabel = (StackSSALabel)ternary.lValue;
/* 513:585 */         StackEntry stackEntry = stackSSALabel.getStackEntry();
/* 514:586 */         stackEntry.decSourceCount();
/* 515:    */       }
/* 516:592 */       List<Op03SimpleStatement> tmp = ListFactory.uniqueList(ifStatement.getTargets());
/* 517:593 */       ifStatement.getTargets().clear();
/* 518:594 */       ifStatement.getTargets().addAll(tmp);
/* 519:595 */       if (ifStatement.getTargets().size() != 1) {
/* 520:596 */         throw new ConfusedCFRException("If statement should only have one target after dedup");
/* 521:    */       }
/* 522:598 */       Op03SimpleStatement joinStatement = (Op03SimpleStatement)ifStatement.getTargets().get(0);
/* 523:599 */       tmp = ListFactory.uniqueList(joinStatement.getSources());
/* 524:600 */       joinStatement.getSources().clear();
/* 525:601 */       joinStatement.getSources().addAll(tmp);
/* 526:    */       
/* 527:    */ 
/* 528:    */ 
/* 529:    */ 
/* 530:606 */       LValueProp.condenseLValues(statements);
/* 531:    */       
/* 532:608 */       return true;
/* 533:    */     }
/* 534:612 */     BlockIdentifier elseBlockLabel = null;
/* 535:613 */     if ((maybeSimpleIfElse) && (elseBranch.isEmpty())) {
/* 536:614 */       maybeSimpleIfElse = false;
/* 537:    */     }
/* 538:616 */     boolean flipBlocks = false;
/* 539:617 */     if (maybeSimpleIfElse)
/* 540:    */     {
/* 541:618 */       elseBlockLabel = blockIdentifierFactory.getNextBlockIdentifier(BlockType.SIMPLE_IF_ELSE);
/* 542:619 */       Misc.markWholeBlock(elseBranch, elseBlockLabel);
/* 543:    */       
/* 544:    */ 
/* 545:    */ 
/* 546:    */ 
/* 547:    */ 
/* 548:    */ 
/* 549:    */ 
/* 550:    */ 
/* 551:    */ 
/* 552:    */ 
/* 553:    */ 
/* 554:    */ 
/* 555:    */ 
/* 556:    */ 
/* 557:    */ 
/* 558:    */ 
/* 559:636 */       Set<Op03SimpleStatement> allIfSources = Misc.collectAllSources(ifBranch);
/* 560:637 */       allIfSources.removeAll(ifBranch);
/* 561:638 */       allIfSources.remove(ifStatement);
/* 562:639 */       if (!allIfSources.isEmpty())
/* 563:    */       {
/* 564:641 */         Op03SimpleStatement elseStart = (Op03SimpleStatement)elseBranch.get(0);
/* 565:642 */         Pair<Set<Op03SimpleStatement>, Set<Op03SimpleStatement>> reachinfo = Misc.GraphVisitorBlockReachable.getBlockReachableAndExits(elseStart, elseBlockLabel);
/* 566:643 */         Set<Op03SimpleStatement> reachableElse = (Set)reachinfo.getFirst();
/* 567:645 */         if ((reachableElse.size() == elseBranch.size()) && (((Set)reachinfo.getSecond()).isEmpty()))
/* 568:    */         {
/* 569:648 */           innerIfStatement.negateCondition();
/* 570:649 */           List<Op03SimpleStatement> targets = ifStatement.getTargets();
/* 571:650 */           Op03SimpleStatement tgt0 = (Op03SimpleStatement)targets.get(0);
/* 572:651 */           Op03SimpleStatement tgt1 = (Op03SimpleStatement)targets.get(1);
/* 573:652 */           targets.clear();
/* 574:653 */           targets.add(tgt1);
/* 575:654 */           targets.add(tgt0);
/* 576:    */           
/* 577:656 */           leaveIfBranchGoto = null;
/* 578:657 */           List<Op03SimpleStatement> oldIfBranch = ifBranch;
/* 579:658 */           ifBranch = elseBranch;
/* 580:659 */           elseBranch = null;
/* 581:660 */           Collections.sort(ifBranch, new CompareByIndex());
/* 582:661 */           Op03SimpleStatement last = (Op03SimpleStatement)ifBranch.get(ifBranch.size() - 1);
/* 583:662 */           InstrIndex fromHere = last.getIndex().justAfter();
/* 584:663 */           Cleaner.sortAndRenumberFromInPlace(oldIfBranch, fromHere);
/* 585:664 */           ignoreLocally.removeAll(oldIfBranch);
/* 586:665 */           flipBlocks = true;
/* 587:666 */           elseBlockLabel.setBlockType(BlockType.SIMPLE_IF_TAKEN);
/* 588:    */         }
/* 589:    */       }
/* 590:    */     }
/* 591:668 */     BlockIdentifier ifBlockLabel = blockIdentifierFactory.getNextBlockIdentifier(BlockType.SIMPLE_IF_TAKEN);
/* 592:669 */     if (flipBlocks)
/* 593:    */     {
/* 594:670 */       ifBlockLabel = elseBlockLabel;
/* 595:671 */       elseBlockLabel = null;
/* 596:    */     }
/* 597:    */     else
/* 598:    */     {
/* 599:673 */       Misc.markWholeBlock(ifBranch, ifBlockLabel);
/* 600:    */     }
/* 601:677 */     if (leaveIfBranchGoto != null) {
/* 602:677 */       leaveIfBranchGoto.setJumpType(JumpType.GOTO_OUT_OF_IF);
/* 603:    */     }
/* 604:678 */     innerIfStatement.setJumpType(JumpType.GOTO_OUT_OF_IF);
/* 605:679 */     innerIfStatement.setKnownBlocks(ifBlockLabel, elseBlockLabel);
/* 606:680 */     ignoreTheseJumps.addAll(ignoreLocally);
/* 607:681 */     if (flipBlocks) {
/* 608:682 */       Cleaner.sortAndRenumberInPlace(statements);
/* 609:    */     }
/* 610:684 */     return true;
/* 611:    */   }
/* 612:    */   
/* 613:    */   private static DiscoveredTernary testForTernary(List<Op03SimpleStatement> ifBranch, List<Op03SimpleStatement> elseBranch, Op03SimpleStatement leaveIfBranch)
/* 614:    */   {
/* 615:689 */     if ((ifBranch == null) || (elseBranch == null)) {
/* 616:689 */       return null;
/* 617:    */     }
/* 618:690 */     if (leaveIfBranch == null) {
/* 619:690 */       return null;
/* 620:    */     }
/* 621:691 */     TypeFilter<Nop> notNops = new TypeFilter(Nop.class, false);
/* 622:692 */     ifBranch = Functional.filter(ifBranch, notNops);
/* 623:693 */     switch (ifBranch.size())
/* 624:    */     {
/* 625:    */     case 1: 
/* 626:    */       break;
/* 627:    */     case 2: 
/* 628:697 */       if (ifBranch.get(1) != leaveIfBranch) {
/* 629:698 */         return null;
/* 630:    */       }
/* 631:    */       break;
/* 632:    */     default: 
/* 633:702 */       return null;
/* 634:    */     }
/* 635:704 */     if (((Op03SimpleStatement)ifBranch.get(0)).getSources().size() != 1) {
/* 636:704 */       return null;
/* 637:    */     }
/* 638:706 */     elseBranch = Functional.filter(elseBranch, notNops);
/* 639:707 */     if (elseBranch.size() != 1) {
/* 640:708 */       return null;
/* 641:    */     }
/* 642:710 */     if (((Op03SimpleStatement)elseBranch.get(0)).getSources().size() != 1) {
/* 643:710 */       return null;
/* 644:    */     }
/* 645:712 */     Op03SimpleStatement s1 = (Op03SimpleStatement)ifBranch.get(0);
/* 646:713 */     Op03SimpleStatement s2 = (Op03SimpleStatement)elseBranch.get(0);
/* 647:714 */     if (s2.getSources().size() != 1) {
/* 648:714 */       return null;
/* 649:    */     }
/* 650:715 */     LValue l1 = s1.getStatement().getCreatedLValue();
/* 651:716 */     LValue l2 = s2.getStatement().getCreatedLValue();
/* 652:717 */     if ((l1 == null) || (l2 == null)) {
/* 653:718 */       return null;
/* 654:    */     }
/* 655:720 */     if (!l2.equals(l1)) {
/* 656:721 */       return null;
/* 657:    */     }
/* 658:723 */     return new DiscoveredTernary(l1, s1.getStatement().getRValue(), s2.getStatement().getRValue(), null);
/* 659:    */   }
/* 660:    */   
/* 661:    */   private static class DiscoveredTernary
/* 662:    */   {
/* 663:    */     LValue lValue;
/* 664:    */     Expression e1;
/* 665:    */     Expression e2;
/* 666:    */     
/* 667:    */     private DiscoveredTernary(LValue lValue, Expression e1, Expression e2)
/* 668:    */     {
/* 669:734 */       this.lValue = lValue;
/* 670:735 */       this.e1 = e1;
/* 671:736 */       this.e2 = e2;
/* 672:    */     }
/* 673:    */     
/* 674:    */     private static Troolean isOneOrZeroLiteral(Expression e)
/* 675:    */     {
/* 676:740 */       if (!(e instanceof Literal)) {
/* 677:740 */         return Troolean.NEITHER;
/* 678:    */       }
/* 679:741 */       TypedLiteral typedLiteral = ((Literal)e).getValue();
/* 680:742 */       Object value = typedLiteral.getValue();
/* 681:743 */       if (!(value instanceof Integer)) {
/* 682:743 */         return Troolean.NEITHER;
/* 683:    */       }
/* 684:744 */       int iValue = ((Integer)value).intValue();
/* 685:745 */       if (iValue == 1) {
/* 686:745 */         return Troolean.TRUE;
/* 687:    */       }
/* 688:746 */       if (iValue == 0) {
/* 689:746 */         return Troolean.FALSE;
/* 690:    */       }
/* 691:747 */       return Troolean.NEITHER;
/* 692:    */     }
/* 693:    */     
/* 694:    */     private boolean isPointlessBoolean()
/* 695:    */     {
/* 696:751 */       if ((this.e1.getInferredJavaType().getRawType() != RawJavaType.BOOLEAN) || (this.e2.getInferredJavaType().getRawType() != RawJavaType.BOOLEAN)) {
/* 697:752 */         return false;
/* 698:    */       }
/* 699:754 */       if (isOneOrZeroLiteral(this.e1) != Troolean.TRUE) {
/* 700:754 */         return false;
/* 701:    */       }
/* 702:755 */       if (isOneOrZeroLiteral(this.e2) != Troolean.FALSE) {
/* 703:755 */         return false;
/* 704:    */       }
/* 705:756 */       return true;
/* 706:    */     }
/* 707:    */   }
/* 708:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter
 * JD-Core Version:    0.7.0.1
 */