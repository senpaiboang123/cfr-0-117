/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers;
/*  2:   */ 
/*  3:   */ import java.util.Map;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CastExpression;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.MemberFunctionInvokation;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/* 14:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/* 15:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/* 16:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 17:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/* 18:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 19:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/* 20:   */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/* 21:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 22:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/* 23:   */ import org.benf.cfr.reader.util.MapFactory;
/* 24:   */ 
/* 25:   */ public class NakedNullCaster
/* 26:   */   implements StructuredStatementTransformer, ExpressionRewriter
/* 27:   */ {
/* 28:   */   public void transform(Op04StructuredStatement root)
/* 29:   */   {
/* 30:26 */     StructuredScope structuredScope = new StructuredScope();
/* 31:27 */     root.transform(this, structuredScope);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public StructuredStatement transform(StructuredStatement in, StructuredScope scope)
/* 35:   */   {
/* 36:32 */     in.transformStructuredChildren(this, scope);
/* 37:33 */     in.rewriteExpressions(this);
/* 38:34 */     return in;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 42:   */   {
/* 43:39 */     if ((expression instanceof MemberFunctionInvokation))
/* 44:   */     {
/* 45:40 */       MemberFunctionInvokation invokation = (MemberFunctionInvokation)expression;
/* 46:41 */       Expression object = invokation.getObject();
/* 47:42 */       if (Literal.NULL.equals(object))
/* 48:   */       {
/* 49:44 */         JavaTypeInstance callType = invokation.getMethodPrototype().getClassType();
/* 50:45 */         Map<Expression, Expression> replace = MapFactory.newMap();
/* 51:46 */         replace.put(object, new CastExpression(new InferredJavaType(callType, InferredJavaType.Source.LITERAL), object));
/* 52:47 */         CloneHelper cloneHelper = new CloneHelper(replace);
/* 53:48 */         expression = (Expression)expression.deepClone(cloneHelper);
/* 54:   */       }
/* 55:   */     }
/* 56:51 */     return expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 57:   */   }
/* 58:   */   
/* 59:   */   public ConditionalExpression rewriteExpression(ConditionalExpression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 60:   */   {
/* 61:56 */     Expression res = expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 62:57 */     return (ConditionalExpression)res;
/* 63:   */   }
/* 64:   */   
/* 65:   */   public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 66:   */   {
/* 67:62 */     return lValue;
/* 68:   */   }
/* 69:   */   
/* 70:   */   public StackSSALabel rewriteExpression(StackSSALabel lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 71:   */   {
/* 72:67 */     return lValue;
/* 73:   */   }
/* 74:   */   
/* 75:   */   public void handleStatement(StatementContainer statementContainer) {}
/* 76:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.NakedNullCaster
 * JD-Core Version:    0.7.0.1
 */