package org.benf.cfr.reader.bytecode.analysis.opgraph;

import java.util.List;

public abstract interface Graph<T>
{
  public abstract List<T> getSources();
  
  public abstract List<T> getTargets();
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.Graph
 * JD-Core Version:    0.7.0.1
 */