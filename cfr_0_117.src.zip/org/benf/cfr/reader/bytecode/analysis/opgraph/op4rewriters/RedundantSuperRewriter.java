/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Set;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.AbstractMatchResultIterator;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.CollectMatch;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.Matcher;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.MiscStatementTools;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/* 14:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.SuperFunctionInvokation;
/* 15:   */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
/* 16:   */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.SuperFunctionInvokationWildcard;
/* 17:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 18:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredDefinition;
/* 19:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredExpressionStatement;
/* 20:   */ import org.benf.cfr.reader.util.Functional;
/* 21:   */ import org.benf.cfr.reader.util.Predicate;
/* 22:   */ 
/* 23:   */ public class RedundantSuperRewriter
/* 24:   */   implements Op04Rewriter
/* 25:   */ {
/* 26:   */   protected List<Expression> getSuperArgs(WildcardMatch wcm)
/* 27:   */   {
/* 28:26 */     return null;
/* 29:   */   }
/* 30:   */   
/* 31:   */   protected Set<LValue> getDeclarationsToNop(WildcardMatch wcm)
/* 32:   */   {
/* 33:30 */     return null;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public void rewrite(Op04StructuredStatement root)
/* 37:   */   {
/* 38:35 */     List<StructuredStatement> structuredStatements = MiscStatementTools.linearise(root);
/* 39:36 */     if (structuredStatements == null) {
/* 40:36 */       return;
/* 41:   */     }
/* 42:38 */     WildcardMatch wcm1 = new WildcardMatch();
/* 43:   */     
/* 44:40 */     Matcher<StructuredStatement> m = new CollectMatch("ass1", new StructuredExpressionStatement(wcm1.getSuperFunction("s1", getSuperArgs(wcm1)), false));
/* 45:   */     
/* 46:   */ 
/* 47:43 */     MatchIterator<StructuredStatement> mi = new MatchIterator(structuredStatements);
/* 48:44 */     MatchResultCollector collector = new SuperResultCollector(wcm1, structuredStatements, null);
/* 49:45 */     while (mi.hasNext())
/* 50:   */     {
/* 51:46 */       mi.advance();
/* 52:47 */       if (m.match(mi, collector)) {}
/* 53:   */     }
/* 54:   */   }
/* 55:   */   
/* 56:   */   protected boolean canBeNopped(SuperFunctionInvokation superInvokation)
/* 57:   */   {
/* 58:55 */     return superInvokation.isEmptyIgnoringSynthetics();
/* 59:   */   }
/* 60:   */   
/* 61:   */   private class SuperResultCollector
/* 62:   */     extends AbstractMatchResultIterator
/* 63:   */   {
/* 64:   */     private final WildcardMatch wcm;
/* 65:   */     private final List<StructuredStatement> structuredStatements;
/* 66:   */     
/* 67:   */     private SuperResultCollector(List<StructuredStatement> wcm)
/* 68:   */     {
/* 69:64 */       this.wcm = wcm;
/* 70:65 */       this.structuredStatements = structuredStatements;
/* 71:   */     }
/* 72:   */     
/* 73:   */     public void clear() {}
/* 74:   */     
/* 75:   */     public void collectStatement(String name, StructuredStatement statement)
/* 76:   */     {
/* 77:75 */       SuperFunctionInvokation superInvokation = this.wcm.getSuperFunction("s1").getMatch();
/* 78:   */       Set<LValue> declarationsToNop;
/* 79:77 */       if (RedundantSuperRewriter.this.canBeNopped(superInvokation))
/* 80:   */       {
/* 81:78 */         statement.getContainer().nopOut();
/* 82:79 */         declarationsToNop = RedundantSuperRewriter.this.getDeclarationsToNop(this.wcm);
/* 83:80 */         if (declarationsToNop != null)
/* 84:   */         {
/* 85:81 */           List<StructuredStatement> decls = Functional.filter(this.structuredStatements, new Predicate()
/* 86:   */           {
/* 87:   */             public boolean test(StructuredStatement in)
/* 88:   */             {
/* 89:84 */               return in instanceof StructuredDefinition;
/* 90:   */             }
/* 91:   */           });
/* 92:87 */           for (StructuredStatement decl : decls)
/* 93:   */           {
/* 94:88 */             StructuredDefinition defn = (StructuredDefinition)decl;
/* 95:89 */             if (declarationsToNop.contains(defn.getLvalue())) {
/* 96:90 */               defn.getContainer().nopOut();
/* 97:   */             }
/* 98:   */           }
/* 99:   */         }
/* :0:   */       }
/* :1:   */     }
/* :2:   */     
/* :3:   */     public void collectMatches(String name, WildcardMatch wcm) {}
/* :4:   */   }
/* :5:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.RedundantSuperRewriter
 * JD-Core Version:    0.7.0.1
 */