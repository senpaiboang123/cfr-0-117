/*    1:     */ package org.benf.cfr.reader.bytecode.analysis.opgraph;
/*    2:     */ 
/*    3:     */ import java.util.Collection;
/*    4:     */ import java.util.Iterator;
/*    5:     */ import java.util.LinkedList;
/*    6:     */ import java.util.List;
/*    7:     */ import java.util.Map;
/*    8:     */ import java.util.Set;
/*    9:     */ import java.util.SortedMap;
/*   10:     */ import java.util.Stack;
/*   11:     */ import java.util.Vector;
/*   12:     */ import java.util.logging.Logger;
/*   13:     */ import org.benf.cfr.reader.bytecode.BytecodeMeta;
/*   14:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.BadCastChainRewriter;
/*   15:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.InnerClassConstructorRewriter;
/*   16:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.LValueReplacingRewriter;
/*   17:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.LambdaRewriter;
/*   18:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.PrimitiveBoxingRewriter;
/*   19:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.RedundantSuperRewriter;
/*   20:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SyntheticAccessorRewriter;
/*   21:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SyntheticOuterRefRewriter;
/*   22:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.VarArgsRewriter;
/*   23:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.checker.Op04Checker;
/*   24:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.BadLoopPrettifier;
/*   25:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.CanRemovePointlessBlock;
/*   26:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.ExpressionRewriterTransformer;
/*   27:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.NakedNullCaster;
/*   28:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*   29:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.TypeAnnotationTransformer;
/*   30:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.TypedBooleanTidier;
/*   31:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.VariableNameTidier;
/*   32:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.VariableNameTidier.NameDiscoverer;
/*   33:     */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.MiscStatementTools;
/*   34:     */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   35:     */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   36:     */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   37:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CastExpression;
/*   38:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationAnonymousInner;
/*   39:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*   40:     */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.FieldVariable;
/*   41:     */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*   42:     */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*   43:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*   44:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockType;
/*   45:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*   46:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Triplet;
/*   47:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/*   48:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscovererImpl;
/*   49:     */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*   50:     */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*   51:     */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.Block;
/*   52:     */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredBreak;
/*   53:     */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredComment;
/*   54:     */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredAnonymousBreak;
/*   55:     */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredCatch;
/*   56:     */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredGoto;
/*   57:     */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredIf;
/*   58:     */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredWhile;
/*   59:     */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*   60:     */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*   61:     */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*   62:     */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*   63:     */ import org.benf.cfr.reader.bytecode.analysis.variables.NamedVariable;
/*   64:     */ import org.benf.cfr.reader.bytecode.analysis.variables.VariableFactory;
/*   65:     */ import org.benf.cfr.reader.entities.AccessFlag;
/*   66:     */ import org.benf.cfr.reader.entities.ClassFile;
/*   67:     */ import org.benf.cfr.reader.entities.ClassFileField;
/*   68:     */ import org.benf.cfr.reader.entities.Method;
/*   69:     */ import org.benf.cfr.reader.entities.attributes.AttributeCode;
/*   70:     */ import org.benf.cfr.reader.entities.attributes.AttributeRuntimeVisibleTypeAnnotations;
/*   71:     */ import org.benf.cfr.reader.state.ClassCache;
/*   72:     */ import org.benf.cfr.reader.state.DCCommonState;
/*   73:     */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*   74:     */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*   75:     */ import org.benf.cfr.reader.util.DecompilerComment;
/*   76:     */ import org.benf.cfr.reader.util.DecompilerComments;
/*   77:     */ import org.benf.cfr.reader.util.ListFactory;
/*   78:     */ import org.benf.cfr.reader.util.MapFactory;
/*   79:     */ import org.benf.cfr.reader.util.SetFactory;
/*   80:     */ import org.benf.cfr.reader.util.StackFactory;
/*   81:     */ import org.benf.cfr.reader.util.TypeUsageCollectable;
/*   82:     */ import org.benf.cfr.reader.util.getopt.Options;
/*   83:     */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*   84:     */ import org.benf.cfr.reader.util.output.Dumpable;
/*   85:     */ import org.benf.cfr.reader.util.output.Dumper;
/*   86:     */ import org.benf.cfr.reader.util.output.LoggerFactory;
/*   87:     */ 
/*   88:     */ public class Op04StructuredStatement
/*   89:     */   implements MutableGraph<Op04StructuredStatement>, Dumpable, StatementContainer<StructuredStatement>, TypeUsageCollectable
/*   90:     */ {
/*   91:  46 */   private static final Logger logger = LoggerFactory.create(Op04StructuredStatement.class);
/*   92:     */   private InstrIndex instrIndex;
/*   93:  50 */   private List<Op04StructuredStatement> sources = ListFactory.newList();
/*   94:  51 */   private List<Op04StructuredStatement> targets = ListFactory.newList();
/*   95:     */   private StructuredStatement structuredStatement;
/*   96:     */   private Set<BlockIdentifier> blockMembership;
/*   97:  59 */   private static final Set<BlockIdentifier> EMPTY_BLOCKSET = SetFactory.newSet();
/*   98:     */   
/*   99:     */   private static Set<BlockIdentifier> blockSet(Collection<BlockIdentifier> in)
/*  100:     */   {
/*  101:  62 */     if ((in == null) || (in.isEmpty())) {
/*  102:  62 */       return EMPTY_BLOCKSET;
/*  103:     */     }
/*  104:  63 */     return SetFactory.newSet(in);
/*  105:     */   }
/*  106:     */   
/*  107:     */   public Op04StructuredStatement(StructuredStatement justStatement)
/*  108:     */   {
/*  109:  69 */     this.structuredStatement = justStatement;
/*  110:  70 */     this.instrIndex = new InstrIndex(-1000);
/*  111:  71 */     this.blockMembership = EMPTY_BLOCKSET;
/*  112:  72 */     justStatement.setContainer(this);
/*  113:     */   }
/*  114:     */   
/*  115:     */   public Op04StructuredStatement(InstrIndex instrIndex, Collection<BlockIdentifier> blockMembership, StructuredStatement structuredStatement)
/*  116:     */   {
/*  117:  79 */     this.instrIndex = instrIndex;
/*  118:  80 */     this.structuredStatement = structuredStatement;
/*  119:  81 */     this.blockMembership = blockSet(blockMembership);
/*  120:  82 */     structuredStatement.setContainer(this);
/*  121:     */   }
/*  122:     */   
/*  123:     */   public Op04StructuredStatement nopThisAndReplace()
/*  124:     */   {
/*  125:  87 */     Op04StructuredStatement replacement = new Op04StructuredStatement(this.instrIndex, this.blockMembership, this.structuredStatement);
/*  126:  88 */     replaceStatementWithNOP("");
/*  127:  89 */     replaceInSources(this, replacement);
/*  128:  90 */     replaceInTargets(this, replacement);
/*  129:  91 */     return replacement;
/*  130:     */   }
/*  131:     */   
/*  132:     */   public void nopThis()
/*  133:     */   {
/*  134:  95 */     replaceStatementWithNOP("");
/*  135:     */   }
/*  136:     */   
/*  137:     */   public StructuredStatement getStatement()
/*  138:     */   {
/*  139: 101 */     return this.structuredStatement;
/*  140:     */   }
/*  141:     */   
/*  142:     */   public void collectTypeUsages(TypeUsageCollector collector)
/*  143:     */   {
/*  144: 106 */     this.structuredStatement.collectTypeUsages(collector);
/*  145:     */   }
/*  146:     */   
/*  147:     */   public StructuredStatement getTargetStatement(int idx)
/*  148:     */   {
/*  149: 111 */     throw new UnsupportedOperationException();
/*  150:     */   }
/*  151:     */   
/*  152:     */   public String getLabel()
/*  153:     */   {
/*  154: 116 */     throw new UnsupportedOperationException();
/*  155:     */   }
/*  156:     */   
/*  157:     */   public InstrIndex getIndex()
/*  158:     */   {
/*  159: 121 */     return this.instrIndex;
/*  160:     */   }
/*  161:     */   
/*  162:     */   public void nopOut()
/*  163:     */   {
/*  164: 126 */     replaceStatementWithNOP("");
/*  165:     */   }
/*  166:     */   
/*  167:     */   public void replaceStatement(StructuredStatement newTarget)
/*  168:     */   {
/*  169: 131 */     this.structuredStatement = newTarget;
/*  170:     */   }
/*  171:     */   
/*  172:     */   public void nopOutConditional()
/*  173:     */   {
/*  174: 136 */     throw new UnsupportedOperationException();
/*  175:     */   }
/*  176:     */   
/*  177:     */   public SSAIdentifiers getSSAIdentifiers()
/*  178:     */   {
/*  179: 141 */     throw new UnsupportedOperationException();
/*  180:     */   }
/*  181:     */   
/*  182:     */   public Set<BlockIdentifier> getBlockIdentifiers()
/*  183:     */   {
/*  184: 146 */     return this.blockMembership;
/*  185:     */   }
/*  186:     */   
/*  187:     */   public BlockIdentifier getBlockStarted()
/*  188:     */   {
/*  189: 151 */     throw new UnsupportedOperationException();
/*  190:     */   }
/*  191:     */   
/*  192:     */   public Set<BlockIdentifier> getBlocksEnded()
/*  193:     */   {
/*  194: 156 */     throw new UnsupportedOperationException();
/*  195:     */   }
/*  196:     */   
/*  197:     */   public void copyBlockInformationFrom(StatementContainer<StructuredStatement> other)
/*  198:     */   {
/*  199: 161 */     throw new UnsupportedOperationException();
/*  200:     */   }
/*  201:     */   
/*  202:     */   private boolean hasUnstructuredSource()
/*  203:     */   {
/*  204: 166 */     for (Op04StructuredStatement source : this.sources) {
/*  205: 167 */       if (!source.structuredStatement.isProperlyStructured()) {
/*  206: 168 */         return true;
/*  207:     */       }
/*  208:     */     }
/*  209: 171 */     return false;
/*  210:     */   }
/*  211:     */   
/*  212:     */   public Collection<BlockIdentifier> getBlockMembership()
/*  213:     */   {
/*  214: 176 */     return this.blockMembership;
/*  215:     */   }
/*  216:     */   
/*  217:     */   public Dumper dump(Dumper dumper)
/*  218:     */   {
/*  219: 181 */     if (hasUnstructuredSource()) {
/*  220: 182 */       dumper.printLabel(this.instrIndex.toString() + ": // " + this.sources.size() + " sources");
/*  221:     */     }
/*  222: 184 */     this.structuredStatement.dump(dumper);
/*  223: 185 */     return dumper;
/*  224:     */   }
/*  225:     */   
/*  226:     */   public List<Op04StructuredStatement> getSources()
/*  227:     */   {
/*  228: 190 */     return this.sources;
/*  229:     */   }
/*  230:     */   
/*  231:     */   public List<Op04StructuredStatement> getTargets()
/*  232:     */   {
/*  233: 195 */     return this.targets;
/*  234:     */   }
/*  235:     */   
/*  236:     */   public void addSource(Op04StructuredStatement source)
/*  237:     */   {
/*  238: 200 */     this.sources.add(source);
/*  239:     */   }
/*  240:     */   
/*  241:     */   public void addTarget(Op04StructuredStatement target)
/*  242:     */   {
/*  243: 205 */     this.targets.add(target);
/*  244:     */   }
/*  245:     */   
/*  246:     */   public String getTargetLabel(int idx)
/*  247:     */   {
/*  248: 209 */     return ((Op04StructuredStatement)this.targets.get(idx)).instrIndex.toString();
/*  249:     */   }
/*  250:     */   
/*  251:     */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer)
/*  252:     */   {
/*  253: 213 */     this.structuredStatement.traceLocalVariableScope(scopeDiscoverer);
/*  254:     */   }
/*  255:     */   
/*  256:     */   private void replaceAsSource(Op04StructuredStatement old)
/*  257:     */   {
/*  258: 221 */     replaceInSources(old, this);
/*  259: 222 */     addTarget(old);
/*  260: 223 */     old.addSource(this);
/*  261:     */   }
/*  262:     */   
/*  263:     */   public void replaceTarget(Op04StructuredStatement from, Op04StructuredStatement to)
/*  264:     */   {
/*  265: 227 */     int index = this.targets.indexOf(from);
/*  266: 228 */     if (index == -1) {
/*  267: 229 */       throw new ConfusedCFRException("Invalid target.  Trying to replace " + from + " -> " + to);
/*  268:     */     }
/*  269: 231 */     this.targets.set(index, to);
/*  270:     */   }
/*  271:     */   
/*  272:     */   public void replaceSource(Op04StructuredStatement from, Op04StructuredStatement to)
/*  273:     */   {
/*  274: 235 */     int index = this.sources.indexOf(from);
/*  275: 236 */     if (index == -1) {
/*  276: 237 */       throw new ConfusedCFRException("Invalid source");
/*  277:     */     }
/*  278: 239 */     this.sources.set(index, to);
/*  279:     */   }
/*  280:     */   
/*  281:     */   public void setSources(List<Op04StructuredStatement> sources)
/*  282:     */   {
/*  283: 243 */     this.sources = sources;
/*  284:     */   }
/*  285:     */   
/*  286:     */   public void setTargets(List<Op04StructuredStatement> targets)
/*  287:     */   {
/*  288: 247 */     this.targets = targets;
/*  289:     */   }
/*  290:     */   
/*  291:     */   public static void replaceInSources(Op04StructuredStatement original, Op04StructuredStatement replacement)
/*  292:     */   {
/*  293: 251 */     for (Op04StructuredStatement source : original.getSources()) {
/*  294: 252 */       source.replaceTarget(original, replacement);
/*  295:     */     }
/*  296: 254 */     replacement.setSources(original.getSources());
/*  297: 255 */     original.setSources(ListFactory.newList());
/*  298:     */   }
/*  299:     */   
/*  300:     */   public static void replaceInTargets(Op04StructuredStatement original, Op04StructuredStatement replacement)
/*  301:     */   {
/*  302: 259 */     for (Op04StructuredStatement target : original.getTargets()) {
/*  303: 260 */       target.replaceSource(original, replacement);
/*  304:     */     }
/*  305: 262 */     replacement.setTargets(original.getTargets());
/*  306: 263 */     original.setTargets(ListFactory.newList());
/*  307:     */   }
/*  308:     */   
/*  309:     */   public void linearizeStatementsInto(List<StructuredStatement> out)
/*  310:     */   {
/*  311: 271 */     this.structuredStatement.linearizeInto(out);
/*  312:     */   }
/*  313:     */   
/*  314:     */   public void removeLastContinue(BlockIdentifier block)
/*  315:     */   {
/*  316: 275 */     if ((this.structuredStatement instanceof Block))
/*  317:     */     {
/*  318: 276 */       boolean removed = ((Block)this.structuredStatement).removeLastContinue(block);
/*  319: 277 */       logger.info("Removing last continue for " + block + " succeeded? " + removed);
/*  320:     */     }
/*  321:     */     else
/*  322:     */     {
/*  323: 279 */       throw new ConfusedCFRException("Trying to remove last continue, but statement isn't block");
/*  324:     */     }
/*  325:     */   }
/*  326:     */   
/*  327:     */   public void removeLastGoto()
/*  328:     */   {
/*  329: 284 */     if ((this.structuredStatement instanceof Block)) {
/*  330: 285 */       ((Block)this.structuredStatement).removeLastGoto();
/*  331:     */     } else {
/*  332: 287 */       throw new ConfusedCFRException("Trying to remove last goto, but statement isn't a block!");
/*  333:     */     }
/*  334:     */   }
/*  335:     */   
/*  336:     */   public void removeLastGoto(Op04StructuredStatement toHere)
/*  337:     */   {
/*  338: 292 */     if ((this.structuredStatement instanceof Block)) {
/*  339: 293 */       ((Block)this.structuredStatement).removeLastGoto(toHere);
/*  340:     */     } else {
/*  341: 295 */       throw new ConfusedCFRException("Trying to remove last goto, but statement isn't a block!");
/*  342:     */     }
/*  343:     */   }
/*  344:     */   
/*  345:     */   public UnstructuredWhile removeLastEndWhile()
/*  346:     */   {
/*  347: 300 */     if ((this.structuredStatement instanceof Block)) {
/*  348: 301 */       return ((Block)this.structuredStatement).removeLastEndWhile();
/*  349:     */     }
/*  350: 303 */     return null;
/*  351:     */   }
/*  352:     */   
/*  353:     */   public void informBlockMembership(Vector<BlockIdentifier> currentlyIn)
/*  354:     */   {
/*  355: 308 */     StructuredStatement replacement = this.structuredStatement.informBlockHeirachy(currentlyIn);
/*  356: 309 */     if (replacement == null) {
/*  357: 309 */       return;
/*  358:     */     }
/*  359: 310 */     this.structuredStatement = replacement;
/*  360: 311 */     replacement.setContainer(this);
/*  361:     */   }
/*  362:     */   
/*  363:     */   public String toString()
/*  364:     */   {
/*  365: 316 */     return this.structuredStatement.toString();
/*  366:     */   }
/*  367:     */   
/*  368:     */   public void replaceStatementWithNOP(String comment)
/*  369:     */   {
/*  370: 321 */     this.structuredStatement = new StructuredComment(comment);
/*  371: 322 */     this.structuredStatement.setContainer(this);
/*  372:     */   }
/*  373:     */   
/*  374:     */   private boolean claimBlock(Op04StructuredStatement innerBlock, BlockIdentifier thisBlock, Vector<BlockIdentifier> currentlyIn)
/*  375:     */   {
/*  376: 326 */     int idx = this.targets.indexOf(innerBlock);
/*  377: 327 */     if (idx == -1) {
/*  378: 328 */       return false;
/*  379:     */     }
/*  380: 330 */     StructuredStatement replacement = this.structuredStatement.claimBlock(innerBlock, thisBlock, currentlyIn);
/*  381: 331 */     if (replacement == null) {
/*  382: 331 */       return false;
/*  383:     */     }
/*  384: 332 */     this.structuredStatement = replacement;
/*  385: 333 */     replacement.setContainer(this);
/*  386: 334 */     return true;
/*  387:     */   }
/*  388:     */   
/*  389:     */   public void replaceContainedStatement(StructuredStatement structuredStatement)
/*  390:     */   {
/*  391: 338 */     this.structuredStatement = structuredStatement;
/*  392: 339 */     this.structuredStatement.setContainer(this);
/*  393:     */   }
/*  394:     */   
/*  395:     */   private static class StackedBlock
/*  396:     */   {
/*  397:     */     BlockIdentifier blockIdentifier;
/*  398:     */     LinkedList<Op04StructuredStatement> statements;
/*  399:     */     Op04StructuredStatement outerStart;
/*  400:     */     
/*  401:     */     private StackedBlock(BlockIdentifier blockIdentifier, LinkedList<Op04StructuredStatement> statements, Op04StructuredStatement outerStart)
/*  402:     */     {
/*  403: 348 */       this.blockIdentifier = blockIdentifier;
/*  404: 349 */       this.statements = statements;
/*  405: 350 */       this.outerStart = outerStart;
/*  406:     */     }
/*  407:     */   }
/*  408:     */   
/*  409:     */   private static Set<BlockIdentifier> getEndingBlocks(Stack<BlockIdentifier> wasIn, Set<BlockIdentifier> nowIn)
/*  410:     */   {
/*  411: 359 */     Set<BlockIdentifier> wasCopy = SetFactory.newSet(wasIn);
/*  412: 360 */     wasCopy.removeAll(nowIn);
/*  413: 361 */     return wasCopy;
/*  414:     */   }
/*  415:     */   
/*  416:     */   private static BlockIdentifier getStartingBlocks(Stack<BlockIdentifier> wasIn, Set<BlockIdentifier> nowIn)
/*  417:     */   {
/*  418: 369 */     if (nowIn.size() <= wasIn.size()) {
/*  419: 369 */       return null;
/*  420:     */     }
/*  421: 370 */     Set<BlockIdentifier> nowCopy = SetFactory.newSet(nowIn);
/*  422: 371 */     nowCopy.removeAll(wasIn);
/*  423: 372 */     if (nowCopy.size() != 1) {
/*  424: 374 */       throw new ConfusedCFRException("Started " + nowCopy.size() + " blocks at once");
/*  425:     */     }
/*  426: 376 */     return (BlockIdentifier)nowCopy.iterator().next();
/*  427:     */   }
/*  428:     */   
/*  429:     */   private static class MutableProcessingBlockState
/*  430:     */   {
/*  431: 380 */     BlockIdentifier currentBlockIdentifier = null;
/*  432: 381 */     LinkedList<Op04StructuredStatement> currentBlock = ListFactory.newLinkedList();
/*  433:     */   }
/*  434:     */   
/*  435:     */   public static void processEndingBlocks(Set<BlockIdentifier> endOfTheseBlocks, Stack<BlockIdentifier> blocksCurrentlyIn, Stack<StackedBlock> stackedBlocks, MutableProcessingBlockState mutableProcessingBlockState)
/*  436:     */   {
/*  437: 389 */     logger.fine("statement is last statement in these blocks " + endOfTheseBlocks);
/*  438: 391 */     while (!endOfTheseBlocks.isEmpty())
/*  439:     */     {
/*  440: 392 */       if (mutableProcessingBlockState.currentBlockIdentifier == null) {
/*  441: 393 */         throw new ConfusedCFRException("Trying to end block, but not in any!");
/*  442:     */       }
/*  443: 396 */       if (!endOfTheseBlocks.remove(mutableProcessingBlockState.currentBlockIdentifier)) {
/*  444: 397 */         throw new ConfusedCFRException("Tried to end blocks " + endOfTheseBlocks + ", but top level block is " + mutableProcessingBlockState.currentBlockIdentifier);
/*  445:     */       }
/*  446: 399 */       BlockIdentifier popBlockIdentifier = (BlockIdentifier)blocksCurrentlyIn.pop();
/*  447: 400 */       if (popBlockIdentifier != mutableProcessingBlockState.currentBlockIdentifier) {
/*  448: 401 */         throw new ConfusedCFRException("Tried to end blocks " + endOfTheseBlocks + ", but top level block is " + mutableProcessingBlockState.currentBlockIdentifier);
/*  449:     */       }
/*  450: 403 */       LinkedList<Op04StructuredStatement> blockJustEnded = mutableProcessingBlockState.currentBlock;
/*  451: 404 */       StackedBlock popBlock = (StackedBlock)stackedBlocks.pop();
/*  452: 405 */       mutableProcessingBlockState.currentBlock = popBlock.statements;
/*  453:     */       
/*  454: 407 */       Op04StructuredStatement finishedBlock = new Op04StructuredStatement(new Block(blockJustEnded, true));
/*  455: 408 */       finishedBlock.replaceAsSource((Op04StructuredStatement)blockJustEnded.getFirst());
/*  456: 409 */       Op04StructuredStatement blockStartContainer = popBlock.outerStart;
/*  457: 411 */       if (!blockStartContainer.claimBlock(finishedBlock, mutableProcessingBlockState.currentBlockIdentifier, blocksCurrentlyIn)) {
/*  458: 412 */         mutableProcessingBlockState.currentBlock.add(finishedBlock);
/*  459:     */       }
/*  460: 414 */       mutableProcessingBlockState.currentBlockIdentifier = popBlock.blockIdentifier;
/*  461:     */     }
/*  462:     */   }
/*  463:     */   
/*  464:     */   public boolean isFullyStructured()
/*  465:     */   {
/*  466: 419 */     return this.structuredStatement.isRecursivelyStructured();
/*  467:     */   }
/*  468:     */   
/*  469:     */   public static Op04StructuredStatement buildNestedBlocks(List<Op04StructuredStatement> containers)
/*  470:     */   {
/*  471: 431 */     Stack<BlockIdentifier> blocksCurrentlyIn = StackFactory.newStack();
/*  472: 432 */     LinkedList<Op04StructuredStatement> outerBlock = ListFactory.newLinkedList();
/*  473: 433 */     Stack<StackedBlock> stackedBlocks = StackFactory.newStack();
/*  474:     */     
/*  475: 435 */     MutableProcessingBlockState mutableProcessingBlockState = new MutableProcessingBlockState(null);
/*  476: 436 */     mutableProcessingBlockState.currentBlock = outerBlock;
/*  477: 438 */     for (Op04StructuredStatement container : containers)
/*  478:     */     {
/*  479: 447 */       Set<BlockIdentifier> endOfTheseBlocks = getEndingBlocks(blocksCurrentlyIn, container.blockMembership);
/*  480: 448 */       if (!endOfTheseBlocks.isEmpty()) {
/*  481: 449 */         processEndingBlocks(endOfTheseBlocks, blocksCurrentlyIn, stackedBlocks, mutableProcessingBlockState);
/*  482:     */       }
/*  483: 452 */       BlockIdentifier startsThisBlock = getStartingBlocks(blocksCurrentlyIn, container.blockMembership);
/*  484: 453 */       if (startsThisBlock != null)
/*  485:     */       {
/*  486: 454 */         logger.fine("Starting block " + startsThisBlock);
/*  487: 455 */         BlockType blockType = startsThisBlock.getBlockType();
/*  488:     */         
/*  489:     */ 
/*  490:     */ 
/*  491: 459 */         Op04StructuredStatement blockClaimer = (Op04StructuredStatement)mutableProcessingBlockState.currentBlock.getLast();
/*  492:     */         
/*  493: 461 */         stackedBlocks.push(new StackedBlock(mutableProcessingBlockState.currentBlockIdentifier, mutableProcessingBlockState.currentBlock, blockClaimer, null));
/*  494: 462 */         mutableProcessingBlockState.currentBlock = ListFactory.newLinkedList();
/*  495: 463 */         mutableProcessingBlockState.currentBlockIdentifier = startsThisBlock;
/*  496: 464 */         blocksCurrentlyIn.push(mutableProcessingBlockState.currentBlockIdentifier);
/*  497:     */       }
/*  498: 467 */       container.informBlockMembership(blocksCurrentlyIn);
/*  499: 468 */       mutableProcessingBlockState.currentBlock.add(container);
/*  500:     */     }
/*  501: 475 */     if (!stackedBlocks.isEmpty()) {
/*  502: 476 */       processEndingBlocks(SetFactory.newSet(blocksCurrentlyIn), blocksCurrentlyIn, stackedBlocks, mutableProcessingBlockState);
/*  503:     */     }
/*  504: 478 */     Block result = new Block(outerBlock, true);
/*  505: 479 */     return new Op04StructuredStatement(result);
/*  506:     */   }
/*  507:     */   
/*  508:     */   private static class LabelledBlockExtractor
/*  509:     */     implements StructuredStatementTransformer
/*  510:     */   {
/*  511:     */     public StructuredStatement transform(StructuredStatement in, StructuredScope scope)
/*  512:     */     {
/*  513: 486 */       if ((in instanceof Block))
/*  514:     */       {
/*  515: 487 */         Block block = (Block)in;
/*  516: 488 */         block.extractLabelledBlocks();
/*  517:     */       }
/*  518: 490 */       in.transformStructuredChildren(this, scope);
/*  519: 491 */       return in;
/*  520:     */     }
/*  521:     */   }
/*  522:     */   
/*  523:     */   private static class EmptyCatchTidier
/*  524:     */     implements StructuredStatementTransformer
/*  525:     */   {
/*  526:     */     public StructuredStatement transform(StructuredStatement in, StructuredScope scope)
/*  527:     */     {
/*  528: 498 */       if ((in instanceof UnstructuredCatch)) {
/*  529: 499 */         return ((UnstructuredCatch)in).getCatchForEmpty();
/*  530:     */       }
/*  531: 501 */       in.transformStructuredChildren(this, scope);
/*  532: 502 */       return in;
/*  533:     */     }
/*  534:     */   }
/*  535:     */   
/*  536:     */   private static class TryCatchTidier
/*  537:     */     implements StructuredStatementTransformer
/*  538:     */   {
/*  539:     */     public StructuredStatement transform(StructuredStatement in, StructuredScope scope)
/*  540:     */     {
/*  541: 509 */       if ((in instanceof Block))
/*  542:     */       {
/*  543: 511 */         Block block = (Block)in;
/*  544: 512 */         block.combineTryCatch();
/*  545:     */       }
/*  546: 514 */       in.transformStructuredChildren(this, scope);
/*  547: 515 */       return in;
/*  548:     */     }
/*  549:     */   }
/*  550:     */   
/*  551:     */   private static class Inliner
/*  552:     */     implements StructuredStatementTransformer
/*  553:     */   {
/*  554:     */     public StructuredStatement transform(StructuredStatement in, StructuredScope scope)
/*  555:     */     {
/*  556: 522 */       in.transformStructuredChildren(this, scope);
/*  557: 523 */       if ((in instanceof Block))
/*  558:     */       {
/*  559: 524 */         Block block = (Block)in;
/*  560: 525 */         block.combineInlineable();
/*  561:     */       }
/*  562: 527 */       return in;
/*  563:     */     }
/*  564:     */   }
/*  565:     */   
/*  566:     */   public static class UnstructuredIfConverter
/*  567:     */     implements StructuredStatementTransformer
/*  568:     */   {
/*  569:     */     public StructuredStatement transform(StructuredStatement in, StructuredScope scope)
/*  570:     */     {
/*  571: 537 */       in.transformStructuredChildren(this, scope);
/*  572: 538 */       if ((in instanceof UnstructuredIf)) {
/*  573: 539 */         in = ((UnstructuredIf)in).convertEmptyToGoto();
/*  574:     */       }
/*  575: 541 */       return in;
/*  576:     */     }
/*  577:     */   }
/*  578:     */   
/*  579:     */   public static StructuredStatement transformStructuredGotoWithScope(StructuredScope scope, StructuredStatement stm, Stack<Triplet<StructuredStatement, BlockIdentifier, Set<Op04StructuredStatement>>> breaktargets)
/*  580:     */   {
/*  581: 548 */     Set<Op04StructuredStatement> nextFallThrough = scope.getNextFallThrough(stm);
/*  582: 549 */     List<Op04StructuredStatement> targets = stm.getContainer().getTargets();
/*  583:     */     
/*  584: 551 */     Op04StructuredStatement target = targets.isEmpty() ? null : (Op04StructuredStatement)targets.get(0);
/*  585: 552 */     if (nextFallThrough.contains(target))
/*  586:     */     {
/*  587: 556 */       if (scope.statementIsLast(stm)) {
/*  588: 557 */         return new StructuredComment("");
/*  589:     */       }
/*  590: 558 */       if (scope.getDirectFallThrough(stm).contains(target)) {
/*  591: 559 */         return new StructuredComment("");
/*  592:     */       }
/*  593: 561 */       return stm;
/*  594:     */     }
/*  595: 563 */     if (!breaktargets.isEmpty())
/*  596:     */     {
/*  597: 565 */       Triplet<StructuredStatement, BlockIdentifier, Set<Op04StructuredStatement>> breakTarget = (Triplet)breaktargets.peek();
/*  598: 566 */       if (((Set)breakTarget.getThird()).contains(target)) {
/*  599: 567 */         return new StructuredBreak((BlockIdentifier)breakTarget.getSecond(), true);
/*  600:     */       }
/*  601:     */     }
/*  602: 570 */     return stm;
/*  603:     */   }
/*  604:     */   
/*  605:     */   private static abstract class ScopeDescendingTransformer
/*  606:     */     implements StructuredStatementTransformer
/*  607:     */   {
/*  608: 576 */     private final Stack<Triplet<StructuredStatement, BlockIdentifier, Set<Op04StructuredStatement>>> targets = new Stack();
/*  609:     */     
/*  610:     */     protected abstract StructuredStatement doTransform(StructuredStatement paramStructuredStatement, Stack<Triplet<StructuredStatement, BlockIdentifier, Set<Op04StructuredStatement>>> paramStack, StructuredScope paramStructuredScope);
/*  611:     */     
/*  612:     */     public StructuredStatement transform(StructuredStatement in, StructuredScope scope)
/*  613:     */     {
/*  614: 586 */       BlockIdentifier breakableBlock = in.getBreakableBlockOrNull();
/*  615: 587 */       if (breakableBlock != null)
/*  616:     */       {
/*  617: 588 */         Set<Op04StructuredStatement> next = scope.getNextFallThrough(in);
/*  618: 589 */         this.targets.push(Triplet.make(in, breakableBlock, next));
/*  619:     */       }
/*  620: 591 */       StructuredStatement out = in;
/*  621:     */       try
/*  622:     */       {
/*  623: 593 */         out.transformStructuredChildrenInReverse(this, scope);
/*  624: 594 */         out = doTransform(out, this.targets, scope);
/*  625: 595 */         if ((out instanceof StructuredBreak)) {
/*  626: 596 */           out = ((StructuredBreak)out).maybeTightenToLocal(this.targets);
/*  627:     */         }
/*  628:     */       }
/*  629:     */       finally
/*  630:     */       {
/*  631: 599 */         if (breakableBlock != null) {
/*  632: 600 */           this.targets.pop();
/*  633:     */         }
/*  634:     */       }
/*  635: 603 */       return out;
/*  636:     */     }
/*  637:     */   }
/*  638:     */   
/*  639:     */   private static class StructuredGotoRemover
/*  640:     */     extends Op04StructuredStatement.ScopeDescendingTransformer
/*  641:     */   {
/*  642:     */     private StructuredGotoRemover()
/*  643:     */     {
/*  644: 608 */       super();
/*  645:     */     }
/*  646:     */     
/*  647:     */     protected StructuredStatement doTransform(StructuredStatement statement, Stack<Triplet<StructuredStatement, BlockIdentifier, Set<Op04StructuredStatement>>> targets, StructuredScope scope)
/*  648:     */     {
/*  649: 611 */       if (((statement instanceof UnstructuredGoto)) || ((statement instanceof UnstructuredAnonymousBreak))) {
/*  650: 613 */         statement = Op04StructuredStatement.transformStructuredGotoWithScope(scope, statement, targets);
/*  651:     */       }
/*  652: 615 */       return statement;
/*  653:     */     }
/*  654:     */   }
/*  655:     */   
/*  656:     */   private static class NamedBreakRemover
/*  657:     */     extends Op04StructuredStatement.ScopeDescendingTransformer
/*  658:     */   {
/*  659:     */     private NamedBreakRemover()
/*  660:     */     {
/*  661: 619 */       super();
/*  662:     */     }
/*  663:     */     
/*  664:     */     protected StructuredStatement doTransform(StructuredStatement statement, Stack<Triplet<StructuredStatement, BlockIdentifier, Set<Op04StructuredStatement>>> targets, StructuredScope scope)
/*  665:     */     {
/*  666: 622 */       if ((statement instanceof StructuredBreak)) {
/*  667: 623 */         statement = ((StructuredBreak)statement).maybeTightenToLocal(targets);
/*  668:     */       }
/*  669: 625 */       return statement;
/*  670:     */     }
/*  671:     */   }
/*  672:     */   
/*  673:     */   private static class PointlessBlockRemover
/*  674:     */     implements StructuredStatementTransformer
/*  675:     */   {
/*  676:     */     public StructuredStatement transform(StructuredStatement in, StructuredScope scope)
/*  677:     */     {
/*  678: 632 */       in.transformStructuredChildren(this, scope);
/*  679: 633 */       if ((in instanceof CanRemovePointlessBlock)) {
/*  680: 634 */         ((CanRemovePointlessBlock)in).removePointlessBlocks(scope);
/*  681:     */       }
/*  682: 636 */       return in;
/*  683:     */     }
/*  684:     */   }
/*  685:     */   
/*  686:     */   public void transform(StructuredStatementTransformer transformer, StructuredScope scope)
/*  687:     */   {
/*  688: 641 */     StructuredStatement old = this.structuredStatement;
/*  689: 642 */     this.structuredStatement = transformer.transform(this.structuredStatement, scope);
/*  690: 643 */     if ((this.structuredStatement != old) && (this.structuredStatement != null)) {
/*  691: 644 */       this.structuredStatement.setContainer(this);
/*  692:     */     }
/*  693:     */   }
/*  694:     */   
/*  695:     */   public static void insertLabelledBlocks(Op04StructuredStatement root)
/*  696:     */   {
/*  697: 652 */     root.transform(new LabelledBlockExtractor(null), new StructuredScope());
/*  698:     */   }
/*  699:     */   
/*  700:     */   public static void tidyEmptyCatch(Op04StructuredStatement root)
/*  701:     */   {
/*  702: 660 */     root.transform(new EmptyCatchTidier(null), new StructuredScope());
/*  703:     */   }
/*  704:     */   
/*  705:     */   public static void tidyTryCatch(Op04StructuredStatement root)
/*  706:     */   {
/*  707: 664 */     root.transform(new TryCatchTidier(null), new StructuredScope());
/*  708:     */   }
/*  709:     */   
/*  710:     */   public static void inlinePossibles(Op04StructuredStatement root)
/*  711:     */   {
/*  712: 668 */     root.transform(new Inliner(null), new StructuredScope());
/*  713:     */   }
/*  714:     */   
/*  715:     */   public static void convertUnstructuredIf(Op04StructuredStatement root)
/*  716:     */   {
/*  717: 672 */     root.transform(new UnstructuredIfConverter(), new StructuredScope());
/*  718:     */   }
/*  719:     */   
/*  720:     */   public static void tidyVariableNames(Method method, Op04StructuredStatement root, BytecodeMeta bytecodeMeta, DecompilerComments comments, ClassCache classCache)
/*  721:     */   {
/*  722: 676 */     VariableNameTidier variableNameTidier = new VariableNameTidier(method, VariableNameTidier.NameDiscoverer.getUsedLambdaNames(bytecodeMeta, root), classCache);
/*  723: 677 */     variableNameTidier.transform(root);
/*  724: 679 */     if (variableNameTidier.isClassRenamed()) {
/*  725: 680 */       comments.addComment(DecompilerComment.CLASS_RENAMED);
/*  726:     */     }
/*  727:     */   }
/*  728:     */   
/*  729:     */   public static void applyTypeAnnotations(AttributeCode code, Op04StructuredStatement root, SortedMap<Integer, Integer> instrsByOffset, DecompilerComments comments)
/*  730:     */   {
/*  731: 686 */     AttributeRuntimeVisibleTypeAnnotations typeAnnotations = code.getRuntimeVisibleTypeAnnotations();
/*  732: 687 */     if (typeAnnotations == null) {
/*  733: 687 */       return;
/*  734:     */     }
/*  735: 688 */     TypeAnnotationTransformer transformer = new TypeAnnotationTransformer(typeAnnotations, instrsByOffset, comments);
/*  736: 689 */     transformer.transform(root);
/*  737:     */   }
/*  738:     */   
/*  739:     */   public static void removePointlessReturn(Op04StructuredStatement root)
/*  740:     */   {
/*  741: 693 */     StructuredStatement statement = root.getStatement();
/*  742: 694 */     if ((statement instanceof Block))
/*  743:     */     {
/*  744: 695 */       Block block = (Block)statement;
/*  745: 696 */       block.removeLastNVReturn();
/*  746:     */     }
/*  747:     */   }
/*  748:     */   
/*  749:     */   public static void tidyTypedBooleans(Op04StructuredStatement root)
/*  750:     */   {
/*  751: 702 */     new TypedBooleanTidier().transform(root);
/*  752:     */   }
/*  753:     */   
/*  754:     */   public static void miscKeyholeTransforms(Op04StructuredStatement root)
/*  755:     */   {
/*  756: 706 */     new NakedNullCaster().transform(root);
/*  757:     */   }
/*  758:     */   
/*  759:     */   public static void prettifyBadLoops(Op04StructuredStatement root)
/*  760:     */   {
/*  761: 710 */     new BadLoopPrettifier().transform(root);
/*  762:     */   }
/*  763:     */   
/*  764:     */   public static void removeStructuredGotos(Op04StructuredStatement root)
/*  765:     */   {
/*  766: 714 */     root.transform(new StructuredGotoRemover(null), new StructuredScope());
/*  767:     */   }
/*  768:     */   
/*  769:     */   public static void removeUnnecessaryLabelledBreaks(Op04StructuredStatement root)
/*  770:     */   {
/*  771: 743 */     root.transform(new NamedBreakRemover(null), new StructuredScope());
/*  772:     */   }
/*  773:     */   
/*  774:     */   public static void removePointlessBlocks(Op04StructuredStatement root)
/*  775:     */   {
/*  776: 747 */     root.transform(new PointlessBlockRemover(null), new StructuredScope());
/*  777:     */   }
/*  778:     */   
/*  779:     */   public static void discoverVariableScopes(Method method, Op04StructuredStatement root, VariableFactory variableFactory)
/*  780:     */   {
/*  781: 761 */     LValueScopeDiscovererImpl scopeDiscoverer = new LValueScopeDiscovererImpl(method.getMethodPrototype(), variableFactory);
/*  782: 762 */     root.traceLocalVariableScope(scopeDiscoverer);
/*  783:     */     
/*  784: 764 */     scopeDiscoverer.markDiscoveredCreations();
/*  785:     */   }
/*  786:     */   
/*  787:     */   public static class LValueTypeClashCheck
/*  788:     */     implements LValueScopeDiscoverer, StructuredStatementTransformer
/*  789:     */   {
/*  790: 769 */     Set<Integer> clashes = SetFactory.newSet();
/*  791:     */     
/*  792:     */     public void enterBlock(StructuredStatement structuredStatement) {}
/*  793:     */     
/*  794:     */     public void leaveBlock(StructuredStatement structuredStatement) {}
/*  795:     */     
/*  796:     */     public void collect(StackSSALabel lValue, StatementContainer<StructuredStatement> statementContainer, Expression value)
/*  797:     */     {
/*  798: 781 */       collect(lValue);
/*  799:     */     }
/*  800:     */     
/*  801:     */     public void collectMultiUse(StackSSALabel lValue, StatementContainer<StructuredStatement> statementContainer, Expression value)
/*  802:     */     {
/*  803: 786 */       collect(lValue);
/*  804:     */     }
/*  805:     */     
/*  806:     */     public void collectMutatedLValue(LValue lValue, StatementContainer<StructuredStatement> statementContainer, Expression value)
/*  807:     */     {
/*  808: 791 */       collect(lValue);
/*  809:     */     }
/*  810:     */     
/*  811:     */     public void collectLocalVariableAssignment(LocalVariable localVariable, StatementContainer<StructuredStatement> statementContainer, Expression value)
/*  812:     */     {
/*  813: 796 */       collect(localVariable);
/*  814:     */     }
/*  815:     */     
/*  816:     */     public void collect(LValue lValue)
/*  817:     */     {
/*  818: 800 */       lValue.collectLValueUsage(this);
/*  819: 801 */       InferredJavaType inferredJavaType = lValue.getInferredJavaType();
/*  820: 802 */       if ((inferredJavaType != null) && 
/*  821: 803 */         ((inferredJavaType.isClash()) || (inferredJavaType.getJavaTypeInstance() == RawJavaType.REF)) && 
/*  822: 804 */         ((lValue instanceof LocalVariable)))
/*  823:     */       {
/*  824: 805 */         int idx = ((LocalVariable)lValue).getIdx();
/*  825: 806 */         if (idx >= 0) {
/*  826: 806 */           this.clashes.add(Integer.valueOf(idx));
/*  827:     */         }
/*  828:     */       }
/*  829:     */     }
/*  830:     */     
/*  831:     */     public StructuredStatement transform(StructuredStatement in, StructuredScope scope)
/*  832:     */     {
/*  833: 814 */       in.traceLocalVariableScope(this);
/*  834: 815 */       in.transformStructuredChildren(this, scope);
/*  835: 816 */       return in;
/*  836:     */     }
/*  837:     */   }
/*  838:     */   
/*  839:     */   public static boolean checkTypeClashes(Op04StructuredStatement block, BytecodeMeta bytecodeMeta)
/*  840:     */   {
/*  841: 821 */     LValueTypeClashCheck clashCheck = new LValueTypeClashCheck();
/*  842: 822 */     block.traceLocalVariableScope(clashCheck);
/*  843: 823 */     if (!clashCheck.clashes.isEmpty())
/*  844:     */     {
/*  845: 824 */       bytecodeMeta.informLivenessClashes(clashCheck.clashes);
/*  846: 825 */       return true;
/*  847:     */     }
/*  848: 827 */     return false;
/*  849:     */   }
/*  850:     */   
/*  851:     */   public static FieldVariable findInnerClassOuterThis(Method method, Op04StructuredStatement root)
/*  852:     */   {
/*  853: 832 */     MethodPrototype prototype = method.getMethodPrototype();
/*  854:     */     
/*  855: 834 */     List<LocalVariable> vars = prototype.getComputedParameters();
/*  856: 835 */     if (vars.isEmpty()) {
/*  857: 835 */       return null;
/*  858:     */     }
/*  859: 837 */     LocalVariable outerThis = (LocalVariable)vars.get(0);
/*  860:     */     
/*  861:     */ 
/*  862: 840 */     InnerClassConstructorRewriter innerClassConstructorRewriter = new InnerClassConstructorRewriter(method.getClassFile(), outerThis);
/*  863:     */     
/*  864: 842 */     innerClassConstructorRewriter.rewrite(root);
/*  865: 843 */     FieldVariable matchedLValue = innerClassConstructorRewriter.getMatchedField();
/*  866: 844 */     return matchedLValue;
/*  867:     */   }
/*  868:     */   
/*  869:     */   public static void removeInnerClassOuterThis(Method method, Op04StructuredStatement root)
/*  870:     */   {
/*  871: 850 */     MethodPrototype prototype = method.getMethodPrototype();
/*  872:     */     
/*  873: 852 */     List<LocalVariable> vars = prototype.getComputedParameters();
/*  874: 853 */     if (vars.isEmpty()) {
/*  875: 853 */       return;
/*  876:     */     }
/*  877: 855 */     LocalVariable outerThis = (LocalVariable)vars.get(0);
/*  878:     */     
/*  879:     */ 
/*  880: 858 */     InnerClassConstructorRewriter innerClassConstructorRewriter = new InnerClassConstructorRewriter(method.getClassFile(), outerThis);
/*  881:     */     
/*  882: 860 */     innerClassConstructorRewriter.rewrite(root);
/*  883: 861 */     FieldVariable matchedLValue = innerClassConstructorRewriter.getMatchedField();
/*  884: 862 */     if (matchedLValue == null) {
/*  885: 863 */       return;
/*  886:     */     }
/*  887: 870 */     Map<LValue, LValue> replacements = MapFactory.newMap();
/*  888: 871 */     replacements.put(outerThis, matchedLValue);
/*  889: 872 */     innerClassConstructorRewriter.getAssignmentStatement().getContainer().nopOut();
/*  890: 873 */     prototype.setInnerOuterThis();
/*  891: 874 */     prototype.hide(0);
/*  892:     */     
/*  893: 876 */     applyLValueReplacer(replacements, root);
/*  894:     */   }
/*  895:     */   
/*  896:     */   private static void removeSyntheticConstructorOuterArgs(Method method, Op04StructuredStatement root, boolean isInstance)
/*  897:     */   {
/*  898: 880 */     MethodPrototype prototype = method.getMethodPrototype();
/*  899: 881 */     List<LocalVariable> vars = prototype.getComputedParameters();
/*  900: 882 */     if (vars.isEmpty()) {
/*  901: 882 */       return;
/*  902:     */     }
/*  903: 884 */     Map<LValue, LValue> replacements = MapFactory.newMap();
/*  904:     */     
/*  905:     */ 
/*  906:     */ 
/*  907:     */ 
/*  908:     */ 
/*  909:     */ 
/*  910: 891 */     List<ConstructorInvokationAnonymousInner> usages = method.getClassFile().getAnonymousUsages();
/*  911:     */     
/*  912: 893 */     ConstructorInvokationAnonymousInner usage = usages.size() == 1 ? (ConstructorInvokationAnonymousInner)usages.get(0) : null;
/*  913: 899 */     if (usage != null)
/*  914:     */     {
/*  915: 900 */       List<Expression> actualArgs = usage.getArgs();
/*  916: 901 */       if (actualArgs.size() != vars.size()) {
/*  917: 903 */         return;
/*  918:     */       }
/*  919: 905 */       int start = isInstance ? 1 : 0;
/*  920: 906 */       int x = start;
/*  921: 906 */       for (int len = vars.size(); x < len; x++)
/*  922:     */       {
/*  923: 907 */         LocalVariable protoVar = (LocalVariable)vars.get(x);
/*  924: 908 */         Expression arg = (Expression)actualArgs.get(x);
/*  925:     */         
/*  926: 910 */         arg = CastExpression.removeImplicit(arg);
/*  927: 914 */         if ((arg instanceof LValueExpression))
/*  928:     */         {
/*  929: 915 */           LValue lValueArg = ((LValueExpression)arg).getLValue();
/*  930: 916 */           String name = null;
/*  931: 917 */           if ((lValueArg instanceof LocalVariable))
/*  932:     */           {
/*  933: 918 */             LocalVariable localVariable = (LocalVariable)lValueArg;
/*  934:     */             
/*  935: 920 */             InnerClassConstructorRewriter innerClassConstructorRewriter = new InnerClassConstructorRewriter(method.getClassFile(), protoVar);
/*  936: 921 */             innerClassConstructorRewriter.rewrite(root);
/*  937: 922 */             FieldVariable matchedField = innerClassConstructorRewriter.getMatchedField();
/*  938: 923 */             if (matchedField != null)
/*  939:     */             {
/*  940: 925 */               innerClassConstructorRewriter.getAssignmentStatement().getContainer().nopOut();
/*  941:     */               
/*  942:     */ 
/*  943:     */ 
/*  944:     */ 
/*  945:     */ 
/*  946: 931 */               ClassFileField classFileField = matchedField.getClassFileField();
/*  947: 932 */               classFileField.overrideName(localVariable.getName().getStringName());
/*  948: 933 */               classFileField.markSyntheticOuterRef();
/*  949: 934 */               classFileField.markHidden();
/*  950: 935 */               prototype.hide(x);
/*  951: 936 */               lValueArg.markFinal();
/*  952:     */             }
/*  953:     */           }
/*  954:     */         }
/*  955:     */       }
/*  956:     */     }
/*  957: 941 */     applyLValueReplacer(replacements, root);
/*  958:     */   }
/*  959:     */   
/*  960:     */   private static void applyLValueReplacer(Map<LValue, LValue> replacements, Op04StructuredStatement root)
/*  961:     */   {
/*  962: 945 */     if (!replacements.isEmpty())
/*  963:     */     {
/*  964: 946 */       LValueReplacingRewriter lValueReplacingRewriter = new LValueReplacingRewriter(replacements);
/*  965: 947 */       MiscStatementTools.applyExpressionRewriter(root, lValueReplacingRewriter);
/*  966:     */     }
/*  967:     */   }
/*  968:     */   
/*  969:     */   public static void fixInnerClassConstructorSyntheticOuterArgs(ClassFile classFile, Method method, Op04StructuredStatement root)
/*  970:     */   {
/*  971: 955 */     if (classFile.isInnerClass()) {
/*  972: 956 */       removeSyntheticConstructorOuterArgs(method, root, !classFile.testAccessFlag(AccessFlag.ACC_STATIC));
/*  973:     */     }
/*  974:     */   }
/*  975:     */   
/*  976:     */   public static void inlineSyntheticAccessors(DCCommonState state, Method method, Op04StructuredStatement root)
/*  977:     */   {
/*  978: 962 */     JavaTypeInstance classType = method.getClassFile().getClassType();
/*  979: 963 */     new SyntheticAccessorRewriter(state, classType).rewrite(root);
/*  980:     */   }
/*  981:     */   
/*  982:     */   public static void removeConstructorBoilerplate(Op04StructuredStatement root)
/*  983:     */   {
/*  984: 967 */     new RedundantSuperRewriter().rewrite(root);
/*  985:     */   }
/*  986:     */   
/*  987:     */   public static void rewriteLambdas(DCCommonState state, Method method, Op04StructuredStatement root)
/*  988:     */   {
/*  989: 971 */     Options options = state.getOptions();
/*  990: 972 */     if (!((Boolean)options.getOption(OptionsImpl.REWRITE_LAMBDAS, method.getClassFile().getClassFileVersion())).booleanValue()) {
/*  991: 972 */       return;
/*  992:     */     }
/*  993: 974 */     new LambdaRewriter(state, method.getClassFile()).rewrite(root);
/*  994:     */   }
/*  995:     */   
/*  996:     */   public static void removeUnnecessaryVarargArrays(Options options, Method method, Op04StructuredStatement root)
/*  997:     */   {
/*  998: 978 */     new VarArgsRewriter().rewrite(root);
/*  999:     */   }
/* 1000:     */   
/* 1001:     */   public static void removePrimitiveDeconversion(Options options, Method method, Op04StructuredStatement root)
/* 1002:     */   {
/* 1003: 982 */     if (!((Boolean)options.getOption(OptionsImpl.SUGAR_BOXING)).booleanValue()) {
/* 1004: 982 */       return;
/* 1005:     */     }
/* 1006: 984 */     root.transform(new ExpressionRewriterTransformer(new PrimitiveBoxingRewriter()), new StructuredScope());
/* 1007:     */   }
/* 1008:     */   
/* 1009:     */   public static void rewriteBadCastChains(Options options, Method method, Op04StructuredStatement root)
/* 1010:     */   {
/* 1011: 988 */     root.transform(new ExpressionRewriterTransformer(new BadCastChainRewriter()), new StructuredScope());
/* 1012:     */   }
/* 1013:     */   
/* 1014:     */   public static void replaceNestedSyntheticOuterRefs(Op04StructuredStatement root)
/* 1015:     */   {
/* 1016: 992 */     List<StructuredStatement> statements = MiscStatementTools.linearise(root);
/* 1017: 997 */     if (statements == null) {
/* 1018: 997 */       return;
/* 1019:     */     }
/* 1020: 999 */     SyntheticOuterRefRewriter syntheticOuterRefRewriter = new SyntheticOuterRefRewriter();
/* 1021:1000 */     for (StructuredStatement statement : statements) {
/* 1022:1001 */       statement.rewriteExpressions(syntheticOuterRefRewriter);
/* 1023:     */     }
/* 1024:     */   }
/* 1025:     */   
/* 1026:     */   public static void applyChecker(Op04Checker checker, Op04StructuredStatement root, DecompilerComments comments)
/* 1027:     */   {
/* 1028:1010 */     StructuredScope structuredScope = new StructuredScope();
/* 1029:1011 */     root.transform(checker, structuredScope);
/* 1030:1012 */     checker.commentInto(comments);
/* 1031:     */   }
/* 1032:     */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement
 * JD-Core Version:    0.7.0.1
 */