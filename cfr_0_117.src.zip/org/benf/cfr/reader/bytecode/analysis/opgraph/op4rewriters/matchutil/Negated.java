/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  4:   */ 
/*  5:   */ public class Negated
/*  6:   */   implements Matcher<StructuredStatement>
/*  7:   */ {
/*  8:   */   Matcher<StructuredStatement> inner;
/*  9:   */   
/* 10:   */   public Negated(Matcher<StructuredStatement> inner)
/* 11:   */   {
/* 12:12 */     this.inner = inner;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 16:   */   {
/* 17:17 */     MatchIterator<StructuredStatement> mi = matchIterator.copy();
/* 18:19 */     if (this.inner.match(mi, matchResultCollector)) {
/* 19:19 */       return false;
/* 20:   */     }
/* 21:21 */     matchIterator.advance();
/* 22:22 */     return true;
/* 23:   */   }
/* 24:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.Negated
 * JD-Core Version:    0.7.0.1
 */