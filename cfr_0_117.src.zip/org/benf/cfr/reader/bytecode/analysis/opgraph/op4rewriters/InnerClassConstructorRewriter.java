/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.AbstractMatchResultIterator;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.CollectMatch;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.Matcher;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.MiscStatementTools;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.FieldVariable;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/* 14:   */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
/* 15:   */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.LValueWildcard;
/* 16:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 17:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredAssignment;
/* 18:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 19:   */ import org.benf.cfr.reader.entities.AccessFlag;
/* 20:   */ import org.benf.cfr.reader.entities.ClassFile;
/* 21:   */ import org.benf.cfr.reader.entities.ClassFileField;
/* 22:   */ import org.benf.cfr.reader.entities.Field;
/* 23:   */ 
/* 24:   */ public class InnerClassConstructorRewriter
/* 25:   */   implements Op04Rewriter
/* 26:   */ {
/* 27:   */   private final ClassFile classFile;
/* 28:   */   private final LocalVariable outerArg;
/* 29:   */   private FieldVariable matchedField;
/* 30:   */   private StructuredStatement assignmentStatement;
/* 31:   */   
/* 32:   */   public InnerClassConstructorRewriter(ClassFile classFile, LocalVariable outerArg)
/* 33:   */   {
/* 34:27 */     this.outerArg = outerArg;
/* 35:28 */     this.classFile = classFile;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void rewrite(Op04StructuredStatement root)
/* 39:   */   {
/* 40:33 */     List<StructuredStatement> structuredStatements = MiscStatementTools.linearise(root);
/* 41:34 */     if (root == null) {
/* 42:34 */       return;
/* 43:   */     }
/* 44:36 */     WildcardMatch wcm1 = new WildcardMatch();
/* 45:   */     
/* 46:38 */     Matcher<StructuredStatement> m = new CollectMatch("ass1", new StructuredAssignment(wcm1.getLValueWildCard("outercopy"), new LValueExpression(this.outerArg)));
/* 47:   */     
/* 48:   */ 
/* 49:   */ 
/* 50:42 */     MatchIterator<StructuredStatement> mi = new MatchIterator(structuredStatements);
/* 51:43 */     ConstructResultCollector collector = new ConstructResultCollector(wcm1, null);
/* 52:44 */     while (mi.hasNext())
/* 53:   */     {
/* 54:45 */       mi.advance();
/* 55:46 */       if (m.match(mi, collector))
/* 56:   */       {
/* 57:47 */         LValue lValue = wcm1.getLValueWildCard("outercopy").getMatch();
/* 58:48 */         if ((lValue instanceof FieldVariable)) {
/* 59:   */           try
/* 60:   */           {
/* 61:50 */             FieldVariable fieldVariable = (FieldVariable)lValue;
/* 62:51 */             ClassFileField classField = this.classFile.getFieldByName(fieldVariable.getFieldName(), fieldVariable.getInferredJavaType().getJavaTypeInstance());
/* 63:52 */             Field field = classField.getField();
/* 64:55 */             if ((field.testAccessFlag(AccessFlag.ACC_SYNTHETIC)) && (field.testAccessFlag(AccessFlag.ACC_FINAL)))
/* 65:   */             {
/* 66:56 */               this.assignmentStatement = collector.assignmentStatement;
/* 67:57 */               this.matchedField = ((FieldVariable)lValue);
/* 68:   */             }
/* 69:   */           }
/* 70:   */           catch (NoSuchFieldException e) {}
/* 71:   */         }
/* 72:62 */         return;
/* 73:   */       }
/* 74:   */     }
/* 75:   */   }
/* 76:   */   
/* 77:   */   public FieldVariable getMatchedField()
/* 78:   */   {
/* 79:68 */     return this.matchedField;
/* 80:   */   }
/* 81:   */   
/* 82:   */   public StructuredStatement getAssignmentStatement()
/* 83:   */   {
/* 84:72 */     return this.assignmentStatement;
/* 85:   */   }
/* 86:   */   
/* 87:   */   private static class ConstructResultCollector
/* 88:   */     extends AbstractMatchResultIterator
/* 89:   */   {
/* 90:   */     private final WildcardMatch wcm;
/* 91:   */     private StructuredStatement assignmentStatement;
/* 92:   */     
/* 93:   */     private ConstructResultCollector(WildcardMatch wcm)
/* 94:   */     {
/* 95:81 */       this.wcm = wcm;
/* 96:   */     }
/* 97:   */     
/* 98:   */     public void clear()
/* 99:   */     {
/* :0:86 */       this.assignmentStatement = null;
/* :1:   */     }
/* :2:   */     
/* :3:   */     public void collectStatement(String name, StructuredStatement statement)
/* :4:   */     {
/* :5:91 */       this.assignmentStatement = statement;
/* :6:   */     }
/* :7:   */     
/* :8:   */     public void collectMatches(String name, WildcardMatch wcm) {}
/* :9:   */   }
/* ;0:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.InnerClassConstructorRewriter
 * JD-Core Version:    0.7.0.1
 */