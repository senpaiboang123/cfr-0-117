/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Set;
/*  5:   */ import org.benf.cfr.reader.bytecode.BytecodeMeta;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ForIterStatement;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.types.BindingSuperContainer;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.types.GenericTypeBinder;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaArrayTypeInstance;
/* 14:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericPlaceholderTypeInstance;
/* 15:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericRefTypeInstance;
/* 16:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/* 17:   */ import org.benf.cfr.reader.bytecode.analysis.types.TypeConstants;
/* 18:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 19:   */ import org.benf.cfr.reader.util.Functional;
/* 20:   */ import org.benf.cfr.reader.util.SetFactory;
/* 21:   */ 
/* 22:   */ public class LoopLivenessClash
/* 23:   */ {
/* 24:   */   public static boolean detect(List<Op03SimpleStatement> statements, BytecodeMeta bytecodeMeta)
/* 25:   */   {
/* 26:19 */     List<Op03SimpleStatement> iters = Functional.filter(statements, new TypeFilter(ForIterStatement.class));
/* 27:20 */     if (iters.isEmpty()) {
/* 28:20 */       return false;
/* 29:   */     }
/* 30:22 */     boolean found = false;
/* 31:23 */     for (Op03SimpleStatement iter : iters) {
/* 32:24 */       if (detect(iter, bytecodeMeta)) {
/* 33:24 */         found = true;
/* 34:   */       }
/* 35:   */     }
/* 36:26 */     return found;
/* 37:   */   }
/* 38:   */   
/* 39:   */   private static JavaTypeInstance getIterableIterType(JavaTypeInstance type)
/* 40:   */   {
/* 41:30 */     if (!(type instanceof JavaGenericRefTypeInstance)) {
/* 42:30 */       return null;
/* 43:   */     }
/* 44:31 */     JavaGenericRefTypeInstance generic = (JavaGenericRefTypeInstance)type;
/* 45:32 */     BindingSuperContainer bindingSuperContainer = type.getBindingSupers();
/* 46:   */     
/* 47:34 */     JavaGenericRefTypeInstance iterType = bindingSuperContainer.getBoundSuperForBase(TypeConstants.ITERABLE);
/* 48:35 */     GenericTypeBinder typeBinder = GenericTypeBinder.extractBindings(iterType, generic);
/* 49:36 */     if (typeBinder == null) {
/* 50:36 */       return null;
/* 51:   */     }
/* 52:37 */     JavaGenericRefTypeInstance boundIterable = iterType.getBoundInstance(typeBinder);
/* 53:38 */     List<JavaTypeInstance> iterBindings = boundIterable.getGenericTypes();
/* 54:39 */     if (iterBindings.size() != 1) {
/* 55:39 */       return null;
/* 56:   */     }
/* 57:40 */     JavaTypeInstance iteratedType = (JavaTypeInstance)iterBindings.get(0);
/* 58:41 */     return iteratedType;
/* 59:   */   }
/* 60:   */   
/* 61:   */   private static boolean detect(Op03SimpleStatement statement, BytecodeMeta bytecodeMeta)
/* 62:   */   {
/* 63:45 */     ForIterStatement forIterStatement = (ForIterStatement)statement.getStatement();
/* 64:46 */     LValue iterator = forIterStatement.getCreatedLValue();
/* 65:48 */     if (!(iterator instanceof LocalVariable)) {
/* 66:48 */       return false;
/* 67:   */     }
/* 68:50 */     JavaTypeInstance iterType = iterator.getInferredJavaType().getJavaTypeInstance();
/* 69:51 */     InferredJavaType inferredListType = forIterStatement.getList().getInferredJavaType();
/* 70:52 */     JavaTypeInstance listType = inferredListType.getJavaTypeInstance();
/* 71:   */     
/* 72:54 */     JavaTypeInstance listIterType = null;
/* 73:55 */     if ((listType instanceof JavaArrayTypeInstance)) {
/* 74:56 */       listIterType = ((JavaArrayTypeInstance)listType).removeAnArrayIndirection();
/* 75:   */     } else {
/* 76:58 */       listIterType = getIterableIterType(listType);
/* 77:   */     }
/* 78:60 */     if (listIterType == null) {
/* 79:60 */       return false;
/* 80:   */     }
/* 81:61 */     if (iterType.equals(listIterType)) {
/* 82:61 */       return false;
/* 83:   */     }
/* 84:64 */     if ((listIterType instanceof JavaGenericPlaceholderTypeInstance))
/* 85:   */     {
/* 86:65 */       bytecodeMeta.takeIteratedTypeHint(inferredListType, iterType);
/* 87:66 */       return false;
/* 88:   */     }
/* 89:76 */     LocalVariable lvIter = (LocalVariable)iterator;
/* 90:77 */     Set<Integer> clashes = SetFactory.newSet();
/* 91:78 */     clashes.add(Integer.valueOf(lvIter.getIdx()));
/* 92:79 */     bytecodeMeta.informLivenessClashes(clashes);
/* 93:80 */     return true;
/* 94:   */   }
/* 95:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopLivenessClash
 * JD-Core Version:    0.7.0.1
 */