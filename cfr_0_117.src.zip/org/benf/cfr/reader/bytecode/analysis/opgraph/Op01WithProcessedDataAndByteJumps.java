/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph;
/*   2:    */ 
/*   3:    */ import java.util.Map;
/*   4:    */ import org.benf.cfr.reader.bytecode.opcode.JVMInstr;
/*   5:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*   6:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/*   7:    */ 
/*   8:    */ public class Op01WithProcessedDataAndByteJumps
/*   9:    */ {
/*  10:    */   private final JVMInstr instruction;
/*  11:    */   private final byte[] data;
/*  12:    */   private final int[] rawTargetOffsets;
/*  13:    */   private final ConstantPoolEntry[] constantPoolEntries;
/*  14:    */   private final int originalRawOffset;
/*  15:    */   
/*  16:    */   public Op01WithProcessedDataAndByteJumps(JVMInstr instruction, byte[] data, int[] rawTargetOffsets, int originalRawOffset)
/*  17:    */   {
/*  18: 19 */     this.instruction = instruction;
/*  19: 20 */     this.data = data;
/*  20: 21 */     this.rawTargetOffsets = rawTargetOffsets;
/*  21: 22 */     this.constantPoolEntries = null;
/*  22: 23 */     this.originalRawOffset = originalRawOffset;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public Op01WithProcessedDataAndByteJumps(JVMInstr instruction, byte[] data, int[] rawTargetOffsets, int originalRawOffset, ConstantPoolEntry[] constantPoolEntries)
/*  26:    */   {
/*  27: 27 */     this.instruction = instruction;
/*  28: 28 */     this.data = data;
/*  29: 29 */     this.rawTargetOffsets = rawTargetOffsets;
/*  30: 30 */     this.originalRawOffset = originalRawOffset;
/*  31: 31 */     this.constantPoolEntries = constantPoolEntries;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public JVMInstr getJVMInstr()
/*  35:    */   {
/*  36: 35 */     return this.instruction;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public byte[] getData()
/*  40:    */   {
/*  41: 39 */     return this.data;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public Op02WithProcessedDataAndRefs createOp2(ConstantPool cp, int index)
/*  45:    */   {
/*  46: 43 */     return new Op02WithProcessedDataAndRefs(this.instruction, this.data, index, cp, this.constantPoolEntries, this.originalRawOffset);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public int[] getAbsoluteIndexJumps(int thisOpByteIndex, Map<Integer, Integer> lutByOffset)
/*  50:    */   {
/*  51: 47 */     int thisOpInstructionIndex = ((Integer)lutByOffset.get(Integer.valueOf(thisOpByteIndex))).intValue();
/*  52: 48 */     if (this.rawTargetOffsets == null) {
/*  53: 49 */       return new int[] { thisOpInstructionIndex + 1 };
/*  54:    */     }
/*  55: 54 */     int[] targetIndexes = new int[this.rawTargetOffsets.length];
/*  56: 55 */     for (int x = 0; x < this.rawTargetOffsets.length; x++)
/*  57:    */     {
/*  58: 56 */       int targetRawAddress = thisOpByteIndex + this.rawTargetOffsets[x];
/*  59: 57 */       int targetIndex = ((Integer)lutByOffset.get(Integer.valueOf(targetRawAddress))).intValue();
/*  60: 58 */       targetIndexes[x] = targetIndex;
/*  61:    */     }
/*  62: 60 */     return targetIndexes;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public int getInstructionLength()
/*  66:    */   {
/*  67: 64 */     return this.data == null ? 1 : this.data.length + 1;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public String toString()
/*  71:    */   {
/*  72: 69 */     return "op1 : " + this.instruction + ", length " + getInstructionLength();
/*  73:    */   }
/*  74:    */   
/*  75:    */   public Integer getAStoreIdx()
/*  76:    */   {
/*  77: 73 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$opcode$JVMInstr[this.instruction.ordinal()])
/*  78:    */     {
/*  79:    */     case 1: 
/*  80: 75 */       return Integer.valueOf(this.data[0]);
/*  81:    */     case 2: 
/*  82: 77 */       throw new UnsupportedOperationException();
/*  83:    */     case 3: 
/*  84: 79 */       return Integer.valueOf(0);
/*  85:    */     case 4: 
/*  86: 81 */       return Integer.valueOf(1);
/*  87:    */     case 5: 
/*  88: 83 */       return Integer.valueOf(2);
/*  89:    */     case 6: 
/*  90: 85 */       return Integer.valueOf(3);
/*  91:    */     }
/*  92: 87 */     return null;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public Integer getALoadIdx()
/*  96:    */   {
/*  97: 91 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$opcode$JVMInstr[this.instruction.ordinal()])
/*  98:    */     {
/*  99:    */     case 7: 
/* 100: 93 */       return Integer.valueOf(this.data[0]);
/* 101:    */     case 8: 
/* 102: 95 */       throw new UnsupportedOperationException();
/* 103:    */     case 9: 
/* 104: 97 */       return Integer.valueOf(0);
/* 105:    */     case 10: 
/* 106: 99 */       return Integer.valueOf(1);
/* 107:    */     case 11: 
/* 108:101 */       return Integer.valueOf(2);
/* 109:    */     case 12: 
/* 110:103 */       return Integer.valueOf(3);
/* 111:    */     }
/* 112:105 */     return null;
/* 113:    */   }
/* 114:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps
 * JD-Core Version:    0.7.0.1
 */