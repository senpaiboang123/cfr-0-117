package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;

import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;

public abstract interface Op04Rewriter
{
  public abstract void rewrite(Op04StructuredStatement paramOp04StructuredStatement);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.Op04Rewriter
 * JD-Core Version:    0.7.0.1
 */