/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Map;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.MiscStatementTools;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CastExpression;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.DynamicInvokation;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LambdaExpression;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LambdaExpressionCommon;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LambdaExpressionFallback;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.StaticFunctionInvokation;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.structured.expression.StructuredStatementExpression;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredExpressionStatement;
/*  26:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredReturn;
/*  27:    */ import org.benf.cfr.reader.bytecode.analysis.types.DynamicInvokeType;
/*  28:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  29:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  30:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  31:    */ import org.benf.cfr.reader.bytecode.analysis.types.TypeConstants;
/*  32:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  33:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  34:    */ import org.benf.cfr.reader.bytecode.analysis.variables.NamedVariable;
/*  35:    */ import org.benf.cfr.reader.entities.AccessFlagMethod;
/*  36:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  37:    */ import org.benf.cfr.reader.entities.Method;
/*  38:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass;
/*  39:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodHandle;
/*  40:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodRef;
/*  41:    */ import org.benf.cfr.reader.state.DCCommonState;
/*  42:    */ import org.benf.cfr.reader.util.CannotLoadClassException;
/*  43:    */ import org.benf.cfr.reader.util.ListFactory;
/*  44:    */ import org.benf.cfr.reader.util.MapFactory;
/*  45:    */ import org.benf.cfr.reader.util.lambda.LambdaUtils;
/*  46:    */ 
/*  47:    */ public class LambdaRewriter
/*  48:    */   implements Op04Rewriter, ExpressionRewriter
/*  49:    */ {
/*  50:    */   private final DCCommonState state;
/*  51:    */   private final ClassFile thisClassFile;
/*  52:    */   private final JavaTypeInstance typeInstance;
/*  53:    */   
/*  54:    */   public LambdaRewriter(DCCommonState state, ClassFile thisClassFile)
/*  55:    */   {
/*  56: 36 */     this.state = state;
/*  57: 37 */     this.thisClassFile = thisClassFile;
/*  58: 38 */     this.typeInstance = thisClassFile.getClassType().getDeGenerifiedType();
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void rewrite(Op04StructuredStatement root)
/*  62:    */   {
/*  63: 43 */     List<StructuredStatement> structuredStatements = MiscStatementTools.linearise(root);
/*  64: 44 */     if (structuredStatements == null) {
/*  65: 44 */       return;
/*  66:    */     }
/*  67: 53 */     for (StructuredStatement statement : structuredStatements) {
/*  68: 54 */       statement.rewriteExpressions(this);
/*  69:    */     }
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void handleStatement(StatementContainer statementContainer) {}
/*  73:    */   
/*  74:    */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  75:    */   {
/*  76: 67 */     expression = expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/*  77: 68 */     if ((expression instanceof DynamicInvokation)) {
/*  78: 69 */       expression = rewriteDynamicExpression((DynamicInvokation)expression);
/*  79:    */     }
/*  80: 71 */     Expression res = expression;
/*  81: 72 */     if ((res instanceof CastExpression))
/*  82:    */     {
/*  83: 73 */       Expression child = ((CastExpression)res).getChild();
/*  84: 74 */       if ((child instanceof LambdaExpressionCommon))
/*  85:    */       {
/*  86: 75 */         JavaTypeInstance resType = res.getInferredJavaType().getJavaTypeInstance();
/*  87: 76 */         JavaTypeInstance childType = child.getInferredJavaType().getJavaTypeInstance();
/*  88: 77 */         if (childType.implicitlyCastsTo(resType, null)) {
/*  89: 78 */           return child;
/*  90:    */         }
/*  91: 84 */         Expression tmp = new CastExpression(child.getInferredJavaType(), child, true);
/*  92: 85 */         res = new CastExpression(res.getInferredJavaType(), tmp);
/*  93: 86 */         return res;
/*  94:    */       }
/*  95:    */     }
/*  96: 90 */     return res;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public ConditionalExpression rewriteExpression(ConditionalExpression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 100:    */   {
/* 101: 95 */     Expression res = expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 102: 96 */     return (ConditionalExpression)res;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 106:    */   {
/* 107:107 */     return lValue;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public StackSSALabel rewriteExpression(StackSSALabel lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 111:    */   {
/* 112:112 */     return lValue;
/* 113:    */   }
/* 114:    */   
/* 115:    */   private Expression rewriteDynamicExpression(DynamicInvokation dynamicExpression)
/* 116:    */   {
/* 117:120 */     List<Expression> curriedArgs = dynamicExpression.getDynamicArgs();
/* 118:121 */     Expression functionCall = dynamicExpression.getInnerInvokation();
/* 119:122 */     if ((functionCall instanceof StaticFunctionInvokation)) {
/* 120:123 */       return rewriteDynamicExpression(dynamicExpression, (StaticFunctionInvokation)functionCall, curriedArgs);
/* 121:    */     }
/* 122:125 */     return dynamicExpression;
/* 123:    */   }
/* 124:    */   
/* 125:    */   private static LocalVariable getLocalVariable(Expression e)
/* 126:    */   {
/* 127:132 */     if (!(e instanceof LValueExpression)) {
/* 128:132 */       throw new CannotDelambaException(null);
/* 129:    */     }
/* 130:133 */     LValueExpression lValueExpression = (LValueExpression)e;
/* 131:134 */     LValue lValue = lValueExpression.getLValue();
/* 132:135 */     if (!(lValue instanceof LocalVariable)) {
/* 133:135 */       throw new CannotDelambaException(null);
/* 134:    */     }
/* 135:136 */     return (LocalVariable)lValue;
/* 136:    */   }
/* 137:    */   
/* 138:    */   private Expression rewriteDynamicExpression(Expression dynamicExpression, StaticFunctionInvokation functionInvokation, List<Expression> curriedArgs)
/* 139:    */   {
/* 140:140 */     JavaTypeInstance typeInstance = functionInvokation.getClazz();
/* 141:141 */     if (!typeInstance.getRawName().equals("java.lang.invoke.LambdaMetafactory")) {
/* 142:141 */       return dynamicExpression;
/* 143:    */     }
/* 144:142 */     String functionName = functionInvokation.getName();
/* 145:    */     
/* 146:144 */     DynamicInvokeType dynamicInvokeType = DynamicInvokeType.lookup(functionName);
/* 147:145 */     if (dynamicInvokeType == DynamicInvokeType.UNKNOWN) {
/* 148:145 */       return dynamicExpression;
/* 149:    */     }
/* 150:147 */     List<Expression> metaFactoryArgs = functionInvokation.getArgs();
/* 151:148 */     if (metaFactoryArgs.size() != 6) {
/* 152:148 */       return dynamicExpression;
/* 153:    */     }
/* 154:153 */     Expression arg = (Expression)metaFactoryArgs.get(3);
/* 155:    */     
/* 156:155 */     List<JavaTypeInstance> targetFnArgTypes = LambdaUtils.getLiteralProto(arg).getArgs();
/* 157:    */     
/* 158:157 */     ConstantPoolEntryMethodHandle lambdaFnHandle = LambdaUtils.getHandle((Expression)metaFactoryArgs.get(4));
/* 159:158 */     ConstantPoolEntryMethodRef lambdaMethRef = lambdaFnHandle.getMethodRef();
/* 160:159 */     JavaTypeInstance lambdaTypeLocation = lambdaMethRef.getClassEntry().getTypeInstance();
/* 161:160 */     MethodPrototype lambdaFn = lambdaMethRef.getMethodPrototype();
/* 162:161 */     String lambdaFnName = lambdaFn.getName();
/* 163:162 */     List<JavaTypeInstance> lambdaFnArgTypes = lambdaFn.getArgs();
/* 164:164 */     if (!(lambdaTypeLocation instanceof JavaRefTypeInstance)) {
/* 165:165 */       return dynamicExpression;
/* 166:    */     }
/* 167:167 */     JavaRefTypeInstance lambdaTypeRefLocation = (JavaRefTypeInstance)lambdaTypeLocation;
/* 168:    */     ClassFile classFile;
/* 169:    */     ClassFile classFile;
/* 170:169 */     if (this.typeInstance.equals(lambdaTypeRefLocation)) {
/* 171:170 */       classFile = this.thisClassFile;
/* 172:    */     } else {
/* 173:    */       try
/* 174:    */       {
/* 175:173 */         classFile = this.state.getClassFile(lambdaTypeRefLocation);
/* 176:    */       }
/* 177:    */       catch (CannotLoadClassException e)
/* 178:    */       {
/* 179:176 */         return dynamicExpression;
/* 180:    */       }
/* 181:    */     }
/* 182:179 */     if (classFile == null) {
/* 183:180 */       return dynamicExpression;
/* 184:    */     }
/* 185:185 */     boolean instance = false;
/* 186:186 */     switch (1.$SwitchMap$org$benf$cfr$reader$entities$bootstrap$MethodHandleBehaviour[lambdaFnHandle.getReferenceKind().ordinal()])
/* 187:    */     {
/* 188:    */     case 1: 
/* 189:    */     case 2: 
/* 190:    */     case 3: 
/* 191:190 */       instance = true;
/* 192:    */     }
/* 193:194 */     if (curriedArgs.size() + targetFnArgTypes.size() - (instance ? 1 : 0) != lambdaFnArgTypes.size()) {
/* 194:195 */       throw new IllegalStateException("Bad argument counts!");
/* 195:    */     }
/* 196:201 */     Method lambdaMethod = null;
/* 197:    */     try
/* 198:    */     {
/* 199:203 */       lambdaMethod = classFile.getMethodByPrototype(lambdaFn);
/* 200:    */     }
/* 201:    */     catch (NoSuchMethodException e)
/* 202:    */     {
/* 203:206 */       return dynamicExpression;
/* 204:    */     }
/* 205:209 */     int x = 0;
/* 206:209 */     for (int len = curriedArgs.size(); x < len; x++)
/* 207:    */     {
/* 208:214 */       Expression curriedArg = (Expression)curriedArgs.get(x);
/* 209:215 */       JavaTypeInstance curriedArgType = curriedArg.getInferredJavaType().getJavaTypeInstance();
/* 210:216 */       if (curriedArgType.getDeGenerifiedType().equals(TypeConstants.SUPPLIER)) {
/* 211:217 */         if ((curriedArg instanceof CastExpression))
/* 212:    */         {
/* 213:218 */           CastExpression castExpression = (CastExpression)curriedArg;
/* 214:219 */           curriedArg = new CastExpression(curriedArg.getInferredJavaType(), castExpression.getChild(), true);
/* 215:    */         }
/* 216:220 */         else if (!(curriedArg instanceof LValueExpression))
/* 217:    */         {
/* 218:221 */           curriedArg = new CastExpression(curriedArg.getInferredJavaType(), curriedArg, true);
/* 219:    */         }
/* 220:    */       }
/* 221:224 */       curriedArgs.set(x, CastExpression.removeImplicit(curriedArg));
/* 222:    */     }
/* 223:226 */     if ((this.typeInstance.equals(lambdaTypeRefLocation)) && (lambdaMethod.testAccessFlag(AccessFlagMethod.ACC_SYNTHETIC))) {
/* 224:    */       try
/* 225:    */       {
/* 226:231 */         Op04StructuredStatement lambdaCode = lambdaMethod.getAnalysis();
/* 227:232 */         int nLambdaArgs = targetFnArgTypes.size();
/* 228:    */         
/* 229:    */ 
/* 230:    */ 
/* 231:    */ 
/* 232:237 */         List<LValue> replacementParameters = ListFactory.newList();
/* 233:238 */         int n = instance ? 1 : 0;
/* 234:238 */         for (int m = curriedArgs.size(); n < m; n++) {
/* 235:239 */           replacementParameters.add(getLocalVariable((Expression)curriedArgs.get(n)));
/* 236:    */         }
/* 237:241 */         List<LValue> anonymousLambdaArgs = ListFactory.newList();
/* 238:242 */         List<LocalVariable> originalParameters = lambdaMethod.getMethodPrototype().getComputedParameters();
/* 239:243 */         int offset = replacementParameters.size();
/* 240:244 */         for (int n = 0; n < nLambdaArgs; n++)
/* 241:    */         {
/* 242:245 */           LocalVariable original = (LocalVariable)originalParameters.get(n + offset);
/* 243:246 */           String name = original.getName().getStringName();
/* 244:247 */           LocalVariable tmp = new LocalVariable(name, new InferredJavaType((JavaTypeInstance)targetFnArgTypes.get(n), InferredJavaType.Source.EXPRESSION));
/* 245:248 */           anonymousLambdaArgs.add(tmp);
/* 246:249 */           replacementParameters.add(tmp);
/* 247:    */         }
/* 248:257 */         if (originalParameters.size() != replacementParameters.size()) {
/* 249:257 */           throw new CannotDelambaException(null);
/* 250:    */         }
/* 251:259 */         Map<LValue, LValue> rewrites = MapFactory.newMap();
/* 252:260 */         for (int x = 0; x < originalParameters.size(); x++) {
/* 253:261 */           rewrites.put(originalParameters.get(x), replacementParameters.get(x));
/* 254:    */         }
/* 255:264 */         List<StructuredStatement> structuredLambdaStatements = MiscStatementTools.linearise(lambdaCode);
/* 256:265 */         if (structuredLambdaStatements == null) {
/* 257:266 */           throw new CannotDelambaException(null);
/* 258:    */         }
/* 259:269 */         ExpressionRewriter variableRenamer = new LambdaInternalRewriter(rewrites);
/* 260:270 */         for (StructuredStatement lambdaStatement : structuredLambdaStatements) {
/* 261:271 */           lambdaStatement.rewriteExpressions(variableRenamer);
/* 262:    */         }
/* 263:273 */         StructuredStatement lambdaStatement = lambdaCode.getStatement();
/* 264:274 */         if ((structuredLambdaStatements.size() == 3) && ((structuredLambdaStatements.get(1) instanceof StructuredReturn)))
/* 265:    */         {
/* 266:278 */           StructuredReturn structuredReturn = (StructuredReturn)structuredLambdaStatements.get(1);
/* 267:279 */           lambdaStatement = new StructuredExpressionStatement(structuredReturn.getValue(), true);
/* 268:    */         }
/* 269:282 */         lambdaMethod.hideSynthetic();
/* 270:283 */         return new LambdaExpression(dynamicExpression.getInferredJavaType(), anonymousLambdaArgs, new StructuredStatementExpression(new InferredJavaType(lambdaMethod.getMethodPrototype().getReturnType(), InferredJavaType.Source.EXPRESSION), lambdaStatement));
/* 271:    */       }
/* 272:    */       catch (CannotDelambaException e) {}
/* 273:    */     }
/* 274:289 */     return new LambdaExpressionFallback(lambdaTypeRefLocation, dynamicExpression.getInferredJavaType(), lambdaFnName, targetFnArgTypes, curriedArgs, instance);
/* 275:    */   }
/* 276:    */   
/* 277:    */   public static class LambdaInternalRewriter
/* 278:    */     implements ExpressionRewriter
/* 279:    */   {
/* 280:    */     private final Map<LValue, LValue> rewrites;
/* 281:    */     
/* 282:    */     public LambdaInternalRewriter(Map<LValue, LValue> rewrites)
/* 283:    */     {
/* 284:297 */       this.rewrites = rewrites;
/* 285:    */     }
/* 286:    */     
/* 287:    */     public void handleStatement(StatementContainer statementContainer) {}
/* 288:    */     
/* 289:    */     public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 290:    */     {
/* 291:307 */       return expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 292:    */     }
/* 293:    */     
/* 294:    */     public ConditionalExpression rewriteExpression(ConditionalExpression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 295:    */     {
/* 296:312 */       Expression res = expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 297:313 */       return (ConditionalExpression)res;
/* 298:    */     }
/* 299:    */     
/* 300:    */     public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 301:    */     {
/* 302:324 */       LValue replacement = (LValue)this.rewrites.get(lValue);
/* 303:325 */       return replacement == null ? lValue : replacement;
/* 304:    */     }
/* 305:    */     
/* 306:    */     public StackSSALabel rewriteExpression(StackSSALabel lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 307:    */     {
/* 308:330 */       return lValue;
/* 309:    */     }
/* 310:    */   }
/* 311:    */   
/* 312:    */   private static class CannotDelambaException
/* 313:    */     extends IllegalStateException
/* 314:    */   {}
/* 315:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.LambdaRewriter
 * JD-Core Version:    0.7.0.1
 */