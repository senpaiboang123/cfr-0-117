/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.AccountingRewriter;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentAndAliasCondenser;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentAndAliasCondenser.AliasRewriter;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentAndAliasCondenser.MutationRewriterFirstPass;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentAndAliasCondenser.MutationRewriterSecondPass;
/* 10:   */ 
/* 11:   */ public class LValueProp
/* 12:   */ {
/* 13:   */   public static void condenseLValues(List<Op03SimpleStatement> statements)
/* 14:   */   {
/* 15:20 */     AccountingRewriter accountingRewriter = new AccountingRewriter();
/* 16:21 */     for (Op03SimpleStatement statement : statements) {
/* 17:22 */       statement.rewrite(accountingRewriter);
/* 18:   */     }
/* 19:24 */     accountingRewriter.flush();
/* 20:   */     
/* 21:   */ 
/* 22:27 */     LValueAssignmentAndAliasCondenser lValueAssigmentCollector = new LValueAssignmentAndAliasCondenser();
/* 23:28 */     for (Op03SimpleStatement statement : statements) {
/* 24:29 */       statement.collect(lValueAssigmentCollector);
/* 25:   */     }
/* 26:38 */     LValueAssignmentAndAliasCondenser.MutationRewriterFirstPass firstPassRewriter = lValueAssigmentCollector.getMutationRewriterFirstPass();
/* 27:39 */     if (firstPassRewriter != null)
/* 28:   */     {
/* 29:40 */       for (Op03SimpleStatement statement : statements) {
/* 30:41 */         statement.condense(firstPassRewriter);
/* 31:   */       }
/* 32:44 */       LValueAssignmentAndAliasCondenser.MutationRewriterSecondPass secondPassRewriter = firstPassRewriter.getSecondPassRewriter();
/* 33:45 */       if (secondPassRewriter != null) {
/* 34:46 */         for (Op03SimpleStatement statement : statements) {
/* 35:47 */           statement.condense(secondPassRewriter);
/* 36:   */         }
/* 37:   */       }
/* 38:51 */       lValueAssigmentCollector = new LValueAssignmentAndAliasCondenser();
/* 39:52 */       for (Op03SimpleStatement statement : statements) {
/* 40:53 */         statement.collect(lValueAssigmentCollector);
/* 41:   */       }
/* 42:   */     }
/* 43:60 */     LValueAssignmentAndAliasCondenser.AliasRewriter multiRewriter = lValueAssigmentCollector.getAliasRewriter();
/* 44:61 */     for (Op03SimpleStatement statement : statements) {
/* 45:62 */       statement.condense(multiRewriter);
/* 46:   */     }
/* 47:64 */     multiRewriter.inferAliases();
/* 48:66 */     for (Op03SimpleStatement statement : statements) {
/* 49:67 */       statement.condense(lValueAssigmentCollector);
/* 50:   */     }
/* 51:   */   }
/* 52:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LValueProp
 * JD-Core Version:    0.7.0.1
 */