/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Map;
/*   5:    */ import java.util.Set;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.AssignmentSimple;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CaseStatement;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.IfExitingStatement;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.IfStatement;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.MonitorExitStatement;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.Nop;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ReturnNothingStatement;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ReturnStatement;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ReturnValueStatement;
/*  26:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  27:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollectorSimple;
/*  28:    */ import org.benf.cfr.reader.entities.Method;
/*  29:    */ import org.benf.cfr.reader.util.Functional;
/*  30:    */ import org.benf.cfr.reader.util.MapFactory;
/*  31:    */ import org.benf.cfr.reader.util.SetFactory;
/*  32:    */ import org.benf.cfr.reader.util.SetUtil;
/*  33:    */ 
/*  34:    */ public class RemoveDeterministicJumps
/*  35:    */ {
/*  36:    */   public static List<Op03SimpleStatement> apply(Method method, List<Op03SimpleStatement> statements)
/*  37:    */   {
/*  38: 24 */     boolean success = false;
/*  39: 25 */     Set<BlockIdentifier> ignoreInThese = FinallyRewriter.getBlocksAffectedByFinally(statements);
/*  40: 27 */     for (Op03SimpleStatement stm : statements) {
/*  41: 28 */       if (((stm.getStatement() instanceof AssignmentSimple)) && 
/*  42: 29 */         (!SetUtil.hasIntersection(ignoreInThese, stm.getBlockIdentifiers())))
/*  43:    */       {
/*  44: 30 */         Map<LValue, Literal> display = MapFactory.newMap();
/*  45: 31 */         success |= propagateLiteralReturn(method, stm, display);
/*  46:    */       }
/*  47:    */     }
/*  48: 34 */     if (success) {
/*  49: 35 */       statements = Cleaner.removeUnreachableCode(statements, true);
/*  50:    */     }
/*  51: 37 */     return statements;
/*  52:    */   }
/*  53:    */   
/*  54:    */   private static boolean propagateLiteralReturn(Method method, Op03SimpleStatement original, Map<LValue, Literal> display)
/*  55:    */   {
/*  56: 41 */     Op03SimpleStatement current = original;
/*  57: 42 */     Set<Op03SimpleStatement> seen = SetFactory.newSet();
/*  58: 43 */     boolean canRewrite = true;
/*  59: 44 */     int nAssigns = 0;
/*  60:    */     
/*  61: 46 */     boolean adjustedOrig = false;
/*  62: 47 */     int nAssignsAtAdjust = 0;
/*  63:    */     for (;;)
/*  64:    */     {
/*  65: 49 */       if (current.getSources().size() != 1) {
/*  66: 49 */         canRewrite = false;
/*  67:    */       }
/*  68: 50 */       if (!seen.add(current)) {
/*  69: 50 */         return false;
/*  70:    */       }
/*  71: 51 */       Class<?> cls = current.getStatement().getClass();
/*  72: 52 */       List<Op03SimpleStatement> curTargets = current.getTargets();
/*  73: 53 */       int nTargets = curTargets.size();
/*  74: 54 */       if (cls == Nop.class)
/*  75:    */       {
/*  76: 55 */         if (nTargets != 1) {
/*  77:    */           break;
/*  78:    */         }
/*  79: 56 */         current = (Op03SimpleStatement)curTargets.get(0);
/*  80:    */       }
/*  81: 59 */       else if ((cls == GotoStatement.class) || (cls == MonitorExitStatement.class) || (cls == CaseStatement.class))
/*  82:    */       {
/*  83: 62 */         if (nTargets != 1) {
/*  84:    */           break;
/*  85:    */         }
/*  86: 63 */         current = (Op03SimpleStatement)curTargets.get(0);
/*  87:    */       }
/*  88: 66 */       else if (cls == AssignmentSimple.class)
/*  89:    */       {
/*  90: 67 */         AssignmentSimple assignmentSimple = (AssignmentSimple)current.getStatement();
/*  91: 68 */         LValue lValue = assignmentSimple.getCreatedLValue();
/*  92: 69 */         if ((!(lValue instanceof StackSSALabel)) && (!(lValue instanceof LocalVariable))) {
/*  93:    */           break;
/*  94:    */         }
/*  95: 70 */         Literal literal = assignmentSimple.getRValue().getComputedLiteral(display);
/*  96: 71 */         if (literal == null) {
/*  97:    */           break;
/*  98:    */         }
/*  99: 72 */         display.put(lValue, literal);
/* 100: 73 */         current = (Op03SimpleStatement)curTargets.get(0);
/* 101: 74 */         nAssigns++;
/* 102:    */       }
/* 103:    */       else
/* 104:    */       {
/* 105: 79 */         if (cls != IfStatement.class) {
/* 106:    */           break;
/* 107:    */         }
/* 108: 80 */         IfStatement ifStatement = (IfStatement)current.getStatement();
/* 109: 81 */         Literal literal = ifStatement.getCondition().getComputedLiteral(display);
/* 110: 82 */         Boolean bool = literal == null ? null : literal.getValue().getMaybeBoolValue();
/* 111: 83 */         if (bool == null)
/* 112:    */         {
/* 113: 87 */           if (adjustedOrig) {
/* 114:    */             break;
/* 115:    */           }
/* 116: 90 */           adjustedOrig = true;
/* 117: 91 */           nAssignsAtAdjust = nAssigns;
/* 118: 92 */           original = current;
/* 119: 93 */           current = (Op03SimpleStatement)curTargets.get(1);
/* 120:    */         }
/* 121:    */         else
/* 122:    */         {
/* 123: 96 */           current = (Op03SimpleStatement)curTargets.get(bool.booleanValue() ? 1 : 0);
/* 124:    */         }
/* 125:    */       }
/* 126:    */     }
/* 127:102 */     Statement currentStatement = current.getStatement();
/* 128:103 */     Class<?> cls = current.getStatement().getClass();
/* 129:114 */     if ((currentStatement instanceof ReturnStatement))
/* 130:    */     {
/* 131:117 */       if (cls == ReturnNothingStatement.class)
/* 132:    */       {
/* 133:118 */         replace(original, adjustedOrig, new ReturnNothingStatement());
/* 134:    */       }
/* 135:119 */       else if (cls == ReturnValueStatement.class)
/* 136:    */       {
/* 137:120 */         ReturnValueStatement returnValueStatement = (ReturnValueStatement)current.getStatement();
/* 138:    */         
/* 139:122 */         LValueUsageCollectorSimple collectorSimple = new LValueUsageCollectorSimple();
/* 140:123 */         Expression res = returnValueStatement.getReturnValue();
/* 141:124 */         res.collectUsedLValues(collectorSimple);
/* 142:125 */         if (SetUtil.hasIntersection(display.keySet(), collectorSimple.getUsedLValues())) {
/* 143:128 */           return false;
/* 144:    */         }
/* 145:130 */         Expression lit = res.getComputedLiteral(display);
/* 146:131 */         if (lit != null) {
/* 147:131 */           res = lit;
/* 148:    */         }
/* 149:133 */         replace(original, adjustedOrig, new ReturnValueStatement(res, returnValueStatement.getFnReturnType()));
/* 150:    */       }
/* 151:    */       else
/* 152:    */       {
/* 153:135 */         return false;
/* 154:    */       }
/* 155:137 */       return true;
/* 156:    */     }
/* 157:148 */     if (!adjustedOrig) {
/* 158:148 */       return false;
/* 159:    */     }
/* 160:149 */     Op03SimpleStatement origTarget = (Op03SimpleStatement)original.getTargets().get(1);
/* 161:150 */     if (current == origTarget) {
/* 162:150 */       return false;
/* 163:    */     }
/* 164:153 */     if ((nAssigns != nAssignsAtAdjust) || (nAssigns == 0)) {
/* 165:153 */       return false;
/* 166:    */     }
/* 167:155 */     original.replaceTarget(origTarget, current);
/* 168:156 */     origTarget.removeSource(original);
/* 169:157 */     current.addSource(original);
/* 170:158 */     return true;
/* 171:    */   }
/* 172:    */   
/* 173:    */   private static void replaceConditionalReturn(Op03SimpleStatement conditional, ReturnStatement returnStatement)
/* 174:    */   {
/* 175:162 */     Op03SimpleStatement originalConditionalTarget = (Op03SimpleStatement)conditional.getTargets().get(1);
/* 176:163 */     IfStatement ifStatement = (IfStatement)conditional.getStatement();
/* 177:164 */     conditional.replaceStatement(new IfExitingStatement(ifStatement.getCondition(), returnStatement));
/* 178:165 */     conditional.removeTarget(originalConditionalTarget);
/* 179:166 */     originalConditionalTarget.removeSource(conditional);
/* 180:    */   }
/* 181:    */   
/* 182:    */   private static void replaceAssignmentReturn(Op03SimpleStatement assignment, ReturnStatement returnStatement)
/* 183:    */   {
/* 184:170 */     assignment.replaceStatement(returnStatement);
/* 185:171 */     Op03SimpleStatement tgt = (Op03SimpleStatement)assignment.getTargets().get(0);
/* 186:172 */     tgt.removeSource(assignment);
/* 187:173 */     assignment.removeTarget(tgt);
/* 188:    */   }
/* 189:    */   
/* 190:    */   private static void replace(Op03SimpleStatement source, boolean isIf, ReturnStatement returnNothingStatement)
/* 191:    */   {
/* 192:177 */     if (isIf) {
/* 193:178 */       replaceConditionalReturn(source, returnNothingStatement);
/* 194:    */     } else {
/* 195:180 */       replaceAssignmentReturn(source, returnNothingStatement);
/* 196:    */     }
/* 197:    */   }
/* 198:    */   
/* 199:    */   private static boolean propagateLiteralReturn(Method method, Op03SimpleStatement original, Op03SimpleStatement orignext, LValue originalLValue, Expression originalRValue, Map<LValue, Literal> display)
/* 200:    */   {
/* 201:207 */     Op03SimpleStatement current = orignext;
/* 202:208 */     Set<Op03SimpleStatement> seen = SetFactory.newSet();
/* 203:    */     for (;;)
/* 204:    */     {
/* 205:210 */       if (!seen.add(current)) {
/* 206:210 */         return false;
/* 207:    */       }
/* 208:211 */       Class<?> cls = current.getStatement().getClass();
/* 209:212 */       List<Op03SimpleStatement> curTargets = current.getTargets();
/* 210:213 */       int nTargets = curTargets.size();
/* 211:214 */       if (cls == Nop.class)
/* 212:    */       {
/* 213:215 */         if (nTargets != 1) {
/* 214:215 */           return false;
/* 215:    */         }
/* 216:216 */         current = (Op03SimpleStatement)curTargets.get(0);
/* 217:    */       }
/* 218:    */       else
/* 219:    */       {
/* 220:219 */         if ((cls == ReturnNothingStatement.class) || 
/* 221:220 */           (cls == ReturnValueStatement.class)) {
/* 222:    */           break label322;
/* 223:    */         }
/* 224:221 */         if ((cls == GotoStatement.class) || (cls == MonitorExitStatement.class))
/* 225:    */         {
/* 226:223 */           if (nTargets != 1) {
/* 227:223 */             return false;
/* 228:    */           }
/* 229:224 */           current = (Op03SimpleStatement)curTargets.get(0);
/* 230:    */         }
/* 231:227 */         else if (cls == AssignmentSimple.class)
/* 232:    */         {
/* 233:228 */           AssignmentSimple assignmentSimple = (AssignmentSimple)current.getStatement();
/* 234:229 */           LValue lValue = assignmentSimple.getCreatedLValue();
/* 235:230 */           if ((!(lValue instanceof StackSSALabel)) && (!(lValue instanceof LocalVariable))) {
/* 236:230 */             return false;
/* 237:    */           }
/* 238:231 */           Literal literal = assignmentSimple.getRValue().getComputedLiteral(display);
/* 239:232 */           if (literal == null) {
/* 240:232 */             return false;
/* 241:    */           }
/* 242:233 */           display.put(lValue, literal);
/* 243:234 */           current = (Op03SimpleStatement)curTargets.get(0);
/* 244:    */         }
/* 245:    */         else
/* 246:    */         {
/* 247:239 */           if (cls != IfStatement.class) {
/* 248:    */             break;
/* 249:    */           }
/* 250:240 */           IfStatement ifStatement = (IfStatement)current.getStatement();
/* 251:241 */           Literal literal = ifStatement.getCondition().getComputedLiteral(display);
/* 252:242 */           Boolean bool = literal == null ? null : literal.getValue().getMaybeBoolValue();
/* 253:243 */           if (bool == null) {
/* 254:244 */             return false;
/* 255:    */           }
/* 256:246 */           current = (Op03SimpleStatement)curTargets.get(bool.booleanValue() ? 1 : 0);
/* 257:    */         }
/* 258:    */       }
/* 259:    */     }
/* 260:249 */     return false;
/* 261:    */     label322:
/* 262:252 */     Class<?> cls = current.getStatement().getClass();
/* 263:256 */     if (cls == ReturnNothingStatement.class)
/* 264:    */     {
/* 265:257 */       if (!(originalRValue instanceof Literal)) {
/* 266:257 */         return false;
/* 267:    */       }
/* 268:258 */       original.replaceStatement(new ReturnNothingStatement());
/* 269:259 */       orignext.removeSource(original);
/* 270:260 */       original.removeTarget(orignext);
/* 271:261 */       return true;
/* 272:    */     }
/* 273:270 */     if (cls == ReturnValueStatement.class)
/* 274:    */     {
/* 275:271 */       ReturnValueStatement returnValueStatement = (ReturnValueStatement)current.getStatement();
/* 276:272 */       if ((originalRValue instanceof Literal))
/* 277:    */       {
/* 278:273 */         Expression e = returnValueStatement.getReturnValue().getComputedLiteral(display);
/* 279:274 */         if (e == null) {
/* 280:274 */           return false;
/* 281:    */         }
/* 282:275 */         original.replaceStatement(new ReturnValueStatement(e, returnValueStatement.getFnReturnType()));
/* 283:    */       }
/* 284:    */       else
/* 285:    */       {
/* 286:277 */         Expression ret = returnValueStatement.getReturnValue();
/* 287:278 */         if (!(ret instanceof LValueExpression)) {
/* 288:278 */           return false;
/* 289:    */         }
/* 290:279 */         LValue retLValue = ((LValueExpression)ret).getLValue();
/* 291:280 */         if (!retLValue.equals(originalLValue)) {
/* 292:280 */           return false;
/* 293:    */         }
/* 294:282 */         original.replaceStatement(new ReturnValueStatement(originalRValue, returnValueStatement.getFnReturnType()));
/* 295:    */       }
/* 296:284 */       orignext.removeSource(original);
/* 297:285 */       original.removeTarget(orignext);
/* 298:286 */       return true;
/* 299:    */     }
/* 300:288 */     return false;
/* 301:    */   }
/* 302:    */   
/* 303:    */   public static void propagateToReturn(Method method, List<Op03SimpleStatement> statements)
/* 304:    */   {
/* 305:296 */     boolean success = false;
/* 306:    */     
/* 307:298 */     List<Op03SimpleStatement> assignmentSimples = Functional.filter(statements, new TypeFilter(AssignmentSimple.class));
/* 308:299 */     Set<BlockIdentifier> affectedByFinally = FinallyRewriter.getBlocksAffectedByFinally(statements);
/* 309:301 */     for (Op03SimpleStatement stm : assignmentSimples) {
/* 310:302 */       if (!SetUtil.hasIntersection(affectedByFinally, stm.getBlockIdentifiers()))
/* 311:    */       {
/* 312:303 */         Statement inner = stm.getStatement();
/* 313:314 */         if (stm.getTargets().size() == 1)
/* 314:    */         {
/* 315:316 */           AssignmentSimple assignmentSimple = (AssignmentSimple)inner;
/* 316:317 */           LValue lValue = assignmentSimple.getCreatedLValue();
/* 317:318 */           Expression rValue = assignmentSimple.getRValue();
/* 318:319 */           if (((lValue instanceof StackSSALabel)) || ((lValue instanceof LocalVariable)))
/* 319:    */           {
/* 320:320 */             Map<LValue, Literal> display = MapFactory.newMap();
/* 321:321 */             if ((rValue instanceof Literal)) {
/* 322:322 */               display.put(lValue, (Literal)rValue);
/* 323:    */             }
/* 324:324 */             Op03SimpleStatement next = (Op03SimpleStatement)stm.getTargets().get(0);
/* 325:325 */             success |= propagateLiteralReturn(method, stm, next, lValue, rValue, display);
/* 326:    */           }
/* 327:    */         }
/* 328:    */       }
/* 329:    */     }
/* 330:330 */     if (success) {
/* 331:330 */       Op03SimpleStatement.replaceReturningIfs(statements, true);
/* 332:    */     }
/* 333:    */   }
/* 334:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.RemoveDeterministicJumps
 * JD-Core Version:    0.7.0.1
 */