/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Set;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.MemberFunctionInvokation;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.StaticFunctionInvokation;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 11:   */ import org.benf.cfr.reader.util.SetFactory;
/* 12:   */ 
/* 13:   */ public class BoxingHelper
/* 14:   */ {
/* 15:14 */   private static Set<Pair<String, String>> unboxing = SetFactory.newSet(new Pair[] { Pair.make("java.lang.Integer", "intValue"), Pair.make("java.lang.Long", "longValue"), Pair.make("java.lang.Double", "doubleValue"), Pair.make("java.lang.Short", "shortValue"), Pair.make("java.lang.Boolean", "booleanValue") });
/* 16:22 */   private static Set<Pair<String, String>> boxing = SetFactory.newSet(new Pair[] { Pair.make("java.lang.Integer", "valueOf"), Pair.make("java.lang.Long", "valueOf"), Pair.make("java.lang.Double", "valueOf"), Pair.make("java.lang.Short", "valueOf"), Pair.make("java.lang.Boolean", "valueOf") });
/* 17:   */   
/* 18:   */   public static Expression sugarUnboxing(MemberFunctionInvokation memberFunctionInvokation)
/* 19:   */   {
/* 20:32 */     String name = memberFunctionInvokation.getName();
/* 21:33 */     JavaTypeInstance type = memberFunctionInvokation.getObject().getInferredJavaType().getJavaTypeInstance();
/* 22:34 */     String rawTypeName = type.getRawName();
/* 23:35 */     Pair<String, String> testPair = Pair.make(rawTypeName, name);
/* 24:36 */     if (unboxing.contains(testPair))
/* 25:   */     {
/* 26:37 */       Expression expression = memberFunctionInvokation.getObject();
/* 27:38 */       return expression;
/* 28:   */     }
/* 29:40 */     return memberFunctionInvokation;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public static Expression sugarBoxing(StaticFunctionInvokation staticFunctionInvokation)
/* 33:   */   {
/* 34:45 */     String name = staticFunctionInvokation.getName();
/* 35:46 */     JavaTypeInstance type = staticFunctionInvokation.getClazz();
/* 36:47 */     if (staticFunctionInvokation.getArgs().size() != 1) {
/* 37:47 */       return staticFunctionInvokation;
/* 38:   */     }
/* 39:48 */     Expression arg1 = (Expression)staticFunctionInvokation.getArgs().get(0);
/* 40:49 */     String rawTypeName = type.getRawName();
/* 41:50 */     Pair<String, String> testPair = Pair.make(rawTypeName, name);
/* 42:51 */     if (boxing.contains(testPair))
/* 43:   */     {
/* 44:52 */       JavaTypeInstance argType = arg1.getInferredJavaType().getJavaTypeInstance();
/* 45:53 */       if (argType.implicitlyCastsTo(type, null)) {
/* 46:54 */         return (Expression)staticFunctionInvokation.getArgs().get(0);
/* 47:   */       }
/* 48:   */     }
/* 49:57 */     return staticFunctionInvokation;
/* 50:   */   }
/* 51:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.BoxingHelper
 * JD-Core Version:    0.7.0.1
 */