/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Map;
/*   5:    */ import java.util.Set;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.AbstractMatchResultIterator;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchOneOf;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchSequence;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.Matcher;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.ResetAfterTest;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.MiscStatementTools;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithOp;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithmeticOperation;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithmeticPostMutationOperation;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithmeticPreMutationOperation;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AssignmentExpression;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.MemberFunctionInvokation;
/*  26:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.StackValue;
/*  27:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.StaticFunctionInvokation;
/*  28:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  29:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  30:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  31:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StaticVariable;
/*  32:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  33:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  34:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  35:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  36:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
/*  37:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.ExpressionWildcard;
/*  38:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.LValueWildcard;
/*  39:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.MemberFunctionInvokationWildcard;
/*  40:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.StaticFunctionInvokationWildcard;
/*  41:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  42:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredAssignment;
/*  43:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredExpressionStatement;
/*  44:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredReturn;
/*  45:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.BeginBlock;
/*  46:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.EndBlock;
/*  47:    */ import org.benf.cfr.reader.bytecode.analysis.types.InnerClassInfo;
/*  48:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  49:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  50:    */ import org.benf.cfr.reader.entities.AccessFlagMethod;
/*  51:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  52:    */ import org.benf.cfr.reader.entities.Method;
/*  53:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodRef;
/*  54:    */ import org.benf.cfr.reader.state.DCCommonState;
/*  55:    */ import org.benf.cfr.reader.util.MapFactory;
/*  56:    */ import org.benf.cfr.reader.util.SetFactory;
/*  57:    */ import org.benf.cfr.reader.util.SetUtil;
/*  58:    */ 
/*  59:    */ public class SyntheticAccessorRewriter
/*  60:    */   implements Op04Rewriter, ExpressionRewriter
/*  61:    */ {
/*  62:    */   private final DCCommonState state;
/*  63:    */   private final JavaTypeInstance thisClassType;
/*  64:    */   private static final String RETURN_LVALUE = "returnlvalue";
/*  65:    */   private static final String MUTATION1 = "mutation1";
/*  66:    */   private static final String MUTATION2 = "mutation2";
/*  67:    */   private static final String PRE_INC = "preinc";
/*  68:    */   private static final String POST_INC = "postinc";
/*  69:    */   private static final String PRE_DEC = "predec";
/*  70:    */   private static final String POST_DEC = "postdec";
/*  71:    */   private static final String FUNCCALL1 = "funccall1";
/*  72:    */   private static final String FUNCCALL2 = "funccall2";
/*  73:    */   
/*  74:    */   public SyntheticAccessorRewriter(DCCommonState state, JavaTypeInstance thisClassType)
/*  75:    */   {
/*  76: 43 */     this.state = state;
/*  77: 44 */     this.thisClassType = thisClassType;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void rewrite(Op04StructuredStatement root)
/*  81:    */   {
/*  82: 49 */     List<StructuredStatement> structuredStatements = MiscStatementTools.linearise(root);
/*  83: 50 */     if (structuredStatements == null) {
/*  84: 50 */       return;
/*  85:    */     }
/*  86: 52 */     for (StructuredStatement statement : structuredStatements) {
/*  87: 53 */       statement.rewriteExpressions(this);
/*  88:    */     }
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void handleStatement(StatementContainer statementContainer) {}
/*  92:    */   
/*  93:    */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  94:    */   {
/*  95: 69 */     expression = expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/*  96: 70 */     if ((expression instanceof StaticFunctionInvokation)) {
/*  97: 74 */       return rewriteFunctionExpression((StaticFunctionInvokation)expression);
/*  98:    */     }
/*  99: 76 */     return expression;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public ConditionalExpression rewriteExpression(ConditionalExpression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 103:    */   {
/* 104: 81 */     Expression res = expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 105: 82 */     return (ConditionalExpression)res;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 109:    */   {
/* 110: 93 */     return lValue;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public StackSSALabel rewriteExpression(StackSSALabel lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 114:    */   {
/* 115: 98 */     return lValue;
/* 116:    */   }
/* 117:    */   
/* 118:    */   private Expression rewriteFunctionExpression(StaticFunctionInvokation functionInvokation)
/* 119:    */   {
/* 120:102 */     Expression res = rewriteFunctionExpression2(functionInvokation);
/* 121:104 */     if (res == null) {
/* 122:104 */       return functionInvokation;
/* 123:    */     }
/* 124:105 */     return res;
/* 125:    */   }
/* 126:    */   
/* 127:    */   private static boolean validRelationship(JavaTypeInstance type1, JavaTypeInstance type2)
/* 128:    */   {
/* 129:120 */     Set<JavaTypeInstance> parents1 = SetFactory.newSet();
/* 130:121 */     type1.getInnerClassHereInfo().collectTransitiveDegenericParents(parents1);
/* 131:122 */     parents1.add(type1);
/* 132:123 */     Set<JavaTypeInstance> parents2 = SetFactory.newSet();
/* 133:124 */     type2.getInnerClassHereInfo().collectTransitiveDegenericParents(parents2);
/* 134:125 */     parents2.add(type2);
/* 135:126 */     boolean res = SetUtil.hasIntersection(parents1, parents2);
/* 136:127 */     return res;
/* 137:    */   }
/* 138:    */   
/* 139:    */   private Expression rewriteFunctionExpression2(StaticFunctionInvokation functionInvokation)
/* 140:    */   {
/* 141:131 */     JavaTypeInstance tgtType = functionInvokation.getClazz();
/* 142:133 */     if (!validRelationship(this.thisClassType, tgtType)) {
/* 143:133 */       return null;
/* 144:    */     }
/* 145:135 */     ClassFile otherClass = this.state.getClassFile(tgtType);
/* 146:136 */     JavaTypeInstance otherType = otherClass.getClassType();
/* 147:137 */     MethodPrototype otherPrototype = functionInvokation.getFunction().getMethodPrototype();
/* 148:138 */     List<Expression> appliedArgs = functionInvokation.getArgs();
/* 149:    */     
/* 150:    */ 
/* 151:    */ 
/* 152:    */ 
/* 153:    */ 
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:    */ 
/* 158:    */ 
/* 159:    */ 
/* 160:    */ 
/* 161:    */ 
/* 162:152 */     Method otherMethod = null;
/* 163:    */     try
/* 164:    */     {
/* 165:154 */       otherMethod = otherClass.getMethodByPrototype(otherPrototype);
/* 166:    */     }
/* 167:    */     catch (NoSuchMethodException e)
/* 168:    */     {
/* 169:157 */       return null;
/* 170:    */     }
/* 171:159 */     if (!otherMethod.testAccessFlag(AccessFlagMethod.ACC_STATIC)) {
/* 172:159 */       return null;
/* 173:    */     }
/* 174:160 */     if (!otherMethod.testAccessFlag(AccessFlagMethod.ACC_SYNTHETIC)) {
/* 175:160 */       return null;
/* 176:    */     }
/* 177:164 */     if (!otherMethod.hasCodeAttribute()) {
/* 178:164 */       return null;
/* 179:    */     }
/* 180:165 */     Op04StructuredStatement otherCode = otherMethod.getAnalysis();
/* 181:166 */     if (otherCode == null) {
/* 182:166 */       return null;
/* 183:    */     }
/* 184:167 */     List<LocalVariable> methodArgs = otherMethod.getMethodPrototype().getComputedParameters();
/* 185:    */     
/* 186:169 */     List<StructuredStatement> structuredStatements = MiscStatementTools.linearise(otherCode);
/* 187:    */     
/* 188:171 */     Expression res = tryRewriteAccessor(structuredStatements, otherType, appliedArgs, methodArgs);
/* 189:172 */     if (res != null)
/* 190:    */     {
/* 191:173 */       otherMethod.hideSynthetic();
/* 192:174 */       return res;
/* 193:    */     }
/* 194:177 */     res = tryRewriteFunctionCall(structuredStatements, otherType, appliedArgs, methodArgs);
/* 195:178 */     if (res != null)
/* 196:    */     {
/* 197:179 */       otherMethod.hideSynthetic();
/* 198:180 */       return res;
/* 199:    */     }
/* 200:183 */     return null;
/* 201:    */   }
/* 202:    */   
/* 203:    */   private Expression tryRewriteAccessor(List<StructuredStatement> structuredStatements, JavaTypeInstance otherType, List<Expression> appliedArgs, List<LocalVariable> methodArgs)
/* 204:    */   {
/* 205:188 */     WildcardMatch wcm = new WildcardMatch();
/* 206:    */     
/* 207:    */ 
/* 208:191 */     Matcher<StructuredStatement> matcher = new MatchSequence(new Matcher[] { new BeginBlock(null), new MatchOneOf(new Matcher[] { new ResetAfterTest(wcm, "returnlvalue", new StructuredReturn(new LValueExpression(wcm.getLValueWildCard("lvalue")), null)), new ResetAfterTest(wcm, "mutation1", new MatchSequence(new Matcher[] { new StructuredAssignment(wcm.getLValueWildCard("lvalue"), wcm.getExpressionWildCard("rvalue")), new StructuredReturn(new LValueExpression(wcm.getLValueWildCard("lvalue")), null) })), new ResetAfterTest(wcm, "mutation2", new MatchSequence(new Matcher[] { new StructuredAssignment(wcm.getLValueWildCard("lvalue"), wcm.getExpressionWildCard("rvalue")), new StructuredReturn(wcm.getExpressionWildCard("rvalue"), null) })), new ResetAfterTest(wcm, "preinc", new StructuredReturn(new ArithmeticPreMutationOperation(wcm.getLValueWildCard("lvalue"), ArithOp.PLUS), null)), new ResetAfterTest(wcm, "predec", new StructuredReturn(new ArithmeticPreMutationOperation(wcm.getLValueWildCard("lvalue"), ArithOp.MINUS), null)), new ResetAfterTest(wcm, "postinc", new StructuredReturn(new ArithmeticPostMutationOperation(wcm.getLValueWildCard("lvalue"), ArithOp.PLUS), null)), new ResetAfterTest(wcm, "postinc", new MatchSequence(new Matcher[] { new StructuredExpressionStatement(new ArithmeticPostMutationOperation(wcm.getLValueWildCard("lvalue"), ArithOp.PLUS), false), new StructuredReturn(new LValueExpression(wcm.getLValueWildCard("lvalue")), null) })), new ResetAfterTest(wcm, "postinc", new MatchSequence(new Matcher[] { new StructuredAssignment(wcm.getStackLabelWildcard("tmp"), new LValueExpression(wcm.getLValueWildCard("lvalue"))), new StructuredAssignment(wcm.getLValueWildCard("lvalue"), new ArithmeticOperation(new StackValue(wcm.getStackLabelWildcard("tmp")), new Literal(TypedLiteral.getInt(1)), ArithOp.PLUS)), new StructuredReturn(new StackValue(wcm.getStackLabelWildcard("tmp")), null) })), new ResetAfterTest(wcm, "postdec", new MatchSequence(new Matcher[] { new StructuredExpressionStatement(new ArithmeticPostMutationOperation(wcm.getLValueWildCard("lvalue"), ArithOp.MINUS), false), new StructuredReturn(new LValueExpression(wcm.getLValueWildCard("lvalue")), null) })), new ResetAfterTest(wcm, "postdec", new StructuredReturn(new ArithmeticPostMutationOperation(wcm.getLValueWildCard("lvalue"), ArithOp.MINUS), null)) }), new EndBlock(null) });
/* 209:    */     
/* 210:    */ 
/* 211:    */ 
/* 212:    */ 
/* 213:    */ 
/* 214:    */ 
/* 215:    */ 
/* 216:    */ 
/* 217:    */ 
/* 218:    */ 
/* 219:    */ 
/* 220:    */ 
/* 221:    */ 
/* 222:    */ 
/* 223:    */ 
/* 224:    */ 
/* 225:    */ 
/* 226:    */ 
/* 227:    */ 
/* 228:    */ 
/* 229:    */ 
/* 230:    */ 
/* 231:    */ 
/* 232:    */ 
/* 233:    */ 
/* 234:    */ 
/* 235:    */ 
/* 236:    */ 
/* 237:    */ 
/* 238:    */ 
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:    */ 
/* 243:    */ 
/* 244:    */ 
/* 245:    */ 
/* 246:    */ 
/* 247:    */ 
/* 248:    */ 
/* 249:    */ 
/* 250:    */ 
/* 251:    */ 
/* 252:    */ 
/* 253:    */ 
/* 254:    */ 
/* 255:    */ 
/* 256:    */ 
/* 257:    */ 
/* 258:    */ 
/* 259:    */ 
/* 260:243 */     MatchIterator<StructuredStatement> mi = new MatchIterator(structuredStatements);
/* 261:    */     
/* 262:245 */     AccessorMatchCollector accessorMatchCollector = new AccessorMatchCollector(null);
/* 263:    */     
/* 264:247 */     mi.advance();
/* 265:248 */     if (!matcher.match(mi, accessorMatchCollector)) {
/* 266:248 */       return null;
/* 267:    */     }
/* 268:249 */     if (accessorMatchCollector.matchType == null) {
/* 269:249 */       return null;
/* 270:    */     }
/* 271:251 */     boolean isStatic = accessorMatchCollector.lValue instanceof StaticVariable;
/* 272:252 */     if (isStatic)
/* 273:    */     {
/* 274:254 */       StaticVariable staticVariable = (StaticVariable)accessorMatchCollector.lValue;
/* 275:255 */       if (!otherType.equals(staticVariable.getOwningClassType())) {
/* 276:255 */         return null;
/* 277:    */       }
/* 278:    */     }
/* 279:262 */     String matchType = accessorMatchCollector.matchType;
/* 280:    */     
/* 281:264 */     Map<LValue, LValue> lValueReplacements = MapFactory.newMap();
/* 282:265 */     Map<Expression, Expression> expressionReplacements = MapFactory.newMap();
/* 283:266 */     for (int x = 0; x < methodArgs.size(); x++)
/* 284:    */     {
/* 285:267 */       LocalVariable methodArg = (LocalVariable)methodArgs.get(x);
/* 286:268 */       Expression appliedArg = (Expression)appliedArgs.get(x);
/* 287:269 */       if ((appliedArg instanceof LValueExpression))
/* 288:    */       {
/* 289:270 */         LValue appliedLvalue = ((LValueExpression)appliedArg).getLValue();
/* 290:271 */         lValueReplacements.put(methodArg, appliedLvalue);
/* 291:    */       }
/* 292:273 */       expressionReplacements.put(new LValueExpression(methodArg), appliedArg);
/* 293:    */     }
/* 294:275 */     CloneHelper cloneHelper = new CloneHelper(expressionReplacements, lValueReplacements);
/* 295:277 */     if ((matchType.equals("mutation1")) || (matchType.equals("mutation2")))
/* 296:    */     {
/* 297:278 */       AssignmentExpression assignmentExpression = new AssignmentExpression(accessorMatchCollector.lValue, accessorMatchCollector.rValue);
/* 298:279 */       return cloneHelper.replaceOrClone(assignmentExpression);
/* 299:    */     }
/* 300:280 */     if (matchType.equals("returnlvalue")) {
/* 301:281 */       return cloneHelper.replaceOrClone(new LValueExpression(accessorMatchCollector.lValue));
/* 302:    */     }
/* 303:282 */     if (matchType.equals("predec"))
/* 304:    */     {
/* 305:283 */       Expression res = new ArithmeticPreMutationOperation(accessorMatchCollector.lValue, ArithOp.MINUS);
/* 306:284 */       return cloneHelper.replaceOrClone(res);
/* 307:    */     }
/* 308:285 */     if (matchType.equals("preinc"))
/* 309:    */     {
/* 310:286 */       Expression res = new ArithmeticPreMutationOperation(accessorMatchCollector.lValue, ArithOp.PLUS);
/* 311:287 */       return cloneHelper.replaceOrClone(res);
/* 312:    */     }
/* 313:288 */     if (matchType.equals("postdec"))
/* 314:    */     {
/* 315:289 */       Expression res = new ArithmeticPostMutationOperation(accessorMatchCollector.lValue, ArithOp.MINUS);
/* 316:290 */       return cloneHelper.replaceOrClone(res);
/* 317:    */     }
/* 318:291 */     if (matchType.equals("postinc"))
/* 319:    */     {
/* 320:292 */       Expression res = new ArithmeticPostMutationOperation(accessorMatchCollector.lValue, ArithOp.PLUS);
/* 321:293 */       return cloneHelper.replaceOrClone(res);
/* 322:    */     }
/* 323:295 */     throw new IllegalStateException();
/* 324:    */   }
/* 325:    */   
/* 326:    */   private class AccessorMatchCollector
/* 327:    */     extends AbstractMatchResultIterator
/* 328:    */   {
/* 329:    */     String matchType;
/* 330:    */     LValue lValue;
/* 331:    */     Expression rValue;
/* 332:    */     
/* 333:    */     private AccessorMatchCollector() {}
/* 334:    */     
/* 335:    */     public void clear() {}
/* 336:    */     
/* 337:    */     public void collectStatement(String name, StructuredStatement statement) {}
/* 338:    */     
/* 339:    */     public void collectMatches(String name, WildcardMatch wcm)
/* 340:    */     {
/* 341:362 */       this.matchType = name;
/* 342:363 */       this.lValue = wcm.getLValueWildCard("lvalue").getMatch();
/* 343:364 */       if ((this.matchType.equals("mutation1")) || (this.matchType.equals("mutation2"))) {
/* 344:365 */         this.rValue = wcm.getExpressionWildCard("rvalue").getMatch();
/* 345:    */       }
/* 346:    */     }
/* 347:    */   }
/* 348:    */   
/* 349:370 */   private final String MEM_SUB1 = "msub1";
/* 350:371 */   private final String STA_SUB1 = "ssub1";
/* 351:372 */   private final String MEM_FUN1 = "mfun1";
/* 352:373 */   private final String STA_FUN1 = "sfun1";
/* 353:    */   
/* 354:    */   private Expression tryRewriteFunctionCall(List<StructuredStatement> structuredStatements, JavaTypeInstance otherType, List<Expression> appliedArgs, List<LocalVariable> methodArgs)
/* 355:    */   {
/* 356:377 */     WildcardMatch wcm = new WildcardMatch();
/* 357:    */     
/* 358:379 */     Matcher<StructuredStatement> matcher = new MatchSequence(new Matcher[] { new BeginBlock(null), new MatchOneOf(new Matcher[] { new ResetAfterTest(wcm, "msub1", new StructuredExpressionStatement(wcm.getMemberFunction("func", null, false, new LValueExpression(wcm.getLValueWildCard("lvalue")), null), false)), new ResetAfterTest(wcm, "ssub1", new StructuredExpressionStatement(wcm.getStaticFunction("func", otherType, null, null, (List)null), false)), new ResetAfterTest(wcm, "mfun1", new StructuredReturn(wcm.getMemberFunction("func", null, false, new LValueExpression(wcm.getLValueWildCard("lvalue")), null), null)), new ResetAfterTest(wcm, "sfun1", new StructuredReturn(wcm.getStaticFunction("func", otherType, null, null, (List)null), null)) }), new EndBlock(null) });
/* 359:    */     
/* 360:    */ 
/* 361:    */ 
/* 362:    */ 
/* 363:    */ 
/* 364:    */ 
/* 365:    */ 
/* 366:    */ 
/* 367:    */ 
/* 368:    */ 
/* 369:    */ 
/* 370:    */ 
/* 371:    */ 
/* 372:    */ 
/* 373:    */ 
/* 374:    */ 
/* 375:    */ 
/* 376:    */ 
/* 377:398 */     MatchIterator<StructuredStatement> mi = new MatchIterator(structuredStatements);
/* 378:    */     
/* 379:400 */     FuncMatchCollector funcMatchCollector = new FuncMatchCollector(null);
/* 380:    */     
/* 381:402 */     mi.advance();
/* 382:403 */     if (!matcher.match(mi, funcMatchCollector)) {
/* 383:403 */       return null;
/* 384:    */     }
/* 385:404 */     if (funcMatchCollector.matchType == null) {
/* 386:404 */       return null;
/* 387:    */     }
/* 388:406 */     Map<LValue, LValue> lValueReplacements = MapFactory.newMap();
/* 389:407 */     Map<Expression, Expression> expressionReplacements = MapFactory.newMap();
/* 390:408 */     for (int x = 0; x < methodArgs.size(); x++)
/* 391:    */     {
/* 392:409 */       LocalVariable methodArg = (LocalVariable)methodArgs.get(x);
/* 393:410 */       Expression appliedArg = (Expression)appliedArgs.get(x);
/* 394:411 */       if ((appliedArg instanceof LValueExpression))
/* 395:    */       {
/* 396:412 */         LValue appliedLvalue = ((LValueExpression)appliedArg).getLValue();
/* 397:413 */         lValueReplacements.put(methodArg, appliedLvalue);
/* 398:    */       }
/* 399:415 */       expressionReplacements.put(new LValueExpression(methodArg), appliedArg);
/* 400:    */     }
/* 401:417 */     CloneHelper cloneHelper = new CloneHelper(expressionReplacements, lValueReplacements);
/* 402:418 */     return cloneHelper.replaceOrClone(funcMatchCollector.functionInvokation);
/* 403:    */   }
/* 404:    */   
/* 405:    */   private class FuncMatchCollector
/* 406:    */     extends AbstractMatchResultIterator
/* 407:    */   {
/* 408:    */     String matchType;
/* 409:    */     LValue lValue;
/* 410:    */     StaticFunctionInvokation staticFunctionInvokation;
/* 411:    */     MemberFunctionInvokation memberFunctionInvokation;
/* 412:    */     Expression functionInvokation;
/* 413:    */     private boolean isStatic;
/* 414:    */     
/* 415:    */     private FuncMatchCollector() {}
/* 416:    */     
/* 417:    */     public void clear() {}
/* 418:    */     
/* 419:    */     public void collectStatement(String name, StructuredStatement statement) {}
/* 420:    */     
/* 421:    */     public void collectMatches(String name, WildcardMatch wcm)
/* 422:    */     {
/* 423:443 */       this.matchType = name;
/* 424:444 */       if ((this.matchType.equals("sfun1")) || (this.matchType.endsWith("ssub1")))
/* 425:    */       {
/* 426:445 */         this.staticFunctionInvokation = wcm.getStaticFunction("func").getMatch();
/* 427:446 */         this.functionInvokation = this.staticFunctionInvokation;
/* 428:447 */         this.isStatic = true;
/* 429:    */       }
/* 430:    */       else
/* 431:    */       {
/* 432:449 */         this.memberFunctionInvokation = wcm.getMemberFunction("func").getMatch();
/* 433:450 */         this.functionInvokation = this.memberFunctionInvokation;
/* 434:451 */         this.lValue = wcm.getLValueWildCard("lvalue").getMatch();
/* 435:452 */         this.isStatic = false;
/* 436:    */       }
/* 437:    */     }
/* 438:    */   }
/* 439:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SyntheticAccessorRewriter
 * JD-Core Version:    0.7.0.1
 */