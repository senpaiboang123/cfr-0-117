/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*   2:    */ 
/*   3:    */ import java.util.Collections;
/*   4:    */ import java.util.LinkedList;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Set;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.InstrIndex;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractFunctionInvokation;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AssignmentExpression;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.BooleanOperation;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.TernaryExpression;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.AbstractExpressionRewriter;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.AssignmentSimple;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.WhileStatement;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollectorSimple;
/*  26:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  27:    */ import org.benf.cfr.reader.util.ListFactory;
/*  28:    */ import org.benf.cfr.reader.util.SetFactory;
/*  29:    */ 
/*  30:    */ public class InlineDeAssigner
/*  31:    */ {
/*  32:    */   private static class Deassigner
/*  33:    */     extends AbstractExpressionRewriter
/*  34:    */   {
/*  35: 45 */     Set<LValue> read = SetFactory.newSet();
/*  36: 46 */     Set<LValue> write = SetFactory.newSet();
/*  37: 48 */     List<AssignmentExpression> extracted = ListFactory.newList();
/*  38: 50 */     boolean noFurther = false;
/*  39:    */     
/*  40:    */     private Expression tryExtractAssignment(AssignmentExpression assignmentExpression)
/*  41:    */     {
/*  42: 64 */       LValue lValue = assignmentExpression.getlValue();
/*  43: 65 */       if ((this.read.contains(lValue)) || (this.write.contains(lValue))) {
/*  44: 65 */         return assignmentExpression;
/*  45:    */       }
/*  46: 66 */       LValueUsageCollectorSimple lValueUsageCollectorSimple = new LValueUsageCollectorSimple();
/*  47: 67 */       assignmentExpression.getrValue().collectUsedLValues(lValueUsageCollectorSimple);
/*  48: 68 */       for (LValue lValue1 : lValueUsageCollectorSimple.getUsedLValues()) {
/*  49: 69 */         if (this.write.contains(lValue1)) {
/*  50: 69 */           return assignmentExpression;
/*  51:    */         }
/*  52:    */       }
/*  53: 71 */       this.extracted.add(assignmentExpression);
/*  54: 72 */       return new LValueExpression(lValue);
/*  55:    */     }
/*  56:    */     
/*  57:    */     public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  58:    */     {
/*  59: 77 */       if (this.noFurther) {
/*  60: 77 */         return expression;
/*  61:    */       }
/*  62: 81 */       if ((expression instanceof ConditionalExpression)) {
/*  63: 81 */         return rewriteExpression((ConditionalExpression)expression, ssaIdentifiers, statementContainer, flags);
/*  64:    */       }
/*  65: 86 */       if ((expression instanceof AssignmentExpression))
/*  66:    */       {
/*  67: 87 */         AssignmentExpression assignmentExpression = (AssignmentExpression)expression;
/*  68: 88 */         assignmentExpression.applyRValueOnlyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/*  69: 89 */         return tryExtractAssignment((AssignmentExpression)expression);
/*  70:    */       }
/*  71: 94 */       if ((expression instanceof TernaryExpression))
/*  72:    */       {
/*  73: 95 */         TernaryExpression ternaryExpression = (TernaryExpression)expression;
/*  74: 96 */         expression = ternaryExpression.applyConditionOnlyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/*  75: 97 */         this.noFurther = true;
/*  76: 98 */         return expression;
/*  77:    */       }
/*  78:101 */       Expression result = super.rewriteExpression(expression, ssaIdentifiers, statementContainer, flags);
/*  79:103 */       if ((expression instanceof AbstractFunctionInvokation)) {
/*  80:104 */         this.noFurther = true;
/*  81:    */       }
/*  82:106 */       return result;
/*  83:    */     }
/*  84:    */     
/*  85:    */     public ConditionalExpression rewriteExpression(ConditionalExpression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  86:    */     {
/*  87:111 */       if (this.noFurther) {
/*  88:111 */         return expression;
/*  89:    */       }
/*  90:114 */       if ((expression instanceof BooleanOperation))
/*  91:    */       {
/*  92:115 */         BooleanOperation booleanOperation = (BooleanOperation)expression;
/*  93:116 */         ConditionalExpression lhs = booleanOperation.getLhs();
/*  94:117 */         ConditionalExpression lhs2 = rewriteExpression(lhs, ssaIdentifiers, statementContainer, flags);
/*  95:118 */         if (lhs2 != lhs) {
/*  96:119 */           return new BooleanOperation(lhs2, booleanOperation.getRhs(), booleanOperation.getOp());
/*  97:    */         }
/*  98:121 */         this.noFurther = true;
/*  99:122 */         return expression;
/* 100:    */       }
/* 101:124 */       return super.rewriteExpression(expression, ssaIdentifiers, statementContainer, flags);
/* 102:    */     }
/* 103:    */     
/* 104:    */     public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 105:    */     {
/* 106:130 */       switch (InlineDeAssigner.1.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$rewriters$ExpressionRewriterFlags[flags.ordinal()])
/* 107:    */       {
/* 108:    */       case 1: 
/* 109:132 */         this.write.add(lValue);
/* 110:133 */         break;
/* 111:    */       case 2: 
/* 112:135 */         this.read.add(lValue);
/* 113:136 */         break;
/* 114:    */       case 3: 
/* 115:138 */         this.write.add(lValue);
/* 116:139 */         this.read.add(lValue);
/* 117:    */       }
/* 118:142 */       return lValue;
/* 119:    */     }
/* 120:    */     
/* 121:    */     public StackSSALabel rewriteExpression(StackSSALabel lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 122:    */     {
/* 123:147 */       return (StackSSALabel)rewriteExpression(lValue, ssaIdentifiers, statementContainer, flags);
/* 124:    */     }
/* 125:    */   }
/* 126:    */   
/* 127:    */   private static void rewrite(Deassigner deassigner, Op03SimpleStatement container, List<Op03SimpleStatement> added)
/* 128:    */   {
/* 129:153 */     List<AssignmentExpression> assignmentExpressions = deassigner.extracted;
/* 130:154 */     if (assignmentExpressions.isEmpty()) {
/* 131:154 */       return;
/* 132:    */     }
/* 133:155 */     Collections.reverse(assignmentExpressions);
/* 134:156 */     InstrIndex index = container.getIndex();
/* 135:157 */     Op03SimpleStatement last = container;
/* 136:158 */     List<Op03SimpleStatement> sources = ListFactory.newList(container.getSources());
/* 137:159 */     container.getSources().clear();
/* 138:160 */     for (AssignmentExpression expression : assignmentExpressions)
/* 139:    */     {
/* 140:161 */       index = index.justBefore();
/* 141:162 */       AssignmentSimple assignmentSimple = new AssignmentSimple(expression.getlValue(), expression.getrValue());
/* 142:163 */       Op03SimpleStatement newAssign = new Op03SimpleStatement(container.getBlockIdentifiers(), assignmentSimple, index);
/* 143:164 */       added.add(newAssign);
/* 144:165 */       newAssign.addTarget(last);
/* 145:166 */       last.addSource(newAssign);
/* 146:167 */       last = newAssign;
/* 147:    */     }
/* 148:169 */     for (Op03SimpleStatement source : sources)
/* 149:    */     {
/* 150:170 */       source.replaceTarget(container, last);
/* 151:171 */       last.addSource(source);
/* 152:    */     }
/* 153:    */   }
/* 154:    */   
/* 155:    */   private static void deAssign(AssignmentSimple assignmentSimple, Op03SimpleStatement container, List<Op03SimpleStatement> added)
/* 156:    */   {
/* 157:181 */     Expression rhs = assignmentSimple.getRValue();
/* 158:182 */     if (((rhs instanceof LValueExpression)) || ((rhs instanceof Literal))) {
/* 159:182 */       return;
/* 160:    */     }
/* 161:183 */     Deassigner deassigner = new Deassigner(null);
/* 162:184 */     LinkedList<LValue> lValues = ListFactory.newLinkedList();
/* 163:185 */     while ((rhs instanceof AssignmentExpression))
/* 164:    */     {
/* 165:186 */       AssignmentExpression assignmentExpression = (AssignmentExpression)rhs;
/* 166:187 */       lValues.addFirst(assignmentExpression.getlValue());
/* 167:188 */       rhs = assignmentExpression.getrValue();
/* 168:    */     }
/* 169:191 */     Expression rhs2 = deassigner.rewriteExpression(rhs, container.getSSAIdentifiers(), container, ExpressionRewriterFlags.RVALUE);
/* 170:192 */     if (deassigner.extracted.isEmpty()) {
/* 171:192 */       return;
/* 172:    */     }
/* 173:193 */     for (LValue outer : lValues) {
/* 174:194 */       rhs2 = new AssignmentExpression(outer, rhs2);
/* 175:    */     }
/* 176:196 */     assignmentSimple.setRValue(rhs2);
/* 177:197 */     rewrite(deassigner, container, added);
/* 178:    */   }
/* 179:    */   
/* 180:    */   private static void deAssign(Op03SimpleStatement container, List<Op03SimpleStatement> added)
/* 181:    */   {
/* 182:201 */     Deassigner deassigner = new Deassigner(null);
/* 183:202 */     container.rewrite(deassigner);
/* 184:203 */     rewrite(deassigner, container, added);
/* 185:    */   }
/* 186:    */   
/* 187:    */   public static boolean extractAssignments(List<Op03SimpleStatement> statements)
/* 188:    */   {
/* 189:207 */     List<Op03SimpleStatement> newStatements = ListFactory.newList();
/* 190:208 */     for (Op03SimpleStatement statement : statements) {
/* 191:209 */       if (statement.getSources().size() == 1)
/* 192:    */       {
/* 193:210 */         Statement stmt = statement.getStatement();
/* 194:211 */         Class<? extends Statement> clazz = stmt.getClass();
/* 195:212 */         if (clazz == AssignmentSimple.class) {
/* 196:213 */           deAssign((AssignmentSimple)stmt, statement, newStatements);
/* 197:214 */         } else if (clazz != WhileStatement.class) {
/* 198:217 */           deAssign(statement, newStatements);
/* 199:    */         }
/* 200:    */       }
/* 201:    */     }
/* 202:220 */     if (newStatements.isEmpty()) {
/* 203:220 */       return false;
/* 204:    */     }
/* 205:221 */     statements.addAll(newStatements);
/* 206:222 */     Cleaner.sortAndRenumberInPlace(statements);
/* 207:223 */     return true;
/* 208:    */   }
/* 209:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.InlineDeAssigner
 * JD-Core Version:    0.7.0.1
 */