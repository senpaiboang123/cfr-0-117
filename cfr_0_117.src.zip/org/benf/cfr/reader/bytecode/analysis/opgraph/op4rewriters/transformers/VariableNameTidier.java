/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.HashSet;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.LinkedList;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.Set;
/*  10:    */ import org.benf.cfr.reader.bytecode.BytecodeMeta;
/*  11:    */ import org.benf.cfr.reader.bytecode.BytecodeMeta.CodeInfoFlag;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LambdaExpression;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.SentinelLocalClassLValue;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StaticVariable;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.AbstractExpressionRewriter;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  26:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  27:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  28:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  29:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  30:    */ import org.benf.cfr.reader.bytecode.analysis.variables.Keywords;
/*  31:    */ import org.benf.cfr.reader.bytecode.analysis.variables.NamedVariable;
/*  32:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  33:    */ import org.benf.cfr.reader.entities.Method;
/*  34:    */ import org.benf.cfr.reader.state.ClassCache;
/*  35:    */ import org.benf.cfr.reader.util.ListFactory;
/*  36:    */ import org.benf.cfr.reader.util.MapFactory;
/*  37:    */ import org.benf.cfr.reader.util.Predicate;
/*  38:    */ import org.benf.cfr.reader.util.SetFactory;
/*  39:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  40:    */ 
/*  41:    */ public class VariableNameTidier
/*  42:    */   implements StructuredStatementTransformer
/*  43:    */ {
/*  44:    */   private final Method method;
/*  45: 32 */   private boolean classRenamed = false;
/*  46:    */   private final JavaTypeInstance ownerClassType;
/*  47:    */   private final Set<String> bannedNames;
/*  48:    */   private final ClassCache classCache;
/*  49:    */   
/*  50:    */   public VariableNameTidier(Method method, Set<String> bannedNames, ClassCache classCache)
/*  51:    */   {
/*  52: 39 */     this.method = method;
/*  53: 40 */     this.ownerClassType = method.getClassFile().getClassType();
/*  54: 41 */     this.bannedNames = bannedNames;
/*  55: 42 */     this.classCache = classCache;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public VariableNameTidier(Method method, ClassCache classCache)
/*  59:    */   {
/*  60: 46 */     this(method, new HashSet(), classCache);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void transform(Op04StructuredStatement root)
/*  64:    */   {
/*  65: 50 */     StructuredScopeWithVars structuredScopeWithVars = new StructuredScopeWithVars(null);
/*  66: 51 */     structuredScopeWithVars.add(null);
/*  67: 52 */     List<LocalVariable> params = this.method.getMethodPrototype().getComputedParameters();
/*  68: 53 */     for (LocalVariable param : params) {
/*  69: 54 */       structuredScopeWithVars.defineHere(null, param);
/*  70:    */     }
/*  71: 57 */     root.transform(this, structuredScopeWithVars);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public static class NameDiscoverer
/*  75:    */     extends AbstractExpressionRewriter
/*  76:    */     implements StructuredStatementTransformer
/*  77:    */   {
/*  78: 70 */     private final Set<String> usedNames = SetFactory.newSet();
/*  79: 71 */     private static final Set<String> EMPTY = ;
/*  80:    */     
/*  81:    */     private void addLValues(Collection<LValue> definedHere)
/*  82:    */     {
/*  83: 78 */       if (definedHere == null) {
/*  84: 78 */         return;
/*  85:    */       }
/*  86: 79 */       for (LValue scopedEntity : definedHere) {
/*  87: 80 */         if ((scopedEntity instanceof LocalVariable))
/*  88:    */         {
/*  89: 81 */           NamedVariable namedVariable = ((LocalVariable)scopedEntity).getName();
/*  90: 82 */           this.usedNames.add(namedVariable.getStringName());
/*  91:    */         }
/*  92:    */       }
/*  93:    */     }
/*  94:    */     
/*  95:    */     public StructuredStatement transform(StructuredStatement in, StructuredScope scope)
/*  96:    */     {
/*  97: 93 */       in.rewriteExpressions(this);
/*  98:    */       
/*  99: 95 */       in.transformStructuredChildren(this, scope);
/* 100: 96 */       return in;
/* 101:    */     }
/* 102:    */     
/* 103:    */     public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 104:    */     {
/* 105:101 */       if ((expression instanceof LambdaExpression))
/* 106:    */       {
/* 107:102 */         addLValues(((LambdaExpression)expression).getArgs());
/* 108:103 */         return expression;
/* 109:    */       }
/* 110:105 */       return expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 111:    */     }
/* 112:    */     
/* 113:    */     public static Set<String> getUsedLambdaNames(BytecodeMeta bytecodeMeta, Op04StructuredStatement in)
/* 114:    */     {
/* 115:111 */       if (!bytecodeMeta.has(BytecodeMeta.CodeInfoFlag.USES_INVOKEDYNAMIC)) {
/* 116:112 */         return EMPTY;
/* 117:    */       }
/* 118:114 */       NameDiscoverer discoverer = new NameDiscoverer();
/* 119:115 */       in.transform(discoverer, new StructuredScope());
/* 120:116 */       return discoverer.usedNames;
/* 121:    */     }
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void renameToAvoidHiding(Set<String> avoid, List<LocalVariable> collisions)
/* 125:    */   {
/* 126:121 */     StructuredScopeWithVars structuredScopeWithVars = new StructuredScopeWithVars(null);
/* 127:122 */     structuredScopeWithVars.add(null);
/* 128:123 */     structuredScopeWithVars.markInitiallyDefined(avoid);
/* 129:124 */     for (LocalVariable hider : collisions) {
/* 130:126 */       structuredScopeWithVars.defineHere(hider);
/* 131:    */     }
/* 132:    */   }
/* 133:    */   
/* 134:    */   public boolean isClassRenamed()
/* 135:    */   {
/* 136:131 */     return this.classRenamed;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public StructuredStatement transform(StructuredStatement in, StructuredScope scope)
/* 140:    */   {
/* 141:136 */     StructuredScopeWithVars structuredScopeWithVars = (StructuredScopeWithVars)scope;
/* 142:    */     
/* 143:138 */     List<LValue> definedHere = in.findCreatedHere();
/* 144:139 */     if (definedHere != null) {
/* 145:140 */       for (LValue scopedEntity : definedHere)
/* 146:    */       {
/* 147:141 */         if ((scopedEntity instanceof LocalVariable)) {
/* 148:142 */           structuredScopeWithVars.defineHere(in, (LocalVariable)scopedEntity);
/* 149:    */         }
/* 150:144 */         if ((scopedEntity instanceof SentinelLocalClassLValue)) {
/* 151:145 */           structuredScopeWithVars.defineLocalClassHere(in, (SentinelLocalClassLValue)scopedEntity);
/* 152:    */         }
/* 153:    */       }
/* 154:    */     }
/* 155:155 */     ExpressionRewriter simplifier = new NameSimplifier(this.ownerClassType, structuredScopeWithVars, null);
/* 156:156 */     in.rewriteExpressions(simplifier);
/* 157:    */     
/* 158:158 */     in.transformStructuredChildren(this, scope);
/* 159:159 */     return in;
/* 160:    */   }
/* 161:    */   
/* 162:    */   private static class NameSimplifier
/* 163:    */     extends AbstractExpressionRewriter
/* 164:    */   {
/* 165:    */     private final VariableNameTidier.StructuredScopeWithVars localScope;
/* 166:    */     private final JavaTypeInstance ownerClassType;
/* 167:    */     
/* 168:    */     private NameSimplifier(JavaTypeInstance ownerClassType, VariableNameTidier.StructuredScopeWithVars localScope)
/* 169:    */     {
/* 170:167 */       this.ownerClassType = ownerClassType;
/* 171:168 */       this.localScope = localScope;
/* 172:    */     }
/* 173:    */     
/* 174:    */     public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 175:    */     {
/* 176:173 */       if (lValue.getClass() == StaticVariable.class)
/* 177:    */       {
/* 178:174 */         StaticVariable staticVariable = (StaticVariable)lValue;
/* 179:175 */         if ((staticVariable.getOwningClassType().equals(this.ownerClassType)) && 
/* 180:176 */           (!this.localScope.isDefined(staticVariable.getFieldName()))) {
/* 181:177 */           return staticVariable.getSimpleCopy();
/* 182:    */         }
/* 183:    */       }
/* 184:181 */       return lValue;
/* 185:    */     }
/* 186:    */   }
/* 187:    */   
/* 188:    */   private class StructuredScopeWithVars
/* 189:    */     extends StructuredScope
/* 190:    */   {
/* 191:    */     private final LinkedList<AtLevel> scope;
/* 192:    */     private final Map<String, Integer> nextPostFixed;
/* 193:    */     
/* 194:    */     private StructuredScopeWithVars()
/* 195:    */     {
/* 196:187 */       this.scope = ListFactory.newLinkedList();
/* 197:188 */       this.nextPostFixed = MapFactory.newLazyMap(new UnaryFunction()
/* 198:    */       {
/* 199:    */         public Integer invoke(String arg)
/* 200:    */         {
/* 201:191 */           return Integer.valueOf(2);
/* 202:    */         }
/* 203:    */       });
/* 204:    */     }
/* 205:    */     
/* 206:    */     public void remove(StructuredStatement statement)
/* 207:    */     {
/* 208:196 */       super.remove(statement);
/* 209:197 */       this.scope.removeFirst();
/* 210:    */     }
/* 211:    */     
/* 212:    */     public void add(StructuredStatement statement)
/* 213:    */     {
/* 214:202 */       super.add(statement);
/* 215:203 */       this.scope.addFirst(new AtLevel(statement, null));
/* 216:    */     }
/* 217:    */     
/* 218:    */     private boolean alreadyDefined(String name)
/* 219:    */     {
/* 220:207 */       return alreadyDefined(name, true);
/* 221:    */     }
/* 222:    */     
/* 223:    */     private boolean alreadyDefined(String name, boolean checkClassCache)
/* 224:    */     {
/* 225:211 */       if (VariableNameTidier.this.bannedNames.contains(name)) {
/* 226:211 */         return true;
/* 227:    */       }
/* 228:212 */       for (AtLevel atLevel : this.scope) {
/* 229:213 */         if (atLevel.isDefinedHere(name)) {
/* 230:214 */           return true;
/* 231:    */         }
/* 232:    */       }
/* 233:220 */       if ((checkClassCache) && (VariableNameTidier.this.classCache.isClassName(name))) {
/* 234:220 */         return true;
/* 235:    */       }
/* 236:221 */       return false;
/* 237:    */     }
/* 238:    */     
/* 239:    */     private String getNext(String base)
/* 240:    */     {
/* 241:225 */       int postfix = ((Integer)this.nextPostFixed.get(base)).intValue();
/* 242:226 */       this.nextPostFixed.put(base, Integer.valueOf(postfix + 1));
/* 243:227 */       return base + postfix;
/* 244:    */     }
/* 245:    */     
/* 246:    */     private String suggestByType(LocalVariable localVariable)
/* 247:    */     {
/* 248:231 */       JavaTypeInstance type = localVariable.getInferredJavaType().getJavaTypeInstance();
/* 249:    */       
/* 250:    */ 
/* 251:    */ 
/* 252:235 */       RawJavaType raw = RawJavaType.getUnboxedTypeFor(type);
/* 253:236 */       if (raw != null) {
/* 254:236 */         type = raw;
/* 255:    */       }
/* 256:237 */       return type.suggestVarName();
/* 257:    */     }
/* 258:    */     
/* 259:    */     private String mkLcMojo(String in)
/* 260:    */     {
/* 261:241 */       return " class!" + in;
/* 262:    */     }
/* 263:    */     
/* 264:    */     public void defineLocalClassHere(StructuredStatement statement, SentinelLocalClassLValue localVariable)
/* 265:    */     {
/* 266:245 */       JavaTypeInstance type = localVariable.getLocalClassType();
/* 267:246 */       String name = type.suggestVarName();
/* 268:247 */       if (name == null) {
/* 269:247 */         name = type.getRawName().replace('.', '_');
/* 270:    */       }
/* 271:248 */       char[] chars = name.toCharArray();
/* 272:249 */       int idx = 0;
/* 273:249 */       for (int len = chars.length; idx < len; idx++)
/* 274:    */       {
/* 275:250 */         char c = chars[idx];
/* 276:251 */         if ((c < '0') || (c > '9'))
/* 277:    */         {
/* 278:252 */           chars[idx] = Character.toUpperCase(chars[idx]);
/* 279:253 */           name = new String(chars, idx, chars.length - idx);
/* 280:254 */           break;
/* 281:    */         }
/* 282:    */       }
/* 283:258 */       String lcMojo = mkLcMojo(name);
/* 284:259 */       if (!alreadyDefined(lcMojo))
/* 285:    */       {
/* 286:260 */         ((AtLevel)this.scope.getFirst()).defineHere(lcMojo);
/* 287:261 */         VariableNameTidier.this.method.markUsedLocalClassType(type, name);
/* 288:    */       }
/* 289:    */       else
/* 290:    */       {
/* 291:    */         String postfixedVarName;
/* 292:    */         do
/* 293:    */         {
/* 294:267 */           postfixedVarName = getNext(name);
/* 295:268 */         } while (alreadyDefined(mkLcMojo(postfixedVarName)));
/* 296:269 */         ((AtLevel)this.scope.getFirst()).defineHere(mkLcMojo(postfixedVarName));
/* 297:    */         
/* 298:271 */         VariableNameTidier.this.method.markUsedLocalClassType(type, postfixedVarName);
/* 299:272 */         VariableNameTidier.this.classRenamed = true;
/* 300:    */       }
/* 301:    */     }
/* 302:    */     
/* 303:    */     public void defineHere(StructuredStatement statement, LocalVariable localVariable)
/* 304:    */     {
/* 305:277 */       NamedVariable namedVariable = localVariable.getName();
/* 306:278 */       if (!namedVariable.isGoodName())
/* 307:    */       {
/* 308:279 */         String suggestion = null;
/* 309:280 */         if (statement != null) {
/* 310:281 */           suggestion = statement.suggestName(localVariable, new Predicate()
/* 311:    */           {
/* 312:    */             public boolean test(String in)
/* 313:    */             {
/* 314:284 */               return VariableNameTidier.StructuredScopeWithVars.this.alreadyDefined(in);
/* 315:    */             }
/* 316:    */           });
/* 317:    */         }
/* 318:288 */         if (suggestion == null) {
/* 319:288 */           suggestion = suggestByType(localVariable);
/* 320:    */         }
/* 321:289 */         if (suggestion != null)
/* 322:    */         {
/* 323:290 */           if ((suggestion.length() == 1) && (suggestion.toUpperCase().equals(suggestion))) {
/* 324:290 */             suggestion = suggestion.toLowerCase();
/* 325:    */           }
/* 326:291 */           namedVariable.forceName(suggestion);
/* 327:    */         }
/* 328:    */       }
/* 329:294 */       if (Keywords.isAKeyword(namedVariable.getStringName())) {
/* 330:295 */         namedVariable.forceName(namedVariable.getStringName() + "_");
/* 331:    */       }
/* 332:298 */       defineHere(localVariable);
/* 333:    */     }
/* 334:    */     
/* 335:    */     public void markInitiallyDefined(Set<String> names)
/* 336:    */     {
/* 337:    */       String name;
/* 338:302 */       for (Iterator i$ = names.iterator(); i$.hasNext(); ((AtLevel)this.scope.getFirst()).defineHere(name)) {
/* 339:302 */         name = (String)i$.next();
/* 340:    */       }
/* 341:    */     }
/* 342:    */     
/* 343:    */     public boolean isDefined(String anyNameType)
/* 344:    */     {
/* 345:306 */       return alreadyDefined(anyNameType, false);
/* 346:    */     }
/* 347:    */     
/* 348:    */     public void defineHere(LocalVariable localVariable)
/* 349:    */     {
/* 350:314 */       NamedVariable namedVariable = localVariable.getName();
/* 351:315 */       String base = namedVariable.getStringName();
/* 352:316 */       if (!alreadyDefined(base))
/* 353:    */       {
/* 354:317 */         ((AtLevel)this.scope.getFirst()).defineHere(base);
/* 355:    */       }
/* 356:    */       else
/* 357:    */       {
/* 358:    */         String postfixedVarName;
/* 359:    */         do
/* 360:    */         {
/* 361:325 */           postfixedVarName = getNext(base);
/* 362:326 */         } while (alreadyDefined(postfixedVarName));
/* 363:327 */         localVariable.getName().forceName(postfixedVarName);
/* 364:328 */         ((AtLevel)this.scope.getFirst()).defineHere(postfixedVarName);
/* 365:    */       }
/* 366:    */     }
/* 367:    */     
/* 368:    */     protected class AtLevel
/* 369:    */     {
/* 370:    */       StructuredStatement statement;
/* 371:333 */       Set<String> definedHere = SetFactory.newSet();
/* 372:    */       int next;
/* 373:    */       
/* 374:    */       private AtLevel(StructuredStatement statement)
/* 375:    */       {
/* 376:337 */         this.statement = statement;
/* 377:338 */         this.next = 0;
/* 378:    */       }
/* 379:    */       
/* 380:    */       public String toString()
/* 381:    */       {
/* 382:343 */         return this.statement.toString();
/* 383:    */       }
/* 384:    */       
/* 385:    */       public boolean isDefinedHere(String name)
/* 386:    */       {
/* 387:347 */         return this.definedHere.contains(name);
/* 388:    */       }
/* 389:    */       
/* 390:    */       public void defineHere(String name)
/* 391:    */       {
/* 392:351 */         this.definedHere.add(name);
/* 393:    */       }
/* 394:    */     }
/* 395:    */   }
/* 396:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.VariableNameTidier
 * JD-Core Version:    0.7.0.1
 */