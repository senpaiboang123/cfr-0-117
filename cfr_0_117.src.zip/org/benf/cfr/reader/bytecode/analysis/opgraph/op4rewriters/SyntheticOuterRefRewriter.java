/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.FieldVariable;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 12:   */ 
/* 13:   */ public class SyntheticOuterRefRewriter
/* 14:   */   implements ExpressionRewriter
/* 15:   */ {
/* 16:   */   public void handleStatement(StatementContainer statementContainer) {}
/* 17:   */   
/* 18:   */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 19:   */   {
/* 20:39 */     return expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public ConditionalExpression rewriteExpression(ConditionalExpression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 24:   */   {
/* 25:44 */     Expression res = expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 26:45 */     return (ConditionalExpression)res;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 30:   */   {
/* 31:56 */     if ((lValue instanceof FieldVariable)) {
/* 32:57 */       ((FieldVariable)lValue).rewriteLeftNestedSyntheticOuterRefs();
/* 33:   */     }
/* 34:59 */     return lValue.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public StackSSALabel rewriteExpression(StackSSALabel lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 38:   */   {
/* 39:64 */     return lValue;
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SyntheticOuterRefRewriter
 * JD-Core Version:    0.7.0.1
 */