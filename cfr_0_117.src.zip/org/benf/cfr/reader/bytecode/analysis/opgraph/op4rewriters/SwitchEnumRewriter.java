/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*   2:    */ 
/*   3:    */ import java.util.LinkedList;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Map;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.AbstractMatchResultIterator;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.CollectMatch;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.KleeneStar;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchSequence;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.Matcher;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.ResetAfterTest;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.MiscStatementTools;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArrayIndex;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArrayLength;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.NewPrimitiveArray;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral.LiteralType;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.ArrayVariable;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StaticVariable;
/*  26:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
/*  27:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.ExpressionWildcard;
/*  28:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.LValueWildcard;
/*  29:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.StaticVariableWildcard;
/*  30:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  31:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.Block;
/*  32:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredAssignment;
/*  33:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredCase;
/*  34:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredCatch;
/*  35:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredComment;
/*  36:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredSwitch;
/*  37:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredTry;
/*  38:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.BeginBlock;
/*  39:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.EndBlock;
/*  40:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaArrayTypeInstance;
/*  41:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  42:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  43:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  44:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  45:    */ import org.benf.cfr.reader.entities.ClassFileField;
/*  46:    */ import org.benf.cfr.reader.entities.Field;
/*  47:    */ import org.benf.cfr.reader.entities.Method;
/*  48:    */ import org.benf.cfr.reader.state.DCCommonState;
/*  49:    */ import org.benf.cfr.reader.util.CannotLoadClassException;
/*  50:    */ import org.benf.cfr.reader.util.ClassFileVersion;
/*  51:    */ import org.benf.cfr.reader.util.Functional;
/*  52:    */ import org.benf.cfr.reader.util.ListFactory;
/*  53:    */ import org.benf.cfr.reader.util.MapFactory;
/*  54:    */ import org.benf.cfr.reader.util.Predicate;
/*  55:    */ import org.benf.cfr.reader.util.getopt.Options;
/*  56:    */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*  57:    */ 
/*  58:    */ public class SwitchEnumRewriter
/*  59:    */   implements Op04Rewriter
/*  60:    */ {
/*  61:    */   private final DCCommonState dcCommonState;
/*  62:    */   private final ClassFileVersion classFileVersion;
/*  63: 36 */   private static final JavaTypeInstance expectedLUTType = new JavaArrayTypeInstance(1, RawJavaType.INT);
/*  64:    */   
/*  65:    */   public SwitchEnumRewriter(DCCommonState dcCommonState, ClassFileVersion classFileVersion)
/*  66:    */   {
/*  67: 39 */     this.dcCommonState = dcCommonState;
/*  68: 40 */     this.classFileVersion = classFileVersion;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void rewrite(Op04StructuredStatement root)
/*  72:    */   {
/*  73: 45 */     Options options = this.dcCommonState.getOptions();
/*  74: 46 */     if (!((Boolean)options.getOption(OptionsImpl.ENUM_SWITCH, this.classFileVersion)).booleanValue()) {
/*  75: 46 */       return;
/*  76:    */     }
/*  77: 48 */     List<StructuredStatement> structuredStatements = MiscStatementTools.linearise(root);
/*  78: 49 */     if (structuredStatements == null) {
/*  79: 49 */       return;
/*  80:    */     }
/*  81: 51 */     List<StructuredStatement> switchStatements = Functional.filter(structuredStatements, new Predicate()
/*  82:    */     {
/*  83:    */       public boolean test(StructuredStatement in)
/*  84:    */       {
/*  85: 54 */         return in.getClass() == StructuredSwitch.class;
/*  86:    */       }
/*  87: 56 */     });
/*  88: 57 */     MatchIterator<StructuredStatement> mi = new MatchIterator(switchStatements);
/*  89:    */     
/*  90: 59 */     WildcardMatch wcm = new WildcardMatch();
/*  91:    */     
/*  92: 61 */     Matcher<StructuredStatement> m = new ResetAfterTest(wcm, new CollectMatch("switch", new StructuredSwitch(new ArrayIndex(new LValueExpression(wcm.getLValueWildCard("lut")), wcm.getMemberFunction("fncall", "ordinal", wcm.getExpressionWildCard("object"))), null, wcm.getBlockIdentifier("block"))));
/*  93:    */     
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100: 69 */     SwitchEnumMatchResultCollector matchResultCollector = new SwitchEnumMatchResultCollector(wcm, null);
/* 101: 70 */     while (mi.hasNext())
/* 102:    */     {
/* 103: 71 */       mi.advance();
/* 104: 72 */       matchResultCollector.clear();
/* 105: 73 */       if (m.match(mi, matchResultCollector))
/* 106:    */       {
/* 107: 74 */         tryRewrite(matchResultCollector);
/* 108: 75 */         mi.rewind1();
/* 109:    */       }
/* 110:    */     }
/* 111:    */   }
/* 112:    */   
/* 113:    */   private void tryRewrite(SwitchEnumMatchResultCollector mrc)
/* 114:    */   {
/* 115:103 */     StructuredSwitch structuredSwitch = mrc.getStructuredSwitch();
/* 116:104 */     LValue lookupTable = mrc.getLookupTable();
/* 117:105 */     Expression enumObject = mrc.getEnumObject();
/* 118:107 */     if (!(lookupTable instanceof StaticVariable)) {
/* 119:108 */       return;
/* 120:    */     }
/* 121:111 */     StaticVariable staticLookupTable = (StaticVariable)lookupTable;
/* 122:112 */     JavaTypeInstance classInfo = staticLookupTable.getOwningClassType();
/* 123:113 */     String varName = staticLookupTable.getFieldName();
/* 124:    */     ClassFile enumLutClass;
/* 125:    */     try
/* 126:    */     {
/* 127:124 */       enumLutClass = this.dcCommonState.getClassFile(classInfo);
/* 128:    */     }
/* 129:    */     catch (CannotLoadClassException e)
/* 130:    */     {
/* 131:    */       return;
/* 132:    */     }
/* 133:    */     Field lut;
/* 134:    */     try
/* 135:    */     {
/* 136:131 */       lut = enumLutClass.getFieldByName(varName, staticLookupTable.getInferredJavaType().getJavaTypeInstance()).getField();
/* 137:    */     }
/* 138:    */     catch (NoSuchFieldException e)
/* 139:    */     {
/* 140:133 */       return;
/* 141:    */     }
/* 142:135 */     JavaTypeInstance fieldType = lut.getJavaTypeInstance();
/* 143:136 */     if (!fieldType.equals(expectedLUTType)) {
/* 144:    */       return;
/* 145:    */     }
/* 146:    */     Method lutStaticInit;
/* 147:    */     try
/* 148:    */     {
/* 149:140 */       lutStaticInit = (Method)enumLutClass.getMethodByName("<clinit>").get(0);
/* 150:    */     }
/* 151:    */     catch (NoSuchMethodException e)
/* 152:    */     {
/* 153:142 */       return;
/* 154:    */     }
/* 155:144 */     Op04StructuredStatement lutStaticInitCode = lutStaticInit.getAnalysis();
/* 156:    */     
/* 157:146 */     List<StructuredStatement> structuredStatements = MiscStatementTools.linearise(lutStaticInitCode);
/* 158:147 */     if (structuredStatements == null) {
/* 159:147 */       return;
/* 160:    */     }
/* 161:150 */     structuredStatements = Functional.filter(structuredStatements, new Predicate()
/* 162:    */     {
/* 163:    */       public boolean test(StructuredStatement in)
/* 164:    */       {
/* 165:153 */         return !(in instanceof StructuredComment);
/* 166:    */       }
/* 167:157 */     });
/* 168:158 */     MatchIterator<StructuredStatement> mi = new MatchIterator(structuredStatements);
/* 169:    */     
/* 170:160 */     WildcardMatch wcm1 = new WildcardMatch();
/* 171:161 */     WildcardMatch wcm2 = new WildcardMatch();
/* 172:    */     
/* 173:163 */     Matcher<StructuredStatement> m = new ResetAfterTest(wcm1, new MatchSequence(new Matcher[] { new StructuredAssignment(lookupTable, new NewPrimitiveArray(new ArrayLength(wcm1.getStaticFunction("func", enumObject.getInferredJavaType().getJavaTypeInstance(), null, "values")), RawJavaType.INT)), new KleeneStar(new ResetAfterTest(wcm2, new MatchSequence(new Matcher[] { new StructuredTry(null, null, null), new BeginBlock(null), new StructuredAssignment(new ArrayVariable(new ArrayIndex(new LValueExpression(lookupTable), wcm2.getMemberFunction("ordinal", "ordinal", new LValueExpression(wcm2.getStaticVariable("enumval", enumObject.getInferredJavaType().getJavaTypeInstance(), enumObject.getInferredJavaType()))))), wcm2.getExpressionWildCard("literal")), new EndBlock(null), new StructuredCatch(null, null, null, null), new BeginBlock(null), new EndBlock(null) }))) }));
/* 174:    */     
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:    */ 
/* 181:    */ 
/* 182:    */ 
/* 183:    */ 
/* 184:    */ 
/* 185:    */ 
/* 186:    */ 
/* 187:    */ 
/* 188:    */ 
/* 189:    */ 
/* 190:    */ 
/* 191:    */ 
/* 192:    */ 
/* 193:    */ 
/* 194:    */ 
/* 195:    */ 
/* 196:    */ 
/* 197:    */ 
/* 198:    */ 
/* 199:    */ 
/* 200:    */ 
/* 201:    */ 
/* 202:    */ 
/* 203:    */ 
/* 204:194 */     SwitchForeignEnumMatchResultCollector matchResultCollector = new SwitchForeignEnumMatchResultCollector(wcm1, wcm2, null);
/* 205:195 */     boolean matched = false;
/* 206:196 */     while (mi.hasNext())
/* 207:    */     {
/* 208:197 */       mi.advance();
/* 209:198 */       matchResultCollector.clear();
/* 210:199 */       if (m.match(mi, matchResultCollector)) {
/* 211:202 */         matched = true;
/* 212:    */       }
/* 213:    */     }
/* 214:207 */     if (!matched) {
/* 215:209 */       return;
/* 216:    */     }
/* 217:212 */     Map<Integer, StaticVariable> reverseLut = matchResultCollector.getLUT();
/* 218:    */     
/* 219:    */ 
/* 220:    */ 
/* 221:    */ 
/* 222:    */ 
/* 223:    */ 
/* 224:219 */     Op04StructuredStatement switchBlock = structuredSwitch.getBody();
/* 225:220 */     StructuredStatement switchBlockStatement = switchBlock.getStatement();
/* 226:221 */     if (!(switchBlockStatement instanceof Block)) {
/* 227:222 */       throw new IllegalStateException("Inside switch should be a block");
/* 228:    */     }
/* 229:225 */     Block block = (Block)switchBlockStatement;
/* 230:226 */     List<Op04StructuredStatement> caseStatements = block.getBlockStatements();
/* 231:    */     
/* 232:    */ 
/* 233:    */ 
/* 234:    */ 
/* 235:231 */     LinkedList<Op04StructuredStatement> newBlockContent = ListFactory.newLinkedList();
/* 236:232 */     InferredJavaType inferredJavaType = enumObject.getInferredJavaType();
/* 237:233 */     for (Op04StructuredStatement caseOuter : caseStatements)
/* 238:    */     {
/* 239:234 */       StructuredStatement caseInner = caseOuter.getStatement();
/* 240:235 */       if (!(caseInner instanceof StructuredCase)) {
/* 241:236 */         return;
/* 242:    */       }
/* 243:238 */       StructuredCase caseStmt = (StructuredCase)caseInner;
/* 244:239 */       List<Expression> values = caseStmt.getValues();
/* 245:240 */       List<Expression> newValues = ListFactory.newList();
/* 246:241 */       for (Expression value : values)
/* 247:    */       {
/* 248:242 */         Integer iVal = getIntegerFromLiteralExpression(value);
/* 249:243 */         if (iVal == null) {
/* 250:244 */           return;
/* 251:    */         }
/* 252:246 */         StaticVariable enumVal = (StaticVariable)reverseLut.get(iVal);
/* 253:247 */         if (enumVal == null) {
/* 254:248 */           return;
/* 255:    */         }
/* 256:250 */         newValues.add(new LValueExpression(enumVal));
/* 257:    */       }
/* 258:252 */       StructuredCase replacement = new StructuredCase(newValues, inferredJavaType, caseStmt.getBody(), caseStmt.getBlockIdentifier(), true);
/* 259:253 */       newBlockContent.add(new Op04StructuredStatement(replacement));
/* 260:    */     }
/* 261:255 */     Block replacementBlock = new Block(newBlockContent, block.isIndenting());
/* 262:    */     
/* 263:257 */     StructuredSwitch newSwitch = new StructuredSwitch(enumObject, new Op04StructuredStatement(replacementBlock), structuredSwitch.getBlockIdentifier());
/* 264:    */     
/* 265:    */ 
/* 266:    */ 
/* 267:    */ 
/* 268:262 */     structuredSwitch.getContainer().replaceContainedStatement(newSwitch);
/* 269:263 */     enumLutClass.markHiddenInnerClass();
/* 270:    */   }
/* 271:    */   
/* 272:    */   private Integer getIntegerFromLiteralExpression(Expression exp)
/* 273:    */   {
/* 274:267 */     if (!(exp instanceof Literal)) {
/* 275:268 */       return null;
/* 276:    */     }
/* 277:270 */     Literal literal = (Literal)exp;
/* 278:271 */     TypedLiteral typedLiteral = literal.getValue();
/* 279:272 */     if (typedLiteral.getType() != TypedLiteral.LiteralType.Integer) {
/* 280:273 */       return null;
/* 281:    */     }
/* 282:275 */     return (Integer)typedLiteral.getValue();
/* 283:    */   }
/* 284:    */   
/* 285:    */   private static class SwitchEnumMatchResultCollector
/* 286:    */     extends AbstractMatchResultIterator
/* 287:    */   {
/* 288:    */     private final WildcardMatch wcm;
/* 289:    */     private LValue lookupTable;
/* 290:    */     private Expression enumObject;
/* 291:    */     private StructuredSwitch structuredSwitch;
/* 292:    */     
/* 293:    */     private SwitchEnumMatchResultCollector(WildcardMatch wcm)
/* 294:    */     {
/* 295:287 */       this.wcm = wcm;
/* 296:    */     }
/* 297:    */     
/* 298:    */     public void clear()
/* 299:    */     {
/* 300:292 */       this.lookupTable = null;
/* 301:293 */       this.enumObject = null;
/* 302:    */     }
/* 303:    */     
/* 304:    */     public void collectStatement(String name, StructuredStatement statement)
/* 305:    */     {
/* 306:298 */       if (name.equals("switch")) {
/* 307:299 */         this.structuredSwitch = ((StructuredSwitch)statement);
/* 308:    */       }
/* 309:    */     }
/* 310:    */     
/* 311:    */     public void collectMatches(String name, WildcardMatch wcm)
/* 312:    */     {
/* 313:305 */       this.lookupTable = wcm.getLValueWildCard("lut").getMatch();
/* 314:306 */       this.enumObject = wcm.getExpressionWildCard("object").getMatch();
/* 315:    */     }
/* 316:    */     
/* 317:    */     public LValue getLookupTable()
/* 318:    */     {
/* 319:310 */       return this.lookupTable;
/* 320:    */     }
/* 321:    */     
/* 322:    */     public Expression getEnumObject()
/* 323:    */     {
/* 324:314 */       return this.enumObject;
/* 325:    */     }
/* 326:    */     
/* 327:    */     public StructuredSwitch getStructuredSwitch()
/* 328:    */     {
/* 329:318 */       return this.structuredSwitch;
/* 330:    */     }
/* 331:    */   }
/* 332:    */   
/* 333:    */   private class SwitchForeignEnumMatchResultCollector
/* 334:    */     extends AbstractMatchResultIterator
/* 335:    */   {
/* 336:    */     private final WildcardMatch wcmOuter;
/* 337:    */     private final WildcardMatch wcmCase;
/* 338:    */     private boolean bad;
/* 339:326 */     private final Map<Integer, StaticVariable> lutValues = MapFactory.newMap();
/* 340:    */     
/* 341:    */     private SwitchForeignEnumMatchResultCollector(WildcardMatch wcmOuter, WildcardMatch wcmCase)
/* 342:    */     {
/* 343:329 */       this.wcmOuter = wcmOuter;
/* 344:330 */       this.wcmCase = wcmCase;
/* 345:    */     }
/* 346:    */     
/* 347:    */     public Map<Integer, StaticVariable> getLUT()
/* 348:    */     {
/* 349:334 */       return this.lutValues;
/* 350:    */     }
/* 351:    */     
/* 352:    */     public void clear() {}
/* 353:    */     
/* 354:    */     public void collectStatement(String name, StructuredStatement statement) {}
/* 355:    */     
/* 356:    */     public void collectMatches(String name, WildcardMatch wcm)
/* 357:    */     {
/* 358:349 */       if (wcm != this.wcmOuter) {
/* 359:351 */         if (wcm == this.wcmCase)
/* 360:    */         {
/* 361:352 */           StaticVariable staticVariable = wcm.getStaticVariable("enumval").getMatch();
/* 362:    */           
/* 363:354 */           Expression exp = wcm.getExpressionWildCard("literal").getMatch();
/* 364:355 */           Integer literalInt = SwitchEnumRewriter.this.getIntegerFromLiteralExpression(exp);
/* 365:356 */           if (literalInt == null)
/* 366:    */           {
/* 367:357 */             this.bad = true;
/* 368:358 */             return;
/* 369:    */           }
/* 370:360 */           this.lutValues.put(literalInt, staticVariable);
/* 371:    */         }
/* 372:    */       }
/* 373:    */     }
/* 374:    */   }
/* 375:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchEnumRewriter
 * JD-Core Version:    0.7.0.1
 */