/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Set;
/*   5:    */ import java.util.concurrent.atomic.AtomicBoolean;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.InstrIndex;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractAssignmentExpression;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithOp;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArrayIndex;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArrayLength;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.BoolOp;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.BooleanExpression;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.BooleanOperation;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CompOp;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ComparisonOperation;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.AssignmentSimple;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ForIterStatement;
/*  26:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ForStatement;
/*  27:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.IfStatement;
/*  28:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.WhileStatement;
/*  29:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  30:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.JumpType;
/*  31:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollectorSimple;
/*  32:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  33:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
/*  34:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.ExpressionWildcard;
/*  35:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.LValueWildcard;
/*  36:    */ import org.benf.cfr.reader.bytecode.analysis.types.BindingSuperContainer;
/*  37:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  38:    */ import org.benf.cfr.reader.bytecode.analysis.types.TypeConstants;
/*  39:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  40:    */ import org.benf.cfr.reader.util.Functional;
/*  41:    */ import org.benf.cfr.reader.util.Predicate;
/*  42:    */ import org.benf.cfr.reader.util.SetFactory;
/*  43:    */ import org.benf.cfr.reader.util.functors.BinaryProcedure;
/*  44:    */ import org.benf.cfr.reader.util.graph.GraphVisitor;
/*  45:    */ import org.benf.cfr.reader.util.graph.GraphVisitorDFS;
/*  46:    */ 
/*  47:    */ public class IterLoopRewriter
/*  48:    */ {
/*  49:    */   private static Pair<ConditionalExpression, ConditionalExpression> getSplitAnd(ConditionalExpression cnd)
/*  50:    */   {
/*  51: 30 */     if (!(cnd instanceof BooleanOperation)) {
/*  52: 30 */       return Pair.make(cnd, null);
/*  53:    */     }
/*  54: 31 */     BooleanOperation op = (BooleanOperation)cnd;
/*  55: 32 */     if (op.getOp() != BoolOp.AND) {
/*  56: 32 */       return Pair.make(cnd, null);
/*  57:    */     }
/*  58: 33 */     return Pair.make(op.getLhs(), op.getRhs());
/*  59:    */   }
/*  60:    */   
/*  61:    */   private static boolean rewriteArrayForLoop(Op03SimpleStatement loop, List<Op03SimpleStatement> statements)
/*  62:    */   {
/*  63: 58 */     Op03SimpleStatement preceeding = Misc.findSingleBackSource(loop);
/*  64: 59 */     if (preceeding == null) {
/*  65: 59 */       return false;
/*  66:    */     }
/*  67: 61 */     ForStatement forStatement = (ForStatement)loop.getStatement();
/*  68:    */     
/*  69: 63 */     WildcardMatch wildcardMatch = new WildcardMatch();
/*  70: 65 */     if (!wildcardMatch.match(new AssignmentSimple(wildcardMatch.getLValueWildCard("iter"), new Literal(TypedLiteral.getInt(0))), forStatement.getInitial())) {
/*  71: 67 */       return false;
/*  72:    */     }
/*  73: 69 */     LValue originalLoopVariable = wildcardMatch.getLValueWildCard("iter").getMatch();
/*  74:    */     
/*  75:    */ 
/*  76: 72 */     List<AbstractAssignmentExpression> assignments = forStatement.getAssignments();
/*  77: 73 */     if (assignments.size() != 1) {
/*  78: 73 */       return false;
/*  79:    */     }
/*  80: 74 */     AbstractAssignmentExpression assignment = (AbstractAssignmentExpression)assignments.get(0);
/*  81: 75 */     boolean incrMatch = assignment.isSelfMutatingOp1(originalLoopVariable, ArithOp.PLUS);
/*  82: 76 */     if (!incrMatch) {
/*  83: 76 */       return false;
/*  84:    */     }
/*  85: 82 */     ConditionalExpression condition = forStatement.getCondition();
/*  86: 83 */     Pair<ConditionalExpression, ConditionalExpression> condpr = getSplitAnd(condition);
/*  87: 85 */     if (!wildcardMatch.match(new ComparisonOperation(new LValueExpression(originalLoopVariable), new LValueExpression(wildcardMatch.getLValueWildCard("bound")), CompOp.LT), condpr.getFirst())) {
/*  88: 90 */       return false;
/*  89:    */     }
/*  90: 93 */     LValue originalLoopBound = wildcardMatch.getLValueWildCard("bound").getMatch();
/*  91: 97 */     if (!wildcardMatch.match(new AssignmentSimple(originalLoopBound, new ArrayLength(new LValueExpression(wildcardMatch.getLValueWildCard("array")))), preceeding.getStatement())) {
/*  92: 99 */       return false;
/*  93:    */     }
/*  94:101 */     LValue originalArray = wildcardMatch.getLValueWildCard("array").getMatch();
/*  95:    */     
/*  96:103 */     Expression arrayStatement = new LValueExpression(originalArray);
/*  97:104 */     Op03SimpleStatement prepreceeding = null;
/*  98:108 */     if ((preceeding.getSources().size() == 1) && 
/*  99:109 */       (wildcardMatch.match(new AssignmentSimple(originalArray, wildcardMatch.getExpressionWildCard("value")), ((Op03SimpleStatement)preceeding.getSources().get(0)).getStatement())))
/* 100:    */     {
/* 101:112 */       prepreceeding = (Op03SimpleStatement)preceeding.getSources().get(0);
/* 102:113 */       arrayStatement = wildcardMatch.getExpressionWildCard("value").getMatch();
/* 103:    */     }
/* 104:120 */     Op03SimpleStatement realLoopStart = (Op03SimpleStatement)loop.getTargets().get(0);
/* 105:121 */     Op03SimpleStatement loopStart = realLoopStart;
/* 106:122 */     if (condpr.getSecond() != null)
/* 107:    */     {
/* 108:128 */       IfStatement fakeLoopStm = new IfStatement(((ConditionalExpression)condpr.getSecond()).getNegated());
/* 109:129 */       fakeLoopStm.setJumpType(JumpType.BREAK);
/* 110:130 */       loopStart = new Op03SimpleStatement(loopStart.getBlockIdentifiers(), fakeLoopStm, loopStart.getIndex().justBefore());
/* 111:    */     }
/* 112:135 */     WildcardMatch.LValueWildcard sugariterWC = wildcardMatch.getLValueWildCard("sugariter");
/* 113:136 */     Expression arrIndex = new ArrayIndex(new LValueExpression(originalArray), new LValueExpression(originalLoopVariable));
/* 114:137 */     boolean hiddenIter = false;
/* 115:138 */     if (!wildcardMatch.match(new AssignmentSimple(sugariterWC, arrIndex), loopStart.getStatement()))
/* 116:    */     {
/* 117:143 */       Set<Expression> poison = SetFactory.newSet(new Expression[] { new LValueExpression(originalLoopVariable) });
/* 118:144 */       if (!Misc.findHiddenIter(loopStart.getStatement(), sugariterWC, arrIndex, poison)) {
/* 119:145 */         return false;
/* 120:    */       }
/* 121:147 */       hiddenIter = true;
/* 122:    */     }
/* 123:150 */     LValue sugarIter = sugariterWC.getMatch();
/* 124:    */     
/* 125:    */ 
/* 126:    */ 
/* 127:154 */     final BlockIdentifier forBlock = forStatement.getBlockIdentifier();
/* 128:155 */     List<Op03SimpleStatement> statementsInBlock = Functional.filter(statements, new Predicate()
/* 129:    */     {
/* 130:    */       public boolean test(Op03SimpleStatement in)
/* 131:    */       {
/* 132:158 */         return in.getBlockIdentifiers().contains(this.val$forBlock);
/* 133:    */       }
/* 134:165 */     });
/* 135:166 */     LValueUsageCollectorSimple usageCollector = new LValueUsageCollectorSimple();
/* 136:167 */     final Set<LValue> cantUpdate = SetFactory.newSet(new LValue[] { originalArray, originalLoopBound, originalLoopVariable });
/* 137:169 */     for (Op03SimpleStatement inBlock : statementsInBlock) {
/* 138:170 */       if (inBlock != loopStart)
/* 139:    */       {
/* 140:171 */         Statement inStatement = inBlock.getStatement();
/* 141:172 */         inStatement.collectLValueUsage(usageCollector);
/* 142:173 */         for (LValue cantUse : cantUpdate) {
/* 143:174 */           if (usageCollector.isUsed(cantUse)) {
/* 144:175 */             return false;
/* 145:    */           }
/* 146:    */         }
/* 147:178 */         LValue updated = inStatement.getCreatedLValue();
/* 148:179 */         if (updated != null) {
/* 149:180 */           if (cantUpdate.contains(updated)) {
/* 150:181 */             return false;
/* 151:    */           }
/* 152:    */         }
/* 153:    */       }
/* 154:    */     }
/* 155:192 */     final AtomicBoolean res = new AtomicBoolean();
/* 156:193 */     GraphVisitor<Op03SimpleStatement> graphVisitor = new GraphVisitorDFS(loop, new BinaryProcedure()
/* 157:    */     {
/* 158:    */       public void call(Op03SimpleStatement arg1, GraphVisitor<Op03SimpleStatement> arg2)
/* 159:    */       {
/* 160:    */         LValueUsageCollectorSimple usageCollector;
/* 161:197 */         if ((this.val$loop != arg1) && (!arg1.getBlockIdentifiers().contains(forBlock)))
/* 162:    */         {
/* 163:199 */           Statement inStatement = arg1.getStatement();
/* 164:201 */           if ((inStatement instanceof AssignmentSimple))
/* 165:    */           {
/* 166:202 */             AssignmentSimple assignmentSimple = (AssignmentSimple)inStatement;
/* 167:203 */             if (cantUpdate.contains(assignmentSimple.getCreatedLValue())) {
/* 168:203 */               return;
/* 169:    */             }
/* 170:    */           }
/* 171:205 */           usageCollector = new LValueUsageCollectorSimple();
/* 172:206 */           inStatement.collectLValueUsage(usageCollector);
/* 173:207 */           for (LValue cantUse : cantUpdate) {
/* 174:208 */             if (usageCollector.isUsed(cantUse))
/* 175:    */             {
/* 176:209 */               res.set(true);
/* 177:210 */               return;
/* 178:    */             }
/* 179:    */           }
/* 180:    */         }
/* 181:214 */         for (Op03SimpleStatement target : arg1.getTargets()) {
/* 182:215 */           arg2.enqueue(target);
/* 183:    */         }
/* 184:    */       }
/* 185:218 */     });
/* 186:219 */     graphVisitor.process();
/* 187:220 */     if (res.get()) {
/* 188:221 */       return false;
/* 189:    */     }
/* 190:225 */     loop.replaceStatement(new ForIterStatement(forBlock, sugarIter, arrayStatement));
/* 191:226 */     if (loopStart != realLoopStart)
/* 192:    */     {
/* 193:227 */       if (hiddenIter)
/* 194:    */       {
/* 195:232 */         loop.replaceTarget(realLoopStart, loopStart);
/* 196:233 */         realLoopStart.replaceSource(loop, loopStart);
/* 197:234 */         loopStart.addSource(loop);
/* 198:235 */         loopStart.addTarget(realLoopStart);
/* 199:236 */         Op03SimpleStatement endStm = (Op03SimpleStatement)loop.getTargets().get(1);
/* 200:237 */         loopStart.addTarget(endStm);
/* 201:238 */         endStm.addSource(loopStart);
/* 202:239 */         Misc.replaceHiddenIter(loopStart.getStatement(), sugariterWC.getMatch(), arrIndex);
/* 203:    */         
/* 204:241 */         statements.add(statements.indexOf(realLoopStart), loopStart);
/* 205:    */       }
/* 206:    */     }
/* 207:246 */     else if (hiddenIter) {
/* 208:250 */       Misc.replaceHiddenIter(loopStart.getStatement(), sugariterWC.getMatch(), arrIndex);
/* 209:    */     } else {
/* 210:252 */       loopStart.nopOut();
/* 211:    */     }
/* 212:255 */     preceeding.nopOut();
/* 213:256 */     if (prepreceeding != null) {
/* 214:257 */       prepreceeding.nopOut();
/* 215:    */     }
/* 216:260 */     return true;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public static void rewriteArrayForLoops(List<Op03SimpleStatement> statements)
/* 220:    */   {
/* 221:265 */     for (Op03SimpleStatement loop : Functional.filter(statements, new TypeFilter(ForStatement.class))) {
/* 222:266 */       rewriteArrayForLoop(loop, statements);
/* 223:    */     }
/* 224:    */   }
/* 225:    */   
/* 226:    */   private static void rewriteIteratorWhileLoop(Op03SimpleStatement loop, List<Op03SimpleStatement> statements)
/* 227:    */   {
/* 228:280 */     WhileStatement whileStatement = (WhileStatement)loop.getStatement();
/* 229:    */     
/* 230:    */ 
/* 231:    */ 
/* 232:    */ 
/* 233:285 */     Op03SimpleStatement preceeding = Misc.findSingleBackSource(loop);
/* 234:286 */     if (preceeding == null) {
/* 235:286 */       return;
/* 236:    */     }
/* 237:288 */     WildcardMatch wildcardMatch = new WildcardMatch();
/* 238:    */     
/* 239:290 */     ConditionalExpression condition = whileStatement.getCondition();
/* 240:291 */     Pair<ConditionalExpression, ConditionalExpression> condpr = getSplitAnd(condition);
/* 241:293 */     if (!wildcardMatch.match(new BooleanExpression(wildcardMatch.getMemberFunction("hasnextfn", "hasNext", new LValueExpression(wildcardMatch.getLValueWildCard("iterable")))), condpr.getFirst())) {
/* 242:297 */       return;
/* 243:    */     }
/* 244:299 */     final LValue iterable = wildcardMatch.getLValueWildCard("iterable").getMatch();
/* 245:    */     
/* 246:301 */     Op03SimpleStatement realLoopStart = (Op03SimpleStatement)loop.getTargets().get(0);
/* 247:302 */     Op03SimpleStatement loopStart = realLoopStart;
/* 248:303 */     if (condpr.getSecond() != null)
/* 249:    */     {
/* 250:309 */       IfStatement fakeLoopStm = new IfStatement(((ConditionalExpression)condpr.getSecond()).getNegated());
/* 251:310 */       fakeLoopStm.setJumpType(JumpType.BREAK);
/* 252:311 */       loopStart = new Op03SimpleStatement(loopStart.getBlockIdentifiers(), fakeLoopStm, loopStart.getIndex().justBefore());
/* 253:    */     }
/* 254:315 */     boolean isCastExpression = false;
/* 255:316 */     boolean hiddenIter = false;
/* 256:317 */     WildcardMatch.LValueWildcard sugariterWC = wildcardMatch.getLValueWildCard("sugariter");
/* 257:318 */     Expression nextCall = wildcardMatch.getMemberFunction("nextfn", "next", new LValueExpression(wildcardMatch.getLValueWildCard("iterable")));
/* 258:319 */     if (!wildcardMatch.match(new AssignmentSimple(sugariterWC, nextCall), loopStart.getStatement())) {
/* 259:322 */       if (wildcardMatch.match(new AssignmentSimple(sugariterWC, wildcardMatch.getCastExpressionWildcard("cast", nextCall)), loopStart.getStatement()))
/* 260:    */       {
/* 261:327 */         isCastExpression = true;
/* 262:    */       }
/* 263:    */       else
/* 264:    */       {
/* 265:330 */         Set<Expression> poison = SetFactory.newSet(new Expression[] { new LValueExpression(iterable) });
/* 266:331 */         if (!Misc.findHiddenIter(loopStart.getStatement(), sugariterWC, nextCall, poison)) {
/* 267:332 */           return;
/* 268:    */         }
/* 269:334 */         hiddenIter = true;
/* 270:    */       }
/* 271:    */     }
/* 272:337 */     LValue sugarIter = wildcardMatch.getLValueWildCard("sugariter").getMatch();
/* 273:339 */     if (!wildcardMatch.match(new AssignmentSimple(wildcardMatch.getLValueWildCard("iterable"), wildcardMatch.getMemberFunction("iterator", "iterator", wildcardMatch.getExpressionWildCard("iteratorsource"))), preceeding.getStatement())) {
/* 274:342 */       return;
/* 275:    */     }
/* 276:344 */     Expression iterSource = wildcardMatch.getExpressionWildCard("iteratorsource").getMatch();
/* 277:    */     
/* 278:    */ 
/* 279:    */ 
/* 280:348 */     final BlockIdentifier blockIdentifier = whileStatement.getBlockIdentifier();
/* 281:349 */     List<Op03SimpleStatement> statementsInBlock = Functional.filter(statements, new Predicate()
/* 282:    */     {
/* 283:    */       public boolean test(Op03SimpleStatement in)
/* 284:    */       {
/* 285:352 */         return in.getBlockIdentifiers().contains(this.val$blockIdentifier);
/* 286:    */       }
/* 287:359 */     });
/* 288:360 */     LValueUsageCollectorSimple usageCollector = new LValueUsageCollectorSimple();
/* 289:361 */     for (Op03SimpleStatement inBlock : statementsInBlock) {
/* 290:362 */       if (inBlock != loopStart)
/* 291:    */       {
/* 292:363 */         Statement inStatement = inBlock.getStatement();
/* 293:364 */         inStatement.collectLValueUsage(usageCollector);
/* 294:365 */         if (usageCollector.isUsed(iterable)) {
/* 295:366 */           return;
/* 296:    */         }
/* 297:368 */         LValue updated = inStatement.getCreatedLValue();
/* 298:369 */         if (updated != null) {
/* 299:370 */           if ((updated.equals(sugarIter)) || (updated.equals(iterable))) {
/* 300:371 */             return;
/* 301:    */           }
/* 302:    */         }
/* 303:    */       }
/* 304:    */     }
/* 305:382 */     JavaTypeInstance iteratorSourceType = iterSource.getInferredJavaType().getJavaTypeInstance();
/* 306:383 */     BindingSuperContainer supers = iteratorSourceType.getBindingSupers();
/* 307:384 */     if ((supers != null) && (!supers.containsBase(TypeConstants.ITERABLE))) {
/* 308:384 */       return;
/* 309:    */     }
/* 310:393 */     final AtomicBoolean res = new AtomicBoolean();
/* 311:394 */     GraphVisitor<Op03SimpleStatement> graphVisitor = new GraphVisitorDFS(loop, new BinaryProcedure()
/* 312:    */     {
/* 313:    */       public void call(Op03SimpleStatement arg1, GraphVisitor<Op03SimpleStatement> arg2)
/* 314:    */       {
/* 315:398 */         if ((this.val$loop != arg1) && (!arg1.getBlockIdentifiers().contains(blockIdentifier)))
/* 316:    */         {
/* 317:400 */           Statement inStatement = arg1.getStatement();
/* 318:402 */           if ((inStatement instanceof AssignmentSimple))
/* 319:    */           {
/* 320:403 */             AssignmentSimple assignmentSimple = (AssignmentSimple)inStatement;
/* 321:404 */             if (iterable.equals(assignmentSimple.getCreatedLValue())) {
/* 322:404 */               return;
/* 323:    */             }
/* 324:    */           }
/* 325:406 */           LValueUsageCollectorSimple usageCollector = new LValueUsageCollectorSimple();
/* 326:407 */           inStatement.collectLValueUsage(usageCollector);
/* 327:408 */           if (usageCollector.isUsed(iterable))
/* 328:    */           {
/* 329:409 */             res.set(true);
/* 330:410 */             return;
/* 331:    */           }
/* 332:    */         }
/* 333:413 */         for (Op03SimpleStatement target : arg1.getTargets()) {
/* 334:414 */           arg2.enqueue(target);
/* 335:    */         }
/* 336:    */       }
/* 337:417 */     });
/* 338:418 */     graphVisitor.process();
/* 339:419 */     if (res.get()) {
/* 340:420 */       return;
/* 341:    */     }
/* 342:423 */     loop.replaceStatement(new ForIterStatement(blockIdentifier, sugarIter, iterSource));
/* 343:424 */     if (loopStart != realLoopStart)
/* 344:    */     {
/* 345:425 */       if (hiddenIter)
/* 346:    */       {
/* 347:430 */         loop.replaceTarget(realLoopStart, loopStart);
/* 348:431 */         realLoopStart.replaceSource(loop, loopStart);
/* 349:432 */         loopStart.addSource(loop);
/* 350:433 */         loopStart.addTarget(realLoopStart);
/* 351:434 */         Op03SimpleStatement endStm = (Op03SimpleStatement)loop.getTargets().get(1);
/* 352:435 */         loopStart.addTarget(endStm);
/* 353:436 */         endStm.addSource(loopStart);
/* 354:437 */         Misc.replaceHiddenIter(loopStart.getStatement(), sugariterWC.getMatch(), nextCall);
/* 355:    */         
/* 356:439 */         statements.add(statements.indexOf(realLoopStart), loopStart);
/* 357:    */       }
/* 358:    */     }
/* 359:444 */     else if (hiddenIter) {
/* 360:445 */       Misc.replaceHiddenIter(loopStart.getStatement(), sugariterWC.getMatch(), nextCall);
/* 361:    */     } else {
/* 362:447 */       loopStart.nopOut();
/* 363:    */     }
/* 364:450 */     preceeding.nopOut();
/* 365:    */   }
/* 366:    */   
/* 367:    */   public static void rewriteIteratorWhileLoops(List<Op03SimpleStatement> statements)
/* 368:    */   {
/* 369:454 */     List<Op03SimpleStatement> loops = Functional.filter(statements, new TypeFilter(WhileStatement.class));
/* 370:455 */     for (Op03SimpleStatement loop : loops) {
/* 371:456 */       rewriteIteratorWhileLoop(loop, statements);
/* 372:    */     }
/* 373:    */   }
/* 374:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.IterLoopRewriter
 * JD-Core Version:    0.7.0.1
 */