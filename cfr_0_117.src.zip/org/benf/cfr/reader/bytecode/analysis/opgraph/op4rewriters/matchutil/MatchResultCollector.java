package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil;

import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;

public abstract interface MatchResultCollector
{
  public abstract void clear();
  
  public abstract void collectStatement(String paramString, StructuredStatement paramStructuredStatement);
  
  public abstract void collectStatementRange(String paramString, MatchIterator<StructuredStatement> paramMatchIterator1, MatchIterator<StructuredStatement> paramMatchIterator2);
  
  public abstract void collectMatches(String paramString, WildcardMatch paramWildcardMatch);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector
 * JD-Core Version:    0.7.0.1
 */