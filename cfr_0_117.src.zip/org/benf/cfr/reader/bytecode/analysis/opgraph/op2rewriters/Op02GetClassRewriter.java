/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  7:   */ import org.benf.cfr.reader.bytecode.opcode.JVMInstr;
/*  8:   */ import org.benf.cfr.reader.entities.ClassFile;
/*  9:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/* 10:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodRef;
/* 11:   */ 
/* 12:   */ public class Op02GetClassRewriter
/* 13:   */ {
/* 14:19 */   private static Op02GetClassRewriter INSTANCE = new Op02GetClassRewriter();
/* 15:   */   
/* 16:   */   private Op02WithProcessedDataAndRefs getSinglePrev(Op02WithProcessedDataAndRefs item)
/* 17:   */   {
/* 18:22 */     if (item.getSources().size() != 1) {
/* 19:22 */       return null;
/* 20:   */     }
/* 21:23 */     Op02WithProcessedDataAndRefs prev = (Op02WithProcessedDataAndRefs)item.getSources().get(0);
/* 22:24 */     if (prev.getTargets().size() != 1) {
/* 23:24 */       return null;
/* 24:   */     }
/* 25:25 */     return prev;
/* 26:   */   }
/* 27:   */   
/* 28:   */   private void tryRemove(ClassFile classFile, Op02WithProcessedDataAndRefs item, GetClassTest classTest)
/* 29:   */   {
/* 30:33 */     Op02WithProcessedDataAndRefs pop = getSinglePrev(item);
/* 31:34 */     if (pop == null) {
/* 32:34 */       return;
/* 33:   */     }
/* 34:36 */     if (pop.getInstr() != JVMInstr.POP) {
/* 35:36 */       return;
/* 36:   */     }
/* 37:37 */     Op02WithProcessedDataAndRefs getClass = getSinglePrev(pop);
/* 38:38 */     if (getClass == null) {
/* 39:38 */       return;
/* 40:   */     }
/* 41:39 */     if (!isGetClass(getClass)) {
/* 42:39 */       return;
/* 43:   */     }
/* 44:41 */     Op02WithProcessedDataAndRefs dup = getSinglePrev(getClass);
/* 45:42 */     if (dup == null) {
/* 46:42 */       return;
/* 47:   */     }
/* 48:43 */     if (dup.getInstr() != JVMInstr.DUP) {
/* 49:43 */       return;
/* 50:   */     }
/* 51:45 */     if (!classTest.test(classFile, item)) {
/* 52:45 */       return;
/* 53:   */     }
/* 54:47 */     dup.nop();
/* 55:48 */     getClass.nop();
/* 56:49 */     pop.nop();
/* 57:   */   }
/* 58:   */   
/* 59:   */   private boolean isGetClass(Op02WithProcessedDataAndRefs item)
/* 60:   */   {
/* 61:53 */     ConstantPoolEntry[] cpEntries = item.getCpEntries();
/* 62:54 */     if ((cpEntries == null) || (cpEntries.length == 0)) {
/* 63:54 */       return false;
/* 64:   */     }
/* 65:55 */     ConstantPoolEntry entry = cpEntries[0];
/* 66:56 */     if (!(entry instanceof ConstantPoolEntryMethodRef)) {
/* 67:56 */       return false;
/* 68:   */     }
/* 69:57 */     ConstantPoolEntryMethodRef function = (ConstantPoolEntryMethodRef)entry;
/* 70:   */     
/* 71:59 */     MethodPrototype methodPrototype = function.getMethodPrototype();
/* 72:60 */     if (!methodPrototype.getName().equals("getClass")) {
/* 73:60 */       return false;
/* 74:   */     }
/* 75:61 */     if (methodPrototype.getArgs().size() != 0) {
/* 76:61 */       return false;
/* 77:   */     }
/* 78:62 */     if (!methodPrototype.getReturnType().getDeGenerifiedType().getRawName().equals("java.lang.Class")) {
/* 79:63 */       return false;
/* 80:   */     }
/* 81:64 */     return true;
/* 82:   */   }
/* 83:   */   
/* 84:   */   public static void removeInvokeGetClass(ClassFile classFile, List<Op02WithProcessedDataAndRefs> op02list, GetClassTest classTest)
/* 85:   */   {
/* 86:68 */     JVMInstr testInstr = classTest.getInstr();
/* 87:69 */     for (Op02WithProcessedDataAndRefs item : op02list) {
/* 88:70 */       if (item.getInstr() == testInstr) {
/* 89:71 */         INSTANCE.tryRemove(classFile, item, classTest);
/* 90:   */       }
/* 91:   */     }
/* 92:   */   }
/* 93:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters.Op02GetClassRewriter
 * JD-Core Version:    0.7.0.1
 */