package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.checker;

import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
import org.benf.cfr.reader.util.DecompilerComments;

public abstract interface Op04Checker
  extends StructuredStatementTransformer
{
  public abstract void commentInto(DecompilerComments paramDecompilerComments);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.checker.Op04Checker
 * JD-Core Version:    0.7.0.1
 */