/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.checker;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredCatch;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredTry;
/*  7:   */ import org.benf.cfr.reader.util.DecompilerComment;
/*  8:   */ import org.benf.cfr.reader.util.DecompilerComments;
/*  9:   */ 
/* 10:   */ public class LooseCatchChecker
/* 11:   */   implements Op04Checker
/* 12:   */ {
/* 13:11 */   private boolean looseCatch = false;
/* 14:   */   
/* 15:   */   public StructuredStatement transform(StructuredStatement in, StructuredScope scope)
/* 16:   */   {
/* 17:15 */     if (this.looseCatch) {
/* 18:15 */       return in;
/* 19:   */     }
/* 20:16 */     if ((in instanceof StructuredCatch))
/* 21:   */     {
/* 22:18 */       StructuredStatement outer = scope.getInnermost();
/* 23:19 */       if (!(outer instanceof StructuredTry))
/* 24:   */       {
/* 25:20 */         this.looseCatch = true;
/* 26:21 */         return in;
/* 27:   */       }
/* 28:   */     }
/* 29:24 */     in.transformStructuredChildren(this, scope);
/* 30:25 */     return in;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public void commentInto(DecompilerComments comments)
/* 34:   */   {
/* 35:30 */     if (this.looseCatch) {
/* 36:31 */       comments.addComment(DecompilerComment.LOOSE_CATCH_BLOCK);
/* 37:   */     }
/* 38:   */   }
/* 39:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.checker.LooseCatchChecker
 * JD-Core Version:    0.7.0.1
 */