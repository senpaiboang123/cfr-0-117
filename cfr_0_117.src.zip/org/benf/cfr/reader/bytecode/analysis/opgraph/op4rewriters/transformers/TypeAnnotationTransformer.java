/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.SortedMap;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaAnnotatedTypeIterator;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.annotated.JavaAnnotatedTypeInstance;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  21:    */ import org.benf.cfr.reader.entities.annotations.AnnotationTableTypeEntry;
/*  22:    */ import org.benf.cfr.reader.entities.attributes.AttributeRuntimeVisibleTypeAnnotations;
/*  23:    */ import org.benf.cfr.reader.entities.attributes.TypeAnnotationTargetInfo.TypeAnnotationLocalVarTarget;
/*  24:    */ import org.benf.cfr.reader.entities.attributes.TypePath;
/*  25:    */ import org.benf.cfr.reader.entities.attributes.TypePathPart;
/*  26:    */ import org.benf.cfr.reader.util.DecompilerComments;
/*  27:    */ 
/*  28:    */ public class TypeAnnotationTransformer
/*  29:    */   implements StructuredStatementTransformer, ExpressionRewriter
/*  30:    */ {
/*  31:    */   private final AttributeRuntimeVisibleTypeAnnotations typeAnnotations;
/*  32:    */   private final SortedMap<Integer, Integer> instrsByOffset;
/*  33:    */   private final DecompilerComments comments;
/*  34:    */   
/*  35:    */   public TypeAnnotationTransformer(AttributeRuntimeVisibleTypeAnnotations typeAnnotations, SortedMap<Integer, Integer> instrsByOffset, DecompilerComments comments)
/*  36:    */   {
/*  37: 33 */     this.typeAnnotations = typeAnnotations;
/*  38: 34 */     this.instrsByOffset = instrsByOffset;
/*  39: 35 */     this.comments = comments;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void transform(Op04StructuredStatement root)
/*  43:    */   {
/*  44: 39 */     StructuredScope structuredScope = new StructuredScope();
/*  45: 40 */     root.transform(this, structuredScope);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public StructuredStatement transform(StructuredStatement in, StructuredScope scope)
/*  49:    */   {
/*  50: 45 */     in.transformStructuredChildren(this, scope);
/*  51: 46 */     in.rewriteExpressions(this);
/*  52: 47 */     return in;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  56:    */   {
/*  57: 52 */     return expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public ConditionalExpression rewriteExpression(ConditionalExpression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  61:    */   {
/*  62: 57 */     Expression res = expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/*  63: 58 */     return (ConditionalExpression)res;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  67:    */   {
/*  68: 63 */     return lValue;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public StackSSALabel rewriteExpression(StackSSALabel lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  72:    */   {
/*  73: 68 */     return lValue;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public void handleStatement(StatementContainer statementContainer)
/*  77:    */   {
/*  78: 73 */     Object rawStatement = statementContainer.getStatement();
/*  79: 74 */     if (!(rawStatement instanceof StructuredStatement)) {
/*  80: 74 */       return;
/*  81:    */     }
/*  82: 75 */     StructuredStatement stm = (StructuredStatement)rawStatement;
/*  83:    */     
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87: 80 */     List<LValue> createdHere = stm.findCreatedHere();
/*  88: 81 */     if ((createdHere == null) || (createdHere.isEmpty())) {
/*  89: 81 */       return;
/*  90:    */     }
/*  91: 83 */     for (LValue lValue : createdHere) {
/*  92: 84 */       if ((lValue instanceof LocalVariable))
/*  93:    */       {
/*  94: 85 */         LocalVariable localVariable = (LocalVariable)lValue;
/*  95: 86 */         int offset = localVariable.getOriginalRawOffset();
/*  96: 87 */         int slot = localVariable.getIdx();
/*  97: 88 */         if ((offset >= 0) && (slot >= 0))
/*  98:    */         {
/*  99: 91 */           SortedMap<Integer, Integer> heapMap = this.instrsByOffset.headMap(Integer.valueOf(offset));
/* 100: 92 */           int offsetTolerance = heapMap.isEmpty() ? 1 : offset - ((Integer)heapMap.lastKey()).intValue();
/* 101:    */           
/* 102: 94 */           List<AnnotationTableTypeEntry<TypeAnnotationTargetInfo.TypeAnnotationLocalVarTarget>> entries = this.typeAnnotations.getLocalVariableAnnotations(offset, slot, offsetTolerance);
/* 103: 96 */           if (!entries.isEmpty())
/* 104:    */           {
/* 105: 98 */             annotatedTypeInstance = localVariable.getAnnotatedCreationType();
/* 106: 99 */             if (annotatedTypeInstance == null)
/* 107:    */             {
/* 108:100 */               annotatedTypeInstance = localVariable.getInferredJavaType().getJavaTypeInstance().getAnnotatedInstance();
/* 109:101 */               localVariable.setCustomCreationType(annotatedTypeInstance);
/* 110:    */             }
/* 111:104 */             for (AnnotationTableTypeEntry<TypeAnnotationTargetInfo.TypeAnnotationLocalVarTarget> entry : entries)
/* 112:    */             {
/* 113:105 */               JavaAnnotatedTypeIterator iterator = annotatedTypeInstance.pathIterator();
/* 114:106 */               for (TypePathPart part : entry.getTypePath().segments) {
/* 115:107 */                 iterator = part.apply(iterator, this.comments);
/* 116:    */               }
/* 117:109 */               iterator.apply(entry);
/* 118:    */             }
/* 119:    */           }
/* 120:    */         }
/* 121:    */       }
/* 122:    */     }
/* 123:    */     JavaAnnotatedTypeInstance annotatedTypeInstance;
/* 124:    */   }
/* 125:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.TypeAnnotationTransformer
 * JD-Core Version:    0.7.0.1
 */