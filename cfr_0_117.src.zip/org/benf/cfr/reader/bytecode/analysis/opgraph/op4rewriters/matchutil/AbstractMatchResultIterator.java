package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil;

import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;

public class AbstractMatchResultIterator
  implements MatchResultCollector
{
  public void clear() {}
  
  public void collectStatement(String name, StructuredStatement statement) {}
  
  public void collectStatementRange(String name, MatchIterator<StructuredStatement> start, MatchIterator<StructuredStatement> end) {}
  
  public void collectMatches(String name, WildcardMatch wcm) {}
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.AbstractMatchResultIterator
 * JD-Core Version:    0.7.0.1
 */