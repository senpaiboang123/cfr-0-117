/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.iterrewriter;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.Op04Rewriter;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.AbstractMatchResultIterator;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.CollectMatch;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.CollectMatchRange;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.KleenePlus;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchOneOf;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchSequence;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.Matcher;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.Negated;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.ResetAfterTest;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.MiscStatementTools;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.BooleanExpression;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.NotOperation;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.ExpressionWildcard;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.LValueWildcard;
/*  26:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  27:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.Block;
/*  28:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredAssignment;
/*  29:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredBreak;
/*  30:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredDo;
/*  31:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredIf;
/*  32:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredIter;
/*  33:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredReturn;
/*  34:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredWhile;
/*  35:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.BeginBlock;
/*  36:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.EndBlock;
/*  37:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaArrayTypeInstance;
/*  38:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  39:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  40:    */ import org.benf.cfr.reader.util.ClassFileVersion;
/*  41:    */ import org.benf.cfr.reader.util.Predicate;
/*  42:    */ import org.benf.cfr.reader.util.getopt.Options;
/*  43:    */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*  44:    */ 
/*  45:    */ public class LoopIterRewriter
/*  46:    */   implements Op04Rewriter
/*  47:    */ {
/*  48:    */   private final Options options;
/*  49:    */   private final ClassFileVersion classFileVersion;
/*  50:    */   
/*  51:    */   public LoopIterRewriter(Options options, ClassFileVersion classFileVersion)
/*  52:    */   {
/*  53: 29 */     this.options = options;
/*  54: 30 */     this.classFileVersion = classFileVersion;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void rewrite(Op04StructuredStatement root)
/*  58:    */   {
/*  59: 35 */     if (!((Boolean)this.options.getOption(OptionsImpl.ARRAY_ITERATOR, this.classFileVersion)).booleanValue()) {
/*  60: 35 */       return;
/*  61:    */     }
/*  62: 37 */     List<StructuredStatement> structuredStatements = MiscStatementTools.linearise(root);
/*  63: 38 */     if (structuredStatements == null) {
/*  64: 38 */       return;
/*  65:    */     }
/*  66: 40 */     MatchIterator<StructuredStatement> mi = new MatchIterator(structuredStatements);
/*  67:    */     
/*  68: 42 */     WildcardMatch wcm = new WildcardMatch();
/*  69:    */     
/*  70: 44 */     LValue array$_lv = wcm.getLValueWildCard("arr$", new Predicate()
/*  71:    */     {
/*  72:    */       public boolean test(LValue in)
/*  73:    */       {
/*  74: 47 */         JavaTypeInstance type = in.getInferredJavaType().getJavaTypeInstance();
/*  75: 48 */         if ((type instanceof JavaArrayTypeInstance)) {
/*  76: 48 */           return true;
/*  77:    */         }
/*  78: 49 */         return false;
/*  79:    */       }
/*  80: 52 */     });
/*  81: 53 */     Expression collection = wcm.getExpressionWildCard("collection");
/*  82:    */     
/*  83: 55 */     LValue i$_lv = wcm.getLValueWildCard("i$");
/*  84: 56 */     Expression i$ = new LValueExpression(i$_lv);
/*  85: 57 */     LValue iter_lv = wcm.getLValueWildCard("iter");
/*  86: 58 */     Expression iter = new LValueExpression(i$_lv);
/*  87:    */     
/*  88:    */ 
/*  89: 61 */     Matcher<StructuredStatement> m = new ResetAfterTest(wcm, new MatchSequence(new Matcher[] { new CollectMatch("i$", new StructuredAssignment(i$_lv, wcm.getMemberFunction("iterfn", "iterator", collection))), new MatchOneOf(new Matcher[] { new MatchSequence(new Matcher[] { new CollectMatch("do", new StructuredDo(null, null, wcm.getBlockIdentifier("doblockident"))), new BeginBlock(wcm.getBlockWildcard("doblock")), new CollectMatch("exit", new StructuredIf(new NotOperation(new BooleanExpression(wcm.getMemberFunction("hasnext", "hasNext", i$))), null)), new BeginBlock(null), new CollectMatch("exitinner", new MatchOneOf(new Matcher[] { new StructuredBreak(wcm.getBlockIdentifier("doblockident"), false), new StructuredReturn(wcm.getExpressionWildCard("returnvalue"), null), new StructuredReturn(null, null) })), new EndBlock(null), new CollectMatch("incr", new StructuredAssignment(iter_lv, wcm.getMemberFunction("getnext", "next", i$))), new CollectMatchRange("body", new KleenePlus(new Negated(new EndBlock(wcm.getBlockWildcard("doblock"))))), new EndBlock(wcm.getBlockWildcard("doblock")) }), new MatchSequence(new Matcher[] { new CollectMatch("while", new StructuredWhile(new BooleanExpression(wcm.getMemberFunction("hasnext", "hasNext", i$)), null, wcm.getBlockIdentifier("whileblockident"))), new BeginBlock(wcm.getBlockWildcard("whileblockident")), new CollectMatch("incr", new StructuredAssignment(iter_lv, wcm.getMemberFunction("getnext", "next", i$))), new CollectMatchRange("body", new KleenePlus(new Negated(new EndBlock(wcm.getBlockWildcard("whileblockident"))))), new EndBlock(wcm.getBlockWildcard("whileblockident")) }) }) }));
/*  90:    */     
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124: 96 */     IterMatchResultCollector matchResultCollector = new IterMatchResultCollector(null);
/* 125: 97 */     while (mi.hasNext())
/* 126:    */     {
/* 127: 98 */       mi.advance();
/* 128: 99 */       matchResultCollector.clear();
/* 129:100 */       if (m.match(mi, matchResultCollector))
/* 130:    */       {
/* 131:103 */         switch (2.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$opgraph$op4rewriters$iterrewriter$LoopIterRewriter$MatchType[matchResultCollector.getMatchType().ordinal()])
/* 132:    */         {
/* 133:    */         case 1: 
/* 134:105 */           validateAndRewriteWhile(mi, matchResultCollector);
/* 135:106 */           break;
/* 136:    */         case 2: 
/* 137:108 */           validateAndRewriteDo(mi, matchResultCollector);
/* 138:    */         }
/* 139:111 */         mi.rewind1();
/* 140:    */       }
/* 141:    */     }
/* 142:    */   }
/* 143:    */   
/* 144:    */   private static enum MatchType
/* 145:    */   {
/* 146:119 */     NONE,  WHILE_LOOP,  DO_LOOP;
/* 147:    */     
/* 148:    */     private MatchType() {}
/* 149:    */   }
/* 150:    */   
/* 151:    */   private static class IterMatchResultCollector
/* 152:    */     extends AbstractMatchResultIterator
/* 153:    */   {
/* 154:    */     LoopIterRewriter.MatchType matchType;
/* 155:    */     StructuredAssignment iSetup;
/* 156:    */     StructuredStatement exit;
/* 157:    */     StructuredStatement exitinner;
/* 158:    */     StructuredStatement incrStatement;
/* 159:    */     StructuredDo doStatement;
/* 160:    */     StructuredWhile whileStatement;
/* 161:    */     LValue iter_lv;
/* 162:    */     Expression collection;
/* 163:    */     
/* 164:    */     public void clear()
/* 165:    */     {
/* 166:139 */       this.matchType = LoopIterRewriter.MatchType.NONE;
/* 167:140 */       this.iSetup = null;
/* 168:141 */       this.exit = null;
/* 169:142 */       this.doStatement = null;
/* 170:143 */       this.whileStatement = null;
/* 171:144 */       this.incrStatement = null;
/* 172:    */     }
/* 173:    */     
/* 174:    */     public void collectStatement(String name, StructuredStatement statement)
/* 175:    */     {
/* 176:149 */       if (name.equals("i$"))
/* 177:    */       {
/* 178:150 */         this.iSetup = ((StructuredAssignment)statement);
/* 179:    */       }
/* 180:151 */       else if (name.equals("do"))
/* 181:    */       {
/* 182:152 */         this.matchType = LoopIterRewriter.MatchType.DO_LOOP;
/* 183:153 */         this.doStatement = ((StructuredDo)statement);
/* 184:    */       }
/* 185:154 */       else if (name.equals("while"))
/* 186:    */       {
/* 187:155 */         this.matchType = LoopIterRewriter.MatchType.WHILE_LOOP;
/* 188:156 */         this.whileStatement = ((StructuredWhile)statement);
/* 189:    */       }
/* 190:157 */       else if (name.equals("exit"))
/* 191:    */       {
/* 192:158 */         this.exit = statement;
/* 193:    */       }
/* 194:159 */       else if (name.equals("exitinner"))
/* 195:    */       {
/* 196:160 */         this.exitinner = statement;
/* 197:    */       }
/* 198:161 */       else if (name.equals("incr"))
/* 199:    */       {
/* 200:162 */         this.incrStatement = statement;
/* 201:    */       }
/* 202:    */       else
/* 203:    */       {
/* 204:164 */         throw new UnsupportedOperationException("Unexpected match " + name);
/* 205:    */       }
/* 206:    */     }
/* 207:    */     
/* 208:    */     public void collectStatementRange(String name, MatchIterator<StructuredStatement> start, MatchIterator<StructuredStatement> end)
/* 209:    */     {
/* 210:171 */       if (!name.equals("body")) {
/* 211:173 */         throw new UnsupportedOperationException("Unexpected match " + name);
/* 212:    */       }
/* 213:    */     }
/* 214:    */     
/* 215:    */     public void collectMatches(String name, WildcardMatch wcm)
/* 216:    */     {
/* 217:179 */       this.iter_lv = wcm.getLValueWildCard("iter").getMatch();
/* 218:180 */       this.collection = wcm.getExpressionWildCard("collection").getMatch();
/* 219:    */     }
/* 220:    */     
/* 221:    */     private LoopIterRewriter.MatchType getMatchType()
/* 222:    */     {
/* 223:185 */       return this.matchType;
/* 224:    */     }
/* 225:    */   }
/* 226:    */   
/* 227:    */   private boolean validateAndRewriteDo(MatchIterator<StructuredStatement> mi, IterMatchResultCollector matchResultCollector)
/* 228:    */   {
/* 229:190 */     StructuredDo doStatement = matchResultCollector.doStatement;
/* 230:191 */     Op04StructuredStatement doContainer = doStatement.getContainer();
/* 231:192 */     Op04StructuredStatement doBody = doStatement.getBody();
/* 232:197 */     if (!(doBody.getStatement() instanceof Block)) {
/* 233:198 */       return false;
/* 234:    */     }
/* 235:205 */     StructuredStatement exitInner = matchResultCollector.exitinner;
/* 236:206 */     boolean copyexit = false;
/* 237:207 */     if ((exitInner instanceof StructuredReturn))
/* 238:    */     {
/* 239:208 */       boolean legitReturn = false;
/* 240:209 */       if (mi.isFinished())
/* 241:    */       {
/* 242:210 */         legitReturn = true;
/* 243:    */       }
/* 244:    */       else
/* 245:    */       {
/* 246:212 */         StructuredStatement afterLoop = (StructuredStatement)mi.getCurrent();
/* 247:213 */         int remaining = mi.getRemaining();
/* 248:214 */         if ((remaining == 1) && ((afterLoop instanceof EndBlock)))
/* 249:    */         {
/* 250:215 */           copyexit = true;
/* 251:216 */           legitReturn = true;
/* 252:    */         }
/* 253:218 */         else if (afterLoop.equals(exitInner))
/* 254:    */         {
/* 255:218 */           legitReturn = true;
/* 256:    */         }
/* 257:    */       }
/* 258:221 */       if (!legitReturn) {
/* 259:221 */         return false;
/* 260:    */       }
/* 261:    */     }
/* 262:225 */     matchResultCollector.incrStatement.getContainer().nopOut();
/* 263:    */     
/* 264:227 */     LValue iter_lv = matchResultCollector.iter_lv;
/* 265:228 */     Expression collection = matchResultCollector.collection;
/* 266:    */     
/* 267:230 */     matchResultCollector.iSetup.getContainer().nopOut();
/* 268:231 */     matchResultCollector.exit.getContainer().nopOut();
/* 269:    */     
/* 270:233 */     BlockIdentifier blockidentifier = doStatement.getBlock();
/* 271:234 */     StructuredStatement replacement = new StructuredIter(blockidentifier, iter_lv, collection, doBody);
/* 272:236 */     if (copyexit) {
/* 273:237 */       replacement = Block.getBlockFor(false, new StructuredStatement[] { replacement, exitInner });
/* 274:    */     }
/* 275:240 */     doContainer.replaceContainedStatement(replacement);
/* 276:    */     
/* 277:242 */     return true;
/* 278:    */   }
/* 279:    */   
/* 280:    */   private boolean validateAndRewriteWhile(MatchIterator<StructuredStatement> mi, IterMatchResultCollector matchResultCollector)
/* 281:    */   {
/* 282:246 */     StructuredWhile whileStatement = matchResultCollector.whileStatement;
/* 283:247 */     Op04StructuredStatement whileContainer = whileStatement.getContainer();
/* 284:248 */     Op04StructuredStatement whileBody = whileStatement.getBody();
/* 285:    */     
/* 286:250 */     matchResultCollector.incrStatement.getContainer().nopOut();
/* 287:    */     
/* 288:252 */     LValue iter_lv = matchResultCollector.iter_lv;
/* 289:253 */     Expression collection = matchResultCollector.collection;
/* 290:    */     
/* 291:255 */     matchResultCollector.iSetup.getContainer().nopOut();
/* 292:    */     
/* 293:257 */     BlockIdentifier blockidentifier = whileStatement.getBlock();
/* 294:258 */     StructuredStatement replacement = new StructuredIter(blockidentifier, iter_lv, collection, whileBody);
/* 295:    */     
/* 296:260 */     whileContainer.replaceContainedStatement(replacement);
/* 297:    */     
/* 298:262 */     return true;
/* 299:    */   }
/* 300:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.iterrewriter.LoopIterRewriter
 * JD-Core Version:    0.7.0.1
 */