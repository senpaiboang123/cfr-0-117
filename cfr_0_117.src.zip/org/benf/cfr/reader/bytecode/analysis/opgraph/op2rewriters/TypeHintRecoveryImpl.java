/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Map;
/*  5:   */ import org.benf.cfr.reader.bytecode.BytecodeMeta;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.types.BindingSuperContainer;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.types.GenericTypeBinder;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericRefTypeInstance;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.types.TypeConstants;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/* 13:   */ 
/* 14:   */ public class TypeHintRecoveryImpl
/* 15:   */   implements TypeHintRecovery
/* 16:   */ {
/* 17:   */   private final Map<Integer, JavaTypeInstance> iteratedTypeHints;
/* 18:   */   
/* 19:   */   public TypeHintRecoveryImpl(BytecodeMeta bytecodeMeta)
/* 20:   */   {
/* 21:14 */     this.iteratedTypeHints = bytecodeMeta.getIteratedTypeHints();
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void improve(InferredJavaType type)
/* 25:   */   {
/* 26:19 */     int index = type.getTaggedBytecodeLocation();
/* 27:20 */     if (index < 0) {
/* 28:20 */       return;
/* 29:   */     }
/* 30:21 */     JavaTypeInstance original = type.getJavaTypeInstance();
/* 31:22 */     JavaTypeInstance improved = (JavaTypeInstance)this.iteratedTypeHints.get(Integer.valueOf(index));
/* 32:23 */     if ((improved == null) || (!(original instanceof JavaGenericRefTypeInstance))) {
/* 33:23 */       return;
/* 34:   */     }
/* 35:24 */     BindingSuperContainer bindingSuperContainer = original.getBindingSupers();
/* 36:25 */     JavaGenericRefTypeInstance unboundIterable = bindingSuperContainer.getBoundSuperForBase(TypeConstants.ITERABLE);
/* 37:26 */     JavaGenericRefTypeInstance unboundThis = bindingSuperContainer.getBoundSuperForBase(original.getDeGenerifiedType());
/* 38:27 */     List<JavaTypeInstance> iterTypes = unboundIterable.getGenericTypes();
/* 39:28 */     if (iterTypes.size() != 1) {
/* 40:28 */       return;
/* 41:   */     }
/* 42:29 */     String unbound = ((JavaTypeInstance)iterTypes.get(0)).getRawName();
/* 43:30 */     GenericTypeBinder genericTypeBinder = GenericTypeBinder.createEmpty();
/* 44:31 */     genericTypeBinder.suggestBindingFor(unbound, improved);
/* 45:32 */     JavaTypeInstance rebound = genericTypeBinder.getBindingFor(unboundThis);
/* 46:33 */     type.forceDelegate(new InferredJavaType(rebound, InferredJavaType.Source.IMPROVED_ITERATION));
/* 47:   */   }
/* 48:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters.TypeHintRecoveryImpl
 * JD-Core Version:    0.7.0.1
 */