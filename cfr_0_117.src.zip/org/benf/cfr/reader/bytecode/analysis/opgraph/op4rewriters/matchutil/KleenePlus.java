/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  4:   */ 
/*  5:   */ public class KleenePlus
/*  6:   */   extends KleeneN
/*  7:   */ {
/*  8:   */   public KleenePlus(Matcher<StructuredStatement> inner)
/*  9:   */   {
/* 10: 7 */     super(1, inner);
/* 11:   */   }
/* 12:   */   
/* 13:   */   public KleenePlus(Matcher<StructuredStatement>... matchers)
/* 14:   */   {
/* 15:11 */     super(1, matchers);
/* 16:   */   }
/* 17:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.KleenePlus
 * JD-Core Version:    0.7.0.1
 */