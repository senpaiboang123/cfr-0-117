/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.AbstractMatchResultIterator;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.CollectMatch;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchOneOf;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchSequence;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.Matcher;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.ResetAfterTest;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.MiscStatementTools;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.BoolOp;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.BooleanExpression;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.BooleanOperation;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.NotOperation;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StaticVariable;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.ConditionalExpressionWildcard;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.StaticVariableWildcard;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  26:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredAssert;
/*  27:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredAssignment;
/*  28:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredBreak;
/*  29:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredIf;
/*  30:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredReturn;
/*  31:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredThrow;
/*  32:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.BeginBlock;
/*  33:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.EndBlock;
/*  34:    */ import org.benf.cfr.reader.bytecode.analysis.types.InnerClassInfo;
/*  35:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  36:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  37:    */ import org.benf.cfr.reader.bytecode.analysis.types.TypeConstants;
/*  38:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  39:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  40:    */ import org.benf.cfr.reader.entities.AccessFlag;
/*  41:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  42:    */ import org.benf.cfr.reader.entities.ClassFileField;
/*  43:    */ import org.benf.cfr.reader.entities.Field;
/*  44:    */ import org.benf.cfr.reader.entities.Method;
/*  45:    */ 
/*  46:    */ public class AssertRewriter
/*  47:    */ {
/*  48:    */   private final ClassFile classFile;
/*  49: 25 */   private ClassFileField assertionsDisabledField = null;
/*  50: 26 */   private StaticVariable assertionStatic = null;
/*  51:    */   
/*  52:    */   public AssertRewriter(ClassFile classFile)
/*  53:    */   {
/*  54: 29 */     this.classFile = classFile;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void sugarAsserts(Method staticInit)
/*  58:    */   {
/*  59: 40 */     if (!staticInit.hasCodeAttribute()) {
/*  60: 40 */       return;
/*  61:    */     }
/*  62: 41 */     List<StructuredStatement> statements = MiscStatementTools.linearise(staticInit.getAnalysis());
/*  63: 42 */     if (statements == null) {
/*  64: 42 */       return;
/*  65:    */     }
/*  66: 43 */     MatchIterator<StructuredStatement> mi = new MatchIterator(statements);
/*  67: 44 */     WildcardMatch wcm1 = new WildcardMatch();
/*  68:    */     
/*  69: 46 */     JavaTypeInstance topClassType = this.classFile.getClassType();
/*  70: 47 */     InnerClassInfo innerClassInfo = topClassType.getInnerClassHereInfo();
/*  71: 48 */     JavaTypeInstance classType = topClassType;
/*  72: 49 */     while (innerClassInfo != InnerClassInfo.NOT)
/*  73:    */     {
/*  74: 50 */       JavaTypeInstance nextClass = innerClassInfo.getOuterClass();
/*  75: 51 */       if ((nextClass == null) || (nextClass.equals(classType))) {
/*  76:    */         break;
/*  77:    */       }
/*  78: 52 */       classType = nextClass;
/*  79: 53 */       innerClassInfo = classType.getInnerClassHereInfo();
/*  80:    */     }
/*  81: 56 */     Matcher<StructuredStatement> m = new ResetAfterTest(wcm1, new CollectMatch("ass1", new StructuredAssignment(wcm1.getStaticVariable("assertbool", topClassType, new InferredJavaType(RawJavaType.BOOLEAN, InferredJavaType.Source.TEST)), new NotOperation(new BooleanExpression(wcm1.getMemberFunction("assertmeth", "desiredAssertionStatus", new Literal(TypedLiteral.getClass(classType))))))));
/*  82:    */     
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92: 67 */     AssertVarCollector matchResultCollector = new AssertVarCollector(wcm1, null);
/*  93: 68 */     while (mi.hasNext())
/*  94:    */     {
/*  95: 69 */       mi.advance();
/*  96: 70 */       matchResultCollector.clear();
/*  97: 71 */       if (m.match(mi, matchResultCollector))
/*  98:    */       {
/*  99: 74 */         if (matchResultCollector.matched()) {
/* 100:    */           break;
/* 101:    */         }
/* 102: 75 */         mi.rewind1();
/* 103:    */       }
/* 104:    */     }
/* 105: 78 */     if (!matchResultCollector.matched()) {
/* 106: 78 */       return;
/* 107:    */     }
/* 108: 79 */     this.assertionsDisabledField = matchResultCollector.assertField;
/* 109: 80 */     this.assertionStatic = matchResultCollector.assertStatic;
/* 110:    */     
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117: 88 */     rewriteMethods();
/* 118:    */   }
/* 119:    */   
/* 120:    */   private class AssertVarCollector
/* 121:    */     extends AbstractMatchResultIterator
/* 122:    */   {
/* 123:    */     private final WildcardMatch wcm;
/* 124: 95 */     ClassFileField assertField = null;
/* 125: 96 */     StaticVariable assertStatic = null;
/* 126:    */     
/* 127:    */     private AssertVarCollector(WildcardMatch wcm)
/* 128:    */     {
/* 129: 99 */       this.wcm = wcm;
/* 130:    */     }
/* 131:    */     
/* 132:    */     public void clear()
/* 133:    */     {
/* 134:104 */       this.assertField = null;
/* 135:105 */       this.assertStatic = null;
/* 136:    */     }
/* 137:    */     
/* 138:    */     public void collectStatement(String name, StructuredStatement statement)
/* 139:    */     {
/* 140:110 */       StaticVariable staticVariable = this.wcm.getStaticVariable("assertbool").getMatch();
/* 141:    */       ClassFileField field;
/* 142:    */       try
/* 143:    */       {
/* 144:114 */         field = AssertRewriter.this.classFile.getFieldByName(staticVariable.getFieldName(), staticVariable.getInferredJavaType().getJavaTypeInstance());
/* 145:    */       }
/* 146:    */       catch (NoSuchFieldException e)
/* 147:    */       {
/* 148:116 */         return;
/* 149:    */       }
/* 150:118 */       if (!field.getField().testAccessFlag(AccessFlag.ACC_SYNTHETIC)) {
/* 151:118 */         return;
/* 152:    */       }
/* 153:119 */       this.assertField = field;
/* 154:120 */       statement.getContainer().nopOut();
/* 155:121 */       this.assertField.markHidden();
/* 156:122 */       this.assertStatic = staticVariable;
/* 157:    */     }
/* 158:    */     
/* 159:    */     public void collectMatches(String name, WildcardMatch wcm) {}
/* 160:    */     
/* 161:    */     public boolean matched()
/* 162:    */     {
/* 163:130 */       return this.assertField != null;
/* 164:    */     }
/* 165:    */   }
/* 166:    */   
/* 167:    */   private void rewriteMethods()
/* 168:    */   {
/* 169:135 */     List<Method> methods = this.classFile.getMethods();
/* 170:    */     
/* 171:137 */     WildcardMatch wcm1 = new WildcardMatch();
/* 172:    */     
/* 173:139 */     Matcher<StructuredStatement> m = new ResetAfterTest(wcm1, new MatchOneOf(new Matcher[] { new CollectMatch("ass1", new MatchSequence(new Matcher[] { new StructuredIf(new BooleanOperation(new NotOperation(new BooleanExpression(new LValueExpression(this.assertionStatic))), wcm1.getConditionalExpressionWildcard("condition"), BoolOp.AND), null), new BeginBlock(null), new StructuredThrow(wcm1.getConstructorSimpleWildcard("exception", TypeConstants.ASSERTION_ERROR)), new EndBlock(null) })), new CollectMatch("ass1b", new MatchSequence(new Matcher[] { new StructuredIf(new NotOperation(new BooleanOperation(new BooleanExpression(new LValueExpression(this.assertionStatic)), wcm1.getConditionalExpressionWildcard("condition"), BoolOp.OR)), null), new BeginBlock(null), new StructuredThrow(wcm1.getConstructorSimpleWildcard("exception", TypeConstants.ASSERTION_ERROR)), new EndBlock(null) })), new CollectMatch("ass2", new MatchSequence(new Matcher[] { new MatchOneOf(new Matcher[] { new StructuredIf(new BooleanOperation(new BooleanExpression(new LValueExpression(this.assertionStatic)), wcm1.getConditionalExpressionWildcard("condition2"), BoolOp.OR), null), new StructuredIf(new BooleanExpression(new LValueExpression(this.assertionStatic)), null) }), new BeginBlock(wcm1.getBlockWildcard("condBlock")), new MatchOneOf(new Matcher[] { new StructuredReturn(null, null), new StructuredReturn(wcm1.getExpressionWildCard("retval"), null), new StructuredBreak(wcm1.getBlockIdentifier("breakblock"), false) }), new EndBlock(wcm1.getBlockWildcard("condBlock")), new CollectMatch("ass2throw", new StructuredThrow(wcm1.getConstructorSimpleWildcard("exception2", TypeConstants.ASSERTION_ERROR))) })), new CollectMatch("assonly", new MatchSequence(new Matcher[] { new StructuredIf(new NotOperation(new BooleanExpression(new LValueExpression(this.assertionStatic))), null), new BeginBlock(null), new StructuredThrow(wcm1.getConstructorSimpleWildcard("exception", TypeConstants.ASSERTION_ERROR)), new EndBlock(null) })) }));
/* 174:    */     
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:    */ 
/* 181:    */ 
/* 182:    */ 
/* 183:    */ 
/* 184:    */ 
/* 185:    */ 
/* 186:    */ 
/* 187:    */ 
/* 188:    */ 
/* 189:    */ 
/* 190:    */ 
/* 191:    */ 
/* 192:    */ 
/* 193:    */ 
/* 194:    */ 
/* 195:    */ 
/* 196:    */ 
/* 197:    */ 
/* 198:    */ 
/* 199:    */ 
/* 200:    */ 
/* 201:    */ 
/* 202:    */ 
/* 203:    */ 
/* 204:    */ 
/* 205:    */ 
/* 206:    */ 
/* 207:    */ 
/* 208:    */ 
/* 209:    */ 
/* 210:    */ 
/* 211:    */ 
/* 212:    */ 
/* 213:    */ 
/* 214:    */ 
/* 215:    */ 
/* 216:    */ 
/* 217:    */ 
/* 218:    */ 
/* 219:    */ 
/* 220:    */ 
/* 221:    */ 
/* 222:    */ 
/* 223:    */ 
/* 224:    */ 
/* 225:    */ 
/* 226:    */ 
/* 227:    */ 
/* 228:194 */     AssertUseCollector collector = new AssertUseCollector(wcm1, null);
/* 229:196 */     for (Method method : methods) {
/* 230:197 */       if (method.hasCodeAttribute())
/* 231:    */       {
/* 232:199 */         List<StructuredStatement> statements = MiscStatementTools.linearise(method.getAnalysis());
/* 233:200 */         if (statements != null)
/* 234:    */         {
/* 235:202 */           MatchIterator<StructuredStatement> mi = new MatchIterator(statements);
/* 236:204 */           while (mi.hasNext())
/* 237:    */           {
/* 238:205 */             mi.advance();
/* 239:206 */             if (m.match(mi, collector)) {
/* 240:207 */               mi.rewind1();
/* 241:    */             }
/* 242:    */           }
/* 243:    */         }
/* 244:    */       }
/* 245:    */     }
/* 246:    */   }
/* 247:    */   
/* 248:    */   private class AssertUseCollector
/* 249:    */     extends AbstractMatchResultIterator
/* 250:    */   {
/* 251:    */     private StructuredStatement ass2throw;
/* 252:    */     private final WildcardMatch wcm;
/* 253:    */     
/* 254:    */     private AssertUseCollector(WildcardMatch wcm)
/* 255:    */     {
/* 256:222 */       this.wcm = wcm;
/* 257:    */     }
/* 258:    */     
/* 259:    */     public void clear()
/* 260:    */     {
/* 261:227 */       this.ass2throw = null;
/* 262:    */     }
/* 263:    */     
/* 264:    */     public void collectStatement(String name, StructuredStatement statement)
/* 265:    */     {
/* 266:232 */       if ((name.equals("ass1")) || (name.equals("ass1b")))
/* 267:    */       {
/* 268:233 */         StructuredIf ifStatement = (StructuredIf)statement;
/* 269:234 */         ConditionalExpression condition = this.wcm.getConditionalExpressionWildcard("condition").getMatch();
/* 270:235 */         if (name.equals("ass1")) {
/* 271:235 */           condition = new NotOperation(condition);
/* 272:    */         }
/* 273:236 */         condition = condition.simplify();
/* 274:237 */         StructuredStatement structuredAssert = ifStatement.convertToAssertion(new StructuredAssert(condition));
/* 275:238 */         ifStatement.getContainer().replaceContainedStatement(structuredAssert);
/* 276:    */       }
/* 277:239 */       else if (name.equals("ass2"))
/* 278:    */       {
/* 279:240 */         if (this.ass2throw == null) {
/* 280:240 */           throw new IllegalStateException();
/* 281:    */         }
/* 282:241 */         StructuredIf ifStatement = (StructuredIf)statement;
/* 283:    */         
/* 284:243 */         WildcardMatch.ConditionalExpressionWildcard wcard = this.wcm.getConditionalExpressionWildcard("condition2");
/* 285:244 */         ConditionalExpression conditionalExpression = wcard.getMatch();
/* 286:245 */         if (conditionalExpression == null) {
/* 287:246 */           conditionalExpression = new BooleanExpression(new Literal(TypedLiteral.getBoolean(0)));
/* 288:    */         }
/* 289:248 */         StructuredStatement structuredAssert = new StructuredAssert(conditionalExpression);
/* 290:249 */         ifStatement.getContainer().replaceContainedStatement(structuredAssert);
/* 291:250 */         this.ass2throw.getContainer().replaceContainedStatement(ifStatement.getIfTaken().getStatement());
/* 292:    */       }
/* 293:251 */       else if (name.equals("ass2throw"))
/* 294:    */       {
/* 295:252 */         this.ass2throw = statement;
/* 296:    */       }
/* 297:253 */       else if (name.equals("assonly"))
/* 298:    */       {
/* 299:254 */         StructuredIf ifStatement = (StructuredIf)statement;
/* 300:255 */         StructuredStatement structuredAssert = ifStatement.convertToAssertion(new StructuredAssert(new BooleanExpression(Literal.FALSE)));
/* 301:256 */         ifStatement.getContainer().replaceContainedStatement(structuredAssert);
/* 302:    */       }
/* 303:    */     }
/* 304:    */   }
/* 305:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.AssertRewriter
 * JD-Core Version:    0.7.0.1
 */