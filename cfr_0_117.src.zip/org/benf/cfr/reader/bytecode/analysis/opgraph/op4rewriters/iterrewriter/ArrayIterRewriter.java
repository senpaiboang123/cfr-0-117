/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.iterrewriter;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.Op04Rewriter;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.AbstractMatchResultIterator;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.CollectMatch;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.CollectMatchRange;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.KleenePlus;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchOneOf;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchSequence;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.Matcher;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.Negated;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.ResetAfterTest;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.MiscStatementTools;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractAssignmentExpression;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithOp;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithmeticPreMutationOperation;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArrayIndex;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArrayLength;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CompOp;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ComparisonOperation;
/*  26:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  27:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  28:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  29:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.AssignmentSimple;
/*  30:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  31:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
/*  32:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.ExpressionWildcard;
/*  33:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.LValueWildcard;
/*  34:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  35:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.Block;
/*  36:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredAssignment;
/*  37:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredBreak;
/*  38:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredDo;
/*  39:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredExpressionStatement;
/*  40:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredFor;
/*  41:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredIf;
/*  42:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredIter;
/*  43:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredReturn;
/*  44:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.BeginBlock;
/*  45:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.EndBlock;
/*  46:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaArrayTypeInstance;
/*  47:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  48:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  49:    */ import org.benf.cfr.reader.util.ClassFileVersion;
/*  50:    */ import org.benf.cfr.reader.util.ListFactory;
/*  51:    */ import org.benf.cfr.reader.util.Predicate;
/*  52:    */ import org.benf.cfr.reader.util.getopt.Options;
/*  53:    */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*  54:    */ 
/*  55:    */ public class ArrayIterRewriter
/*  56:    */   implements Op04Rewriter
/*  57:    */ {
/*  58:    */   private final Options options;
/*  59:    */   private final ClassFileVersion classFileVersion;
/*  60:    */   
/*  61:    */   public ArrayIterRewriter(Options options, ClassFileVersion classFileVersion)
/*  62:    */   {
/*  63: 31 */     this.options = options;
/*  64: 32 */     this.classFileVersion = classFileVersion;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void rewrite(Op04StructuredStatement root)
/*  68:    */   {
/*  69: 37 */     if (!((Boolean)this.options.getOption(OptionsImpl.ARRAY_ITERATOR, this.classFileVersion)).booleanValue()) {
/*  70: 37 */       return;
/*  71:    */     }
/*  72: 39 */     List<StructuredStatement> structuredStatements = MiscStatementTools.linearise(root);
/*  73: 40 */     if (structuredStatements == null) {
/*  74: 40 */       return;
/*  75:    */     }
/*  76: 42 */     MatchIterator<StructuredStatement> mi = new MatchIterator(structuredStatements);
/*  77:    */     
/*  78: 44 */     WildcardMatch wcm = new WildcardMatch();
/*  79:    */     
/*  80: 46 */     LValue array$_lv = wcm.getLValueWildCard("arr$", new Predicate()
/*  81:    */     {
/*  82:    */       public boolean test(LValue in)
/*  83:    */       {
/*  84: 49 */         JavaTypeInstance type = in.getInferredJavaType().getJavaTypeInstance();
/*  85: 50 */         if ((type instanceof JavaArrayTypeInstance)) {
/*  86: 50 */           return true;
/*  87:    */         }
/*  88: 51 */         return false;
/*  89:    */       }
/*  90: 54 */     });
/*  91: 55 */     LValue iter_lv = wcm.getLValueWildCard("i");
/*  92: 56 */     Expression iter = new LValueExpression(iter_lv);
/*  93:    */     
/*  94: 58 */     Expression orig_array = wcm.getExpressionWildCard("array");
/*  95: 59 */     LValue i$_lv = wcm.getLValueWildCard("i$");
/*  96: 60 */     Expression i$ = new LValueExpression(i$_lv);
/*  97: 61 */     LValue len$_lv = wcm.getLValueWildCard("len$");
/*  98: 62 */     Expression len$ = new LValueExpression(len$_lv);
/*  99: 63 */     Expression array$ = new LValueExpression(array$_lv);
/* 100:    */     
/* 101: 65 */     Matcher<StructuredStatement> m = new ResetAfterTest(wcm, new MatchSequence(new Matcher[] { new CollectMatch("array$", new StructuredAssignment(array$_lv, orig_array)), new CollectMatch("len$", new StructuredAssignment(len$_lv, new ArrayLength(array$))), new MatchOneOf(new Matcher[] { new MatchSequence(new Matcher[] { new CollectMatch("i$", new StructuredAssignment(i$_lv, new Literal(TypedLiteral.getInt(0)))), new CollectMatch("do", new StructuredDo(null, null, wcm.getBlockIdentifier("doblockident"))), new BeginBlock(wcm.getBlockWildcard("doblock")), new CollectMatch("exit", new StructuredIf(new ComparisonOperation(i$, len$, CompOp.GTE), null)), new BeginBlock(null), new MatchOneOf(new Matcher[] { new StructuredBreak(wcm.getBlockIdentifier("doblockident"), false), new StructuredReturn(wcm.getExpressionWildCard("returnvalue"), null), new StructuredReturn(null, null) }), new EndBlock(null), new CollectMatch("assigniter", new StructuredAssignment(iter_lv, new ArrayIndex(array$, i$))), new CollectMatchRange("body", new KleenePlus(new Negated(new MatchOneOf(new Matcher[] { new StructuredExpressionStatement(new ArithmeticPreMutationOperation(i$_lv, ArithOp.PLUS), true), new EndBlock(wcm.getBlockWildcard("doblock")) })))), new CollectMatch("incr", new StructuredExpressionStatement(new ArithmeticPreMutationOperation(i$_lv, ArithOp.PLUS), true)), new EndBlock(wcm.getBlockWildcard("doblock")) }), new MatchSequence(new Matcher[] { new CollectMatch("for", new StructuredFor(new ComparisonOperation(i$, len$, CompOp.LT), new AssignmentSimple(i$_lv, new Literal(TypedLiteral.getInt(0))), ListFactory.newList(new AbstractAssignmentExpression[] { new ArithmeticPreMutationOperation(i$_lv, ArithOp.PLUS) }), null, wcm.getBlockIdentifier("doblockident"))), new BeginBlock(wcm.getBlockWildcard("forblock")), new CollectMatch("assigniter", new StructuredAssignment(iter_lv, new ArrayIndex(array$, i$))), new CollectMatchRange("body", new KleenePlus(new Negated(new EndBlock(wcm.getBlockWildcard("doblock"))))), new EndBlock(wcm.getBlockWildcard("forblock")) }) }) }));
/* 102:    */     
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:    */ 
/* 127:    */ 
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:    */ 
/* 134:    */ 
/* 135:    */ 
/* 136:    */ 
/* 137:    */ 
/* 138:    */ 
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:    */ 
/* 147:    */ 
/* 148:    */ 
/* 149:113 */     IterMatchResultCollector matchResultCollector = new IterMatchResultCollector(null);
/* 150:114 */     while (mi.hasNext())
/* 151:    */     {
/* 152:115 */       mi.advance();
/* 153:116 */       matchResultCollector.clear();
/* 154:117 */       if (m.match(mi, matchResultCollector))
/* 155:    */       {
/* 156:120 */         switch (2.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$opgraph$op4rewriters$iterrewriter$ArrayIterRewriter$MatchType[matchResultCollector.getMatchType().ordinal()])
/* 157:    */         {
/* 158:    */         case 1: 
/* 159:122 */           validateAndRewriteFor(matchResultCollector);
/* 160:123 */           break;
/* 161:    */         case 2: 
/* 162:125 */           validateAndRewriteDo(matchResultCollector);
/* 163:    */         }
/* 164:128 */         mi.rewind1();
/* 165:    */       }
/* 166:    */     }
/* 167:    */   }
/* 168:    */   
/* 169:    */   private static enum MatchType
/* 170:    */   {
/* 171:136 */     NONE,  FOR_LOOP,  DO_LOOP;
/* 172:    */     
/* 173:    */     private MatchType() {}
/* 174:    */   }
/* 175:    */   
/* 176:    */   private static class IterMatchResultCollector
/* 177:    */     extends AbstractMatchResultIterator
/* 178:    */   {
/* 179:    */     ArrayIterRewriter.MatchType matchType;
/* 180:    */     StructuredAssignment arraySetup;
/* 181:    */     StructuredAssignment lenSetup;
/* 182:    */     StructuredAssignment iSetup;
/* 183:    */     StructuredStatement exit;
/* 184:    */     StructuredStatement incrStatement;
/* 185:    */     StructuredStatement assignIter;
/* 186:    */     StructuredDo doStatement;
/* 187:    */     StructuredFor forStatement;
/* 188:    */     LValue iter_lv;
/* 189:    */     Expression orig_array;
/* 190:    */     
/* 191:    */     public void clear()
/* 192:    */     {
/* 193:158 */       this.matchType = ArrayIterRewriter.MatchType.NONE;
/* 194:159 */       this.arraySetup = (this.lenSetup = this.iSetup = null);
/* 195:160 */       this.exit = null;
/* 196:161 */       this.doStatement = null;
/* 197:162 */       this.forStatement = null;
/* 198:163 */       this.incrStatement = null;
/* 199:    */     }
/* 200:    */     
/* 201:    */     public void collectStatement(String name, StructuredStatement statement)
/* 202:    */     {
/* 203:168 */       if (name.equals("array$"))
/* 204:    */       {
/* 205:169 */         this.arraySetup = ((StructuredAssignment)statement);
/* 206:    */       }
/* 207:170 */       else if (name.equals("len$"))
/* 208:    */       {
/* 209:171 */         this.lenSetup = ((StructuredAssignment)statement);
/* 210:    */       }
/* 211:172 */       else if (name.equals("i$"))
/* 212:    */       {
/* 213:173 */         this.iSetup = ((StructuredAssignment)statement);
/* 214:    */       }
/* 215:174 */       else if (name.equals("do"))
/* 216:    */       {
/* 217:175 */         this.matchType = ArrayIterRewriter.MatchType.DO_LOOP;
/* 218:176 */         this.doStatement = ((StructuredDo)statement);
/* 219:    */       }
/* 220:177 */       else if (name.equals("for"))
/* 221:    */       {
/* 222:178 */         this.matchType = ArrayIterRewriter.MatchType.FOR_LOOP;
/* 223:179 */         this.forStatement = ((StructuredFor)statement);
/* 224:    */       }
/* 225:180 */       else if (name.equals("exit"))
/* 226:    */       {
/* 227:181 */         this.exit = statement;
/* 228:    */       }
/* 229:182 */       else if (name.equals("incr"))
/* 230:    */       {
/* 231:183 */         this.incrStatement = statement;
/* 232:    */       }
/* 233:184 */       else if (name.equals("assigniter"))
/* 234:    */       {
/* 235:185 */         this.assignIter = statement;
/* 236:    */       }
/* 237:    */       else
/* 238:    */       {
/* 239:187 */         throw new UnsupportedOperationException("Unexpected match " + name);
/* 240:    */       }
/* 241:    */     }
/* 242:    */     
/* 243:    */     public void collectStatementRange(String name, MatchIterator<StructuredStatement> start, MatchIterator<StructuredStatement> end)
/* 244:    */     {
/* 245:194 */       if (!name.equals("body")) {
/* 246:196 */         throw new UnsupportedOperationException("Unexpected match " + name);
/* 247:    */       }
/* 248:    */     }
/* 249:    */     
/* 250:    */     public void collectMatches(String name, WildcardMatch wcm)
/* 251:    */     {
/* 252:202 */       this.iter_lv = wcm.getLValueWildCard("i").getMatch();
/* 253:203 */       this.orig_array = wcm.getExpressionWildCard("array").getMatch();
/* 254:    */     }
/* 255:    */     
/* 256:    */     private ArrayIterRewriter.MatchType getMatchType()
/* 257:    */     {
/* 258:208 */       return this.matchType;
/* 259:    */     }
/* 260:    */   }
/* 261:    */   
/* 262:    */   private boolean validateAndRewriteFor(IterMatchResultCollector matchResultCollector)
/* 263:    */   {
/* 264:213 */     StructuredFor structuredFor = matchResultCollector.forStatement;
/* 265:214 */     Op04StructuredStatement forContainer = structuredFor.getContainer();
/* 266:215 */     Op04StructuredStatement forBody = structuredFor.getBody();
/* 267:217 */     if (!(forBody.getStatement() instanceof Block)) {
/* 268:218 */       return false;
/* 269:    */     }
/* 270:221 */     BlockIdentifier blockidentifier = structuredFor.getBlock();
/* 271:    */     
/* 272:223 */     LValue iter_lv = matchResultCollector.iter_lv;
/* 273:224 */     Expression array = matchResultCollector.orig_array;
/* 274:    */     
/* 275:226 */     matchResultCollector.arraySetup.getContainer().nopOut();
/* 276:227 */     matchResultCollector.lenSetup.getContainer().nopOut();
/* 277:228 */     matchResultCollector.assignIter.getContainer().nopOut();
/* 278:    */     
/* 279:230 */     StructuredStatement forIter = new StructuredIter(blockidentifier, iter_lv, array, forBody);
/* 280:231 */     forContainer.replaceContainedStatement(forIter);
/* 281:    */     
/* 282:    */ 
/* 283:234 */     return true;
/* 284:    */   }
/* 285:    */   
/* 286:    */   private boolean validateAndRewriteDo(IterMatchResultCollector matchResultCollector)
/* 287:    */   {
/* 288:238 */     StructuredDo doStatement = matchResultCollector.doStatement;
/* 289:239 */     Op04StructuredStatement doContainer = doStatement.getContainer();
/* 290:240 */     Op04StructuredStatement doBody = doStatement.getBody();
/* 291:245 */     if (!(doBody.getStatement() instanceof Block)) {
/* 292:246 */       return false;
/* 293:    */     }
/* 294:249 */     matchResultCollector.incrStatement.getContainer().nopOut();
/* 295:    */     
/* 296:251 */     LValue iter_lv = matchResultCollector.iter_lv;
/* 297:252 */     Expression array = matchResultCollector.orig_array;
/* 298:    */     
/* 299:254 */     matchResultCollector.iSetup.getContainer().nopOut();
/* 300:255 */     matchResultCollector.arraySetup.getContainer().nopOut();
/* 301:256 */     matchResultCollector.lenSetup.getContainer().nopOut();
/* 302:257 */     matchResultCollector.exit.getContainer().nopOut();
/* 303:258 */     matchResultCollector.assignIter.getContainer().nopOut();
/* 304:    */     
/* 305:260 */     BlockIdentifier blockidentifier = doStatement.getBlock();
/* 306:261 */     StructuredStatement forIter = new StructuredIter(blockidentifier, iter_lv, array, doBody);
/* 307:262 */     doContainer.replaceContainedStatement(forIter);
/* 308:    */     
/* 309:264 */     return true;
/* 310:    */   }
/* 311:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.iterrewriter.ArrayIterRewriter
 * JD-Core Version:    0.7.0.1
 */