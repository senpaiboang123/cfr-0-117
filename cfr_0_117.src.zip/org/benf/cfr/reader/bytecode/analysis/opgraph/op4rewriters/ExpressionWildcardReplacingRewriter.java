/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.AbstractExpressionRewriter;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
/*  9:   */ import org.benf.cfr.reader.util.functors.NonaryFunction;
/* 10:   */ 
/* 11:   */ public class ExpressionWildcardReplacingRewriter
/* 12:   */   extends AbstractExpressionRewriter
/* 13:   */ {
/* 14:   */   private final WildcardMatch wildcardMatch;
/* 15:   */   private final Expression search;
/* 16:   */   private final NonaryFunction<Expression> replacementFunction;
/* 17:   */   
/* 18:   */   public ExpressionWildcardReplacingRewriter(WildcardMatch wildcardMatch, Expression search, NonaryFunction<Expression> replacementFunction)
/* 19:   */   {
/* 20:17 */     this.wildcardMatch = wildcardMatch;
/* 21:18 */     this.search = search;
/* 22:19 */     this.replacementFunction = replacementFunction;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 26:   */   {
/* 27:24 */     if (expression == null) {
/* 28:24 */       return null;
/* 29:   */     }
/* 30:25 */     if (this.search.equals(expression))
/* 31:   */     {
/* 32:26 */       Expression replacement = (Expression)this.replacementFunction.invoke();
/* 33:27 */       if (replacement != null)
/* 34:   */       {
/* 35:28 */         this.wildcardMatch.reset();
/* 36:29 */         return replacement;
/* 37:   */       }
/* 38:   */     }
/* 39:32 */     this.wildcardMatch.reset();
/* 40:33 */     return expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 41:   */   }
/* 42:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.ExpressionWildcardReplacingRewriter
 * JD-Core Version:    0.7.0.1
 */