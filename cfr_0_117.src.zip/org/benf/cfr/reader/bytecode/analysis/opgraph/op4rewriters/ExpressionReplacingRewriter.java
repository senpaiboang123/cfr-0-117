/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.AbstractExpressionRewriter;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  8:   */ 
/*  9:   */ public class ExpressionReplacingRewriter
/* 10:   */   extends AbstractExpressionRewriter
/* 11:   */ {
/* 12:   */   private final Expression search;
/* 13:   */   private final Expression replace;
/* 14:   */   
/* 15:   */   public ExpressionReplacingRewriter(Expression search, Expression replace)
/* 16:   */   {
/* 17:17 */     this.search = search;
/* 18:18 */     this.replace = replace;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 22:   */   {
/* 23:23 */     if (this.search.equals(expression)) {
/* 24:24 */       return this.replace;
/* 25:   */     }
/* 26:26 */     return expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.ExpressionReplacingRewriter
 * JD-Core Version:    0.7.0.1
 */