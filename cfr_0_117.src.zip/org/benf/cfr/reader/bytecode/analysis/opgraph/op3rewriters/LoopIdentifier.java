/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*   2:    */ 
/*   3:    */ import java.util.Collections;
/*   4:    */ import java.util.Comparator;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Set;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.InstrIndex;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CatchStatement;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CommentStatement;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.DoStatement;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.IfStatement;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ReturnNothingStatement;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.WhileStatement;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifierFactory;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockType;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.JumpType;
/*  23:    */ import org.benf.cfr.reader.entities.Method;
/*  24:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionGroup.Entry;
/*  25:    */ import org.benf.cfr.reader.util.CannotPerformDecode;
/*  26:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  27:    */ import org.benf.cfr.reader.util.Functional;
/*  28:    */ import org.benf.cfr.reader.util.ListFactory;
/*  29:    */ import org.benf.cfr.reader.util.MapFactory;
/*  30:    */ import org.benf.cfr.reader.util.Predicate;
/*  31:    */ import org.benf.cfr.reader.util.SetFactory;
/*  32:    */ import org.benf.cfr.reader.util.SetUtil;
/*  33:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  34:    */ 
/*  35:    */ public class LoopIdentifier
/*  36:    */ {
/*  37:    */   private static class LoopResult
/*  38:    */   {
/*  39:    */     final BlockIdentifier blockIdentifier;
/*  40:    */     final Op03SimpleStatement blockStart;
/*  41:    */     
/*  42:    */     private LoopResult(BlockIdentifier blockIdentifier, Op03SimpleStatement blockStart)
/*  43:    */     {
/*  44: 27 */       this.blockIdentifier = blockIdentifier;
/*  45: 28 */       this.blockStart = blockStart;
/*  46:    */     }
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static void identifyLoops1(Method method, List<Op03SimpleStatement> statements, BlockIdentifierFactory blockIdentifierFactory)
/*  50:    */   {
/*  51: 41 */     List<Op03SimpleStatement> pathtests = Functional.filter(statements, new TypeFilter(GotoStatement.class));
/*  52: 42 */     for (Op03SimpleStatement start : pathtests) {
/*  53: 43 */       considerAsPathologicalLoop(start, statements);
/*  54:    */     }
/*  55: 46 */     List<Op03SimpleStatement> backjumps = Functional.filter(statements, new Misc.HasBackJump());
/*  56: 47 */     List<Op03SimpleStatement> starts = Functional.uniqAll(Functional.map(backjumps, new Misc.GetBackJump()));
/*  57:    */     
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61: 52 */     Map<BlockIdentifier, Op03SimpleStatement> blockEndsCache = MapFactory.newMap();
/*  62: 53 */     Collections.sort(starts, new CompareByIndex());
/*  63:    */     
/*  64: 55 */     List<LoopResult> loopResults = ListFactory.newList();
/*  65: 56 */     Set<BlockIdentifier> relevantBlocks = SetFactory.newSet();
/*  66: 57 */     for (Op03SimpleStatement start : starts)
/*  67:    */     {
/*  68: 58 */       BlockIdentifier blockIdentifier = considerAsWhileLoopStart(method, start, statements, blockIdentifierFactory, blockEndsCache);
/*  69: 59 */       if (blockIdentifier == null) {
/*  70: 60 */         blockIdentifier = considerAsDoLoopStart(start, statements, blockIdentifierFactory, blockEndsCache);
/*  71:    */       }
/*  72: 62 */       if (blockIdentifier != null)
/*  73:    */       {
/*  74: 63 */         loopResults.add(new LoopResult(blockIdentifier, start, null));
/*  75: 64 */         relevantBlocks.add(blockIdentifier);
/*  76:    */       }
/*  77:    */     }
/*  78: 68 */     if (loopResults.isEmpty()) {
/*  79: 68 */       return;
/*  80:    */     }
/*  81: 69 */     Collections.reverse(loopResults);
/*  82:    */     
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88: 76 */     fixLoopOverlaps(statements, loopResults, relevantBlocks);
/*  89:    */   }
/*  90:    */   
/*  91:    */   private static void fixLoopOverlaps(List<Op03SimpleStatement> statements, List<LoopResult> loopResults, Set<BlockIdentifier> relevantBlocks)
/*  92:    */   {
/*  93: 86 */     Map<BlockIdentifier, List<BlockIdentifier>> requiredExtents = MapFactory.newLazyMap(new UnaryFunction()
/*  94:    */     {
/*  95:    */       public List<BlockIdentifier> invoke(BlockIdentifier arg)
/*  96:    */       {
/*  97: 89 */         return ListFactory.newList();
/*  98:    */       }
/*  99: 92 */     });
/* 100: 93 */     Map<BlockIdentifier, Op03SimpleStatement> lastForBlock = MapFactory.newMap();
/* 101: 95 */     for (LoopResult loopResult : loopResults)
/* 102:    */     {
/* 103: 96 */       final Op03SimpleStatement start = loopResult.blockStart;
/* 104: 97 */       testBlockIdentifier = loopResult.blockIdentifier;
/* 105:    */       
/* 106: 99 */       Set<BlockIdentifier> startIn = SetUtil.intersectionOrNull(start.getBlockIdentifiers(), relevantBlocks);
/* 107:100 */       List<Op03SimpleStatement> backSources = Functional.filter(start.getSources(), new Predicate()
/* 108:    */       {
/* 109:    */         public boolean test(Op03SimpleStatement in)
/* 110:    */         {
/* 111:103 */           return (in.getBlockIdentifiers().contains(this.val$testBlockIdentifier)) && (in.getIndex().isBackJumpTo(start));
/* 112:    */         }
/* 113:    */       });
/* 114:108 */       if (!backSources.isEmpty())
/* 115:    */       {
/* 116:109 */         Collections.sort(backSources, new CompareByIndex());
/* 117:110 */         Op03SimpleStatement lastBackSource = (Op03SimpleStatement)backSources.get(backSources.size() - 1);
/* 118:    */         
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:115 */         lastForBlock.put(testBlockIdentifier, lastBackSource);
/* 123:116 */         if (startIn != null)
/* 124:    */         {
/* 125:118 */           Set<BlockIdentifier> backIn = SetUtil.intersectionOrNull(lastBackSource.getBlockIdentifiers(), relevantBlocks);
/* 126:119 */           if (backIn != null) {
/* 127:120 */             if (!backIn.containsAll(startIn))
/* 128:    */             {
/* 129:122 */               Set<BlockIdentifier> startMissing = SetFactory.newSet(startIn);
/* 130:123 */               startMissing.removeAll(backIn);
/* 131:124 */               for (BlockIdentifier missing : startMissing) {
/* 132:125 */                 ((List)requiredExtents.get(missing)).add(testBlockIdentifier);
/* 133:    */               }
/* 134:    */             }
/* 135:    */           }
/* 136:    */         }
/* 137:    */       }
/* 138:    */     }
/* 139:    */     BlockIdentifier testBlockIdentifier;
/* 140:130 */     if (requiredExtents.isEmpty()) {
/* 141:130 */       return;
/* 142:    */     }
/* 143:133 */     List<BlockIdentifier> extendBlocks = ListFactory.newList(requiredExtents.keySet());
/* 144:134 */     Collections.sort(extendBlocks, new Comparator()
/* 145:    */     {
/* 146:    */       public int compare(BlockIdentifier blockIdentifier, BlockIdentifier blockIdentifier2)
/* 147:    */       {
/* 148:137 */         return blockIdentifier.getIndex() - blockIdentifier2.getIndex();
/* 149:    */       }
/* 150:140 */     });
/* 151:141 */     Comparator<Op03SimpleStatement> comparator = new CompareByIndex();
/* 152:144 */     for (BlockIdentifier extendThis : extendBlocks)
/* 153:    */     {
/* 154:145 */       List<BlockIdentifier> possibleEnds = (List)requiredExtents.get(extendThis);
/* 155:146 */       if (!possibleEnds.isEmpty())
/* 156:    */       {
/* 157:149 */         List<Op03SimpleStatement> possibleEndOps = ListFactory.newList();
/* 158:150 */         for (BlockIdentifier end : possibleEnds) {
/* 159:151 */           possibleEndOps.add(lastForBlock.get(end));
/* 160:    */         }
/* 161:153 */         Collections.sort(possibleEndOps, comparator);
/* 162:    */         
/* 163:155 */         Op03SimpleStatement extendTo = (Op03SimpleStatement)possibleEndOps.get(possibleEndOps.size() - 1);
/* 164:    */         
/* 165:    */ 
/* 166:    */ 
/* 167:    */ 
/* 168:    */ 
/* 169:161 */         Op03SimpleStatement oldEnd = (Op03SimpleStatement)lastForBlock.get(extendThis);
/* 170:    */         
/* 171:163 */         int start = statements.indexOf(oldEnd);
/* 172:164 */         int end = statements.indexOf(extendTo);
/* 173:166 */         for (int x = start; x <= end; x++) {
/* 174:167 */           ((Op03SimpleStatement)statements.get(x)).getBlockIdentifiers().add(extendThis);
/* 175:    */         }
/* 176:170 */         rewriteEndLoopOverlapStatement(oldEnd, extendThis);
/* 177:    */       }
/* 178:    */     }
/* 179:    */   }
/* 180:    */   
/* 181:    */   private static void rewriteEndLoopOverlapStatement(Op03SimpleStatement oldEnd, BlockIdentifier loopBlock)
/* 182:    */   {
/* 183:176 */     Statement statement = oldEnd.getStatement();
/* 184:177 */     Class<?> clazz = statement.getClass();
/* 185:178 */     if (clazz == WhileStatement.class)
/* 186:    */     {
/* 187:179 */       WhileStatement whileStatement = (WhileStatement)statement;
/* 188:180 */       ConditionalExpression condition = whileStatement.getCondition();
/* 189:181 */       if (oldEnd.getTargets().size() == 2)
/* 190:    */       {
/* 191:182 */         IfStatement repl = new IfStatement(condition);
/* 192:183 */         repl.setKnownBlocks(loopBlock, null);
/* 193:184 */         repl.setJumpType(JumpType.CONTINUE);
/* 194:185 */         oldEnd.replaceStatement(repl);
/* 195:186 */         if (oldEnd.getThisComparisonBlock() == loopBlock) {
/* 196:187 */           oldEnd.clearThisComparisonBlock();
/* 197:    */         }
/* 198:189 */         return;
/* 199:    */       }
/* 200:190 */       if ((oldEnd.getTargets().size() == 1) && (condition == null))
/* 201:    */       {
/* 202:191 */         GotoStatement repl = new GotoStatement();
/* 203:192 */         repl.setJumpType(JumpType.CONTINUE);
/* 204:193 */         oldEnd.replaceStatement(repl);
/* 205:194 */         if (oldEnd.getThisComparisonBlock() == loopBlock) {
/* 206:195 */           oldEnd.clearThisComparisonBlock();
/* 207:    */         }
/* 208:197 */         return;
/* 209:    */       }
/* 210:    */     }
/* 211:    */   }
/* 212:    */   
/* 213:    */   private static boolean considerAsPathologicalLoop(Op03SimpleStatement start, List<Op03SimpleStatement> statements)
/* 214:    */   {
/* 215:207 */     if (start.getStatement().getClass() != GotoStatement.class) {
/* 216:207 */       return false;
/* 217:    */     }
/* 218:208 */     if (start.getTargets().get(0) != start) {
/* 219:208 */       return false;
/* 220:    */     }
/* 221:209 */     Op03SimpleStatement next = new Op03SimpleStatement(start.getBlockIdentifiers(), new GotoStatement(), start.getIndex().justAfter());
/* 222:210 */     start.replaceStatement(new CommentStatement("Infinite loop"));
/* 223:211 */     start.replaceTarget(start, next);
/* 224:212 */     start.replaceSource(start, next);
/* 225:213 */     next.addSource(start);
/* 226:214 */     next.addTarget(start);
/* 227:215 */     statements.add(statements.indexOf(start) + 1, next);
/* 228:216 */     return true;
/* 229:    */   }
/* 230:    */   
/* 231:    */   private static BlockIdentifier considerAsDoLoopStart(Op03SimpleStatement start, List<Op03SimpleStatement> statements, BlockIdentifierFactory blockIdentifierFactory, Map<BlockIdentifier, Op03SimpleStatement> postBlockCache)
/* 232:    */   {
/* 233:223 */     InstrIndex startIndex = start.getIndex();
/* 234:224 */     List<Op03SimpleStatement> backJumpSources = start.getSources();
/* 235:225 */     if (backJumpSources.isEmpty()) {
/* 236:226 */       throw new ConfusedCFRException("Node doesn't have ANY sources! " + start);
/* 237:    */     }
/* 238:228 */     backJumpSources = Functional.filter(backJumpSources, new Predicate()
/* 239:    */     {
/* 240:    */       public boolean test(Op03SimpleStatement in)
/* 241:    */       {
/* 242:231 */         return in.getIndex().compareTo(this.val$startIndex) >= 0;
/* 243:    */       }
/* 244:233 */     });
/* 245:234 */     Collections.sort(backJumpSources, new CompareByIndex());
/* 246:235 */     if (backJumpSources.isEmpty()) {
/* 247:236 */       throw new ConfusedCFRException("Node should have back jump sources.");
/* 248:    */     }
/* 249:238 */     int lastJumpIdx = backJumpSources.size() - 1;
/* 250:239 */     Op03SimpleStatement lastJump = (Op03SimpleStatement)backJumpSources.get(lastJumpIdx);
/* 251:240 */     boolean conditional = false;
/* 252:241 */     boolean wasConditional = false;
/* 253:242 */     if ((lastJump.getStatement() instanceof IfStatement))
/* 254:    */     {
/* 255:243 */       conditional = true;
/* 256:244 */       wasConditional = true;
/* 257:245 */       IfStatement ifStatement = (IfStatement)lastJump.getStatement();
/* 258:246 */       if (ifStatement.getJumpTarget().getContainer() != start) {
/* 259:247 */         return null;
/* 260:    */       }
/* 261:253 */       for (int x = 0; x < lastJumpIdx; x++)
/* 262:    */       {
/* 263:254 */         Op03SimpleStatement prevJump = (Op03SimpleStatement)backJumpSources.get(x);
/* 264:255 */         Statement prevJumpStatement = prevJump.getStatement();
/* 265:256 */         if (prevJumpStatement.getClass() == GotoStatement.class)
/* 266:    */         {
/* 267:257 */           conditional = false;
/* 268:258 */           break;
/* 269:    */         }
/* 270:    */       }
/* 271:    */     }
/* 272:264 */     int startIdx = statements.indexOf(start);
/* 273:265 */     int endIdx = statements.indexOf(lastJump);
/* 274:267 */     if (startIdx >= endIdx) {
/* 275:267 */       return null;
/* 276:    */     }
/* 277:269 */     BlockIdentifier blockIdentifier = blockIdentifierFactory.getNextBlockIdentifier(conditional ? BlockType.DOLOOP : BlockType.UNCONDITIONALDOLOOP);
/* 278:    */     try
/* 279:    */     {
/* 280:276 */       validateAndAssignLoopIdentifier(statements, startIdx, endIdx + 1, blockIdentifier, start);
/* 281:    */     }
/* 282:    */     catch (CannotPerformDecode e)
/* 283:    */     {
/* 284:279 */       return null;
/* 285:    */     }
/* 286:285 */     Op03SimpleStatement doStatement = new Op03SimpleStatement(start.getBlockIdentifiers(), new DoStatement(blockIdentifier), start.getIndex().justBefore());
/* 287:286 */     doStatement.getBlockIdentifiers().remove(blockIdentifier);
/* 288:    */     
/* 289:    */ 
/* 290:289 */     List<Op03SimpleStatement> startSources = ListFactory.newList(start.getSources());
/* 291:290 */     for (Op03SimpleStatement source : startSources) {
/* 292:291 */       if (!source.getBlockIdentifiers().contains(blockIdentifier))
/* 293:    */       {
/* 294:292 */         source.replaceTarget(start, doStatement);
/* 295:293 */         start.removeSource(source);
/* 296:294 */         doStatement.addSource(source);
/* 297:    */       }
/* 298:    */     }
/* 299:297 */     doStatement.addTarget(start);
/* 300:298 */     start.addSource(doStatement);
/* 301:    */     Op03SimpleStatement postBlock;
/* 302:    */     Op03SimpleStatement postBlock;
/* 303:300 */     if (conditional)
/* 304:    */     {
/* 305:301 */       postBlock = (Op03SimpleStatement)lastJump.getTargets().get(0);
/* 306:    */     }
/* 307:    */     else
/* 308:    */     {
/* 309:307 */       if (wasConditional)
/* 310:    */       {
/* 311:310 */         IfStatement ifStatement = (IfStatement)lastJump.getStatement();
/* 312:311 */         ifStatement.negateCondition();
/* 313:312 */         ifStatement.setJumpType(JumpType.BREAK);
/* 314:313 */         Op03SimpleStatement oldFallthrough = (Op03SimpleStatement)lastJump.getTargets().get(0);
/* 315:314 */         Op03SimpleStatement oldTaken = (Op03SimpleStatement)lastJump.getTargets().get(1);
/* 316:    */         
/* 317:316 */         Op03SimpleStatement newBackJump = new Op03SimpleStatement(lastJump.getBlockIdentifiers(), new GotoStatement(), lastJump.getIndex().justAfter());
/* 318:    */         
/* 319:318 */         lastJump.getTargets().set(0, newBackJump);
/* 320:319 */         lastJump.getTargets().set(1, oldFallthrough);
/* 321:320 */         oldTaken.replaceSource(lastJump, newBackJump);
/* 322:321 */         newBackJump.addSource(lastJump);
/* 323:322 */         newBackJump.addTarget(oldTaken);
/* 324:323 */         statements.add(statements.indexOf(oldFallthrough), newBackJump);
/* 325:324 */         lastJump = newBackJump;
/* 326:    */       }
/* 327:327 */       int newIdx = statements.indexOf(lastJump) + 1;
/* 328:329 */       if (newIdx >= statements.size())
/* 329:    */       {
/* 330:330 */         Op03SimpleStatement postBlock = new Op03SimpleStatement(SetFactory.newSet(), new ReturnNothingStatement(), lastJump.getIndex().justAfter());
/* 331:331 */         statements.add(postBlock);
/* 332:    */       }
/* 333:    */       else
/* 334:    */       {
/* 335:336 */         postBlock = (Op03SimpleStatement)statements.get(newIdx);
/* 336:    */       }
/* 337:    */     }
/* 338:340 */     if (start.getFirstStatementInThisBlock() != null)
/* 339:    */     {
/* 340:344 */       BlockIdentifier outer = Misc.findOuterBlock(start.getFirstStatementInThisBlock(), blockIdentifier, statements);
/* 341:345 */       if (blockIdentifier == outer) {
/* 342:347 */         throw new UnsupportedOperationException();
/* 343:    */       }
/* 344:351 */       doStatement.setFirstStatementInThisBlock(start.getFirstStatementInThisBlock());
/* 345:352 */       start.setFirstStatementInThisBlock(blockIdentifier);
/* 346:    */     }
/* 347:364 */     if (!conditional)
/* 348:    */     {
/* 349:365 */       Set<BlockIdentifier> lastContent = SetFactory.newSet(lastJump.getBlockIdentifiers());
/* 350:366 */       lastContent.removeAll(start.getBlockIdentifiers());
/* 351:367 */       Set<BlockIdentifier> internalTryBlocks = SetFactory.newOrderedSet(Functional.filterSet(lastContent, new Predicate()
/* 352:    */       {
/* 353:    */         public boolean test(BlockIdentifier in)
/* 354:    */         {
/* 355:370 */           return in.getBlockType() == BlockType.TRYBLOCK;
/* 356:    */         }
/* 357:    */       }));
/* 358:374 */       if (!internalTryBlocks.isEmpty())
/* 359:    */       {
/* 360:376 */         int postBlockIdx = statements.indexOf(postBlock);
/* 361:377 */         int lastPostBlock = postBlockIdx;
/* 362:380 */         while (lastPostBlock + 1 < statements.size())
/* 363:    */         {
/* 364:382 */           int currentIdx = lastPostBlock + 1;
/* 365:383 */           Op03SimpleStatement stm = (Op03SimpleStatement)statements.get(lastPostBlock);
/* 366:384 */           if (!(stm.getStatement() instanceof CatchStatement)) {
/* 367:    */             break;
/* 368:    */           }
/* 369:386 */           CatchStatement catchStatement = (CatchStatement)stm.getStatement();
/* 370:387 */           BlockIdentifier catchBlockIdent = catchStatement.getCatchBlockIdent();
/* 371:388 */           List<BlockIdentifier> tryBlocks = Functional.map(catchStatement.getExceptions(), new UnaryFunction()
/* 372:    */           {
/* 373:    */             public BlockIdentifier invoke(ExceptionGroup.Entry arg)
/* 374:    */             {
/* 375:391 */               return arg.getTryBlockIdentifier();
/* 376:    */             }
/* 377:    */           });
/* 378:394 */           if (!internalTryBlocks.containsAll(tryBlocks)) {
/* 379:    */             break;
/* 380:    */           }
/* 381:395 */           while ((currentIdx < statements.size() - 1) && (((Op03SimpleStatement)statements.get(currentIdx)).getBlockIdentifiers().contains(catchBlockIdent))) {
/* 382:396 */             currentIdx++;
/* 383:    */           }
/* 384:398 */           lastPostBlock = currentIdx;
/* 385:    */         }
/* 386:400 */         if (lastPostBlock != postBlockIdx)
/* 387:    */         {
/* 388:402 */           if (!lastJump.getTargets().contains(start)) {
/* 389:403 */             throw new ConfusedCFRException("Nonsensical loop would be emitted - failure");
/* 390:    */           }
/* 391:405 */           Op03SimpleStatement afterNewJump = (Op03SimpleStatement)statements.get(lastPostBlock);
/* 392:    */           
/* 393:    */ 
/* 394:    */ 
/* 395:    */ 
/* 396:410 */           Op03SimpleStatement newBackJump = new Op03SimpleStatement(afterNewJump.getBlockIdentifiers(), new GotoStatement(), afterNewJump.getIndex().justBefore());
/* 397:411 */           newBackJump.addTarget(start);
/* 398:412 */           newBackJump.addSource(lastJump);
/* 399:413 */           lastJump.replaceTarget(start, newBackJump);
/* 400:414 */           start.replaceSource(lastJump, newBackJump);
/* 401:    */           
/* 402:    */ 
/* 403:    */ 
/* 404:    */ 
/* 405:419 */           Op03SimpleStatement preNewJump = (Op03SimpleStatement)statements.get(lastPostBlock - 1);
/* 406:420 */           if (afterNewJump.getSources().contains(preNewJump))
/* 407:    */           {
/* 408:421 */             Op03SimpleStatement interstit = new Op03SimpleStatement(preNewJump.getBlockIdentifiers(), new GotoStatement(), newBackJump.getIndex().justBefore());
/* 409:422 */             preNewJump.replaceTarget(afterNewJump, interstit);
/* 410:423 */             afterNewJump.replaceSource(preNewJump, interstit);
/* 411:424 */             interstit.addSource(preNewJump);
/* 412:425 */             interstit.addTarget(afterNewJump);
/* 413:426 */             statements.add(lastPostBlock, interstit);
/* 414:427 */             lastPostBlock++;
/* 415:    */           }
/* 416:430 */           statements.add(lastPostBlock, newBackJump);
/* 417:431 */           lastJump = newBackJump;
/* 418:432 */           postBlock = afterNewJump;
/* 419:436 */           for (int idx = postBlockIdx; idx <= lastPostBlock; idx++) {
/* 420:437 */             ((Op03SimpleStatement)statements.get(idx)).markBlock(blockIdentifier);
/* 421:    */           }
/* 422:    */         }
/* 423:    */       }
/* 424:    */     }
/* 425:442 */     statements.add(statements.indexOf(start), doStatement);
/* 426:443 */     lastJump.markBlockStatement(blockIdentifier, null, lastJump, statements);
/* 427:444 */     start.markFirstStatementInBlock(blockIdentifier);
/* 428:    */     
/* 429:    */ 
/* 430:447 */     postBlockCache.put(blockIdentifier, postBlock);
/* 431:    */     
/* 432:449 */     return blockIdentifier;
/* 433:    */   }
/* 434:    */   
/* 435:    */   private static BlockIdentifier considerAsWhileLoopStart(Method method, Op03SimpleStatement start, List<Op03SimpleStatement> statements, BlockIdentifierFactory blockIdentifierFactory, Map<BlockIdentifier, Op03SimpleStatement> postBlockCache)
/* 436:    */   {
/* 437:463 */     InstrIndex startIndex = start.getIndex();
/* 438:464 */     List<Op03SimpleStatement> backJumpSources = start.getSources();
/* 439:465 */     backJumpSources = Functional.filter(backJumpSources, new Predicate()
/* 440:    */     {
/* 441:    */       public boolean test(Op03SimpleStatement in)
/* 442:    */       {
/* 443:468 */         return in.getIndex().compareTo(this.val$startIndex) >= 0;
/* 444:    */       }
/* 445:470 */     });
/* 446:471 */     Collections.sort(backJumpSources, new CompareByIndex());
/* 447:472 */     Op03SimpleStatement conditional = findFirstConditional(start);
/* 448:473 */     if (conditional == null) {
/* 449:475 */       return null;
/* 450:    */     }
/* 451:480 */     Op03SimpleStatement lastJump = (Op03SimpleStatement)backJumpSources.get(backJumpSources.size() - 1);
/* 452:    */     
/* 453:    */ 
/* 454:    */ 
/* 455:484 */     List<Op03SimpleStatement> conditionalTargets = conditional.getTargets();
/* 456:    */     
/* 457:    */ 
/* 458:    */ 
/* 459:    */ 
/* 460:    */ 
/* 461:    */ 
/* 462:    */ 
/* 463:    */ 
/* 464:    */ 
/* 465:494 */     Op03SimpleStatement loopBreak = (Op03SimpleStatement)conditionalTargets.get(1);
/* 466:506 */     if ((loopBreak == conditional) && (start == conditional))
/* 467:    */     {
/* 468:508 */       Statement stm = conditional.getStatement();
/* 469:509 */       if (!(stm instanceof IfStatement)) {
/* 470:509 */         return null;
/* 471:    */       }
/* 472:510 */       IfStatement ifStatement = (IfStatement)stm;
/* 473:511 */       ifStatement.negateCondition();
/* 474:    */       
/* 475:513 */       Op03SimpleStatement backJump = new Op03SimpleStatement(conditional.getBlockIdentifiers(), new GotoStatement(), conditional.getIndex().justAfter());
/* 476:514 */       Op03SimpleStatement notTaken = (Op03SimpleStatement)conditional.getTargets().get(0);
/* 477:515 */       conditional.replaceTarget(notTaken, backJump);
/* 478:516 */       conditional.replaceSource(conditional, backJump);
/* 479:517 */       conditional.replaceTarget(conditional, notTaken);
/* 480:518 */       backJump.addSource(conditional);
/* 481:519 */       backJump.addTarget(conditional);
/* 482:520 */       statements.add(statements.indexOf(conditional) + 1, backJump);
/* 483:521 */       conditionalTargets = conditional.getTargets();
/* 484:522 */       loopBreak = notTaken;
/* 485:    */     }
/* 486:525 */     if (loopBreak.getIndex().compareTo(lastJump.getIndex()) <= 0) {
/* 487:528 */       if (loopBreak.getIndex().compareTo(startIndex) >= 0) {
/* 488:529 */         return null;
/* 489:    */       }
/* 490:    */     }
/* 491:533 */     if (start != conditional) {
/* 492:535 */       return null;
/* 493:    */     }
/* 494:537 */     int idxConditional = statements.indexOf(start);
/* 495:    */     
/* 496:    */ 
/* 497:    */ 
/* 498:    */ 
/* 499:    */ 
/* 500:    */ 
/* 501:    */ 
/* 502:    */ 
/* 503:    */ 
/* 504:    */ 
/* 505:    */ 
/* 506:    */ 
/* 507:550 */     int idxAfterEnd = statements.indexOf(loopBreak);
/* 508:551 */     if (idxAfterEnd < idxConditional)
/* 509:    */     {
/* 510:561 */       Op03SimpleStatement startOfOuterLoop = (Op03SimpleStatement)statements.get(idxAfterEnd);
/* 511:562 */       if (startOfOuterLoop.getThisComparisonBlock() == null) {
/* 512:564 */         return null;
/* 513:    */       }
/* 514:567 */       Op03SimpleStatement endOfOuter = (Op03SimpleStatement)postBlockCache.get(startOfOuterLoop.getThisComparisonBlock());
/* 515:568 */       if (endOfOuter == null) {
/* 516:569 */         throw new ConfusedCFRException("BlockIdentifier doesn't exist in blockEndsCache");
/* 517:    */       }
/* 518:571 */       idxAfterEnd = statements.indexOf(endOfOuter);
/* 519:    */     }
/* 520:576 */     if (idxConditional >= idxAfterEnd) {
/* 521:578 */       return null;
/* 522:    */     }
/* 523:580 */     BlockIdentifier blockIdentifier = blockIdentifierFactory.getNextBlockIdentifier(BlockType.WHILELOOP);
/* 524:    */     int lastIdx;
/* 525:    */     try
/* 526:    */     {
/* 527:588 */       lastIdx = validateAndAssignLoopIdentifier(statements, idxConditional + 1, idxAfterEnd, blockIdentifier, start);
/* 528:    */     }
/* 529:    */     catch (CannotPerformDecode e)
/* 530:    */     {
/* 531:590 */       return null;
/* 532:    */     }
/* 533:593 */     Op03SimpleStatement lastInBlock = (Op03SimpleStatement)statements.get(lastIdx);
/* 534:594 */     Op03SimpleStatement blockEnd = (Op03SimpleStatement)statements.get(idxAfterEnd);
/* 535:    */     
/* 536:596 */     start.markBlockStatement(blockIdentifier, lastInBlock, blockEnd, statements);
/* 537:597 */     ((Op03SimpleStatement)statements.get(idxConditional + 1)).markFirstStatementInBlock(blockIdentifier);
/* 538:598 */     postBlockCache.put(blockIdentifier, blockEnd);
/* 539:600 */     if ((lastInBlock.getStatement().fallsToNext()) && (lastInBlock.getTargets().size() == 1))
/* 540:    */     {
/* 541:601 */       Op03SimpleStatement afterFallThrough = new Op03SimpleStatement(lastInBlock.getBlockIdentifiers(), new GotoStatement(), lastInBlock.getIndex().justAfter());
/* 542:    */       
/* 543:    */ 
/* 544:604 */       SwitchUtils.checkFixNewCase(afterFallThrough, lastInBlock);
/* 545:605 */       Op03SimpleStatement tgt = (Op03SimpleStatement)lastInBlock.getTargets().get(0);
/* 546:606 */       lastInBlock.replaceTarget(tgt, afterFallThrough);
/* 547:607 */       tgt.replaceSource(lastInBlock, afterFallThrough);
/* 548:608 */       afterFallThrough.addSource(lastInBlock);
/* 549:609 */       afterFallThrough.addTarget(tgt);
/* 550:610 */       statements.add(afterFallThrough);
/* 551:611 */       lastInBlock = afterFallThrough;
/* 552:    */     }
/* 553:617 */     Op03SimpleStatement afterLastInBlock = lastIdx + 1 < statements.size() ? (Op03SimpleStatement)statements.get(lastIdx + 1) : null;
/* 554:618 */     loopBreak = (Op03SimpleStatement)conditional.getTargets().get(1);
/* 555:619 */     if (afterLastInBlock != loopBreak)
/* 556:    */     {
/* 557:620 */       Op03SimpleStatement newAfterLast = new Op03SimpleStatement(afterLastInBlock.getBlockIdentifiers(), new GotoStatement(), lastInBlock.getIndex().justAfter());
/* 558:621 */       conditional.replaceTarget(loopBreak, newAfterLast);
/* 559:622 */       newAfterLast.addSource(conditional);
/* 560:623 */       loopBreak.replaceSource(conditional, newAfterLast);
/* 561:624 */       newAfterLast.addTarget(loopBreak);
/* 562:625 */       statements.add(newAfterLast);
/* 563:    */     }
/* 564:628 */     return blockIdentifier;
/* 565:    */   }
/* 566:    */   
/* 567:    */   private static Op03SimpleStatement findFirstConditional(Op03SimpleStatement start)
/* 568:    */   {
/* 569:633 */     Set<Op03SimpleStatement> visited = SetFactory.newSet();
/* 570:    */     do
/* 571:    */     {
/* 572:635 */       Statement innerStatement = start.getStatement();
/* 573:636 */       if ((innerStatement instanceof IfStatement)) {
/* 574:637 */         return start;
/* 575:    */       }
/* 576:639 */       List<Op03SimpleStatement> targets = start.getTargets();
/* 577:640 */       if (targets.size() != 1) {
/* 578:640 */         return null;
/* 579:    */       }
/* 580:641 */       start = (Op03SimpleStatement)targets.get(0);
/* 581:642 */       if (visited.contains(start)) {
/* 582:643 */         return null;
/* 583:    */       }
/* 584:645 */       visited.add(start);
/* 585:646 */     } while (start != null);
/* 586:647 */     return null;
/* 587:    */   }
/* 588:    */   
/* 589:    */   private static int validateAndAssignLoopIdentifier(List<Op03SimpleStatement> statements, int idxTestStart, int idxAfterEnd, BlockIdentifier blockIdentifier, Op03SimpleStatement start)
/* 590:    */   {
/* 591:655 */     int last = Misc.getFarthestReachableInRange(statements, idxTestStart, idxAfterEnd);
/* 592:    */     
/* 593:    */ 
/* 594:    */ 
/* 595:    */ 
/* 596:    */ 
/* 597:    */ 
/* 598:662 */     Op03SimpleStatement discoveredLast = (Op03SimpleStatement)statements.get(last);
/* 599:663 */     Set<BlockIdentifier> lastBlocks = SetFactory.newSet(discoveredLast.getBlockIdentifiers());
/* 600:664 */     lastBlocks.removeAll(start.getBlockIdentifiers());
/* 601:665 */     Set<BlockIdentifier> catches = SetFactory.newSet(Functional.filterSet(lastBlocks, new Predicate()
/* 602:    */     {
/* 603:    */       public boolean test(BlockIdentifier in)
/* 604:    */       {
/* 605:668 */         BlockType type = in.getBlockType();
/* 606:669 */         return (type == BlockType.CATCHBLOCK) || (type == BlockType.SWITCH);
/* 607:    */       }
/* 608:672 */     }));
/* 609:673 */     int newlast = last;
/* 610:674 */     while (!catches.isEmpty())
/* 611:    */     {
/* 612:678 */       Op03SimpleStatement stm = (Op03SimpleStatement)statements.get(newlast);
/* 613:679 */       catches.retainAll(stm.getBlockIdentifiers());
/* 614:680 */       if (catches.isEmpty()) {
/* 615:    */         break;
/* 616:    */       }
/* 617:683 */       last = newlast;
/* 618:684 */       if (newlast >= statements.size() - 1) {
/* 619:    */         break;
/* 620:    */       }
/* 621:685 */       newlast++;
/* 622:    */     }
/* 623:692 */     for (int x = idxTestStart; x <= last; x++) {
/* 624:693 */       ((Op03SimpleStatement)statements.get(x)).markBlock(blockIdentifier);
/* 625:    */     }
/* 626:695 */     return last;
/* 627:    */   }
/* 628:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier
 * JD-Core Version:    0.7.0.1
 */