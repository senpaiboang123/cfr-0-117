/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Map;
/*   5:    */ import java.util.Map.Entry;
/*   6:    */ import java.util.Set;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.MemberFunctionInvokation;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.AssignmentSimple;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ExpressionStatement;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.types.GenericTypeBinder;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericBaseInstance;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericPlaceholderTypeInstance;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  19:    */ import org.benf.cfr.reader.util.Functional;
/*  20:    */ import org.benf.cfr.reader.util.ListFactory;
/*  21:    */ import org.benf.cfr.reader.util.MapFactory;
/*  22:    */ import org.benf.cfr.reader.util.SetFactory;
/*  23:    */ import org.benf.cfr.reader.util.SetUtil;
/*  24:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  25:    */ 
/*  26:    */ public class GenericInferer
/*  27:    */ {
/*  28:    */   private static class GenericInferData
/*  29:    */   {
/*  30:    */     GenericTypeBinder binder;
/*  31:    */     Set<JavaGenericPlaceholderTypeInstance> nullPlaceholders;
/*  32:    */     
/*  33:    */     private GenericInferData(GenericTypeBinder binder, Set<JavaGenericPlaceholderTypeInstance> nullPlaceholders)
/*  34:    */     {
/*  35: 27 */       this.binder = binder;
/*  36: 28 */       this.nullPlaceholders = nullPlaceholders;
/*  37:    */     }
/*  38:    */     
/*  39:    */     private GenericInferData(GenericTypeBinder binder)
/*  40:    */     {
/*  41: 32 */       this.binder = binder;
/*  42: 33 */       this.nullPlaceholders = null;
/*  43:    */     }
/*  44:    */     
/*  45:    */     public boolean isValid()
/*  46:    */     {
/*  47: 37 */       return this.binder != null;
/*  48:    */     }
/*  49:    */     
/*  50:    */     public GenericInferData mergeWith(GenericInferData other)
/*  51:    */     {
/*  52: 41 */       if (!isValid()) {
/*  53: 41 */         return this;
/*  54:    */       }
/*  55: 42 */       if (!other.isValid()) {
/*  56: 42 */         return other;
/*  57:    */       }
/*  58: 44 */       GenericTypeBinder newBinder = this.binder.mergeWith(other.binder, true);
/*  59: 45 */       if (newBinder == null) {
/*  60: 45 */         return new GenericInferData(null);
/*  61:    */       }
/*  62: 47 */       Set<JavaGenericPlaceholderTypeInstance> newNullPlaceHolders = SetUtil.originalIntersectionOrNull(this.nullPlaceholders, other.nullPlaceholders);
/*  63: 48 */       return new GenericInferData(newBinder, newNullPlaceHolders);
/*  64:    */     }
/*  65:    */     
/*  66:    */     public GenericTypeBinder getTypeBinder()
/*  67:    */     {
/*  68: 56 */       if ((this.nullPlaceholders != null) && (!this.nullPlaceholders.isEmpty())) {
/*  69: 57 */         for (JavaGenericPlaceholderTypeInstance onlyNull : this.nullPlaceholders) {
/*  70: 58 */           this.binder.suggestOnlyNullBinding(onlyNull);
/*  71:    */         }
/*  72:    */       }
/*  73: 61 */       return this.binder;
/*  74:    */     }
/*  75:    */   }
/*  76:    */   
/*  77:    */   static GenericInferData getGtbNullFiltered(MemberFunctionInvokation m)
/*  78:    */   {
/*  79: 66 */     List<Expression> args = m.getArgs();
/*  80: 67 */     GenericTypeBinder res = m.getMethodPrototype().getTypeBinderFor(args);
/*  81: 68 */     List<Boolean> nulls = m.getNulls();
/*  82: 69 */     if (args.size() != nulls.size()) {
/*  83: 69 */       return new GenericInferData(res, null);
/*  84:    */     }
/*  85: 70 */     boolean found = false;
/*  86: 71 */     for (Boolean b : nulls) {
/*  87: 72 */       if (b.booleanValue())
/*  88:    */       {
/*  89: 72 */         found = true; break;
/*  90:    */       }
/*  91:    */     }
/*  92: 74 */     if (!found) {
/*  93: 74 */       return new GenericInferData(res, null);
/*  94:    */     }
/*  95: 80 */     Set<JavaGenericPlaceholderTypeInstance> nullBindings = null;
/*  96: 81 */     int x = 0;
/*  97: 81 */     for (int len = args.size(); x < len; x++) {
/*  98: 82 */       if (((Boolean)nulls.get(x)).booleanValue())
/*  99:    */       {
/* 100: 83 */         JavaTypeInstance t = ((Expression)args.get(x)).getInferredJavaType().getJavaTypeInstance();
/* 101: 84 */         if ((t instanceof JavaGenericPlaceholderTypeInstance))
/* 102:    */         {
/* 103: 85 */           JavaGenericPlaceholderTypeInstance placeholder = (JavaGenericPlaceholderTypeInstance)t;
/* 104: 86 */           JavaTypeInstance t2 = res.getBindingFor(placeholder);
/* 105: 87 */           if (t2.equals(placeholder))
/* 106:    */           {
/* 107: 88 */             if (nullBindings == null) {
/* 108: 88 */               nullBindings = SetFactory.newSet();
/* 109:    */             }
/* 110: 89 */             res.removeBinding(placeholder);
/* 111: 90 */             nullBindings.add(placeholder);
/* 112:    */           }
/* 113:    */         }
/* 114:    */       }
/* 115:    */     }
/* 116: 95 */     return new GenericInferData(res, nullBindings, null);
/* 117:    */   }
/* 118:    */   
/* 119:    */   public static void inferGenericObjectInfoFromCalls(List<Op03SimpleStatement> statements)
/* 120:    */   {
/* 121:100 */     List<MemberFunctionInvokation> memberFunctionInvokations = ListFactory.newList();
/* 122:101 */     for (Op03SimpleStatement statement : statements)
/* 123:    */     {
/* 124:102 */       Statement contained = statement.getStatement();
/* 125:103 */       if ((contained instanceof ExpressionStatement))
/* 126:    */       {
/* 127:104 */         Expression e = ((ExpressionStatement)contained).getExpression();
/* 128:105 */         if ((e instanceof MemberFunctionInvokation)) {
/* 129:106 */           memberFunctionInvokations.add((MemberFunctionInvokation)e);
/* 130:    */         }
/* 131:    */       }
/* 132:108 */       else if ((contained instanceof AssignmentSimple))
/* 133:    */       {
/* 134:109 */         Expression e = ((AssignmentSimple)contained).getRValue();
/* 135:110 */         if ((e instanceof MemberFunctionInvokation)) {
/* 136:111 */           memberFunctionInvokations.add((MemberFunctionInvokation)e);
/* 137:    */         }
/* 138:    */       }
/* 139:    */     }
/* 140:115 */     Map<Integer, List<MemberFunctionInvokation>> byTypKey = MapFactory.newTreeMap();
/* 141:116 */     Functional.groupToMapBy(memberFunctionInvokations, byTypKey, new UnaryFunction()
/* 142:    */     {
/* 143:    */       public Integer invoke(MemberFunctionInvokation arg)
/* 144:    */       {
/* 145:119 */         return Integer.valueOf(arg.getObject().getInferredJavaType().getLocalId());
/* 146:    */       }
/* 147:    */     });
/* 148:124 */     for (Map.Entry<Integer, List<MemberFunctionInvokation>> entry : byTypKey.entrySet())
/* 149:    */     {
/* 150:125 */       Integer key = (Integer)entry.getKey();
/* 151:126 */       List<MemberFunctionInvokation> invokations = (List)entry.getValue();
/* 152:127 */       if (!invokations.isEmpty())
/* 153:    */       {
/* 154:129 */         Expression obj0 = ((MemberFunctionInvokation)invokations.get(0)).getObject();
/* 155:130 */         JavaTypeInstance type = obj0.getInferredJavaType().getJavaTypeInstance();
/* 156:131 */         if ((type instanceof JavaGenericBaseInstance))
/* 157:    */         {
/* 158:132 */           JavaGenericBaseInstance genericType = (JavaGenericBaseInstance)type;
/* 159:133 */           if (genericType.hasUnbound())
/* 160:    */           {
/* 161:135 */             GenericInferData inferData = getGtbNullFiltered((MemberFunctionInvokation)invokations.get(0));
/* 162:136 */             if (inferData.isValid())
/* 163:    */             {
/* 164:137 */               int x = 1;
/* 165:137 */               for (int len = invokations.size();; x++)
/* 166:    */               {
/* 167:137 */                 if (x >= len) {
/* 168:    */                   break label352;
/* 169:    */                 }
/* 170:138 */                 GenericInferData inferData1 = getGtbNullFiltered((MemberFunctionInvokation)invokations.get(x));
/* 171:139 */                 inferData = inferData.mergeWith(inferData1);
/* 172:140 */                 if (!inferData.isValid()) {
/* 173:    */                   break;
/* 174:    */                 }
/* 175:    */               }
/* 176:144 */               GenericTypeBinder typeBinder = inferData.getTypeBinder();
/* 177:145 */               obj0.getInferredJavaType().deGenerify(typeBinder.getBindingFor(obj0.getInferredJavaType().getJavaTypeInstance()));
/* 178:    */             }
/* 179:    */           }
/* 180:    */         }
/* 181:    */       }
/* 182:    */     }
/* 183:    */     label352:
/* 184:    */   }
/* 185:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.GenericInferer
 * JD-Core Version:    0.7.0.1
 */