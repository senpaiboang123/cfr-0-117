/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*  2:   */ 
/*  3:   */ import java.util.Map;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.AbstractExpressionRewriter;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  9:   */ 
/* 10:   */ public class LValueReplacingRewriter
/* 11:   */   extends AbstractExpressionRewriter
/* 12:   */ {
/* 13:   */   private final Map<LValue, LValue> replacements;
/* 14:   */   
/* 15:   */   public LValueReplacingRewriter(Map<LValue, LValue> replacements)
/* 16:   */   {
/* 17:15 */     this.replacements = replacements;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 21:   */   {
/* 22:20 */     LValue replacement = (LValue)this.replacements.get(lValue);
/* 23:21 */     if (replacement != null) {
/* 24:22 */       return replacement;
/* 25:   */     }
/* 26:24 */     return lValue.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.LValueReplacingRewriter
 * JD-Core Version:    0.7.0.1
 */