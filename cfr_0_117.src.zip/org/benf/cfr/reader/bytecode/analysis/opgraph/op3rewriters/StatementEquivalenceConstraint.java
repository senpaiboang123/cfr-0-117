/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.ComparableUnderEC;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.DefaultEquivalenceConstraint;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdent;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  9:   */ 
/* 10:   */ public class StatementEquivalenceConstraint
/* 11:   */   extends DefaultEquivalenceConstraint
/* 12:   */ {
/* 13:   */   private final SSAIdentifiers<LValue> ident1;
/* 14:   */   private final SSAIdentifiers<LValue> ident2;
/* 15:   */   
/* 16:   */   public StatementEquivalenceConstraint(Op03SimpleStatement stm1, Op03SimpleStatement stm2)
/* 17:   */   {
/* 18:16 */     this.ident1 = stm1.getSSAIdentifiers();
/* 19:17 */     this.ident2 = stm2.getSSAIdentifiers();
/* 20:   */   }
/* 21:   */   
/* 22:   */   public boolean equivalent(ComparableUnderEC o1, ComparableUnderEC o2)
/* 23:   */   {
/* 24:22 */     if (((o1 instanceof LValue)) && ((o2 instanceof LValue)))
/* 25:   */     {
/* 26:23 */       SSAIdent i1 = this.ident1.getSSAIdentOnEntry((LValue)o1);
/* 27:24 */       SSAIdent i2 = this.ident2.getSSAIdentOnEntry((LValue)o2);
/* 28:25 */       if (i1 == null)
/* 29:   */       {
/* 30:26 */         if (i2 != null) {
/* 31:26 */           return false;
/* 32:   */         }
/* 33:   */       }
/* 34:28 */       else if (!i1.equals(i2)) {
/* 35:28 */         return false;
/* 36:   */       }
/* 37:   */     }
/* 38:31 */     return super.equivalent(o1, o2);
/* 39:   */   }
/* 40:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.StatementEquivalenceConstraint
 * JD-Core Version:    0.7.0.1
 */