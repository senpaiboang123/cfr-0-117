/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Map;
/*   5:    */ import java.util.Map.Entry;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractAssignmentExpression;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.AbstractExpressionRewriter;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ForIterStatement;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaArrayTypeInstance;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaWildcardTypeInstance;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.types.TypeConstants;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  23:    */ import org.benf.cfr.reader.entities.Method;
/*  24:    */ import org.benf.cfr.reader.util.MapFactory;
/*  25:    */ 
/*  26:    */ public class NarrowingTypeRewriter
/*  27:    */ {
/*  28: 32 */   public static final JavaTypeInstance BAD_SENTINEL = new JavaWildcardTypeInstance(null, null);
/*  29:    */   
/*  30:    */   private static JavaTypeInstance getListType(Expression e)
/*  31:    */   {
/*  32: 35 */     if (e == null) {
/*  33: 35 */       return BAD_SENTINEL;
/*  34:    */     }
/*  35: 36 */     JavaTypeInstance listtype = e.getInferredJavaType().getJavaTypeInstance();
/*  36: 37 */     if ((listtype instanceof JavaArrayTypeInstance)) {
/*  37: 38 */       return listtype.removeAnArrayIndirection();
/*  38:    */     }
/*  39: 40 */     return BAD_SENTINEL;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void rewrite(Method method, List<Op03SimpleStatement> statements)
/*  43:    */   {
/*  44: 44 */     LValueAssignmentCollector collector = new LValueAssignmentCollector(null);
/*  45: 46 */     for (LocalVariable lv : method.getMethodPrototype().getComputedParameters()) {
/*  46: 47 */       collector.collect(lv, BAD_SENTINEL);
/*  47:    */     }
/*  48: 50 */     for (Op03SimpleStatement statement : statements)
/*  49:    */     {
/*  50: 51 */       Statement stm = statement.getStatement();
/*  51: 52 */       LValue created = stm.getCreatedLValue();
/*  52: 53 */       if (created != null)
/*  53:    */       {
/*  54: 54 */         Expression rValue = stm.getRValue();
/*  55: 55 */         JavaTypeInstance type = rValue == null ? BAD_SENTINEL : rValue.getInferredJavaType().getJavaTypeInstance();
/*  56: 56 */         if ((stm instanceof ForIterStatement))
/*  57:    */         {
/*  58: 57 */           Expression list = ((ForIterStatement)stm).getList();
/*  59: 58 */           type = getListType(list);
/*  60:    */         }
/*  61: 60 */         collector.collect(created, type);
/*  62:    */       }
/*  63: 62 */       stm.rewriteExpressions(collector, statement.getSSAIdentifiers());
/*  64:    */     }
/*  65: 65 */     Map<LocalVariable, JavaTypeInstance> updatable = collector.getUsable();
/*  66: 66 */     for (Map.Entry<LocalVariable, JavaTypeInstance> entry : updatable.entrySet())
/*  67:    */     {
/*  68: 67 */       LocalVariable lv = (LocalVariable)entry.getKey();
/*  69: 68 */       JavaTypeInstance tgt = (JavaTypeInstance)entry.getValue();
/*  70: 69 */       InferredJavaType lvt = lv.getInferredJavaType();
/*  71: 70 */       if (lvt.getJavaTypeInstance() == TypeConstants.OBJECT) {
/*  72: 71 */         lvt.forceType(tgt, true);
/*  73:    */       }
/*  74:    */     }
/*  75:    */   }
/*  76:    */   
/*  77:    */   private static class LValueAssignmentCollector
/*  78:    */     extends AbstractExpressionRewriter
/*  79:    */   {
/*  80: 81 */     private final Map<LocalVariable, JavaTypeInstance> usable = MapFactory.newMap();
/*  81:    */     
/*  82:    */     public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  83:    */     {
/*  84: 85 */       if ((expression instanceof AbstractAssignmentExpression))
/*  85:    */       {
/*  86: 86 */         AbstractAssignmentExpression aae = (AbstractAssignmentExpression)expression;
/*  87: 87 */         LValue lValue = aae.getUpdatedLValue();
/*  88: 88 */         collect(lValue, NarrowingTypeRewriter.BAD_SENTINEL);
/*  89:    */       }
/*  90: 90 */       return super.rewriteExpression(expression, ssaIdentifiers, statementContainer, flags);
/*  91:    */     }
/*  92:    */     
/*  93:    */     public void collect(LValue lValue, JavaTypeInstance type)
/*  94:    */     {
/*  95: 94 */       if (!(lValue instanceof LocalVariable)) {
/*  96: 94 */         return;
/*  97:    */       }
/*  98: 95 */       LocalVariable lv = (LocalVariable)lValue;
/*  99: 96 */       JavaTypeInstance b = (JavaTypeInstance)this.usable.get(lv);
/* 100: 97 */       if (type == null) {
/* 101: 97 */         type = NarrowingTypeRewriter.BAD_SENTINEL;
/* 102:    */       }
/* 103: 98 */       if (b == null)
/* 104:    */       {
/* 105: 99 */         this.usable.put(lv, type);
/* 106:100 */         return;
/* 107:    */       }
/* 108:102 */       if (b != NarrowingTypeRewriter.BAD_SENTINEL) {
/* 109:103 */         this.usable.put(lv, NarrowingTypeRewriter.BAD_SENTINEL);
/* 110:    */       }
/* 111:    */     }
/* 112:    */     
/* 113:    */     public Map<LocalVariable, JavaTypeInstance> getUsable()
/* 114:    */     {
/* 115:108 */       Map<LocalVariable, JavaTypeInstance> res = MapFactory.newMap();
/* 116:109 */       for (Map.Entry<LocalVariable, JavaTypeInstance> entry : this.usable.entrySet()) {
/* 117:110 */         if (entry.getValue() != NarrowingTypeRewriter.BAD_SENTINEL) {
/* 118:111 */           res.put(entry.getKey(), entry.getValue());
/* 119:    */         }
/* 120:    */       }
/* 121:114 */       return res;
/* 122:    */     }
/* 123:    */   }
/* 124:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.NarrowingTypeRewriter
 * JD-Core Version:    0.7.0.1
 */