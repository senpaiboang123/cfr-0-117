/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractNewArray;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArrayIndex;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.NewAnonymousArray;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.StackValue;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral.LiteralType;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.ArrayVariable;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.AssignmentSimple;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.ExpressionWildcard;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.LValueWildcard;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch.NewArrayWildcard;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.stack.StackEntry;
/*  25:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  26:    */ import org.benf.cfr.reader.util.Functional;
/*  27:    */ import org.benf.cfr.reader.util.ListFactory;
/*  28:    */ import org.benf.cfr.reader.util.Predicate;
/*  29:    */ 
/*  30:    */ public class AnonymousArray
/*  31:    */ {
/*  32:    */   private static boolean resugarAnonymousArray(Op03SimpleStatement newArray, List<Op03SimpleStatement> statements)
/*  33:    */   {
/*  34: 26 */     Statement stm = newArray.getStatement();
/*  35: 27 */     if (!(stm instanceof AssignmentSimple)) {
/*  36: 28 */       return false;
/*  37:    */     }
/*  38: 30 */     AssignmentSimple assignmentSimple = (AssignmentSimple)newArray.getStatement();
/*  39: 31 */     WildcardMatch start = new WildcardMatch();
/*  40: 32 */     if (!start.match(new AssignmentSimple(start.getLValueWildCard("array"), start.getNewArrayWildCard("def")), assignmentSimple)) {
/*  41: 36 */       throw new ConfusedCFRException("Expecting new array");
/*  42:    */     }
/*  43: 41 */     LValue arrayLValue = start.getLValueWildCard("array").getMatch();
/*  44: 42 */     if ((!(arrayLValue instanceof StackSSALabel)) && (!(arrayLValue instanceof LocalVariable))) {
/*  45: 43 */       return false;
/*  46:    */     }
/*  47: 45 */     LValue array = arrayLValue;
/*  48: 46 */     AbstractNewArray arrayDef = start.getNewArrayWildCard("def").getMatch();
/*  49: 47 */     Expression dimSize0 = arrayDef.getDimSize(0);
/*  50: 48 */     if (!(dimSize0 instanceof Literal)) {
/*  51: 48 */       return false;
/*  52:    */     }
/*  53: 49 */     Literal lit = (Literal)dimSize0;
/*  54: 50 */     if (lit.getValue().getType() != TypedLiteral.LiteralType.Integer) {
/*  55: 50 */       return false;
/*  56:    */     }
/*  57: 51 */     int bound = ((Integer)lit.getValue().getValue()).intValue();
/*  58:    */     
/*  59: 53 */     Op03SimpleStatement next = newArray;
/*  60: 54 */     List<Expression> anon = ListFactory.newList();
/*  61: 55 */     List<Op03SimpleStatement> anonAssigns = ListFactory.newList();
/*  62: 56 */     Expression arrayExpression = null;
/*  63: 57 */     if ((array instanceof StackSSALabel)) {
/*  64: 58 */       arrayExpression = new StackValue((StackSSALabel)array);
/*  65:    */     } else {
/*  66: 60 */       arrayExpression = new LValueExpression(array);
/*  67:    */     }
/*  68: 62 */     for (int x = 0; x < bound; x++)
/*  69:    */     {
/*  70: 63 */       if (next.getTargets().size() != 1) {
/*  71: 64 */         return false;
/*  72:    */       }
/*  73: 66 */       next = (Op03SimpleStatement)next.getTargets().get(0);
/*  74: 67 */       WildcardMatch testAnon = new WildcardMatch();
/*  75: 68 */       Literal idx = new Literal(TypedLiteral.getInt(x));
/*  76: 69 */       if (!testAnon.match(new AssignmentSimple(new ArrayVariable(new ArrayIndex(arrayExpression, idx)), testAnon.getExpressionWildCard("val")), next.getStatement())) {
/*  77: 74 */         return false;
/*  78:    */       }
/*  79: 76 */       anon.add(testAnon.getExpressionWildCard("val").getMatch());
/*  80: 77 */       anonAssigns.add(next);
/*  81:    */     }
/*  82: 79 */     AssignmentSimple replacement = new AssignmentSimple(arrayLValue.getInferredJavaType(), assignmentSimple.getCreatedLValue(), new NewAnonymousArray(arrayDef.getInferredJavaType(), arrayDef.getNumDims(), anon, false));
/*  83: 80 */     newArray.replaceStatement(replacement);
/*  84:    */     StackEntry arrayStackEntry;
/*  85: 81 */     if ((array instanceof StackSSALabel))
/*  86:    */     {
/*  87: 82 */       arrayStackEntry = ((StackSSALabel)array).getStackEntry();
/*  88: 83 */       for (Op03SimpleStatement create : anonAssigns) {
/*  89: 84 */         arrayStackEntry.decrementUsage();
/*  90:    */       }
/*  91:    */     }
/*  92: 87 */     for (Op03SimpleStatement create : anonAssigns) {
/*  93: 88 */       create.nopOut();
/*  94:    */     }
/*  95: 90 */     return true;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public static void resugarAnonymousArrays(List<Op03SimpleStatement> statements)
/*  99:    */   {
/* 100:109 */     boolean success = false;
/* 101:    */     do
/* 102:    */     {
/* 103:111 */       List<Op03SimpleStatement> assignments = Functional.filter(statements, new TypeFilter(AssignmentSimple.class));
/* 104:    */       
/* 105:113 */       assignments = Functional.filter(assignments, new Predicate()
/* 106:    */       {
/* 107:    */         public boolean test(Op03SimpleStatement in)
/* 108:    */         {
/* 109:116 */           AssignmentSimple assignmentSimple = (AssignmentSimple)in.getStatement();
/* 110:117 */           WildcardMatch wildcardMatch = new WildcardMatch();
/* 111:118 */           return wildcardMatch.match(new AssignmentSimple(wildcardMatch.getLValueWildCard("array"), wildcardMatch.getNewArrayWildCard("def", 1, null)), assignmentSimple);
/* 112:    */         }
/* 113:123 */       });
/* 114:124 */       success = false;
/* 115:125 */       for (Op03SimpleStatement assignment : assignments) {
/* 116:126 */         success |= resugarAnonymousArray(assignment, statements);
/* 117:    */       }
/* 118:128 */       if (success) {
/* 119:129 */         LValueProp.condenseLValues(statements);
/* 120:    */       }
/* 121:132 */     } while (success);
/* 122:    */   }
/* 123:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.AnonymousArray
 * JD-Core Version:    0.7.0.1
 */