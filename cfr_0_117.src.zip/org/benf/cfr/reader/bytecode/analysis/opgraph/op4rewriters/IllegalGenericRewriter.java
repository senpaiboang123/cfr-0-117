/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractFunctionInvokation;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericBaseInstance;
/* 14:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/* 15:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 16:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/* 17:   */ 
/* 18:   */ public class IllegalGenericRewriter
/* 19:   */   implements ExpressionRewriter
/* 20:   */ {
/* 21:   */   private final ConstantPool cp;
/* 22:   */   
/* 23:   */   public IllegalGenericRewriter(ConstantPool cp)
/* 24:   */   {
/* 25:24 */     this.cp = cp;
/* 26:   */   }
/* 27:   */   
/* 28:   */   private boolean hasIllegalGenerics(JavaTypeInstance javaTypeInstance)
/* 29:   */   {
/* 30:28 */     if (!(javaTypeInstance instanceof JavaGenericBaseInstance)) {
/* 31:28 */       return false;
/* 32:   */     }
/* 33:29 */     JavaGenericBaseInstance genericBaseInstance = (JavaGenericBaseInstance)javaTypeInstance;
/* 34:30 */     return genericBaseInstance.hasForeignUnbound(this.cp);
/* 35:   */   }
/* 36:   */   
/* 37:   */   private void maybeRewriteExpressionType(InferredJavaType inferredJavaType)
/* 38:   */   {
/* 39:34 */     JavaTypeInstance javaTypeInstance = inferredJavaType.getJavaTypeInstance();
/* 40:35 */     if (hasIllegalGenerics(javaTypeInstance))
/* 41:   */     {
/* 42:36 */       JavaTypeInstance deGenerified = javaTypeInstance.getDeGenerifiedType();
/* 43:37 */       inferredJavaType.deGenerify(deGenerified);
/* 44:   */     }
/* 45:   */   }
/* 46:   */   
/* 47:   */   private void maybeRewriteExplicitCallTyping(AbstractFunctionInvokation abstractFunctionInvokation)
/* 48:   */   {
/* 49:42 */     List<JavaTypeInstance> list = abstractFunctionInvokation.getExplicitGenerics();
/* 50:43 */     if (list == null) {
/* 51:43 */       return;
/* 52:   */     }
/* 53:44 */     for (JavaTypeInstance type : list) {
/* 54:45 */       if (hasIllegalGenerics(type))
/* 55:   */       {
/* 56:46 */         abstractFunctionInvokation.setExplicitGenerics(null);
/* 57:47 */         return;
/* 58:   */       }
/* 59:   */     }
/* 60:   */   }
/* 61:   */   
/* 62:   */   public void handleStatement(StatementContainer statementContainer) {}
/* 63:   */   
/* 64:   */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 65:   */   {
/* 66:59 */     expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 67:60 */     if ((expression instanceof AbstractFunctionInvokation)) {
/* 68:61 */       maybeRewriteExplicitCallTyping((AbstractFunctionInvokation)expression);
/* 69:   */     }
/* 70:63 */     maybeRewriteExpressionType(expression.getInferredJavaType());
/* 71:64 */     return expression;
/* 72:   */   }
/* 73:   */   
/* 74:   */   public ConditionalExpression rewriteExpression(ConditionalExpression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 75:   */   {
/* 76:69 */     ConditionalExpression res = (ConditionalExpression)expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 77:70 */     return res;
/* 78:   */   }
/* 79:   */   
/* 80:   */   public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 81:   */   {
/* 82:80 */     maybeRewriteExpressionType(lValue.getInferredJavaType());
/* 83:81 */     return lValue;
/* 84:   */   }
/* 85:   */   
/* 86:   */   public StackSSALabel rewriteExpression(StackSSALabel lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 87:   */   {
/* 88:86 */     return lValue;
/* 89:   */   }
/* 90:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.IllegalGenericRewriter
 * JD-Core Version:    0.7.0.1
 */