/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Map;
/*   5:    */ import java.util.Map.Entry;
/*   6:    */ import java.util.Set;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentCollector;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  18:    */ import org.benf.cfr.reader.util.ListFactory;
/*  19:    */ import org.benf.cfr.reader.util.MapFactory;
/*  20:    */ 
/*  21:    */ public class LValuePropSimple
/*  22:    */ {
/*  23:    */   private static class AssignmentCollector
/*  24:    */     implements LValueAssignmentCollector<Statement>
/*  25:    */   {
/*  26: 30 */     Map<StackSSALabel, StatementContainer<Statement>> assignments = MapFactory.newMap();
/*  27: 31 */     Map<StackSSALabel, Expression> values = MapFactory.newMap();
/*  28:    */     
/*  29:    */     public void collect(StackSSALabel lValue, StatementContainer<Statement> statementContainer, Expression value)
/*  30:    */     {
/*  31: 34 */       if (this.assignments.containsKey(lValue))
/*  32:    */       {
/*  33: 35 */         this.assignments.put(lValue, null);
/*  34: 36 */         this.values.remove(lValue);
/*  35:    */       }
/*  36:    */       else
/*  37:    */       {
/*  38: 38 */         this.assignments.put(lValue, statementContainer);
/*  39: 39 */         this.values.put(lValue, value);
/*  40:    */       }
/*  41:    */     }
/*  42:    */     
/*  43:    */     public void collectMultiUse(StackSSALabel lValue, StatementContainer<Statement> statementContainer, Expression value)
/*  44:    */     {
/*  45: 45 */       this.assignments.put(lValue, null);
/*  46:    */     }
/*  47:    */     
/*  48:    */     public void collectMutatedLValue(LValue lValue, StatementContainer<Statement> statementContainer, Expression value)
/*  49:    */     {
/*  50: 50 */       if ((lValue instanceof StackSSALabel)) {
/*  51: 51 */         this.assignments.put((StackSSALabel)lValue, null);
/*  52:    */       }
/*  53:    */     }
/*  54:    */     
/*  55:    */     public void collectLocalVariableAssignment(LocalVariable localVariable, StatementContainer<Statement> statementContainer, Expression value) {}
/*  56:    */   }
/*  57:    */   
/*  58:    */   private static class UsageCollector
/*  59:    */     implements LValueUsageCollector
/*  60:    */   {
/*  61: 62 */     Map<StackSSALabel, Boolean> singleUsages = MapFactory.newMap();
/*  62:    */     
/*  63:    */     public void collect(LValue lValue)
/*  64:    */     {
/*  65: 66 */       if (!(lValue instanceof StackSSALabel)) {
/*  66: 66 */         return;
/*  67:    */       }
/*  68: 67 */       StackSSALabel stackSSALabel = (StackSSALabel)lValue;
/*  69: 68 */       if (this.singleUsages.containsKey(stackSSALabel)) {
/*  70: 69 */         this.singleUsages.put(stackSSALabel, null);
/*  71:    */       } else {
/*  72: 71 */         this.singleUsages.put(stackSSALabel, Boolean.TRUE);
/*  73:    */       }
/*  74:    */     }
/*  75:    */     
/*  76:    */     List<StackSSALabel> getSingleUsages()
/*  77:    */     {
/*  78: 76 */       List<StackSSALabel> res = ListFactory.newList();
/*  79: 77 */       for (Map.Entry<StackSSALabel, Boolean> entry : this.singleUsages.entrySet()) {
/*  80: 78 */         if (entry.getValue() == Boolean.TRUE) {
/*  81: 78 */           res.add(entry.getKey());
/*  82:    */         }
/*  83:    */       }
/*  84: 80 */       return res;
/*  85:    */     }
/*  86:    */   }
/*  87:    */   
/*  88:    */   public static List<Op03SimpleStatement> condenseSimpleLValues(List<Op03SimpleStatement> statementList)
/*  89:    */   {
/*  90: 85 */     AssignmentCollector assignmentCollector = new AssignmentCollector(null);
/*  91: 86 */     UsageCollector usageCollector = new UsageCollector(null);
/*  92: 88 */     for (Op03SimpleStatement statement : statementList)
/*  93:    */     {
/*  94: 89 */       statement.getStatement().collectLValueAssignments(assignmentCollector);
/*  95: 90 */       statement.getStatement().collectLValueUsage(usageCollector);
/*  96:    */     }
/*  97: 93 */     Map<StackSSALabel, StatementContainer<Statement>> created = assignmentCollector.assignments;
/*  98: 94 */     List<StackSSALabel> singleUsages = usageCollector.getSingleUsages();
/*  99: 95 */     Map<StackSSALabel, Op03SimpleStatement> createdAndUsed = MapFactory.newMap();
/* 100: 96 */     Map<Op03SimpleStatement, StackSSALabel> creations = MapFactory.newIdentityMap();
/* 101: 97 */     for (StackSSALabel single : singleUsages)
/* 102:    */     {
/* 103: 98 */       StatementContainer<Statement> creation = (StatementContainer)created.get(single);
/* 104: 99 */       if (creation != null)
/* 105:    */       {
/* 106:100 */         createdAndUsed.put(single, (Op03SimpleStatement)creation);
/* 107:101 */         creations.put((Op03SimpleStatement)creation, single);
/* 108:    */       }
/* 109:    */     }
/* 110:105 */     int nopCount = 0;
/* 111:106 */     for (int x = statementList.size(); x > 1; x--)
/* 112:    */     {
/* 113:107 */       Op03SimpleStatement prev = (Op03SimpleStatement)statementList.get(x - 1);
/* 114:108 */       if (creations.containsKey(statementList.get(x - 1)))
/* 115:    */       {
/* 116:109 */         Op03SimpleStatement now = (Op03SimpleStatement)statementList.get(x);
/* 117:110 */         if ((prev.getTargets().size() == 1) && (prev.getTargets().get(0) == now) && 
/* 118:111 */           (now.getSources().size() == 1))
/* 119:    */         {
/* 120:112 */           UsageCollector oneUsagecollector = new UsageCollector(null);
/* 121:113 */           now.getStatement().collectLValueUsage(oneUsagecollector);
/* 122:117 */           if ((prev.getBlockIdentifiers().isEmpty()) && 
/* 123:118 */             (now.getBlockIdentifiers().isEmpty()))
/* 124:    */           {
/* 125:119 */             StackSSALabel prevCreated = (StackSSALabel)creations.get(prev);
/* 126:120 */             if (oneUsagecollector.getSingleUsages().contains(prevCreated))
/* 127:    */             {
/* 128:121 */               final Expression rhs = (Expression)assignmentCollector.values.get(prevCreated);
/* 129:    */               
/* 130:123 */               LValueRewriter<Statement> rewriter = new LValueRewriter()
/* 131:    */               {
/* 132:    */                 public Expression getLValueReplacement(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer<Statement> statementContainer)
/* 133:    */                 {
/* 134:126 */                   if (lValue.equals(this.val$prevCreated)) {
/* 135:126 */                     return rhs;
/* 136:    */                   }
/* 137:127 */                   return null;
/* 138:    */                 }
/* 139:    */                 
/* 140:    */                 public boolean explicitlyReplaceThisLValue(LValue lValue)
/* 141:    */                 {
/* 142:132 */                   return lValue.equals(this.val$prevCreated);
/* 143:    */                 }
/* 144:    */                 
/* 145:    */                 public void checkPostConditions(LValue lValue, Expression rValue) {}
/* 146:140 */               };
/* 147:141 */               Statement nowS = now.getStatement();
/* 148:142 */               nowS.replaceSingleUsageLValues(rewriter, null);
/* 149:143 */               prev.replaceStatement(nowS);
/* 150:    */               
/* 151:    */ 
/* 152:    */ 
/* 153:147 */               prev.getTargets().clear();
/* 154:148 */               now.getSources().clear();
/* 155:149 */               for (Op03SimpleStatement target : now.getTargets())
/* 156:    */               {
/* 157:150 */                 target.replaceSource(now, prev);
/* 158:151 */                 prev.addTarget(target);
/* 159:    */               }
/* 160:153 */               now.getTargets().clear();
/* 161:154 */               now.nopOut();
/* 162:155 */               nopCount++;
/* 163:    */             }
/* 164:    */           }
/* 165:    */         }
/* 166:    */       }
/* 167:    */     }
/* 168:159 */     if (nopCount > 0) {
/* 169:160 */       statementList = Cleaner.removeUnreachableCode(statementList, false);
/* 170:    */     }
/* 171:162 */     return statementList;
/* 172:    */   }
/* 173:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LValuePropSimple
 * JD-Core Version:    0.7.0.1
 */