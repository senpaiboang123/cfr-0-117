/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Set;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.Block;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredBreak;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredDo;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredIf;
/* 14:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredReturn;
/* 15:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredWhile;
/* 16:   */ 
/* 17:   */ public class BadLoopPrettifier
/* 18:   */   implements StructuredStatementTransformer
/* 19:   */ {
/* 20:   */   public void transform(Op04StructuredStatement root)
/* 21:   */   {
/* 22:28 */     StructuredScope structuredScope = new StructuredScope();
/* 23:29 */     root.transform(this, structuredScope);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public List<Op04StructuredStatement> getIfBlock(Op04StructuredStatement maybeBlock)
/* 27:   */   {
/* 28:33 */     StructuredStatement bodyStatement = maybeBlock.getStatement();
/* 29:34 */     if (!(bodyStatement instanceof Block)) {
/* 30:34 */       return null;
/* 31:   */     }
/* 32:35 */     Block block = (Block)bodyStatement;
/* 33:   */     
/* 34:37 */     return block.getBlockStatements();
/* 35:   */   }
/* 36:   */   
/* 37:   */   public StructuredStatement transform(StructuredStatement in, StructuredScope scope)
/* 38:   */   {
/* 39:42 */     in.transformStructuredChildren(this, scope);
/* 40:44 */     if (!(in instanceof StructuredDo)) {
/* 41:44 */       return in;
/* 42:   */     }
/* 43:46 */     StructuredDo structuredDo = (StructuredDo)in;
/* 44:47 */     BlockIdentifier blockIdent = structuredDo.getBlock();
/* 45:49 */     if (structuredDo.getCondition() != null) {
/* 46:49 */       return in;
/* 47:   */     }
/* 48:51 */     List<Op04StructuredStatement> statements = getIfBlock(((StructuredDo)in).getBody());
/* 49:56 */     if ((statements == null) || (statements.isEmpty())) {
/* 50:56 */       return in;
/* 51:   */     }
/* 52:58 */     Op04StructuredStatement statement1 = (Op04StructuredStatement)statements.get(0);
/* 53:59 */     if (!(statement1.getStatement() instanceof StructuredIf)) {
/* 54:59 */       return in;
/* 55:   */     }
/* 56:61 */     StructuredIf ifStatement = (StructuredIf)statement1.getStatement();
/* 57:63 */     if (ifStatement.hasElseBlock()) {
/* 58:63 */       return in;
/* 59:   */     }
/* 60:65 */     List<Op04StructuredStatement> ifStatements = getIfBlock(ifStatement.getIfTaken());
/* 61:66 */     if ((ifStatements == null) || (ifStatements.size() != 1)) {
/* 62:66 */       return in;
/* 63:   */     }
/* 64:68 */     Op04StructuredStatement exitStatement = (Op04StructuredStatement)ifStatements.get(0);
/* 65:69 */     StructuredStatement structuredExit = exitStatement.getStatement();
/* 66:   */     
/* 67:71 */     boolean liftTestBody = false;
/* 68:73 */     if ((structuredExit instanceof StructuredBreak))
/* 69:   */     {
/* 70:74 */       StructuredBreak breakStatement = (StructuredBreak)structuredExit;
/* 71:76 */       if (!breakStatement.getBreakBlock().equals(blockIdent)) {
/* 72:76 */         return in;
/* 73:   */       }
/* 74:   */     }
/* 75:77 */     else if ((structuredExit instanceof StructuredReturn))
/* 76:   */     {
/* 77:78 */       Set<Op04StructuredStatement> fallthrough = scope.getNextFallThrough(in);
/* 78:79 */       if (!fallthrough.isEmpty()) {
/* 79:80 */         return in;
/* 80:   */       }
/* 81:82 */       liftTestBody = true;
/* 82:   */     }
/* 83:   */     else
/* 84:   */     {
/* 85:84 */       return in;
/* 86:   */     }
/* 87:87 */     statements.remove(0);
/* 88:88 */     ConditionalExpression condition = ifStatement.getConditionalExpression().getNegated().simplify();
/* 89:   */     
/* 90:90 */     StructuredWhile structuredWhile = new StructuredWhile(condition, structuredDo.getBody(), blockIdent);
/* 91:91 */     if (!liftTestBody) {
/* 92:91 */       return structuredWhile;
/* 93:   */     }
/* 94:93 */     Block lifted = Block.getBlockFor(false, new StructuredStatement[] { structuredWhile, structuredExit });
/* 95:94 */     return lifted;
/* 96:   */   }
/* 97:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.BadLoopPrettifier
 * JD-Core Version:    0.7.0.1
 */