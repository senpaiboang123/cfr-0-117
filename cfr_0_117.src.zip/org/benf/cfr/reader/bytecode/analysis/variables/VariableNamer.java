package org.benf.cfr.reader.bytecode.analysis.variables;

import java.util.List;

public abstract interface VariableNamer
{
  public abstract NamedVariable getName(int paramInt, Ident paramIdent, long paramLong);
  
  public abstract List<NamedVariable> getNamedVariables();
  
  public abstract void mutatingRenameUnClash(NamedVariable paramNamedVariable);
  
  public abstract void forceName(Ident paramIdent, long paramLong, String paramString);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.variables.VariableNamer
 * JD-Core Version:    0.7.0.1
 */