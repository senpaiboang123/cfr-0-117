/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.variables;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  4:   */ 
/*  5:   */ public class Slot
/*  6:   */ {
/*  7:   */   private final JavaTypeInstance javaTypeInstance;
/*  8:   */   private final int idx;
/*  9:   */   
/* 10:   */   public Slot(JavaTypeInstance javaTypeInstance, int idx)
/* 11:   */   {
/* 12:11 */     this.javaTypeInstance = javaTypeInstance;
/* 13:12 */     this.idx = idx;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public boolean equals(Object o)
/* 17:   */   {
/* 18:17 */     if (this == o) {
/* 19:17 */       return true;
/* 20:   */     }
/* 21:18 */     if ((o == null) || (getClass() != o.getClass())) {
/* 22:18 */       return false;
/* 23:   */     }
/* 24:20 */     Slot slot = (Slot)o;
/* 25:22 */     if (this.idx != slot.idx) {
/* 26:22 */       return false;
/* 27:   */     }
/* 28:24 */     return true;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public int getIdx()
/* 32:   */   {
/* 33:28 */     return this.idx;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public JavaTypeInstance getJavaTypeInstance()
/* 37:   */   {
/* 38:32 */     return this.javaTypeInstance;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public String toString()
/* 42:   */   {
/* 43:37 */     return "S{" + this.idx + '}';
/* 44:   */   }
/* 45:   */   
/* 46:   */   public int hashCode()
/* 47:   */   {
/* 48:44 */     return this.idx;
/* 49:   */   }
/* 50:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.variables.Slot
 * JD-Core Version:    0.7.0.1
 */