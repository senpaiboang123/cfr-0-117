/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.variables;
/*  2:   */ 
/*  3:   */ import java.util.Collection;
/*  4:   */ import java.util.List;
/*  5:   */ import java.util.Map;
/*  6:   */ import java.util.regex.Matcher;
/*  7:   */ import java.util.regex.Pattern;
/*  8:   */ import org.benf.cfr.reader.util.ListFactory;
/*  9:   */ import org.benf.cfr.reader.util.MapFactory;
/* 10:   */ 
/* 11:   */ public class VariableNamerDefault
/* 12:   */   implements VariableNamer
/* 13:   */ {
/* 14:14 */   private Map<Ident, NamedVariable> cached = MapFactory.newMap();
/* 15:   */   
/* 16:   */   public NamedVariable getName(int originalRawOffset, Ident ident, long stackPosition)
/* 17:   */   {
/* 18:21 */     NamedVariable res = (NamedVariable)this.cached.get(ident);
/* 19:22 */     if (res == null)
/* 20:   */     {
/* 21:23 */       res = new NamedVariableDefault("var" + ident);
/* 22:24 */       this.cached.put(ident, res);
/* 23:   */     }
/* 24:26 */     return res;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void forceName(Ident ident, long stackPosition, String name)
/* 28:   */   {
/* 29:31 */     NamedVariable res = (NamedVariable)this.cached.get(ident);
/* 30:32 */     if (res == null)
/* 31:   */     {
/* 32:33 */       this.cached.put(ident, new NamedVariableDefault(name));
/* 33:34 */       return;
/* 34:   */     }
/* 35:36 */     res.forceName(name);
/* 36:   */   }
/* 37:   */   
/* 38:   */   public List<NamedVariable> getNamedVariables()
/* 39:   */   {
/* 40:42 */     return ListFactory.newList(this.cached.values());
/* 41:   */   }
/* 42:   */   
/* 43:   */   public void mutatingRenameUnClash(NamedVariable toRename)
/* 44:   */   {
/* 45:47 */     Collection<NamedVariable> namedVars = this.cached.values();
/* 46:48 */     Map<String, NamedVariable> namedVariableMap = MapFactory.newMap();
/* 47:49 */     for (NamedVariable var : namedVars) {
/* 48:50 */       namedVariableMap.put(var.getStringName(), var);
/* 49:   */     }
/* 50:53 */     String name = toRename.getStringName();
/* 51:54 */     Pattern p = Pattern.compile("^(.*[^\\d]+)([\\d]+)$");
/* 52:55 */     Matcher m = p.matcher(name);
/* 53:56 */     int start = 2;
/* 54:57 */     String prefix = name;
/* 55:58 */     if (m.matches())
/* 56:   */     {
/* 57:59 */       prefix = m.group(0);
/* 58:60 */       start = Integer.parseInt(m.group(1));
/* 59:61 */       start++;
/* 60:   */     }
/* 61:   */     for (;;)
/* 62:   */     {
/* 63:64 */       String name2 = prefix + start;
/* 64:65 */       if (!namedVariableMap.containsKey(name2))
/* 65:   */       {
/* 66:66 */         toRename.forceName(name2);
/* 67:67 */         return;
/* 68:   */       }
/* 69:69 */       start++;
/* 70:   */     }
/* 71:   */   }
/* 72:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.variables.VariableNamerDefault
 * JD-Core Version:    0.7.0.1
 */