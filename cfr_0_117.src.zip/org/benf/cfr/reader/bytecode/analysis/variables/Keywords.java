/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.variables;
/*  2:   */ 
/*  3:   */ import java.util.Set;
/*  4:   */ import org.benf.cfr.reader.util.SetFactory;
/*  5:   */ 
/*  6:   */ public class Keywords
/*  7:   */ {
/*  8: 9 */   private static final Set<String> keywords = SetFactory.newSet(new String[] { "abstract", "continue", "for", "new", "switch", "assert", "default", "goto", "package", "synchronized", "boolean", "do", "if", "private", "this", "break", "double", "implements", "protected", "throw", "byte", "else", "import", "public", "throws", "case", "enum", "instanceof", "return", "transient", "catch", "extends", "int", "short", "try", "char", "final", "interface", "static", "void", "class", "finally", "long", "strictfp", "volatile", "const", "float", "native", "super", "while", "true", "false", "null" });
/*  9:   */   
/* 10:   */   public static boolean isAKeyword(String string)
/* 11:   */   {
/* 12:24 */     return keywords.contains(string);
/* 13:   */   }
/* 14:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.variables.Keywords
 * JD-Core Version:    0.7.0.1
 */