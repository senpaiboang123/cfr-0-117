/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.variables;
/*  2:   */ 
/*  3:   */ public class Ident
/*  4:   */ {
/*  5:   */   private final int stackpos;
/*  6:   */   private final int idx;
/*  7:   */   
/*  8:   */   public Ident(int stackpos, int idx)
/*  9:   */   {
/* 10: 8 */     this.stackpos = stackpos;
/* 11: 9 */     this.idx = idx;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String toString()
/* 15:   */   {
/* 16:14 */     if (this.idx == 0) {
/* 17:14 */       return "" + this.stackpos;
/* 18:   */     }
/* 19:15 */     return "" + this.stackpos + "_" + this.idx;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public boolean equals(Object o)
/* 23:   */   {
/* 24:20 */     if (this == o) {
/* 25:20 */       return true;
/* 26:   */     }
/* 27:21 */     if ((o == null) || (getClass() != o.getClass())) {
/* 28:21 */       return false;
/* 29:   */     }
/* 30:23 */     Ident ident = (Ident)o;
/* 31:25 */     if (this.idx != ident.idx) {
/* 32:25 */       return false;
/* 33:   */     }
/* 34:26 */     if (this.stackpos != ident.stackpos) {
/* 35:26 */       return false;
/* 36:   */     }
/* 37:28 */     return true;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public int getIdx()
/* 41:   */   {
/* 42:32 */     return this.idx;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public int hashCode()
/* 46:   */   {
/* 47:37 */     int result = this.stackpos;
/* 48:38 */     result = 31 * result + this.idx;
/* 49:39 */     return result;
/* 50:   */   }
/* 51:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.variables.Ident
 * JD-Core Version:    0.7.0.1
 */