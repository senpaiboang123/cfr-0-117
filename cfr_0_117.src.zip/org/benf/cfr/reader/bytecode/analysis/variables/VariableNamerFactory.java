/* 1:  */ package org.benf.cfr.reader.bytecode.analysis.variables;
/* 2:  */ 
/* 3:  */ import org.benf.cfr.reader.entities.attributes.AttributeLocalVariableTable;
/* 4:  */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/* 5:  */ 
/* 6:  */ public class VariableNamerFactory
/* 7:  */ {
/* 8:  */   public static VariableNamer getNamer(AttributeLocalVariableTable source, ConstantPool cp)
/* 9:  */   {
/* ::8 */     if (source == null) {
/* ;:8 */       return new VariableNamerDefault();
/* <:  */     }
/* =:9 */     return new VariableNamerHinted(source.getLocalVariableEntryList(), cp);
/* >:  */   }
/* ?:  */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.variables.VariableNamerFactory
 * JD-Core Version:    0.7.0.1
 */