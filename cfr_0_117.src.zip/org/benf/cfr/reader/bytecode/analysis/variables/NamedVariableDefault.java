/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.variables;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  4:   */ 
/*  5:   */ public class NamedVariableDefault
/*  6:   */   implements NamedVariable
/*  7:   */ {
/*  8:   */   private String name;
/*  9: 7 */   private boolean isGoodName = false;
/* 10:   */   
/* 11:   */   public NamedVariableDefault(String name)
/* 12:   */   {
/* 13:10 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public void forceName(String name)
/* 17:   */   {
/* 18:15 */     this.name = name;
/* 19:16 */     this.isGoodName = true;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String getStringName()
/* 23:   */   {
/* 24:21 */     return this.name;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public Dumper dump(Dumper d)
/* 28:   */   {
/* 29:26 */     return d.print(this.name);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public boolean isGoodName()
/* 33:   */   {
/* 34:31 */     return this.isGoodName;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public boolean equals(Object o)
/* 38:   */   {
/* 39:36 */     if (this == o) {
/* 40:36 */       return true;
/* 41:   */     }
/* 42:37 */     if ((o == null) || (getClass() != o.getClass())) {
/* 43:37 */       return false;
/* 44:   */     }
/* 45:39 */     NamedVariableDefault that = (NamedVariableDefault)o;
/* 46:41 */     if (!this.name.equals(that.name)) {
/* 47:41 */       return false;
/* 48:   */     }
/* 49:43 */     return true;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public int hashCode()
/* 53:   */   {
/* 54:48 */     return this.name.hashCode();
/* 55:   */   }
/* 56:   */   
/* 57:   */   public String toString()
/* 58:   */   {
/* 59:53 */     return this.name;
/* 60:   */   }
/* 61:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.variables.NamedVariableDefault
 * JD-Core Version:    0.7.0.1
 */