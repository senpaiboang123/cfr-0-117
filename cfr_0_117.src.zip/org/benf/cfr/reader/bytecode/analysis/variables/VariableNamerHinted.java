/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.variables;
/*   2:    */ 
/*   3:    */ import java.util.Comparator;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Map;
/*   6:    */ import java.util.TreeSet;
/*   7:    */ import java.util.regex.Matcher;
/*   8:    */ import java.util.regex.Pattern;
/*   9:    */ import org.benf.cfr.reader.entities.attributes.LocalVariableEntry;
/*  10:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  11:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryUTF8;
/*  12:    */ import org.benf.cfr.reader.util.ListFactory;
/*  13:    */ import org.benf.cfr.reader.util.MapFactory;
/*  14:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  15:    */ import org.benf.cfr.reader.util.output.IllegalIdentifierReplacement;
/*  16:    */ 
/*  17:    */ public class VariableNamerHinted
/*  18:    */   implements VariableNamer
/*  19:    */ {
/*  20: 16 */   private int genIdx = 0;
/*  21: 17 */   private final VariableNamer missingNamer = new VariableNamerDefault();
/*  22: 19 */   private final OrderLocalVariables orderLocalVariable = new OrderLocalVariables(null);
/*  23: 20 */   private final Map<Short, TreeSet<LocalVariableEntry>> localVariableEntryTreeSet = MapFactory.newLazyMap(new UnaryFunction()
/*  24:    */   {
/*  25:    */     public TreeSet<LocalVariableEntry> invoke(Short arg)
/*  26:    */     {
/*  27: 24 */       return new TreeSet(VariableNamerHinted.this.orderLocalVariable);
/*  28:    */     }
/*  29: 20 */   });
/*  30: 28 */   private final Map<LocalVariableEntry, NamedVariable> cache = MapFactory.newMap();
/*  31:    */   private final ConstantPool cp;
/*  32:    */   
/*  33:    */   public VariableNamerHinted(List<LocalVariableEntry> entryList, ConstantPool cp)
/*  34:    */   {
/*  35: 34 */     for (LocalVariableEntry e : entryList) {
/*  36: 35 */       ((TreeSet)this.localVariableEntryTreeSet.get(Short.valueOf(e.getIndex()))).add(e);
/*  37:    */     }
/*  38: 37 */     this.cp = cp;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public NamedVariable getName(int originalRawOffset, Ident ident, long stackPosition)
/*  42:    */   {
/*  43: 42 */     originalRawOffset += 2;
/*  44:    */     
/*  45: 44 */     short sstackPos = (short)(int)stackPosition;
/*  46: 45 */     if (!this.localVariableEntryTreeSet.containsKey(Short.valueOf(sstackPos))) {
/*  47: 46 */       return this.missingNamer.getName(0, ident, sstackPos);
/*  48:    */     }
/*  49: 48 */     LocalVariableEntry tmp = new LocalVariableEntry((short)originalRawOffset, (short)1, (short)-1, (short)-1, (short)(int)stackPosition);
/*  50: 49 */     LocalVariableEntry lve = (LocalVariableEntry)((TreeSet)this.localVariableEntryTreeSet.get(Short.valueOf(sstackPos))).floor(tmp);
/*  51: 51 */     if (lve == null) {
/*  52: 52 */       return this.missingNamer.getName(0, ident, sstackPos);
/*  53:    */     }
/*  54: 56 */     LocalVariableEntry key = lve;
/*  55: 57 */     NamedVariable namedVariable = (NamedVariable)this.cache.get(key);
/*  56: 58 */     if (namedVariable == null)
/*  57:    */     {
/*  58: 59 */       String name = this.cp.getUTF8Entry(lve.getNameIndex()).getValue();
/*  59: 60 */       if (IllegalIdentifierReplacement.isIllegal(name)) {
/*  60: 61 */         namedVariable = new NamedVariableDefault(name);
/*  61:    */       } else {
/*  62: 63 */         namedVariable = new NamedVariableFromHint(name, lve.getIndex(), this.genIdx);
/*  63:    */       }
/*  64: 65 */       this.cache.put(key, namedVariable);
/*  65:    */     }
/*  66: 67 */     return namedVariable;
/*  67:    */   }
/*  68:    */   
/*  69:    */   private static class OrderLocalVariables
/*  70:    */     implements Comparator<LocalVariableEntry>
/*  71:    */   {
/*  72:    */     public int compare(LocalVariableEntry a, LocalVariableEntry b)
/*  73:    */     {
/*  74: 81 */       int x = a.getIndex() - b.getIndex();
/*  75: 82 */       if (x != 0) {
/*  76: 82 */         return x;
/*  77:    */       }
/*  78: 83 */       return a.getStartPc() - b.getStartPc();
/*  79:    */     }
/*  80:    */   }
/*  81:    */   
/*  82:    */   public List<NamedVariable> getNamedVariables()
/*  83:    */   {
/*  84: 90 */     return ListFactory.newList(this.cache.values());
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void forceName(Ident ident, long stackPosition, String name) {}
/*  88:    */   
/*  89:    */   public void mutatingRenameUnClash(NamedVariable toRename)
/*  90:    */   {
/*  91:100 */     Map<String, NamedVariable> namedVariableMap = MapFactory.newMap();
/*  92:101 */     for (NamedVariable var : this.cache.values()) {
/*  93:102 */       namedVariableMap.put(var.getStringName(), var);
/*  94:    */     }
/*  95:104 */     for (NamedVariable var : this.missingNamer.getNamedVariables()) {
/*  96:105 */       namedVariableMap.put(var.getStringName(), var);
/*  97:    */     }
/*  98:108 */     String name = toRename.getStringName();
/*  99:109 */     Pattern p = Pattern.compile("^(.*[^\\d]+)([\\d]+)$");
/* 100:110 */     Matcher m = p.matcher(name);
/* 101:111 */     int start = 2;
/* 102:112 */     String prefix = name;
/* 103:113 */     if (m.matches())
/* 104:    */     {
/* 105:114 */       prefix = m.group(1);
/* 106:115 */       String numPart = m.group(2);
/* 107:116 */       start = Integer.parseInt(numPart);
/* 108:117 */       start++;
/* 109:    */     }
/* 110:    */     for (;;)
/* 111:    */     {
/* 112:120 */       String name2 = prefix + start;
/* 113:121 */       if (!namedVariableMap.containsKey(name2))
/* 114:    */       {
/* 115:122 */         toRename.forceName(name2);
/* 116:123 */         return;
/* 117:    */       }
/* 118:125 */       start++;
/* 119:    */     }
/* 120:    */   }
/* 121:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.variables.VariableNamerHinted
 * JD-Core Version:    0.7.0.1
 */