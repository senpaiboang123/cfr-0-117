/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.variables;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Map;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/* 13:   */ import org.benf.cfr.reader.entities.ClassFile;
/* 14:   */ import org.benf.cfr.reader.entities.Method;
/* 15:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/* 16:   */ import org.benf.cfr.reader.util.MapFactory;
/* 17:   */ 
/* 18:   */ public class VariableFactory
/* 19:   */ {
/* 20:   */   private final VariableNamer variableNamer;
/* 21:   */   private final Map<Integer, InferredJavaType> typedArgs;
/* 22:   */   private final Method method;
/* 23:23 */   private final Map<LValue, LValue> cache = MapFactory.newMap();
/* 24:   */   
/* 25:   */   public VariableFactory(Method method)
/* 26:   */   {
/* 27:26 */     this.variableNamer = method.getVariableNamer();
/* 28:27 */     if (method == null) {
/* 29:28 */       throw new ConfusedCFRException("No method signature for a variable factory");
/* 30:   */     }
/* 31:30 */     MethodPrototype methodPrototype = method.getMethodPrototype();
/* 32:31 */     List<JavaTypeInstance> args = methodPrototype.getArgs();
/* 33:32 */     this.typedArgs = MapFactory.newMap();
/* 34:33 */     int offset = 0;
/* 35:34 */     if (methodPrototype.isInstanceMethod())
/* 36:   */     {
/* 37:35 */       JavaTypeInstance thisType = method.getClassFile().getClassType();
/* 38:36 */       this.typedArgs.put(Integer.valueOf(offset++), new InferredJavaType(thisType, InferredJavaType.Source.UNKNOWN, true));
/* 39:   */     }
/* 40:38 */     for (JavaTypeInstance arg : args)
/* 41:   */     {
/* 42:39 */       this.typedArgs.put(Integer.valueOf(offset), new InferredJavaType(arg, InferredJavaType.Source.UNKNOWN, true));
/* 43:40 */       offset += arg.getStackType().getComputationCategory();
/* 44:   */     }
/* 45:42 */     if (methodPrototype.parametersComputed()) {
/* 46:43 */       for (LocalVariable localVariable : methodPrototype.getComputedParameters()) {
/* 47:44 */         this.cache.put(localVariable, localVariable);
/* 48:   */       }
/* 49:   */     }
/* 50:47 */     this.method = method;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public JavaTypeInstance getReturn()
/* 54:   */   {
/* 55:51 */     return this.method.getMethodPrototype().getReturnType();
/* 56:   */   }
/* 57:   */   
/* 58:   */   public LValue localVariable(int stackPosition, Ident ident, int origCodeRawOffset)
/* 59:   */   {
/* 60:58 */     if (ident == null) {
/* 61:59 */       throw new IllegalStateException();
/* 62:   */     }
/* 63:61 */     InferredJavaType varType = ident.getIdx() == 0 ? (InferredJavaType)this.typedArgs.get(Integer.valueOf(stackPosition)) : null;
/* 64:62 */     if (varType == null) {
/* 65:63 */       varType = new InferredJavaType(RawJavaType.VOID, InferredJavaType.Source.UNKNOWN);
/* 66:   */     }
/* 67:65 */     LValue tmp = new LocalVariable(stackPosition, ident, this.variableNamer, origCodeRawOffset, varType);
/* 68:66 */     LValue val = (LValue)this.cache.get(tmp);
/* 69:67 */     if (val == null)
/* 70:   */     {
/* 71:68 */       this.cache.put(tmp, tmp);
/* 72:69 */       val = tmp;
/* 73:   */     }
/* 74:71 */     return val;
/* 75:   */   }
/* 76:   */   
/* 77:   */   public void mutatingRenameUnClash(LocalVariable toRename)
/* 78:   */   {
/* 79:75 */     this.variableNamer.mutatingRenameUnClash(toRename.getName());
/* 80:   */   }
/* 81:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.variables.VariableFactory
 * JD-Core Version:    0.7.0.1
 */