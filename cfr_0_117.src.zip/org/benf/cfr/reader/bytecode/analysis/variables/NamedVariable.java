package org.benf.cfr.reader.bytecode.analysis.variables;

import org.benf.cfr.reader.util.output.Dumpable;
import org.benf.cfr.reader.util.output.Dumper;

public abstract interface NamedVariable
  extends Dumpable
{
  public abstract void forceName(String paramString);
  
  public abstract String getStringName();
  
  public abstract boolean isGoodName();
  
  public abstract Dumper dump(Dumper paramDumper);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.variables.NamedVariable
 * JD-Core Version:    0.7.0.1
 */