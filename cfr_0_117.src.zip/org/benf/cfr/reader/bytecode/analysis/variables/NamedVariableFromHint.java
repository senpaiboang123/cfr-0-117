/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.variables;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  4:   */ 
/*  5:   */ public class NamedVariableFromHint
/*  6:   */   implements NamedVariable
/*  7:   */ {
/*  8:   */   private String name;
/*  9:   */   private int slot;
/* 10:   */   private int idx;
/* 11:   */   
/* 12:   */   public NamedVariableFromHint(String name, int slot, int idx)
/* 13:   */   {
/* 14:11 */     this.name = name;
/* 15:12 */     this.slot = slot;
/* 16:13 */     this.idx = idx;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void forceName(String name)
/* 20:   */   {
/* 21:18 */     this.name = name;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String getStringName()
/* 25:   */   {
/* 26:23 */     return this.name;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public Dumper dump(Dumper d)
/* 30:   */   {
/* 31:28 */     return d.print(this.name);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public boolean isGoodName()
/* 35:   */   {
/* 36:33 */     return true;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public boolean equals(Object o)
/* 40:   */   {
/* 41:38 */     if (this == o) {
/* 42:38 */       return true;
/* 43:   */     }
/* 44:39 */     if ((o == null) || (getClass() != o.getClass())) {
/* 45:39 */       return false;
/* 46:   */     }
/* 47:41 */     NamedVariableFromHint that = (NamedVariableFromHint)o;
/* 48:43 */     if (this.slot != that.slot) {
/* 49:43 */       return false;
/* 50:   */     }
/* 51:44 */     if (this.idx != that.idx) {
/* 52:44 */       return false;
/* 53:   */     }
/* 54:45 */     if (!this.name.equals(that.name)) {
/* 55:45 */       return false;
/* 56:   */     }
/* 57:47 */     return true;
/* 58:   */   }
/* 59:   */   
/* 60:   */   public int hashCode()
/* 61:   */   {
/* 62:52 */     int result = this.name.hashCode();
/* 63:53 */     result = 31 * result + this.slot;
/* 64:54 */     result = 31 * result + this.idx;
/* 65:55 */     return result;
/* 66:   */   }
/* 67:   */   
/* 68:   */   public String toString()
/* 69:   */   {
/* 70:60 */     return this.name + " (" + this.slot + ")";
/* 71:   */   }
/* 72:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.variables.NamedVariableFromHint
 * JD-Core Version:    0.7.0.1
 */