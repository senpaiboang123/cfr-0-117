/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.utils.scope;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Map;
/*   6:    */ import java.util.Map.Entry;
/*   7:    */ import java.util.Stack;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.SentinelLocalClassLValue;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.Block;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.variables.NamedVariable;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.variables.VariableFactory;
/*  22:    */ import org.benf.cfr.reader.util.Functional;
/*  23:    */ import org.benf.cfr.reader.util.ListFactory;
/*  24:    */ import org.benf.cfr.reader.util.MapFactory;
/*  25:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  26:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  27:    */ 
/*  28:    */ public class LValueScopeDiscovererImpl
/*  29:    */   implements LValueScopeDiscoverer
/*  30:    */ {
/*  31: 29 */   private final Map<NamedVariable, ScopeDefinition> earliestDefinition = MapFactory.newIdentityMap();
/*  32: 30 */   private final Map<Integer, Map<NamedVariable, Boolean>> earliestDefinitionsByLevel = MapFactory.newLazyMap(new UnaryFunction()
/*  33:    */   {
/*  34:    */     public Map<NamedVariable, Boolean> invoke(Integer arg)
/*  35:    */     {
/*  36: 33 */       return MapFactory.newIdentityMap();
/*  37:    */     }
/*  38: 30 */   });
/*  39: 36 */   private transient int currentDepth = 0;
/*  40: 37 */   private transient Stack<StatementContainer<StructuredStatement>> currentBlock = new Stack();
/*  41: 39 */   private final List<ScopeDefinition> discoveredCreations = ListFactory.newList();
/*  42:    */   private final VariableFactory variableFactory;
/*  43:    */   
/*  44:    */   public LValueScopeDiscovererImpl(MethodPrototype prototype, VariableFactory variableFactory)
/*  45:    */   {
/*  46: 43 */     List<LocalVariable> parameters = prototype.getComputedParameters();
/*  47: 44 */     this.variableFactory = variableFactory;
/*  48: 45 */     for (LocalVariable parameter : parameters)
/*  49:    */     {
/*  50: 46 */       InferredJavaType inferredJavaType = parameter.getInferredJavaType();
/*  51: 47 */       ScopeDefinition prototypeScope = new ScopeDefinition(0, null, null, parameter, inferredJavaType, parameter.getName(), null);
/*  52: 48 */       this.earliestDefinition.put(parameter.getName(), prototypeScope);
/*  53:    */     }
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void enterBlock(StructuredStatement structuredStatement)
/*  57:    */   {
/*  58: 54 */     StatementContainer<StructuredStatement> container = structuredStatement.getContainer();
/*  59: 55 */     this.currentBlock.push(container);
/*  60: 56 */     this.currentDepth += 1;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void leaveBlock(StructuredStatement structuredStatement)
/*  64:    */   {
/*  65: 61 */     for (NamedVariable definedHere : ((Map)this.earliestDefinitionsByLevel.get(Integer.valueOf(this.currentDepth))).keySet()) {
/*  66: 62 */       this.earliestDefinition.remove(definedHere);
/*  67:    */     }
/*  68: 64 */     this.earliestDefinitionsByLevel.remove(Integer.valueOf(this.currentDepth));
/*  69: 65 */     StatementContainer<StructuredStatement> oldContainer = (StatementContainer)this.currentBlock.pop();
/*  70: 66 */     if (structuredStatement.getContainer() != oldContainer) {
/*  71: 67 */       throw new IllegalStateException();
/*  72:    */     }
/*  73: 69 */     this.currentDepth -= 1;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public void collect(StackSSALabel lValue, StatementContainer<StructuredStatement> statementContainer, Expression value) {}
/*  77:    */   
/*  78:    */   public void collectMultiUse(StackSSALabel lValue, StatementContainer<StructuredStatement> statementContainer, Expression value) {}
/*  79:    */   
/*  80:    */   public void collectMutatedLValue(LValue lValue, StatementContainer<StructuredStatement> statementContainer, Expression value) {}
/*  81:    */   
/*  82:    */   public void collectLocalVariableAssignment(LocalVariable localVariable, StatementContainer<StructuredStatement> statementContainer, Expression value)
/*  83:    */   {
/*  84: 93 */     NamedVariable name = localVariable.getName();
/*  85: 94 */     ScopeDefinition previousDef = (ScopeDefinition)this.earliestDefinition.get(name);
/*  86: 95 */     if (previousDef == null)
/*  87:    */     {
/*  88: 97 */       JavaTypeInstance type = localVariable.getInferredJavaType().getJavaTypeInstance();
/*  89: 98 */       ScopeDefinition scopeDefinition = new ScopeDefinition(this.currentDepth, this.currentBlock, statementContainer, localVariable, type, name, null);
/*  90: 99 */       this.earliestDefinition.put(name, scopeDefinition);
/*  91:100 */       ((Map)this.earliestDefinitionsByLevel.get(Integer.valueOf(this.currentDepth))).put(name, Boolean.valueOf(true));
/*  92:101 */       this.discoveredCreations.add(scopeDefinition);
/*  93:102 */       return;
/*  94:    */     }
/*  95:108 */     JavaTypeInstance oldType = previousDef.getJavaTypeInstance();
/*  96:109 */     JavaTypeInstance newType = localVariable.getInferredJavaType().getJavaTypeInstance();
/*  97:110 */     if (!oldType.equals(newType))
/*  98:    */     {
/*  99:111 */       ((Map)this.earliestDefinitionsByLevel.get(Integer.valueOf(previousDef.getDepth()))).remove(previousDef.getName());
/* 100:112 */       if (previousDef.getDepth() == this.currentDepth)
/* 101:    */       {
/* 102:113 */         this.variableFactory.mutatingRenameUnClash(localVariable);
/* 103:114 */         name = localVariable.getName();
/* 104:    */       }
/* 105:117 */       InferredJavaType inferredJavaType = localVariable.getInferredJavaType();
/* 106:118 */       ScopeDefinition scopeDefinition = new ScopeDefinition(this.currentDepth, this.currentBlock, statementContainer, localVariable, inferredJavaType, name, null);
/* 107:119 */       this.earliestDefinition.put(name, scopeDefinition);
/* 108:120 */       ((Map)this.earliestDefinitionsByLevel.get(Integer.valueOf(this.currentDepth))).put(name, Boolean.valueOf(true));
/* 109:121 */       this.discoveredCreations.add(scopeDefinition);
/* 110:    */     }
/* 111:    */   }
/* 112:    */   
/* 113:    */   private static class ScopeKey
/* 114:    */   {
/* 115:    */     private final LValue lValue;
/* 116:    */     private final JavaTypeInstance type;
/* 117:    */     
/* 118:    */     private ScopeKey(LValue lValue, JavaTypeInstance type)
/* 119:    */     {
/* 120:130 */       this.lValue = lValue;
/* 121:    */       
/* 122:    */ 
/* 123:    */ 
/* 124:134 */       this.type = type;
/* 125:    */     }
/* 126:    */     
/* 127:    */     public boolean equals(Object o)
/* 128:    */     {
/* 129:139 */       if (this == o) {
/* 130:139 */         return true;
/* 131:    */       }
/* 132:140 */       if ((o == null) || (getClass() != o.getClass())) {
/* 133:140 */         return false;
/* 134:    */       }
/* 135:142 */       ScopeKey scopeKey = (ScopeKey)o;
/* 136:144 */       if (!this.lValue.equals(scopeKey.lValue)) {
/* 137:144 */         return false;
/* 138:    */       }
/* 139:145 */       if (!this.type.equals(scopeKey.type)) {
/* 140:145 */         return false;
/* 141:    */       }
/* 142:147 */       return true;
/* 143:    */     }
/* 144:    */     
/* 145:    */     private LValue getlValue()
/* 146:    */     {
/* 147:151 */       return this.lValue;
/* 148:    */     }
/* 149:    */     
/* 150:    */     public int hashCode()
/* 151:    */     {
/* 152:156 */       int result = this.lValue.hashCode();
/* 153:157 */       result = 31 * result + this.type.hashCode();
/* 154:158 */       return result;
/* 155:    */     }
/* 156:    */   }
/* 157:    */   
/* 158:    */   public void markDiscoveredCreations()
/* 159:    */   {
/* 160:167 */     Map<ScopeKey, List<ScopeDefinition>> definitionsByType = Functional.groupToMapBy(this.discoveredCreations, new UnaryFunction()
/* 161:    */     {
/* 162:    */       public LValueScopeDiscovererImpl.ScopeKey invoke(LValueScopeDiscovererImpl.ScopeDefinition arg)
/* 163:    */       {
/* 164:170 */         return arg.getScopeKey();
/* 165:    */       }
/* 166:    */     });
/* 167:174 */     for (Map.Entry<ScopeKey, List<ScopeDefinition>> entry : definitionsByType.entrySet())
/* 168:    */     {
/* 169:175 */       ScopeKey scopeKey = (ScopeKey)entry.getKey();
/* 170:176 */       List<ScopeDefinition> definitions = (List)entry.getValue();
/* 171:    */       
/* 172:    */ 
/* 173:179 */       List<StatementContainer<StructuredStatement>> commonScope = null;
/* 174:180 */       ScopeDefinition bestDefn = null;
/* 175:181 */       LValue scopedEntity = scopeKey.getlValue();
/* 176:182 */       for (ScopeDefinition definition : definitions)
/* 177:    */       {
/* 178:183 */         StructuredStatement statement = (StructuredStatement)definition.getStatementContainer().getStatement();
/* 179:185 */         if (statement.alwaysDefines(scopedEntity))
/* 180:    */         {
/* 181:186 */           statement.markCreator(scopedEntity);
/* 182:    */         }
/* 183:    */         else
/* 184:    */         {
/* 185:189 */           List<StatementContainer<StructuredStatement>> scopeList = definition.getNestedScope();
/* 186:190 */           if (scopeList.isEmpty()) {
/* 187:190 */             scopeList = null;
/* 188:    */           }
/* 189:207 */           if (scopeList == null)
/* 190:    */           {
/* 191:208 */             commonScope = null;
/* 192:209 */             bestDefn = definition;
/* 193:210 */             break;
/* 194:    */           }
/* 195:213 */           if (commonScope == null)
/* 196:    */           {
/* 197:214 */             commonScope = scopeList;
/* 198:215 */             bestDefn = definition;
/* 199:    */           }
/* 200:    */           else
/* 201:    */           {
/* 202:219 */             commonScope = getCommonPrefix(commonScope, scopeList);
/* 203:220 */             if (commonScope.size() == scopeList.size()) {
/* 204:221 */               bestDefn = definition;
/* 205:    */             } else {
/* 206:223 */               bestDefn = null;
/* 207:    */             }
/* 208:    */           }
/* 209:    */         }
/* 210:    */       }
/* 211:229 */       if (bestDefn != definitions.get(0)) {
/* 212:229 */         bestDefn = null;
/* 213:    */       }
/* 214:230 */       StatementContainer<StructuredStatement> creationContainer = null;
/* 215:231 */       if ((scopedEntity instanceof SentinelLocalClassLValue))
/* 216:    */       {
/* 217:232 */         List<StatementContainer<StructuredStatement>> scope = null;
/* 218:233 */         if (bestDefn != null) {
/* 219:234 */           scope = bestDefn.getNestedScope();
/* 220:235 */         } else if (commonScope != null) {
/* 221:236 */           scope = commonScope;
/* 222:    */         }
/* 223:239 */         if (scope != null) {
/* 224:240 */           for (int i = scope.size() - 1; i >= 0; i--)
/* 225:    */           {
/* 226:241 */             StatementContainer<StructuredStatement> thisItem = (StatementContainer)scope.get(i);
/* 227:242 */             if ((thisItem.getStatement() instanceof Block))
/* 228:    */             {
/* 229:243 */               Block block = (Block)thisItem.getStatement();
/* 230:244 */               block.setIndenting(true);
/* 231:245 */               creationContainer = thisItem;
/* 232:246 */               break;
/* 233:    */             }
/* 234:    */           }
/* 235:    */         }
/* 236:    */       }
/* 237:251 */       else if (bestDefn != null)
/* 238:    */       {
/* 239:252 */         creationContainer = bestDefn.getStatementContainer();
/* 240:    */       }
/* 241:253 */       else if (commonScope != null)
/* 242:    */       {
/* 243:254 */         creationContainer = (StatementContainer)commonScope.get(commonScope.size() - 1);
/* 244:    */       }
/* 245:258 */       if (creationContainer != null) {
/* 246:259 */         ((StructuredStatement)creationContainer.getStatement()).markCreator(scopedEntity);
/* 247:    */       }
/* 248:    */     }
/* 249:    */   }
/* 250:    */   
/* 251:    */   private static <T> List<T> getCommonPrefix(List<T> a, List<T> b)
/* 252:    */   {
/* 253:    */     List<T> lb;
/* 254:    */     List<T> la;
/* 255:    */     List<T> lb;
/* 256:267 */     if (a.size() < b.size())
/* 257:    */     {
/* 258:268 */       List<T> la = a;
/* 259:269 */       lb = b;
/* 260:    */     }
/* 261:    */     else
/* 262:    */     {
/* 263:271 */       la = b;
/* 264:272 */       lb = a;
/* 265:    */     }
/* 266:275 */     int maxRes = Math.min(la.size(), lb.size());
/* 267:276 */     int sameLen = 0;
/* 268:277 */     for (int x = 0; x < maxRes; sameLen++)
/* 269:    */     {
/* 270:278 */       if (!la.get(x).equals(lb.get(x))) {
/* 271:    */         break;
/* 272:    */       }
/* 273:277 */       x++;
/* 274:    */     }
/* 275:280 */     if (sameLen == la.size()) {
/* 276:280 */       return la;
/* 277:    */     }
/* 278:281 */     return la.subList(0, sameLen);
/* 279:    */   }
/* 280:    */   
/* 281:    */   public void collect(LValue lValue)
/* 282:    */   {
/* 283:289 */     Class<?> lValueClass = lValue.getClass();
/* 284:291 */     if (lValueClass == LocalVariable.class)
/* 285:    */     {
/* 286:292 */       LocalVariable localVariable = (LocalVariable)lValue;
/* 287:293 */       NamedVariable name = localVariable.getName();
/* 288:294 */       if (name.getStringName().equals("this")) {
/* 289:294 */         return;
/* 290:    */       }
/* 291:296 */       ScopeDefinition previousDef = (ScopeDefinition)this.earliestDefinition.get(name);
/* 292:298 */       if (previousDef != null) {
/* 293:298 */         return;
/* 294:    */       }
/* 295:302 */       InferredJavaType inferredJavaType = lValue.getInferredJavaType();
/* 296:303 */       ScopeDefinition scopeDefinition = new ScopeDefinition(this.currentDepth, this.currentBlock, (StatementContainer)this.currentBlock.peek(), lValue, inferredJavaType, name, null);
/* 297:304 */       this.earliestDefinition.put(name, scopeDefinition);
/* 298:305 */       ((Map)this.earliestDefinitionsByLevel.get(Integer.valueOf(this.currentDepth))).put(name, Boolean.valueOf(true));
/* 299:306 */       this.discoveredCreations.add(scopeDefinition);
/* 300:    */     }
/* 301:307 */     else if (lValueClass == SentinelLocalClassLValue.class)
/* 302:    */     {
/* 303:308 */       SentinelLocalClassLValue localClassLValue = (SentinelLocalClassLValue)lValue;
/* 304:    */       
/* 305:310 */       NamedVariable name = new SentinelNV(localClassLValue.getLocalClassType(), null);
/* 306:    */       
/* 307:312 */       ScopeDefinition previousDef = (ScopeDefinition)this.earliestDefinition.get(name);
/* 308:314 */       if (previousDef != null) {
/* 309:314 */         return;
/* 310:    */       }
/* 311:316 */       JavaTypeInstance type = localClassLValue.getLocalClassType();
/* 312:317 */       ScopeDefinition scopeDefinition = new ScopeDefinition(this.currentDepth, this.currentBlock, (StatementContainer)this.currentBlock.peek(), lValue, type, name, null);
/* 313:318 */       this.earliestDefinition.put(name, scopeDefinition);
/* 314:319 */       ((Map)this.earliestDefinitionsByLevel.get(Integer.valueOf(this.currentDepth))).put(name, Boolean.valueOf(true));
/* 315:320 */       this.discoveredCreations.add(scopeDefinition);
/* 316:    */     }
/* 317:    */   }
/* 318:    */   
/* 319:    */   private static class SentinelNV
/* 320:    */     implements NamedVariable
/* 321:    */   {
/* 322:    */     private final JavaTypeInstance typeInstance;
/* 323:    */     
/* 324:    */     private SentinelNV(JavaTypeInstance typeInstance)
/* 325:    */     {
/* 326:329 */       this.typeInstance = typeInstance;
/* 327:    */     }
/* 328:    */     
/* 329:    */     public void forceName(String name) {}
/* 330:    */     
/* 331:    */     public String getStringName()
/* 332:    */     {
/* 333:338 */       return this.typeInstance.getRawName();
/* 334:    */     }
/* 335:    */     
/* 336:    */     public boolean isGoodName()
/* 337:    */     {
/* 338:343 */       return true;
/* 339:    */     }
/* 340:    */     
/* 341:    */     public Dumper dump(Dumper d)
/* 342:    */     {
/* 343:348 */       return null;
/* 344:    */     }
/* 345:    */     
/* 346:    */     public boolean equals(Object o)
/* 347:    */     {
/* 348:353 */       if (this == o) {
/* 349:353 */         return true;
/* 350:    */       }
/* 351:354 */       if ((o == null) || (getClass() != o.getClass())) {
/* 352:354 */         return false;
/* 353:    */       }
/* 354:356 */       SentinelNV that = (SentinelNV)o;
/* 355:358 */       if (this.typeInstance != null ? !this.typeInstance.equals(that.typeInstance) : that.typeInstance != null) {
/* 356:359 */         return false;
/* 357:    */       }
/* 358:361 */       return true;
/* 359:    */     }
/* 360:    */     
/* 361:    */     public int hashCode()
/* 362:    */     {
/* 363:366 */       return this.typeInstance != null ? this.typeInstance.hashCode() : 0;
/* 364:    */     }
/* 365:    */   }
/* 366:    */   
/* 367:    */   private static class ScopeDefinition
/* 368:    */   {
/* 369:    */     private final int depth;
/* 370:    */     private final List<StatementContainer<StructuredStatement>> nestedScope;
/* 371:    */     private final StatementContainer<StructuredStatement> exactStatement;
/* 372:    */     private final LValue lValue;
/* 373:    */     private final JavaTypeInstance lValueType;
/* 374:    */     private final NamedVariable name;
/* 375:    */     private final LValueScopeDiscovererImpl.ScopeKey scopeKey;
/* 376:    */     
/* 377:    */     private ScopeDefinition(int depth, Stack<StatementContainer<StructuredStatement>> nestedScope, StatementContainer<StructuredStatement> exactStatement, LValue lValue, InferredJavaType inferredJavaType, NamedVariable name)
/* 378:    */     {
/* 379:394 */       this(depth, nestedScope, exactStatement, lValue, getUnclashedType(inferredJavaType), name);
/* 380:    */     }
/* 381:    */     
/* 382:    */     private static JavaTypeInstance getUnclashedType(InferredJavaType inferredJavaType)
/* 383:    */     {
/* 384:398 */       if (inferredJavaType.isClash()) {
/* 385:399 */         inferredJavaType.collapseTypeClash();
/* 386:    */       }
/* 387:401 */       return inferredJavaType.getJavaTypeInstance();
/* 388:    */     }
/* 389:    */     
/* 390:    */     private ScopeDefinition(int depth, Stack<StatementContainer<StructuredStatement>> nestedScope, StatementContainer<StructuredStatement> exactStatement, LValue lValue, JavaTypeInstance type, NamedVariable name)
/* 391:    */     {
/* 392:406 */       this.depth = depth;
/* 393:407 */       Pair<List<StatementContainer<StructuredStatement>>, StatementContainer<StructuredStatement>> adjustedScope = getBestScopeFor(lValue, nestedScope, exactStatement);
/* 394:408 */       this.nestedScope = ((List)adjustedScope.getFirst());
/* 395:409 */       this.exactStatement = ((StatementContainer)adjustedScope.getSecond());
/* 396:410 */       this.lValue = lValue;
/* 397:411 */       this.lValueType = type;
/* 398:412 */       this.name = name;
/* 399:413 */       this.scopeKey = new LValueScopeDiscovererImpl.ScopeKey(lValue, type, null);
/* 400:    */     }
/* 401:    */     
/* 402:    */     private static Pair<List<StatementContainer<StructuredStatement>>, StatementContainer<StructuredStatement>> getBestScopeFor(LValue lValue, Collection<StatementContainer<StructuredStatement>> nestedScope, StatementContainer<StructuredStatement> exactStatement)
/* 403:    */     {
/* 404:421 */       if (nestedScope == null) {
/* 405:421 */         return Pair.make(null, exactStatement);
/* 406:    */       }
/* 407:422 */       List<StatementContainer<StructuredStatement>> scope = ListFactory.newList(nestedScope);
/* 408:423 */       if ((exactStatement != null) && (((StructuredStatement)exactStatement.getStatement()).alwaysDefines(lValue))) {
/* 409:423 */         return Pair.make(scope, exactStatement);
/* 410:    */       }
/* 411:424 */       if (scope.isEmpty()) {
/* 412:424 */         return Pair.make(scope, exactStatement);
/* 413:    */       }
/* 414:425 */       for (int x = scope.size() - 1; x >= 0; x--)
/* 415:    */       {
/* 416:426 */         StatementContainer<StructuredStatement> scopeTest = (StatementContainer)scope.get(x);
/* 417:427 */         if (((StructuredStatement)scopeTest.getStatement()).canDefine(lValue)) {
/* 418:    */           break;
/* 419:    */         }
/* 420:428 */         scope.remove(x);
/* 421:    */       }
/* 422:430 */       if (scope.size() == nestedScope.size()) {
/* 423:430 */         return Pair.make(scope, exactStatement);
/* 424:    */       }
/* 425:431 */       if (scope.isEmpty()) {
/* 426:431 */         return Pair.make(null, exactStatement);
/* 427:    */       }
/* 428:432 */       exactStatement = (StatementContainer)scope.get(scope.size() - 1);
/* 429:    */       
/* 430:434 */       return Pair.make(scope, exactStatement);
/* 431:    */     }
/* 432:    */     
/* 433:    */     public JavaTypeInstance getJavaTypeInstance()
/* 434:    */     {
/* 435:438 */       return this.lValueType;
/* 436:    */     }
/* 437:    */     
/* 438:    */     public StatementContainer<StructuredStatement> getStatementContainer()
/* 439:    */     {
/* 440:442 */       return this.exactStatement;
/* 441:    */     }
/* 442:    */     
/* 443:    */     public LValue getlValue()
/* 444:    */     {
/* 445:446 */       return this.lValue;
/* 446:    */     }
/* 447:    */     
/* 448:    */     public int getDepth()
/* 449:    */     {
/* 450:450 */       return this.depth;
/* 451:    */     }
/* 452:    */     
/* 453:    */     public NamedVariable getName()
/* 454:    */     {
/* 455:454 */       return this.name;
/* 456:    */     }
/* 457:    */     
/* 458:    */     public LValueScopeDiscovererImpl.ScopeKey getScopeKey()
/* 459:    */     {
/* 460:458 */       return this.scopeKey;
/* 461:    */     }
/* 462:    */     
/* 463:    */     public List<StatementContainer<StructuredStatement>> getNestedScope()
/* 464:    */     {
/* 465:462 */       return this.nestedScope;
/* 466:    */     }
/* 467:    */     
/* 468:    */     public String toString()
/* 469:    */     {
/* 470:467 */       return this.name + " : " + this.lValueType.getRawName();
/* 471:    */     }
/* 472:    */   }
/* 473:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscovererImpl
 * JD-Core Version:    0.7.0.1
 */