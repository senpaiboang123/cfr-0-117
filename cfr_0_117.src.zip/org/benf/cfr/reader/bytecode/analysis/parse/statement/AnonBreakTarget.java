/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredAnonBreakTarget;
/* 11:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 12:   */ 
/* 13:   */ public class AnonBreakTarget
/* 14:   */   extends AbstractStatement
/* 15:   */ {
/* 16:   */   private final BlockIdentifier blockIdentifier;
/* 17:   */   
/* 18:   */   public AnonBreakTarget(BlockIdentifier blockIdentifier)
/* 19:   */   {
/* 20:13 */     this.blockIdentifier = blockIdentifier;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public Dumper dump(Dumper dumper)
/* 24:   */   {
/* 25:18 */     return dumper;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers) {}
/* 29:   */   
/* 30:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers) {}
/* 31:   */   
/* 32:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector) {}
/* 33:   */   
/* 34:   */   public StructuredStatement getStructuredStatement()
/* 35:   */   {
/* 36:35 */     return new UnstructuredAnonBreakTarget(this.blockIdentifier);
/* 37:   */   }
/* 38:   */   
/* 39:   */   public BlockIdentifier getBlockIdentifier()
/* 40:   */   {
/* 41:39 */     return this.blockIdentifier;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public boolean equals(Object o)
/* 45:   */   {
/* 46:44 */     if (this == o) {
/* 47:44 */       return true;
/* 48:   */     }
/* 49:45 */     if ((o == null) || (getClass() != o.getClass())) {
/* 50:45 */       return false;
/* 51:   */     }
/* 52:47 */     return true;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 56:   */   {
/* 57:52 */     if (this == o) {
/* 58:52 */       return true;
/* 59:   */     }
/* 60:53 */     if ((o == null) || (getClass() != o.getClass())) {
/* 61:53 */       return false;
/* 62:   */     }
/* 63:54 */     return true;
/* 64:   */   }
/* 65:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.AnonBreakTarget
 * JD-Core Version:    0.7.0.1
 */