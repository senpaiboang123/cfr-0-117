/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.rewriters;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractFunctionInvokation;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationSimple;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.StaticFunctionInvokation;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.types.GenericTypeBinder;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericBaseInstance;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/* 14:   */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/* 15:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 16:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodRef;
/* 17:   */ 
/* 18:   */ public class ExplicitTypeCallRewriter
/* 19:   */   extends AbstractExpressionRewriter
/* 20:   */ {
/* 21:18 */   private final InnerExplicitTypeCallRewriter inner = new InnerExplicitTypeCallRewriter(null);
/* 22:   */   
/* 23:   */   private class InnerExplicitTypeCallRewriter
/* 24:   */     extends AbstractExpressionRewriter
/* 25:   */   {
/* 26:   */     private InnerExplicitTypeCallRewriter() {}
/* 27:   */     
/* 28:   */     private Expression rewriteFunctionInvokation(AbstractFunctionInvokation invokation)
/* 29:   */     {
/* 30:30 */       if ((invokation instanceof StaticFunctionInvokation))
/* 31:   */       {
/* 32:31 */         MethodPrototype p = ((StaticFunctionInvokation)invokation).getFunction().getMethodPrototype();
/* 33:34 */         if ((p.hasFormalTypeParameters()) && (p.getVisibleArgCount() == 0))
/* 34:   */         {
/* 35:36 */           JavaTypeInstance returnType = p.getReturnType();
/* 36:37 */           if ((returnType instanceof JavaGenericBaseInstance))
/* 37:   */           {
/* 38:38 */             JavaTypeInstance usedType = invokation.getInferredJavaType().getJavaTypeInstance();
/* 39:39 */             GenericTypeBinder binder = GenericTypeBinder.extractBaseBindings((JavaGenericBaseInstance)returnType, usedType);
/* 40:40 */             if (binder != null)
/* 41:   */             {
/* 42:41 */               List<JavaTypeInstance> types = p.getExplicitGenericUsage(binder);
/* 43:   */               
/* 44:   */ 
/* 45:   */ 
/* 46:   */ 
/* 47:46 */               invokation.setExplicitGenerics(types);
/* 48:   */             }
/* 49:   */           }
/* 50:   */         }
/* 51:   */       }
/* 52:51 */       return invokation;
/* 53:   */     }
/* 54:   */     
/* 55:   */     public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 56:   */     {
/* 57:56 */       if ((expression instanceof AbstractFunctionInvokation)) {
/* 58:58 */         expression = rewriteFunctionInvokation((AbstractFunctionInvokation)expression);
/* 59:   */       }
/* 60:61 */       return expression;
/* 61:   */     }
/* 62:   */     
/* 63:   */     public ConditionalExpression rewriteExpression(ConditionalExpression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 64:   */     {
/* 65:66 */       return expression;
/* 66:   */     }
/* 67:   */   }
/* 68:   */   
/* 69:   */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 70:   */   {
/* 71:72 */     if ((expression instanceof AbstractFunctionInvokation)) {
/* 72:73 */       ((AbstractFunctionInvokation)expression).applyExpressionRewriterToArgs(this.inner, ssaIdentifiers, statementContainer, flags);
/* 73:74 */     } else if ((expression instanceof ConstructorInvokationSimple)) {
/* 74:75 */       expression.applyExpressionRewriter(this.inner, ssaIdentifiers, statementContainer, flags);
/* 75:   */     }
/* 76:77 */     return super.rewriteExpression(expression, ssaIdentifiers, statementContainer, flags);
/* 77:   */   }
/* 78:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExplicitTypeCallRewriter
 * JD-Core Version:    0.7.0.1
 */