/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.lvalue;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.types.annotated.JavaAnnotatedTypeInstance;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 10:   */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/* 11:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 12:   */ import org.benf.cfr.reader.util.Troolean;
/* 13:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 14:   */ import org.benf.cfr.reader.util.output.ToStringDumper;
/* 15:   */ 
/* 16:   */ public abstract class AbstractLValue
/* 17:   */   implements LValue
/* 18:   */ {
/* 19:   */   private InferredJavaType inferredJavaType;
/* 20:   */   
/* 21:   */   public AbstractLValue(InferredJavaType inferredJavaType)
/* 22:   */   {
/* 23:20 */     this.inferredJavaType = inferredJavaType;
/* 24:   */   }
/* 25:   */   
/* 26:   */   protected String typeToString()
/* 27:   */   {
/* 28:24 */     return this.inferredJavaType.toString();
/* 29:   */   }
/* 30:   */   
/* 31:   */   public InferredJavaType getInferredJavaType()
/* 32:   */   {
/* 33:29 */     return this.inferredJavaType;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public JavaAnnotatedTypeInstance getAnnotatedCreationType()
/* 37:   */   {
/* 38:34 */     return null;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 42:   */   {
/* 43:39 */     collector.collect(this.inferredJavaType.getJavaTypeInstance());
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector) {}
/* 47:   */   
/* 48:   */   public boolean doesBlackListLValueReplacement(LValue replace, Expression with)
/* 49:   */   {
/* 50:48 */     return false;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public LValue outerDeepClone(CloneHelper cloneHelper)
/* 54:   */   {
/* 55:53 */     return cloneHelper.replaceOrClone(this);
/* 56:   */   }
/* 57:   */   
/* 58:   */   public boolean canThrow(ExceptionCheck caught)
/* 59:   */   {
/* 60:58 */     return caught.mightCatchUnchecked();
/* 61:   */   }
/* 62:   */   
/* 63:   */   public final String toString()
/* 64:   */   {
/* 65:63 */     return ToStringDumper.toString(this);
/* 66:   */   }
/* 67:   */   
/* 68:   */   public final Dumper dump(Dumper d)
/* 69:   */   {
/* 70:68 */     return dumpWithOuterPrecedence(d, Precedence.WEAKEST, Troolean.NEITHER);
/* 71:   */   }
/* 72:   */   
/* 73:   */   public abstract Precedence getPrecedence();
/* 74:   */   
/* 75:   */   public abstract Dumper dumpInner(Dumper paramDumper);
/* 76:   */   
/* 77:   */   public final Dumper dumpWithOuterPrecedence(Dumper d, Precedence outerP, Troolean isLhs)
/* 78:   */   {
/* 79:78 */     Precedence innerP = getPrecedence();
/* 80:79 */     int cmp = innerP.compareTo(outerP);
/* 81:80 */     if ((cmp > 0) || ((cmp == 0) && (!innerP.isLtoR())))
/* 82:   */     {
/* 83:81 */       d.print("(");
/* 84:82 */       dumpInner(d);
/* 85:83 */       d.print(")");
/* 86:   */     }
/* 87:   */     else
/* 88:   */     {
/* 89:85 */       dumpInner(d);
/* 90:   */     }
/* 91:87 */     return d;
/* 92:   */   }
/* 93:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.lvalue.AbstractLValue
 * JD-Core Version:    0.7.0.1
 */