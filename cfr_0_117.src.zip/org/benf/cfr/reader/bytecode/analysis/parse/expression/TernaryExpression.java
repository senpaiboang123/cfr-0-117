/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.PrimitiveBoxingRewriter;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface.BoxingProcessor;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  16:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  17:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  18:    */ import org.benf.cfr.reader.util.Troolean;
/*  19:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  20:    */ 
/*  21:    */ public class TernaryExpression
/*  22:    */   extends AbstractExpression
/*  23:    */   implements BoxingProcessor
/*  24:    */ {
/*  25:    */   private ConditionalExpression condition;
/*  26:    */   private Expression lhs;
/*  27:    */   private Expression rhs;
/*  28:    */   
/*  29:    */   public TernaryExpression(ConditionalExpression condition, Expression lhs, Expression rhs)
/*  30:    */   {
/*  31: 25 */     super(inferredType(lhs.getInferredJavaType(), rhs.getInferredJavaType()));
/*  32: 26 */     this.condition = condition;
/*  33: 27 */     this.lhs = lhs;
/*  34: 28 */     this.rhs = rhs;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  38:    */   {
/*  39: 33 */     this.condition.collectTypeUsages(collector);
/*  40: 34 */     this.lhs.collectTypeUsages(collector);
/*  41: 35 */     this.rhs.collectTypeUsages(collector);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  45:    */   {
/*  46: 40 */     return new TernaryExpression((ConditionalExpression)cloneHelper.replaceOrClone(this.condition), cloneHelper.replaceOrClone(this.lhs), cloneHelper.replaceOrClone(this.rhs));
/*  47:    */   }
/*  48:    */   
/*  49:    */   private static InferredJavaType inferredType(InferredJavaType a, InferredJavaType b)
/*  50:    */   {
/*  51: 49 */     b.chain(a);
/*  52:    */     
/*  53: 51 */     return a;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public ConditionalExpression getCondition()
/*  57:    */   {
/*  58: 55 */     return this.condition;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public Expression getLhs()
/*  62:    */   {
/*  63: 59 */     return this.lhs;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public Expression getRhs()
/*  67:    */   {
/*  68: 63 */     return this.rhs;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public Precedence getPrecedence()
/*  72:    */   {
/*  73: 68 */     return Precedence.CONDITIONAL;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public Dumper dumpInner(Dumper d)
/*  77:    */   {
/*  78: 73 */     this.condition.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.NEITHER);
/*  79: 74 */     d.print(" ? ");
/*  80: 75 */     this.lhs.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.NEITHER);
/*  81: 76 */     d.print(" : ");
/*  82: 77 */     this.rhs.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.NEITHER);
/*  83: 78 */     return d;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  87:    */   {
/*  88: 83 */     this.rhs = this.rhs.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/*  89: 84 */     this.lhs = this.lhs.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/*  90: 85 */     Expression replacementCondition = this.condition.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/*  91: 86 */     if (replacementCondition != this.condition) {
/*  92: 86 */       throw new ConfusedCFRException("Can't yet support replacing conditions");
/*  93:    */     }
/*  94: 88 */     return this;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  98:    */   {
/*  99: 93 */     this.condition = expressionRewriter.rewriteExpression(this.condition, ssaIdentifiers, statementContainer, flags);
/* 100: 94 */     this.lhs = expressionRewriter.rewriteExpression(this.lhs, ssaIdentifiers, statementContainer, flags);
/* 101: 95 */     this.rhs = expressionRewriter.rewriteExpression(this.rhs, ssaIdentifiers, statementContainer, flags);
/* 102: 96 */     return this;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 106:    */   {
/* 107:101 */     this.rhs = expressionRewriter.rewriteExpression(this.rhs, ssaIdentifiers, statementContainer, flags);
/* 108:102 */     this.lhs = expressionRewriter.rewriteExpression(this.lhs, ssaIdentifiers, statementContainer, flags);
/* 109:103 */     this.condition = expressionRewriter.rewriteExpression(this.condition, ssaIdentifiers, statementContainer, flags);
/* 110:104 */     return this;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public Expression applyConditionOnlyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 114:    */   {
/* 115:108 */     this.condition = expressionRewriter.rewriteExpression(this.condition, ssaIdentifiers, statementContainer, flags);
/* 116:109 */     return this;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/* 120:    */   {
/* 121:114 */     this.condition.collectUsedLValues(lValueUsageCollector);
/* 122:115 */     this.lhs.collectUsedLValues(lValueUsageCollector);
/* 123:116 */     this.rhs.collectUsedLValues(lValueUsageCollector);
/* 124:    */   }
/* 125:    */   
/* 126:    */   public boolean rewriteBoxing(PrimitiveBoxingRewriter boxingRewriter)
/* 127:    */   {
/* 128:121 */     if (boxingRewriter.isUnboxedType(this.lhs))
/* 129:    */     {
/* 130:122 */       this.rhs = boxingRewriter.sugarUnboxing(this.rhs);
/* 131:123 */       return false;
/* 132:    */     }
/* 133:125 */     if (boxingRewriter.isUnboxedType(this.rhs))
/* 134:    */     {
/* 135:126 */       this.lhs = boxingRewriter.sugarUnboxing(this.lhs);
/* 136:127 */       return false;
/* 137:    */     }
/* 138:130 */     return false;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public void applyNonArgExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags) {}
/* 142:    */   
/* 143:    */   public boolean equals(Object o)
/* 144:    */   {
/* 145:140 */     if (this == o) {
/* 146:140 */       return true;
/* 147:    */     }
/* 148:141 */     if ((o == null) || (getClass() != o.getClass())) {
/* 149:141 */       return false;
/* 150:    */     }
/* 151:143 */     TernaryExpression that = (TernaryExpression)o;
/* 152:145 */     if (this.condition != null ? !this.condition.equals(that.condition) : that.condition != null) {
/* 153:145 */       return false;
/* 154:    */     }
/* 155:146 */     if (this.lhs != null ? !this.lhs.equals(that.lhs) : that.lhs != null) {
/* 156:146 */       return false;
/* 157:    */     }
/* 158:147 */     if (this.rhs != null ? !this.rhs.equals(that.rhs) : that.rhs != null) {
/* 159:147 */       return false;
/* 160:    */     }
/* 161:149 */     return true;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 165:    */   {
/* 166:154 */     if (o == null) {
/* 167:154 */       return false;
/* 168:    */     }
/* 169:155 */     if (o == this) {
/* 170:155 */       return true;
/* 171:    */     }
/* 172:156 */     if (o.getClass() != getClass()) {
/* 173:156 */       return false;
/* 174:    */     }
/* 175:157 */     TernaryExpression other = (TernaryExpression)o;
/* 176:158 */     if (!constraint.equivalent(this.condition, other.condition)) {
/* 177:158 */       return false;
/* 178:    */     }
/* 179:159 */     if (!constraint.equivalent(this.lhs, other.lhs)) {
/* 180:159 */       return false;
/* 181:    */     }
/* 182:160 */     if (!constraint.equivalent(this.rhs, other.rhs)) {
/* 183:160 */       return false;
/* 184:    */     }
/* 185:161 */     return true;
/* 186:    */   }
/* 187:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.TernaryExpression
 * JD-Core Version:    0.7.0.1
 */