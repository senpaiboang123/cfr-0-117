/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredSwitch;
/* 13:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 14:   */ 
/* 15:   */ public class SwitchStatement
/* 16:   */   extends AbstractStatement
/* 17:   */ {
/* 18:   */   private Expression switchOn;
/* 19:   */   private final BlockIdentifier switchBlock;
/* 20:   */   
/* 21:   */   public SwitchStatement(Expression switchOn, BlockIdentifier switchBlock)
/* 22:   */   {
/* 23:16 */     this.switchOn = switchOn;
/* 24:17 */     this.switchBlock = switchBlock;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public Dumper dump(Dumper dumper)
/* 28:   */   {
/* 29:22 */     return dumper.print("switch (").dump(this.switchOn).print(") { // " + this.switchBlock + "\n");
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers)
/* 33:   */   {
/* 34:27 */     this.switchOn = this.switchOn.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer());
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/* 38:   */   {
/* 39:32 */     this.switchOn = expressionRewriter.rewriteExpression(this.switchOn, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/* 43:   */   {
/* 44:37 */     this.switchOn.collectUsedLValues(lValueUsageCollector);
/* 45:   */   }
/* 46:   */   
/* 47:   */   public StructuredStatement getStructuredStatement()
/* 48:   */   {
/* 49:42 */     return new UnstructuredSwitch(this.switchOn, this.switchBlock);
/* 50:   */   }
/* 51:   */   
/* 52:   */   public BlockIdentifier getSwitchBlock()
/* 53:   */   {
/* 54:46 */     return this.switchBlock;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 58:   */   {
/* 59:51 */     if (o == null) {
/* 60:51 */       return false;
/* 61:   */     }
/* 62:52 */     if (o == this) {
/* 63:52 */       return true;
/* 64:   */     }
/* 65:53 */     if (getClass() != o.getClass()) {
/* 66:53 */       return false;
/* 67:   */     }
/* 68:54 */     SwitchStatement other = (SwitchStatement)o;
/* 69:55 */     if (!constraint.equivalent(this.switchOn, other.switchOn)) {
/* 70:55 */       return false;
/* 71:   */     }
/* 72:56 */     return true;
/* 73:   */   }
/* 74:   */   
/* 75:   */   public boolean fallsToNext()
/* 76:   */   {
/* 77:61 */     return false;
/* 78:   */   }
/* 79:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.SwitchStatement
 * JD-Core Version:    0.7.0.1
 */