/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredDo;
/* 11:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 12:   */ 
/* 13:   */ public class DoStatement
/* 14:   */   extends AbstractStatement
/* 15:   */ {
/* 16:   */   private final BlockIdentifier blockIdentifier;
/* 17:   */   
/* 18:   */   public DoStatement(BlockIdentifier blockIdentifier)
/* 19:   */   {
/* 20:13 */     this.blockIdentifier = blockIdentifier;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public Dumper dump(Dumper dumper)
/* 24:   */   {
/* 25:18 */     return dumper.print("do\n");
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers) {}
/* 29:   */   
/* 30:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers) {}
/* 31:   */   
/* 32:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector) {}
/* 33:   */   
/* 34:   */   public BlockIdentifier getBlockIdentifier()
/* 35:   */   {
/* 36:34 */     return this.blockIdentifier;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public StructuredStatement getStructuredStatement()
/* 40:   */   {
/* 41:39 */     return new UnstructuredDo(this.blockIdentifier);
/* 42:   */   }
/* 43:   */   
/* 44:   */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 45:   */   {
/* 46:44 */     if (o == null) {
/* 47:44 */       return false;
/* 48:   */     }
/* 49:45 */     if (o == this) {
/* 50:45 */       return true;
/* 51:   */     }
/* 52:46 */     if (getClass() != o.getClass()) {
/* 53:46 */       return false;
/* 54:   */     }
/* 55:47 */     return true;
/* 56:   */   }
/* 57:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.DoStatement
 * JD-Core Version:    0.7.0.1
 */