/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterHelper;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  19:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  20:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  21:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  22:    */ 
/*  23:    */ public class NewObjectArray
/*  24:    */   extends AbstractNewArray
/*  25:    */ {
/*  26:    */   private List<Expression> dimSizes;
/*  27:    */   private final JavaTypeInstance allocatedType;
/*  28:    */   private final JavaTypeInstance resultType;
/*  29:    */   private final int numDims;
/*  30:    */   
/*  31:    */   public NewObjectArray(List<Expression> dimSizes, JavaTypeInstance resultInstance)
/*  32:    */   {
/*  33: 27 */     super(new InferredJavaType(resultInstance, InferredJavaType.Source.EXPRESSION, true));
/*  34: 28 */     this.dimSizes = dimSizes;
/*  35: 29 */     this.allocatedType = resultInstance.getArrayStrippedType();
/*  36: 30 */     this.resultType = resultInstance;
/*  37: 31 */     this.numDims = resultInstance.getNumArrayDimensions();
/*  38: 32 */     for (Expression size : dimSizes) {
/*  39: 33 */       size.getInferredJavaType().useAsWithoutCasting(RawJavaType.INT);
/*  40:    */     }
/*  41:    */   }
/*  42:    */   
/*  43:    */   private NewObjectArray(InferredJavaType inferredJavaType, JavaTypeInstance resultType, int numDims, JavaTypeInstance allocatedType, List<Expression> dimSizes)
/*  44:    */   {
/*  45: 38 */     super(inferredJavaType);
/*  46: 39 */     this.resultType = resultType;
/*  47: 40 */     this.numDims = numDims;
/*  48: 41 */     this.allocatedType = allocatedType;
/*  49: 42 */     this.dimSizes = dimSizes;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  53:    */   {
/*  54: 47 */     return new NewObjectArray(getInferredJavaType(), this.resultType, this.numDims, this.allocatedType, cloneHelper.replaceOrClone(this.dimSizes));
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  58:    */   {
/*  59: 52 */     collector.collect(this.allocatedType);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public Precedence getPrecedence()
/*  63:    */   {
/*  64: 57 */     return Precedence.PAREN_SUB_MEMBER;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public Dumper dumpInner(Dumper d)
/*  68:    */   {
/*  69: 62 */     d.print("new ").dump(this.allocatedType);
/*  70: 63 */     for (Expression dimSize : this.dimSizes) {
/*  71: 64 */       d.print("[").dump(dimSize).print("]");
/*  72:    */     }
/*  73: 66 */     for (int x = this.dimSizes.size(); x < this.numDims; x++) {
/*  74: 67 */       d.print("[]");
/*  75:    */     }
/*  76: 69 */     return d;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public int getNumDims()
/*  80:    */   {
/*  81: 74 */     return this.numDims;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public int getNumSizedDims()
/*  85:    */   {
/*  86: 79 */     return this.dimSizes.size();
/*  87:    */   }
/*  88:    */   
/*  89:    */   public Expression getDimSize(int dim)
/*  90:    */   {
/*  91: 84 */     if (dim >= this.dimSizes.size()) {
/*  92: 84 */       throw new ConfusedCFRException("Out of bounds");
/*  93:    */     }
/*  94: 85 */     return (Expression)this.dimSizes.get(dim);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public JavaTypeInstance getInnerType()
/*  98:    */   {
/*  99: 90 */     return this.resultType;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/* 103:    */   {
/* 104: 95 */     for (int x = this.dimSizes.size() - 1; x >= 0; x--) {
/* 105: 96 */       this.dimSizes.set(x, ((Expression)this.dimSizes.get(x)).replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer));
/* 106:    */     }
/* 107: 98 */     return this;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 111:    */   {
/* 112:103 */     ExpressionRewriterHelper.applyForwards(this.dimSizes, expressionRewriter, ssaIdentifiers, statementContainer, flags);
/* 113:104 */     return this;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 117:    */   {
/* 118:109 */     ExpressionRewriterHelper.applyBackwards(this.dimSizes, expressionRewriter, ssaIdentifiers, statementContainer, flags);
/* 119:110 */     return this;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/* 123:    */   {
/* 124:115 */     for (Expression dimSize : this.dimSizes) {
/* 125:116 */       dimSize.collectUsedLValues(lValueUsageCollector);
/* 126:    */     }
/* 127:    */   }
/* 128:    */   
/* 129:    */   public boolean equals(Object o)
/* 130:    */   {
/* 131:122 */     if (this == o) {
/* 132:122 */       return true;
/* 133:    */     }
/* 134:123 */     if ((o == null) || (getClass() != o.getClass())) {
/* 135:123 */       return false;
/* 136:    */     }
/* 137:125 */     NewObjectArray that = (NewObjectArray)o;
/* 138:127 */     if (this.numDims != that.numDims) {
/* 139:127 */       return false;
/* 140:    */     }
/* 141:128 */     if (this.allocatedType != null ? !this.allocatedType.equals(that.allocatedType) : that.allocatedType != null) {
/* 142:129 */       return false;
/* 143:    */     }
/* 144:130 */     if (this.dimSizes != null ? !this.dimSizes.equals(that.dimSizes) : that.dimSizes != null) {
/* 145:130 */       return false;
/* 146:    */     }
/* 147:131 */     if (this.resultType != null ? !this.resultType.equals(that.resultType) : that.resultType != null) {
/* 148:131 */       return false;
/* 149:    */     }
/* 150:133 */     return true;
/* 151:    */   }
/* 152:    */   
/* 153:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 154:    */   {
/* 155:138 */     if (o == null) {
/* 156:138 */       return false;
/* 157:    */     }
/* 158:139 */     if (o == this) {
/* 159:139 */       return true;
/* 160:    */     }
/* 161:140 */     if (getClass() != o.getClass()) {
/* 162:140 */       return false;
/* 163:    */     }
/* 164:141 */     NewObjectArray other = (NewObjectArray)o;
/* 165:142 */     if (this.numDims != other.numDims) {
/* 166:142 */       return false;
/* 167:    */     }
/* 168:143 */     if (!constraint.equivalent(this.dimSizes, other.dimSizes)) {
/* 169:143 */       return false;
/* 170:    */     }
/* 171:144 */     if (!constraint.equivalent(this.allocatedType, other.allocatedType)) {
/* 172:144 */       return false;
/* 173:    */     }
/* 174:145 */     if (!constraint.equivalent(this.resultType, other.resultType)) {
/* 175:145 */       return false;
/* 176:    */     }
/* 177:146 */     return true;
/* 178:    */   }
/* 179:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.NewObjectArray
 * JD-Core Version:    0.7.0.1
 */