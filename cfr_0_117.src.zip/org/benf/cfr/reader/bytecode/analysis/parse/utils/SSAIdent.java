/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.utils;
/*  2:   */ 
/*  3:   */ import java.util.BitSet;
/*  4:   */ 
/*  5:   */ public class SSAIdent
/*  6:   */ {
/*  7: 6 */   public static SSAIdent poison = new SSAIdent(0, new Object());
/*  8:   */   private final BitSet val;
/*  9:   */   private final Object comparisonType;
/* 10:   */   
/* 11:   */   public SSAIdent(int idx, Object comparisonType)
/* 12:   */   {
/* 13:12 */     this.val = new BitSet();
/* 14:13 */     this.val.set(idx);
/* 15:14 */     this.comparisonType = comparisonType;
/* 16:   */   }
/* 17:   */   
/* 18:   */   private SSAIdent(BitSet content, Object comparisonType)
/* 19:   */   {
/* 20:18 */     this.val = content;
/* 21:19 */     this.comparisonType = comparisonType;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public Object getComparisonType()
/* 25:   */   {
/* 26:23 */     return this.comparisonType;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public SSAIdent mergeWith(SSAIdent other)
/* 30:   */   {
/* 31:27 */     BitSet b1 = this.val;
/* 32:28 */     BitSet b2 = other.val;
/* 33:29 */     if (b1.equals(b2)) {
/* 34:29 */       return this;
/* 35:   */     }
/* 36:30 */     b1 = (BitSet)b1.clone();
/* 37:31 */     b1.or(b2);
/* 38:32 */     return new SSAIdent(b1, this.comparisonType);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public boolean isSuperSet(SSAIdent other)
/* 42:   */   {
/* 43:36 */     BitSet tmp = (BitSet)this.val.clone();
/* 44:37 */     tmp.or(other.val);
/* 45:39 */     if (tmp.cardinality() != this.val.cardinality()) {
/* 46:39 */       return false;
/* 47:   */     }
/* 48:40 */     tmp.xor(other.val);
/* 49:41 */     return tmp.cardinality() > 0;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public int card()
/* 53:   */   {
/* 54:45 */     return this.val.cardinality();
/* 55:   */   }
/* 56:   */   
/* 57:   */   public boolean equals(Object o)
/* 58:   */   {
/* 59:50 */     if (o == this) {
/* 60:50 */       return true;
/* 61:   */     }
/* 62:51 */     if (!(o instanceof SSAIdent)) {
/* 63:51 */       return false;
/* 64:   */     }
/* 65:52 */     SSAIdent other = (SSAIdent)o;
/* 66:53 */     return this.val.equals(other.val);
/* 67:   */   }
/* 68:   */   
/* 69:   */   public int hashCode()
/* 70:   */   {
/* 71:58 */     return this.val.hashCode();
/* 72:   */   }
/* 73:   */   
/* 74:   */   public String toString()
/* 75:   */   {
/* 76:63 */     return this.val.toString();
/* 77:   */   }
/* 78:   */   
/* 79:   */   public boolean isFirstIn(SSAIdent other)
/* 80:   */   {
/* 81:67 */     int bit1 = this.val.nextSetBit(0);
/* 82:68 */     int bit2 = other.val.nextSetBit(0);
/* 83:69 */     return bit1 == bit2;
/* 84:   */   }
/* 85:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdent
 * JD-Core Version:    0.7.0.1
 */