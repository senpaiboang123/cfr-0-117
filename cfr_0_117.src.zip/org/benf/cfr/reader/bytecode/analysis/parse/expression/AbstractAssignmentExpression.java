/* 1:  */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/* 2:  */ 
/* 3:  */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/* 4:  */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 5:  */ 
/* 6:  */ public abstract class AbstractAssignmentExpression
/* 7:  */   extends AbstractExpression
/* 8:  */ {
/* 9:  */   public AbstractAssignmentExpression(InferredJavaType inferredJavaType)
/* ::  */   {
/* ;:9 */     super(inferredJavaType);
/* <:  */   }
/* =:  */   
/* >:  */   public abstract boolean isSelfMutatingOp1(LValue paramLValue, ArithOp paramArithOp);
/* ?:  */   
/* @:  */   public abstract ArithmeticPostMutationOperation getPostMutation();
/* A:  */   
/* B:  */   public abstract LValue getUpdatedLValue();
/* C:  */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractAssignmentExpression
 * JD-Core Version:    0.7.0.1
 */