/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.utils;
/*  2:   */ 
/*  3:   */ public enum BlockType
/*  4:   */ {
/*  5: 4 */   WHILELOOP(true, true),  DOLOOP(true, true),  UNCONDITIONALDOLOOP(true, true),  FORLOOP(true, true),  TRYBLOCK(false, false),  SIMPLE_IF_TAKEN(false, false),  SIMPLE_IF_ELSE(false, false),  CATCHBLOCK(false, false),  SWITCH(true, false),  CASE(false, false),  ANONYMOUS(true, false),  MONITOR(false, false);
/*  6:   */   
/*  7:   */   private final boolean breakable;
/*  8:   */   private final boolean isloop;
/*  9:   */   
/* 10:   */   private BlockType(boolean breakable, boolean isloop)
/* 11:   */   {
/* 12:21 */     this.breakable = breakable;
/* 13:22 */     this.isloop = isloop;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public boolean isBreakable()
/* 17:   */   {
/* 18:26 */     return this.breakable;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public boolean isLoop()
/* 22:   */   {
/* 23:29 */     return this.isloop;
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockType
 * JD-Core Version:    0.7.0.1
 */