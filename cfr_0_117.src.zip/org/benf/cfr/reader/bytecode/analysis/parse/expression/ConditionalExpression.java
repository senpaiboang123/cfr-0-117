package org.benf.cfr.reader.bytecode.analysis.parse.expression;

import java.util.Set;
import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;

public abstract interface ConditionalExpression
  extends Expression
{
  public abstract ConditionalExpression getNegated();
  
  public abstract int getSize(Precedence paramPrecedence);
  
  public abstract ConditionalExpression getDemorganApplied(boolean paramBoolean);
  
  public abstract ConditionalExpression getRightDeep();
  
  public abstract Set<LValue> getLoopLValues();
  
  public abstract ConditionalExpression optimiseForType();
  
  public abstract ConditionalExpression simplify();
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression
 * JD-Core Version:    0.7.0.1
 */