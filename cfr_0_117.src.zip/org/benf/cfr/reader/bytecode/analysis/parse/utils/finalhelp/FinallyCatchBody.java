/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.utils.finalhelp;
/*  2:   */ 
/*  3:   */ import java.util.LinkedList;
/*  4:   */ import java.util.List;
/*  5:   */ import java.util.Set;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CatchStatement;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.Nop;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ThrowStatement;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/* 12:   */ import org.benf.cfr.reader.util.ListFactory;
/* 13:   */ import org.benf.cfr.reader.util.SetFactory;
/* 14:   */ 
/* 15:   */ public class FinallyCatchBody
/* 16:   */ {
/* 17:   */   final Op03SimpleStatement throwOp;
/* 18:   */   final boolean isEmpty;
/* 19:   */   final Op03SimpleStatement catchCodeStart;
/* 20:   */   final List<Op03SimpleStatement> body;
/* 21:   */   final Set<Op03SimpleStatement> bodySet;
/* 22:   */   
/* 23:   */   protected FinallyCatchBody(Op03SimpleStatement throwOp, boolean isEmpty, Op03SimpleStatement catchCodeStart, List<Op03SimpleStatement> body)
/* 24:   */   {
/* 25:24 */     this.throwOp = throwOp;
/* 26:25 */     this.isEmpty = isEmpty;
/* 27:26 */     this.catchCodeStart = catchCodeStart;
/* 28:27 */     this.body = body;
/* 29:28 */     this.bodySet = SetFactory.newOrderedSet(body);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public static FinallyCatchBody build(Op03SimpleStatement catchStart, List<Op03SimpleStatement> allStatements)
/* 33:   */   {
/* 34:32 */     List<Op03SimpleStatement> targets = catchStart.getTargets();
/* 35:33 */     if (targets.size() != 1) {
/* 36:34 */       return null;
/* 37:   */     }
/* 38:36 */     if (!(catchStart.getStatement() instanceof CatchStatement)) {
/* 39:36 */       return null;
/* 40:   */     }
/* 41:37 */     CatchStatement catchStatement = (CatchStatement)catchStart.getStatement();
/* 42:38 */     BlockIdentifier catchBlockIdentifier = catchStatement.getCatchBlockIdent();
/* 43:39 */     LinkedList<Op03SimpleStatement> catchBody = ListFactory.newLinkedList();
/* 44:   */     
/* 45:   */ 
/* 46:   */ 
/* 47:43 */     int idx = allStatements.indexOf(catchStart) + 1;
/* 48:43 */     for (int len = allStatements.size(); idx < len; idx++)
/* 49:   */     {
/* 50:44 */       Op03SimpleStatement stm = (Op03SimpleStatement)allStatements.get(idx);
/* 51:45 */       boolean isNop = stm.getStatement() instanceof Nop;
/* 52:46 */       boolean contained = stm.getBlockIdentifiers().contains(catchBlockIdentifier);
/* 53:47 */       if ((!isNop) && (!contained)) {
/* 54:   */         break;
/* 55:   */       }
/* 56:48 */       if (contained) {
/* 57:48 */         catchBody.add(stm);
/* 58:   */       }
/* 59:   */     }
/* 60:51 */     if (catchBody.isEmpty()) {
/* 61:52 */       return new FinallyCatchBody(null, true, null, catchBody);
/* 62:   */     }
/* 63:54 */     ThrowStatement testThrow = new ThrowStatement(new LValueExpression(catchStatement.getCreatedLValue()));
/* 64:55 */     boolean hasThrow = false;
/* 65:56 */     Op03SimpleStatement throwOp = null;
/* 66:57 */     if (testThrow.equals(((Op03SimpleStatement)catchBody.getLast()).getStatement()))
/* 67:   */     {
/* 68:58 */       hasThrow = true;
/* 69:59 */       throwOp = (Op03SimpleStatement)catchBody.removeLast();
/* 70:   */     }
/* 71:61 */     return new FinallyCatchBody(throwOp, false, (Op03SimpleStatement)targets.get(0), catchBody);
/* 72:   */   }
/* 73:   */   
/* 74:   */   public boolean isEmpty()
/* 75:   */   {
/* 76:65 */     return this.isEmpty;
/* 77:   */   }
/* 78:   */   
/* 79:   */   public int getSize()
/* 80:   */   {
/* 81:69 */     return this.body.size();
/* 82:   */   }
/* 83:   */   
/* 84:   */   public Op03SimpleStatement getCatchCodeStart()
/* 85:   */   {
/* 86:73 */     return this.catchCodeStart;
/* 87:   */   }
/* 88:   */   
/* 89:   */   public Op03SimpleStatement getThrowOp()
/* 90:   */   {
/* 91:77 */     return this.throwOp;
/* 92:   */   }
/* 93:   */   
/* 94:   */   public boolean hasThrowOp()
/* 95:   */   {
/* 96:81 */     return this.throwOp != null;
/* 97:   */   }
/* 98:   */   
/* 99:   */   public boolean contains(Op03SimpleStatement stm)
/* :0:   */   {
/* :1:85 */     return this.bodySet.contains(stm);
/* :2:   */   }
/* :3:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.finalhelp.FinallyCatchBody
 * JD-Core Version:    0.7.0.1
 */