/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.rewriters;
/*  2:   */ 
/*  3:   */ import java.util.Map;
/*  4:   */ import java.util.Map.Entry;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackEntry;
/* 12:   */ import org.benf.cfr.reader.util.LazyMap;
/* 13:   */ import org.benf.cfr.reader.util.MapFactory;
/* 14:   */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/* 15:   */ 
/* 16:   */ public class AccountingRewriter
/* 17:   */   implements ExpressionRewriter
/* 18:   */ {
/* 19:18 */   private final Map<StackSSALabel, Long> count = new LazyMap(MapFactory.newLinkedMap(), new UnaryFunction()
/* 20:   */   {
/* 21:   */     public Long invoke(StackSSALabel arg)
/* 22:   */     {
/* 23:23 */       return new Long(0L);
/* 24:   */     }
/* 25:18 */   });
/* 26:   */   
/* 27:   */   public void handleStatement(StatementContainer statementContainer) {}
/* 28:   */   
/* 29:   */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 30:   */   {
/* 31:34 */     return expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public ConditionalExpression rewriteExpression(ConditionalExpression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 35:   */   {
/* 36:39 */     Expression res = expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 37:40 */     return (ConditionalExpression)res;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 41:   */   {
/* 42:51 */     if ((lValue instanceof StackSSALabel)) {
/* 43:52 */       return rewriteExpression((StackSSALabel)lValue, ssaIdentifiers, statementContainer, flags);
/* 44:   */     }
/* 45:54 */     return lValue.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 46:   */   }
/* 47:   */   
/* 48:   */   public StackSSALabel rewriteExpression(StackSSALabel lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 49:   */   {
/* 50:59 */     if (flags != ExpressionRewriterFlags.LVALUE) {
/* 51:61 */       this.count.put(lValue, Long.valueOf(((Long)this.count.get(lValue)).longValue() + 1L));
/* 52:   */     }
/* 53:63 */     return lValue;
/* 54:   */   }
/* 55:   */   
/* 56:   */   public void flush()
/* 57:   */   {
/* 58:67 */     for (Map.Entry<StackSSALabel, Long> entry : this.count.entrySet())
/* 59:   */     {
/* 60:69 */       StackSSALabel stackSSALabel = (StackSSALabel)entry.getKey();
/* 61:70 */       stackSSALabel.getStackEntry().forceUsageCount(((Long)entry.getValue()).longValue());
/* 62:   */     }
/* 63:   */   }
/* 64:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.rewriters.AccountingRewriter
 * JD-Core Version:    0.7.0.1
 */