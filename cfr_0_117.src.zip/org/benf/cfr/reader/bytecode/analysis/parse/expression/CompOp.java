/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*  4:   */ import org.benf.cfr.reader.bytecode.opcode.JVMInstr;
/*  5:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  6:   */ 
/*  7:   */ public enum CompOp
/*  8:   */ {
/*  9: 8 */   LT("<", Precedence.REL_CMP_INSTANCEOF),  GT(">", Precedence.REL_CMP_INSTANCEOF),  LTE("<=", Precedence.REL_CMP_INSTANCEOF),  GTE(">=", Precedence.REL_CMP_INSTANCEOF),  EQ("==", Precedence.REL_EQ),  NE("!=", Precedence.REL_EQ);
/* 10:   */   
/* 11:   */   private final String showAs;
/* 12:   */   private final Precedence precedence;
/* 13:   */   
/* 14:   */   private CompOp(String showAs, Precedence precedence)
/* 15:   */   {
/* 16:20 */     this.showAs = showAs;
/* 17:21 */     this.precedence = precedence;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public String getShowAs()
/* 21:   */   {
/* 22:25 */     return this.showAs;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public Precedence getPrecedence()
/* 26:   */   {
/* 27:29 */     return this.precedence;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public CompOp getInverted()
/* 31:   */   {
/* 32:33 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$expression$CompOp[ordinal()])
/* 33:   */     {
/* 34:   */     case 1: 
/* 35:35 */       return GTE;
/* 36:   */     case 2: 
/* 37:37 */       return LTE;
/* 38:   */     case 3: 
/* 39:39 */       return LT;
/* 40:   */     case 4: 
/* 41:41 */       return GT;
/* 42:   */     case 5: 
/* 43:43 */       return NE;
/* 44:   */     case 6: 
/* 45:45 */       return EQ;
/* 46:   */     }
/* 47:47 */     throw new ConfusedCFRException("Can't invert CompOp " + this);
/* 48:   */   }
/* 49:   */   
/* 50:   */   public static CompOp getOpFor(JVMInstr instr)
/* 51:   */   {
/* 52:53 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$opcode$JVMInstr[instr.ordinal()])
/* 53:   */     {
/* 54:   */     case 1: 
/* 55:   */     case 2: 
/* 56:56 */       return EQ;
/* 57:   */     case 3: 
/* 58:58 */       return LT;
/* 59:   */     case 4: 
/* 60:60 */       return GTE;
/* 61:   */     case 5: 
/* 62:62 */       return GT;
/* 63:   */     case 6: 
/* 64:   */     case 7: 
/* 65:65 */       return NE;
/* 66:   */     case 8: 
/* 67:67 */       return LTE;
/* 68:   */     case 9: 
/* 69:69 */       return EQ;
/* 70:   */     case 10: 
/* 71:71 */       return NE;
/* 72:   */     case 11: 
/* 73:73 */       return LTE;
/* 74:   */     case 12: 
/* 75:75 */       return LT;
/* 76:   */     case 13: 
/* 77:77 */       return GTE;
/* 78:   */     case 14: 
/* 79:79 */       return GT;
/* 80:   */     }
/* 81:81 */     throw new ConfusedCFRException("Don't know comparison op for " + instr);
/* 82:   */   }
/* 83:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.CompOp
 * JD-Core Version:    0.7.0.1
 */