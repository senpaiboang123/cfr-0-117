/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredComment;
/* 12:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 13:   */ 
/* 14:   */ public class JSRRetStatement
/* 15:   */   extends AbstractStatement
/* 16:   */ {
/* 17:   */   private Expression ret;
/* 18:   */   
/* 19:   */   public JSRRetStatement(Expression ret)
/* 20:   */   {
/* 21:15 */     this.ret = ret;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public Dumper dump(Dumper dumper)
/* 25:   */   {
/* 26:20 */     return dumper.print("Ret");
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers)
/* 30:   */   {
/* 31:25 */     this.ret = this.ret.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer());
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/* 35:   */   {
/* 36:30 */     this.ret = expressionRewriter.rewriteExpression(this.ret, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE);
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/* 40:   */   {
/* 41:35 */     this.ret.collectUsedLValues(lValueUsageCollector);
/* 42:   */   }
/* 43:   */   
/* 44:   */   public StructuredStatement getStructuredStatement()
/* 45:   */   {
/* 46:40 */     return new StructuredComment("JSR Ret");
/* 47:   */   }
/* 48:   */   
/* 49:   */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 50:   */   {
/* 51:46 */     if (o == null) {
/* 52:46 */       return false;
/* 53:   */     }
/* 54:47 */     if (o == this) {
/* 55:47 */       return true;
/* 56:   */     }
/* 57:48 */     if (getClass() != o.getClass()) {
/* 58:48 */       return false;
/* 59:   */     }
/* 60:49 */     JSRRetStatement other = (JSRRetStatement)o;
/* 61:50 */     if (!constraint.equivalent(this.ret, other.ret)) {
/* 62:50 */       return false;
/* 63:   */     }
/* 64:51 */     return true;
/* 65:   */   }
/* 66:   */   
/* 67:   */   public boolean fallsToNext()
/* 68:   */   {
/* 69:56 */     return false;
/* 70:   */   }
/* 71:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.JSRRetStatement
 * JD-Core Version:    0.7.0.1
 */