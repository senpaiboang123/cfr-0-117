package org.benf.cfr.reader.bytecode.analysis.parse.statement;

import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractAssignmentExpression;
import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithOp;

public abstract class AbstractAssignment
  extends AbstractStatement
{
  public abstract boolean isSelfMutatingOperation();
  
  public abstract boolean isSelfMutatingOp1(LValue paramLValue, ArithOp paramArithOp);
  
  public abstract Expression getPostMutation();
  
  public abstract AbstractAssignmentExpression getInliningExpression();
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.AbstractAssignment
 * JD-Core Version:    0.7.0.1
 */