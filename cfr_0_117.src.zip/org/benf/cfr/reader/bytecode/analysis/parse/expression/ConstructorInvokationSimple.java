/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.VarArgsRewriter;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface.FunctionProcessor;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.FieldVariable;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.SentinelLocalClassLValue;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.types.GenericTypeBinder;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.types.InnerClassInfo;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericBaseInstance;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  20:    */ import org.benf.cfr.reader.entities.ClassFileField;
/*  21:    */ import org.benf.cfr.reader.entities.classfilehelpers.OverloadMethodSet;
/*  22:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/*  23:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  24:    */ 
/*  25:    */ public class ConstructorInvokationSimple
/*  26:    */   extends AbstractConstructorInvokation
/*  27:    */   implements FunctionProcessor
/*  28:    */ {
/*  29:    */   private final MemberFunctionInvokation constructorInvokation;
/*  30:    */   
/*  31:    */   public ConstructorInvokationSimple(MemberFunctionInvokation constructorInvokation, InferredJavaType inferredJavaType, List<Expression> args)
/*  32:    */   {
/*  33: 27 */     super(inferredJavaType, constructorInvokation.getFunction(), args);
/*  34: 28 */     this.constructorInvokation = constructorInvokation;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  38:    */   {
/*  39: 33 */     return new ConstructorInvokationSimple(this.constructorInvokation, getInferredJavaType(), cloneHelper.replaceOrClone(getArgs()));
/*  40:    */   }
/*  41:    */   
/*  42:    */   public Precedence getPrecedence()
/*  43:    */   {
/*  44: 38 */     return Precedence.PAREN_SUB_MEMBER;
/*  45:    */   }
/*  46:    */   
/*  47:    */   private JavaTypeInstance getFinalDisplayTypeInstance()
/*  48:    */   {
/*  49: 42 */     JavaTypeInstance res = getTypeInstance();
/*  50: 43 */     if (!(res instanceof JavaGenericBaseInstance)) {
/*  51: 43 */       return res;
/*  52:    */     }
/*  53: 44 */     if (!((JavaGenericBaseInstance)res).hasL01Wildcard()) {
/*  54: 44 */       return res;
/*  55:    */     }
/*  56: 45 */     res = ((JavaGenericBaseInstance)res).getWithoutL01Wildcard();
/*  57: 46 */     return res;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public Dumper dumpInner(Dumper d)
/*  61:    */   {
/*  62: 51 */     JavaTypeInstance clazz = getFinalDisplayTypeInstance();
/*  63: 52 */     List<Expression> args = getArgs();
/*  64: 53 */     MethodPrototype prototype = this.constructorInvokation.getMethodPrototype();
/*  65: 55 */     if ((prototype.isInnerOuterThis()) && (prototype.isHiddenArg(0)) && (args.size() > 0))
/*  66:    */     {
/*  67: 56 */       Expression a1 = (Expression)args.get(0);
/*  68: 58 */       if (!a1.toString().equals("this"))
/*  69:    */       {
/*  70: 59 */         if ((a1 instanceof LValueExpression))
/*  71:    */         {
/*  72: 60 */           LValue lValue = ((LValueExpression)a1).getLValue();
/*  73: 61 */           if ((lValue instanceof FieldVariable))
/*  74:    */           {
/*  75: 62 */             ClassFileField classFileField = ((FieldVariable)lValue).getClassFileField();
/*  76: 63 */             if (classFileField.isSyntheticOuterRef()) {
/*  77:    */               break label133;
/*  78:    */             }
/*  79:    */           }
/*  80:    */         }
/*  81: 66 */         d.dump(a1).print('.');
/*  82:    */       }
/*  83:    */     }
/*  84:    */     label133:
/*  85: 70 */     d.print("new ").dump(clazz).print("(");
/*  86: 71 */     boolean first = true;
/*  87: 72 */     for (int i = 0; i < args.size(); i++) {
/*  88: 73 */       if (!prototype.isHiddenArg(i))
/*  89:    */       {
/*  90: 74 */         Expression arg = (Expression)args.get(i);
/*  91: 75 */         if (!first) {
/*  92: 75 */           d.print(", ");
/*  93:    */         }
/*  94: 76 */         first = false;
/*  95: 77 */         d.dump(arg);
/*  96:    */       }
/*  97:    */     }
/*  98: 79 */     d.print(")");
/*  99: 80 */     return d;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public boolean equals(Object o)
/* 103:    */   {
/* 104: 85 */     if (o == this) {
/* 105: 85 */       return true;
/* 106:    */     }
/* 107: 86 */     if (o == null) {
/* 108: 86 */       return false;
/* 109:    */     }
/* 110: 87 */     if (!(o instanceof ConstructorInvokationSimple)) {
/* 111: 87 */       return false;
/* 112:    */     }
/* 113: 89 */     return super.equals(o);
/* 114:    */   }
/* 115:    */   
/* 116:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/* 117:    */   {
/* 118: 94 */     JavaTypeInstance lValueType = this.constructorInvokation.getClassTypeInstance();
/* 119: 95 */     InnerClassInfo innerClassInfo = lValueType.getInnerClassHereInfo();
/* 120: 97 */     if ((innerClassInfo.isMethodScopedClass()) && (!innerClassInfo.isAnonymousClass())) {
/* 121: 98 */       lValueUsageCollector.collect(new SentinelLocalClassLValue(lValueType));
/* 122:    */     }
/* 123:101 */     super.collectUsedLValues(lValueUsageCollector);
/* 124:    */   }
/* 125:    */   
/* 126:    */   public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 127:    */   {
/* 128:107 */     if (!(o instanceof ConstructorInvokationSimple)) {
/* 129:107 */       return false;
/* 130:    */     }
/* 131:108 */     if (!super.equivalentUnder(o, constraint)) {
/* 132:108 */       return false;
/* 133:    */     }
/* 134:109 */     return true;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public boolean canThrow(ExceptionCheck caught)
/* 138:    */   {
/* 139:114 */     return caught.checkAgainst(this.constructorInvokation);
/* 140:    */   }
/* 141:    */   
/* 142:    */   public void rewriteVarArgs(VarArgsRewriter varArgsRewriter)
/* 143:    */   {
/* 144:119 */     MethodPrototype methodPrototype = getMethodPrototype();
/* 145:120 */     if (!methodPrototype.isVarArgs()) {
/* 146:120 */       return;
/* 147:    */     }
/* 148:121 */     OverloadMethodSet overloadMethodSet = getOverloadMethodSet();
/* 149:122 */     if (overloadMethodSet == null) {
/* 150:122 */       return;
/* 151:    */     }
/* 152:123 */     GenericTypeBinder gtb = methodPrototype.getTypeBinderFor(getArgs());
/* 153:124 */     varArgsRewriter.rewriteVarArgsArg(overloadMethodSet, methodPrototype, getArgs(), gtb);
/* 154:    */   }
/* 155:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationSimple
 * JD-Core Version:    0.7.0.1
 */