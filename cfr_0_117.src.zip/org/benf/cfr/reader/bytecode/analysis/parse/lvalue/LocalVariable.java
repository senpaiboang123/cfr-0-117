/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.lvalue;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentCollector;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifierFactory;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.types.annotated.JavaAnnotatedTypeInstance;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.variables.Ident;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.variables.NamedVariable;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.variables.NamedVariableDefault;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.variables.VariableNamer;
/*  20:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/*  21:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  22:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  23:    */ 
/*  24:    */ public class LocalVariable
/*  25:    */   extends AbstractLValue
/*  26:    */ {
/*  27:    */   private final NamedVariable name;
/*  28:    */   private final int idx;
/*  29:    */   private final Ident ident;
/*  30:    */   private boolean guessedFinal;
/*  31:    */   private final int originalRawOffset;
/*  32:    */   private JavaAnnotatedTypeInstance customCreationType;
/*  33:    */   
/*  34:    */   public LocalVariable(int stackPosition, Ident ident, VariableNamer variableNamer, int originalRawOffset, InferredJavaType inferredJavaType)
/*  35:    */   {
/*  36: 31 */     super(inferredJavaType);
/*  37: 32 */     this.name = variableNamer.getName(originalRawOffset, ident, stackPosition);
/*  38: 33 */     this.idx = stackPosition;
/*  39: 34 */     this.ident = ident;
/*  40: 35 */     this.guessedFinal = false;
/*  41: 36 */     this.originalRawOffset = originalRawOffset;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public LocalVariable(String name, InferredJavaType inferredJavaType)
/*  45:    */   {
/*  46: 40 */     super(inferredJavaType);
/*  47: 41 */     this.name = new NamedVariableDefault(name);
/*  48: 42 */     this.idx = -1;
/*  49: 43 */     this.ident = null;
/*  50: 44 */     this.guessedFinal = false;
/*  51: 45 */     this.originalRawOffset = -1;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public int getOriginalRawOffset()
/*  55:    */   {
/*  56: 49 */     return this.originalRawOffset;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public int getNumberOfCreators()
/*  60:    */   {
/*  61: 54 */     throw new ConfusedCFRException("NYI");
/*  62:    */   }
/*  63:    */   
/*  64:    */   public boolean isFinal()
/*  65:    */   {
/*  66: 59 */     return this.guessedFinal;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void markFinal()
/*  70:    */   {
/*  71: 64 */     this.guessedFinal = true;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void setCustomCreationType(JavaAnnotatedTypeInstance customCreationType)
/*  75:    */   {
/*  76: 70 */     this.customCreationType = customCreationType;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public JavaAnnotatedTypeInstance getAnnotatedCreationType()
/*  80:    */   {
/*  81: 75 */     return this.customCreationType;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public LValue deepClone(CloneHelper cloneHelper)
/*  85:    */   {
/*  86: 83 */     return this;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public Precedence getPrecedence()
/*  90:    */   {
/*  91: 88 */     return Precedence.HIGHEST;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public Dumper dumpInner(Dumper d)
/*  95:    */   {
/*  96: 93 */     return this.name.dump(d).print(typeToString());
/*  97:    */   }
/*  98:    */   
/*  99:    */   public NamedVariable getName()
/* 100:    */   {
/* 101: 97 */     return this.name;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public int getIdx()
/* 105:    */   {
/* 106:101 */     return this.idx;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public boolean canThrow(ExceptionCheck caught)
/* 110:    */   {
/* 111:106 */     return false;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public <T> void collectLValueAssignments(Expression assignedTo, StatementContainer<T> statementContainer, LValueAssignmentCollector<T> lValueAssigmentCollector)
/* 115:    */   {
/* 116:111 */     lValueAssigmentCollector.collectLocalVariableAssignment(this, statementContainer, assignedTo);
/* 117:    */   }
/* 118:    */   
/* 119:    */   public LValue replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/* 120:    */   {
/* 121:116 */     return this;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public SSAIdentifiers<LValue> collectVariableMutation(SSAIdentifierFactory<LValue> ssaIdentifierFactory)
/* 125:    */   {
/* 126:121 */     return new SSAIdentifiers(this, ssaIdentifierFactory);
/* 127:    */   }
/* 128:    */   
/* 129:    */   public LValue applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 130:    */   {
/* 131:126 */     return this;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public boolean equals(Object o)
/* 135:    */   {
/* 136:131 */     if (this == o) {
/* 137:131 */       return true;
/* 138:    */     }
/* 139:132 */     if (!(o instanceof LocalVariable)) {
/* 140:132 */       return false;
/* 141:    */     }
/* 142:134 */     LocalVariable that = (LocalVariable)o;
/* 143:136 */     if (!this.name.equals(that.name)) {
/* 144:136 */       return false;
/* 145:    */     }
/* 146:137 */     if (this.idx != that.idx) {
/* 147:138 */       return false;
/* 148:    */     }
/* 149:140 */     if (this.ident == null)
/* 150:    */     {
/* 151:141 */       if (that.ident != null) {
/* 152:141 */         return false;
/* 153:    */       }
/* 154:    */     }
/* 155:143 */     else if (!this.ident.equals(that.ident)) {
/* 156:143 */       return false;
/* 157:    */     }
/* 158:146 */     return true;
/* 159:    */   }
/* 160:    */   
/* 161:    */   public int hashCode()
/* 162:    */   {
/* 163:151 */     int result = this.name.hashCode();
/* 164:152 */     result = 31 * result + this.idx;
/* 165:153 */     if (this.ident != null) {
/* 166:153 */       result = 31 * result + this.ident.hashCode();
/* 167:    */     }
/* 168:154 */     return result;
/* 169:    */   }
/* 170:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable
 * JD-Core Version:    0.7.0.1
 */