/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  8:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  9:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodRef;
/* 10:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 11:   */ 
/* 12:   */ public class SuperFunctionInvokation
/* 13:   */   extends AbstractMemberFunctionInvokation
/* 14:   */ {
/* 15:   */   public SuperFunctionInvokation(ConstantPool cp, ConstantPoolEntryMethodRef function, Expression object, List<Expression> args, List<Boolean> nulls)
/* 16:   */   {
/* 17:18 */     super(cp, function, object, args, nulls);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public Expression deepClone(CloneHelper cloneHelper)
/* 21:   */   {
/* 22:23 */     return new SuperFunctionInvokation(getCp(), getFunction(), cloneHelper.replaceOrClone(getObject()), cloneHelper.replaceOrClone(getArgs()), getNulls());
/* 23:   */   }
/* 24:   */   
/* 25:   */   public boolean isEmptyIgnoringSynthetics()
/* 26:   */   {
/* 27:27 */     MethodPrototype prototype = getMethodPrototype();
/* 28:28 */     int i = 0;
/* 29:28 */     for (int len = prototype.getArgs().size(); i < len; i++) {
/* 30:29 */       if (!prototype.isHiddenArg(i)) {
/* 31:29 */         return false;
/* 32:   */       }
/* 33:   */     }
/* 34:31 */     return true;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public Precedence getPrecedence()
/* 38:   */   {
/* 39:36 */     return Precedence.PAREN_SUB_MEMBER;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public Dumper dumpInner(Dumper d)
/* 43:   */   {
/* 44:41 */     MethodPrototype methodPrototype = getMethodPrototype();
/* 45:42 */     List<Expression> args = getArgs();
/* 46:43 */     if (methodPrototype.getName().equals("<init>")) {
/* 47:44 */       d.print("super(");
/* 48:   */     } else {
/* 49:46 */       d.print("super.").print(methodPrototype.getFixedName()).print("(");
/* 50:   */     }
/* 51:48 */     boolean first = true;
/* 52:50 */     for (int x = 0; x < args.size(); x++) {
/* 53:51 */       if (!methodPrototype.isHiddenArg(x))
/* 54:   */       {
/* 55:52 */         Expression arg = (Expression)args.get(x);
/* 56:53 */         if (!first) {
/* 57:53 */           d.print(", ");
/* 58:   */         }
/* 59:54 */         first = false;
/* 60:55 */         methodPrototype.dumpAppropriatelyCastedArgumentString(arg, x, d);
/* 61:   */       }
/* 62:   */     }
/* 63:57 */     d.print(")");
/* 64:58 */     return d;
/* 65:   */   }
/* 66:   */   
/* 67:   */   public String getName()
/* 68:   */   {
/* 69:62 */     return "super";
/* 70:   */   }
/* 71:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.SuperFunctionInvokation
 * JD-Core Version:    0.7.0.1
 */