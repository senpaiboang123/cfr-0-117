/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.utils;
/*  2:   */ 
/*  3:   */ public enum JumpType
/*  4:   */ {
/*  5: 4 */   NONE("none", false),  GOTO("goto", true),  GOTO_OUT_OF_IF("goto_out_of_if", false),  GOTO_OUT_OF_TRY("goto_out_of_try", false),  BREAK("break", false),  BREAK_ANONYMOUS("break anon", false),  CONTINUE("continue", false),  END_BLOCK("// endblock", false);
/*  6:   */   
/*  7:   */   private final String description;
/*  8:   */   private final boolean isUnknown;
/*  9:   */   
/* 10:   */   private JumpType(String description, boolean isUnknown)
/* 11:   */   {
/* 12:18 */     this.description = description;
/* 13:19 */     this.isUnknown = isUnknown;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public boolean isUnknown()
/* 17:   */   {
/* 18:23 */     return this.isUnknown;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String toString()
/* 22:   */   {
/* 23:28 */     return this.description;
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.JumpType
 * JD-Core Version:    0.7.0.1
 */