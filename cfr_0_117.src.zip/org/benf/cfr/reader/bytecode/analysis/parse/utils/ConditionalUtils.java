/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.utils;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.TernaryExpression;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 10:   */ 
/* 11:   */ public class ConditionalUtils
/* 12:   */ {
/* 13:   */   public static ConditionalExpression simplify(ConditionalExpression condition)
/* 14:   */   {
/* 15:13 */     ConditionalExpression applyDemorgan = condition.getDemorganApplied(false);
/* 16:14 */     int demorganSize = applyDemorgan.getSize(Precedence.WEAKEST);
/* 17:15 */     int conditionSize = condition.getSize(Precedence.WEAKEST);
/* 18:16 */     if (demorganSize < conditionSize) {
/* 19:17 */       condition = applyDemorgan;
/* 20:   */     }
/* 21:22 */     condition = condition.getRightDeep();
/* 22:23 */     return condition;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public static Expression simplify(TernaryExpression condition)
/* 26:   */   {
/* 27:27 */     if (condition.getInferredJavaType().getRawType() != RawJavaType.BOOLEAN) {
/* 28:27 */       return condition;
/* 29:   */     }
/* 30:28 */     Expression e1 = condition.getLhs();
/* 31:29 */     Expression e2 = condition.getRhs();
/* 32:30 */     ConditionalExpression pred = condition.getCondition();
/* 33:31 */     if ((!e1.equals(Literal.TRUE)) || (!e2.equals(Literal.FALSE))) {
/* 34:33 */       if ((e1.equals(Literal.FALSE)) && (e2.equals(Literal.TRUE))) {
/* 35:34 */         pred = pred.getNegated();
/* 36:   */       } else {
/* 37:36 */         return condition;
/* 38:   */       }
/* 39:   */     }
/* 40:38 */     return simplify(pred);
/* 41:   */   }
/* 42:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.ConditionalUtils
 * JD-Core Version:    0.7.0.1
 */