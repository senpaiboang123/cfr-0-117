/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 11:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodRef;
/* 12:   */ 
/* 13:   */ public abstract class AbstractFunctionInvokation
/* 14:   */   extends AbstractExpression
/* 15:   */ {
/* 16:   */   private final ConstantPoolEntryMethodRef function;
/* 17:   */   private final MethodPrototype methodPrototype;
/* 18:   */   
/* 19:   */   protected AbstractFunctionInvokation(ConstantPoolEntryMethodRef function, InferredJavaType inferredJavaType)
/* 20:   */   {
/* 21:19 */     super(inferredJavaType);
/* 22:20 */     this.function = function;
/* 23:21 */     this.methodPrototype = function.getMethodPrototype();
/* 24:   */   }
/* 25:   */   
/* 26:   */   public abstract void applyExpressionRewriterToArgs(ExpressionRewriter paramExpressionRewriter, SSAIdentifiers paramSSAIdentifiers, StatementContainer paramStatementContainer, ExpressionRewriterFlags paramExpressionRewriterFlags);
/* 27:   */   
/* 28:   */   public abstract void setExplicitGenerics(List<JavaTypeInstance> paramList);
/* 29:   */   
/* 30:   */   public abstract List<JavaTypeInstance> getExplicitGenerics();
/* 31:   */   
/* 32:   */   public ConstantPoolEntryMethodRef getFunction()
/* 33:   */   {
/* 34:31 */     return this.function;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public MethodPrototype getMethodPrototype()
/* 38:   */   {
/* 39:34 */     return this.methodPrototype;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public String getName()
/* 43:   */   {
/* 44:37 */     return this.methodPrototype.getName();
/* 45:   */   }
/* 46:   */   
/* 47:   */   public String getFixedName()
/* 48:   */   {
/* 49:41 */     return this.methodPrototype.getFixedName();
/* 50:   */   }
/* 51:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractFunctionInvokation
 * JD-Core Version:    0.7.0.1
 */