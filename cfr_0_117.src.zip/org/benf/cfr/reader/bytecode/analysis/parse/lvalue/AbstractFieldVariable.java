/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.lvalue;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentCollector;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifierFactory;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  13:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  14:    */ import org.benf.cfr.reader.entities.ClassFileField;
/*  15:    */ import org.benf.cfr.reader.entities.Field;
/*  16:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/*  17:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass;
/*  18:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryFieldRef;
/*  19:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  20:    */ import org.benf.cfr.reader.util.CannotLoadClassException;
/*  21:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  22:    */ 
/*  23:    */ public abstract class AbstractFieldVariable
/*  24:    */   extends AbstractLValue
/*  25:    */ {
/*  26:    */   private final ClassFileField classFileField;
/*  27:    */   private final String failureName;
/*  28:    */   private final JavaTypeInstance owningClass;
/*  29:    */   
/*  30:    */   public AbstractFieldVariable(ConstantPoolEntry field)
/*  31:    */   {
/*  32: 28 */     super(getFieldType((ConstantPoolEntryFieldRef)field));
/*  33: 29 */     ConstantPoolEntryFieldRef fieldRef = (ConstantPoolEntryFieldRef)field;
/*  34: 30 */     this.classFileField = getField(fieldRef);
/*  35: 31 */     this.failureName = fieldRef.getLocalName();
/*  36: 32 */     this.owningClass = fieldRef.getClassEntry().getTypeInstance();
/*  37:    */   }
/*  38:    */   
/*  39:    */   protected AbstractFieldVariable(AbstractFieldVariable other)
/*  40:    */   {
/*  41: 36 */     super(other.getInferredJavaType());
/*  42: 37 */     this.classFileField = other.classFileField;
/*  43: 38 */     this.failureName = other.failureName;
/*  44: 39 */     this.owningClass = other.owningClass;
/*  45:    */   }
/*  46:    */   
/*  47:    */   protected AbstractFieldVariable(InferredJavaType type, JavaTypeInstance clazz, String varName)
/*  48:    */   {
/*  49: 43 */     super(type);
/*  50: 44 */     this.classFileField = null;
/*  51: 45 */     this.owningClass = clazz;
/*  52: 46 */     this.failureName = varName;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  56:    */   {
/*  57: 51 */     super.collectTypeUsages(collector);
/*  58: 52 */     if (this.classFileField != null) {
/*  59: 52 */       collector.collect(this.classFileField.getField().getJavaTypeInstance());
/*  60:    */     }
/*  61: 53 */     collector.collect(this.owningClass);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void markFinal() {}
/*  65:    */   
/*  66:    */   public boolean isFinal()
/*  67:    */   {
/*  68: 63 */     return false;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public int getNumberOfCreators()
/*  72:    */   {
/*  73: 68 */     throw new ConfusedCFRException("NYI");
/*  74:    */   }
/*  75:    */   
/*  76:    */   public JavaTypeInstance getOwningClassType()
/*  77:    */   {
/*  78: 72 */     return this.owningClass;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public String getFieldName()
/*  82:    */   {
/*  83: 76 */     if (this.classFileField == null) {
/*  84: 77 */       return this.failureName;
/*  85:    */     }
/*  86: 79 */     return this.classFileField.getFieldName();
/*  87:    */   }
/*  88:    */   
/*  89:    */   public ClassFileField getClassFileField()
/*  90:    */   {
/*  91: 83 */     return this.classFileField;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public SSAIdentifiers<LValue> collectVariableMutation(SSAIdentifierFactory<LValue> ssaIdentifierFactory)
/*  95:    */   {
/*  96: 88 */     return new SSAIdentifiers(this, ssaIdentifierFactory);
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void collectLValueAssignments(Expression assignedTo, StatementContainer statementContainer, LValueAssignmentCollector lValueAssigmentCollector) {}
/* 100:    */   
/* 101:    */   public static ClassFileField getField(ConstantPoolEntryFieldRef fieldRef)
/* 102:    */   {
/* 103: 97 */     String name = fieldRef.getLocalName();
/* 104: 98 */     JavaRefTypeInstance ref = (JavaRefTypeInstance)fieldRef.getClassEntry().getTypeInstance();
/* 105:    */     try
/* 106:    */     {
/* 107:100 */       ClassFile classFile = ref.getClassFile();
/* 108:101 */       if (classFile == null) {
/* 109:101 */         return null;
/* 110:    */       }
/* 111:103 */       return classFile.getFieldByName(name, fieldRef.getJavaTypeInstance());
/* 112:    */     }
/* 113:    */     catch (NoSuchFieldException ignore) {}catch (CannotLoadClassException ignore) {}
/* 114:108 */     return null;
/* 115:    */   }
/* 116:    */   
/* 117:    */   static InferredJavaType getFieldType(ConstantPoolEntryFieldRef fieldRef)
/* 118:    */   {
/* 119:113 */     String name = fieldRef.getLocalName();
/* 120:114 */     JavaRefTypeInstance ref = (JavaRefTypeInstance)fieldRef.getClassEntry().getTypeInstance();
/* 121:    */     try
/* 122:    */     {
/* 123:116 */       ClassFile classFile = ref.getClassFile();
/* 124:117 */       if (classFile != null)
/* 125:    */       {
/* 126:119 */         Field field = classFile.getFieldByName(name, fieldRef.getJavaTypeInstance()).getField();
/* 127:120 */         return new InferredJavaType(field.getJavaTypeInstance(), InferredJavaType.Source.FIELD);
/* 128:    */       }
/* 129:    */     }
/* 130:    */     catch (CannotLoadClassException e) {}catch (NoSuchFieldException ignore) {}
/* 131:125 */     return new InferredJavaType(fieldRef.getJavaTypeInstance(), InferredJavaType.Source.FIELD);
/* 132:    */   }
/* 133:    */   
/* 134:    */   public boolean equals(Object o)
/* 135:    */   {
/* 136:130 */     if (this == o) {
/* 137:130 */       return true;
/* 138:    */     }
/* 139:131 */     if (!(o instanceof AbstractFieldVariable)) {
/* 140:131 */       return false;
/* 141:    */     }
/* 142:133 */     AbstractFieldVariable that = (AbstractFieldVariable)o;
/* 143:135 */     if (!getFieldName().equals(that.getFieldName())) {
/* 144:135 */       return false;
/* 145:    */     }
/* 146:136 */     if (this.owningClass != null ? !this.owningClass.equals(that.owningClass) : that.owningClass != null) {
/* 147:136 */       return false;
/* 148:    */     }
/* 149:138 */     return true;
/* 150:    */   }
/* 151:    */   
/* 152:    */   public int hashCode()
/* 153:    */   {
/* 154:143 */     int result = getFieldName().hashCode();
/* 155:144 */     result = 31 * result + (this.owningClass != null ? this.owningClass.hashCode() : 0);
/* 156:145 */     return result;
/* 157:    */   }
/* 158:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.lvalue.AbstractFieldVariable
 * JD-Core Version:    0.7.0.1
 */