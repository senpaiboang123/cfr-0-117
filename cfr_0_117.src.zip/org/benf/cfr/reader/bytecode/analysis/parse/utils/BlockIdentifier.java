/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.utils;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Set;
/*   7:    */ import org.benf.cfr.reader.util.Functional;
/*   8:    */ import org.benf.cfr.reader.util.ListFactory;
/*   9:    */ import org.benf.cfr.reader.util.Predicate;
/*  10:    */ 
/*  11:    */ public class BlockIdentifier
/*  12:    */   implements Comparable<BlockIdentifier>
/*  13:    */ {
/*  14:    */   private final int index;
/*  15:    */   private BlockType blockType;
/*  16: 16 */   private int knownForeignReferences = 0;
/*  17:    */   
/*  18:    */   public BlockIdentifier(int index, BlockType blockType)
/*  19:    */   {
/*  20: 19 */     this.index = index;
/*  21: 20 */     this.blockType = blockType;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public BlockType getBlockType()
/*  25:    */   {
/*  26: 24 */     return this.blockType;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void setBlockType(BlockType blockType)
/*  30:    */   {
/*  31: 28 */     this.blockType = blockType;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public String getName()
/*  35:    */   {
/*  36: 32 */     return "block" + this.index;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public int getIndex()
/*  40:    */   {
/*  41: 36 */     return this.index;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void addForeignRef()
/*  45:    */   {
/*  46: 40 */     this.knownForeignReferences += 1;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void releaseForeignRef()
/*  50:    */   {
/*  51: 44 */     this.knownForeignReferences -= 1;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public boolean hasForeignReferences()
/*  55:    */   {
/*  56: 48 */     return this.knownForeignReferences > 0;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public String toString()
/*  60:    */   {
/*  61: 53 */     return "" + this.index + "[" + this.blockType + "]";
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static boolean blockIsOneOf(BlockIdentifier needle, Set<BlockIdentifier> haystack)
/*  65:    */   {
/*  66: 57 */     return haystack.contains(needle);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static BlockIdentifier getOutermostContainedIn(Set<BlockIdentifier> endingBlocks, Set<BlockIdentifier> blocksInAtThisPoint)
/*  70:    */   {
/*  71: 61 */     List<BlockIdentifier> containedIn = Functional.filter(ListFactory.newList(endingBlocks), new Predicate()
/*  72:    */     {
/*  73:    */       public boolean test(BlockIdentifier in)
/*  74:    */       {
/*  75: 64 */         return this.val$blocksInAtThisPoint.contains(in);
/*  76:    */       }
/*  77:    */     });
/*  78: 67 */     if (containedIn.isEmpty()) {
/*  79: 67 */       return null;
/*  80:    */     }
/*  81: 68 */     Collections.sort(containedIn);
/*  82: 69 */     return (BlockIdentifier)containedIn.get(0);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static BlockIdentifier getInnermostBreakable(List<BlockIdentifier> blocks)
/*  86:    */   {
/*  87: 74 */     BlockIdentifier res = null;
/*  88: 75 */     for (BlockIdentifier block : blocks) {
/*  89: 76 */       if (block.blockType.isBreakable()) {
/*  90: 76 */         res = block;
/*  91:    */       }
/*  92:    */     }
/*  93: 78 */     return res;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public static BlockIdentifier getOutermostEnding(List<BlockIdentifier> blocks, Set<BlockIdentifier> blocksEnding)
/*  97:    */   {
/*  98: 85 */     for (BlockIdentifier blockIdentifier : blocks) {
/*  99: 86 */       if (blocksEnding.contains(blockIdentifier)) {
/* 100: 86 */         return blockIdentifier;
/* 101:    */       }
/* 102:    */     }
/* 103: 88 */     return null;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public static boolean isInAllBlocks(Collection<BlockIdentifier> mustBeIn, Collection<BlockIdentifier> isIn)
/* 107:    */   {
/* 108: 93 */     for (BlockIdentifier must : mustBeIn) {
/* 109: 94 */       if (!isIn.contains(must)) {
/* 110: 94 */         return false;
/* 111:    */       }
/* 112:    */     }
/* 113: 96 */     return true;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public static boolean isInAnyBlock(Collection<BlockIdentifier> mustBeInOneOf, Collection<BlockIdentifier> isIn)
/* 117:    */   {
/* 118:100 */     for (BlockIdentifier block : isIn) {
/* 119:101 */       if (mustBeInOneOf.contains(block)) {
/* 120:101 */         return true;
/* 121:    */       }
/* 122:    */     }
/* 123:103 */     return false;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public int compareTo(BlockIdentifier blockIdentifier)
/* 127:    */   {
/* 128:108 */     return this.index - blockIdentifier.index;
/* 129:    */   }
/* 130:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier
 * JD-Core Version:    0.7.0.1
 */