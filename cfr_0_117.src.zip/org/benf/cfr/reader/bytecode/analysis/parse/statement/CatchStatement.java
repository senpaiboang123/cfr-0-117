/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentCollector;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredCatch;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  20:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionGroup.Entry;
/*  21:    */ import org.benf.cfr.reader.util.Functional;
/*  22:    */ import org.benf.cfr.reader.util.Predicate;
/*  23:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  24:    */ 
/*  25:    */ public class CatchStatement
/*  26:    */   extends AbstractStatement
/*  27:    */ {
/*  28:    */   private final List<ExceptionGroup.Entry> exceptions;
/*  29:    */   private BlockIdentifier catchBlockIdent;
/*  30:    */   private LValue catching;
/*  31:    */   
/*  32:    */   public CatchStatement(List<ExceptionGroup.Entry> exceptions, LValue catching)
/*  33:    */   {
/*  34: 26 */     this.exceptions = exceptions;
/*  35: 27 */     this.catching = catching;
/*  36: 28 */     if (!exceptions.isEmpty())
/*  37:    */     {
/*  38: 29 */       JavaTypeInstance collapsedCatchType = determineType(exceptions);
/*  39: 30 */       InferredJavaType catchType = new InferredJavaType(collapsedCatchType, InferredJavaType.Source.EXCEPTION, true);
/*  40: 31 */       this.catching.getInferredJavaType().chain(catchType);
/*  41:    */     }
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static JavaTypeInstance determineType(List<ExceptionGroup.Entry> exceptions)
/*  45:    */   {
/*  46: 36 */     InferredJavaType ijt = new InferredJavaType();
/*  47: 37 */     ijt.chain(new InferredJavaType(((ExceptionGroup.Entry)exceptions.get(0)).getCatchType(), InferredJavaType.Source.EXCEPTION));
/*  48: 38 */     int x = 1;
/*  49: 38 */     for (int len = exceptions.size(); x < len; x++) {
/*  50: 39 */       ijt.chain(new InferredJavaType(((ExceptionGroup.Entry)exceptions.get(x)).getCatchType(), InferredJavaType.Source.EXCEPTION));
/*  51:    */     }
/*  52: 41 */     if (ijt.isClash()) {
/*  53: 42 */       ijt.collapseTypeClash();
/*  54:    */     }
/*  55: 44 */     return ijt.getJavaTypeInstance();
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void removeCatchBlockFor(final BlockIdentifier tryBlockIdent)
/*  59:    */   {
/*  60: 48 */     List<ExceptionGroup.Entry> toRemove = Functional.filter(this.exceptions, new Predicate()
/*  61:    */     {
/*  62:    */       public boolean test(ExceptionGroup.Entry in)
/*  63:    */       {
/*  64: 51 */         return in.getTryBlockIdentifier().equals(tryBlockIdent);
/*  65:    */       }
/*  66: 53 */     });
/*  67: 54 */     this.exceptions.removeAll(toRemove);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public Dumper dump(Dumper dumper)
/*  71:    */   {
/*  72: 59 */     return dumper.print("catch ( " + this.exceptions + " ").dump(this.catching).print(" ) {\n");
/*  73:    */   }
/*  74:    */   
/*  75:    */   public BlockIdentifier getCatchBlockIdent()
/*  76:    */   {
/*  77: 63 */     return this.catchBlockIdent;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void setCatchBlockIdent(BlockIdentifier catchBlockIdent)
/*  81:    */   {
/*  82: 67 */     this.catchBlockIdent = catchBlockIdent;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers) {}
/*  86:    */   
/*  87:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/*  88:    */   {
/*  89: 76 */     this.catching = expressionRewriter.rewriteExpression(this.catching, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.LVALUE);
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector) {}
/*  93:    */   
/*  94:    */   public void collectLValueAssignments(LValueAssignmentCollector<Statement> lValueAssigmentCollector)
/*  95:    */   {
/*  96: 85 */     if ((this.catching instanceof LocalVariable)) {
/*  97: 86 */       lValueAssigmentCollector.collectLocalVariableAssignment((LocalVariable)this.catching, getContainer(), null);
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   public LValue getCreatedLValue()
/* 102:    */   {
/* 103: 92 */     return this.catching;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public List<ExceptionGroup.Entry> getExceptions()
/* 107:    */   {
/* 108: 97 */     return this.exceptions;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public StructuredStatement getStructuredStatement()
/* 112:    */   {
/* 113:102 */     return new UnstructuredCatch(this.exceptions, this.catchBlockIdent, this.catching);
/* 114:    */   }
/* 115:    */   
/* 116:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 117:    */   {
/* 118:107 */     if (o == null) {
/* 119:107 */       return false;
/* 120:    */     }
/* 121:108 */     if (o == this) {
/* 122:108 */       return true;
/* 123:    */     }
/* 124:109 */     if (getClass() != o.getClass()) {
/* 125:109 */       return false;
/* 126:    */     }
/* 127:110 */     CatchStatement other = (CatchStatement)o;
/* 128:111 */     if (!constraint.equivalent(this.exceptions, other.exceptions)) {
/* 129:111 */       return false;
/* 130:    */     }
/* 131:112 */     if (!constraint.equivalent(this.catching, other.catching)) {
/* 132:112 */       return false;
/* 133:    */     }
/* 134:113 */     return true;
/* 135:    */   }
/* 136:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.CatchStatement
 * JD-Core Version:    0.7.0.1
 */