/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import java.util.Map;
/*   4:    */ import java.util.Set;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.PrimitiveBoxingRewriter;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface.BoxingProcessor;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral.LiteralType;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.ConditionalUtils;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  25:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/*  26:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  27:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  28:    */ import org.benf.cfr.reader.util.SetFactory;
/*  29:    */ import org.benf.cfr.reader.util.Troolean;
/*  30:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  31:    */ 
/*  32:    */ public class ComparisonOperation
/*  33:    */   extends AbstractExpression
/*  34:    */   implements ConditionalExpression, BoxingProcessor
/*  35:    */ {
/*  36:    */   private Expression lhs;
/*  37:    */   private Expression rhs;
/*  38:    */   private final CompOp op;
/*  39:    */   
/*  40:    */   public ComparisonOperation(Expression lhs, Expression rhs, CompOp op)
/*  41:    */   {
/*  42: 32 */     super(new InferredJavaType(RawJavaType.BOOLEAN, InferredJavaType.Source.EXPRESSION));
/*  43: 33 */     this.lhs = lhs;
/*  44: 34 */     this.rhs = rhs;
/*  45:    */     
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72: 62 */     boolean lLiteral = lhs instanceof Literal;
/*  73: 63 */     boolean rLiteral = rhs instanceof Literal;
/*  74:    */     
/*  75: 65 */     InferredJavaType.compareAsWithoutCasting(lhs.getInferredJavaType(), rhs.getInferredJavaType(), lLiteral, rLiteral);
/*  76: 66 */     this.op = op;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  80:    */   {
/*  81: 71 */     return new ComparisonOperation(cloneHelper.replaceOrClone(this.lhs), cloneHelper.replaceOrClone(this.rhs), this.op);
/*  82:    */   }
/*  83:    */   
/*  84:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  85:    */   {
/*  86: 76 */     this.lhs.collectTypeUsages(collector);
/*  87: 77 */     this.rhs.collectTypeUsages(collector);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public int getSize(Precedence outerPrecedence)
/*  91:    */   {
/*  92: 82 */     return 3;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public Precedence getPrecedence()
/*  96:    */   {
/*  97: 87 */     return this.op.getPrecedence();
/*  98:    */   }
/*  99:    */   
/* 100:    */   public Dumper dumpInner(Dumper d)
/* 101:    */   {
/* 102: 92 */     this.lhs.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.TRUE);
/* 103: 93 */     d.print(" ").print(this.op.getShowAs()).print(" ");
/* 104: 94 */     this.rhs.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.FALSE);
/* 105: 95 */     return d;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/* 109:    */   {
/* 110:100 */     this.rhs = this.rhs.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/* 111:101 */     this.lhs = this.lhs.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/* 112:105 */     if (this.lhs.canPushDownInto())
/* 113:    */     {
/* 114:106 */       if (this.rhs.canPushDownInto()) {
/* 115:106 */         throw new ConfusedCFRException("2 sides of a comparison support pushdown?");
/* 116:    */       }
/* 117:107 */       Expression res = this.lhs.pushDown(this.rhs, this);
/* 118:108 */       if (res != null) {
/* 119:108 */         return res;
/* 120:    */       }
/* 121:    */     }
/* 122:109 */     else if (this.rhs.canPushDownInto())
/* 123:    */     {
/* 124:110 */       Expression res = this.rhs.pushDown(this.lhs, getNegated());
/* 125:111 */       if (res != null) {
/* 126:111 */         return res;
/* 127:    */       }
/* 128:    */     }
/* 129:113 */     return this;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 133:    */   {
/* 134:118 */     this.lhs = expressionRewriter.rewriteExpression(this.lhs, ssaIdentifiers, statementContainer, flags);
/* 135:119 */     this.rhs = expressionRewriter.rewriteExpression(this.rhs, ssaIdentifiers, statementContainer, flags);
/* 136:120 */     return this;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 140:    */   {
/* 141:125 */     this.rhs = expressionRewriter.rewriteExpression(this.rhs, ssaIdentifiers, statementContainer, flags);
/* 142:126 */     this.lhs = expressionRewriter.rewriteExpression(this.lhs, ssaIdentifiers, statementContainer, flags);
/* 143:127 */     return this;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public ConditionalExpression getNegated()
/* 147:    */   {
/* 148:133 */     return new ComparisonOperation(this.lhs, this.rhs, this.op.getInverted());
/* 149:    */   }
/* 150:    */   
/* 151:    */   public CompOp getOp()
/* 152:    */   {
/* 153:137 */     return this.op;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public ConditionalExpression getDemorganApplied(boolean amNegating)
/* 157:    */   {
/* 158:142 */     if (!amNegating) {
/* 159:142 */       return this;
/* 160:    */     }
/* 161:143 */     return getNegated();
/* 162:    */   }
/* 163:    */   
/* 164:    */   public ConditionalExpression getRightDeep()
/* 165:    */   {
/* 166:148 */     return this;
/* 167:    */   }
/* 168:    */   
/* 169:    */   protected void addIfLValue(Expression expression, Set<LValue> res)
/* 170:    */   {
/* 171:152 */     if ((expression instanceof LValueExpression)) {
/* 172:153 */       res.add(((LValueExpression)expression).getLValue());
/* 173:    */     }
/* 174:    */   }
/* 175:    */   
/* 176:    */   public Set<LValue> getLoopLValues()
/* 177:    */   {
/* 178:159 */     Set<LValue> res = SetFactory.newSet();
/* 179:160 */     addIfLValue(this.lhs, res);
/* 180:161 */     addIfLValue(this.rhs, res);
/* 181:162 */     return res;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/* 185:    */   {
/* 186:167 */     this.lhs.collectUsedLValues(lValueUsageCollector);
/* 187:168 */     this.rhs.collectUsedLValues(lValueUsageCollector);
/* 188:    */   }
/* 189:    */   
/* 190:    */   private static enum BooleanComparisonType
/* 191:    */   {
/* 192:172 */     NOT(false),  AS_IS(true),  NEGATED(true);
/* 193:    */     
/* 194:    */     private final boolean isValid;
/* 195:    */     
/* 196:    */     private BooleanComparisonType(boolean isValid)
/* 197:    */     {
/* 198:179 */       this.isValid = isValid;
/* 199:    */     }
/* 200:    */     
/* 201:    */     public boolean isValid()
/* 202:    */     {
/* 203:183 */       return this.isValid;
/* 204:    */     }
/* 205:    */   }
/* 206:    */   
/* 207:    */   private static BooleanComparisonType isBooleanComparison(Expression a, Expression b, CompOp op)
/* 208:    */   {
/* 209:188 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$expression$CompOp[op.ordinal()])
/* 210:    */     {
/* 211:    */     case 1: 
/* 212:    */     case 2: 
/* 213:    */       break;
/* 214:    */     default: 
/* 215:193 */       return BooleanComparisonType.NOT;
/* 216:    */     }
/* 217:195 */     if (a.getInferredJavaType().getJavaTypeInstance().getRawTypeOfSimpleType() != RawJavaType.BOOLEAN) {
/* 218:196 */       return BooleanComparisonType.NOT;
/* 219:    */     }
/* 220:197 */     if (!(b instanceof Literal)) {
/* 221:197 */       return BooleanComparisonType.NOT;
/* 222:    */     }
/* 223:198 */     Literal literal = (Literal)b;
/* 224:199 */     TypedLiteral lit = literal.getValue();
/* 225:200 */     if (lit.getType() != TypedLiteral.LiteralType.Integer) {
/* 226:200 */       return BooleanComparisonType.NOT;
/* 227:    */     }
/* 228:201 */     int i = ((Integer)lit.getValue()).intValue();
/* 229:202 */     if ((i < 0) || (i > 1)) {
/* 230:202 */       return BooleanComparisonType.NOT;
/* 231:    */     }
/* 232:203 */     if (op == CompOp.NE) {
/* 233:203 */       i = 1 - i;
/* 234:    */     }
/* 235:205 */     if (i == 0) {
/* 236:206 */       return BooleanComparisonType.NEGATED;
/* 237:    */     }
/* 238:208 */     return BooleanComparisonType.AS_IS;
/* 239:    */   }
/* 240:    */   
/* 241:    */   public ConditionalExpression getConditionalExpression(Expression booleanExpression, BooleanComparisonType booleanComparisonType)
/* 242:    */   {
/* 243:213 */     ConditionalExpression res = null;
/* 244:214 */     if ((booleanExpression instanceof ConditionalExpression)) {
/* 245:215 */       res = (ConditionalExpression)booleanExpression;
/* 246:    */     } else {
/* 247:217 */       res = new BooleanExpression(booleanExpression);
/* 248:    */     }
/* 249:219 */     if (booleanComparisonType == BooleanComparisonType.NEGATED) {
/* 250:219 */       res = res.getNegated();
/* 251:    */     }
/* 252:220 */     return res;
/* 253:    */   }
/* 254:    */   
/* 255:    */   public ConditionalExpression optimiseForType()
/* 256:    */   {
/* 257:225 */     BooleanComparisonType bct = null;
/* 258:226 */     if ((bct = isBooleanComparison(this.lhs, this.rhs, this.op)).isValid()) {
/* 259:227 */       return getConditionalExpression(this.lhs, bct);
/* 260:    */     }
/* 261:228 */     if ((bct = isBooleanComparison(this.rhs, this.lhs, this.op)).isValid()) {
/* 262:229 */       return getConditionalExpression(this.rhs, bct);
/* 263:    */     }
/* 264:231 */     return this;
/* 265:    */   }
/* 266:    */   
/* 267:    */   public Expression getLhs()
/* 268:    */   {
/* 269:235 */     return this.lhs;
/* 270:    */   }
/* 271:    */   
/* 272:    */   public Expression getRhs()
/* 273:    */   {
/* 274:239 */     return this.rhs;
/* 275:    */   }
/* 276:    */   
/* 277:    */   public ConditionalExpression simplify()
/* 278:    */   {
/* 279:244 */     return ConditionalUtils.simplify(this);
/* 280:    */   }
/* 281:    */   
/* 282:    */   public boolean rewriteBoxing(PrimitiveBoxingRewriter boxingRewriter)
/* 283:    */   {
/* 284:249 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$expression$CompOp[this.op.ordinal()])
/* 285:    */     {
/* 286:    */     case 1: 
/* 287:    */     case 2: 
/* 288:252 */       if (boxingRewriter.isUnboxedType(this.lhs))
/* 289:    */       {
/* 290:253 */         this.rhs = boxingRewriter.sugarUnboxing(this.rhs);
/* 291:254 */         return false;
/* 292:    */       }
/* 293:256 */       if (boxingRewriter.isUnboxedType(this.rhs))
/* 294:    */       {
/* 295:257 */         this.lhs = boxingRewriter.sugarUnboxing(this.lhs);
/* 296:258 */         return false;
/* 297:    */       }
/* 298:    */       break;
/* 299:    */     default: 
/* 300:262 */       this.lhs = boxingRewriter.sugarUnboxing(this.lhs);
/* 301:263 */       this.rhs = boxingRewriter.sugarUnboxing(this.rhs);
/* 302:    */     }
/* 303:266 */     return false;
/* 304:    */   }
/* 305:    */   
/* 306:    */   public void applyNonArgExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags) {}
/* 307:    */   
/* 308:    */   public boolean equals(Object o)
/* 309:    */   {
/* 310:275 */     if (o == this) {
/* 311:275 */       return true;
/* 312:    */     }
/* 313:276 */     if (!(o instanceof ComparisonOperation)) {
/* 314:276 */       return false;
/* 315:    */     }
/* 316:277 */     ComparisonOperation other = (ComparisonOperation)o;
/* 317:278 */     return (this.op == other.op) && (this.lhs.equals(other.lhs)) && (this.rhs.equals(other.rhs));
/* 318:    */   }
/* 319:    */   
/* 320:    */   public boolean canThrow(ExceptionCheck caught)
/* 321:    */   {
/* 322:285 */     return (this.lhs.canThrow(caught)) || (this.rhs.canThrow(caught));
/* 323:    */   }
/* 324:    */   
/* 325:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 326:    */   {
/* 327:290 */     if (o == null) {
/* 328:290 */       return false;
/* 329:    */     }
/* 330:291 */     if (o == this) {
/* 331:291 */       return true;
/* 332:    */     }
/* 333:292 */     if (getClass() != o.getClass()) {
/* 334:292 */       return false;
/* 335:    */     }
/* 336:293 */     ComparisonOperation other = (ComparisonOperation)o;
/* 337:294 */     if (!constraint.equivalent(this.op, other.op)) {
/* 338:294 */       return false;
/* 339:    */     }
/* 340:295 */     if (!constraint.equivalent(this.lhs, other.lhs)) {
/* 341:295 */       return false;
/* 342:    */     }
/* 343:296 */     if (!constraint.equivalent(this.rhs, other.rhs)) {
/* 344:296 */       return false;
/* 345:    */     }
/* 346:297 */     return true;
/* 347:    */   }
/* 348:    */   
/* 349:    */   public Literal getComputedLiteral(Map<LValue, Literal> display)
/* 350:    */   {
/* 351:302 */     Literal lV = this.lhs.getComputedLiteral(display);
/* 352:303 */     Literal rV = this.rhs.getComputedLiteral(display);
/* 353:304 */     if ((lV == null) || (rV == null)) {
/* 354:304 */       return null;
/* 355:    */     }
/* 356:305 */     TypedLiteral l = lV.getValue();
/* 357:306 */     TypedLiteral r = rV.getValue();
/* 358:307 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$expression$CompOp[this.op.ordinal()])
/* 359:    */     {
/* 360:    */     case 1: 
/* 361:309 */       return l.equals(r) ? Literal.TRUE : Literal.FALSE;
/* 362:    */     case 2: 
/* 363:311 */       return l.equals(r) ? Literal.FALSE : Literal.TRUE;
/* 364:    */     }
/* 365:314 */     return null;
/* 366:    */   }
/* 367:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.ComparisonOperation
 * JD-Core Version:    0.7.0.1
 */