/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.utils;
/*   2:    */ 
/*   3:    */ import java.util.Iterator;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Map;
/*   6:    */ import java.util.Map.Entry;
/*   7:    */ import java.util.Set;
/*   8:    */ import java.util.logging.Logger;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArrayIndex;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AssignmentExpression;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.StackValue;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.ArrayVariable;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.AssignmentSimple;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.stack.StackEntry;
/*  24:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  25:    */ import org.benf.cfr.reader.util.ListFactory;
/*  26:    */ import org.benf.cfr.reader.util.MapFactory;
/*  27:    */ import org.benf.cfr.reader.util.SetFactory;
/*  28:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  29:    */ import org.benf.cfr.reader.util.output.LoggerFactory;
/*  30:    */ 
/*  31:    */ public class LValueAssignmentAndAliasCondenser
/*  32:    */   implements LValueRewriter<Statement>, LValueAssignmentCollector<Statement>
/*  33:    */ {
/*  34: 27 */   private static final Logger logger = LoggerFactory.create(LValueAssignmentAndAliasCondenser.class);
/*  35:    */   private final Map<StackSSALabel, ExpressionStatement> found;
/*  36:    */   private final Set<StackSSALabel> blacklisted;
/*  37:    */   private final Map<StackSSALabel, Expression> aliasReplacements;
/*  38:    */   private final Map<StackSSALabel, ExpressionStatement> multiFound;
/*  39:    */   private final Map<VersionedLValue, ExpressionStatement> mutableFound;
/*  40:    */   Map<Expression, Expression> cache;
/*  41:    */   
/*  42:    */   public void collect(StackSSALabel lValue, StatementContainer<Statement> statementContainer, Expression value)
/*  43:    */   {
/*  44: 59 */     this.found.put(lValue, new ExpressionStatement(value, statementContainer, null));
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void collectMultiUse(StackSSALabel lValue, StatementContainer<Statement> statementContainer, Expression value)
/*  48:    */   {
/*  49: 64 */     this.multiFound.put(lValue, new ExpressionStatement(value, statementContainer, null));
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void collectMutatedLValue(LValue lValue, StatementContainer<Statement> statementContainer, Expression value)
/*  53:    */   {
/*  54: 69 */     SSAIdent version = statementContainer.getSSAIdentifiers().getSSAIdentOnExit(lValue);
/*  55: 70 */     if (null != this.mutableFound.put(new VersionedLValue(lValue, version, null), new ExpressionStatement(value, statementContainer, null))) {
/*  56: 71 */       throw new ConfusedCFRException("Duplicate versioned SSA Ident.");
/*  57:    */     }
/*  58:    */   }
/*  59:    */   
/*  60:    */   public LValueAssignmentAndAliasCondenser()
/*  61:    */   {
/*  62: 32 */     this.found = MapFactory.newLinkedMap();
/*  63: 33 */     this.blacklisted = SetFactory.newOrderedSet();
/*  64:    */     
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68: 38 */     this.aliasReplacements = MapFactory.newMap();
/*  69:    */     
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78: 48 */     this.multiFound = MapFactory.newMap();
/*  79:    */     
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84: 54 */     this.mutableFound = MapFactory.newMap();
/*  85:    */     
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110: 80 */     this.cache = MapFactory.newMap();
/* 111:    */   }
/* 112:    */   
/* 113:    */   Set<LValue> findAssignees(Statement s)
/* 114:    */   {
/* 115: 83 */     if (!(s instanceof AssignmentSimple)) {
/* 116: 83 */       return null;
/* 117:    */     }
/* 118: 84 */     AssignmentSimple assignmentSimple = (AssignmentSimple)s;
/* 119: 85 */     Set<LValue> res = SetFactory.newSet();
/* 120: 86 */     res.add(assignmentSimple.getCreatedLValue());
/* 121: 87 */     Expression rvalue = assignmentSimple.getRValue();
/* 122: 88 */     while ((rvalue instanceof AssignmentExpression))
/* 123:    */     {
/* 124: 89 */       AssignmentExpression assignmentExpression = (AssignmentExpression)rvalue;
/* 125: 90 */       res.add(assignmentExpression.getlValue());
/* 126: 91 */       rvalue = assignmentExpression.getrValue();
/* 127:    */     }
/* 128: 93 */     return res;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public Expression getLValueReplacement(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer<Statement> lvSc)
/* 132:    */   {
/* 133: 97 */     if (!(lValue instanceof StackSSALabel)) {
/* 134: 97 */       return null;
/* 135:    */     }
/* 136: 99 */     StackSSALabel stackSSALabel = (StackSSALabel)lValue;
/* 137:101 */     if (!this.found.containsKey(stackSSALabel)) {
/* 138:101 */       return null;
/* 139:    */     }
/* 140:102 */     if (this.blacklisted.contains(stackSSALabel)) {
/* 141:103 */       return null;
/* 142:    */     }
/* 143:105 */     ExpressionStatement pair = (ExpressionStatement)this.found.get(stackSSALabel);
/* 144:    */     
/* 145:    */ 
/* 146:108 */     StatementContainer<Statement> statementContainer = pair.statementContainer;
/* 147:109 */     SSAIdentifiers replacementIdentifiers = statementContainer == null ? null : statementContainer.getSSAIdentifiers();
/* 148:    */     
/* 149:    */ 
/* 150:112 */     Expression res = pair.expression;
/* 151:    */     SSAIdentifiers tgtIdents;
/* 152:114 */     if (replacementIdentifiers != null)
/* 153:    */     {
/* 154:115 */       LValueUsageCollectorSimple lvcInSource = new LValueUsageCollectorSimple();
/* 155:116 */       res.collectUsedLValues(lvcInSource);
/* 156:118 */       for (LValue resLValue : lvcInSource.getUsedLValues()) {
/* 157:120 */         if (!ssaIdentifiers.isValidReplacement(resLValue, replacementIdentifiers))
/* 158:    */         {
/* 159:123 */           Set<LValue> assignees = findAssignees((Statement)lvSc.getStatement());
/* 160:124 */           if ((assignees != null) && 
/* 161:125 */             (assignees.contains(resLValue)))
/* 162:    */           {
/* 163:126 */             Op03SimpleStatement lv03 = (Op03SimpleStatement)lvSc;
/* 164:127 */             for (Op03SimpleStatement source : lv03.getSources()) {
/* 165:128 */               if (!source.getSSAIdentifiers().isValidReplacementOnExit(resLValue, replacementIdentifiers)) {
/* 166:129 */                 return null;
/* 167:    */               }
/* 168:    */             }
/* 169:    */           }
/* 170:    */           else
/* 171:    */           {
/* 172:138 */             return null;
/* 173:    */           }
/* 174:    */         }
/* 175:    */       }
/* 176:148 */       Set<LValue> changes = (statementContainer instanceof Op03SimpleStatement) ? replacementIdentifiers.getChanges() : null;
/* 177:    */       Iterator i$;
/* 178:149 */       if ((changes != null) && (!changes.isEmpty()))
/* 179:    */       {
/* 180:150 */         Op03SimpleStatement container = (Op03SimpleStatement)statementContainer;
/* 181:151 */         for (i$ = container.getTargets().iterator(); i$.hasNext();)
/* 182:    */         {
/* 183:151 */           target = (Op03SimpleStatement)i$.next();
/* 184:152 */           if (target != lvSc) {
/* 185:153 */             for (LValue change : changes) {
/* 186:154 */               if (target.getSSAIdentifiers().getSSAIdentOnEntry(change).equals(replacementIdentifiers.getSSAIdentOnExit(change))) {
/* 187:156 */                 return null;
/* 188:    */               }
/* 189:    */             }
/* 190:    */           }
/* 191:    */         }
/* 192:    */       }
/* 193:    */       Op03SimpleStatement target;
/* 194:166 */       if ((changes != null) && (!changes.isEmpty()))
/* 195:    */       {
/* 196:167 */         tgtIdents = lvSc.getSSAIdentifiers();
/* 197:168 */         for (LValue change : changes) {
/* 198:170 */           tgtIdents.setKnownIdentifierOnEntry(change, replacementIdentifiers.getSSAIdentOnEntry(change));
/* 199:    */         }
/* 200:    */       }
/* 201:    */     }
/* 202:175 */     if (statementContainer != null)
/* 203:    */     {
/* 204:176 */       lvSc.copyBlockInformationFrom(statementContainer);
/* 205:177 */       statementContainer.nopOut();
/* 206:    */     }
/* 207:179 */     stackSSALabel.getStackEntry().decrementUsage();
/* 208:180 */     if (this.aliasReplacements.containsKey(stackSSALabel))
/* 209:    */     {
/* 210:181 */       this.found.put(stackSSALabel, new ExpressionStatement((Expression)this.aliasReplacements.get(stackSSALabel), null, null));
/* 211:182 */       this.aliasReplacements.remove(stackSSALabel);
/* 212:    */     }
/* 213:186 */     Expression prev = null;
/* 214:187 */     if (((res instanceof StackValue)) && (((StackValue)res).getStackValue() == stackSSALabel)) {
/* 215:188 */       prev = res;
/* 216:    */     }
/* 217:191 */     while ((res != null) && (res != prev))
/* 218:    */     {
/* 219:192 */       prev = res;
/* 220:193 */       if (this.cache.containsKey(res))
/* 221:    */       {
/* 222:194 */         res = (Expression)this.cache.get(res);
/* 223:195 */         prev = res;
/* 224:    */       }
/* 225:197 */       res = res.replaceSingleUsageLValues(this, ssaIdentifiers, lvSc);
/* 226:    */     }
/* 227:200 */     this.cache.put(new StackValue(stackSSALabel), prev);
/* 228:    */     
/* 229:202 */     return prev;
/* 230:    */   }
/* 231:    */   
/* 232:    */   public boolean explicitlyReplaceThisLValue(LValue lValue)
/* 233:    */   {
/* 234:207 */     return false;
/* 235:    */   }
/* 236:    */   
/* 237:    */   public void checkPostConditions(LValue lValue, Expression rValue)
/* 238:    */   {
/* 239:227 */     if (!(lValue instanceof StackSSALabel)) {
/* 240:227 */       return;
/* 241:    */     }
/* 242:228 */     StackSSALabel label = (StackSSALabel)lValue;
/* 243:229 */     if (this.aliasReplacements.containsKey(label)) {
/* 244:229 */       return;
/* 245:    */     }
/* 246:230 */     if (!this.found.containsKey(label)) {
/* 247:230 */       return;
/* 248:    */     }
/* 249:231 */     long count = label.getStackEntry().getUsageCount();
/* 250:232 */     if ((count > 1L) && (!rValue.isSimple())) {
/* 251:233 */       this.blacklisted.add(label);
/* 252:    */     }
/* 253:    */   }
/* 254:    */   
/* 255:    */   private static class ExpressionStatement
/* 256:    */   {
/* 257:    */     private final Expression expression;
/* 258:    */     private final StatementContainer<Statement> statementContainer;
/* 259:    */     
/* 260:    */     private ExpressionStatement(Expression expression, StatementContainer<Statement> statementContainer)
/* 261:    */     {
/* 262:242 */       this.expression = expression;
/* 263:243 */       this.statementContainer = statementContainer;
/* 264:    */     }
/* 265:    */   }
/* 266:    */   
/* 267:    */   public AliasRewriter getAliasRewriter()
/* 268:    */   {
/* 269:248 */     return new AliasRewriter();
/* 270:    */   }
/* 271:    */   
/* 272:    */   public class AliasRewriter
/* 273:    */     implements LValueRewriter<Statement>
/* 274:    */   {
/* 275:252 */     private final Map<StackSSALabel, List<StatementContainer<Statement>>> usages = MapFactory.newLazyMap(new UnaryFunction()
/* 276:    */     {
/* 277:    */       public List<StatementContainer<Statement>> invoke(StackSSALabel ignore)
/* 278:    */       {
/* 279:256 */         return ListFactory.newList();
/* 280:    */       }
/* 281:252 */     });
/* 282:260 */     private final Map<StackSSALabel, List<LValueAssignmentAndAliasCondenser.LValueStatementContainer>> possibleAliases = MapFactory.newLazyMap(new UnaryFunction()
/* 283:    */     {
/* 284:    */       public List<LValueAssignmentAndAliasCondenser.LValueStatementContainer> invoke(StackSSALabel ignore)
/* 285:    */       {
/* 286:264 */         return ListFactory.newList();
/* 287:    */       }
/* 288:260 */     });
/* 289:    */     
/* 290:    */     public AliasRewriter() {}
/* 291:    */     
/* 292:    */     public Expression getLValueReplacement(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer<Statement> statementContainer)
/* 293:    */     {
/* 294:271 */       if (!(lValue instanceof StackSSALabel)) {
/* 295:271 */         return null;
/* 296:    */       }
/* 297:272 */       StackSSALabel stackSSALabel = (StackSSALabel)lValue;
/* 298:274 */       if (!LValueAssignmentAndAliasCondenser.this.multiFound.containsKey(lValue)) {
/* 299:274 */         return null;
/* 300:    */       }
/* 301:278 */       if ((statementContainer.getStatement() instanceof AssignmentSimple))
/* 302:    */       {
/* 303:279 */         AssignmentSimple assignmentSimple = (AssignmentSimple)statementContainer.getStatement();
/* 304:280 */         Expression rhs = assignmentSimple.getRValue();
/* 305:281 */         if (((rhs instanceof StackValue)) && 
/* 306:282 */           (((StackValue)rhs).getStackValue().equals(stackSSALabel))) {
/* 307:283 */           ((List)this.possibleAliases.get(stackSSALabel)).add(new LValueAssignmentAndAliasCondenser.LValueStatementContainer(assignmentSimple.getCreatedLValue(), statementContainer, null));
/* 308:    */         }
/* 309:    */       }
/* 310:287 */       ((List)this.usages.get(stackSSALabel)).add(statementContainer);
/* 311:288 */       return null;
/* 312:    */     }
/* 313:    */     
/* 314:    */     private LValue getAlias(StackSSALabel stackSSALabel, LValueAssignmentAndAliasCondenser.ExpressionStatement target)
/* 315:    */     {
/* 316:296 */       List<LValueAssignmentAndAliasCondenser.LValueStatementContainer> possibleAliasList = (List)this.possibleAliases.get(stackSSALabel);
/* 317:297 */       if (possibleAliasList.isEmpty()) {
/* 318:297 */         return null;
/* 319:    */       }
/* 320:298 */       LValue guessAlias = null;
/* 321:299 */       StatementContainer guessStatement = null;
/* 322:300 */       for (LValueAssignmentAndAliasCondenser.LValueStatementContainer lValueStatementContainer : possibleAliasList) {
/* 323:301 */         if (!(lValueStatementContainer.lValue instanceof StackSSALabel))
/* 324:    */         {
/* 325:302 */           guessAlias = lValueStatementContainer.lValue;
/* 326:303 */           guessStatement = lValueStatementContainer.statementContainer;
/* 327:304 */           break;
/* 328:    */         }
/* 329:    */       }
/* 330:307 */       if (guessAlias == null) {
/* 331:307 */         return null;
/* 332:    */       }
/* 333:314 */       LValue returnGuessAlias = guessAlias;
/* 334:315 */       List<LValue> checkThese = ListFactory.newList();
/* 335:316 */       if ((guessAlias instanceof ArrayVariable))
/* 336:    */       {
/* 337:317 */         ArrayVariable arrayVariable = (ArrayVariable)guessAlias;
/* 338:318 */         ArrayIndex arrayIndex = arrayVariable.getArrayIndex();
/* 339:319 */         Expression array = arrayIndex.getArray();
/* 340:320 */         if (!(array instanceof LValueExpression)) {
/* 341:320 */           return null;
/* 342:    */         }
/* 343:321 */         LValueExpression lValueArrayIndex = (LValueExpression)array;
/* 344:322 */         checkThese.add(lValueArrayIndex.getLValue());
/* 345:323 */         Expression index = arrayIndex.getIndex();
/* 346:324 */         if ((index instanceof LValueExpression)) {
/* 347:325 */           checkThese.add(((LValueExpression)index).getLValue());
/* 348:326 */         } else if (!(index instanceof Literal)) {
/* 349:328 */           return null;
/* 350:    */         }
/* 351:    */       }
/* 352:    */       else
/* 353:    */       {
/* 354:331 */         checkThese.add(guessAlias);
/* 355:    */       }
/* 356:333 */       for (Iterator i$ = ((List)this.usages.get(stackSSALabel)).iterator(); i$.hasNext();)
/* 357:    */       {
/* 358:333 */         verifyStatement = (StatementContainer)i$.next();
/* 359:338 */         if (((Statement)verifyStatement.getStatement()).doesBlackListLValueReplacement(stackSSALabel, LValueAssignmentAndAliasCondenser.ExpressionStatement.access$300(target))) {
/* 360:338 */           return null;
/* 361:    */         }
/* 362:339 */         for (LValue checkThis : checkThese) {
/* 363:340 */           if (guessStatement != verifyStatement) {
/* 364:341 */             if (!verifyStatement.getSSAIdentifiers().isValidReplacement(checkThis, guessStatement.getSSAIdentifiers())) {
/* 365:342 */               return null;
/* 366:    */             }
/* 367:    */           }
/* 368:    */         }
/* 369:    */       }
/* 370:    */       StatementContainer<Statement> verifyStatement;
/* 371:350 */       return returnGuessAlias;
/* 372:    */     }
/* 373:    */     
/* 374:    */     public void inferAliases()
/* 375:    */     {
/* 376:354 */       for (Map.Entry<StackSSALabel, LValueAssignmentAndAliasCondenser.ExpressionStatement> multi : LValueAssignmentAndAliasCondenser.this.multiFound.entrySet())
/* 377:    */       {
/* 378:358 */         StackSSALabel stackSSALabel = (StackSSALabel)multi.getKey();
/* 379:359 */         LValue alias = getAlias(stackSSALabel, (LValueAssignmentAndAliasCondenser.ExpressionStatement)multi.getValue());
/* 380:360 */         if (alias != null)
/* 381:    */         {
/* 382:364 */           LValueAssignmentAndAliasCondenser.this.found.put(stackSSALabel, multi.getValue());
/* 383:365 */           LValueAssignmentAndAliasCondenser.this.aliasReplacements.put(stackSSALabel, new LValueExpression(alias));
/* 384:    */         }
/* 385:    */       }
/* 386:    */     }
/* 387:    */     
/* 388:    */     public boolean explicitlyReplaceThisLValue(LValue lValue)
/* 389:    */     {
/* 390:372 */       return false;
/* 391:    */     }
/* 392:    */     
/* 393:    */     public void checkPostConditions(LValue lValue, Expression rValue) {}
/* 394:    */   }
/* 395:    */   
/* 396:    */   public MutationRewriterFirstPass getMutationRewriterFirstPass()
/* 397:    */   {
/* 398:382 */     if (this.mutableFound.isEmpty()) {
/* 399:382 */       return null;
/* 400:    */     }
/* 401:383 */     return new MutationRewriterFirstPass();
/* 402:    */   }
/* 403:    */   
/* 404:    */   public void collectLocalVariableAssignment(LocalVariable localVariable, StatementContainer<Statement> statementContainer, Expression value) {}
/* 405:    */   
/* 406:    */   public class MutationRewriterFirstPass
/* 407:    */     implements LValueRewriter<Statement>
/* 408:    */   {
/* 409:389 */     private final Map<LValueAssignmentAndAliasCondenser.VersionedLValue, Set<StatementContainer>> mutableUseFound = MapFactory.newLazyMap(new UnaryFunction()
/* 410:    */     {
/* 411:    */       public Set<StatementContainer> invoke(LValueAssignmentAndAliasCondenser.VersionedLValue arg)
/* 412:    */       {
/* 413:392 */         return SetFactory.newSet();
/* 414:    */       }
/* 415:389 */     });
/* 416:    */     
/* 417:    */     public MutationRewriterFirstPass() {}
/* 418:    */     
/* 419:    */     public Expression getLValueReplacement(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer<Statement> statementContainer)
/* 420:    */     {
/* 421:399 */       SSAIdent ssaIdent = ssaIdentifiers.getSSAIdentOnExit(lValue);
/* 422:400 */       if (ssaIdent != null)
/* 423:    */       {
/* 424:401 */         LValueAssignmentAndAliasCondenser.VersionedLValue versionedLValue = new LValueAssignmentAndAliasCondenser.VersionedLValue(lValue, ssaIdent, null);
/* 425:402 */         if (LValueAssignmentAndAliasCondenser.this.mutableFound.containsKey(versionedLValue)) {
/* 426:404 */           ((Set)this.mutableUseFound.get(versionedLValue)).add(statementContainer);
/* 427:    */         }
/* 428:    */       }
/* 429:407 */       return null;
/* 430:    */     }
/* 431:    */     
/* 432:    */     public boolean explicitlyReplaceThisLValue(LValue lValue)
/* 433:    */     {
/* 434:412 */       return true;
/* 435:    */     }
/* 436:    */     
/* 437:    */     public void checkPostConditions(LValue lValue, Expression rValue) {}
/* 438:    */     
/* 439:    */     private StatementContainer getUniqueParent(StatementContainer start, Set<StatementContainer> seen)
/* 440:    */     {
/* 441:431 */       Op03SimpleStatement o3current = (Op03SimpleStatement)start;
/* 442:    */       for (;;)
/* 443:    */       {
/* 444:434 */         if (seen.contains(o3current)) {
/* 445:435 */           return o3current;
/* 446:    */         }
/* 447:437 */         List<Op03SimpleStatement> targets = o3current.getTargets();
/* 448:438 */         if (targets.size() != 1) {
/* 449:438 */           return null;
/* 450:    */         }
/* 451:439 */         o3current = (Op03SimpleStatement)targets.get(0);
/* 452:    */       }
/* 453:    */     }
/* 454:    */     
/* 455:    */     public LValueAssignmentAndAliasCondenser.MutationRewriterSecondPass getSecondPassRewriter()
/* 456:    */     {
/* 457:449 */       Map<LValueAssignmentAndAliasCondenser.VersionedLValue, StatementContainer> replacableUses = MapFactory.newMap();
/* 458:450 */       for (Map.Entry<LValueAssignmentAndAliasCondenser.VersionedLValue, Set<StatementContainer>> entry : this.mutableUseFound.entrySet())
/* 459:    */       {
/* 460:451 */         LValueAssignmentAndAliasCondenser.ExpressionStatement definition = (LValueAssignmentAndAliasCondenser.ExpressionStatement)LValueAssignmentAndAliasCondenser.this.mutableFound.get(entry.getKey());
/* 461:452 */         StatementContainer uniqueParent = getUniqueParent(LValueAssignmentAndAliasCondenser.ExpressionStatement.access$200(definition), (Set)entry.getValue());
/* 462:453 */         if (uniqueParent != null) {
/* 463:454 */           replacableUses.put(entry.getKey(), uniqueParent);
/* 464:    */         }
/* 465:    */       }
/* 466:458 */       if (replacableUses.isEmpty()) {
/* 467:458 */         return null;
/* 468:    */       }
/* 469:460 */       return new LValueAssignmentAndAliasCondenser.MutationRewriterSecondPass(LValueAssignmentAndAliasCondenser.this, replacableUses, null);
/* 470:    */     }
/* 471:    */   }
/* 472:    */   
/* 473:    */   public class MutationRewriterSecondPass
/* 474:    */     implements LValueRewriter<Statement>
/* 475:    */   {
/* 476:    */     private final Map<LValueAssignmentAndAliasCondenser.VersionedLValue, StatementContainer> mutableReplacable;
/* 477:    */     
/* 478:    */     private MutationRewriterSecondPass()
/* 479:    */     {
/* 480:469 */       this.mutableReplacable = mutableReplacable;
/* 481:    */     }
/* 482:    */     
/* 483:    */     public Expression getLValueReplacement(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer<Statement> statementContainer)
/* 484:    */     {
/* 485:474 */       SSAIdent ssaIdent = ssaIdentifiers.getSSAIdentOnExit(lValue);
/* 486:475 */       if (ssaIdent != null)
/* 487:    */       {
/* 488:476 */         LValueAssignmentAndAliasCondenser.VersionedLValue versionedLValue = new LValueAssignmentAndAliasCondenser.VersionedLValue(lValue, ssaIdent, null);
/* 489:477 */         StatementContainer canReplaceIn = (StatementContainer)this.mutableReplacable.get(versionedLValue);
/* 490:478 */         if (canReplaceIn == statementContainer)
/* 491:    */         {
/* 492:479 */           LValueAssignmentAndAliasCondenser.ExpressionStatement replaceWith = (LValueAssignmentAndAliasCondenser.ExpressionStatement)LValueAssignmentAndAliasCondenser.this.mutableFound.get(versionedLValue);
/* 493:480 */           if (LValueAssignmentAndAliasCondenser.ExpressionStatement.access$200(replaceWith) == statementContainer) {
/* 494:480 */             return null;
/* 495:    */           }
/* 496:483 */           this.mutableReplacable.remove(versionedLValue);
/* 497:484 */           LValueAssignmentAndAliasCondenser.ExpressionStatement.access$200(replaceWith).nopOut();
/* 498:485 */           SSAIdentifiers previousIdents = LValueAssignmentAndAliasCondenser.ExpressionStatement.access$200(replaceWith).getSSAIdentifiers();
/* 499:486 */           SSAIdentifiers currentIdents = statementContainer.getSSAIdentifiers();
/* 500:487 */           currentIdents.setKnownIdentifierOnEntry(lValue, previousIdents.getSSAIdentOnEntry(lValue));
/* 501:488 */           return LValueAssignmentAndAliasCondenser.ExpressionStatement.access$300(replaceWith);
/* 502:    */         }
/* 503:    */       }
/* 504:491 */       return null;
/* 505:    */     }
/* 506:    */     
/* 507:    */     public boolean explicitlyReplaceThisLValue(LValue lValue)
/* 508:    */     {
/* 509:496 */       return true;
/* 510:    */     }
/* 511:    */     
/* 512:    */     public void checkPostConditions(LValue lValue, Expression rValue) {}
/* 513:    */   }
/* 514:    */   
/* 515:    */   private static class LValueStatementContainer
/* 516:    */   {
/* 517:    */     private final LValue lValue;
/* 518:    */     private final StatementContainer statementContainer;
/* 519:    */     
/* 520:    */     private LValueStatementContainer(LValue lValue, StatementContainer statementContainer)
/* 521:    */     {
/* 522:511 */       this.lValue = lValue;
/* 523:512 */       this.statementContainer = statementContainer;
/* 524:    */     }
/* 525:    */   }
/* 526:    */   
/* 527:    */   private static final class VersionedLValue
/* 528:    */   {
/* 529:    */     private final LValue lValue;
/* 530:    */     private final SSAIdent ssaIdent;
/* 531:    */     
/* 532:    */     private VersionedLValue(LValue lValue, SSAIdent ssaIdent)
/* 533:    */     {
/* 534:521 */       this.lValue = lValue;
/* 535:522 */       this.ssaIdent = ssaIdent;
/* 536:    */     }
/* 537:    */     
/* 538:    */     public int hashCode()
/* 539:    */     {
/* 540:527 */       return this.lValue.hashCode() + 31 * this.ssaIdent.hashCode();
/* 541:    */     }
/* 542:    */     
/* 543:    */     public boolean equals(Object o)
/* 544:    */     {
/* 545:532 */       if (o == this) {
/* 546:532 */         return true;
/* 547:    */       }
/* 548:533 */       if (!(o instanceof VersionedLValue)) {
/* 549:533 */         return false;
/* 550:    */       }
/* 551:535 */       VersionedLValue other = (VersionedLValue)o;
/* 552:536 */       return (this.lValue.equals(other.lValue)) && (this.ssaIdent.equals(other.ssaIdent));
/* 553:    */     }
/* 554:    */   }
/* 555:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentAndAliasCondenser
 * JD-Core Version:    0.7.0.1
 */