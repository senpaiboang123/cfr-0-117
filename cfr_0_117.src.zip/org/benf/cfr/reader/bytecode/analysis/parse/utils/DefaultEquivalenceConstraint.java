/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.utils;
/*  2:   */ 
/*  3:   */ import java.util.Collection;
/*  4:   */ import java.util.Iterator;
/*  5:   */ 
/*  6:   */ public class DefaultEquivalenceConstraint
/*  7:   */   implements EquivalenceConstraint
/*  8:   */ {
/*  9: 8 */   public static final EquivalenceConstraint INSTANCE = new DefaultEquivalenceConstraint();
/* 10:   */   
/* 11:   */   public boolean equivalent(Object o1, Object o2)
/* 12:   */   {
/* 13:12 */     if (o1 == null) {
/* 14:12 */       return o2 == null;
/* 15:   */     }
/* 16:13 */     return o1.equals(o2);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public boolean equivalent(ComparableUnderEC o1, ComparableUnderEC o2)
/* 20:   */   {
/* 21:18 */     if (o1 == null) {
/* 22:18 */       return o2 == null;
/* 23:   */     }
/* 24:19 */     return o1.equivalentUnder(o2, this);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public boolean equivalent(Collection col1, Collection col2)
/* 28:   */   {
/* 29:24 */     if (col1 == null) {
/* 30:24 */       return col2 == null;
/* 31:   */     }
/* 32:25 */     if (col1.size() != col2.size()) {
/* 33:25 */       return false;
/* 34:   */     }
/* 35:26 */     Iterator<?> i1 = col1.iterator();
/* 36:27 */     Iterator<?> i2 = col2.iterator();
/* 37:28 */     while (i1.hasNext())
/* 38:   */     {
/* 39:29 */       Object o1 = i1.next();
/* 40:30 */       Object o2 = i2.next();
/* 41:31 */       if (((o1 instanceof ComparableUnderEC)) && ((o2 instanceof ComparableUnderEC)))
/* 42:   */       {
/* 43:32 */         if (!equivalent((ComparableUnderEC)o1, (ComparableUnderEC)o2)) {
/* 44:32 */           return false;
/* 45:   */         }
/* 46:   */       }
/* 47:34 */       else if (!equivalent(o1, o2)) {
/* 48:34 */         return false;
/* 49:   */       }
/* 50:   */     }
/* 51:37 */     return true;
/* 52:   */   }
/* 53:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.DefaultEquivalenceConstraint
 * JD-Core Version:    0.7.0.1
 */