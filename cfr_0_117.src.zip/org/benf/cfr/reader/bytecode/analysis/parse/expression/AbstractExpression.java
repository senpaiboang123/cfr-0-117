/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import java.util.Map;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*   9:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/*  10:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  11:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  12:    */ import org.benf.cfr.reader.util.Troolean;
/*  13:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  14:    */ import org.benf.cfr.reader.util.output.ToStringDumper;
/*  15:    */ 
/*  16:    */ public abstract class AbstractExpression
/*  17:    */   implements Expression
/*  18:    */ {
/*  19:    */   private final InferredJavaType inferredJavaType;
/*  20:    */   
/*  21:    */   public AbstractExpression(InferredJavaType inferredJavaType)
/*  22:    */   {
/*  23: 22 */     this.inferredJavaType = inferredJavaType;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  27:    */   {
/*  28: 33 */     collector.collect(this.inferredJavaType.getJavaTypeInstance());
/*  29:    */   }
/*  30:    */   
/*  31:    */   public boolean canPushDownInto()
/*  32:    */   {
/*  33: 38 */     return false;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public boolean isSimple()
/*  37:    */   {
/*  38: 43 */     return false;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public Expression pushDown(Expression toPush, Expression parent)
/*  42:    */   {
/*  43: 48 */     throw new ConfusedCFRException("Push down not supported.");
/*  44:    */   }
/*  45:    */   
/*  46:    */   public InferredJavaType getInferredJavaType()
/*  47:    */   {
/*  48: 53 */     return this.inferredJavaType;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public Expression outerDeepClone(CloneHelper cloneHelper)
/*  52:    */   {
/*  53: 58 */     return cloneHelper.replaceOrClone(this);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public final String toString()
/*  57:    */   {
/*  58: 63 */     return ToStringDumper.toString(this);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public boolean canThrow(ExceptionCheck caught)
/*  62:    */   {
/*  63: 68 */     return true;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public abstract boolean equals(Object paramObject);
/*  67:    */   
/*  68:    */   public Literal getComputedLiteral(Map<LValue, Literal> display)
/*  69:    */   {
/*  70: 75 */     return null;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public final Dumper dump(Dumper d)
/*  74:    */   {
/*  75: 80 */     return dumpWithOuterPrecedence(d, Precedence.WEAKEST, Troolean.NEITHER);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public abstract Precedence getPrecedence();
/*  79:    */   
/*  80:    */   public abstract Dumper dumpInner(Dumper paramDumper);
/*  81:    */   
/*  82:    */   public final Dumper dumpWithOuterPrecedence(Dumper d, Precedence outerP, Troolean isLhs)
/*  83:    */   {
/*  84: 90 */     Precedence innerP = getPrecedence();
/*  85: 91 */     int cmp = innerP.compareTo(outerP);
/*  86: 92 */     boolean requires = false;
/*  87: 93 */     if (cmp > 0) {
/*  88: 94 */       requires = true;
/*  89: 95 */     } else if (cmp == 0) {
/*  90: 96 */       if ((innerP == outerP) && (innerP.isCommutative())) {
/*  91: 97 */         requires = false;
/*  92:    */       } else {
/*  93: 99 */         switch (1.$SwitchMap$org$benf$cfr$reader$util$Troolean[isLhs.ordinal()])
/*  94:    */         {
/*  95:    */         case 1: 
/*  96:102 */           requires = !innerP.isLtoR();
/*  97:103 */           break;
/*  98:    */         case 2: 
/*  99:105 */           requires = innerP.isLtoR();
/* 100:106 */           break;
/* 101:    */         case 3: 
/* 102:108 */           requires = !innerP.isLtoR();
/* 103:    */         }
/* 104:    */       }
/* 105:    */     }
/* 106:113 */     if (requires)
/* 107:    */     {
/* 108:114 */       d.print("(");
/* 109:115 */       dumpInner(d);
/* 110:116 */       d.print(")");
/* 111:    */     }
/* 112:    */     else
/* 113:    */     {
/* 114:118 */       dumpInner(d);
/* 115:    */     }
/* 116:120 */     return d;
/* 117:    */   }
/* 118:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression
 * JD-Core Version:    0.7.0.1
 */