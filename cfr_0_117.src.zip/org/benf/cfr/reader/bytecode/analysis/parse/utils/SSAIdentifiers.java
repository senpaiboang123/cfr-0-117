/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.utils;
/*   2:    */ 
/*   3:    */ import java.util.Iterator;
/*   4:    */ import java.util.Map;
/*   5:    */ import java.util.Map.Entry;
/*   6:    */ import java.util.Set;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   8:    */ import org.benf.cfr.reader.util.BinaryPredicate;
/*   9:    */ import org.benf.cfr.reader.util.MapFactory;
/*  10:    */ import org.benf.cfr.reader.util.SetFactory;
/*  11:    */ 
/*  12:    */ public class SSAIdentifiers<KEYTYPE>
/*  13:    */ {
/*  14:    */   private final Map<KEYTYPE, SSAIdent> knownIdentifiersOnEntry;
/*  15:    */   private final Map<KEYTYPE, SSAIdent> knownIdentifiersOnExit;
/*  16:    */   private final Map<KEYTYPE, KEYTYPE> fixedHere;
/*  17:    */   
/*  18:    */   public SSAIdentifiers()
/*  19:    */   {
/*  20: 18 */     this.knownIdentifiersOnEntry = MapFactory.newMap();
/*  21: 19 */     this.knownIdentifiersOnExit = MapFactory.newMap();
/*  22: 20 */     this.fixedHere = MapFactory.newMap();
/*  23:    */   }
/*  24:    */   
/*  25:    */   public SSAIdentifiers(SSAIdentifiers<KEYTYPE> other)
/*  26:    */   {
/*  27: 24 */     this.fixedHere = MapFactory.newMap();
/*  28: 25 */     this.fixedHere.putAll(other.fixedHere);
/*  29: 26 */     this.knownIdentifiersOnEntry = MapFactory.newMap();
/*  30: 27 */     this.knownIdentifiersOnEntry.putAll(other.knownIdentifiersOnEntry);
/*  31: 28 */     this.knownIdentifiersOnExit = MapFactory.newMap();
/*  32: 29 */     this.knownIdentifiersOnExit.putAll(other.knownIdentifiersOnExit);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public SSAIdentifiers(KEYTYPE lValue, SSAIdentifierFactory<KEYTYPE> ssaIdentifierFactory)
/*  36:    */   {
/*  37: 33 */     SSAIdent id = ssaIdentifierFactory.getIdent(lValue);
/*  38: 34 */     this.knownIdentifiersOnEntry = MapFactory.newMap();
/*  39: 35 */     this.knownIdentifiersOnExit = MapFactory.newMap();
/*  40: 36 */     this.knownIdentifiersOnExit.put(lValue, id);
/*  41: 37 */     this.fixedHere = MapFactory.newMap();
/*  42: 38 */     this.fixedHere.put(lValue, lValue);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public SSAIdentifiers(Map<KEYTYPE, SSAIdent> precomputedIdentifiers)
/*  46:    */   {
/*  47: 42 */     this.knownIdentifiersOnEntry = MapFactory.newMap();
/*  48: 43 */     this.knownIdentifiersOnExit = MapFactory.newMap();
/*  49: 44 */     this.fixedHere = MapFactory.newMap();
/*  50: 45 */     this.knownIdentifiersOnEntry.putAll(precomputedIdentifiers);
/*  51: 46 */     this.knownIdentifiersOnExit.putAll(precomputedIdentifiers);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public boolean mergeWith(SSAIdentifiers<KEYTYPE> other)
/*  55:    */   {
/*  56: 50 */     return mergeWith(other, null);
/*  57:    */   }
/*  58:    */   
/*  59:    */   private boolean registerChange(Map<KEYTYPE, SSAIdent> knownIdentifiers, KEYTYPE lValue, SSAIdent otherIdent)
/*  60:    */   {
/*  61: 54 */     if (!knownIdentifiers.containsKey(lValue))
/*  62:    */     {
/*  63: 55 */       knownIdentifiers.put(lValue, otherIdent);
/*  64: 56 */       return true;
/*  65:    */     }
/*  66: 59 */     SSAIdent oldIdent = (SSAIdent)knownIdentifiers.get(lValue);
/*  67: 60 */     Object k1 = oldIdent.getComparisonType();
/*  68: 61 */     Object k2 = otherIdent.getComparisonType();
/*  69:    */     SSAIdent newIdent;
/*  70:    */     SSAIdent newIdent;
/*  71: 63 */     if (k1 == k2) {
/*  72: 64 */       newIdent = oldIdent.mergeWith(otherIdent);
/*  73:    */     } else {
/*  74: 66 */       newIdent = SSAIdent.poison;
/*  75:    */     }
/*  76: 69 */     if (!newIdent.equals(oldIdent))
/*  77:    */     {
/*  78: 70 */       knownIdentifiers.put(lValue, newIdent);
/*  79: 71 */       return true;
/*  80:    */     }
/*  81: 74 */     return false;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public boolean mergeWith(SSAIdentifiers<KEYTYPE> other, BinaryPredicate<KEYTYPE, KEYTYPE> pred)
/*  85:    */   {
/*  86: 80 */     boolean changed = false;
/*  87: 81 */     for (Iterator i$ = other.knownIdentifiersOnExit.entrySet().iterator(); i$.hasNext(); changed = true)
/*  88:    */     {
/*  89: 81 */       Map.Entry<KEYTYPE, SSAIdent> valueSetEntry = (Map.Entry)i$.next();
/*  90: 82 */       KEYTYPE lValue = valueSetEntry.getKey();
/*  91: 83 */       SSAIdent otherIdent = (SSAIdent)valueSetEntry.getValue();
/*  92: 84 */       boolean c1 = registerChange(this.knownIdentifiersOnEntry, lValue, otherIdent);
/*  93: 85 */       boolean skip = false;
/*  94: 86 */       if ((this.fixedHere.containsKey(lValue)) && (
/*  95: 87 */         (pred == null) || (!pred.test(lValue, this.fixedHere.get(lValue))))) {
/*  96: 88 */         skip = true;
/*  97:    */       }
/*  98: 91 */       boolean c2 = (!skip) && (registerChange(this.knownIdentifiersOnExit, lValue, otherIdent));
/*  99: 92 */       if ((!c1) && (!c2)) {}
/* 100:    */     }
/* 101: 94 */     return changed;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public Set<KEYTYPE> getFixedHere()
/* 105:    */   {
/* 106: 98 */     return this.fixedHere.keySet();
/* 107:    */   }
/* 108:    */   
/* 109:    */   public boolean isValidReplacement(LValue lValue, SSAIdentifiers<KEYTYPE> other)
/* 110:    */   {
/* 111:116 */     SSAIdent thisVersion = (SSAIdent)this.knownIdentifiersOnEntry.get(lValue);
/* 112:117 */     SSAIdent otherVersion = (SSAIdent)other.knownIdentifiersOnExit.get(lValue);
/* 113:118 */     if ((thisVersion == null) && (otherVersion == null)) {
/* 114:118 */       return true;
/* 115:    */     }
/* 116:119 */     if ((thisVersion == null) || (otherVersion == null)) {
/* 117:119 */       return false;
/* 118:    */     }
/* 119:120 */     boolean res = thisVersion.equals(otherVersion);
/* 120:121 */     if (res) {
/* 121:121 */       return true;
/* 122:    */     }
/* 123:125 */     if (thisVersion.isSuperSet(otherVersion)) {
/* 124:125 */       return true;
/* 125:    */     }
/* 126:126 */     return false;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public boolean isValidReplacementOnExit(LValue lValue, SSAIdentifiers<KEYTYPE> other)
/* 130:    */   {
/* 131:130 */     SSAIdent thisVersion = (SSAIdent)this.knownIdentifiersOnExit.get(lValue);
/* 132:131 */     SSAIdent otherVersion = (SSAIdent)other.knownIdentifiersOnExit.get(lValue);
/* 133:132 */     if ((thisVersion == null) && (otherVersion == null)) {
/* 134:132 */       return true;
/* 135:    */     }
/* 136:133 */     if ((thisVersion == null) || (otherVersion == null)) {
/* 137:133 */       return false;
/* 138:    */     }
/* 139:134 */     boolean res = thisVersion.equals(otherVersion);
/* 140:135 */     if (res) {
/* 141:135 */       return true;
/* 142:    */     }
/* 143:139 */     if (thisVersion.isSuperSet(otherVersion)) {
/* 144:139 */       return true;
/* 145:    */     }
/* 146:140 */     return false;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public Set<KEYTYPE> getChanges()
/* 150:    */   {
/* 151:144 */     Set<KEYTYPE> result = SetFactory.newSet();
/* 152:145 */     for (Map.Entry<KEYTYPE, SSAIdent> entry : this.knownIdentifiersOnEntry.entrySet())
/* 153:    */     {
/* 154:146 */       SSAIdent after = (SSAIdent)this.knownIdentifiersOnExit.get(entry.getKey());
/* 155:147 */       if ((after != null) && (!after.equals(entry.getValue()))) {
/* 156:148 */         result.add(entry.getKey());
/* 157:    */       }
/* 158:    */     }
/* 159:151 */     return result;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public SSAIdent getSSAIdentOnExit(KEYTYPE lValue)
/* 163:    */   {
/* 164:155 */     return (SSAIdent)this.knownIdentifiersOnExit.get(lValue);
/* 165:    */   }
/* 166:    */   
/* 167:    */   public SSAIdent getSSAIdentOnEntry(KEYTYPE lValue)
/* 168:    */   {
/* 169:159 */     return (SSAIdent)this.knownIdentifiersOnEntry.get(lValue);
/* 170:    */   }
/* 171:    */   
/* 172:    */   public void removeEntryIdent(KEYTYPE key)
/* 173:    */   {
/* 174:163 */     this.knownIdentifiersOnEntry.remove(key);
/* 175:    */   }
/* 176:    */   
/* 177:    */   public void setKnownIdentifierOnExit(KEYTYPE lValue, SSAIdent ident)
/* 178:    */   {
/* 179:167 */     this.knownIdentifiersOnExit.put(lValue, ident);
/* 180:    */   }
/* 181:    */   
/* 182:    */   public void setKnownIdentifierOnEntry(KEYTYPE lValue, SSAIdent ident)
/* 183:    */   {
/* 184:171 */     this.knownIdentifiersOnEntry.put(lValue, ident);
/* 185:    */   }
/* 186:    */   
/* 187:    */   public int sizeOnExit()
/* 188:    */   {
/* 189:175 */     return this.knownIdentifiersOnExit.size();
/* 190:    */   }
/* 191:    */   
/* 192:    */   public Map<KEYTYPE, SSAIdent> getKnownIdentifiersOnExit()
/* 193:    */   {
/* 194:179 */     return this.knownIdentifiersOnExit;
/* 195:    */   }
/* 196:    */   
/* 197:    */   public String toString()
/* 198:    */   {
/* 199:184 */     StringBuilder sb = new StringBuilder();
/* 200:185 */     for (Map.Entry<KEYTYPE, SSAIdent> entry : this.knownIdentifiersOnEntry.entrySet()) {
/* 201:186 */       sb.append(entry.getKey()).append("@").append(entry.getValue()).append(" ");
/* 202:    */     }
/* 203:188 */     sb.append(" -> ");
/* 204:189 */     for (Map.Entry<KEYTYPE, SSAIdent> entry : this.knownIdentifiersOnExit.entrySet()) {
/* 205:190 */       sb.append(entry.getKey()).append("@").append(entry.getValue()).append(" ");
/* 206:    */     }
/* 207:192 */     return sb.toString();
/* 208:    */   }
/* 209:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers
 * JD-Core Version:    0.7.0.1
 */