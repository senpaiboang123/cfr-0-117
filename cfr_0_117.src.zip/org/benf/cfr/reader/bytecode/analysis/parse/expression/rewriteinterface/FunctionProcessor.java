package org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface;

import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.VarArgsRewriter;

public abstract interface FunctionProcessor
{
  public abstract void rewriteVarArgs(VarArgsRewriter paramVarArgsRewriter);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface.FunctionProcessor
 * JD-Core Version:    0.7.0.1
 */