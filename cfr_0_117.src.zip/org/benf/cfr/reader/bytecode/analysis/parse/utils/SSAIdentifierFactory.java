/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.utils;
/*  2:   */ 
/*  3:   */ import java.util.Map;
/*  4:   */ import org.benf.cfr.reader.util.MapFactory;
/*  5:   */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  6:   */ 
/*  7:   */ public class SSAIdentifierFactory<KEYTYPE>
/*  8:   */ {
/*  9: 9 */   private final Map<KEYTYPE, Integer> nextIdentFor = MapFactory.newLazyMap(MapFactory.newLinkedMap(), new UnaryFunction()
/* 10:   */   {
/* 11:   */     public Integer invoke(KEYTYPE ignore)
/* 12:   */     {
/* 13:14 */       return Integer.valueOf(0);
/* 14:   */     }
/* 15: 9 */   });
/* 16:   */   private final UnaryFunction<KEYTYPE, Object> typeComparisonFunction;
/* 17:   */   
/* 18:   */   public SSAIdentifierFactory(UnaryFunction<KEYTYPE, Object> typeComparisonFunction)
/* 19:   */   {
/* 20:21 */     this.typeComparisonFunction = typeComparisonFunction;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public SSAIdent getIdent(KEYTYPE lValue)
/* 24:   */   {
/* 25:25 */     int val = ((Integer)this.nextIdentFor.get(lValue)).intValue();
/* 26:26 */     this.nextIdentFor.put(lValue, Integer.valueOf(val + 1));
/* 27:27 */     return new SSAIdent(val, this.typeComparisonFunction == null ? null : this.typeComparisonFunction.invoke(lValue));
/* 28:   */   }
/* 29:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifierFactory
 * JD-Core Version:    0.7.0.1
 */