package org.benf.cfr.reader.bytecode.analysis.parse.utils;

import java.util.Collection;

public abstract interface EquivalenceConstraint
{
  public abstract boolean equivalent(Object paramObject1, Object paramObject2);
  
  public abstract boolean equivalent(Collection paramCollection1, Collection paramCollection2);
  
  public abstract boolean equivalent(ComparableUnderEC paramComparableUnderEC1, ComparableUnderEC paramComparableUnderEC2);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint
 * JD-Core Version:    0.7.0.1
 */