/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.lvalue;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArrayIndex;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentCollector;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifierFactory;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  16:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  17:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  18:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  19:    */ 
/*  20:    */ public class ArrayVariable
/*  21:    */   extends AbstractLValue
/*  22:    */ {
/*  23:    */   private ArrayIndex arrayIndex;
/*  24:    */   
/*  25:    */   public ArrayVariable(ArrayIndex arrayIndex)
/*  26:    */   {
/*  27: 21 */     super(arrayIndex.getInferredJavaType());
/*  28: 22 */     this.arrayIndex = arrayIndex;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public void markFinal() {}
/*  32:    */   
/*  33:    */   public boolean isFinal()
/*  34:    */   {
/*  35: 32 */     return false;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public LValue deepClone(CloneHelper cloneHelper)
/*  39:    */   {
/*  40: 37 */     return new ArrayVariable((ArrayIndex)cloneHelper.replaceOrClone(this.arrayIndex));
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  44:    */   {
/*  45: 42 */     this.arrayIndex.collectTypeUsages(collector);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/*  49:    */   {
/*  50: 47 */     this.arrayIndex.collectUsedLValues(lValueUsageCollector);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public boolean doesBlackListLValueReplacement(LValue replace, Expression with)
/*  54:    */   {
/*  55: 52 */     return this.arrayIndex.doesBlackListLValueReplacement(replace, with);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public int getNumberOfCreators()
/*  59:    */   {
/*  60: 57 */     throw new ConfusedCFRException("NYI");
/*  61:    */   }
/*  62:    */   
/*  63:    */   public Precedence getPrecedence()
/*  64:    */   {
/*  65: 62 */     return Precedence.PAREN_SUB_MEMBER;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public Dumper dumpInner(Dumper d)
/*  69:    */   {
/*  70: 67 */     return this.arrayIndex.dump(d);
/*  71:    */   }
/*  72:    */   
/*  73:    */   public ArrayIndex getArrayIndex()
/*  74:    */   {
/*  75: 71 */     return this.arrayIndex;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void collectLValueAssignments(Expression assignedTo, StatementContainer statementContainer, LValueAssignmentCollector lValueAssigmentCollector) {}
/*  79:    */   
/*  80:    */   public LValue replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  81:    */   {
/*  82: 80 */     this.arrayIndex = ((ArrayIndex)this.arrayIndex.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer));
/*  83: 81 */     return this;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public LValue applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  87:    */   {
/*  88: 87 */     this.arrayIndex = ((ArrayIndex)this.arrayIndex.applyExpressionRewriter(expressionRewriter, ssaIdentifiers, statementContainer, ExpressionRewriterFlags.RVALUE));
/*  89: 88 */     return this;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public SSAIdentifiers<LValue> collectVariableMutation(SSAIdentifierFactory<LValue> ssaIdentifierFactory)
/*  93:    */   {
/*  94: 93 */     return new SSAIdentifiers();
/*  95:    */   }
/*  96:    */   
/*  97:    */   public boolean equals(Object o)
/*  98:    */   {
/*  99: 98 */     if (this == o) {
/* 100: 99 */       return true;
/* 101:    */     }
/* 102:101 */     if (!(o instanceof ArrayVariable)) {
/* 103:101 */       return false;
/* 104:    */     }
/* 105:102 */     ArrayVariable other = (ArrayVariable)o;
/* 106:103 */     return this.arrayIndex.equals(other.arrayIndex);
/* 107:    */   }
/* 108:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.lvalue.ArrayVariable
 * JD-Core Version:    0.7.0.1
 */