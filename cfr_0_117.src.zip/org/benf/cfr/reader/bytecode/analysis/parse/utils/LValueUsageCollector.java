package org.benf.cfr.reader.bytecode.analysis.parse.utils;

import org.benf.cfr.reader.bytecode.analysis.parse.LValue;

public abstract interface LValueUsageCollector
{
  public abstract void collect(LValue paramLValue);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector
 * JD-Core Version:    0.7.0.1
 */