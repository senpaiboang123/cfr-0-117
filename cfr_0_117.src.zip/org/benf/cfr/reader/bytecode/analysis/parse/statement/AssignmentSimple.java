/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractAssignmentExpression;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithOp;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithmeticOperation;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AssignmentExpression;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CastExpression;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.MemberFunctionInvokation;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.CreationCollector;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentCollector;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifierFactory;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredAssignment;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.CastAction;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  26:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/*  27:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  28:    */ 
/*  29:    */ public class AssignmentSimple
/*  30:    */   extends AbstractAssignment
/*  31:    */ {
/*  32:    */   private LValue lvalue;
/*  33:    */   private Expression rvalue;
/*  34:    */   
/*  35:    */   public AssignmentSimple(LValue lvalue, Expression rvalue)
/*  36:    */   {
/*  37: 21 */     this.lvalue = lvalue;
/*  38: 22 */     this.rvalue = lvalue.getInferredJavaType().chain(rvalue.getInferredJavaType()).performCastAction(rvalue, lvalue.getInferredJavaType());
/*  39:    */   }
/*  40:    */   
/*  41:    */   public AssignmentSimple(InferredJavaType type, LValue lvalue, Expression rvalue)
/*  42:    */   {
/*  43: 26 */     this.lvalue = lvalue;
/*  44: 27 */     this.rvalue = rvalue;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public Dumper dump(Dumper d)
/*  48:    */   {
/*  49: 32 */     return d.dump(this.lvalue).print(" = ").dump(this.rvalue).endCodeln();
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void collectLValueAssignments(LValueAssignmentCollector<Statement> lValueAssigmentCollector)
/*  53:    */   {
/*  54: 37 */     this.lvalue.collectLValueAssignments(this.rvalue, getContainer(), lValueAssigmentCollector);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public boolean doesBlackListLValueReplacement(LValue lValue, Expression expression)
/*  58:    */   {
/*  59: 42 */     return this.lvalue.doesBlackListLValueReplacement(lValue, expression);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/*  63:    */   {
/*  64: 47 */     this.rvalue.collectUsedLValues(lValueUsageCollector);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void collectObjectCreation(CreationCollector creationCollector)
/*  68:    */   {
/*  69: 52 */     creationCollector.collectCreation(this.lvalue, this.rvalue, getContainer());
/*  70:    */   }
/*  71:    */   
/*  72:    */   public SSAIdentifiers<LValue> collectLocallyMutatedVariables(SSAIdentifierFactory<LValue> ssaIdentifierFactory)
/*  73:    */   {
/*  74: 57 */     return this.lvalue.collectVariableMutation(ssaIdentifierFactory);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public LValue getCreatedLValue()
/*  78:    */   {
/*  79: 62 */     return this.lvalue;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public Expression getRValue()
/*  83:    */   {
/*  84: 67 */     return this.rvalue;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void setRValue(Expression rvalue)
/*  88:    */   {
/*  89: 71 */     this.rvalue = rvalue;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public boolean isSelfMutatingOperation()
/*  93:    */   {
/*  94: 81 */     Expression localR = this.rvalue;
/*  95: 82 */     while ((localR instanceof CastExpression)) {
/*  96: 82 */       localR = ((CastExpression)localR).getChild();
/*  97:    */     }
/*  98: 83 */     if ((localR instanceof ArithmeticOperation))
/*  99:    */     {
/* 100: 84 */       ArithmeticOperation arithmeticOperation = (ArithmeticOperation)localR;
/* 101: 85 */       if (arithmeticOperation.isLiteralFunctionOf(this.lvalue)) {
/* 102: 85 */         return true;
/* 103:    */       }
/* 104:    */     }
/* 105: 86 */     else if ((localR instanceof MemberFunctionInvokation))
/* 106:    */     {
/* 107: 87 */       MemberFunctionInvokation memberFunctionInvokation = (MemberFunctionInvokation)localR;
/* 108: 88 */       Expression object = memberFunctionInvokation.getObject();
/* 109: 89 */       if ((object instanceof LValueExpression))
/* 110:    */       {
/* 111: 90 */         LValue memberLValue = ((LValueExpression)object).getLValue();
/* 112: 91 */         if (memberLValue.equals(this.lvalue)) {
/* 113: 91 */           return true;
/* 114:    */         }
/* 115:    */       }
/* 116:    */     }
/* 117: 94 */     return false;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public boolean isSelfMutatingOp1(LValue lValue, ArithOp arithOp)
/* 121:    */   {
/* 122: 99 */     return false;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public Expression getPostMutation()
/* 126:    */   {
/* 127:113 */     throw new IllegalStateException();
/* 128:    */   }
/* 129:    */   
/* 130:    */   public AbstractAssignmentExpression getInliningExpression()
/* 131:    */   {
/* 132:118 */     return new AssignmentExpression(getCreatedLValue(), getRValue());
/* 133:    */   }
/* 134:    */   
/* 135:    */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers)
/* 136:    */   {
/* 137:123 */     this.lvalue = this.lvalue.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer());
/* 138:124 */     this.rvalue = this.rvalue.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer());
/* 139:    */     
/* 140:126 */     lValueRewriter.checkPostConditions(this.lvalue, this.rvalue);
/* 141:    */   }
/* 142:    */   
/* 143:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/* 144:    */   {
/* 145:131 */     this.lvalue = expressionRewriter.rewriteExpression(this.lvalue, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.LVALUE);
/* 146:132 */     this.rvalue = expressionRewriter.rewriteExpression(this.rvalue, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE);
/* 147:    */   }
/* 148:    */   
/* 149:    */   public StructuredStatement getStructuredStatement()
/* 150:    */   {
/* 151:137 */     return new StructuredAssignment(this.lvalue, this.rvalue);
/* 152:    */   }
/* 153:    */   
/* 154:    */   public boolean canThrow(ExceptionCheck caught)
/* 155:    */   {
/* 156:142 */     return (this.lvalue.canThrow(caught)) || (this.rvalue.canThrow(caught));
/* 157:    */   }
/* 158:    */   
/* 159:    */   public boolean equals(Object o)
/* 160:    */   {
/* 161:147 */     if (o == this) {
/* 162:147 */       return true;
/* 163:    */     }
/* 164:148 */     if (!(o instanceof AssignmentSimple)) {
/* 165:148 */       return false;
/* 166:    */     }
/* 167:150 */     AssignmentSimple other = (AssignmentSimple)o;
/* 168:151 */     return (this.lvalue.equals(other.lvalue)) && (this.rvalue.equals(other.rvalue));
/* 169:    */   }
/* 170:    */   
/* 171:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 172:    */   {
/* 173:156 */     if (o == null) {
/* 174:156 */       return false;
/* 175:    */     }
/* 176:157 */     if (o == this) {
/* 177:157 */       return true;
/* 178:    */     }
/* 179:158 */     if (getClass() != o.getClass()) {
/* 180:158 */       return false;
/* 181:    */     }
/* 182:159 */     AssignmentSimple other = (AssignmentSimple)o;
/* 183:160 */     if (!constraint.equivalent(this.lvalue, other.lvalue)) {
/* 184:160 */       return false;
/* 185:    */     }
/* 186:161 */     if (!constraint.equivalent(this.rvalue, other.rvalue)) {
/* 187:161 */       return false;
/* 188:    */     }
/* 189:162 */     return true;
/* 190:    */   }
/* 191:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.AssignmentSimple
 * JD-Core Version:    0.7.0.1
 */