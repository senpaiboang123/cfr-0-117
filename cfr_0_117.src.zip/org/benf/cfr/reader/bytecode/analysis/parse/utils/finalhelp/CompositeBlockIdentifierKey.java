/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.utils.finalhelp;
/*  2:   */ 
/*  3:   */ import java.util.Collections;
/*  4:   */ import java.util.List;
/*  5:   */ import java.util.Set;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  8:   */ import org.benf.cfr.reader.util.Functional;
/*  9:   */ import org.benf.cfr.reader.util.Predicate;
/* 10:   */ 
/* 11:   */ public class CompositeBlockIdentifierKey
/* 12:   */   implements Comparable<CompositeBlockIdentifierKey>
/* 13:   */ {
/* 14:   */   private final String key;
/* 15:   */   
/* 16:   */   public CompositeBlockIdentifierKey(Op03SimpleStatement statement)
/* 17:   */   {
/* 18:17 */     this(statement.getBlockIdentifiers());
/* 19:   */   }
/* 20:   */   
/* 21:   */   public CompositeBlockIdentifierKey(Set<BlockIdentifier> blockIdentifiers)
/* 22:   */   {
/* 23:21 */     List<BlockIdentifier> b = Functional.filter(blockIdentifiers, new Predicate()
/* 24:   */     {
/* 25:   */       public boolean test(BlockIdentifier in)
/* 26:   */       {
/* 27:24 */         switch (CompositeBlockIdentifierKey.2.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$utils$BlockType[in.getBlockType().ordinal()])
/* 28:   */         {
/* 29:   */         case 1: 
/* 30:   */         case 2: 
/* 31:27 */           return true;
/* 32:   */         }
/* 33:29 */         return false;
/* 34:   */       }
/* 35:32 */     });
/* 36:33 */     Collections.sort(b);
/* 37:34 */     StringBuilder sb = new StringBuilder();
/* 38:35 */     for (BlockIdentifier blockIdentifier : b) {
/* 39:36 */       sb.append(blockIdentifier.getIndex()).append(".");
/* 40:   */     }
/* 41:38 */     this.key = sb.toString();
/* 42:   */   }
/* 43:   */   
/* 44:   */   public boolean equals(Object o)
/* 45:   */   {
/* 46:43 */     if (this == o) {
/* 47:43 */       return true;
/* 48:   */     }
/* 49:44 */     if ((o == null) || (getClass() != o.getClass())) {
/* 50:44 */       return false;
/* 51:   */     }
/* 52:46 */     CompositeBlockIdentifierKey that = (CompositeBlockIdentifierKey)o;
/* 53:48 */     if (!this.key.equals(that.key)) {
/* 54:48 */       return false;
/* 55:   */     }
/* 56:50 */     return true;
/* 57:   */   }
/* 58:   */   
/* 59:   */   public int hashCode()
/* 60:   */   {
/* 61:55 */     return this.key.hashCode();
/* 62:   */   }
/* 63:   */   
/* 64:   */   public int compareTo(CompositeBlockIdentifierKey compositeBlockIdentifierKey)
/* 65:   */   {
/* 66:60 */     if (compositeBlockIdentifierKey == this) {
/* 67:60 */       return 0;
/* 68:   */     }
/* 69:61 */     if (this.key.length() < compositeBlockIdentifierKey.key.length()) {
/* 70:61 */       return -1;
/* 71:   */     }
/* 72:62 */     return this.key.compareTo(compositeBlockIdentifierKey.key);
/* 73:   */   }
/* 74:   */   
/* 75:   */   public String toString()
/* 76:   */   {
/* 77:67 */     return "CompositeBlockIdentifierKey{key='" + this.key + '\'' + '}';
/* 78:   */   }
/* 79:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.finalhelp.CompositeBlockIdentifierKey
 * JD-Core Version:    0.7.0.1
 */