/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.rewriters;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.TernaryExpression;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.ConditionalUtils;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 11:   */ 
/* 12:   */ public class ConditionalSimplifyingRewriter
/* 13:   */   implements ExpressionRewriter
/* 14:   */ {
/* 15:   */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 16:   */   {
/* 17:21 */     expression = expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 18:22 */     if ((expression instanceof TernaryExpression)) {
/* 19:23 */       expression = ConditionalUtils.simplify((TernaryExpression)expression);
/* 20:24 */     } else if ((expression instanceof ConditionalExpression)) {
/* 21:25 */       expression = ConditionalUtils.simplify((ConditionalExpression)expression);
/* 22:   */     }
/* 23:27 */     return expression;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void handleStatement(StatementContainer statementContainer) {}
/* 27:   */   
/* 28:   */   public ConditionalExpression rewriteExpression(ConditionalExpression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 29:   */   {
/* 30:37 */     Expression res = expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 31:38 */     return (ConditionalExpression)res;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 35:   */   {
/* 36:49 */     return lValue;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public StackSSALabel rewriteExpression(StackSSALabel lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 40:   */   {
/* 41:54 */     return lValue;
/* 42:   */   }
/* 43:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ConditionalSimplifyingRewriter
 * JD-Core Version:    0.7.0.1
 */