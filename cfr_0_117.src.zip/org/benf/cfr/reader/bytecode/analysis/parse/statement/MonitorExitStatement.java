/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredComment;
/* 12:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 13:   */ 
/* 14:   */ public class MonitorExitStatement
/* 15:   */   extends MonitorStatement
/* 16:   */ {
/* 17:   */   private Expression monitor;
/* 18:   */   
/* 19:   */   public MonitorExitStatement(Expression monitor)
/* 20:   */   {
/* 21:18 */     this.monitor = monitor;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public Dumper dump(Dumper dumper)
/* 25:   */   {
/* 26:23 */     return dumper.print("MONITOREXIT : ").dump(this.monitor);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers)
/* 30:   */   {
/* 31:28 */     this.monitor = this.monitor.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer());
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/* 35:   */   {
/* 36:33 */     this.monitor = expressionRewriter.rewriteExpression(this.monitor, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE);
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/* 40:   */   {
/* 41:38 */     this.monitor.collectUsedLValues(lValueUsageCollector);
/* 42:   */   }
/* 43:   */   
/* 44:   */   public StructuredStatement getStructuredStatement()
/* 45:   */   {
/* 46:43 */     return new StructuredComment("** MonitorExit[" + this.monitor + "] (shouldn't be in output)");
/* 47:   */   }
/* 48:   */   
/* 49:   */   public Expression getMonitor()
/* 50:   */   {
/* 51:47 */     return this.monitor;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public boolean equals(Object o)
/* 55:   */   {
/* 56:52 */     if (o == this) {
/* 57:52 */       return true;
/* 58:   */     }
/* 59:53 */     if (!(o instanceof MonitorExitStatement)) {
/* 60:53 */       return false;
/* 61:   */     }
/* 62:54 */     MonitorExitStatement other = (MonitorExitStatement)o;
/* 63:55 */     return this.monitor.equals(other.monitor);
/* 64:   */   }
/* 65:   */   
/* 66:   */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 67:   */   {
/* 68:60 */     if (o == null) {
/* 69:60 */       return false;
/* 70:   */     }
/* 71:61 */     if (o == this) {
/* 72:61 */       return true;
/* 73:   */     }
/* 74:62 */     if (getClass() != o.getClass()) {
/* 75:62 */       return false;
/* 76:   */     }
/* 77:63 */     MonitorExitStatement other = (MonitorExitStatement)o;
/* 78:64 */     if (!constraint.equivalent(this.monitor, other.monitor)) {
/* 79:64 */       return false;
/* 80:   */     }
/* 81:65 */     return true;
/* 82:   */   }
/* 83:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.MonitorExitStatement
 * JD-Core Version:    0.7.0.1
 */