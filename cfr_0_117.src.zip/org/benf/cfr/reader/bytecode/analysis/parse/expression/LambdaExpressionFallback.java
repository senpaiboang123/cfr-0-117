/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterHelper;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  17:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  18:    */ import org.benf.cfr.reader.util.StringUtils;
/*  19:    */ import org.benf.cfr.reader.util.Troolean;
/*  20:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  21:    */ 
/*  22:    */ public class LambdaExpressionFallback
/*  23:    */   extends AbstractExpression
/*  24:    */   implements LambdaExpressionCommon
/*  25:    */ {
/*  26:    */   private JavaTypeInstance callClassType;
/*  27:    */   private String lambdaFnName;
/*  28:    */   private List<JavaTypeInstance> targetFnArgTypes;
/*  29:    */   private List<Expression> curriedArgs;
/*  30:    */   private boolean instance;
/*  31:    */   private final boolean colon;
/*  32:    */   
/*  33:    */   public LambdaExpressionFallback(JavaTypeInstance callClassType, InferredJavaType castJavaType, String lambdaFnName, List<JavaTypeInstance> targetFnArgTypes, List<Expression> curriedArgs, boolean instance)
/*  34:    */   {
/*  35: 38 */     super(castJavaType);
/*  36: 39 */     this.callClassType = callClassType;
/*  37: 40 */     this.lambdaFnName = (lambdaFnName.equals("<init>") ? "new" : lambdaFnName);
/*  38: 41 */     this.targetFnArgTypes = targetFnArgTypes;
/*  39: 42 */     this.curriedArgs = curriedArgs;
/*  40: 43 */     this.instance = instance;
/*  41: 44 */     boolean isColon = false;
/*  42: 45 */     switch (curriedArgs.size())
/*  43:    */     {
/*  44:    */     case 0: 
/*  45: 47 */       isColon = (targetFnArgTypes.size() <= 1) && (!instance);
/*  46: 48 */       if (instance)
/*  47:    */       {
/*  48: 50 */         isColon = true;
/*  49: 51 */         this.instance = false;
/*  50:    */       }
/*  51:    */       break;
/*  52:    */     case 1: 
/*  53: 55 */       isColon = (targetFnArgTypes.size() <= 1) && (instance);
/*  54:    */     }
/*  55: 58 */     this.colon = isColon;
/*  56:    */   }
/*  57:    */   
/*  58:    */   private LambdaExpressionFallback(InferredJavaType inferredJavaType, boolean colon, boolean instance, List<Expression> curriedArgs, List<JavaTypeInstance> targetFnArgTypes, String lambdaFnName, JavaTypeInstance callClassType)
/*  59:    */   {
/*  60: 62 */     super(inferredJavaType);
/*  61: 63 */     this.colon = colon;
/*  62: 64 */     this.instance = instance;
/*  63: 65 */     this.curriedArgs = curriedArgs;
/*  64: 66 */     this.targetFnArgTypes = targetFnArgTypes;
/*  65: 67 */     this.lambdaFnName = lambdaFnName;
/*  66: 68 */     this.callClassType = callClassType;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  70:    */   {
/*  71: 73 */     return new LambdaExpressionFallback(getInferredJavaType(), this.colon, this.instance, cloneHelper.replaceOrClone(this.curriedArgs), this.targetFnArgTypes, this.lambdaFnName, this.callClassType);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  75:    */   {
/*  76: 78 */     collector.collect(this.targetFnArgTypes);
/*  77: 79 */     collector.collectFrom(this.curriedArgs);
/*  78: 80 */     collector.collect(this.callClassType);
/*  79:    */   }
/*  80:    */   
/*  81:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  82:    */   {
/*  83: 85 */     throw new UnsupportedOperationException();
/*  84:    */   }
/*  85:    */   
/*  86:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  87:    */   {
/*  88: 90 */     ExpressionRewriterHelper.applyForwards(this.curriedArgs, expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  89: 91 */     return this;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  93:    */   {
/*  94: 96 */     ExpressionRewriterHelper.applyBackwards(this.curriedArgs, expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  95: 97 */     return this;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public Precedence getPrecedence()
/*  99:    */   {
/* 100:104 */     return Precedence.LAMBDA;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public Dumper dumpInner(Dumper d)
/* 104:    */   {
/* 105:109 */     if (this.colon)
/* 106:    */     {
/* 107:110 */       if (this.instance) {
/* 108:111 */         ((Expression)this.curriedArgs.get(0)).dumpWithOuterPrecedence(d, getPrecedence(), Troolean.TRUE).print("::").print(this.lambdaFnName);
/* 109:    */       } else {
/* 110:113 */         d.dump(this.callClassType).print("::").print(this.lambdaFnName);
/* 111:    */       }
/* 112:    */     }
/* 113:    */     else
/* 114:    */     {
/* 115:116 */       int n = this.targetFnArgTypes.size();
/* 116:117 */       boolean multi = n != 1;
/* 117:118 */       if (multi) {
/* 118:118 */         d.print("(");
/* 119:    */       }
/* 120:119 */       for (int x = 0; x < n; x++)
/* 121:    */       {
/* 122:120 */         if (x > 0) {
/* 123:120 */           d.print(", ");
/* 124:    */         }
/* 125:121 */         d.print("arg_" + x);
/* 126:    */       }
/* 127:123 */       if (multi) {
/* 128:123 */         d.print(")");
/* 129:    */       }
/* 130:124 */       if (this.instance)
/* 131:    */       {
/* 132:125 */         d = d.print(" -> ");
/* 133:126 */         ((Expression)this.curriedArgs.get(0)).dumpWithOuterPrecedence(d, getPrecedence(), Troolean.TRUE).print('.').print(this.lambdaFnName);
/* 134:    */       }
/* 135:    */       else
/* 136:    */       {
/* 137:128 */         d.print(" -> ").dump(this.callClassType).print('.').print(this.lambdaFnName);
/* 138:    */       }
/* 139:130 */       d.print("(");
/* 140:131 */       boolean first = true;
/* 141:132 */       int x = this.instance ? 1 : 0;
/* 142:132 */       for (int cnt = this.curriedArgs.size(); x < cnt; x++)
/* 143:    */       {
/* 144:133 */         Expression c = (Expression)this.curriedArgs.get(x);
/* 145:134 */         first = StringUtils.comma(first, d);
/* 146:135 */         d.dump(c);
/* 147:    */       }
/* 148:137 */       for (int x = 0; x < n; x++)
/* 149:    */       {
/* 150:138 */         first = StringUtils.comma(first, d);
/* 151:139 */         d.print("arg_" + x);
/* 152:    */       }
/* 153:141 */       d.print(")");
/* 154:    */     }
/* 155:143 */     return d;
/* 156:    */   }
/* 157:    */   
/* 158:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector) {}
/* 159:    */   
/* 160:    */   public boolean equals(Object o)
/* 161:    */   {
/* 162:152 */     if (this == o) {
/* 163:152 */       return true;
/* 164:    */     }
/* 165:153 */     if ((o == null) || (getClass() != o.getClass())) {
/* 166:153 */       return false;
/* 167:    */     }
/* 168:155 */     LambdaExpressionFallback that = (LambdaExpressionFallback)o;
/* 169:157 */     if (this.colon != that.colon) {
/* 170:157 */       return false;
/* 171:    */     }
/* 172:158 */     if (this.instance != that.instance) {
/* 173:158 */       return false;
/* 174:    */     }
/* 175:159 */     if (this.callClassType != null ? !this.callClassType.equals(that.callClassType) : that.callClassType != null) {
/* 176:160 */       return false;
/* 177:    */     }
/* 178:161 */     if (this.curriedArgs != null ? !this.curriedArgs.equals(that.curriedArgs) : that.curriedArgs != null) {
/* 179:161 */       return false;
/* 180:    */     }
/* 181:162 */     if (this.lambdaFnName != null ? !this.lambdaFnName.equals(that.lambdaFnName) : that.lambdaFnName != null) {
/* 182:162 */       return false;
/* 183:    */     }
/* 184:163 */     if (this.targetFnArgTypes != null ? !this.targetFnArgTypes.equals(that.targetFnArgTypes) : that.targetFnArgTypes != null) {
/* 185:164 */       return false;
/* 186:    */     }
/* 187:166 */     return true;
/* 188:    */   }
/* 189:    */   
/* 190:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 191:    */   {
/* 192:171 */     if (o == null) {
/* 193:171 */       return false;
/* 194:    */     }
/* 195:172 */     if (o == this) {
/* 196:172 */       return true;
/* 197:    */     }
/* 198:173 */     if (getClass() != o.getClass()) {
/* 199:173 */       return false;
/* 200:    */     }
/* 201:174 */     LambdaExpressionFallback other = (LambdaExpressionFallback)o;
/* 202:175 */     if (this.instance != other.instance) {
/* 203:175 */       return false;
/* 204:    */     }
/* 205:176 */     if (this.colon != other.colon) {
/* 206:176 */       return false;
/* 207:    */     }
/* 208:177 */     if (!constraint.equivalent(this.lambdaFnName, other.lambdaFnName)) {
/* 209:177 */       return false;
/* 210:    */     }
/* 211:178 */     if (!constraint.equivalent(this.curriedArgs, other.curriedArgs)) {
/* 212:178 */       return false;
/* 213:    */     }
/* 214:179 */     return true;
/* 215:    */   }
/* 216:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.LambdaExpressionFallback
 * JD-Core Version:    0.7.0.1
 */