/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.rewriters;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  9:   */ 
/* 10:   */ public abstract class AbstractExpressionRewriter
/* 11:   */   implements ExpressionRewriter
/* 12:   */ {
/* 13:   */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 14:   */   {
/* 15:15 */     return expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public ConditionalExpression rewriteExpression(ConditionalExpression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 19:   */   {
/* 20:20 */     return (ConditionalExpression)expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 24:   */   {
/* 25:30 */     return lValue;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public StackSSALabel rewriteExpression(StackSSALabel lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 29:   */   {
/* 30:37 */     return lValue;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public void handleStatement(StatementContainer statementContainer) {}
/* 34:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.rewriters.AbstractExpressionRewriter
 * JD-Core Version:    0.7.0.1
 */