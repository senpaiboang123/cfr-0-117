/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import java.util.Iterator;
/*   4:    */ import java.util.List;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.PrimitiveBoxingRewriter;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.VarArgsRewriter;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface.BoxingProcessor;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface.FunctionProcessor;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterHelper;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.BindingSuperContainer;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.GenericTypeBinder;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericBaseInstance;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericRefTypeInstance;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  26:    */ import org.benf.cfr.reader.entities.classfilehelpers.OverloadMethodSet;
/*  27:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  28:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass;
/*  29:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodRef;
/*  30:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/*  31:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  32:    */ 
/*  33:    */ public abstract class AbstractMemberFunctionInvokation
/*  34:    */   extends AbstractFunctionInvokation
/*  35:    */   implements FunctionProcessor, BoxingProcessor
/*  36:    */ {
/*  37:    */   private final ConstantPool cp;
/*  38:    */   private final List<Expression> args;
/*  39:    */   private Expression object;
/*  40:    */   private final List<Boolean> nulls;
/*  41:    */   
/*  42:    */   public AbstractMemberFunctionInvokation(ConstantPool cp, ConstantPoolEntryMethodRef function, Expression object, List<Expression> args, List<Boolean> nulls)
/*  43:    */   {
/*  44: 33 */     super(function, new InferredJavaType(function.getMethodPrototype().getReturnType(object.getInferredJavaType().getJavaTypeInstance(), args), InferredJavaType.Source.FUNCTION, true));
/*  45:    */     
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50: 39 */     this.object = object;
/*  51: 40 */     this.args = args;
/*  52: 41 */     this.nulls = nulls;
/*  53: 42 */     this.cp = cp;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  57:    */   {
/*  58:    */     Expression arg;
/*  59: 47 */     for (Iterator i$ = this.args.iterator(); i$.hasNext(); arg.collectTypeUsages(collector)) {
/*  60: 47 */       arg = (Expression)i$.next();
/*  61:    */     }
/*  62: 48 */     getMethodPrototype().collectTypeUsages(collector);
/*  63: 49 */     collector.collectFrom(this.object);
/*  64: 50 */     super.collectTypeUsages(collector);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  68:    */   {
/*  69: 55 */     for (int x = this.args.size() - 1; x >= 0; x--) {
/*  70: 56 */       this.args.set(x, ((Expression)this.args.get(x)).replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer));
/*  71:    */     }
/*  72: 58 */     this.object = this.object.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/*  73: 59 */     return this;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  77:    */   {
/*  78: 64 */     this.object = expressionRewriter.rewriteExpression(this.object, ssaIdentifiers, statementContainer, flags);
/*  79: 65 */     applyExpressionRewriterToArgs(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  80: 66 */     return this;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  84:    */   {
/*  85: 71 */     ExpressionRewriterHelper.applyForwards(this.args, expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  86: 72 */     this.object = expressionRewriter.rewriteExpression(this.object, ssaIdentifiers, statementContainer, flags);
/*  87: 73 */     return this;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public void applyExpressionRewriterToArgs(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  91:    */   {
/*  92: 78 */     ExpressionRewriterHelper.applyForwards(this.args, expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public void setExplicitGenerics(List<JavaTypeInstance> types) {}
/*  96:    */   
/*  97:    */   public List<JavaTypeInstance> getExplicitGenerics()
/*  98:    */   {
/*  99: 88 */     return null;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public Expression getObject()
/* 103:    */   {
/* 104: 92 */     return this.object;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public JavaTypeInstance getClassTypeInstance()
/* 108:    */   {
/* 109: 96 */     return getFunction().getClassEntry().getTypeInstance();
/* 110:    */   }
/* 111:    */   
/* 112:    */   public List<Expression> getArgs()
/* 113:    */   {
/* 114:100 */     return this.args;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public List<Boolean> getNulls()
/* 118:    */   {
/* 119:104 */     return this.nulls;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public Expression getAppropriatelyCastArgument(int idx)
/* 123:    */   {
/* 124:108 */     return getMethodPrototype().getAppropriatelyCastedArgument((Expression)this.args.get(idx), idx);
/* 125:    */   }
/* 126:    */   
/* 127:    */   public ConstantPool getCp()
/* 128:    */   {
/* 129:112 */     return this.cp;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/* 133:    */   {
/* 134:118 */     this.object.collectUsedLValues(lValueUsageCollector);
/* 135:119 */     for (Expression expression : this.args) {
/* 136:120 */       expression.collectUsedLValues(lValueUsageCollector);
/* 137:    */     }
/* 138:    */   }
/* 139:    */   
/* 140:    */   private OverloadMethodSet getOverloadMethodSet()
/* 141:    */   {
/* 142:125 */     OverloadMethodSet overloadMethodSet = getFunction().getOverloadMethodSet();
/* 143:126 */     if (overloadMethodSet == null) {
/* 144:126 */       return null;
/* 145:    */     }
/* 146:127 */     JavaTypeInstance objectType = this.object.getInferredJavaType().getJavaTypeInstance();
/* 147:128 */     if ((objectType instanceof JavaGenericRefTypeInstance))
/* 148:    */     {
/* 149:129 */       JavaGenericRefTypeInstance genericType = (JavaGenericRefTypeInstance)objectType;
/* 150:130 */       return overloadMethodSet.specialiseTo(genericType);
/* 151:    */     }
/* 152:132 */     return overloadMethodSet;
/* 153:    */   }
/* 154:    */   
/* 155:    */   public void rewriteVarArgs(VarArgsRewriter varArgsRewriter)
/* 156:    */   {
/* 157:137 */     MethodPrototype methodPrototype = getMethodPrototype();
/* 158:138 */     if (!methodPrototype.isVarArgs()) {
/* 159:138 */       return;
/* 160:    */     }
/* 161:139 */     OverloadMethodSet overloadMethodSet = getOverloadMethodSet();
/* 162:140 */     if (overloadMethodSet == null) {
/* 163:140 */       return;
/* 164:    */     }
/* 165:141 */     GenericTypeBinder gtb = methodPrototype.getTypeBinderFor(this.args);
/* 166:142 */     varArgsRewriter.rewriteVarArgsArg(overloadMethodSet, methodPrototype, this.args, gtb);
/* 167:    */   }
/* 168:    */   
/* 169:    */   private Expression insertCastOrIgnore(Expression arg, OverloadMethodSet overloadMethodSet, int x)
/* 170:    */   {
/* 171:147 */     JavaTypeInstance argType = overloadMethodSet.getArgType(x, arg.getInferredJavaType().getJavaTypeInstance());
/* 172:148 */     boolean ignore = false;
/* 173:149 */     if ((argType instanceof JavaGenericBaseInstance)) {
/* 174:151 */       ignore |= ((JavaGenericBaseInstance)argType).hasForeignUnbound(this.cp);
/* 175:    */     }
/* 176:156 */     if (!ignore)
/* 177:    */     {
/* 178:157 */       ignore |= arg instanceof LambdaExpression;
/* 179:158 */       ignore |= arg instanceof LambdaExpressionFallback;
/* 180:    */     }
/* 181:160 */     if (!ignore) {
/* 182:161 */       arg = new CastExpression(new InferredJavaType(argType, InferredJavaType.Source.EXPRESSION, true), arg);
/* 183:    */     }
/* 184:163 */     return arg;
/* 185:    */   }
/* 186:    */   
/* 187:    */   public boolean rewriteBoxing(PrimitiveBoxingRewriter boxingRewriter)
/* 188:    */   {
/* 189:168 */     if (this.args.isEmpty()) {
/* 190:168 */       return false;
/* 191:    */     }
/* 192:173 */     OverloadMethodSet overloadMethodSet = getOverloadMethodSet();
/* 193:174 */     if (overloadMethodSet == null)
/* 194:    */     {
/* 195:175 */       boxingRewriter.removeRedundantCastOnly(this.args);
/* 196:176 */       return false;
/* 197:    */     }
/* 198:179 */     MethodPrototype methodPrototype = getMethodPrototype();
/* 199:180 */     BindingSuperContainer bindingSuperContainer = this.object.getInferredJavaType().getJavaTypeInstance().getBindingSupers();
/* 200:181 */     GenericTypeBinder gtb = methodPrototype.getTypeBinderFor(this.args);
/* 201:    */     
/* 202:183 */     boolean callsCorrectEntireMethod = overloadMethodSet.callsCorrectEntireMethod(this.args, gtb);
/* 203:184 */     boolean nullsPresent = false;
/* 204:185 */     for (int x = 0; x < this.args.size(); x++)
/* 205:    */     {
/* 206:193 */       Expression arg = (Expression)this.args.get(x);
/* 207:198 */       if ((!callsCorrectEntireMethod) && (!overloadMethodSet.callsCorrectMethod(arg, x, gtb))) {
/* 208:203 */         arg = insertCastOrIgnore(arg, overloadMethodSet, x);
/* 209:    */       }
/* 210:206 */       arg = boxingRewriter.rewriteExpression(arg, null, null, null);
/* 211:207 */       arg = boxingRewriter.sugarParameterBoxing(arg, x, overloadMethodSet, gtb, methodPrototype);
/* 212:208 */       nullsPresent |= Literal.NULL.equals(arg);
/* 213:209 */       this.args.set(x, arg);
/* 214:    */     }
/* 215:211 */     if (nullsPresent)
/* 216:    */     {
/* 217:212 */       callsCorrectEntireMethod = overloadMethodSet.callsCorrectEntireMethod(this.args, gtb);
/* 218:213 */       if (!callsCorrectEntireMethod) {
/* 219:214 */         for (int x = 0; x < this.args.size(); x++)
/* 220:    */         {
/* 221:215 */           Expression arg = (Expression)this.args.get(x);
/* 222:216 */           if (Literal.NULL.equals(arg))
/* 223:    */           {
/* 224:217 */             arg = insertCastOrIgnore(arg, overloadMethodSet, x);
/* 225:218 */             this.args.set(x, arg);
/* 226:    */           }
/* 227:    */         }
/* 228:    */       }
/* 229:    */     }
/* 230:224 */     return true;
/* 231:    */   }
/* 232:    */   
/* 233:    */   public void applyNonArgExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 234:    */   {
/* 235:229 */     this.object = expressionRewriter.rewriteExpression(this.object, ssaIdentifiers, statementContainer, flags);
/* 236:    */   }
/* 237:    */   
/* 238:    */   public boolean canThrow(ExceptionCheck caught)
/* 239:    */   {
/* 240:240 */     return caught.checkAgainst(this);
/* 241:    */   }
/* 242:    */   
/* 243:    */   public boolean equals(Object o)
/* 244:    */   {
/* 245:245 */     if (o == null) {
/* 246:245 */       return false;
/* 247:    */     }
/* 248:246 */     if (o == this) {
/* 249:246 */       return true;
/* 250:    */     }
/* 251:247 */     if (!(o instanceof AbstractMemberFunctionInvokation)) {
/* 252:247 */       return false;
/* 253:    */     }
/* 254:248 */     AbstractMemberFunctionInvokation other = (AbstractMemberFunctionInvokation)o;
/* 255:249 */     if (!this.object.equals(other.object)) {
/* 256:249 */       return false;
/* 257:    */     }
/* 258:250 */     if (!this.args.equals(other.args)) {
/* 259:250 */       return false;
/* 260:    */     }
/* 261:251 */     return true;
/* 262:    */   }
/* 263:    */   
/* 264:    */   public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 265:    */   {
/* 266:256 */     if (o == null) {
/* 267:256 */       return false;
/* 268:    */     }
/* 269:257 */     if (o == this) {
/* 270:257 */       return true;
/* 271:    */     }
/* 272:258 */     if (!(o instanceof AbstractMemberFunctionInvokation)) {
/* 273:258 */       return false;
/* 274:    */     }
/* 275:259 */     AbstractMemberFunctionInvokation other = (AbstractMemberFunctionInvokation)o;
/* 276:260 */     if (!constraint.equivalent(this.object, other.object)) {
/* 277:260 */       return false;
/* 278:    */     }
/* 279:261 */     if (!constraint.equivalent(this.args, other.args)) {
/* 280:261 */       return false;
/* 281:    */     }
/* 282:262 */     return true;
/* 283:    */   }
/* 284:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractMemberFunctionInvokation
 * JD-Core Version:    0.7.0.1
 */