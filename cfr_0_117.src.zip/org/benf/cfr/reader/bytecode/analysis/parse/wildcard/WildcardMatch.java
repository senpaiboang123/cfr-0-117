/*    1:     */ package org.benf.cfr.reader.bytecode.analysis.parse.wildcard;
/*    2:     */ 
/*    3:     */ import java.util.AbstractList;
/*    4:     */ import java.util.Collection;
/*    5:     */ import java.util.List;
/*    6:     */ import java.util.Map;
/*    7:     */ import java.util.Set;
/*    8:     */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*    9:     */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   10:     */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   11:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractNewArray;
/*   12:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CastExpression;
/*   13:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*   14:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationAnonymousInner;
/*   15:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationSimple;
/*   16:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*   17:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.MemberFunctionInvokation;
/*   18:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.StaticFunctionInvokation;
/*   19:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.SuperFunctionInvokation;
/*   20:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   21:     */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*   22:     */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StaticVariable;
/*   23:     */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   24:     */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*   25:     */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*   26:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*   27:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*   28:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentCollector;
/*   29:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*   30:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*   31:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifierFactory;
/*   32:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*   33:     */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.Block;
/*   34:     */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*   35:     */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*   36:     */ import org.benf.cfr.reader.bytecode.analysis.types.annotated.JavaAnnotatedTypeInstance;
/*   37:     */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*   38:     */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*   39:     */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/*   40:     */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*   41:     */ import org.benf.cfr.reader.util.ListFactory;
/*   42:     */ import org.benf.cfr.reader.util.MapFactory;
/*   43:     */ import org.benf.cfr.reader.util.Predicate;
/*   44:     */ import org.benf.cfr.reader.util.Troolean;
/*   45:     */ import org.benf.cfr.reader.util.output.Dumpable;
/*   46:     */ import org.benf.cfr.reader.util.output.Dumper;
/*   47:     */ 
/*   48:     */ public class WildcardMatch
/*   49:     */ {
/*   50:     */   private Map<String, LValueWildcard> lValueMap;
/*   51:     */   private Map<String, StackLabelWildCard> lStackValueMap;
/*   52:     */   private Map<String, ExpressionWildcard> expressionMap;
/*   53:     */   private Map<String, NewArrayWildcard> newArrayWildcardMap;
/*   54:     */   private Map<String, MemberFunctionInvokationWildcard> memberFunctionMap;
/*   55:     */   private Map<String, SuperFunctionInvokationWildcard> superFunctionMap;
/*   56:     */   private Map<String, StaticFunctionInvokationWildcard> staticFunctionMap;
/*   57:     */   private Map<String, BlockIdentifierWildcard> blockIdentifierWildcardMap;
/*   58:     */   private Map<String, ListWildcard> listMap;
/*   59:     */   private Map<String, StaticVariableWildcard> staticVariableWildcardMap;
/*   60:     */   private Map<String, ConstructorInvokationSimpleWildcard> constructorWildcardMap;
/*   61:     */   private Map<String, ConstructorInvokationAnonymousInnerWildcard> constructorAnonymousWildcardMap;
/*   62:     */   private Map<String, CastExpressionWildcard> castWildcardMap;
/*   63:     */   private Map<String, ConditionalExpressionWildcard> conditionalWildcardMap;
/*   64:     */   private Map<String, BlockWildcard> blockWildcardMap;
/*   65:     */   
/*   66:     */   public WildcardMatch()
/*   67:     */   {
/*   68:  39 */     this.lValueMap = MapFactory.newMap();
/*   69:  40 */     this.lStackValueMap = MapFactory.newMap();
/*   70:  41 */     this.expressionMap = MapFactory.newMap();
/*   71:  42 */     this.newArrayWildcardMap = MapFactory.newMap();
/*   72:  43 */     this.memberFunctionMap = MapFactory.newMap();
/*   73:  44 */     this.superFunctionMap = MapFactory.newMap();
/*   74:  45 */     this.staticFunctionMap = MapFactory.newMap();
/*   75:  46 */     this.blockIdentifierWildcardMap = MapFactory.newMap();
/*   76:  47 */     this.listMap = MapFactory.newMap();
/*   77:  48 */     this.staticVariableWildcardMap = MapFactory.newMap();
/*   78:  49 */     this.constructorWildcardMap = MapFactory.newMap();
/*   79:  50 */     this.constructorAnonymousWildcardMap = MapFactory.newMap();
/*   80:  51 */     this.castWildcardMap = MapFactory.newMap();
/*   81:  52 */     this.conditionalWildcardMap = MapFactory.newMap();
/*   82:  53 */     this.blockWildcardMap = MapFactory.newMap();
/*   83:     */   }
/*   84:     */   
/*   85:     */   private <T> void reset(Collection<? extends Wildcard<T>> coll)
/*   86:     */   {
/*   87:  56 */     for (Wildcard<T> item : coll) {
/*   88:  57 */       item.resetMatch();
/*   89:     */     }
/*   90:     */   }
/*   91:     */   
/*   92:     */   public void reset()
/*   93:     */   {
/*   94:  62 */     reset(this.lValueMap.values());
/*   95:  63 */     reset(this.lStackValueMap.values());
/*   96:  64 */     reset(this.expressionMap.values());
/*   97:  65 */     reset(this.newArrayWildcardMap.values());
/*   98:  66 */     reset(this.memberFunctionMap.values());
/*   99:  67 */     reset(this.blockIdentifierWildcardMap.values());
/*  100:  68 */     reset(this.listMap.values());
/*  101:  69 */     reset(this.staticFunctionMap.values());
/*  102:  70 */     reset(this.staticVariableWildcardMap.values());
/*  103:  71 */     reset(this.superFunctionMap.values());
/*  104:  72 */     reset(this.constructorWildcardMap.values());
/*  105:  73 */     reset(this.constructorAnonymousWildcardMap.values());
/*  106:  74 */     reset(this.castWildcardMap.values());
/*  107:  75 */     reset(this.conditionalWildcardMap.values());
/*  108:  76 */     reset(this.blockWildcardMap.values());
/*  109:     */   }
/*  110:     */   
/*  111:     */   public BlockWildcard getBlockWildcard(String name)
/*  112:     */   {
/*  113:  80 */     BlockWildcard res = (BlockWildcard)this.blockWildcardMap.get(name);
/*  114:  81 */     if (res != null) {
/*  115:  81 */       return res;
/*  116:     */     }
/*  117:  83 */     res = new BlockWildcard();
/*  118:  84 */     this.blockWildcardMap.put(name, res);
/*  119:  85 */     return res;
/*  120:     */   }
/*  121:     */   
/*  122:     */   public StackLabelWildCard getStackLabelWildcard(String name)
/*  123:     */   {
/*  124:  89 */     StackLabelWildCard res = (StackLabelWildCard)this.lStackValueMap.get(name);
/*  125:  90 */     if (res != null) {
/*  126:  90 */       return res;
/*  127:     */     }
/*  128:  92 */     res = new StackLabelWildCard();
/*  129:  93 */     this.lStackValueMap.put(name, res);
/*  130:  94 */     return res;
/*  131:     */   }
/*  132:     */   
/*  133:     */   public ConditionalExpressionWildcard getConditionalExpressionWildcard(String name)
/*  134:     */   {
/*  135:  98 */     ConditionalExpressionWildcard res = (ConditionalExpressionWildcard)this.conditionalWildcardMap.get(name);
/*  136:  99 */     if (res != null) {
/*  137:  99 */       return res;
/*  138:     */     }
/*  139: 101 */     res = new ConditionalExpressionWildcard();
/*  140: 102 */     this.conditionalWildcardMap.put(name, res);
/*  141: 103 */     return res;
/*  142:     */   }
/*  143:     */   
/*  144:     */   public ConstructorInvokationSimpleWildcard getConstructorSimpleWildcard(String name)
/*  145:     */   {
/*  146: 107 */     ConstructorInvokationSimpleWildcard res = (ConstructorInvokationSimpleWildcard)this.constructorWildcardMap.get(name);
/*  147: 108 */     if (res != null) {
/*  148: 108 */       return res;
/*  149:     */     }
/*  150: 110 */     res = new ConstructorInvokationSimpleWildcard(null, null);
/*  151: 111 */     this.constructorWildcardMap.put(name, res);
/*  152: 112 */     return res;
/*  153:     */   }
/*  154:     */   
/*  155:     */   public ConstructorInvokationSimpleWildcard getConstructorSimpleWildcard(String name, JavaTypeInstance clazz)
/*  156:     */   {
/*  157: 116 */     ConstructorInvokationSimpleWildcard res = (ConstructorInvokationSimpleWildcard)this.constructorWildcardMap.get(name);
/*  158: 117 */     if (res != null) {
/*  159: 117 */       return res;
/*  160:     */     }
/*  161: 119 */     res = new ConstructorInvokationSimpleWildcard(clazz, null);
/*  162: 120 */     this.constructorWildcardMap.put(name, res);
/*  163: 121 */     return res;
/*  164:     */   }
/*  165:     */   
/*  166:     */   public ConstructorInvokationAnonymousInnerWildcard getConstructorAnonymousWildcard(String name)
/*  167:     */   {
/*  168: 125 */     ConstructorInvokationAnonymousInnerWildcard res = (ConstructorInvokationAnonymousInnerWildcard)this.constructorAnonymousWildcardMap.get(name);
/*  169: 126 */     if (res != null) {
/*  170: 126 */       return res;
/*  171:     */     }
/*  172: 128 */     res = new ConstructorInvokationAnonymousInnerWildcard(null, null);
/*  173: 129 */     this.constructorAnonymousWildcardMap.put(name, res);
/*  174: 130 */     return res;
/*  175:     */   }
/*  176:     */   
/*  177:     */   public ConstructorInvokationAnonymousInnerWildcard getConstructorAnonymousWildcard(String name, JavaTypeInstance clazz)
/*  178:     */   {
/*  179: 134 */     ConstructorInvokationAnonymousInnerWildcard res = (ConstructorInvokationAnonymousInnerWildcard)this.constructorAnonymousWildcardMap.get(name);
/*  180: 135 */     if (res != null) {
/*  181: 135 */       return res;
/*  182:     */     }
/*  183: 137 */     res = new ConstructorInvokationAnonymousInnerWildcard(clazz, null);
/*  184: 138 */     this.constructorAnonymousWildcardMap.put(name, res);
/*  185: 139 */     return res;
/*  186:     */   }
/*  187:     */   
/*  188:     */   public LValueWildcard getLValueWildCard(String name, Predicate<LValue> test)
/*  189:     */   {
/*  190: 144 */     LValueWildcard res = (LValueWildcard)this.lValueMap.get(name);
/*  191: 145 */     if (res != null) {
/*  192: 145 */       return res;
/*  193:     */     }
/*  194: 147 */     res = new LValueWildcard(name, test, null);
/*  195: 148 */     this.lValueMap.put(name, res);
/*  196: 149 */     return res;
/*  197:     */   }
/*  198:     */   
/*  199:     */   public LValueWildcard getLValueWildCard(String name)
/*  200:     */   {
/*  201: 153 */     LValueWildcard res = (LValueWildcard)this.lValueMap.get(name);
/*  202: 154 */     if (res != null) {
/*  203: 154 */       return res;
/*  204:     */     }
/*  205: 156 */     res = new LValueWildcard(name, null, null);
/*  206: 157 */     this.lValueMap.put(name, res);
/*  207: 158 */     return res;
/*  208:     */   }
/*  209:     */   
/*  210:     */   public ExpressionWildcard getExpressionWildCard(String name)
/*  211:     */   {
/*  212: 162 */     ExpressionWildcard res = (ExpressionWildcard)this.expressionMap.get(name);
/*  213: 163 */     if (res != null) {
/*  214: 163 */       return res;
/*  215:     */     }
/*  216: 165 */     res = new ExpressionWildcard(name);
/*  217: 166 */     this.expressionMap.put(name, res);
/*  218: 167 */     return res;
/*  219:     */   }
/*  220:     */   
/*  221:     */   public CastExpressionWildcard getCastExpressionWildcard(String name, Expression expression)
/*  222:     */   {
/*  223: 171 */     CastExpressionWildcard res = (CastExpressionWildcard)this.castWildcardMap.get(name);
/*  224: 172 */     if (res != null) {
/*  225: 172 */       return res;
/*  226:     */     }
/*  227: 174 */     res = new CastExpressionWildcard(null, expression);
/*  228: 175 */     this.castWildcardMap.put(name, res);
/*  229: 176 */     return res;
/*  230:     */   }
/*  231:     */   
/*  232:     */   public CastExpressionWildcard getCastExpressionWildcard(String name)
/*  233:     */   {
/*  234: 180 */     return (CastExpressionWildcard)this.castWildcardMap.get(name);
/*  235:     */   }
/*  236:     */   
/*  237:     */   public NewArrayWildcard getNewArrayWildCard(String name)
/*  238:     */   {
/*  239: 184 */     return getNewArrayWildCard(name, 1, null);
/*  240:     */   }
/*  241:     */   
/*  242:     */   public NewArrayWildcard getNewArrayWildCard(String name, int numSizedDims, Integer numTotalDims)
/*  243:     */   {
/*  244: 188 */     NewArrayWildcard res = (NewArrayWildcard)this.newArrayWildcardMap.get(name);
/*  245: 189 */     if (res != null) {
/*  246: 189 */       return res;
/*  247:     */     }
/*  248: 191 */     res = new NewArrayWildcard(name, numSizedDims, numTotalDims);
/*  249: 192 */     this.newArrayWildcardMap.put(name, res);
/*  250: 193 */     return res;
/*  251:     */   }
/*  252:     */   
/*  253:     */   public SuperFunctionInvokationWildcard getSuperFunction(String name)
/*  254:     */   {
/*  255: 198 */     return getSuperFunction(name, null);
/*  256:     */   }
/*  257:     */   
/*  258:     */   public SuperFunctionInvokationWildcard getSuperFunction(String name, List<Expression> args)
/*  259:     */   {
/*  260: 202 */     SuperFunctionInvokationWildcard res = (SuperFunctionInvokationWildcard)this.superFunctionMap.get(name);
/*  261: 203 */     if (res != null) {
/*  262: 203 */       return res;
/*  263:     */     }
/*  264: 205 */     res = new SuperFunctionInvokationWildcard(args);
/*  265: 206 */     this.superFunctionMap.put(name, res);
/*  266: 207 */     return res;
/*  267:     */   }
/*  268:     */   
/*  269:     */   public MemberFunctionInvokationWildcard getMemberFunction(String name)
/*  270:     */   {
/*  271: 211 */     return (MemberFunctionInvokationWildcard)this.memberFunctionMap.get(name);
/*  272:     */   }
/*  273:     */   
/*  274:     */   public MemberFunctionInvokationWildcard getMemberFunction(String name, boolean isInitMethod, Expression object)
/*  275:     */   {
/*  276: 215 */     return getMemberFunction(name, null, isInitMethod, object, ListFactory.newList());
/*  277:     */   }
/*  278:     */   
/*  279:     */   public MemberFunctionInvokationWildcard getMemberFunction(String name, String methodname, Expression object)
/*  280:     */   {
/*  281: 219 */     return getMemberFunction(name, methodname, false, object, ListFactory.newList());
/*  282:     */   }
/*  283:     */   
/*  284:     */   public MemberFunctionInvokationWildcard getMemberFunction(String name, String methodname, Expression object, Expression... args)
/*  285:     */   {
/*  286: 223 */     return getMemberFunction(name, methodname, false, object, ListFactory.newList(args));
/*  287:     */   }
/*  288:     */   
/*  289:     */   public MemberFunctionInvokationWildcard getMemberFunction(String name, String methodname, boolean isInitMethod, Expression object, List<Expression> args)
/*  290:     */   {
/*  291: 230 */     MemberFunctionInvokationWildcard res = (MemberFunctionInvokationWildcard)this.memberFunctionMap.get(name);
/*  292: 231 */     if (res != null) {
/*  293: 231 */       return res;
/*  294:     */     }
/*  295: 233 */     res = new MemberFunctionInvokationWildcard(methodname, isInitMethod, object, args);
/*  296: 234 */     this.memberFunctionMap.put(name, res);
/*  297: 235 */     return res;
/*  298:     */   }
/*  299:     */   
/*  300:     */   public StaticFunctionInvokationWildcard getStaticFunction(String name, JavaTypeInstance clazz, JavaTypeInstance returnType, String methodname)
/*  301:     */   {
/*  302: 239 */     return getStaticFunction(name, clazz, returnType, methodname, ListFactory.newList());
/*  303:     */   }
/*  304:     */   
/*  305:     */   public StaticFunctionInvokationWildcard getStaticFunction(String name, JavaTypeInstance clazz, JavaTypeInstance returnType, String methodname, Expression... args)
/*  306:     */   {
/*  307: 243 */     return getStaticFunction(name, clazz, returnType, methodname, ListFactory.newList(args));
/*  308:     */   }
/*  309:     */   
/*  310:     */   public StaticFunctionInvokationWildcard getStaticFunction(String name, JavaTypeInstance clazz, JavaTypeInstance returnType, String methodname, List<Expression> args)
/*  311:     */   {
/*  312: 250 */     StaticFunctionInvokationWildcard res = (StaticFunctionInvokationWildcard)this.staticFunctionMap.get(name);
/*  313: 251 */     if (res != null) {
/*  314: 251 */       return res;
/*  315:     */     }
/*  316: 253 */     res = new StaticFunctionInvokationWildcard(methodname, clazz, returnType, args);
/*  317: 254 */     this.staticFunctionMap.put(name, res);
/*  318: 255 */     return res;
/*  319:     */   }
/*  320:     */   
/*  321:     */   public StaticFunctionInvokationWildcard getStaticFunction(String name)
/*  322:     */   {
/*  323: 259 */     return (StaticFunctionInvokationWildcard)this.staticFunctionMap.get(name);
/*  324:     */   }
/*  325:     */   
/*  326:     */   public StaticVariableWildcard getStaticVariable(String name)
/*  327:     */   {
/*  328: 263 */     return (StaticVariableWildcard)this.staticVariableWildcardMap.get(name);
/*  329:     */   }
/*  330:     */   
/*  331:     */   public StaticVariableWildcard getStaticVariable(String name, JavaTypeInstance clazz, InferredJavaType varType)
/*  332:     */   {
/*  333: 267 */     return getStaticVariable(name, clazz, varType, true);
/*  334:     */   }
/*  335:     */   
/*  336:     */   public StaticVariableWildcard getStaticVariable(String name, JavaTypeInstance clazz, InferredJavaType varType, boolean requireTypeMatch)
/*  337:     */   {
/*  338: 271 */     StaticVariableWildcard res = (StaticVariableWildcard)this.staticVariableWildcardMap.get(name);
/*  339: 272 */     if (res != null) {
/*  340: 272 */       return res;
/*  341:     */     }
/*  342: 274 */     res = new StaticVariableWildcard(varType, clazz, requireTypeMatch);
/*  343: 275 */     this.staticVariableWildcardMap.put(name, res);
/*  344: 276 */     return res;
/*  345:     */   }
/*  346:     */   
/*  347:     */   public BlockIdentifierWildcard getBlockIdentifier(String name)
/*  348:     */   {
/*  349: 280 */     BlockIdentifierWildcard res = (BlockIdentifierWildcard)this.blockIdentifierWildcardMap.get(name);
/*  350: 281 */     if (res != null) {
/*  351: 281 */       return res;
/*  352:     */     }
/*  353: 283 */     res = new BlockIdentifierWildcard();
/*  354: 284 */     this.blockIdentifierWildcardMap.put(name, res);
/*  355: 285 */     return res;
/*  356:     */   }
/*  357:     */   
/*  358:     */   public <T> ListWildcard getList(String name)
/*  359:     */   {
/*  360: 289 */     ListWildcard res = (ListWildcard)this.listMap.get(name);
/*  361: 290 */     if (res != null) {
/*  362: 290 */       return res;
/*  363:     */     }
/*  364: 292 */     res = new ListWildcard();
/*  365: 293 */     this.listMap.put(name, res);
/*  366: 294 */     return res;
/*  367:     */   }
/*  368:     */   
/*  369:     */   public boolean match(Object pattern, Object test)
/*  370:     */   {
/*  371: 298 */     return pattern.equals(test);
/*  372:     */   }
/*  373:     */   
/*  374:     */   private static class DebugDumpable
/*  375:     */     implements Dumpable
/*  376:     */   {
/*  377:     */     public Dumper dump(Dumper dumper)
/*  378:     */     {
/*  379: 304 */       return dumper.print("" + getClass() + " : " + toString());
/*  380:     */     }
/*  381:     */   }
/*  382:     */   
/*  383:     */   public class LValueWildcard
/*  384:     */     extends WildcardMatch.DebugDumpable
/*  385:     */     implements LValue, Wildcard<LValue>
/*  386:     */   {
/*  387:     */     private final String name;
/*  388:     */     private final Predicate<LValue> test;
/*  389:     */     private transient LValue matchedValue;
/*  390:     */     
/*  391:     */     private LValueWildcard(Predicate<LValue> name)
/*  392:     */     {
/*  393: 314 */       super();
/*  394: 315 */       this.name = name;
/*  395: 316 */       this.test = test;
/*  396:     */     }
/*  397:     */     
/*  398:     */     public void markFinal() {}
/*  399:     */     
/*  400:     */     public boolean isFinal()
/*  401:     */     {
/*  402: 326 */       return false;
/*  403:     */     }
/*  404:     */     
/*  405:     */     public void collectTypeUsages(TypeUsageCollector collector) {}
/*  406:     */     
/*  407:     */     public void collectLValueUsage(LValueUsageCollector lValueUsageCollector) {}
/*  408:     */     
/*  409:     */     public JavaAnnotatedTypeInstance getAnnotatedCreationType()
/*  410:     */     {
/*  411: 339 */       throw new UnsupportedOperationException();
/*  412:     */     }
/*  413:     */     
/*  414:     */     public boolean doesBlackListLValueReplacement(LValue replace, Expression with)
/*  415:     */     {
/*  416: 344 */       return false;
/*  417:     */     }
/*  418:     */     
/*  419:     */     public LValue deepClone(CloneHelper cloneHelper)
/*  420:     */     {
/*  421: 349 */       throw new UnsupportedOperationException();
/*  422:     */     }
/*  423:     */     
/*  424:     */     public LValue outerDeepClone(CloneHelper cloneHelper)
/*  425:     */     {
/*  426: 354 */       throw new UnsupportedOperationException();
/*  427:     */     }
/*  428:     */     
/*  429:     */     public int getNumberOfCreators()
/*  430:     */     {
/*  431: 359 */       throw new UnsupportedOperationException();
/*  432:     */     }
/*  433:     */     
/*  434:     */     public void collectLValueAssignments(Expression assignedTo, StatementContainer statementContainer, LValueAssignmentCollector lValueAssigmentCollector)
/*  435:     */     {
/*  436: 364 */       throw new UnsupportedOperationException();
/*  437:     */     }
/*  438:     */     
/*  439:     */     public SSAIdentifiers<LValue> collectVariableMutation(SSAIdentifierFactory<LValue> ssaIdentifierFactory)
/*  440:     */     {
/*  441: 369 */       throw new UnsupportedOperationException();
/*  442:     */     }
/*  443:     */     
/*  444:     */     public LValue replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  445:     */     {
/*  446: 374 */       throw new UnsupportedOperationException();
/*  447:     */     }
/*  448:     */     
/*  449:     */     public LValue applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  450:     */     {
/*  451: 379 */       return this;
/*  452:     */     }
/*  453:     */     
/*  454:     */     public InferredJavaType getInferredJavaType()
/*  455:     */     {
/*  456: 384 */       return InferredJavaType.IGNORE;
/*  457:     */     }
/*  458:     */     
/*  459:     */     public Precedence getPrecedence()
/*  460:     */     {
/*  461: 389 */       throw new UnsupportedOperationException();
/*  462:     */     }
/*  463:     */     
/*  464:     */     public Dumper dumpWithOuterPrecedence(Dumper d, Precedence outerPrecedence, Troolean isLhs)
/*  465:     */     {
/*  466: 394 */       return d;
/*  467:     */     }
/*  468:     */     
/*  469:     */     public boolean canThrow(ExceptionCheck caught)
/*  470:     */     {
/*  471: 399 */       return true;
/*  472:     */     }
/*  473:     */     
/*  474:     */     public boolean equals(Object o)
/*  475:     */     {
/*  476: 404 */       if (!(o instanceof LValue)) {
/*  477: 405 */         return false;
/*  478:     */       }
/*  479: 407 */       if (this.matchedValue == null)
/*  480:     */       {
/*  481: 408 */         if ((this.test == null) || (this.test.test((LValue)o)))
/*  482:     */         {
/*  483: 409 */           this.matchedValue = ((LValue)o);
/*  484: 410 */           return true;
/*  485:     */         }
/*  486: 412 */         return false;
/*  487:     */       }
/*  488: 414 */       return this.matchedValue.equals(o);
/*  489:     */     }
/*  490:     */     
/*  491:     */     public LValue getMatch()
/*  492:     */     {
/*  493: 419 */       return this.matchedValue;
/*  494:     */     }
/*  495:     */     
/*  496:     */     public void resetMatch()
/*  497:     */     {
/*  498: 424 */       this.matchedValue = null;
/*  499:     */     }
/*  500:     */   }
/*  501:     */   
/*  502:     */   public class StackLabelWildCard
/*  503:     */     extends StackSSALabel
/*  504:     */     implements Wildcard<StackSSALabel>
/*  505:     */   {
/*  506:     */     private transient StackSSALabel matchedValue;
/*  507:     */     
/*  508:     */     public StackLabelWildCard()
/*  509:     */     {
/*  510: 432 */       super();
/*  511:     */     }
/*  512:     */     
/*  513:     */     public boolean equals(Object o)
/*  514:     */     {
/*  515: 437 */       if (!(o instanceof StackSSALabel)) {
/*  516: 438 */         return false;
/*  517:     */       }
/*  518: 440 */       if (this.matchedValue == null)
/*  519:     */       {
/*  520: 441 */         this.matchedValue = ((StackSSALabel)o);
/*  521: 442 */         return true;
/*  522:     */       }
/*  523: 444 */       return this.matchedValue.equals(o);
/*  524:     */     }
/*  525:     */     
/*  526:     */     public StackSSALabel getMatch()
/*  527:     */     {
/*  528: 449 */       return this.matchedValue;
/*  529:     */     }
/*  530:     */     
/*  531:     */     public void resetMatch()
/*  532:     */     {
/*  533: 454 */       this.matchedValue = null;
/*  534:     */     }
/*  535:     */   }
/*  536:     */   
/*  537:     */   private abstract class AbstractBaseExpressionWildcard
/*  538:     */     extends WildcardMatch.DebugDumpable
/*  539:     */     implements Expression
/*  540:     */   {
/*  541:     */     private AbstractBaseExpressionWildcard()
/*  542:     */     {
/*  543: 458 */       super();
/*  544:     */     }
/*  545:     */     
/*  546:     */     public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  547:     */     {
/*  548: 462 */       throw new UnsupportedOperationException();
/*  549:     */     }
/*  550:     */     
/*  551:     */     public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  552:     */     {
/*  553: 467 */       throw new UnsupportedOperationException();
/*  554:     */     }
/*  555:     */     
/*  556:     */     public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  557:     */     {
/*  558: 472 */       return applyExpressionRewriter(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  559:     */     }
/*  560:     */     
/*  561:     */     public boolean isSimple()
/*  562:     */     {
/*  563: 477 */       throw new UnsupportedOperationException();
/*  564:     */     }
/*  565:     */     
/*  566:     */     public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/*  567:     */     {
/*  568: 482 */       throw new UnsupportedOperationException();
/*  569:     */     }
/*  570:     */     
/*  571:     */     public boolean canPushDownInto()
/*  572:     */     {
/*  573: 487 */       throw new UnsupportedOperationException();
/*  574:     */     }
/*  575:     */     
/*  576:     */     public Expression pushDown(Expression toPush, Expression parent)
/*  577:     */     {
/*  578: 492 */       throw new UnsupportedOperationException();
/*  579:     */     }
/*  580:     */     
/*  581:     */     public InferredJavaType getInferredJavaType()
/*  582:     */     {
/*  583: 497 */       return InferredJavaType.IGNORE;
/*  584:     */     }
/*  585:     */     
/*  586:     */     public Expression deepClone(CloneHelper cloneHelper)
/*  587:     */     {
/*  588: 502 */       throw new UnsupportedOperationException();
/*  589:     */     }
/*  590:     */     
/*  591:     */     public Expression outerDeepClone(CloneHelper cloneHelper)
/*  592:     */     {
/*  593: 507 */       throw new UnsupportedOperationException();
/*  594:     */     }
/*  595:     */     
/*  596:     */     public Precedence getPrecedence()
/*  597:     */     {
/*  598: 512 */       return Precedence.WEAKEST;
/*  599:     */     }
/*  600:     */     
/*  601:     */     public Dumper dumpWithOuterPrecedence(Dumper d, Precedence outerPrecedence, Troolean isLhs)
/*  602:     */     {
/*  603: 517 */       return dump(d);
/*  604:     */     }
/*  605:     */     
/*  606:     */     public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/*  607:     */     {
/*  608: 522 */       throw new UnsupportedOperationException();
/*  609:     */     }
/*  610:     */     
/*  611:     */     public void collectTypeUsages(TypeUsageCollector collector) {}
/*  612:     */     
/*  613:     */     public boolean canThrow(ExceptionCheck caught)
/*  614:     */     {
/*  615: 531 */       return true;
/*  616:     */     }
/*  617:     */     
/*  618:     */     public Literal getComputedLiteral(Map<LValue, Literal> display)
/*  619:     */     {
/*  620: 536 */       return null;
/*  621:     */     }
/*  622:     */   }
/*  623:     */   
/*  624:     */   public class ExpressionWildcard
/*  625:     */     extends WildcardMatch.AbstractBaseExpressionWildcard
/*  626:     */     implements Wildcard<Expression>
/*  627:     */   {
/*  628:     */     private final String name;
/*  629:     */     private transient Expression matchedValue;
/*  630:     */     
/*  631:     */     public ExpressionWildcard(String name)
/*  632:     */     {
/*  633: 544 */       super(null);
/*  634: 545 */       this.name = name;
/*  635:     */     }
/*  636:     */     
/*  637:     */     public boolean equals(Object o)
/*  638:     */     {
/*  639: 550 */       if (!(o instanceof Expression)) {
/*  640: 551 */         return false;
/*  641:     */       }
/*  642: 553 */       if (this.matchedValue == null)
/*  643:     */       {
/*  644: 554 */         this.matchedValue = ((Expression)o);
/*  645: 555 */         return true;
/*  646:     */       }
/*  647: 557 */       return this.matchedValue.equals(o);
/*  648:     */     }
/*  649:     */     
/*  650:     */     public Expression getMatch()
/*  651:     */     {
/*  652: 562 */       return this.matchedValue;
/*  653:     */     }
/*  654:     */     
/*  655:     */     public void resetMatch()
/*  656:     */     {
/*  657: 567 */       this.matchedValue = null;
/*  658:     */     }
/*  659:     */   }
/*  660:     */   
/*  661:     */   public class NewArrayWildcard
/*  662:     */     extends WildcardMatch.AbstractBaseExpressionWildcard
/*  663:     */     implements Wildcard<AbstractNewArray>
/*  664:     */   {
/*  665:     */     private final String name;
/*  666:     */     private final int numSizedDims;
/*  667:     */     private final Integer numTotalDims;
/*  668:     */     private transient AbstractNewArray matchedValue;
/*  669:     */     
/*  670:     */     public NewArrayWildcard(String name, int numSizedDims, Integer numTotalDims)
/*  671:     */     {
/*  672: 578 */       super(null);
/*  673: 579 */       this.name = name;
/*  674: 580 */       this.numSizedDims = numSizedDims;
/*  675: 581 */       this.numTotalDims = numTotalDims;
/*  676:     */     }
/*  677:     */     
/*  678:     */     public boolean equals(Object o)
/*  679:     */     {
/*  680: 586 */       if (!(o instanceof AbstractNewArray)) {
/*  681: 587 */         return false;
/*  682:     */       }
/*  683: 589 */       if (this.matchedValue == null)
/*  684:     */       {
/*  685: 590 */         AbstractNewArray abstractNewArray = (AbstractNewArray)o;
/*  686: 591 */         if (this.numSizedDims != abstractNewArray.getNumSizedDims()) {
/*  687: 591 */           return false;
/*  688:     */         }
/*  689: 592 */         if ((this.numTotalDims != null) && (this.numTotalDims.intValue() != abstractNewArray.getNumDims())) {
/*  690: 592 */           return false;
/*  691:     */         }
/*  692: 593 */         this.matchedValue = abstractNewArray;
/*  693: 594 */         return true;
/*  694:     */       }
/*  695: 596 */       return this.matchedValue.equals(o);
/*  696:     */     }
/*  697:     */     
/*  698:     */     public AbstractNewArray getMatch()
/*  699:     */     {
/*  700: 601 */       return this.matchedValue;
/*  701:     */     }
/*  702:     */     
/*  703:     */     public void resetMatch()
/*  704:     */     {
/*  705: 606 */       this.matchedValue = null;
/*  706:     */     }
/*  707:     */   }
/*  708:     */   
/*  709:     */   public class MemberFunctionInvokationWildcard
/*  710:     */     extends WildcardMatch.AbstractBaseExpressionWildcard
/*  711:     */     implements Wildcard<MemberFunctionInvokation>
/*  712:     */   {
/*  713:     */     private final String name;
/*  714:     */     private final boolean isInitMethod;
/*  715:     */     private final Expression object;
/*  716:     */     private final List<Expression> args;
/*  717:     */     private transient MemberFunctionInvokation matchedValue;
/*  718:     */     
/*  719:     */     public MemberFunctionInvokationWildcard(boolean name, Expression isInitMethod, List<Expression> object)
/*  720:     */     {
/*  721: 618 */       super(null);
/*  722: 619 */       this.name = name;
/*  723: 620 */       this.isInitMethod = isInitMethod;
/*  724: 621 */       this.object = object;
/*  725: 622 */       this.args = args;
/*  726:     */     }
/*  727:     */     
/*  728:     */     public boolean equals(Object o)
/*  729:     */     {
/*  730: 627 */       if (!(o instanceof MemberFunctionInvokation)) {
/*  731: 627 */         return false;
/*  732:     */       }
/*  733: 628 */       if (this.matchedValue != null) {
/*  734: 628 */         return this.matchedValue.equals(o);
/*  735:     */       }
/*  736: 635 */       MemberFunctionInvokation other = (MemberFunctionInvokation)o;
/*  737: 636 */       if (this.isInitMethod != other.isInitMethod()) {
/*  738: 636 */         return false;
/*  739:     */       }
/*  740: 637 */       if (this.name != null) {
/*  741: 640 */         if (!this.name.equals(other.getName())) {
/*  742: 640 */           return false;
/*  743:     */         }
/*  744:     */       }
/*  745: 642 */       if (!this.object.equals(other.getObject())) {
/*  746: 642 */         return false;
/*  747:     */       }
/*  748: 643 */       List<Expression> otherArgs = other.getArgs();
/*  749: 644 */       if (this.args != null)
/*  750:     */       {
/*  751: 645 */         if (this.args.size() != otherArgs.size()) {
/*  752: 645 */           return false;
/*  753:     */         }
/*  754: 646 */         for (int x = 0; x < this.args.size(); x++)
/*  755:     */         {
/*  756: 647 */           Expression myArg = (Expression)this.args.get(x);
/*  757: 648 */           Expression hisArg = (Expression)otherArgs.get(x);
/*  758: 649 */           if (!myArg.equals(hisArg)) {
/*  759: 649 */             return false;
/*  760:     */           }
/*  761:     */         }
/*  762:     */       }
/*  763: 652 */       this.matchedValue = ((MemberFunctionInvokation)o);
/*  764: 653 */       return true;
/*  765:     */     }
/*  766:     */     
/*  767:     */     public MemberFunctionInvokation getMatch()
/*  768:     */     {
/*  769: 658 */       return this.matchedValue;
/*  770:     */     }
/*  771:     */     
/*  772:     */     public void resetMatch()
/*  773:     */     {
/*  774: 663 */       this.matchedValue = null;
/*  775:     */     }
/*  776:     */   }
/*  777:     */   
/*  778:     */   public class SuperFunctionInvokationWildcard
/*  779:     */     extends WildcardMatch.AbstractBaseExpressionWildcard
/*  780:     */     implements Wildcard<SuperFunctionInvokation>
/*  781:     */   {
/*  782:     */     private final List<Expression> args;
/*  783:     */     private transient SuperFunctionInvokation matchedValue;
/*  784:     */     
/*  785:     */     public SuperFunctionInvokationWildcard()
/*  786:     */     {
/*  787: 672 */       super(null);
/*  788: 673 */       this.args = args;
/*  789:     */     }
/*  790:     */     
/*  791:     */     public boolean equals(Object o)
/*  792:     */     {
/*  793: 678 */       if (!(o instanceof SuperFunctionInvokation)) {
/*  794: 678 */         return false;
/*  795:     */       }
/*  796: 679 */       if (this.matchedValue != null) {
/*  797: 679 */         return this.matchedValue.equals(o);
/*  798:     */       }
/*  799: 686 */       SuperFunctionInvokation other = (SuperFunctionInvokation)o;
/*  800: 687 */       if (this.args != null)
/*  801:     */       {
/*  802: 688 */         List<Expression> otherArgs = other.getArgs();
/*  803: 689 */         if (this.args.size() != otherArgs.size()) {
/*  804: 689 */           return false;
/*  805:     */         }
/*  806: 690 */         for (int x = 0; x < this.args.size(); x++)
/*  807:     */         {
/*  808: 691 */           Expression myArg = (Expression)this.args.get(x);
/*  809: 692 */           Expression hisArg = (Expression)otherArgs.get(x);
/*  810: 693 */           if (!myArg.equals(hisArg)) {
/*  811: 693 */             return false;
/*  812:     */           }
/*  813:     */         }
/*  814:     */       }
/*  815: 696 */       this.matchedValue = other;
/*  816: 697 */       return true;
/*  817:     */     }
/*  818:     */     
/*  819:     */     public SuperFunctionInvokation getMatch()
/*  820:     */     {
/*  821: 702 */       return this.matchedValue;
/*  822:     */     }
/*  823:     */     
/*  824:     */     public void resetMatch()
/*  825:     */     {
/*  826: 707 */       this.matchedValue = null;
/*  827:     */     }
/*  828:     */   }
/*  829:     */   
/*  830:     */   public class StaticFunctionInvokationWildcard
/*  831:     */     extends WildcardMatch.AbstractBaseExpressionWildcard
/*  832:     */     implements Wildcard<StaticFunctionInvokation>
/*  833:     */   {
/*  834:     */     private final String name;
/*  835:     */     private final JavaTypeInstance clazz;
/*  836:     */     private final JavaTypeInstance returnType;
/*  837:     */     private final List<Expression> args;
/*  838:     */     private transient StaticFunctionInvokation matchedValue;
/*  839:     */     
/*  840:     */     public StaticFunctionInvokationWildcard(JavaTypeInstance name, JavaTypeInstance clazz, List<Expression> returnType)
/*  841:     */     {
/*  842: 720 */       super(null);
/*  843: 721 */       this.name = name;
/*  844: 722 */       this.clazz = clazz;
/*  845: 723 */       this.args = args;
/*  846: 724 */       this.returnType = returnType;
/*  847:     */     }
/*  848:     */     
/*  849:     */     public boolean equals(Object o)
/*  850:     */     {
/*  851: 729 */       if (!(o instanceof StaticFunctionInvokation)) {
/*  852: 729 */         return false;
/*  853:     */       }
/*  854: 730 */       if (this.matchedValue != null) {
/*  855: 730 */         return this.matchedValue.equals(o);
/*  856:     */       }
/*  857: 732 */       StaticFunctionInvokation other = (StaticFunctionInvokation)o;
/*  858: 733 */       if ((this.name != null) && 
/*  859: 734 */         (!this.name.equals(other.getName()))) {
/*  860: 734 */         return false;
/*  861:     */       }
/*  862: 736 */       if ((this.returnType != null) && 
/*  863: 737 */         (!this.returnType.equals(other.getInferredJavaType().getJavaTypeInstance()))) {
/*  864: 737 */         return false;
/*  865:     */       }
/*  866: 739 */       if (!this.clazz.equals(other.getClazz())) {
/*  867: 739 */         return false;
/*  868:     */       }
/*  869: 740 */       List<Expression> otherArgs = other.getArgs();
/*  870: 741 */       if (this.args != null)
/*  871:     */       {
/*  872: 742 */         if (this.args.size() != otherArgs.size()) {
/*  873: 742 */           return false;
/*  874:     */         }
/*  875: 743 */         for (int x = 0; x < this.args.size(); x++)
/*  876:     */         {
/*  877: 744 */           Expression myArg = (Expression)this.args.get(x);
/*  878: 745 */           Expression hisArg = (Expression)otherArgs.get(x);
/*  879: 746 */           if (!myArg.equals(hisArg)) {
/*  880: 746 */             return false;
/*  881:     */           }
/*  882:     */         }
/*  883:     */       }
/*  884: 749 */       this.matchedValue = other;
/*  885: 750 */       return true;
/*  886:     */     }
/*  887:     */     
/*  888:     */     public StaticFunctionInvokation getMatch()
/*  889:     */     {
/*  890: 755 */       return this.matchedValue;
/*  891:     */     }
/*  892:     */     
/*  893:     */     public void resetMatch()
/*  894:     */     {
/*  895: 760 */       this.matchedValue = null;
/*  896:     */     }
/*  897:     */   }
/*  898:     */   
/*  899:     */   public class BlockIdentifierWildcard
/*  900:     */     extends BlockIdentifier
/*  901:     */     implements Wildcard<BlockIdentifier>
/*  902:     */   {
/*  903:     */     private BlockIdentifier matchedValue;
/*  904:     */     
/*  905:     */     public BlockIdentifierWildcard()
/*  906:     */     {
/*  907: 770 */       super(null);
/*  908:     */     }
/*  909:     */     
/*  910:     */     public boolean equals(Object o)
/*  911:     */     {
/*  912: 774 */       if (o == this) {
/*  913: 774 */         return true;
/*  914:     */       }
/*  915: 775 */       if (o == null) {
/*  916: 775 */         return false;
/*  917:     */       }
/*  918: 777 */       if (this.matchedValue != null) {
/*  919: 777 */         return this.matchedValue.equals(o);
/*  920:     */       }
/*  921: 779 */       if (!(o instanceof BlockIdentifier)) {
/*  922: 779 */         return false;
/*  923:     */       }
/*  924: 781 */       BlockIdentifier other = (BlockIdentifier)o;
/*  925: 782 */       this.matchedValue = other;
/*  926: 783 */       return true;
/*  927:     */     }
/*  928:     */     
/*  929:     */     public BlockIdentifier getMatch()
/*  930:     */     {
/*  931: 788 */       return this.matchedValue;
/*  932:     */     }
/*  933:     */     
/*  934:     */     public void resetMatch()
/*  935:     */     {
/*  936: 793 */       this.matchedValue = null;
/*  937:     */     }
/*  938:     */   }
/*  939:     */   
/*  940:     */   public class ListWildcard
/*  941:     */     extends AbstractList
/*  942:     */     implements Wildcard<List>
/*  943:     */   {
/*  944:     */     private List matchedValue;
/*  945:     */     
/*  946:     */     public ListWildcard() {}
/*  947:     */     
/*  948:     */     public Object get(int index)
/*  949:     */     {
/*  950: 804 */       throw new UnsupportedOperationException();
/*  951:     */     }
/*  952:     */     
/*  953:     */     public int size()
/*  954:     */     {
/*  955: 809 */       throw new UnsupportedOperationException();
/*  956:     */     }
/*  957:     */     
/*  958:     */     public boolean equals(Object o)
/*  959:     */     {
/*  960: 813 */       if (o == this) {
/*  961: 813 */         return true;
/*  962:     */       }
/*  963: 814 */       if (o == null) {
/*  964: 814 */         return false;
/*  965:     */       }
/*  966: 816 */       if (this.matchedValue != null) {
/*  967: 816 */         return this.matchedValue.equals(o);
/*  968:     */       }
/*  969: 818 */       if (!(o instanceof List)) {
/*  970: 818 */         return false;
/*  971:     */       }
/*  972: 820 */       List other = (List)o;
/*  973: 821 */       this.matchedValue = other;
/*  974: 822 */       return true;
/*  975:     */     }
/*  976:     */     
/*  977:     */     public List getMatch()
/*  978:     */     {
/*  979: 827 */       return this.matchedValue;
/*  980:     */     }
/*  981:     */     
/*  982:     */     public void resetMatch()
/*  983:     */     {
/*  984: 832 */       this.matchedValue = null;
/*  985:     */     }
/*  986:     */   }
/*  987:     */   
/*  988:     */   public class StaticVariableWildcard
/*  989:     */     extends StaticVariable
/*  990:     */     implements Wildcard<StaticVariable>
/*  991:     */   {
/*  992:     */     private StaticVariable matchedValue;
/*  993:     */     private final boolean requireTypeMatch;
/*  994:     */     
/*  995:     */     public StaticVariableWildcard(InferredJavaType type, JavaTypeInstance clazz, boolean requireTypeMatch)
/*  996:     */     {
/*  997: 842 */       super(clazz, null);
/*  998: 843 */       this.requireTypeMatch = requireTypeMatch;
/*  999:     */     }
/* 1000:     */     
/* 1001:     */     public StaticVariable getMatch()
/* 1002:     */     {
/* 1003: 848 */       return this.matchedValue;
/* 1004:     */     }
/* 1005:     */     
/* 1006:     */     public void resetMatch()
/* 1007:     */     {
/* 1008: 853 */       this.matchedValue = null;
/* 1009:     */     }
/* 1010:     */     
/* 1011:     */     public boolean equals(Object o)
/* 1012:     */     {
/* 1013: 858 */       if (o == this) {
/* 1014: 858 */         return true;
/* 1015:     */       }
/* 1016: 859 */       if (o == null) {
/* 1017: 859 */         return false;
/* 1018:     */       }
/* 1019: 861 */       if (this.matchedValue != null) {
/* 1020: 861 */         return this.matchedValue.equals(o);
/* 1021:     */       }
/* 1022: 863 */       if (!(o instanceof StaticVariable)) {
/* 1023: 863 */         return false;
/* 1024:     */       }
/* 1025: 864 */       StaticVariable other = (StaticVariable)o;
/* 1026: 866 */       if (!getOwningClassType().equals(other.getOwningClassType())) {
/* 1027: 866 */         return false;
/* 1028:     */       }
/* 1029: 867 */       JavaTypeInstance thisType = getInferredJavaType().getJavaTypeInstance();
/* 1030: 868 */       JavaTypeInstance otherType = other.getInferredJavaType().getJavaTypeInstance();
/* 1031: 869 */       if ((this.requireTypeMatch) && (!thisType.equals(otherType))) {
/* 1032: 870 */         return false;
/* 1033:     */       }
/* 1034: 872 */       this.matchedValue = other;
/* 1035: 873 */       return true;
/* 1036:     */     }
/* 1037:     */   }
/* 1038:     */   
/* 1039:     */   public class ConstructorInvokationSimpleWildcard
/* 1040:     */     extends WildcardMatch.AbstractBaseExpressionWildcard
/* 1041:     */     implements Wildcard<ConstructorInvokationSimple>
/* 1042:     */   {
/* 1043:     */     private ConstructorInvokationSimple matchedValue;
/* 1044:     */     private final JavaTypeInstance clazz;
/* 1045:     */     private final List<Expression> args;
/* 1046:     */     
/* 1047:     */     public ConstructorInvokationSimpleWildcard(List<Expression> clazz)
/* 1048:     */     {
/* 1049: 883 */       super(null);
/* 1050: 884 */       this.clazz = clazz;
/* 1051: 885 */       this.args = args;
/* 1052:     */     }
/* 1053:     */     
/* 1054:     */     public ConstructorInvokationSimple getMatch()
/* 1055:     */     {
/* 1056: 890 */       return this.matchedValue;
/* 1057:     */     }
/* 1058:     */     
/* 1059:     */     public void resetMatch()
/* 1060:     */     {
/* 1061: 895 */       this.matchedValue = null;
/* 1062:     */     }
/* 1063:     */     
/* 1064:     */     public boolean equals(Object o)
/* 1065:     */     {
/* 1066: 900 */       if (o == this) {
/* 1067: 900 */         return true;
/* 1068:     */       }
/* 1069: 901 */       if (o == null) {
/* 1070: 901 */         return false;
/* 1071:     */       }
/* 1072: 902 */       if (!(o instanceof ConstructorInvokationSimple)) {
/* 1073: 902 */         return false;
/* 1074:     */       }
/* 1075: 904 */       if (this.matchedValue != null) {
/* 1076: 905 */         return this.matchedValue.equals(o);
/* 1077:     */       }
/* 1078: 908 */       ConstructorInvokationSimple other = (ConstructorInvokationSimple)o;
/* 1079: 909 */       if (!this.clazz.equals(other.getTypeInstance())) {
/* 1080: 909 */         return false;
/* 1081:     */       }
/* 1082: 910 */       if ((this.args != null) && (this.args.equals(other.getArgs()))) {
/* 1083: 910 */         return false;
/* 1084:     */       }
/* 1085: 912 */       this.matchedValue = other;
/* 1086: 913 */       return true;
/* 1087:     */     }
/* 1088:     */   }
/* 1089:     */   
/* 1090:     */   public class ConstructorInvokationAnonymousInnerWildcard
/* 1091:     */     extends WildcardMatch.AbstractBaseExpressionWildcard
/* 1092:     */     implements Wildcard<ConstructorInvokationAnonymousInner>
/* 1093:     */   {
/* 1094:     */     private ConstructorInvokationAnonymousInner matchedValue;
/* 1095:     */     private final JavaTypeInstance clazz;
/* 1096:     */     private final List<Expression> args;
/* 1097:     */     
/* 1098:     */     public ConstructorInvokationAnonymousInnerWildcard(List<Expression> clazz)
/* 1099:     */     {
/* 1100: 923 */       super(null);
/* 1101: 924 */       this.clazz = clazz;
/* 1102: 925 */       this.args = args;
/* 1103:     */     }
/* 1104:     */     
/* 1105:     */     public ConstructorInvokationAnonymousInner getMatch()
/* 1106:     */     {
/* 1107: 930 */       return this.matchedValue;
/* 1108:     */     }
/* 1109:     */     
/* 1110:     */     public void resetMatch()
/* 1111:     */     {
/* 1112: 935 */       this.matchedValue = null;
/* 1113:     */     }
/* 1114:     */     
/* 1115:     */     public boolean equals(Object o)
/* 1116:     */     {
/* 1117: 940 */       if (o == this) {
/* 1118: 940 */         return true;
/* 1119:     */       }
/* 1120: 941 */       if (o == null) {
/* 1121: 941 */         return false;
/* 1122:     */       }
/* 1123: 942 */       if (!(o instanceof ConstructorInvokationAnonymousInner)) {
/* 1124: 942 */         return false;
/* 1125:     */       }
/* 1126: 944 */       if (this.matchedValue != null) {
/* 1127: 945 */         return this.matchedValue.equals(o);
/* 1128:     */       }
/* 1129: 948 */       ConstructorInvokationAnonymousInner other = (ConstructorInvokationAnonymousInner)o;
/* 1130: 949 */       JavaTypeInstance otherType = other.getTypeInstance();
/* 1131: 950 */       if ((this.clazz != null) && (!this.clazz.equals(otherType))) {
/* 1132: 950 */         return false;
/* 1133:     */       }
/* 1134: 951 */       if ((this.args != null) && (this.args.equals(other.getArgs()))) {
/* 1135: 951 */         return false;
/* 1136:     */       }
/* 1137: 953 */       this.matchedValue = other;
/* 1138: 954 */       return true;
/* 1139:     */     }
/* 1140:     */   }
/* 1141:     */   
/* 1142:     */   public class CastExpressionWildcard
/* 1143:     */     extends WildcardMatch.AbstractBaseExpressionWildcard
/* 1144:     */     implements Wildcard<CastExpression>
/* 1145:     */   {
/* 1146:     */     private final JavaTypeInstance clazz;
/* 1147:     */     private CastExpression matchedValue;
/* 1148:     */     private Expression expression;
/* 1149:     */     
/* 1150:     */     public CastExpressionWildcard(JavaTypeInstance clazz, Expression expression)
/* 1151:     */     {
/* 1152: 965 */       super(null);
/* 1153: 966 */       this.clazz = clazz;
/* 1154: 967 */       this.expression = expression;
/* 1155:     */     }
/* 1156:     */     
/* 1157:     */     public CastExpression getMatch()
/* 1158:     */     {
/* 1159: 972 */       return this.matchedValue;
/* 1160:     */     }
/* 1161:     */     
/* 1162:     */     public void resetMatch()
/* 1163:     */     {
/* 1164: 977 */       this.matchedValue = null;
/* 1165:     */     }
/* 1166:     */     
/* 1167:     */     public boolean equals(Object o)
/* 1168:     */     {
/* 1169: 982 */       if (o == this) {
/* 1170: 982 */         return true;
/* 1171:     */       }
/* 1172: 983 */       if (o == null) {
/* 1173: 983 */         return false;
/* 1174:     */       }
/* 1175: 984 */       if (!(o instanceof CastExpression)) {
/* 1176: 984 */         return false;
/* 1177:     */       }
/* 1178: 986 */       if (this.matchedValue != null) {
/* 1179: 987 */         return this.matchedValue.equals(o);
/* 1180:     */       }
/* 1181: 990 */       CastExpression other = (CastExpression)o;
/* 1182: 991 */       if ((this.clazz != null) && (!this.clazz.equals(other.getInferredJavaType().getJavaTypeInstance()))) {
/* 1183: 991 */         return false;
/* 1184:     */       }
/* 1185: 992 */       if (!this.expression.equals(other.getChild())) {
/* 1186: 992 */         return false;
/* 1187:     */       }
/* 1188: 995 */       this.matchedValue = other;
/* 1189: 996 */       return true;
/* 1190:     */     }
/* 1191:     */   }
/* 1192:     */   
/* 1193:     */   public class ConditionalExpressionWildcard
/* 1194:     */     extends WildcardMatch.AbstractBaseExpressionWildcard
/* 1195:     */     implements ConditionalExpression, Wildcard<ConditionalExpression>
/* 1196:     */   {
/* 1197:     */     private ConditionalExpression matchedValue;
/* 1198:     */     
/* 1199:     */     public ConditionalExpressionWildcard()
/* 1200:     */     {
/* 1201:1004 */       super(null);
/* 1202:     */     }
/* 1203:     */     
/* 1204:     */     public ConditionalExpression getMatch()
/* 1205:     */     {
/* 1206:1009 */       return this.matchedValue;
/* 1207:     */     }
/* 1208:     */     
/* 1209:     */     public void resetMatch()
/* 1210:     */     {
/* 1211:1014 */       this.matchedValue = null;
/* 1212:     */     }
/* 1213:     */     
/* 1214:     */     public boolean equals(Object o)
/* 1215:     */     {
/* 1216:1019 */       if (o == this) {
/* 1217:1019 */         return true;
/* 1218:     */       }
/* 1219:1020 */       if (o == null) {
/* 1220:1020 */         return false;
/* 1221:     */       }
/* 1222:1021 */       if (!(o instanceof ConditionalExpression)) {
/* 1223:1021 */         return false;
/* 1224:     */       }
/* 1225:1023 */       if (this.matchedValue != null) {
/* 1226:1024 */         return this.matchedValue.equals(o);
/* 1227:     */       }
/* 1228:1027 */       ConditionalExpression other = (ConditionalExpression)o;
/* 1229:     */       
/* 1230:1029 */       this.matchedValue = other;
/* 1231:1030 */       return true;
/* 1232:     */     }
/* 1233:     */     
/* 1234:     */     public ConditionalExpression simplify()
/* 1235:     */     {
/* 1236:1035 */       throw new UnsupportedOperationException();
/* 1237:     */     }
/* 1238:     */     
/* 1239:     */     public ConditionalExpression optimiseForType()
/* 1240:     */     {
/* 1241:1040 */       throw new UnsupportedOperationException();
/* 1242:     */     }
/* 1243:     */     
/* 1244:     */     public Set<LValue> getLoopLValues()
/* 1245:     */     {
/* 1246:1045 */       throw new UnsupportedOperationException();
/* 1247:     */     }
/* 1248:     */     
/* 1249:     */     public ConditionalExpression getDemorganApplied(boolean amNegating)
/* 1250:     */     {
/* 1251:1050 */       throw new UnsupportedOperationException();
/* 1252:     */     }
/* 1253:     */     
/* 1254:     */     public ConditionalExpression getRightDeep()
/* 1255:     */     {
/* 1256:1055 */       throw new UnsupportedOperationException();
/* 1257:     */     }
/* 1258:     */     
/* 1259:     */     public int getSize(Precedence outerPrecedence)
/* 1260:     */     {
/* 1261:1060 */       throw new UnsupportedOperationException();
/* 1262:     */     }
/* 1263:     */     
/* 1264:     */     public ConditionalExpression getNegated()
/* 1265:     */     {
/* 1266:1065 */       throw new UnsupportedOperationException();
/* 1267:     */     }
/* 1268:     */   }
/* 1269:     */   
/* 1270:     */   public class BlockWildcard
/* 1271:     */     extends Block
/* 1272:     */     implements Wildcard<Block>
/* 1273:     */   {
/* 1274:     */     private Block match;
/* 1275:     */     
/* 1276:     */     public BlockWildcard()
/* 1277:     */     {
/* 1278:1073 */       super(false);
/* 1279:     */     }
/* 1280:     */     
/* 1281:     */     public Block getMatch()
/* 1282:     */     {
/* 1283:1078 */       return this.match;
/* 1284:     */     }
/* 1285:     */     
/* 1286:     */     public void resetMatch()
/* 1287:     */     {
/* 1288:1083 */       this.match = null;
/* 1289:     */     }
/* 1290:     */     
/* 1291:     */     public boolean equals(Object o)
/* 1292:     */     {
/* 1293:1088 */       if (o == this) {
/* 1294:1088 */         return true;
/* 1295:     */       }
/* 1296:1089 */       if (o == null) {
/* 1297:1089 */         return false;
/* 1298:     */       }
/* 1299:1090 */       if (!(o instanceof Block)) {
/* 1300:1090 */         return false;
/* 1301:     */       }
/* 1302:1092 */       if (this.match != null) {
/* 1303:1094 */         return this.match == o;
/* 1304:     */       }
/* 1305:1097 */       Block other = (Block)o;
/* 1306:     */       
/* 1307:1099 */       this.match = other;
/* 1308:1100 */       return true;
/* 1309:     */     }
/* 1310:     */   }
/* 1311:     */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.wildcard.WildcardMatch
 * JD-Core Version:    0.7.0.1
 */