/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  16:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  17:    */ import org.benf.cfr.reader.util.StringUtils;
/*  18:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  19:    */ 
/*  20:    */ public class LambdaExpression
/*  21:    */   extends AbstractExpression
/*  22:    */   implements LambdaExpressionCommon
/*  23:    */ {
/*  24:    */   private List<LValue> args;
/*  25:    */   private Expression result;
/*  26:    */   
/*  27:    */   public LambdaExpression(InferredJavaType castJavaType, List<LValue> args, Expression result)
/*  28:    */   {
/*  29: 27 */     super(castJavaType);
/*  30: 28 */     this.args = args;
/*  31: 29 */     this.result = result;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  35:    */   {
/*  36: 34 */     return new LambdaExpression(getInferredJavaType(), cloneHelper.replaceOrClone(this.args), cloneHelper.replaceOrClone(this.result));
/*  37:    */   }
/*  38:    */   
/*  39:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  40:    */   {
/*  41: 39 */     collector.collectFrom(this.args);
/*  42: 40 */     this.result.collectTypeUsages(collector);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  46:    */   {
/*  47: 45 */     throw new UnsupportedOperationException();
/*  48:    */   }
/*  49:    */   
/*  50:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  51:    */   {
/*  52: 50 */     for (int x = 0; x < this.args.size(); x++) {
/*  53: 51 */       this.args.set(x, expressionRewriter.rewriteExpression((LValue)this.args.get(x), ssaIdentifiers, statementContainer, flags));
/*  54:    */     }
/*  55: 53 */     this.result = expressionRewriter.rewriteExpression(this.result, ssaIdentifiers, statementContainer, flags);
/*  56: 54 */     return this;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  60:    */   {
/*  61: 59 */     this.result = expressionRewriter.rewriteExpression(this.result, ssaIdentifiers, statementContainer, flags);
/*  62: 60 */     for (int x = this.args.size() - 1; x >= 0; x--) {
/*  63: 61 */       this.args.set(x, expressionRewriter.rewriteExpression((LValue)this.args.get(x), ssaIdentifiers, statementContainer, flags));
/*  64:    */     }
/*  65: 63 */     return this;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public Precedence getPrecedence()
/*  69:    */   {
/*  70: 68 */     return Precedence.PAREN_SUB_MEMBER;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public Dumper dumpInner(Dumper d)
/*  74:    */   {
/*  75: 73 */     boolean multi = this.args.size() != 1;
/*  76: 74 */     boolean first = true;
/*  77: 75 */     if (multi) {
/*  78: 75 */       d.print("(");
/*  79:    */     }
/*  80: 76 */     for (LValue lValue : this.args)
/*  81:    */     {
/*  82: 77 */       first = StringUtils.comma(first, d);
/*  83: 78 */       d.dump(lValue);
/*  84:    */     }
/*  85: 80 */     if (multi) {
/*  86: 80 */       d.print(")");
/*  87:    */     }
/*  88: 81 */     return d.print(" -> ").dump(this.result);
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector) {}
/*  92:    */   
/*  93:    */   public List<LValue> getArgs()
/*  94:    */   {
/*  95: 89 */     return this.args;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public boolean equals(Object o)
/*  99:    */   {
/* 100: 94 */     if (this == o) {
/* 101: 94 */       return true;
/* 102:    */     }
/* 103: 95 */     if ((o == null) || (getClass() != o.getClass())) {
/* 104: 95 */       return false;
/* 105:    */     }
/* 106: 97 */     LambdaExpression that = (LambdaExpression)o;
/* 107: 99 */     if (this.args != null ? !this.args.equals(that.args) : that.args != null) {
/* 108: 99 */       return false;
/* 109:    */     }
/* 110:100 */     if (this.result != null ? !this.result.equals(that.result) : that.result != null) {
/* 111:100 */       return false;
/* 112:    */     }
/* 113:102 */     return true;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 117:    */   {
/* 118:107 */     if (o == null) {
/* 119:107 */       return false;
/* 120:    */     }
/* 121:108 */     if (o == this) {
/* 122:108 */       return true;
/* 123:    */     }
/* 124:109 */     if (getClass() != o.getClass()) {
/* 125:109 */       return false;
/* 126:    */     }
/* 127:110 */     LambdaExpression other = (LambdaExpression)o;
/* 128:111 */     if (!constraint.equivalent(this.args, other.args)) {
/* 129:111 */       return false;
/* 130:    */     }
/* 131:112 */     if (!constraint.equivalent(this.result, other.result)) {
/* 132:112 */       return false;
/* 133:    */     }
/* 134:113 */     return true;
/* 135:    */   }
/* 136:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.LambdaExpression
 * JD-Core Version:    0.7.0.1
 */