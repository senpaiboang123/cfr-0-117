/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  17:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/*  18:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass;
/*  19:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  20:    */ import org.benf.cfr.reader.util.Troolean;
/*  21:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  22:    */ 
/*  23:    */ public class InstanceOfExpression
/*  24:    */   extends AbstractExpression
/*  25:    */ {
/*  26:    */   private Expression lhs;
/*  27:    */   private JavaTypeInstance typeInstance;
/*  28:    */   
/*  29:    */   public InstanceOfExpression(Expression lhs, ConstantPoolEntry cpe)
/*  30:    */   {
/*  31: 25 */     super(new InferredJavaType(RawJavaType.BOOLEAN, InferredJavaType.Source.EXPRESSION));
/*  32: 26 */     this.lhs = lhs;
/*  33: 27 */     ConstantPoolEntryClass cpec = (ConstantPoolEntryClass)cpe;
/*  34: 28 */     this.typeInstance = cpec.getTypeInstance();
/*  35:    */   }
/*  36:    */   
/*  37:    */   private InstanceOfExpression(InferredJavaType inferredJavaType, Expression lhs, JavaTypeInstance typeInstance)
/*  38:    */   {
/*  39: 32 */     super(inferredJavaType);
/*  40: 33 */     this.lhs = lhs;
/*  41: 34 */     this.typeInstance = typeInstance;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  45:    */   {
/*  46: 39 */     this.lhs.collectTypeUsages(collector);
/*  47: 40 */     collector.collect(this.typeInstance);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  51:    */   {
/*  52: 45 */     return new InstanceOfExpression(getInferredJavaType(), cloneHelper.replaceOrClone(this.lhs), this.typeInstance);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public Precedence getPrecedence()
/*  56:    */   {
/*  57: 50 */     return Precedence.REL_CMP_INSTANCEOF;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public Dumper dumpInner(Dumper d)
/*  61:    */   {
/*  62: 55 */     this.lhs.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.NEITHER);
/*  63: 56 */     return d.print(" instanceof ").dump(this.typeInstance);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  67:    */   {
/*  68: 61 */     this.lhs = this.lhs.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/*  69: 62 */     return this;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  73:    */   {
/*  74: 67 */     this.lhs = expressionRewriter.rewriteExpression(this.lhs, ssaIdentifiers, statementContainer, flags);
/*  75: 68 */     return this;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  79:    */   {
/*  80: 73 */     return applyExpressionRewriter(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/*  84:    */   {
/*  85: 79 */     this.lhs.collectUsedLValues(lValueUsageCollector);
/*  86:    */   }
/*  87:    */   
/*  88:    */   public boolean equals(Object o)
/*  89:    */   {
/*  90: 84 */     if (o == null) {
/*  91: 84 */       return false;
/*  92:    */     }
/*  93: 85 */     if (o == this) {
/*  94: 85 */       return true;
/*  95:    */     }
/*  96: 86 */     if (!(o instanceof InstanceOfExpression)) {
/*  97: 86 */       return false;
/*  98:    */     }
/*  99: 87 */     InstanceOfExpression other = (InstanceOfExpression)o;
/* 100: 88 */     if (!this.lhs.equals(other.lhs)) {
/* 101: 88 */       return false;
/* 102:    */     }
/* 103: 89 */     if (!this.typeInstance.equals(other.typeInstance)) {
/* 104: 89 */       return false;
/* 105:    */     }
/* 106: 90 */     return true;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 110:    */   {
/* 111: 95 */     if (o == null) {
/* 112: 95 */       return false;
/* 113:    */     }
/* 114: 96 */     if (o == this) {
/* 115: 96 */       return true;
/* 116:    */     }
/* 117: 97 */     if (getClass() != o.getClass()) {
/* 118: 97 */       return false;
/* 119:    */     }
/* 120: 98 */     InstanceOfExpression other = (InstanceOfExpression)o;
/* 121: 99 */     if (!constraint.equivalent(this.lhs, other.lhs)) {
/* 122: 99 */       return false;
/* 123:    */     }
/* 124:100 */     if (!constraint.equivalent(this.typeInstance, other.typeInstance)) {
/* 125:100 */       return false;
/* 126:    */     }
/* 127:101 */     return true;
/* 128:    */   }
/* 129:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.InstanceOfExpression
 * JD-Core Version:    0.7.0.1
 */