/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredCase;
/* 14:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 15:   */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/* 16:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 17:   */ 
/* 18:   */ public class CaseStatement
/* 19:   */   extends AbstractStatement
/* 20:   */ {
/* 21:   */   private List<Expression> values;
/* 22:   */   private final BlockIdentifier switchBlock;
/* 23:   */   private final BlockIdentifier caseBlock;
/* 24:   */   private final InferredJavaType caseType;
/* 25:   */   
/* 26:   */   public CaseStatement(List<Expression> values, InferredJavaType caseType, BlockIdentifier switchBlock, BlockIdentifier caseBlock)
/* 27:   */   {
/* 28:22 */     this.values = values;
/* 29:23 */     this.caseType = caseType;
/* 30:24 */     this.switchBlock = switchBlock;
/* 31:25 */     this.caseBlock = caseBlock;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public Dumper dump(Dumper dumper)
/* 35:   */   {
/* 36:30 */     if (this.values.isEmpty()) {
/* 37:31 */       dumper.print("default:\n");
/* 38:   */     } else {
/* 39:33 */       for (Expression value : this.values) {
/* 40:34 */         dumper.print("case ").dump(value).print(":\n");
/* 41:   */       }
/* 42:   */     }
/* 43:37 */     return dumper;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers)
/* 47:   */   {
/* 48:42 */     for (int x = 0; x < this.values.size(); x++) {
/* 49:43 */       this.values.set(x, ((Expression)this.values.get(x)).replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer()));
/* 50:   */     }
/* 51:   */   }
/* 52:   */   
/* 53:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/* 54:   */   {
/* 55:49 */     for (int x = 0; x < this.values.size(); x++) {
/* 56:50 */       this.values.set(x, expressionRewriter.rewriteExpression((Expression)this.values.get(x), ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE));
/* 57:   */     }
/* 58:   */   }
/* 59:   */   
/* 60:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector) {}
/* 61:   */   
/* 62:   */   public BlockIdentifier getSwitchBlock()
/* 63:   */   {
/* 64:60 */     return this.switchBlock;
/* 65:   */   }
/* 66:   */   
/* 67:   */   public boolean isDefault()
/* 68:   */   {
/* 69:64 */     return this.values.isEmpty();
/* 70:   */   }
/* 71:   */   
/* 72:   */   public StructuredStatement getStructuredStatement()
/* 73:   */   {
/* 74:69 */     return new UnstructuredCase(this.values, this.caseType, this.caseBlock);
/* 75:   */   }
/* 76:   */   
/* 77:   */   public BlockIdentifier getCaseBlock()
/* 78:   */   {
/* 79:73 */     return this.caseBlock;
/* 80:   */   }
/* 81:   */   
/* 82:   */   public boolean canThrow(ExceptionCheck caught)
/* 83:   */   {
/* 84:78 */     return false;
/* 85:   */   }
/* 86:   */   
/* 87:   */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 88:   */   {
/* 89:83 */     if (o == null) {
/* 90:83 */       return false;
/* 91:   */     }
/* 92:84 */     if (o == this) {
/* 93:84 */       return true;
/* 94:   */     }
/* 95:85 */     if (getClass() != o.getClass()) {
/* 96:85 */       return false;
/* 97:   */     }
/* 98:86 */     CaseStatement other = (CaseStatement)o;
/* 99:87 */     if (!constraint.equivalent(this.values, other.values)) {
/* :0:87 */       return false;
/* :1:   */     }
/* :2:88 */     return true;
/* :3:   */   }
/* :4:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.CaseStatement
 * JD-Core Version:    0.7.0.1
 */