/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredFinally;
/* 12:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 13:   */ 
/* 14:   */ public class FinallyStatement
/* 15:   */   extends AbstractStatement
/* 16:   */ {
/* 17:   */   private BlockIdentifier finallyBlockIdent;
/* 18:   */   
/* 19:   */   public FinallyStatement(BlockIdentifier finallyBlockIdent)
/* 20:   */   {
/* 21:20 */     this.finallyBlockIdent = finallyBlockIdent;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public Dumper dump(Dumper dumper)
/* 25:   */   {
/* 26:25 */     return dumper.print("finally {\n");
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers) {}
/* 30:   */   
/* 31:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers) {}
/* 32:   */   
/* 33:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector) {}
/* 34:   */   
/* 35:   */   public LValue getCreatedLValue()
/* 36:   */   {
/* 37:42 */     return null;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public StructuredStatement getStructuredStatement()
/* 41:   */   {
/* 42:47 */     return new UnstructuredFinally(this.finallyBlockIdent);
/* 43:   */   }
/* 44:   */   
/* 45:   */   public BlockIdentifier getFinallyBlockIdent()
/* 46:   */   {
/* 47:51 */     return this.finallyBlockIdent;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 51:   */   {
/* 52:56 */     if (o == null) {
/* 53:56 */       return false;
/* 54:   */     }
/* 55:57 */     if (o == this) {
/* 56:57 */       return true;
/* 57:   */     }
/* 58:58 */     if (getClass() != o.getClass()) {
/* 59:58 */       return false;
/* 60:   */     }
/* 61:59 */     FinallyStatement other = (FinallyStatement)o;
/* 62:   */     
/* 63:61 */     return true;
/* 64:   */   }
/* 65:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.FinallyStatement
 * JD-Core Version:    0.7.0.1
 */