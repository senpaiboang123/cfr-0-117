/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  11:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  12:    */ import org.benf.cfr.reader.entities.Method;
/*  13:    */ import org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumperAnonymousInner;
/*  14:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  15:    */ import org.benf.cfr.reader.state.DCCommonState;
/*  16:    */ import org.benf.cfr.reader.util.CannotLoadClassException;
/*  17:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  18:    */ 
/*  19:    */ public class ConstructorInvokationAnonymousInner
/*  20:    */   extends AbstractConstructorInvokation
/*  21:    */ {
/*  22:    */   private final MemberFunctionInvokation constructorInvokation;
/*  23:    */   private final ClassFile classFile;
/*  24:    */   private final JavaTypeInstance anonymousTypeInstance;
/*  25:    */   
/*  26:    */   public ConstructorInvokationAnonymousInner(MemberFunctionInvokation constructorInvokation, InferredJavaType inferredJavaType, List<Expression> args, DCCommonState dcCommonState, JavaTypeInstance anonymousTypeInstance)
/*  27:    */   {
/*  28: 27 */     super(inferredJavaType, constructorInvokation.getFunction(), args);
/*  29: 28 */     this.constructorInvokation = constructorInvokation;
/*  30: 29 */     this.anonymousTypeInstance = anonymousTypeInstance;
/*  31:    */     
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35: 34 */     ClassFile classFile = null;
/*  36:    */     try
/*  37:    */     {
/*  38: 36 */       classFile = dcCommonState.getClassFile(constructorInvokation.getMethodPrototype().getReturnType());
/*  39:    */     }
/*  40:    */     catch (CannotLoadClassException e) {}
/*  41: 39 */     this.classFile = classFile;
/*  42:    */   }
/*  43:    */   
/*  44:    */   protected ConstructorInvokationAnonymousInner(ConstructorInvokationAnonymousInner other, CloneHelper cloneHelper)
/*  45:    */   {
/*  46: 43 */     super(other, cloneHelper);
/*  47: 44 */     this.constructorInvokation = ((MemberFunctionInvokation)cloneHelper.replaceOrClone(other.constructorInvokation));
/*  48: 45 */     this.classFile = other.classFile;
/*  49: 46 */     this.anonymousTypeInstance = other.anonymousTypeInstance;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public ClassFile getClassFile()
/*  53:    */   {
/*  54: 50 */     return this.classFile;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  58:    */   {
/*  59: 56 */     return new ConstructorInvokationAnonymousInner(this, cloneHelper);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public Precedence getPrecedence()
/*  63:    */   {
/*  64: 61 */     return Precedence.PAREN_SUB_MEMBER;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public Dumper dumpInner(Dumper d)
/*  68:    */   {
/*  69: 68 */     ConstantPool cp = this.constructorInvokation.getCp();
/*  70:    */     
/*  71: 70 */     ClassFile anonymousClassFile = null;
/*  72: 71 */     JavaTypeInstance typeInstance = this.anonymousTypeInstance;
/*  73:    */     try
/*  74:    */     {
/*  75: 73 */       anonymousClassFile = cp.getDCCommonState().getClassFile(typeInstance);
/*  76:    */     }
/*  77:    */     catch (CannotLoadClassException e)
/*  78:    */     {
/*  79: 75 */       anonymousClassFile = this.classFile;
/*  80:    */     }
/*  81: 77 */     if (anonymousClassFile != this.classFile) {
/*  82: 78 */       throw new IllegalStateException("Inner class got unexpected class file - revert this change");
/*  83:    */     }
/*  84: 81 */     d.print("new ");
/*  85: 82 */     ClassFileDumperAnonymousInner cfd = new ClassFileDumperAnonymousInner();
/*  86: 83 */     List<Expression> args = getArgs();
/*  87: 84 */     MethodPrototype prototype = this.constructorInvokation.getMethodPrototype();
/*  88:    */     try
/*  89:    */     {
/*  90: 86 */       if (this.classFile != null) {
/*  91: 86 */         prototype = this.classFile.getMethodByPrototype(prototype).getMethodPrototype();
/*  92:    */       }
/*  93:    */     }
/*  94:    */     catch (NoSuchMethodException e) {}
/*  95: 90 */     cfd.dumpWithArgs(this.classFile, prototype, args, false, d);
/*  96: 91 */     d.removePendingCarriageReturn();
/*  97: 92 */     return d;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public Dumper dumpForEnum(Dumper d)
/* 101:    */   {
/* 102: 97 */     ClassFile anonymousClassFile = this.classFile;
/* 103: 98 */     ClassFileDumperAnonymousInner cfd = new ClassFileDumperAnonymousInner();
/* 104: 99 */     List<Expression> args = getArgs();
/* 105:    */     
/* 106:    */ 
/* 107:102 */     return cfd.dumpWithArgs(anonymousClassFile, null, args.subList(2, args.size()), true, d);
/* 108:    */   }
/* 109:    */   
/* 110:    */   public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 111:    */   {
/* 112:107 */     if (!(o instanceof ConstructorInvokationAnonymousInner)) {
/* 113:107 */       return false;
/* 114:    */     }
/* 115:108 */     if (!super.equivalentUnder(o, constraint)) {
/* 116:108 */       return false;
/* 117:    */     }
/* 118:109 */     ConstructorInvokationAnonymousInner other = (ConstructorInvokationAnonymousInner)o;
/* 119:110 */     if (!constraint.equivalent(this.constructorInvokation, other.constructorInvokation)) {
/* 120:110 */       return false;
/* 121:    */     }
/* 122:111 */     return true;
/* 123:    */   }
/* 124:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationAnonymousInner
 * JD-Core Version:    0.7.0.1
 */