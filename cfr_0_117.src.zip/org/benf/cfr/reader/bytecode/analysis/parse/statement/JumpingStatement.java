package org.benf.cfr.reader.bytecode.analysis.parse.statement;

import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.JumpType;

public abstract class JumpingStatement
  extends AbstractStatement
{
  public abstract Statement getJumpTarget();
  
  public abstract JumpType getJumpType();
  
  public abstract void setJumpType(JumpType paramJumpType);
  
  public abstract boolean isConditional();
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.JumpingStatement
 * JD-Core Version:    0.7.0.1
 */