/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import java.util.Map;
/*   4:    */ import java.util.Set;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.ConditionalUtils;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  21:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  22:    */ import org.benf.cfr.reader.util.SetFactory;
/*  23:    */ import org.benf.cfr.reader.util.Troolean;
/*  24:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  25:    */ 
/*  26:    */ public class BooleanOperation
/*  27:    */   extends AbstractExpression
/*  28:    */   implements ConditionalExpression
/*  29:    */ {
/*  30:    */   private ConditionalExpression lhs;
/*  31:    */   private ConditionalExpression rhs;
/*  32:    */   private BoolOp op;
/*  33:    */   
/*  34:    */   public BooleanOperation(ConditionalExpression lhs, ConditionalExpression rhs, BoolOp op)
/*  35:    */   {
/*  36: 27 */     super(new InferredJavaType(RawJavaType.BOOLEAN, InferredJavaType.Source.EXPRESSION));
/*  37: 28 */     this.lhs = lhs;
/*  38: 29 */     this.rhs = rhs;
/*  39: 30 */     this.op = op;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  43:    */   {
/*  44: 35 */     return new BooleanOperation((ConditionalExpression)cloneHelper.replaceOrClone(this.lhs), (ConditionalExpression)cloneHelper.replaceOrClone(this.rhs), this.op);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public ConditionalExpression getLhs()
/*  48:    */   {
/*  49: 43 */     return this.lhs;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public ConditionalExpression getRhs()
/*  53:    */   {
/*  54: 47 */     return this.rhs;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public BoolOp getOp()
/*  58:    */   {
/*  59: 51 */     return this.op;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  63:    */   {
/*  64: 56 */     this.lhs.collectTypeUsages(collector);
/*  65: 57 */     this.rhs.collectTypeUsages(collector);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public int getSize(Precedence outerPrecedence)
/*  69:    */   {
/*  70: 62 */     Precedence precedence = getPrecedence();
/*  71: 63 */     int initial = outerPrecedence.compareTo(precedence) < 0 ? 2 : 0;
/*  72: 64 */     return initial + this.lhs.getSize(precedence) + 2 + this.rhs.getSize(precedence);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  76:    */   {
/*  77: 69 */     this.rhs = ((ConditionalExpression)this.rhs.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer));
/*  78: 70 */     this.lhs = ((ConditionalExpression)this.lhs.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer));
/*  79: 71 */     return this;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  83:    */   {
/*  84: 76 */     this.lhs = expressionRewriter.rewriteExpression(this.lhs, ssaIdentifiers, statementContainer, flags);
/*  85: 77 */     this.rhs = expressionRewriter.rewriteExpression(this.rhs, ssaIdentifiers, statementContainer, flags);
/*  86: 78 */     return this;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  90:    */   {
/*  91: 83 */     this.rhs = expressionRewriter.rewriteExpression(this.rhs, ssaIdentifiers, statementContainer, flags);
/*  92: 84 */     this.lhs = expressionRewriter.rewriteExpression(this.lhs, ssaIdentifiers, statementContainer, flags);
/*  93: 85 */     return this;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public Expression applyLHSOnlyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  97:    */   {
/*  98: 89 */     this.lhs = expressionRewriter.rewriteExpression(this.lhs, ssaIdentifiers, statementContainer, flags);
/*  99: 90 */     return this;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public Precedence getPrecedence()
/* 103:    */   {
/* 104: 95 */     return this.op.getPrecedence();
/* 105:    */   }
/* 106:    */   
/* 107:    */   public Dumper dumpInner(Dumper d)
/* 108:    */   {
/* 109:100 */     this.lhs.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.TRUE);
/* 110:101 */     d.print(" ").print(this.op.getShowAs()).print(" ");
/* 111:102 */     this.rhs.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.FALSE);
/* 112:103 */     return d;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public ConditionalExpression getNegated()
/* 116:    */   {
/* 117:108 */     return new NotOperation(this);
/* 118:    */   }
/* 119:    */   
/* 120:    */   public ConditionalExpression getDemorganApplied(boolean amNegating)
/* 121:    */   {
/* 122:113 */     return new BooleanOperation(this.lhs.getDemorganApplied(amNegating), this.rhs.getDemorganApplied(amNegating), amNegating ? this.op.getDemorgan() : this.op);
/* 123:    */   }
/* 124:    */   
/* 125:    */   public ConditionalExpression getRightDeep()
/* 126:    */   {
/* 127:120 */     while ((this.lhs instanceof BooleanOperation))
/* 128:    */     {
/* 129:121 */       BooleanOperation lbool = (BooleanOperation)this.lhs;
/* 130:122 */       if (lbool.op != this.op) {
/* 131:    */         break;
/* 132:    */       }
/* 133:123 */       ConditionalExpression a = lbool.lhs;
/* 134:124 */       ConditionalExpression b = lbool.rhs;
/* 135:125 */       ConditionalExpression c = this.rhs;
/* 136:126 */       this.lhs = a;
/* 137:127 */       lbool.lhs = b;
/* 138:128 */       lbool.rhs = c;
/* 139:129 */       this.rhs = lbool;
/* 140:    */     }
/* 141:134 */     this.lhs = this.lhs.getRightDeep();
/* 142:135 */     this.rhs = this.rhs.getRightDeep();
/* 143:136 */     return this;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public Set<LValue> getLoopLValues()
/* 147:    */   {
/* 148:141 */     Set<LValue> res = SetFactory.newSet();
/* 149:142 */     res.addAll(this.lhs.getLoopLValues());
/* 150:143 */     res.addAll(this.rhs.getLoopLValues());
/* 151:144 */     return res;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/* 155:    */   {
/* 156:149 */     this.lhs.collectUsedLValues(lValueUsageCollector);
/* 157:150 */     this.rhs.collectUsedLValues(lValueUsageCollector);
/* 158:    */   }
/* 159:    */   
/* 160:    */   public ConditionalExpression optimiseForType()
/* 161:    */   {
/* 162:155 */     this.lhs = this.lhs.optimiseForType();
/* 163:156 */     this.rhs = this.rhs.optimiseForType();
/* 164:157 */     return this;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public ConditionalExpression simplify()
/* 168:    */   {
/* 169:162 */     return ConditionalUtils.simplify(this);
/* 170:    */   }
/* 171:    */   
/* 172:    */   public boolean equals(Object o)
/* 173:    */   {
/* 174:167 */     if (this == o) {
/* 175:167 */       return true;
/* 176:    */     }
/* 177:168 */     if (!(o instanceof BooleanOperation)) {
/* 178:168 */       return false;
/* 179:    */     }
/* 180:170 */     BooleanOperation that = (BooleanOperation)o;
/* 181:172 */     if (!this.lhs.equals(that.lhs)) {
/* 182:172 */       return false;
/* 183:    */     }
/* 184:173 */     if (this.op != that.op) {
/* 185:173 */       return false;
/* 186:    */     }
/* 187:174 */     if (!this.rhs.equals(that.rhs)) {
/* 188:174 */       return false;
/* 189:    */     }
/* 190:176 */     return true;
/* 191:    */   }
/* 192:    */   
/* 193:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 194:    */   {
/* 195:181 */     if (o == null) {
/* 196:181 */       return false;
/* 197:    */     }
/* 198:182 */     if (o == this) {
/* 199:182 */       return true;
/* 200:    */     }
/* 201:183 */     if (getClass() != o.getClass()) {
/* 202:183 */       return false;
/* 203:    */     }
/* 204:184 */     BooleanOperation other = (BooleanOperation)o;
/* 205:185 */     if ((this.op != other.op) && 
/* 206:186 */       (!constraint.equivalent(this.lhs, other.lhs))) {
/* 207:186 */       return false;
/* 208:    */     }
/* 209:187 */     if (!constraint.equivalent(this.rhs, other.rhs)) {
/* 210:187 */       return false;
/* 211:    */     }
/* 212:188 */     return true;
/* 213:    */   }
/* 214:    */   
/* 215:    */   private static Boolean getComputed(Expression e, Map<LValue, Literal> display)
/* 216:    */   {
/* 217:192 */     Literal lv = e.getComputedLiteral(display);
/* 218:193 */     if (lv == null) {
/* 219:193 */       return null;
/* 220:    */     }
/* 221:194 */     return lv.getValue().getMaybeBoolValue();
/* 222:    */   }
/* 223:    */   
/* 224:    */   public Literal getComputedLiteral(Map<LValue, Literal> display)
/* 225:    */   {
/* 226:202 */     Boolean lb = getComputed(this.lhs, display);
/* 227:203 */     if (lb == null) {
/* 228:203 */       return null;
/* 229:    */     }
/* 230:204 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$expression$BoolOp[this.op.ordinal()])
/* 231:    */     {
/* 232:    */     case 1: 
/* 233:206 */       Boolean rb = getComputed(this.rhs, display);
/* 234:207 */       if (rb == null) {
/* 235:207 */         return null;
/* 236:    */       }
/* 237:208 */       return (lb.booleanValue()) && (rb.booleanValue()) ? Literal.TRUE : Literal.FALSE;
/* 238:    */     case 2: 
/* 239:211 */       if (lb.booleanValue()) {
/* 240:211 */         return Literal.TRUE;
/* 241:    */       }
/* 242:212 */       Boolean rb = getComputed(this.rhs, display);
/* 243:213 */       if (rb == null) {
/* 244:213 */         return null;
/* 245:    */       }
/* 246:214 */       return rb.booleanValue() ? Literal.TRUE : Literal.FALSE;
/* 247:    */     }
/* 248:217 */     return null;
/* 249:    */   }
/* 250:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.BooleanOperation
 * JD-Core Version:    0.7.0.1
 */