/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.lvalue;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentCollector;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifierFactory;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.stack.StackEntry;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  16:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/*  17:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  18:    */ 
/*  19:    */ public class StackSSALabel
/*  20:    */   extends AbstractLValue
/*  21:    */ {
/*  22:    */   private final long id;
/*  23:    */   private final StackEntry stackEntry;
/*  24:    */   
/*  25:    */   public StackSSALabel(long id, StackEntry stackEntry)
/*  26:    */   {
/*  27: 21 */     super(stackEntry.getInferredJavaType());
/*  28: 22 */     this.id = id;
/*  29: 23 */     this.stackEntry = stackEntry;
/*  30:    */   }
/*  31:    */   
/*  32:    */   protected StackSSALabel(InferredJavaType inferredJavaType)
/*  33:    */   {
/*  34: 30 */     super(inferredJavaType);
/*  35: 31 */     this.id = 0L;
/*  36: 32 */     this.stackEntry = null;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public void markFinal() {}
/*  40:    */   
/*  41:    */   public boolean isFinal()
/*  42:    */   {
/*  43: 42 */     return false;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public Precedence getPrecedence()
/*  47:    */   {
/*  48: 47 */     return Precedence.HIGHEST;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public Dumper dumpInner(Dumper d)
/*  52:    */   {
/*  53: 52 */     return d.print("v" + this.id + typeToString());
/*  54:    */   }
/*  55:    */   
/*  56:    */   public int getNumberOfCreators()
/*  57:    */   {
/*  58: 57 */     return this.stackEntry.getSourceCount();
/*  59:    */   }
/*  60:    */   
/*  61:    */   public LValue deepClone(CloneHelper cloneHelper)
/*  62:    */   {
/*  63: 62 */     return this;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public boolean canThrow(ExceptionCheck caught)
/*  67:    */   {
/*  68: 67 */     return false;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public <Statement> void collectLValueAssignments(Expression rhsAssigned, StatementContainer<Statement> statementContainer, LValueAssignmentCollector<Statement> lValueAssigmentCollector)
/*  72:    */   {
/*  73: 76 */     if (getNumberOfCreators() == 1) {
/*  74: 77 */       if ((rhsAssigned.isSimple()) || (this.stackEntry.getUsageCount() == 1L)) {
/*  75: 78 */         lValueAssigmentCollector.collect(this, statementContainer, rhsAssigned);
/*  76: 79 */       } else if (this.stackEntry.getUsageCount() > 1L) {
/*  77: 80 */         lValueAssigmentCollector.collectMultiUse(this, statementContainer, rhsAssigned);
/*  78:    */       }
/*  79:    */     }
/*  80:    */   }
/*  81:    */   
/*  82:    */   public SSAIdentifiers<LValue> collectVariableMutation(SSAIdentifierFactory<LValue> ssaIdentifierFactory)
/*  83:    */   {
/*  84: 87 */     return new SSAIdentifiers();
/*  85:    */   }
/*  86:    */   
/*  87:    */   public LValue replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  88:    */   {
/*  89: 92 */     return this;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public LValue applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  93:    */   {
/*  94: 97 */     return this;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public StackEntry getStackEntry()
/*  98:    */   {
/*  99:101 */     return this.stackEntry;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public int hashCode()
/* 103:    */   {
/* 104:106 */     return (int)this.id;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public boolean equals(Object o)
/* 108:    */   {
/* 109:111 */     if (o == null) {
/* 110:111 */       return false;
/* 111:    */     }
/* 112:112 */     if (o == this) {
/* 113:112 */       return true;
/* 114:    */     }
/* 115:113 */     if (!(o instanceof StackSSALabel)) {
/* 116:113 */       return false;
/* 117:    */     }
/* 118:114 */     return this.id == ((StackSSALabel)o).id;
/* 119:    */   }
/* 120:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel
 * JD-Core Version:    0.7.0.1
 */