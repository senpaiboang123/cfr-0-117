/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  16:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/*  17:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass;
/*  18:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/*  19:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  20:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  21:    */ 
/*  22:    */ public class NewObject
/*  23:    */   extends AbstractExpression
/*  24:    */ {
/*  25:    */   private final ConstantPoolEntryClass type;
/*  26:    */   
/*  27:    */   public NewObject(ConstantPoolEntry type)
/*  28:    */   {
/*  29: 27 */     super(new InferredJavaType(((ConstantPoolEntryClass)type).getTypeInstance(), InferredJavaType.Source.EXPRESSION));
/*  30: 28 */     this.type = ((ConstantPoolEntryClass)type);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  34:    */   {
/*  35: 33 */     collector.collect(getTypeInstance());
/*  36:    */   }
/*  37:    */   
/*  38:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  39:    */   {
/*  40: 38 */     return this;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public Precedence getPrecedence()
/*  44:    */   {
/*  45: 43 */     return Precedence.PAREN_SUB_MEMBER;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public Dumper dumpInner(Dumper d)
/*  49:    */   {
/*  50: 48 */     return d.print("new " + getTypeInstance());
/*  51:    */   }
/*  52:    */   
/*  53:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  54:    */   {
/*  55: 53 */     return this;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  59:    */   {
/*  60: 58 */     return this;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  64:    */   {
/*  65: 63 */     return this;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public ConstantPoolEntryClass getType()
/*  69:    */   {
/*  70: 67 */     return this.type;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public JavaTypeInstance getTypeInstance()
/*  74:    */   {
/*  75: 71 */     return getInferredJavaType().getJavaTypeInstance();
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector) {}
/*  79:    */   
/*  80:    */   public boolean equals(Object o)
/*  81:    */   {
/*  82: 80 */     if (o == null) {
/*  83: 80 */       return false;
/*  84:    */     }
/*  85: 81 */     if (o == this) {
/*  86: 81 */       return true;
/*  87:    */     }
/*  88: 82 */     if (!(o instanceof NewObject)) {
/*  89: 82 */       return false;
/*  90:    */     }
/*  91: 83 */     NewObject other = (NewObject)o;
/*  92: 84 */     if (!getTypeInstance().equals(other.getTypeInstance())) {
/*  93: 84 */       return false;
/*  94:    */     }
/*  95: 85 */     return true;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public boolean canThrow(ExceptionCheck caught)
/*  99:    */   {
/* 100: 90 */     return false;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 104:    */   {
/* 105: 95 */     if (o == null) {
/* 106: 95 */       return false;
/* 107:    */     }
/* 108: 96 */     if (o == this) {
/* 109: 96 */       return true;
/* 110:    */     }
/* 111: 97 */     if (o.getClass() != getClass()) {
/* 112: 97 */       return false;
/* 113:    */     }
/* 114: 98 */     NewObject other = (NewObject)o;
/* 115: 99 */     if (!constraint.equivalent(getTypeInstance(), other.getTypeInstance())) {
/* 116: 99 */       return false;
/* 117:    */     }
/* 118:100 */     return true;
/* 119:    */   }
/* 120:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.NewObject
 * JD-Core Version:    0.7.0.1
 */