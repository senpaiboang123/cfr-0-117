package org.benf.cfr.reader.bytecode.analysis.parse;

import java.util.List;
import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.ComparableUnderEC;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.CreationCollector;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentCollector;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifierFactory;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
import org.benf.cfr.reader.util.output.Dumpable;

public abstract interface Statement
  extends Dumpable, ComparableUnderEC
{
  public abstract void setContainer(StatementContainer<Statement> paramStatementContainer);
  
  public abstract void collectLValueAssignments(LValueAssignmentCollector<Statement> paramLValueAssignmentCollector);
  
  public abstract void collectLValueUsage(LValueUsageCollector paramLValueUsageCollector);
  
  public abstract boolean doesBlackListLValueReplacement(LValue paramLValue, Expression paramExpression);
  
  public abstract void replaceSingleUsageLValues(LValueRewriter paramLValueRewriter, SSAIdentifiers paramSSAIdentifiers);
  
  public abstract void rewriteExpressions(ExpressionRewriter paramExpressionRewriter, SSAIdentifiers paramSSAIdentifiers);
  
  public abstract void collectObjectCreation(CreationCollector paramCreationCollector);
  
  public abstract SSAIdentifiers<LValue> collectLocallyMutatedVariables(SSAIdentifierFactory<LValue> paramSSAIdentifierFactory);
  
  public abstract boolean isCompound();
  
  public abstract LValue getCreatedLValue();
  
  public abstract Expression getRValue();
  
  public abstract StatementContainer<Statement> getContainer();
  
  public abstract List<Statement> getCompoundParts();
  
  public abstract StructuredStatement getStructuredStatement();
  
  public abstract boolean equivalentUnder(Object paramObject, EquivalenceConstraint paramEquivalenceConstraint);
  
  public abstract boolean fallsToNext();
  
  public abstract boolean canThrow(ExceptionCheck paramExceptionCheck);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.Statement
 * JD-Core Version:    0.7.0.1
 */