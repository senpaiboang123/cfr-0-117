/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.DeepCloneable;
/*  5:   */ 
/*  6:   */ public abstract class ReturnStatement
/*  7:   */   extends AbstractStatement
/*  8:   */   implements DeepCloneable<ReturnStatement>
/*  9:   */ {
/* 10:   */   public boolean fallsToNext()
/* 11:   */   {
/* 12: 9 */     return false;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public ReturnStatement outerDeepClone(CloneHelper cloneHelper)
/* 16:   */   {
/* 17:14 */     throw new UnsupportedOperationException();
/* 18:   */   }
/* 19:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.ReturnStatement
 * JD-Core Version:    0.7.0.1
 */