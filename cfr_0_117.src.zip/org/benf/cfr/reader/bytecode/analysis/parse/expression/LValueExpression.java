/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import java.util.Map;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  15:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/*  16:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  17:    */ import org.benf.cfr.reader.util.Troolean;
/*  18:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  19:    */ 
/*  20:    */ public class LValueExpression
/*  21:    */   extends AbstractExpression
/*  22:    */ {
/*  23:    */   private LValue lValue;
/*  24:    */   
/*  25:    */   public LValueExpression(LValue lValue)
/*  26:    */   {
/*  27: 25 */     super(lValue.getInferredJavaType());
/*  28: 26 */     this.lValue = lValue;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  32:    */   {
/*  33: 31 */     return new LValueExpression(cloneHelper.replaceOrClone(this.lValue));
/*  34:    */   }
/*  35:    */   
/*  36:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  37:    */   {
/*  38: 36 */     this.lValue.collectTypeUsages(collector);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public boolean isSimple()
/*  42:    */   {
/*  43: 53 */     return false;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  47:    */   {
/*  48: 58 */     if (lValueRewriter.explicitlyReplaceThisLValue(this.lValue))
/*  49:    */     {
/*  50: 59 */       Expression replacement = lValueRewriter.getLValueReplacement(this.lValue, ssaIdentifiers, statementContainer);
/*  51: 60 */       if (replacement != null) {
/*  52: 60 */         return replacement;
/*  53:    */       }
/*  54:    */     }
/*  55: 63 */     this.lValue = this.lValue.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/*  56: 64 */     return this;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  60:    */   {
/*  61: 70 */     this.lValue = expressionRewriter.rewriteExpression(this.lValue, ssaIdentifiers, statementContainer, flags);
/*  62: 71 */     return this;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  66:    */   {
/*  67: 76 */     return applyExpressionRewriter(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public Precedence getPrecedence()
/*  71:    */   {
/*  72: 81 */     return Precedence.PAREN_SUB_MEMBER;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public Dumper dumpInner(Dumper d)
/*  76:    */   {
/*  77: 86 */     return this.lValue.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.NEITHER);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public LValue getLValue()
/*  81:    */   {
/*  82: 90 */     return this.lValue;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/*  86:    */   {
/*  87: 95 */     lValueUsageCollector.collect(this.lValue);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public boolean equals(Object o)
/*  91:    */   {
/*  92:100 */     if (o == this) {
/*  93:100 */       return true;
/*  94:    */     }
/*  95:101 */     if (!(o instanceof LValueExpression)) {
/*  96:101 */       return false;
/*  97:    */     }
/*  98:102 */     return this.lValue.equals(((LValueExpression)o).getLValue());
/*  99:    */   }
/* 100:    */   
/* 101:    */   public int hashCode()
/* 102:    */   {
/* 103:107 */     return this.lValue.hashCode();
/* 104:    */   }
/* 105:    */   
/* 106:    */   public boolean canThrow(ExceptionCheck caught)
/* 107:    */   {
/* 108:112 */     return false;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 112:    */   {
/* 113:117 */     if (o == null) {
/* 114:117 */       return false;
/* 115:    */     }
/* 116:118 */     if (o == this) {
/* 117:118 */       return true;
/* 118:    */     }
/* 119:119 */     if (getClass() != o.getClass()) {
/* 120:119 */       return false;
/* 121:    */     }
/* 122:120 */     LValueExpression other = (LValueExpression)o;
/* 123:121 */     if (!constraint.equivalent(this.lValue, other.lValue)) {
/* 124:121 */       return false;
/* 125:    */     }
/* 126:122 */     return true;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public Literal getComputedLiteral(Map<LValue, Literal> display)
/* 130:    */   {
/* 131:127 */     return (Literal)display.get(this.lValue);
/* 132:    */   }
/* 133:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression
 * JD-Core Version:    0.7.0.1
 */