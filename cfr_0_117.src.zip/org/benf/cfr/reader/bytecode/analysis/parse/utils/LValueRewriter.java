package org.benf.cfr.reader.bytecode.analysis.parse.utils;

import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;

public abstract interface LValueRewriter<T>
{
  public abstract Expression getLValueReplacement(LValue paramLValue, SSAIdentifiers paramSSAIdentifiers, StatementContainer<T> paramStatementContainer);
  
  public abstract boolean explicitlyReplaceThisLValue(LValue paramLValue);
  
  public abstract void checkPostConditions(LValue paramLValue, Expression paramExpression);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter
 * JD-Core Version:    0.7.0.1
 */