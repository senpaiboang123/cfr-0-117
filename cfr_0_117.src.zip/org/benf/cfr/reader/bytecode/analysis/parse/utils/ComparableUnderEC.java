package org.benf.cfr.reader.bytecode.analysis.parse.utils;

public abstract interface ComparableUnderEC
{
  public abstract boolean equivalentUnder(Object paramObject, EquivalenceConstraint paramEquivalenceConstraint);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.ComparableUnderEC
 * JD-Core Version:    0.7.0.1
 */