/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import java.util.Map;
/*   4:    */ import java.util.Set;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.ConditionalUtils;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  20:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  21:    */ import org.benf.cfr.reader.util.SetFactory;
/*  22:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  23:    */ 
/*  24:    */ public class BooleanExpression
/*  25:    */   extends AbstractExpression
/*  26:    */   implements ConditionalExpression
/*  27:    */ {
/*  28:    */   private Expression inner;
/*  29:    */   
/*  30:    */   public BooleanExpression(Expression inner)
/*  31:    */   {
/*  32: 24 */     super(new InferredJavaType(RawJavaType.BOOLEAN, InferredJavaType.Source.EXPRESSION));
/*  33: 25 */     this.inner = inner;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public int getSize(Precedence outer)
/*  37:    */   {
/*  38: 30 */     return 1;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  42:    */   {
/*  43: 35 */     this.inner.collectTypeUsages(collector);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  47:    */   {
/*  48: 40 */     return new BooleanExpression(cloneHelper.replaceOrClone(this.inner));
/*  49:    */   }
/*  50:    */   
/*  51:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  52:    */   {
/*  53: 45 */     this.inner = this.inner.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/*  54: 46 */     return this;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  58:    */   {
/*  59: 51 */     this.inner = expressionRewriter.rewriteExpression(this.inner, ssaIdentifiers, statementContainer, flags);
/*  60: 52 */     return this;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  64:    */   {
/*  65: 57 */     return applyExpressionRewriter(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public Precedence getPrecedence()
/*  69:    */   {
/*  70: 62 */     return this.inner.getPrecedence();
/*  71:    */   }
/*  72:    */   
/*  73:    */   public Dumper dumpInner(Dumper d)
/*  74:    */   {
/*  75: 70 */     return this.inner.dump(d);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public ConditionalExpression getNegated()
/*  79:    */   {
/*  80: 75 */     return new NotOperation(this);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public ConditionalExpression getDemorganApplied(boolean amNegating)
/*  84:    */   {
/*  85: 80 */     if (!amNegating) {
/*  86: 80 */       return this;
/*  87:    */     }
/*  88: 81 */     return getNegated();
/*  89:    */   }
/*  90:    */   
/*  91:    */   public ConditionalExpression getRightDeep()
/*  92:    */   {
/*  93: 86 */     return this;
/*  94:    */   }
/*  95:    */   
/*  96:    */   protected void addIfLValue(Expression expression, Set<LValue> res)
/*  97:    */   {
/*  98: 90 */     if ((expression instanceof LValueExpression)) {
/*  99: 91 */       res.add(((LValueExpression)expression).getLValue());
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:    */   public Set<LValue> getLoopLValues()
/* 104:    */   {
/* 105: 97 */     Set<LValue> res = SetFactory.newSet();
/* 106: 98 */     addIfLValue(this.inner, res);
/* 107: 99 */     return res;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/* 111:    */   {
/* 112:104 */     this.inner.collectUsedLValues(lValueUsageCollector);
/* 113:    */   }
/* 114:    */   
/* 115:    */   public ConditionalExpression optimiseForType()
/* 116:    */   {
/* 117:109 */     return this;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public ConditionalExpression simplify()
/* 121:    */   {
/* 122:114 */     return ConditionalUtils.simplify(this);
/* 123:    */   }
/* 124:    */   
/* 125:    */   public boolean equals(Object o)
/* 126:    */   {
/* 127:119 */     if (o == this) {
/* 128:119 */       return true;
/* 129:    */     }
/* 130:120 */     if (!(o instanceof BooleanExpression)) {
/* 131:120 */       return false;
/* 132:    */     }
/* 133:121 */     BooleanExpression other = (BooleanExpression)o;
/* 134:122 */     return this.inner.equals(other.inner);
/* 135:    */   }
/* 136:    */   
/* 137:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 138:    */   {
/* 139:127 */     if (o == null) {
/* 140:127 */       return false;
/* 141:    */     }
/* 142:128 */     if (o == this) {
/* 143:128 */       return true;
/* 144:    */     }
/* 145:129 */     if (getClass() != o.getClass()) {
/* 146:129 */       return false;
/* 147:    */     }
/* 148:130 */     BooleanExpression other = (BooleanExpression)o;
/* 149:131 */     if (!constraint.equivalent(this.inner, other.inner)) {
/* 150:131 */       return false;
/* 151:    */     }
/* 152:132 */     return true;
/* 153:    */   }
/* 154:    */   
/* 155:    */   public Literal getComputedLiteral(Map<LValue, Literal> display)
/* 156:    */   {
/* 157:137 */     return this.inner.getComputedLiteral(display);
/* 158:    */   }
/* 159:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.BooleanExpression
 * JD-Core Version:    0.7.0.1
 */