package org.benf.cfr.reader.bytecode.analysis.parse.rewriters;

import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;

public abstract interface ExpressionRewriter
{
  public abstract Expression rewriteExpression(Expression paramExpression, SSAIdentifiers paramSSAIdentifiers, StatementContainer paramStatementContainer, ExpressionRewriterFlags paramExpressionRewriterFlags);
  
  public abstract ConditionalExpression rewriteExpression(ConditionalExpression paramConditionalExpression, SSAIdentifiers paramSSAIdentifiers, StatementContainer paramStatementContainer, ExpressionRewriterFlags paramExpressionRewriterFlags);
  
  public abstract LValue rewriteExpression(LValue paramLValue, SSAIdentifiers paramSSAIdentifiers, StatementContainer paramStatementContainer, ExpressionRewriterFlags paramExpressionRewriterFlags);
  
  public abstract StackSSALabel rewriteExpression(StackSSALabel paramStackSSALabel, SSAIdentifiers paramSSAIdentifiers, StatementContainer paramStatementContainer, ExpressionRewriterFlags paramExpressionRewriterFlags);
  
  public abstract void handleStatement(StatementContainer paramStatementContainer);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter
 * JD-Core Version:    0.7.0.1
 */