/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockType;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.JumpType;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredComment;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredAnonymousBreak;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredBreak;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredContinue;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredGoto;
/*  19:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/*  20:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  21:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  22:    */ 
/*  23:    */ public class GotoStatement
/*  24:    */   extends JumpingStatement
/*  25:    */ {
/*  26:    */   private JumpType jumpType;
/*  27:    */   
/*  28:    */   public GotoStatement()
/*  29:    */   {
/*  30: 17 */     this.jumpType = JumpType.GOTO;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public Dumper dump(Dumper dumper)
/*  34:    */   {
/*  35:    */     try
/*  36:    */     {
/*  37: 23 */       return dumper.print("" + this.jumpType + " " + getJumpTarget().getContainer().getLabel() + ";\n");
/*  38:    */     }
/*  39:    */     catch (Exception e) {}
/*  40: 25 */     return dumper.print("!!! " + this.jumpType + " bad target");
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers) {}
/*  44:    */   
/*  45:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers) {}
/*  46:    */   
/*  47:    */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector) {}
/*  48:    */   
/*  49:    */   public JumpType getJumpType()
/*  50:    */   {
/*  51: 43 */     return this.jumpType;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void setJumpType(JumpType jumpType)
/*  55:    */   {
/*  56: 48 */     this.jumpType = jumpType;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public Statement getJumpTarget()
/*  60:    */   {
/*  61: 53 */     return getTargetStatement(0);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public boolean isConditional()
/*  65:    */   {
/*  66: 58 */     return false;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public boolean canThrow(ExceptionCheck caught)
/*  70:    */   {
/*  71: 63 */     return false;
/*  72:    */   }
/*  73:    */   
/*  74:    */   protected BlockIdentifier getTargetStartBlock()
/*  75:    */   {
/*  76: 67 */     Statement statement = getJumpTarget();
/*  77: 68 */     if ((statement instanceof WhileStatement))
/*  78:    */     {
/*  79: 69 */       WhileStatement whileStatement = (WhileStatement)statement;
/*  80: 70 */       return whileStatement.getBlockIdentifier();
/*  81:    */     }
/*  82: 71 */     if ((statement instanceof ForStatement))
/*  83:    */     {
/*  84: 72 */       ForStatement forStatement = (ForStatement)statement;
/*  85: 73 */       return forStatement.getBlockIdentifier();
/*  86:    */     }
/*  87: 74 */     if ((statement instanceof ForIterStatement))
/*  88:    */     {
/*  89: 75 */       ForIterStatement forStatement = (ForIterStatement)statement;
/*  90: 76 */       return forStatement.getBlockIdentifier();
/*  91:    */     }
/*  92: 78 */     BlockIdentifier blockStarted = statement.getContainer().getBlockStarted();
/*  93: 79 */     if (blockStarted != null) {
/*  94: 80 */       switch (blockStarted.getBlockType())
/*  95:    */       {
/*  96:    */       case UNCONDITIONALDOLOOP: 
/*  97: 82 */         return blockStarted;
/*  98:    */       case DOLOOP: 
/*  99: 84 */         return blockStarted;
/* 100:    */       }
/* 101:    */     }
/* 102: 87 */     throw new ConfusedCFRException("CONTINUE without a while " + statement.getClass());
/* 103:    */   }
/* 104:    */   
/* 105:    */   public StructuredStatement getStructuredStatement()
/* 106:    */   {
/* 107: 93 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$utils$JumpType[this.jumpType.ordinal()])
/* 108:    */     {
/* 109:    */     case 1: 
/* 110:    */     case 2: 
/* 111: 96 */       return new StructuredComment("");
/* 112:    */     case 3: 
/* 113:    */     case 4: 
/* 114: 99 */       return new UnstructuredGoto();
/* 115:    */     case 5: 
/* 116:101 */       return new UnstructuredContinue(getTargetStartBlock());
/* 117:    */     case 6: 
/* 118:103 */       return new UnstructuredBreak(getJumpTarget().getContainer().getBlocksEnded());
/* 119:    */     case 7: 
/* 120:105 */       Statement target = getJumpTarget();
/* 121:106 */       if (!(target instanceof AnonBreakTarget)) {
/* 122:107 */         throw new IllegalStateException("Target of anonymous break unexpected.");
/* 123:    */       }
/* 124:109 */       AnonBreakTarget anonBreakTarget = (AnonBreakTarget)target;
/* 125:110 */       BlockIdentifier breakFrom = anonBreakTarget.getBlockIdentifier();
/* 126:111 */       return new UnstructuredAnonymousBreak(breakFrom);
/* 127:    */     }
/* 128:114 */     throw new UnsupportedOperationException();
/* 129:    */   }
/* 130:    */   
/* 131:    */   public boolean equals(Object o)
/* 132:    */   {
/* 133:119 */     if (this == o) {
/* 134:119 */       return true;
/* 135:    */     }
/* 136:120 */     if ((o == null) || (getClass() != o.getClass())) {
/* 137:120 */       return false;
/* 138:    */     }
/* 139:122 */     GotoStatement that = (GotoStatement)o;
/* 140:124 */     if (this.jumpType != that.jumpType) {
/* 141:124 */       return false;
/* 142:    */     }
/* 143:126 */     return true;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 147:    */   {
/* 148:131 */     if (this == o) {
/* 149:131 */       return true;
/* 150:    */     }
/* 151:132 */     if ((o == null) || (getClass() != o.getClass())) {
/* 152:132 */       return false;
/* 153:    */     }
/* 154:134 */     GotoStatement that = (GotoStatement)o;
/* 155:135 */     return constraint.equivalent(this.jumpType, that.jumpType);
/* 156:    */   }
/* 157:    */   
/* 158:    */   public boolean fallsToNext()
/* 159:    */   {
/* 160:140 */     return false;
/* 161:    */   }
/* 162:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement
 * JD-Core Version:    0.7.0.1
 */