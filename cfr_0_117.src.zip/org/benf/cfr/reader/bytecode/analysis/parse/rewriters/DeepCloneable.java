package org.benf.cfr.reader.bytecode.analysis.parse.rewriters;

public abstract interface DeepCloneable<X>
{
  public abstract X deepClone(CloneHelper paramCloneHelper);
  
  public abstract X outerDeepClone(CloneHelper paramCloneHelper);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.rewriters.DeepCloneable
 * JD-Core Version:    0.7.0.1
 */