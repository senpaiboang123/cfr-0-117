/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.expression.misc;
/*  2:   */ 
/*  3:   */ public enum Precedence
/*  4:   */ {
/*  5: 4 */   HIGHEST(true),  PAREN_SUB_MEMBER(true),  LAMBDA(true),  UNARY_POST(false),  UNARY_OTHER(false),  MUL_DIV_MOD(true),  ADD_SUB(true),  BITWISE_SHIFT(true),  REL_CMP_INSTANCEOF(true),  REL_EQ(true),  BIT_AND(true),  BIT_XOR(true),  BIT_OR(true),  LOG_AND(true, true),  LOG_OR(true, true),  CONDITIONAL(false),  ASSIGNMENT(false),  WEAKEST(true);
/*  6:   */   
/*  7:   */   private final boolean isLtoR;
/*  8:   */   private final boolean commute;
/*  9:   */   
/* 10:   */   private Precedence(boolean ltoR)
/* 11:   */   {
/* 12:27 */     this.isLtoR = ltoR;
/* 13:28 */     this.commute = false;
/* 14:   */   }
/* 15:   */   
/* 16:   */   private Precedence(boolean ltoR, boolean commute)
/* 17:   */   {
/* 18:32 */     this.isLtoR = ltoR;
/* 19:33 */     this.commute = commute;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public boolean isLtoR()
/* 23:   */   {
/* 24:37 */     return this.isLtoR;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public boolean isCommutative()
/* 28:   */   {
/* 29:41 */     return this.commute;
/* 30:   */   }
/* 31:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence
 * JD-Core Version:    0.7.0.1
 */