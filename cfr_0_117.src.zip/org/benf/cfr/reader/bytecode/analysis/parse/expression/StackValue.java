/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import java.util.Map;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  16:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  17:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  18:    */ 
/*  19:    */ public class StackValue
/*  20:    */   extends AbstractExpression
/*  21:    */ {
/*  22:    */   private StackSSALabel stackValue;
/*  23:    */   
/*  24:    */   public StackValue(StackSSALabel stackValue)
/*  25:    */   {
/*  26: 21 */     super(stackValue.getInferredJavaType());
/*  27: 22 */     this.stackValue = stackValue;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public Precedence getPrecedence()
/*  31:    */   {
/*  32: 27 */     return Precedence.WEAKEST;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public Dumper dumpInner(Dumper d)
/*  36:    */   {
/*  37: 32 */     return this.stackValue.dump(d);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public boolean isSimple()
/*  41:    */   {
/*  42: 37 */     return true;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  46:    */   {
/*  47: 42 */     this.stackValue.collectTypeUsages(collector);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  51:    */   {
/*  52: 50 */     return this;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  56:    */   {
/*  57: 55 */     Expression replaceMeWith = lValueRewriter.getLValueReplacement(this.stackValue, ssaIdentifiers, statementContainer);
/*  58: 56 */     if (replaceMeWith != null) {
/*  59: 57 */       return replaceMeWith;
/*  60:    */     }
/*  61: 59 */     return this;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  65:    */   {
/*  66: 64 */     this.stackValue = expressionRewriter.rewriteExpression(this.stackValue, ssaIdentifiers, statementContainer, flags);
/*  67: 65 */     return this;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  71:    */   {
/*  72: 70 */     return applyExpressionRewriter(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public StackSSALabel getStackValue()
/*  76:    */   {
/*  77: 74 */     return this.stackValue;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/*  81:    */   {
/*  82: 79 */     lValueUsageCollector.collect(this.stackValue);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public boolean equals(Object o)
/*  86:    */   {
/*  87: 84 */     if (o == this) {
/*  88: 84 */       return true;
/*  89:    */     }
/*  90: 85 */     if (!(o instanceof StackValue)) {
/*  91: 85 */       return false;
/*  92:    */     }
/*  93: 86 */     StackValue other = (StackValue)o;
/*  94: 87 */     return this.stackValue.equals(other.stackValue);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public int hashCode()
/*  98:    */   {
/*  99: 92 */     return this.stackValue.hashCode();
/* 100:    */   }
/* 101:    */   
/* 102:    */   public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 103:    */   {
/* 104: 97 */     if (o == this) {
/* 105: 97 */       return true;
/* 106:    */     }
/* 107: 98 */     if (!(o instanceof StackValue)) {
/* 108: 98 */       return false;
/* 109:    */     }
/* 110: 99 */     StackValue other = (StackValue)o;
/* 111:100 */     return constraint.equivalent(this.stackValue, other.stackValue);
/* 112:    */   }
/* 113:    */   
/* 114:    */   public Literal getComputedLiteral(Map<LValue, Literal> display)
/* 115:    */   {
/* 116:105 */     return (Literal)display.get(this.stackValue);
/* 117:    */   }
/* 118:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.StackValue
 * JD-Core Version:    0.7.0.1
 */