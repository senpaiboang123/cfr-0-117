/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*  4:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  5:   */ 
/*  6:   */ public enum BoolOp
/*  7:   */ {
/*  8: 7 */   OR("||", Precedence.LOG_OR),  AND("&&", Precedence.LOG_AND);
/*  9:   */   
/* 10:   */   private final String showAs;
/* 11:   */   private final Precedence precedence;
/* 12:   */   
/* 13:   */   private BoolOp(String showAs, Precedence precedence)
/* 14:   */   {
/* 15:14 */     this.showAs = showAs;
/* 16:15 */     this.precedence = precedence;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public String getShowAs()
/* 20:   */   {
/* 21:19 */     return this.showAs;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public Precedence getPrecedence()
/* 25:   */   {
/* 26:23 */     return this.precedence;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public BoolOp getDemorgan()
/* 30:   */   {
/* 31:27 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$expression$BoolOp[ordinal()])
/* 32:   */     {
/* 33:   */     case 1: 
/* 34:29 */       return AND;
/* 35:   */     case 2: 
/* 36:31 */       return OR;
/* 37:   */     }
/* 38:33 */     throw new ConfusedCFRException("Unknown op.");
/* 39:   */   }
/* 40:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.BoolOp
 * JD-Core Version:    0.7.0.1
 */