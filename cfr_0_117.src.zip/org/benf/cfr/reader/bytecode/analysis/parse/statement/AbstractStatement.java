/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.CreationCollector;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentCollector;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifierFactory;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 12:   */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/* 13:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/* 14:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 15:   */ import org.benf.cfr.reader.util.output.ToStringDumper;
/* 16:   */ 
/* 17:   */ public abstract class AbstractStatement
/* 18:   */   implements Statement
/* 19:   */ {
/* 20:   */   private StatementContainer<Statement> container;
/* 21:   */   
/* 22:   */   public void setContainer(StatementContainer<Statement> container)
/* 23:   */   {
/* 24:20 */     if (container == null) {
/* 25:20 */       throw new ConfusedCFRException("Trying to setContainer null!");
/* 26:   */     }
/* 27:21 */     this.container = container;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public LValue getCreatedLValue()
/* 31:   */   {
/* 32:26 */     return null;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void collectLValueAssignments(LValueAssignmentCollector<Statement> lValueAssigmentCollector) {}
/* 36:   */   
/* 37:   */   public boolean doesBlackListLValueReplacement(LValue lValue, Expression expression)
/* 38:   */   {
/* 39:35 */     return false;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void collectObjectCreation(CreationCollector creationCollector) {}
/* 43:   */   
/* 44:   */   public SSAIdentifiers<LValue> collectLocallyMutatedVariables(SSAIdentifierFactory<LValue> ssaIdentifierFactory)
/* 45:   */   {
/* 46:44 */     return new SSAIdentifiers();
/* 47:   */   }
/* 48:   */   
/* 49:   */   public StatementContainer<Statement> getContainer()
/* 50:   */   {
/* 51:52 */     return this.container;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public Expression getRValue()
/* 55:   */   {
/* 56:57 */     return null;
/* 57:   */   }
/* 58:   */   
/* 59:   */   protected Statement getTargetStatement(int idx)
/* 60:   */   {
/* 61:61 */     return (Statement)this.container.getTargetStatement(idx);
/* 62:   */   }
/* 63:   */   
/* 64:   */   public boolean isCompound()
/* 65:   */   {
/* 66:66 */     return false;
/* 67:   */   }
/* 68:   */   
/* 69:   */   public List<Statement> getCompoundParts()
/* 70:   */   {
/* 71:71 */     throw new ConfusedCFRException("Should not be calling getCompoundParts on this statement");
/* 72:   */   }
/* 73:   */   
/* 74:   */   public final String toString()
/* 75:   */   {
/* 76:76 */     Dumper d = new ToStringDumper();
/* 77:77 */     d.print(getClass().getSimpleName()).print(": ").dump(this);
/* 78:78 */     return d.toString();
/* 79:   */   }
/* 80:   */   
/* 81:   */   public boolean fallsToNext()
/* 82:   */   {
/* 83:83 */     return true;
/* 84:   */   }
/* 85:   */   
/* 86:   */   public boolean canThrow(ExceptionCheck caught)
/* 87:   */   {
/* 88:88 */     return true;
/* 89:   */   }
/* 90:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.AbstractStatement
 * JD-Core Version:    0.7.0.1
 */