/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import java.util.Map;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  17:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  18:    */ import org.benf.cfr.reader.util.Troolean;
/*  19:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  20:    */ 
/*  21:    */ public class AssignmentExpression
/*  22:    */   extends AbstractAssignmentExpression
/*  23:    */ {
/*  24:    */   private LValue lValue;
/*  25:    */   private Expression rValue;
/*  26:    */   
/*  27:    */   public AssignmentExpression(LValue lValue, Expression rValue)
/*  28:    */   {
/*  29: 24 */     super(lValue.getInferredJavaType());
/*  30: 25 */     this.lValue = lValue;
/*  31: 26 */     this.rValue = rValue;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  35:    */   {
/*  36: 31 */     return new AssignmentExpression(cloneHelper.replaceOrClone(this.lValue), cloneHelper.replaceOrClone(this.rValue));
/*  37:    */   }
/*  38:    */   
/*  39:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  40:    */   {
/*  41: 36 */     this.lValue.collectTypeUsages(collector);
/*  42: 37 */     collector.collectFrom(this.rValue);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public Precedence getPrecedence()
/*  46:    */   {
/*  47: 42 */     return Precedence.ASSIGNMENT;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public Dumper dumpInner(Dumper d)
/*  51:    */   {
/*  52: 47 */     d.dump(this.lValue).print(" = ");
/*  53: 48 */     this.rValue.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.NEITHER);
/*  54: 49 */     return d;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  58:    */   {
/*  59: 54 */     this.rValue = this.rValue.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/*  60: 55 */     this.lValue = this.lValue.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/*  61: 56 */     return this;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  65:    */   {
/*  66: 61 */     this.rValue = expressionRewriter.rewriteExpression(this.rValue, ssaIdentifiers, statementContainer, flags);
/*  67: 62 */     return this;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  71:    */   {
/*  72: 67 */     return applyExpressionRewriter(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public Expression applyRValueOnlyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  76:    */   {
/*  77: 72 */     this.rValue = expressionRewriter.rewriteExpression(this.rValue, ssaIdentifiers, statementContainer, flags);
/*  78: 73 */     return this;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public boolean isSelfMutatingOp1(LValue lValue, ArithOp arithOp)
/*  82:    */   {
/*  83: 78 */     return false;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public ArithmeticPostMutationOperation getPostMutation()
/*  87:    */   {
/*  88: 83 */     throw new IllegalStateException();
/*  89:    */   }
/*  90:    */   
/*  91:    */   public LValue getUpdatedLValue()
/*  92:    */   {
/*  93: 88 */     return this.lValue;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/*  97:    */   {
/*  98: 93 */     lValueUsageCollector.collect(this.lValue);
/*  99: 94 */     this.rValue.collectUsedLValues(lValueUsageCollector);
/* 100:    */   }
/* 101:    */   
/* 102:    */   public LValue getlValue()
/* 103:    */   {
/* 104: 98 */     return this.lValue;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public Expression getrValue()
/* 108:    */   {
/* 109:102 */     return this.rValue;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public boolean equals(Object o)
/* 113:    */   {
/* 114:107 */     if (this == o) {
/* 115:107 */       return true;
/* 116:    */     }
/* 117:108 */     if ((o == null) || (getClass() != o.getClass())) {
/* 118:108 */       return false;
/* 119:    */     }
/* 120:110 */     AssignmentExpression that = (AssignmentExpression)o;
/* 121:112 */     if (this.lValue != null ? !this.lValue.equals(that.lValue) : that.lValue != null) {
/* 122:112 */       return false;
/* 123:    */     }
/* 124:113 */     if (this.rValue != null ? !this.rValue.equals(that.rValue) : that.rValue != null) {
/* 125:113 */       return false;
/* 126:    */     }
/* 127:115 */     return true;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 131:    */   {
/* 132:120 */     if (o == null) {
/* 133:120 */       return false;
/* 134:    */     }
/* 135:121 */     if (o == this) {
/* 136:121 */       return true;
/* 137:    */     }
/* 138:122 */     if (getClass() != o.getClass()) {
/* 139:122 */       return false;
/* 140:    */     }
/* 141:123 */     AssignmentExpression other = (AssignmentExpression)o;
/* 142:124 */     if (!constraint.equivalent(this.lValue, other.lValue)) {
/* 143:124 */       return false;
/* 144:    */     }
/* 145:125 */     if (!constraint.equivalent(this.rValue, other.rValue)) {
/* 146:125 */       return false;
/* 147:    */     }
/* 148:126 */     return true;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public Literal getComputedLiteral(Map<LValue, Literal> display)
/* 152:    */   {
/* 153:131 */     if ((!(this.lValue instanceof StackSSALabel)) && (!(this.lValue instanceof LocalVariable))) {
/* 154:131 */       return null;
/* 155:    */     }
/* 156:132 */     Literal literal = this.rValue.getComputedLiteral(display);
/* 157:133 */     if (literal == null) {
/* 158:133 */       return null;
/* 159:    */     }
/* 160:134 */     display.put(this.lValue, literal);
/* 161:135 */     return literal;
/* 162:    */   }
/* 163:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.AssignmentExpression
 * JD-Core Version:    0.7.0.1
 */