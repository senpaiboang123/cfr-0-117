package org.benf.cfr.reader.bytecode.analysis.parse.statement;

public abstract class MonitorStatement
  extends AbstractStatement
{}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.MonitorStatement
 * JD-Core Version:    0.7.0.1
 */