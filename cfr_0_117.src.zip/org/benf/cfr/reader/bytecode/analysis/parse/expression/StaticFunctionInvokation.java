/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.PrimitiveBoxingRewriter;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.VarArgsRewriter;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface.BoxingProcessor;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface.FunctionProcessor;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterHelper;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.GenericTypeBinder;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  24:    */ import org.benf.cfr.reader.entities.classfilehelpers.OverloadMethodSet;
/*  25:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass;
/*  26:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodRef;
/*  27:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  28:    */ import org.benf.cfr.reader.util.StringUtils;
/*  29:    */ import org.benf.cfr.reader.util.annotation.Nullable;
/*  30:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  31:    */ 
/*  32:    */ public class StaticFunctionInvokation
/*  33:    */   extends AbstractFunctionInvokation
/*  34:    */   implements FunctionProcessor, BoxingProcessor
/*  35:    */ {
/*  36:    */   private final List<Expression> args;
/*  37:    */   private final JavaTypeInstance clazz;
/*  38:    */   @Nullable
/*  39:    */   private List<JavaTypeInstance> explicitGenerics;
/*  40:    */   
/*  41:    */   private static InferredJavaType getTypeForFunction(ConstantPoolEntryMethodRef function, List<Expression> args)
/*  42:    */   {
/*  43: 35 */     InferredJavaType res = new InferredJavaType(function.getMethodPrototype().getReturnType(function.getClassEntry().getTypeInstance(), args), InferredJavaType.Source.FUNCTION, true);
/*  44:    */     
/*  45:    */ 
/*  46: 38 */     return res;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  50:    */   {
/*  51: 43 */     return new StaticFunctionInvokation(getFunction(), cloneHelper.replaceOrClone(this.args));
/*  52:    */   }
/*  53:    */   
/*  54:    */   public StaticFunctionInvokation(ConstantPoolEntryMethodRef function, List<Expression> args)
/*  55:    */   {
/*  56: 48 */     super(function, getTypeForFunction(function, args));
/*  57: 49 */     this.args = args;
/*  58: 50 */     this.clazz = function.getClassEntry().getTypeInstance();
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  62:    */   {
/*  63: 55 */     collector.collect(this.clazz);
/*  64: 56 */     for (Expression arg : this.args) {
/*  65: 57 */       arg.collectTypeUsages(collector);
/*  66:    */     }
/*  67:    */   }
/*  68:    */   
/*  69:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  70:    */   {
/*  71: 63 */     for (int x = this.args.size() - 1; x >= 0; x--) {
/*  72: 64 */       this.args.set(x, ((Expression)this.args.get(x)).replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer));
/*  73:    */     }
/*  74: 66 */     return this;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  78:    */   {
/*  79: 71 */     applyExpressionRewriterToArgs(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  80: 72 */     return this;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  84:    */   {
/*  85: 77 */     ExpressionRewriterHelper.applyBackwards(this.args, expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  86: 78 */     return this;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void applyExpressionRewriterToArgs(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  90:    */   {
/*  91: 83 */     ExpressionRewriterHelper.applyForwards(this.args, expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void setExplicitGenerics(List<JavaTypeInstance> types)
/*  95:    */   {
/*  96: 88 */     this.explicitGenerics = types;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public List<JavaTypeInstance> getExplicitGenerics()
/* 100:    */   {
/* 101: 93 */     return this.explicitGenerics;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public Precedence getPrecedence()
/* 105:    */   {
/* 106: 98 */     return Precedence.PAREN_SUB_MEMBER;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public Dumper dumpInner(Dumper d)
/* 110:    */   {
/* 111:103 */     d.dump(this.clazz).print(".");
/* 112:104 */     if ((this.explicitGenerics != null) && (!this.explicitGenerics.isEmpty()))
/* 113:    */     {
/* 114:105 */       d.print("<");
/* 115:106 */       boolean first = true;
/* 116:107 */       for (JavaTypeInstance typeInstance : this.explicitGenerics)
/* 117:    */       {
/* 118:108 */         first = StringUtils.comma(first, d);
/* 119:109 */         d.dump(typeInstance);
/* 120:    */       }
/* 121:111 */       d.print(">");
/* 122:    */     }
/* 123:113 */     d.identifier(getFixedName()).print("(");
/* 124:114 */     boolean first = true;
/* 125:115 */     for (Expression arg : this.args)
/* 126:    */     {
/* 127:116 */       first = StringUtils.comma(first, d);
/* 128:117 */       d.dump(arg);
/* 129:    */     }
/* 130:119 */     d.print(")");
/* 131:120 */     return d;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/* 135:    */   {
/* 136:125 */     for (Expression expression : this.args) {
/* 137:126 */       expression.collectUsedLValues(lValueUsageCollector);
/* 138:    */     }
/* 139:    */   }
/* 140:    */   
/* 141:    */   public JavaTypeInstance getClazz()
/* 142:    */   {
/* 143:131 */     return this.clazz;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public List<Expression> getArgs()
/* 147:    */   {
/* 148:135 */     return this.args;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public void rewriteVarArgs(VarArgsRewriter varArgsRewriter)
/* 152:    */   {
/* 153:140 */     MethodPrototype methodPrototype = getMethodPrototype();
/* 154:141 */     if (!methodPrototype.isVarArgs()) {
/* 155:141 */       return;
/* 156:    */     }
/* 157:142 */     OverloadMethodSet overloadMethodSet = getFunction().getOverloadMethodSet();
/* 158:143 */     if (overloadMethodSet == null) {
/* 159:143 */       return;
/* 160:    */     }
/* 161:144 */     GenericTypeBinder gtb = methodPrototype.getTypeBinderFor(this.args);
/* 162:145 */     varArgsRewriter.rewriteVarArgsArg(overloadMethodSet, methodPrototype, getArgs(), gtb);
/* 163:    */   }
/* 164:    */   
/* 165:    */   public boolean rewriteBoxing(PrimitiveBoxingRewriter boxingRewriter)
/* 166:    */   {
/* 167:150 */     OverloadMethodSet overloadMethodSet = getFunction().getOverloadMethodSet();
/* 168:151 */     if (overloadMethodSet == null) {
/* 169:152 */       return false;
/* 170:    */     }
/* 171:154 */     for (int x = 0; x < this.args.size(); x++)
/* 172:    */     {
/* 173:162 */       Expression arg = (Expression)this.args.get(x);
/* 174:163 */       arg = boxingRewriter.rewriteExpression(arg, null, null, null);
/* 175:164 */       this.args.set(x, boxingRewriter.sugarParameterBoxing(arg, x, overloadMethodSet, null, getFunction().getMethodPrototype()));
/* 176:    */     }
/* 177:166 */     return true;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public void applyNonArgExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags) {}
/* 181:    */   
/* 182:    */   public boolean equals(Object o)
/* 183:    */   {
/* 184:176 */     if (o == null) {
/* 185:176 */       return false;
/* 186:    */     }
/* 187:177 */     if (o == this) {
/* 188:177 */       return true;
/* 189:    */     }
/* 190:178 */     if (!(o instanceof StaticFunctionInvokation)) {
/* 191:178 */       return false;
/* 192:    */     }
/* 193:179 */     StaticFunctionInvokation other = (StaticFunctionInvokation)o;
/* 194:180 */     if (!getName().equals(other.getName())) {
/* 195:180 */       return false;
/* 196:    */     }
/* 197:181 */     if (!this.clazz.equals(other.clazz)) {
/* 198:181 */       return false;
/* 199:    */     }
/* 200:182 */     if (!this.args.equals(other.args)) {
/* 201:182 */       return false;
/* 202:    */     }
/* 203:183 */     return true;
/* 204:    */   }
/* 205:    */   
/* 206:    */   public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 207:    */   {
/* 208:188 */     if (o == null) {
/* 209:188 */       return false;
/* 210:    */     }
/* 211:189 */     if (o == this) {
/* 212:189 */       return true;
/* 213:    */     }
/* 214:190 */     if (!(o instanceof StaticFunctionInvokation)) {
/* 215:190 */       return false;
/* 216:    */     }
/* 217:191 */     StaticFunctionInvokation other = (StaticFunctionInvokation)o;
/* 218:192 */     if (!constraint.equivalent(getName(), other.getName())) {
/* 219:192 */       return false;
/* 220:    */     }
/* 221:193 */     if (!constraint.equivalent(this.clazz, other.clazz)) {
/* 222:193 */       return false;
/* 223:    */     }
/* 224:194 */     if (!constraint.equivalent(this.args, other.args)) {
/* 225:194 */       return false;
/* 226:    */     }
/* 227:195 */     return true;
/* 228:    */   }
/* 229:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.StaticFunctionInvokation
 * JD-Core Version:    0.7.0.1
 */