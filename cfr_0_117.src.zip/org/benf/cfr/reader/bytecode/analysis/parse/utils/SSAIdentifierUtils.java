/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.utils;
/*  2:   */ 
/*  3:   */ import java.util.Collection;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  5:   */ 
/*  6:   */ public class SSAIdentifierUtils
/*  7:   */ {
/*  8:   */   public static boolean isMovableUnder(Collection<LValue> lValues, LValue lValueMove, SSAIdentifiers atTarget, SSAIdentifiers atSource)
/*  9:   */   {
/* 10: 9 */     for (LValue lValue : lValues) {
/* 11:10 */       if (!atTarget.isValidReplacement(lValue, atSource)) {
/* 12:10 */         return false;
/* 13:   */       }
/* 14:   */     }
/* 15:12 */     SSAIdent afterSrc = atSource.getSSAIdentOnExit(lValueMove);
/* 16:13 */     if (afterSrc == null) {
/* 17:13 */       return false;
/* 18:   */     }
/* 19:14 */     SSAIdent beforeTarget = atTarget.getSSAIdentOnEntry(lValueMove);
/* 20:15 */     if (beforeTarget == null) {
/* 21:15 */       return false;
/* 22:   */     }
/* 23:16 */     if (!beforeTarget.isSuperSet(afterSrc)) {
/* 24:16 */       return false;
/* 25:   */     }
/* 26:17 */     return true;
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifierUtils
 * JD-Core Version:    0.7.0.1
 */