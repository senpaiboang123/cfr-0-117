/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.utils;
/*  2:   */ 
/*  3:   */ public class QuotingUtils
/*  4:   */ {
/*  5:   */   public static String enquoteUTF(String s)
/*  6:   */   {
/*  7: 9 */     char[] raw = s.toCharArray();
/*  8:10 */     StringBuilder stringBuilder = new StringBuilder();
/*  9:11 */     for (char c : raw) {
/* 10:12 */       if ((c < ' ') || (c > '')) {
/* 11:13 */         stringBuilder.append("\\u").append(String.format("%04x", new Object[] { Integer.valueOf(c) }));
/* 12:   */       } else {
/* 13:15 */         stringBuilder.append(c);
/* 14:   */       }
/* 15:   */     }
/* 16:18 */     return stringBuilder.toString();
/* 17:   */   }
/* 18:   */   
/* 19:   */   public static String enquoteString(String s)
/* 20:   */   {
/* 21:22 */     char[] raw = s.toCharArray();
/* 22:23 */     StringBuilder stringBuilder = new StringBuilder();
/* 23:24 */     stringBuilder.append("\"");
/* 24:25 */     for (char c : raw) {
/* 25:26 */       switch (c)
/* 26:   */       {
/* 27:   */       case '\n': 
/* 28:28 */         stringBuilder.append("\\n");
/* 29:29 */         break;
/* 30:   */       case '\r': 
/* 31:31 */         stringBuilder.append("\\r");
/* 32:32 */         break;
/* 33:   */       case '\t': 
/* 34:34 */         stringBuilder.append("\\t");
/* 35:35 */         break;
/* 36:   */       case '\b': 
/* 37:37 */         stringBuilder.append("\\b");
/* 38:38 */         break;
/* 39:   */       case '\f': 
/* 40:40 */         stringBuilder.append("\\f");
/* 41:41 */         break;
/* 42:   */       case '\\': 
/* 43:43 */         stringBuilder.append("\\\\");
/* 44:44 */         break;
/* 45:   */       case '"': 
/* 46:46 */         stringBuilder.append("\\\"");
/* 47:47 */         break;
/* 48:   */       default: 
/* 49:49 */         stringBuilder.append(c);
/* 50:   */       }
/* 51:   */     }
/* 52:53 */     stringBuilder.append("\"");
/* 53:54 */     return stringBuilder.toString();
/* 54:   */   }
/* 55:   */   
/* 56:   */   public static String unquoteString(String s)
/* 57:   */   {
/* 58:58 */     if ((s.startsWith("\"")) && (s.endsWith("\""))) {
/* 59:58 */       s = s.substring(1, s.length() - 1);
/* 60:   */     }
/* 61:59 */     return s;
/* 62:   */   }
/* 63:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.QuotingUtils
 * JD-Core Version:    0.7.0.1
 */