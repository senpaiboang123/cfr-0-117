/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.PrimitiveBoxingRewriter;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface.BoxingProcessor;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterHelper;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  20:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  21:    */ import org.benf.cfr.reader.util.ListFactory;
/*  22:    */ import org.benf.cfr.reader.util.StringUtils;
/*  23:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  24:    */ 
/*  25:    */ public class NewAnonymousArray
/*  26:    */   extends AbstractNewArray
/*  27:    */   implements BoxingProcessor
/*  28:    */ {
/*  29:    */   private JavaTypeInstance allocatedType;
/*  30:    */   private int numDims;
/*  31:    */   private List<Expression> values;
/*  32: 30 */   private boolean isCompletelyAnonymous = false;
/*  33:    */   
/*  34:    */   public NewAnonymousArray(InferredJavaType type, int numDims, List<Expression> values, boolean isCompletelyAnonymous)
/*  35:    */   {
/*  36: 33 */     super(type);
/*  37: 34 */     this.values = ListFactory.newList();
/*  38: 35 */     this.numDims = numDims;
/*  39: 36 */     this.allocatedType = type.getJavaTypeInstance().getArrayStrippedType();
/*  40: 37 */     if ((this.allocatedType instanceof RawJavaType)) {
/*  41: 38 */       for (Expression value : values) {
/*  42: 39 */         value.getInferredJavaType().useAsWithoutCasting((RawJavaType)this.allocatedType);
/*  43:    */       }
/*  44:    */     }
/*  45: 44 */     for (Expression value : values)
/*  46:    */     {
/*  47: 45 */       if ((numDims > 1) && 
/*  48: 46 */         ((value instanceof NewAnonymousArray)))
/*  49:    */       {
/*  50: 47 */         NewAnonymousArray newAnonymousArrayInner = (NewAnonymousArray)value;
/*  51: 48 */         newAnonymousArrayInner.isCompletelyAnonymous = true;
/*  52:    */       }
/*  53: 51 */       this.values.add(value);
/*  54:    */     }
/*  55: 53 */     this.isCompletelyAnonymous = isCompletelyAnonymous;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  59:    */   {
/*  60: 58 */     collector.collect(this.allocatedType);
/*  61: 59 */     collector.collectFrom(this.values);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public boolean rewriteBoxing(PrimitiveBoxingRewriter boxingRewriter)
/*  65:    */   {
/*  66: 64 */     for (int i = 0; i < this.values.size(); i++) {
/*  67: 65 */       this.values.set(i, boxingRewriter.sugarNonParameterBoxing((Expression)this.values.get(i), this.allocatedType));
/*  68:    */     }
/*  69: 67 */     return false;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void applyNonArgExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags) {}
/*  73:    */   
/*  74:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  75:    */   {
/*  76: 76 */     return new NewAnonymousArray(getInferredJavaType(), this.numDims, cloneHelper.replaceOrClone(this.values), this.isCompletelyAnonymous);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public Precedence getPrecedence()
/*  80:    */   {
/*  81: 82 */     return Precedence.PAREN_SUB_MEMBER;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public Dumper dumpInner(Dumper d)
/*  85:    */   {
/*  86: 87 */     if (!this.isCompletelyAnonymous)
/*  87:    */     {
/*  88: 88 */       d.print("new ").dump(this.allocatedType);
/*  89: 89 */       for (int x = 0; x < this.numDims; x++) {
/*  90: 89 */         d.print("[]");
/*  91:    */       }
/*  92:    */     }
/*  93: 91 */     d.print("{");
/*  94: 92 */     boolean first = true;
/*  95: 93 */     for (Expression value : this.values)
/*  96:    */     {
/*  97: 94 */       first = StringUtils.comma(first, d);
/*  98: 95 */       d.dump(value);
/*  99:    */     }
/* 100: 97 */     d.print("}");
/* 101: 98 */     return d;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public List<Expression> getValues()
/* 105:    */   {
/* 106:102 */     return this.values;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/* 110:    */   {
/* 111:107 */     for (int x = this.values.size() - 1; x >= 0; x--) {
/* 112:108 */       this.values.set(x, ((Expression)this.values.get(x)).replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer));
/* 113:    */     }
/* 114:110 */     return this;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 118:    */   {
/* 119:115 */     ExpressionRewriterHelper.applyForwards(this.values, expressionRewriter, ssaIdentifiers, statementContainer, flags);
/* 120:116 */     return this;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 124:    */   {
/* 125:121 */     ExpressionRewriterHelper.applyBackwards(this.values, expressionRewriter, ssaIdentifiers, statementContainer, flags);
/* 126:122 */     return this;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/* 130:    */   {
/* 131:127 */     for (Expression value : this.values) {
/* 132:128 */       value.collectUsedLValues(lValueUsageCollector);
/* 133:    */     }
/* 134:    */   }
/* 135:    */   
/* 136:    */   public int getNumDims()
/* 137:    */   {
/* 138:135 */     return this.numDims;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public int getNumSizedDims()
/* 142:    */   {
/* 143:140 */     return 0;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public Expression getDimSize(int dim)
/* 147:    */   {
/* 148:145 */     throw new UnsupportedOperationException();
/* 149:    */   }
/* 150:    */   
/* 151:    */   public JavaTypeInstance getInnerType()
/* 152:    */   {
/* 153:150 */     return this.allocatedType;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public boolean equals(Object o)
/* 157:    */   {
/* 158:155 */     if (this == o) {
/* 159:155 */       return true;
/* 160:    */     }
/* 161:156 */     if ((o == null) || (getClass() != o.getClass())) {
/* 162:156 */       return false;
/* 163:    */     }
/* 164:158 */     NewAnonymousArray that = (NewAnonymousArray)o;
/* 165:160 */     if (this.isCompletelyAnonymous != that.isCompletelyAnonymous) {
/* 166:160 */       return false;
/* 167:    */     }
/* 168:161 */     if (this.numDims != that.numDims) {
/* 169:161 */       return false;
/* 170:    */     }
/* 171:162 */     if (this.allocatedType != null ? !this.allocatedType.equals(that.allocatedType) : that.allocatedType != null) {
/* 172:163 */       return false;
/* 173:    */     }
/* 174:164 */     if (this.values != null ? !this.values.equals(that.values) : that.values != null) {
/* 175:164 */       return false;
/* 176:    */     }
/* 177:166 */     return true;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 181:    */   {
/* 182:171 */     if (o == null) {
/* 183:171 */       return false;
/* 184:    */     }
/* 185:172 */     if (o == this) {
/* 186:172 */       return true;
/* 187:    */     }
/* 188:173 */     if (getClass() != o.getClass()) {
/* 189:173 */       return false;
/* 190:    */     }
/* 191:174 */     NewAnonymousArray other = (NewAnonymousArray)o;
/* 192:176 */     if (this.isCompletelyAnonymous != other.isCompletelyAnonymous) {
/* 193:176 */       return false;
/* 194:    */     }
/* 195:177 */     if (this.numDims != other.numDims) {
/* 196:177 */       return false;
/* 197:    */     }
/* 198:178 */     if (!constraint.equivalent(this.allocatedType, other.allocatedType)) {
/* 199:178 */       return false;
/* 200:    */     }
/* 201:179 */     if (!constraint.equivalent(this.values, other.values)) {
/* 202:179 */       return false;
/* 203:    */     }
/* 204:180 */     return true;
/* 205:    */   }
/* 206:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.NewAnonymousArray
 * JD-Core Version:    0.7.0.1
 */