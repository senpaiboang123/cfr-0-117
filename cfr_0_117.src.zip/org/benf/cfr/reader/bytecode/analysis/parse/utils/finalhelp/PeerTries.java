/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.utils.finalhelp;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.LinkedList;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Set;
/*   8:    */ import java.util.TreeMap;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.TryStatement;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  13:    */ import org.benf.cfr.reader.util.ListFactory;
/*  14:    */ import org.benf.cfr.reader.util.MapFactory;
/*  15:    */ import org.benf.cfr.reader.util.SetFactory;
/*  16:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  17:    */ 
/*  18:    */ public class PeerTries
/*  19:    */ {
/*  20:    */   private final FinallyGraphHelper finallyGraphHelper;
/*  21:    */   private final Op03SimpleStatement possibleFinallyCatch;
/*  22: 48 */   private final Set<Op03SimpleStatement> seenEver = SetFactory.newOrderedSet();
/*  23: 50 */   private final LinkedList<Op03SimpleStatement> toProcess = ListFactory.newLinkedList();
/*  24:    */   private int nextIdx;
/*  25: 56 */   Set<BlockIdentifier> guessPeerTryBlocks = SetFactory.newSet();
/*  26: 57 */   Map<BlockIdentifier, Op03SimpleStatement> guessPeerTryMap = MapFactory.newMap();
/*  27: 58 */   Set<Op03SimpleStatement> guessPeerTryStarts = SetFactory.newSet();
/*  28: 60 */   private final Map<CompositeBlockIdentifierKey, PeerTrySet> triesByLevel = MapFactory.newLazyMap(new TreeMap(), new UnaryFunction()
/*  29:    */   {
/*  30:    */     public PeerTries.PeerTrySet invoke(CompositeBlockIdentifierKey arg)
/*  31:    */     {
/*  32: 65 */       return new PeerTries.PeerTrySet(PeerTries.access$008(PeerTries.this), null);
/*  33:    */     }
/*  34: 60 */   });
/*  35:    */   
/*  36:    */   public PeerTries(FinallyGraphHelper finallyGraphHelper, Op03SimpleStatement possibleFinallyCatch)
/*  37:    */   {
/*  38: 70 */     this.finallyGraphHelper = finallyGraphHelper;
/*  39: 71 */     this.possibleFinallyCatch = possibleFinallyCatch;
/*  40: 73 */     for (Op03SimpleStatement source : possibleFinallyCatch.getSources())
/*  41:    */     {
/*  42: 74 */       Statement statement = source.getStatement();
/*  43: 75 */       if ((statement instanceof TryStatement))
/*  44:    */       {
/*  45: 76 */         TryStatement tryStatement = (TryStatement)statement;
/*  46: 77 */         BlockIdentifier blockIdentifier = tryStatement.getBlockIdentifier();
/*  47: 78 */         this.guessPeerTryBlocks.add(blockIdentifier);
/*  48: 79 */         this.guessPeerTryMap.put(blockIdentifier, source);
/*  49: 80 */         this.guessPeerTryStarts.add(source);
/*  50:    */       }
/*  51:    */     }
/*  52:    */   }
/*  53:    */   
/*  54:    */   public Op03SimpleStatement getOriginalFinally()
/*  55:    */   {
/*  56: 86 */     return this.possibleFinallyCatch;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public Set<BlockIdentifier> getGuessPeerTryBlocks()
/*  60:    */   {
/*  61: 90 */     return this.guessPeerTryBlocks;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public Map<BlockIdentifier, Op03SimpleStatement> getGuessPeerTryMap()
/*  65:    */   {
/*  66: 94 */     return this.guessPeerTryMap;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public Set<Op03SimpleStatement> getGuessPeerTryStarts()
/*  70:    */   {
/*  71: 98 */     return this.guessPeerTryStarts;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void add(Op03SimpleStatement tryStatement)
/*  75:    */   {
/*  76:102 */     if (!(tryStatement.getStatement() instanceof TryStatement)) {
/*  77:103 */       throw new IllegalStateException();
/*  78:    */     }
/*  79:105 */     if (this.seenEver.contains(tryStatement)) {
/*  80:105 */       return;
/*  81:    */     }
/*  82:107 */     this.toProcess.add(tryStatement);
/*  83:108 */     ((PeerTrySet)this.triesByLevel.get(new CompositeBlockIdentifierKey(tryStatement))).add(tryStatement);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public boolean hasNext()
/*  87:    */   {
/*  88:112 */     return !this.toProcess.isEmpty();
/*  89:    */   }
/*  90:    */   
/*  91:    */   public Op03SimpleStatement removeNext()
/*  92:    */   {
/*  93:116 */     return (Op03SimpleStatement)this.toProcess.removeFirst();
/*  94:    */   }
/*  95:    */   
/*  96:    */   public List<PeerTrySet> getPeerTryGroups()
/*  97:    */   {
/*  98:120 */     return ListFactory.newList(this.triesByLevel.values());
/*  99:    */   }
/* 100:    */   
/* 101:    */   public static final class PeerTrySet
/* 102:    */   {
/* 103:124 */     private final Set<Op03SimpleStatement> content = SetFactory.newOrderedSet();
/* 104:    */     private final int idx;
/* 105:    */     
/* 106:    */     private PeerTrySet(int idx)
/* 107:    */     {
/* 108:128 */       this.idx = idx;
/* 109:    */     }
/* 110:    */     
/* 111:    */     public void add(Op03SimpleStatement op)
/* 112:    */     {
/* 113:132 */       this.content.add(op);
/* 114:    */     }
/* 115:    */     
/* 116:    */     public Collection<Op03SimpleStatement> getPeerTries()
/* 117:    */     {
/* 118:136 */       return this.content;
/* 119:    */     }
/* 120:    */     
/* 121:    */     public boolean equals(Object o)
/* 122:    */     {
/* 123:141 */       if (this == o) {
/* 124:141 */         return true;
/* 125:    */       }
/* 126:142 */       if ((o == null) || (getClass() != o.getClass())) {
/* 127:142 */         return false;
/* 128:    */       }
/* 129:144 */       PeerTrySet that = (PeerTrySet)o;
/* 130:146 */       if (this.idx != that.idx) {
/* 131:146 */         return false;
/* 132:    */       }
/* 133:148 */       return true;
/* 134:    */     }
/* 135:    */     
/* 136:    */     public int hashCode()
/* 137:    */     {
/* 138:153 */       return this.idx;
/* 139:    */     }
/* 140:    */   }
/* 141:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.finalhelp.PeerTries
 * JD-Core Version:    0.7.0.1
 */