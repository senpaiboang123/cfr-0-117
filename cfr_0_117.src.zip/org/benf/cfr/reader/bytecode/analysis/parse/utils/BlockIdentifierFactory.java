/* 1:  */ package org.benf.cfr.reader.bytecode.analysis.parse.utils;
/* 2:  */ 
/* 3:  */ public class BlockIdentifierFactory
/* 4:  */ {
/* 5:4 */   int idx = 0;
/* 6:  */   
/* 7:  */   public BlockIdentifier getNextBlockIdentifier(BlockType blockType)
/* 8:  */   {
/* 9:7 */     return new BlockIdentifier(this.idx++, blockType);
/* ::  */   }
/* ;:  */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifierFactory
 * JD-Core Version:    0.7.0.1
 */