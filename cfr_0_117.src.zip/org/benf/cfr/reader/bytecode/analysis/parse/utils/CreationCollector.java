/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.utils;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Map;
/*   5:    */ import java.util.Map.Entry;
/*   6:    */ import org.benf.cfr.reader.bytecode.AnonymousClassUsage;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.InstrIndex;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractConstructorInvokation;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationAnonymousInner;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationSimple;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.MemberFunctionInvokation;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.NewObject;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.StackValue;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.AssignmentSimple;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.stack.StackEntry;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.types.BindingSuperContainer;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.types.InnerClassInfo;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  26:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  27:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  28:    */ import org.benf.cfr.reader.entities.Method;
/*  29:    */ import org.benf.cfr.reader.state.DCCommonState;
/*  30:    */ import org.benf.cfr.reader.util.ListFactory;
/*  31:    */ import org.benf.cfr.reader.util.MapFactory;
/*  32:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  33:    */ 
/*  34:    */ public class CreationCollector
/*  35:    */ {
/*  36:    */   private static class StatementPair<X>
/*  37:    */   {
/*  38:    */     private final X value;
/*  39:    */     private final StatementContainer location;
/*  40:    */     
/*  41:    */     private StatementPair(X value, StatementContainer location)
/*  42:    */     {
/*  43: 38 */       this.value = value;
/*  44: 39 */       this.location = location;
/*  45:    */     }
/*  46:    */     
/*  47:    */     private X getValue()
/*  48:    */     {
/*  49: 43 */       return this.value;
/*  50:    */     }
/*  51:    */     
/*  52:    */     private StatementContainer getLocation()
/*  53:    */     {
/*  54: 47 */       return this.location;
/*  55:    */     }
/*  56:    */   }
/*  57:    */   
/*  58:    */   private static class Triple
/*  59:    */   {
/*  60:    */     private final LValue lValue;
/*  61:    */     private final CreationCollector.StatementPair<NewObject> creation;
/*  62:    */     private final CreationCollector.StatementPair<MemberFunctionInvokation> construction;
/*  63:    */     
/*  64:    */     private Triple(LValue lValue, CreationCollector.StatementPair<NewObject> creation, CreationCollector.StatementPair<MemberFunctionInvokation> construction)
/*  65:    */     {
/*  66: 57 */       this.lValue = lValue;
/*  67: 58 */       this.creation = creation;
/*  68: 59 */       this.construction = construction;
/*  69:    */     }
/*  70:    */     
/*  71:    */     private LValue getlValue()
/*  72:    */     {
/*  73: 63 */       return this.lValue;
/*  74:    */     }
/*  75:    */     
/*  76:    */     private CreationCollector.StatementPair<NewObject> getCreation()
/*  77:    */     {
/*  78: 67 */       return this.creation;
/*  79:    */     }
/*  80:    */     
/*  81:    */     private CreationCollector.StatementPair<MemberFunctionInvokation> getConstruction()
/*  82:    */     {
/*  83: 71 */       return this.construction;
/*  84:    */     }
/*  85:    */   }
/*  86:    */   
/*  87: 75 */   private final List<Triple> collectedConstructions = ListFactory.newList();
/*  88: 76 */   private final Map<LValue, List<StatementContainer>> collectedCreations = MapFactory.newLazyMap(new UnaryFunction()
/*  89:    */   {
/*  90:    */     public List<StatementContainer> invoke(LValue arg)
/*  91:    */     {
/*  92: 79 */       return ListFactory.newList();
/*  93:    */     }
/*  94: 76 */   });
/*  95:    */   private final AnonymousClassUsage anonymousClassUsage;
/*  96:    */   
/*  97:    */   public CreationCollector(AnonymousClassUsage anonymousClassUsage)
/*  98:    */   {
/*  99: 86 */     this.anonymousClassUsage = anonymousClassUsage;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public void collectCreation(LValue lValue, Expression rValue, StatementContainer container)
/* 103:    */   {
/* 104: 90 */     if (!(rValue instanceof NewObject)) {
/* 105: 90 */       return;
/* 106:    */     }
/* 107: 91 */     if ((!(lValue instanceof StackSSALabel)) && (!(lValue instanceof LocalVariable))) {
/* 108: 91 */       return;
/* 109:    */     }
/* 110: 92 */     ((List)this.collectedCreations.get(lValue)).add(container);
/* 111:    */   }
/* 112:    */   
/* 113:    */   public void collectConstruction(Expression expression, MemberFunctionInvokation rValue, StatementContainer container)
/* 114:    */   {
/* 115:102 */     if ((expression instanceof StackValue))
/* 116:    */     {
/* 117:103 */       StackSSALabel lValue = ((StackValue)expression).getStackValue();
/* 118:104 */       markConstruction(lValue, rValue, container);
/* 119:105 */       return;
/* 120:    */     }
/* 121:107 */     if ((expression instanceof LValueExpression))
/* 122:    */     {
/* 123:108 */       LValue lValue = ((LValueExpression)expression).getLValue();
/* 124:109 */       markConstruction(lValue, rValue, container);
/* 125:110 */       return;
/* 126:    */     }
/* 127:    */   }
/* 128:    */   
/* 129:    */   private void markConstruction(LValue lValue, MemberFunctionInvokation rValue, StatementContainer container)
/* 130:    */   {
/* 131:116 */     this.collectedConstructions.add(new Triple(lValue, null, new StatementPair(rValue, container, null), null));
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void condenseConstructions(Method method, DCCommonState dcCommonState)
/* 135:    */   {
/* 136:124 */     for (Triple construction : this.collectedConstructions)
/* 137:    */     {
/* 138:125 */       LValue lValue = construction.getlValue();
/* 139:126 */       StatementPair<MemberFunctionInvokation> constructionValue = construction.getConstruction();
/* 140:127 */       if (constructionValue != null)
/* 141:    */       {
/* 142:129 */         InstrIndex idx = constructionValue.getLocation().getIndex();
/* 143:130 */         if (this.collectedCreations.containsKey(lValue))
/* 144:    */         {
/* 145:131 */           List<StatementContainer> creations = (List)this.collectedCreations.get(lValue);
/* 146:132 */           boolean found = false;
/* 147:133 */           for (StatementContainer creation : creations) {
/* 148:134 */             if (creation.getIndex().isBackJumpFrom(idx))
/* 149:    */             {
/* 150:135 */               found = true;
/* 151:136 */               break;
/* 152:    */             }
/* 153:    */           }
/* 154:139 */           if (found)
/* 155:    */           {
/* 156:144 */             MemberFunctionInvokation memberFunctionInvokation = (MemberFunctionInvokation)constructionValue.getValue();
/* 157:    */             
/* 158:146 */             JavaTypeInstance lValueType = memberFunctionInvokation.getClassTypeInstance();
/* 159:    */             
/* 160:148 */             InferredJavaType inferredJavaType = lValue.getInferredJavaType();
/* 161:    */             
/* 162:    */ 
/* 163:151 */             AbstractConstructorInvokation constructorInvokation = null;
/* 164:152 */             InnerClassInfo innerClassInfo = lValueType.getInnerClassHereInfo();
/* 165:154 */             if ((innerClassInfo.isMethodScopedClass()) && (!innerClassInfo.isAnonymousClass())) {
/* 166:155 */               method.markUsedLocalClassType(lValueType);
/* 167:    */             }
/* 168:158 */             if (innerClassInfo.isAnonymousClass())
/* 169:    */             {
/* 170:163 */               ConstructorInvokationAnonymousInner constructorInvokationAnonymousInner = new ConstructorInvokationAnonymousInner(memberFunctionInvokation, inferredJavaType, memberFunctionInvokation.getArgs(), dcCommonState, lValueType);
/* 171:    */               
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:168 */               constructorInvokation = constructorInvokationAnonymousInner;
/* 176:169 */               ClassFile classFile = constructorInvokationAnonymousInner.getClassFile();
/* 177:170 */               if (classFile != null) {
/* 178:171 */                 this.anonymousClassUsage.note(classFile, constructorInvokationAnonymousInner);
/* 179:    */               }
/* 180:174 */               BindingSuperContainer bindingSuperContainer = lValueType.getBindingSupers();
/* 181:176 */               if (bindingSuperContainer != null)
/* 182:    */               {
/* 183:177 */                 JavaTypeInstance bestGuess = bindingSuperContainer.getMostLikelyAnonymousType(lValueType);
/* 184:    */                 
/* 185:179 */                 inferredJavaType.forceDelegate(new InferredJavaType(bestGuess, InferredJavaType.Source.UNKNOWN));
/* 186:    */               }
/* 187:    */             }
/* 188:    */             else
/* 189:    */             {
/* 190:182 */               constructorInvokation = new ConstructorInvokationSimple(memberFunctionInvokation, inferredJavaType, memberFunctionInvokation.getArgs());
/* 191:    */             }
/* 192:188 */             AssignmentSimple replacement = new AssignmentSimple(lValue, constructorInvokation);
/* 193:190 */             if ((lValue instanceof StackSSALabel))
/* 194:    */             {
/* 195:191 */               StackSSALabel stackSSALabel = (StackSSALabel)lValue;
/* 196:192 */               StackEntry stackEntry = stackSSALabel.getStackEntry();
/* 197:193 */               stackEntry.decrementUsage();
/* 198:194 */               stackEntry.incSourceCount();
/* 199:    */             }
/* 200:196 */             StatementContainer constructionContainer = constructionValue.getLocation();
/* 201:    */             
/* 202:    */ 
/* 203:199 */             constructionContainer.replaceStatement(replacement);
/* 204:    */           }
/* 205:    */         }
/* 206:    */       }
/* 207:    */     }
/* 208:202 */     for (Map.Entry<LValue, List<StatementContainer>> creations : this.collectedCreations.entrySet())
/* 209:    */     {
/* 210:203 */       lValue = (LValue)creations.getKey();
/* 211:204 */       for (StatementContainer statementContainer : (List)creations.getValue())
/* 212:    */       {
/* 213:205 */         if ((lValue instanceof StackSSALabel))
/* 214:    */         {
/* 215:206 */           StackEntry stackEntry = ((StackSSALabel)lValue).getStackEntry();
/* 216:207 */           stackEntry.decSourceCount();
/* 217:    */         }
/* 218:209 */         statementContainer.nopOut();
/* 219:    */       }
/* 220:    */     }
/* 221:    */     LValue lValue;
/* 222:    */   }
/* 223:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.CreationCollector
 * JD-Core Version:    0.7.0.1
 */