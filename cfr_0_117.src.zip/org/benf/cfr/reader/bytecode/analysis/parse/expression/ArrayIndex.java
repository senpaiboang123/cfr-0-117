/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.PrimitiveBoxingRewriter;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface.BoxingProcessor;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  21:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  22:    */ import org.benf.cfr.reader.util.Troolean;
/*  23:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  24:    */ 
/*  25:    */ public class ArrayIndex
/*  26:    */   extends AbstractExpression
/*  27:    */   implements BoxingProcessor
/*  28:    */ {
/*  29:    */   private Expression array;
/*  30:    */   private Expression index;
/*  31:    */   
/*  32:    */   public ArrayIndex(Expression array, Expression index)
/*  33:    */   {
/*  34: 25 */     super(new InferredJavaType(array.getInferredJavaType().getJavaTypeInstance().removeAnArrayIndirection(), InferredJavaType.Source.OPERATION));
/*  35: 26 */     this.array = array;
/*  36: 27 */     this.index = index;
/*  37: 28 */     index.getInferredJavaType().useAsWithoutCasting(RawJavaType.INT);
/*  38:    */   }
/*  39:    */   
/*  40:    */   private ArrayIndex(InferredJavaType inferredJavaType, Expression array, Expression index)
/*  41:    */   {
/*  42: 32 */     super(inferredJavaType);
/*  43: 33 */     this.array = array;
/*  44: 34 */     this.index = index;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  48:    */   {
/*  49: 39 */     this.array.collectTypeUsages(collector);
/*  50: 40 */     this.index.collectTypeUsages(collector);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  54:    */   {
/*  55: 45 */     return new ArrayIndex(getInferredJavaType(), cloneHelper.replaceOrClone(this.array), cloneHelper.replaceOrClone(this.index));
/*  56:    */   }
/*  57:    */   
/*  58:    */   public Precedence getPrecedence()
/*  59:    */   {
/*  60: 50 */     return Precedence.PAREN_SUB_MEMBER;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public Dumper dumpInner(Dumper d)
/*  64:    */   {
/*  65: 55 */     this.array.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.NEITHER);
/*  66: 56 */     d.print("[").dump(this.index).print("]");
/*  67: 57 */     return d;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  71:    */   {
/*  72: 62 */     this.index = this.index.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/*  73: 63 */     this.array = this.array.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/*  74: 64 */     return this;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public boolean doesBlackListLValueReplacement(LValue replace, Expression with)
/*  78:    */   {
/*  79: 68 */     if (((replace instanceof StackSSALabel)) && ((this.array instanceof StackValue)))
/*  80:    */     {
/*  81: 69 */       StackSSALabel referred = ((StackValue)this.array).getStackValue();
/*  82: 70 */       if (referred.equals(replace))
/*  83:    */       {
/*  84: 71 */         if (with.isSimple()) {
/*  85: 71 */           return false;
/*  86:    */         }
/*  87: 72 */         return true;
/*  88:    */       }
/*  89:    */     }
/*  90: 75 */     return false;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  94:    */   {
/*  95: 80 */     this.array = expressionRewriter.rewriteExpression(this.array, ssaIdentifiers, statementContainer, flags);
/*  96: 81 */     this.index = expressionRewriter.rewriteExpression(this.index, ssaIdentifiers, statementContainer, flags);
/*  97: 82 */     return this;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 101:    */   {
/* 102: 87 */     this.index = expressionRewriter.rewriteExpression(this.index, ssaIdentifiers, statementContainer, flags);
/* 103: 88 */     this.array = expressionRewriter.rewriteExpression(this.array, ssaIdentifiers, statementContainer, flags);
/* 104: 89 */     return this;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/* 108:    */   {
/* 109: 94 */     this.array.collectUsedLValues(lValueUsageCollector);
/* 110: 95 */     this.index.collectUsedLValues(lValueUsageCollector);
/* 111:    */   }
/* 112:    */   
/* 113:    */   public Expression getArray()
/* 114:    */   {
/* 115: 99 */     return this.array;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public Expression getIndex()
/* 119:    */   {
/* 120:103 */     return this.index;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public boolean equals(Object o)
/* 124:    */   {
/* 125:108 */     if (o == this) {
/* 126:108 */       return true;
/* 127:    */     }
/* 128:109 */     if (!(o instanceof ArrayIndex)) {
/* 129:109 */       return false;
/* 130:    */     }
/* 131:110 */     ArrayIndex other = (ArrayIndex)o;
/* 132:111 */     return (this.array.equals(other.array)) && (this.index.equals(other.index));
/* 133:    */   }
/* 134:    */   
/* 135:    */   public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 136:    */   {
/* 137:117 */     if (o == this) {
/* 138:117 */       return true;
/* 139:    */     }
/* 140:118 */     if (!(o instanceof ArrayIndex)) {
/* 141:118 */       return false;
/* 142:    */     }
/* 143:119 */     ArrayIndex other = (ArrayIndex)o;
/* 144:120 */     if (!constraint.equivalent(this.array, other.array)) {
/* 145:120 */       return false;
/* 146:    */     }
/* 147:121 */     if (!constraint.equivalent(this.index, other.index)) {
/* 148:121 */       return false;
/* 149:    */     }
/* 150:122 */     return true;
/* 151:    */   }
/* 152:    */   
/* 153:    */   public boolean rewriteBoxing(PrimitiveBoxingRewriter boxingRewriter)
/* 154:    */   {
/* 155:127 */     this.index = boxingRewriter.sugarUnboxing(this.index);
/* 156:128 */     return false;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public void applyNonArgExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags) {}
/* 160:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.ArrayIndex
 * JD-Core Version:    0.7.0.1
 */