/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.rewriters;
/*  2:   */ 
/*  3:   */ import java.util.Map;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.StackValue;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 13:   */ import org.benf.cfr.reader.util.MapFactory;
/* 14:   */ 
/* 15:   */ public class StackVarToLocalRewriter
/* 16:   */   implements ExpressionRewriter
/* 17:   */ {
/* 18:21 */   private final Map<StackSSALabel, LocalVariable> replacements = MapFactory.newMap();
/* 19:22 */   private int idx = 0;
/* 20:   */   
/* 21:   */   public void handleStatement(StatementContainer statementContainer) {}
/* 22:   */   
/* 23:   */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 24:   */   {
/* 25:30 */     if ((expression instanceof StackValue))
/* 26:   */     {
/* 27:32 */       StackValue stackValue = (StackValue)expression;
/* 28:33 */       return new LValueExpression(getReplacement(stackValue.getStackValue()));
/* 29:   */     }
/* 30:35 */     return expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 31:   */   }
/* 32:   */   
/* 33:   */   public ConditionalExpression rewriteExpression(ConditionalExpression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 34:   */   {
/* 35:40 */     Expression res = expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 36:41 */     return (ConditionalExpression)res;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 40:   */   {
/* 41:52 */     if ((lValue instanceof StackSSALabel)) {
/* 42:53 */       return getReplacement((StackSSALabel)lValue);
/* 43:   */     }
/* 44:55 */     return lValue.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 45:   */   }
/* 46:   */   
/* 47:   */   public StackSSALabel rewriteExpression(StackSSALabel lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 48:   */   {
/* 49:61 */     throw new UnsupportedOperationException();
/* 50:   */   }
/* 51:   */   
/* 52:   */   private LocalVariable getReplacement(StackSSALabel stackSSALabel)
/* 53:   */   {
/* 54:65 */     LocalVariable res = (LocalVariable)this.replacements.get(stackSSALabel);
/* 55:66 */     if (res != null) {
/* 56:66 */       return res;
/* 57:   */     }
/* 58:67 */     res = new LocalVariable("v" + this.idx++, stackSSALabel.getInferredJavaType());
/* 59:68 */     this.replacements.put(stackSSALabel, res);
/* 60:69 */     return res;
/* 61:   */   }
/* 62:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.rewriters.StackVarToLocalRewriter
 * JD-Core Version:    0.7.0.1
 */