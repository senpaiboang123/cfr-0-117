/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import java.util.Map;
/*   4:    */ import java.util.Set;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.ConditionalUtils;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  18:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  19:    */ import org.benf.cfr.reader.util.Troolean;
/*  20:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  21:    */ 
/*  22:    */ public class NotOperation
/*  23:    */   extends AbstractExpression
/*  24:    */   implements ConditionalExpression
/*  25:    */ {
/*  26:    */   private ConditionalExpression inner;
/*  27:    */   
/*  28:    */   public NotOperation(ConditionalExpression lhs)
/*  29:    */   {
/*  30: 23 */     super(lhs.getInferredJavaType());
/*  31: 24 */     this.inner = lhs;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  35:    */   {
/*  36: 29 */     this.inner.collectTypeUsages(collector);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  40:    */   {
/*  41: 34 */     return new NotOperation((ConditionalExpression)cloneHelper.replaceOrClone(this.inner));
/*  42:    */   }
/*  43:    */   
/*  44:    */   public int getSize(Precedence outerPrecedence)
/*  45:    */   {
/*  46: 39 */     return 1 + this.inner.getSize(getPrecedence());
/*  47:    */   }
/*  48:    */   
/*  49:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  50:    */   {
/*  51: 44 */     return this;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  55:    */   {
/*  56: 49 */     this.inner = expressionRewriter.rewriteExpression(this.inner, ssaIdentifiers, statementContainer, flags);
/*  57: 50 */     return this;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  61:    */   {
/*  62: 55 */     return applyExpressionRewriter(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public Precedence getPrecedence()
/*  66:    */   {
/*  67: 60 */     return Precedence.UNARY_OTHER;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public Dumper dumpInner(Dumper d)
/*  71:    */   {
/*  72: 65 */     d.print("!");
/*  73: 66 */     this.inner.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.NEITHER);
/*  74: 67 */     return d;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public ConditionalExpression getNegated()
/*  78:    */   {
/*  79: 72 */     return this.inner;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public ConditionalExpression getDemorganApplied(boolean amNegating)
/*  83:    */   {
/*  84: 77 */     return this.inner.getDemorganApplied(!amNegating);
/*  85:    */   }
/*  86:    */   
/*  87:    */   public ConditionalExpression getRightDeep()
/*  88:    */   {
/*  89: 82 */     this.inner = this.inner.getRightDeep();
/*  90: 83 */     return this;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public Set<LValue> getLoopLValues()
/*  94:    */   {
/*  95: 88 */     return this.inner.getLoopLValues();
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/*  99:    */   {
/* 100: 93 */     this.inner.collectUsedLValues(lValueUsageCollector);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public ConditionalExpression optimiseForType()
/* 104:    */   {
/* 105: 98 */     return this;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public ConditionalExpression simplify()
/* 109:    */   {
/* 110:103 */     return ConditionalUtils.simplify(this);
/* 111:    */   }
/* 112:    */   
/* 113:    */   public boolean equals(Object obj)
/* 114:    */   {
/* 115:108 */     if (obj == null) {
/* 116:108 */       return false;
/* 117:    */     }
/* 118:109 */     if (obj == this) {
/* 119:109 */       return true;
/* 120:    */     }
/* 121:111 */     if (!(obj instanceof NotOperation)) {
/* 122:111 */       return false;
/* 123:    */     }
/* 124:113 */     NotOperation other = (NotOperation)obj;
/* 125:114 */     return this.inner.equals(other.inner);
/* 126:    */   }
/* 127:    */   
/* 128:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 129:    */   {
/* 130:119 */     if (o == null) {
/* 131:119 */       return false;
/* 132:    */     }
/* 133:120 */     if (o == this) {
/* 134:120 */       return true;
/* 135:    */     }
/* 136:121 */     if (getClass() != o.getClass()) {
/* 137:121 */       return false;
/* 138:    */     }
/* 139:122 */     NotOperation other = (NotOperation)o;
/* 140:123 */     if (!constraint.equivalent(this.inner, other.inner)) {
/* 141:123 */       return false;
/* 142:    */     }
/* 143:124 */     return true;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public Literal getComputedLiteral(Map<LValue, Literal> display)
/* 147:    */   {
/* 148:129 */     Literal lv = this.inner.getComputedLiteral(display);
/* 149:130 */     if (lv == null) {
/* 150:130 */       return null;
/* 151:    */     }
/* 152:131 */     TypedLiteral typedLiteral = lv.getValue();
/* 153:132 */     Boolean boolVal = typedLiteral.getMaybeBoolValue();
/* 154:133 */     if (boolVal == null) {
/* 155:133 */       return null;
/* 156:    */     }
/* 157:134 */     return boolVal.booleanValue() ? Literal.TRUE : Literal.FALSE;
/* 158:    */   }
/* 159:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.NotOperation
 * JD-Core Version:    0.7.0.1
 */