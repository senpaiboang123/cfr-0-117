package org.benf.cfr.reader.bytecode.analysis.parse;

import java.util.Map;
import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.DeepCloneable;
import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.ComparableUnderEC;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
import org.benf.cfr.reader.util.TypeUsageCollectable;
import org.benf.cfr.reader.util.output.DumpableWithPrecedence;
import org.benf.cfr.reader.util.output.Dumper;

public abstract interface Expression
  extends DumpableWithPrecedence, DeepCloneable<Expression>, ComparableUnderEC, TypeUsageCollectable
{
  public abstract Expression replaceSingleUsageLValues(LValueRewriter paramLValueRewriter, SSAIdentifiers paramSSAIdentifiers, StatementContainer paramStatementContainer);
  
  public abstract Expression applyExpressionRewriter(ExpressionRewriter paramExpressionRewriter, SSAIdentifiers paramSSAIdentifiers, StatementContainer paramStatementContainer, ExpressionRewriterFlags paramExpressionRewriterFlags);
  
  public abstract Expression applyReverseExpressionRewriter(ExpressionRewriter paramExpressionRewriter, SSAIdentifiers paramSSAIdentifiers, StatementContainer paramStatementContainer, ExpressionRewriterFlags paramExpressionRewriterFlags);
  
  public abstract boolean isSimple();
  
  public abstract void collectUsedLValues(LValueUsageCollector paramLValueUsageCollector);
  
  public abstract boolean canPushDownInto();
  
  public abstract Expression pushDown(Expression paramExpression1, Expression paramExpression2);
  
  public abstract InferredJavaType getInferredJavaType();
  
  public abstract boolean equivalentUnder(Object paramObject, EquivalenceConstraint paramEquivalenceConstraint);
  
  public abstract boolean canThrow(ExceptionCheck paramExceptionCheck);
  
  public abstract Literal getComputedLiteral(Map<LValue, Literal> paramMap);
  
  public abstract Dumper dump(Dumper paramDumper);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.Expression
 * JD-Core Version:    0.7.0.1
 */