/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterHelper;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  16:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  17:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  18:    */ 
/*  19:    */ public class DynamicInvokation
/*  20:    */   extends AbstractExpression
/*  21:    */ {
/*  22:    */   private Expression innerInvokation;
/*  23:    */   private List<Expression> dynamicArgs;
/*  24:    */   
/*  25:    */   public DynamicInvokation(InferredJavaType castJavaType, Expression innerInvokation, List<Expression> dynamicArgs)
/*  26:    */   {
/*  27: 22 */     super(castJavaType);
/*  28: 23 */     this.innerInvokation = innerInvokation;
/*  29: 24 */     this.dynamicArgs = dynamicArgs;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  33:    */   {
/*  34: 29 */     return new DynamicInvokation(getInferredJavaType(), cloneHelper.replaceOrClone(this.innerInvokation), cloneHelper.replaceOrClone(this.dynamicArgs));
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  38:    */   {
/*  39: 34 */     collector.collectFrom(this.innerInvokation);
/*  40: 35 */     collector.collectFrom(this.dynamicArgs);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  44:    */   {
/*  45: 40 */     this.innerInvokation.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/*  46: 41 */     for (int x = this.dynamicArgs.size() - 1; x >= 0; x--) {
/*  47: 42 */       this.dynamicArgs.set(x, ((Expression)this.dynamicArgs.get(x)).replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer));
/*  48:    */     }
/*  49: 44 */     return this;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  53:    */   {
/*  54: 49 */     this.innerInvokation.applyExpressionRewriter(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  55: 50 */     ExpressionRewriterHelper.applyForwards(this.dynamicArgs, expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  56: 51 */     return this;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  60:    */   {
/*  61: 56 */     ExpressionRewriterHelper.applyBackwards(this.dynamicArgs, expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  62: 57 */     this.innerInvokation.applyExpressionRewriter(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  63: 58 */     return this;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public Precedence getPrecedence()
/*  67:    */   {
/*  68: 63 */     return Precedence.PAREN_SUB_MEMBER;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public Dumper dumpInner(Dumper d)
/*  72:    */   {
/*  73: 68 */     d.print("(").dump(getInferredJavaType().getJavaTypeInstance()).print(")");
/*  74: 69 */     d.dump(this.innerInvokation);
/*  75: 70 */     d.print("(");
/*  76: 71 */     boolean first = true;
/*  77: 72 */     for (Expression arg : this.dynamicArgs)
/*  78:    */     {
/*  79: 73 */       if (!first) {
/*  80: 73 */         d.print(", ");
/*  81:    */       }
/*  82: 74 */       first = false;
/*  83: 75 */       d.dump(arg);
/*  84:    */     }
/*  85: 77 */     d.print(")");
/*  86: 78 */     return d;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/*  90:    */   {
/*  91: 83 */     this.innerInvokation.collectUsedLValues(lValueUsageCollector);
/*  92: 84 */     for (Expression expression : this.dynamicArgs) {
/*  93: 85 */       expression.collectUsedLValues(lValueUsageCollector);
/*  94:    */     }
/*  95:    */   }
/*  96:    */   
/*  97:    */   public Expression getInnerInvokation()
/*  98:    */   {
/*  99: 90 */     return this.innerInvokation;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public List<Expression> getDynamicArgs()
/* 103:    */   {
/* 104: 94 */     return this.dynamicArgs;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public boolean equals(Object o)
/* 108:    */   {
/* 109: 99 */     if (this == o) {
/* 110: 99 */       return true;
/* 111:    */     }
/* 112:100 */     if ((o == null) || (getClass() != o.getClass())) {
/* 113:100 */       return false;
/* 114:    */     }
/* 115:102 */     DynamicInvokation that = (DynamicInvokation)o;
/* 116:104 */     if (this.dynamicArgs != null ? !this.dynamicArgs.equals(that.dynamicArgs) : that.dynamicArgs != null) {
/* 117:104 */       return false;
/* 118:    */     }
/* 119:105 */     if (this.innerInvokation != null ? !this.innerInvokation.equals(that.innerInvokation) : that.innerInvokation != null) {
/* 120:106 */       return false;
/* 121:    */     }
/* 122:108 */     return true;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 126:    */   {
/* 127:113 */     if (o == null) {
/* 128:113 */       return false;
/* 129:    */     }
/* 130:114 */     if (o == this) {
/* 131:114 */       return true;
/* 132:    */     }
/* 133:115 */     if (getClass() != o.getClass()) {
/* 134:115 */       return false;
/* 135:    */     }
/* 136:116 */     DynamicInvokation other = (DynamicInvokation)o;
/* 137:117 */     if (!constraint.equivalent(this.innerInvokation, other.innerInvokation)) {
/* 138:117 */       return false;
/* 139:    */     }
/* 140:118 */     if (!constraint.equivalent(this.dynamicArgs, other.dynamicArgs)) {
/* 141:118 */       return false;
/* 142:    */     }
/* 143:119 */     return true;
/* 144:    */   }
/* 145:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.DynamicInvokation
 * JD-Core Version:    0.7.0.1
 */