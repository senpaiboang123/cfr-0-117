/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.rewriters;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  7:   */ 
/*  8:   */ public class ExpressionRewriterHelper
/*  9:   */ {
/* 10:   */   public static void applyForwards(List<Expression> list, ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 11:   */   {
/* 12:11 */     for (int x = 0; x < list.size(); x++) {
/* 13:12 */       list.set(x, expressionRewriter.rewriteExpression((Expression)list.get(x), ssaIdentifiers, statementContainer, flags));
/* 14:   */     }
/* 15:   */   }
/* 16:   */   
/* 17:   */   public static void applyBackwards(List<Expression> list, ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 18:   */   {
/* 19:17 */     for (int x = list.size() - 1; x >= 0; x--) {
/* 20:18 */       list.set(x, expressionRewriter.rewriteExpression((Expression)list.get(x), ssaIdentifiers, statementContainer, flags));
/* 21:   */     }
/* 22:   */   }
/* 23:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterHelper
 * JD-Core Version:    0.7.0.1
 */