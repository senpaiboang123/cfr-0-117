/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.ArrayType;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaArrayTypeInstance;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  19:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  20:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  21:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  22:    */ 
/*  23:    */ public class NewPrimitiveArray
/*  24:    */   extends AbstractNewArray
/*  25:    */ {
/*  26:    */   private Expression size;
/*  27:    */   private final JavaTypeInstance type;
/*  28:    */   
/*  29:    */   public NewPrimitiveArray(Expression size, byte type)
/*  30:    */   {
/*  31: 23 */     this(size, ArrayType.getArrayType(type).getJavaTypeInstance());
/*  32:    */   }
/*  33:    */   
/*  34:    */   public NewPrimitiveArray(Expression size, JavaTypeInstance type)
/*  35:    */   {
/*  36: 28 */     super(new InferredJavaType(new JavaArrayTypeInstance(1, type), InferredJavaType.Source.EXPRESSION));
/*  37: 29 */     this.size = size;
/*  38: 30 */     this.type = type;
/*  39: 31 */     size.getInferredJavaType().useAsWithoutCasting(RawJavaType.INT);
/*  40:    */   }
/*  41:    */   
/*  42:    */   private NewPrimitiveArray(InferredJavaType inferredJavaType, JavaTypeInstance type, Expression size)
/*  43:    */   {
/*  44: 35 */     super(inferredJavaType);
/*  45: 36 */     this.type = type;
/*  46: 37 */     this.size = size;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  50:    */   {
/*  51: 42 */     this.size.collectTypeUsages(collector);
/*  52: 43 */     collector.collect(this.type);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  56:    */   {
/*  57: 48 */     return new NewPrimitiveArray(getInferredJavaType(), this.type, cloneHelper.replaceOrClone(this.size));
/*  58:    */   }
/*  59:    */   
/*  60:    */   public Precedence getPrecedence()
/*  61:    */   {
/*  62: 53 */     return Precedence.PAREN_SUB_MEMBER;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public Dumper dumpInner(Dumper d)
/*  66:    */   {
/*  67: 58 */     return d.print("new " + this.type + "[").dump(this.size).print("]");
/*  68:    */   }
/*  69:    */   
/*  70:    */   public int getNumDims()
/*  71:    */   {
/*  72: 63 */     return 1;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public int getNumSizedDims()
/*  76:    */   {
/*  77: 68 */     return 1;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public Expression getDimSize(int dim)
/*  81:    */   {
/*  82: 73 */     if (dim > 0) {
/*  83: 73 */       throw new ConfusedCFRException("Only 1 dimension for primitive arrays!");
/*  84:    */     }
/*  85: 74 */     return this.size;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public JavaTypeInstance getInnerType()
/*  89:    */   {
/*  90: 79 */     return this.type;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  94:    */   {
/*  95: 84 */     this.size = this.size.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/*  96: 85 */     return this;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 100:    */   {
/* 101: 91 */     this.size = expressionRewriter.rewriteExpression(this.size, ssaIdentifiers, statementContainer, flags);
/* 102: 92 */     return this;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 106:    */   {
/* 107: 97 */     return applyExpressionRewriter(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/* 108:    */   }
/* 109:    */   
/* 110:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/* 111:    */   {
/* 112:102 */     this.size.collectUsedLValues(lValueUsageCollector);
/* 113:    */   }
/* 114:    */   
/* 115:    */   public boolean equals(Object o)
/* 116:    */   {
/* 117:107 */     if (o == this) {
/* 118:107 */       return true;
/* 119:    */     }
/* 120:108 */     if (o == null) {
/* 121:108 */       return false;
/* 122:    */     }
/* 123:109 */     if (!(o instanceof NewPrimitiveArray)) {
/* 124:109 */       return false;
/* 125:    */     }
/* 126:110 */     NewPrimitiveArray other = (NewPrimitiveArray)o;
/* 127:111 */     if (!this.size.equals(other.size)) {
/* 128:111 */       return false;
/* 129:    */     }
/* 130:112 */     if (!this.type.equals(other.type)) {
/* 131:112 */       return false;
/* 132:    */     }
/* 133:113 */     return true;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 137:    */   {
/* 138:118 */     if (o == null) {
/* 139:118 */       return false;
/* 140:    */     }
/* 141:119 */     if (o == this) {
/* 142:119 */       return true;
/* 143:    */     }
/* 144:120 */     if (getClass() != o.getClass()) {
/* 145:120 */       return false;
/* 146:    */     }
/* 147:121 */     NewPrimitiveArray other = (NewPrimitiveArray)o;
/* 148:122 */     if (!constraint.equivalent(this.size, other.size)) {
/* 149:122 */       return false;
/* 150:    */     }
/* 151:123 */     if (!constraint.equivalent(this.type, other.type)) {
/* 152:123 */       return false;
/* 153:    */     }
/* 154:124 */     return true;
/* 155:    */   }
/* 156:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.NewPrimitiveArray
 * JD-Core Version:    0.7.0.1
 */