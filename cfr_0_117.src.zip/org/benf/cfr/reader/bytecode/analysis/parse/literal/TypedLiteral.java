/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.literal;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.QuotingUtils;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericRefTypeInstance;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.types.TypeConstants;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  12:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  13:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/*  14:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass;
/*  15:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryDouble;
/*  16:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryFloat;
/*  17:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryInteger;
/*  18:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryLong;
/*  19:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodHandle;
/*  20:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodRef;
/*  21:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodType;
/*  22:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryString;
/*  23:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryUTF8;
/*  24:    */ import org.benf.cfr.reader.state.ClassCache;
/*  25:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  26:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  27:    */ import org.benf.cfr.reader.util.ListFactory;
/*  28:    */ import org.benf.cfr.reader.util.TypeUsageCollectable;
/*  29:    */ import org.benf.cfr.reader.util.output.Dumpable;
/*  30:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  31:    */ import org.benf.cfr.reader.util.output.ToStringDumper;
/*  32:    */ 
/*  33:    */ public class TypedLiteral
/*  34:    */   implements TypeUsageCollectable, Dumpable
/*  35:    */ {
/*  36:    */   private final InferredJavaType inferredJavaType;
/*  37:    */   private final LiteralType type;
/*  38:    */   private final Object value;
/*  39:    */   
/*  40:    */   public static enum LiteralType
/*  41:    */   {
/*  42: 19 */     Integer,  Long,  Double,  Float,  String,  NullObject,  Class,  MethodHandle,  MethodType;
/*  43:    */     
/*  44:    */     private LiteralType() {}
/*  45:    */   }
/*  46:    */   
/*  47:    */   protected TypedLiteral(LiteralType type, InferredJavaType inferredJavaType, Object value)
/*  48:    */   {
/*  49: 35 */     this.type = type;
/*  50: 36 */     this.value = value;
/*  51: 37 */     this.inferredJavaType = inferredJavaType;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  55:    */   {
/*  56: 42 */     if (this.type == LiteralType.Class) {
/*  57: 43 */       collector.collect((JavaTypeInstance)this.value);
/*  58:    */     }
/*  59:    */   }
/*  60:    */   
/*  61:    */   private static String integerName(Object o)
/*  62:    */   {
/*  63: 48 */     if (!(o instanceof Integer)) {
/*  64: 48 */       return o.toString();
/*  65:    */     }
/*  66: 49 */     int i = ((Integer)o).intValue();
/*  67: 50 */     switch (i)
/*  68:    */     {
/*  69:    */     case 2147483647: 
/*  70: 52 */       return "Integer.MAX_VALUE";
/*  71:    */     case -2147483648: 
/*  72: 54 */       return "Integer.MIN_VALUE";
/*  73:    */     }
/*  74: 56 */     return o.toString();
/*  75:    */   }
/*  76:    */   
/*  77:    */   private static String doubleName(Object o)
/*  78:    */   {
/*  79: 61 */     if (!(o instanceof Double)) {
/*  80: 61 */       return o.toString();
/*  81:    */     }
/*  82: 62 */     double d = ((Double)o).doubleValue();
/*  83: 63 */     boolean isNeg = d < 0.0D;
/*  84: 64 */     if (Double.isInfinite(d)) {
/*  85: 65 */       return isNeg ? "Double.NEGATIVE_INFINITY" : "Double.POSITIVE_INFINITY";
/*  86:    */     }
/*  87: 67 */     if (Double.compare(d, 1.7976931348623157E+308D) == 0) {
/*  88: 67 */       return "Double.MAX_VALUE";
/*  89:    */     }
/*  90: 68 */     if (Double.compare(d, 4.9E-324D) == 0) {
/*  91: 68 */       return "Double.MIN_VALUE";
/*  92:    */     }
/*  93: 69 */     if (Double.compare(d, 2.225073858507201E-308D) == 0) {
/*  94: 69 */       return "Double.MIN_NORMAL";
/*  95:    */     }
/*  96: 70 */     if (Double.isNaN(d)) {
/*  97: 71 */       return "Double.NaN";
/*  98:    */     }
/*  99: 73 */     return o.toString();
/* 100:    */   }
/* 101:    */   
/* 102:    */   private static String floatName(Object o)
/* 103:    */   {
/* 104: 77 */     if (!(o instanceof Float)) {
/* 105: 77 */       return o.toString() + "f";
/* 106:    */     }
/* 107: 78 */     float d = ((Float)o).floatValue();
/* 108: 79 */     boolean isNeg = d < 0.0F;
/* 109: 80 */     if (Float.isInfinite(d)) {
/* 110: 81 */       return isNeg ? "Float.NEGATIVE_INFINITY" : "Float.POSITIVE_INFINITY";
/* 111:    */     }
/* 112: 83 */     if (Float.compare(d, 3.4028235E+38F) == 0) {
/* 113: 83 */       return "Float.MAX_VALUE";
/* 114:    */     }
/* 115: 84 */     if (Float.compare(d, 1.4E-45F) == 0) {
/* 116: 84 */       return "Float.MIN_VALUE";
/* 117:    */     }
/* 118: 85 */     if (Float.compare(d, 1.175494E-038F) == 0) {
/* 119: 85 */       return "Float.MIN_NORMAL";
/* 120:    */     }
/* 121: 86 */     if (Float.isNaN(d)) {
/* 122: 87 */       return "Float.NaN";
/* 123:    */     }
/* 124: 89 */     return o.toString() + "f";
/* 125:    */   }
/* 126:    */   
/* 127:    */   public boolean getBoolValue()
/* 128:    */   {
/* 129: 93 */     if (this.type != LiteralType.Integer) {
/* 130: 93 */       throw new IllegalStateException("Expecting integral literal");
/* 131:    */     }
/* 132: 94 */     Integer i = (Integer)this.value;
/* 133: 95 */     return i.intValue() != 0;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public Boolean getMaybeBoolValue()
/* 137:    */   {
/* 138: 99 */     if (this.type != LiteralType.Integer) {
/* 139: 99 */       return null;
/* 140:    */     }
/* 141:100 */     Integer i = (Integer)this.value;
/* 142:101 */     return i.intValue() == 0 ? Boolean.FALSE : Boolean.TRUE;
/* 143:    */   }
/* 144:    */   
/* 145:    */   private static String charName(Object o)
/* 146:    */   {
/* 147:106 */     if (!(o instanceof Integer)) {
/* 148:106 */       throw new ConfusedCFRException("Expecting char-as-int");
/* 149:    */     }
/* 150:107 */     int i = ((Integer)o).intValue();
/* 151:108 */     char c = (char)i;
/* 152:109 */     switch (c)
/* 153:    */     {
/* 154:    */     case '"': 
/* 155:111 */       return "'\\\"'";
/* 156:    */     case '\r': 
/* 157:113 */       return "'\\r'";
/* 158:    */     case '\n': 
/* 159:115 */       return "'\\n'";
/* 160:    */     case '\t': 
/* 161:117 */       return "'\\t'";
/* 162:    */     case '\b': 
/* 163:119 */       return "'\\b'";
/* 164:    */     case '\f': 
/* 165:121 */       return "'\\f'";
/* 166:    */     case '\\': 
/* 167:123 */       return "'\\\\'";
/* 168:    */     case '\'': 
/* 169:125 */       return "'\\''";
/* 170:    */     }
/* 171:127 */     if ((i < 32) || (i >= 254)) {
/* 172:130 */       return "'\\u" + String.format("%04x", new Object[] { Integer.valueOf(i) }) + "'";
/* 173:    */     }
/* 174:132 */     return "'" + c + "'";
/* 175:    */   }
/* 176:    */   
/* 177:    */   private static String boolName(Object o)
/* 178:    */   {
/* 179:138 */     if (!(o instanceof Integer)) {
/* 180:138 */       throw new ConfusedCFRException("Expecting boolean-as-int");
/* 181:    */     }
/* 182:139 */     int i = ((Integer)o).intValue();
/* 183:140 */     switch (i)
/* 184:    */     {
/* 185:    */     case 0: 
/* 186:142 */       return "false";
/* 187:    */     case 1: 
/* 188:144 */       return "true";
/* 189:    */     }
/* 190:146 */     return "BADBOOL " + i;
/* 191:    */   }
/* 192:    */   
/* 193:    */   private static String longName(Object o)
/* 194:    */   {
/* 195:152 */     if (!(o instanceof Long)) {
/* 196:152 */       return o.toString();
/* 197:    */     }
/* 198:153 */     long l = ((Long)o).longValue();
/* 199:154 */     if (l == 9223372036854775807L) {
/* 200:154 */       return "Long.MAX_VALUE";
/* 201:    */     }
/* 202:155 */     if (l == -9223372036854775808L) {
/* 203:155 */       return "Long.MIN_VALUE";
/* 204:    */     }
/* 205:156 */     if (l == 2147483647L) {
/* 206:156 */       return "Integer.MAX_VALUE";
/* 207:    */     }
/* 208:157 */     if (l == -2147483648L) {
/* 209:157 */       return "Integer.MIN_VALUE";
/* 210:    */     }
/* 211:158 */     String longString = o.toString();
/* 212:159 */     if (l > 1048575L)
/* 213:    */     {
/* 214:160 */       String hexTest = Long.toHexString(l).toUpperCase();
/* 215:161 */       byte[] bytes = hexTest.getBytes();
/* 216:162 */       byte[] count = new byte[16];
/* 217:163 */       int diff = 0;
/* 218:164 */       int i = 0;
/* 219:164 */       for (int len = bytes.length; i < len; i++)
/* 220:    */       {
/* 221:165 */         byte b = bytes[i];
/* 222:166 */         if ((b >= 48) && (b <= 57))
/* 223:    */         {
/* 224:167 */           int tmp148_147 = (bytes[i] - 48);count;
/* 225:167 */           if ((tmp148_138[tmp148_147] = (byte)(tmp148_138[tmp148_147] + 1)) == 1) {
/* 226:167 */             diff++;
/* 227:    */           }
/* 228:    */         }
/* 229:168 */         else if ((tmp148_147 >= 65) && (tmp148_147 <= 70))
/* 230:    */         {
/* 231:169 */           int tmp192_191 = (bytes[i] - 65 + 10);count;
/* 232:169 */           if ((tmp192_179[tmp192_191] = (byte)(tmp192_179[tmp192_191] + 1)) == 1) {
/* 233:169 */             diff++;
/* 234:    */           }
/* 235:    */         }
/* 236:    */         else
/* 237:    */         {
/* 238:171 */           diff = 10;
/* 239:172 */           break;
/* 240:    */         }
/* 241:    */       }
/* 242:175 */       if (diff <= 2) {
/* 243:175 */         longString = "0x" + hexTest;
/* 244:    */       }
/* 245:    */     }
/* 246:178 */     if ((l > 2147483647L) || (l < -2147483648L)) {
/* 247:179 */       return longString + "L";
/* 248:    */     }
/* 249:181 */     return longString;
/* 250:    */   }
/* 251:    */   
/* 252:    */   private static String methodHandleName(Object o)
/* 253:    */   {
/* 254:186 */     ConstantPoolEntryMethodHandle methodHandle = (ConstantPoolEntryMethodHandle)o;
/* 255:187 */     ConstantPoolEntryMethodRef methodRef = methodHandle.getMethodRef();
/* 256:188 */     return methodRef.getMethodPrototype().toString();
/* 257:    */   }
/* 258:    */   
/* 259:    */   private static String methodTypeName(Object o)
/* 260:    */   {
/* 261:192 */     ConstantPoolEntryMethodType methodType = (ConstantPoolEntryMethodType)o;
/* 262:193 */     return methodType.getDescriptor().getValue();
/* 263:    */   }
/* 264:    */   
/* 265:    */   public Dumper dump(Dumper d)
/* 266:    */   {
/* 267:198 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$literal$TypedLiteral$LiteralType[this.type.ordinal()])
/* 268:    */     {
/* 269:    */     case 1: 
/* 270:200 */       return d.print((String)this.value);
/* 271:    */     case 2: 
/* 272:202 */       return d.print("null");
/* 273:    */     case 3: 
/* 274:204 */       switch (this.inferredJavaType.getRawType())
/* 275:    */       {
/* 276:    */       case CHAR: 
/* 277:206 */         return d.print(charName(this.value));
/* 278:    */       case BOOLEAN: 
/* 279:208 */         return d.print(boolName(this.value));
/* 280:    */       }
/* 281:210 */       return d.print(integerName(this.value));
/* 282:    */     case 4: 
/* 283:213 */       return d.print(longName(this.value));
/* 284:    */     case 5: 
/* 285:215 */       return d.print(methodTypeName(this.value));
/* 286:    */     case 6: 
/* 287:217 */       return d.print(methodHandleName(this.value));
/* 288:    */     case 7: 
/* 289:219 */       return d.dump((JavaTypeInstance)this.value).print(".class");
/* 290:    */     case 8: 
/* 291:221 */       return d.print(doubleName(this.value));
/* 292:    */     case 9: 
/* 293:223 */       return d.print(floatName(this.value));
/* 294:    */     }
/* 295:225 */     return d.print(this.value.toString());
/* 296:    */   }
/* 297:    */   
/* 298:    */   public String toString()
/* 299:    */   {
/* 300:231 */     return ToStringDumper.toString(this);
/* 301:    */   }
/* 302:    */   
/* 303:    */   public static TypedLiteral getLong(long v)
/* 304:    */   {
/* 305:235 */     return new TypedLiteral(LiteralType.Long, new InferredJavaType(RawJavaType.LONG, InferredJavaType.Source.LITERAL), Long.valueOf(v));
/* 306:    */   }
/* 307:    */   
/* 308:    */   public static TypedLiteral getInt(int v)
/* 309:    */   {
/* 310:239 */     return new TypedLiteral(LiteralType.Integer, new InferredJavaType(RawJavaType.INT, InferredJavaType.Source.LITERAL), Integer.valueOf(v));
/* 311:    */   }
/* 312:    */   
/* 313:    */   public static TypedLiteral getChar(int v)
/* 314:    */   {
/* 315:243 */     return new TypedLiteral(LiteralType.Integer, new InferredJavaType(RawJavaType.CHAR, InferredJavaType.Source.LITERAL), Integer.valueOf(v));
/* 316:    */   }
/* 317:    */   
/* 318:    */   public static TypedLiteral getBoolean(int v)
/* 319:    */   {
/* 320:250 */     return new TypedLiteral(LiteralType.Integer, new InferredJavaType(RawJavaType.BOOLEAN, InferredJavaType.Source.LITERAL), Integer.valueOf(v));
/* 321:    */   }
/* 322:    */   
/* 323:    */   public static TypedLiteral getDouble(double v)
/* 324:    */   {
/* 325:254 */     return new TypedLiteral(LiteralType.Double, new InferredJavaType(RawJavaType.DOUBLE, InferredJavaType.Source.LITERAL), Double.valueOf(v));
/* 326:    */   }
/* 327:    */   
/* 328:    */   public static TypedLiteral getFloat(float v)
/* 329:    */   {
/* 330:258 */     return new TypedLiteral(LiteralType.Float, new InferredJavaType(RawJavaType.FLOAT, InferredJavaType.Source.LITERAL), Float.valueOf(v));
/* 331:    */   }
/* 332:    */   
/* 333:    */   public static TypedLiteral getClass(JavaTypeInstance v)
/* 334:    */   {
/* 335:262 */     JavaTypeInstance tgt = new JavaGenericRefTypeInstance(TypeConstants.CLASS, ListFactory.newList(new JavaTypeInstance[] { v }));
/* 336:263 */     return new TypedLiteral(LiteralType.Class, new InferredJavaType(tgt, InferredJavaType.Source.LITERAL), v);
/* 337:    */   }
/* 338:    */   
/* 339:    */   public static TypedLiteral getString(String v)
/* 340:    */   {
/* 341:267 */     return new TypedLiteral(LiteralType.String, new InferredJavaType(TypeConstants.STRING, InferredJavaType.Source.LITERAL), v);
/* 342:    */   }
/* 343:    */   
/* 344:    */   public static TypedLiteral getNull()
/* 345:    */   {
/* 346:271 */     return new TypedLiteral(LiteralType.NullObject, new InferredJavaType(RawJavaType.NULL, InferredJavaType.Source.LITERAL), null);
/* 347:    */   }
/* 348:    */   
/* 349:    */   public static TypedLiteral getMethodHandle(ConstantPoolEntryMethodHandle methodHandle, ConstantPool cp)
/* 350:    */   {
/* 351:275 */     JavaTypeInstance typeInstance = cp.getClassCache().getRefClassFor("java.lang.invoke.MethodHandle");
/* 352:276 */     return new TypedLiteral(LiteralType.MethodHandle, new InferredJavaType(typeInstance, InferredJavaType.Source.LITERAL), methodHandle);
/* 353:    */   }
/* 354:    */   
/* 355:    */   public static TypedLiteral getMethodType(ConstantPoolEntryMethodType methodType, ConstantPool cp)
/* 356:    */   {
/* 357:281 */     JavaTypeInstance typeInstance = cp.getClassCache().getRefClassFor("java.lang.invoke.MethodType");
/* 358:282 */     return new TypedLiteral(LiteralType.MethodType, new InferredJavaType(typeInstance, InferredJavaType.Source.LITERAL), methodType);
/* 359:    */   }
/* 360:    */   
/* 361:    */   public static TypedLiteral getConstantPoolEntryUTF8(ConstantPoolEntryUTF8 cpe)
/* 362:    */   {
/* 363:286 */     return getString(QuotingUtils.enquoteString(cpe.getValue()));
/* 364:    */   }
/* 365:    */   
/* 366:    */   public static TypedLiteral getConstantPoolEntry(ConstantPool cp, ConstantPoolEntry cpe)
/* 367:    */   {
/* 368:290 */     if ((cpe instanceof ConstantPoolEntryDouble)) {
/* 369:291 */       return getDouble(((ConstantPoolEntryDouble)cpe).getValue());
/* 370:    */     }
/* 371:292 */     if ((cpe instanceof ConstantPoolEntryFloat)) {
/* 372:293 */       return getFloat(((ConstantPoolEntryFloat)cpe).getValue());
/* 373:    */     }
/* 374:294 */     if ((cpe instanceof ConstantPoolEntryLong)) {
/* 375:295 */       return getLong(((ConstantPoolEntryLong)cpe).getValue());
/* 376:    */     }
/* 377:296 */     if ((cpe instanceof ConstantPoolEntryInteger)) {
/* 378:297 */       return getInt(((ConstantPoolEntryInteger)cpe).getValue());
/* 379:    */     }
/* 380:298 */     if ((cpe instanceof ConstantPoolEntryString)) {
/* 381:299 */       return getString(((ConstantPoolEntryString)cpe).getValue());
/* 382:    */     }
/* 383:300 */     if ((cpe instanceof ConstantPoolEntryClass)) {
/* 384:301 */       return getClass(((ConstantPoolEntryClass)cpe).getTypeInstance());
/* 385:    */     }
/* 386:302 */     if ((cpe instanceof ConstantPoolEntryMethodHandle)) {
/* 387:303 */       return getMethodHandle((ConstantPoolEntryMethodHandle)cpe, cp);
/* 388:    */     }
/* 389:304 */     if ((cpe instanceof ConstantPoolEntryMethodType)) {
/* 390:305 */       return getMethodType((ConstantPoolEntryMethodType)cpe, cp);
/* 391:    */     }
/* 392:307 */     throw new ConfusedCFRException("Can't turn ConstantPoolEntry into Literal - got " + cpe);
/* 393:    */   }
/* 394:    */   
/* 395:    */   public static TypedLiteral shrinkTo(TypedLiteral original, RawJavaType tgt)
/* 396:    */   {
/* 397:311 */     if (original.getType() != LiteralType.Integer) {
/* 398:311 */       return original;
/* 399:    */     }
/* 400:312 */     if (tgt.getStackType() != StackType.INT) {
/* 401:312 */       return original;
/* 402:    */     }
/* 403:313 */     Integer i = (Integer)original.value;
/* 404:314 */     if (i == null) {
/* 405:314 */       return original;
/* 406:    */     }
/* 407:315 */     switch (tgt)
/* 408:    */     {
/* 409:    */     case BOOLEAN: 
/* 410:317 */       return getBoolean(i.intValue());
/* 411:    */     case CHAR: 
/* 412:319 */       return getChar(i.intValue());
/* 413:    */     }
/* 414:321 */     return original;
/* 415:    */   }
/* 416:    */   
/* 417:    */   public LiteralType getType()
/* 418:    */   {
/* 419:325 */     return this.type;
/* 420:    */   }
/* 421:    */   
/* 422:    */   public Object getValue()
/* 423:    */   {
/* 424:329 */     return this.value;
/* 425:    */   }
/* 426:    */   
/* 427:    */   public InferredJavaType getInferredJavaType()
/* 428:    */   {
/* 429:333 */     return this.inferredJavaType;
/* 430:    */   }
/* 431:    */   
/* 432:    */   public boolean equals(Object o)
/* 433:    */   {
/* 434:338 */     if (o == this) {
/* 435:338 */       return true;
/* 436:    */     }
/* 437:339 */     if (!(o instanceof TypedLiteral)) {
/* 438:339 */       return false;
/* 439:    */     }
/* 440:340 */     TypedLiteral other = (TypedLiteral)o;
/* 441:341 */     return (this.type == other.type) && (this.value == null ? other.value == null : this.value.equals(other.value));
/* 442:    */   }
/* 443:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral
 * JD-Core Version:    0.7.0.1
 */