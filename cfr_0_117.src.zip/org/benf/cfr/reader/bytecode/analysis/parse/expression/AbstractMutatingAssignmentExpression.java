/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  5:   */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/*  6:   */ 
/*  7:   */ public abstract class AbstractMutatingAssignmentExpression
/*  8:   */   extends AbstractAssignmentExpression
/*  9:   */ {
/* 10:   */   public AbstractMutatingAssignmentExpression(InferredJavaType inferredJavaType)
/* 11:   */   {
/* 12:10 */     super(inferredJavaType);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public boolean canThrow(ExceptionCheck caught)
/* 16:   */   {
/* 17:15 */     return !(getInferredJavaType().getJavaTypeInstance() instanceof RawJavaType);
/* 18:   */   }
/* 19:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractMutatingAssignmentExpression
 * JD-Core Version:    0.7.0.1
 */