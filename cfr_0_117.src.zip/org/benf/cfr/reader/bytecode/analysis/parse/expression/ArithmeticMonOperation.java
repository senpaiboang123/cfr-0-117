/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 13:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 14:   */ import org.benf.cfr.reader.util.Troolean;
/* 15:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 16:   */ 
/* 17:   */ public class ArithmeticMonOperation
/* 18:   */   extends AbstractExpression
/* 19:   */ {
/* 20:   */   private Expression lhs;
/* 21:   */   private final ArithOp op;
/* 22:   */   
/* 23:   */   public ArithmeticMonOperation(Expression lhs, ArithOp op)
/* 24:   */   {
/* 25:20 */     super(lhs.getInferredJavaType());
/* 26:21 */     this.lhs = lhs;
/* 27:22 */     this.op = op;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 31:   */   {
/* 32:27 */     this.lhs.collectTypeUsages(collector);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public Expression deepClone(CloneHelper cloneHelper)
/* 36:   */   {
/* 37:32 */     return new ArithmeticMonOperation(cloneHelper.replaceOrClone(this.lhs), this.op);
/* 38:   */   }
/* 39:   */   
/* 40:   */   public Precedence getPrecedence()
/* 41:   */   {
/* 42:37 */     return this.op.getPrecedence();
/* 43:   */   }
/* 44:   */   
/* 45:   */   public Dumper dumpInner(Dumper d)
/* 46:   */   {
/* 47:42 */     d.print(this.op.getShowAs() + " ");
/* 48:43 */     this.lhs.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.NEITHER);
/* 49:44 */     return d;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/* 53:   */   {
/* 54:49 */     this.lhs = this.lhs.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/* 55:50 */     return this;
/* 56:   */   }
/* 57:   */   
/* 58:   */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 59:   */   {
/* 60:55 */     this.lhs = expressionRewriter.rewriteExpression(this.lhs, ssaIdentifiers, statementContainer, flags);
/* 61:56 */     return this;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 65:   */   {
/* 66:61 */     return applyExpressionRewriter(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/* 67:   */   }
/* 68:   */   
/* 69:   */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/* 70:   */   {
/* 71:66 */     this.lhs.collectUsedLValues(lValueUsageCollector);
/* 72:   */   }
/* 73:   */   
/* 74:   */   public boolean equals(Object o)
/* 75:   */   {
/* 76:71 */     if (this == o) {
/* 77:71 */       return true;
/* 78:   */     }
/* 79:72 */     if ((o == null) || (getClass() != o.getClass())) {
/* 80:72 */       return false;
/* 81:   */     }
/* 82:74 */     ArithmeticMonOperation that = (ArithmeticMonOperation)o;
/* 83:76 */     if (this.lhs != null ? !this.lhs.equals(that.lhs) : that.lhs != null) {
/* 84:76 */       return false;
/* 85:   */     }
/* 86:77 */     if (this.op != that.op) {
/* 87:77 */       return false;
/* 88:   */     }
/* 89:79 */     return true;
/* 90:   */   }
/* 91:   */   
/* 92:   */   public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 93:   */   {
/* 94:84 */     if (this == o) {
/* 95:84 */       return true;
/* 96:   */     }
/* 97:85 */     if ((o == null) || (getClass() != o.getClass())) {
/* 98:85 */       return false;
/* 99:   */     }
/* :0:87 */     ArithmeticMonOperation other = (ArithmeticMonOperation)o;
/* :1:88 */     if (!constraint.equivalent(this.lhs, other.lhs)) {
/* :2:88 */       return false;
/* :3:   */     }
/* :4:89 */     if (!constraint.equivalent(this.op, other.op)) {
/* :5:89 */       return false;
/* :6:   */     }
/* :7:90 */     return true;
/* :8:   */   }
/* :9:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithmeticMonOperation
 * JD-Core Version:    0.7.0.1
 */