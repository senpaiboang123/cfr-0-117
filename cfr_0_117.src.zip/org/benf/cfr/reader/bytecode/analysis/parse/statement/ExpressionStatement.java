/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredExpressionStatement;
/* 12:   */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/* 13:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 14:   */ 
/* 15:   */ public class ExpressionStatement
/* 16:   */   extends AbstractStatement
/* 17:   */ {
/* 18:   */   private Expression expression;
/* 19:   */   
/* 20:   */   public ExpressionStatement(Expression expression)
/* 21:   */   {
/* 22:16 */     this.expression = expression;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public Dumper dump(Dumper d)
/* 26:   */   {
/* 27:21 */     return this.expression.dump(d).endCodeln();
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers)
/* 31:   */   {
/* 32:26 */     this.expression = this.expression.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer());
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/* 36:   */   {
/* 37:31 */     this.expression = expressionRewriter.rewriteExpression(this.expression, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE);
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/* 41:   */   {
/* 42:36 */     this.expression.collectUsedLValues(lValueUsageCollector);
/* 43:   */   }
/* 44:   */   
/* 45:   */   public Expression getExpression()
/* 46:   */   {
/* 47:40 */     return this.expression;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public StructuredStatement getStructuredStatement()
/* 51:   */   {
/* 52:45 */     return new StructuredExpressionStatement(this.expression, false);
/* 53:   */   }
/* 54:   */   
/* 55:   */   public boolean equals(Object o)
/* 56:   */   {
/* 57:50 */     if (o == null) {
/* 58:50 */       return false;
/* 59:   */     }
/* 60:51 */     if (o == this) {
/* 61:51 */       return true;
/* 62:   */     }
/* 63:52 */     if (!(o instanceof ExpressionStatement)) {
/* 64:52 */       return false;
/* 65:   */     }
/* 66:53 */     ExpressionStatement other = (ExpressionStatement)o;
/* 67:54 */     return this.expression.equals(other.expression);
/* 68:   */   }
/* 69:   */   
/* 70:   */   public boolean canThrow(ExceptionCheck caught)
/* 71:   */   {
/* 72:59 */     return this.expression.canThrow(caught);
/* 73:   */   }
/* 74:   */   
/* 75:   */   public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 76:   */   {
/* 77:64 */     if (o == null) {
/* 78:64 */       return false;
/* 79:   */     }
/* 80:65 */     if (o == this) {
/* 81:65 */       return true;
/* 82:   */     }
/* 83:66 */     if (!(o instanceof ExpressionStatement)) {
/* 84:66 */       return false;
/* 85:   */     }
/* 86:67 */     ExpressionStatement other = (ExpressionStatement)o;
/* 87:68 */     return constraint.equivalent(this.expression, other.expression);
/* 88:   */   }
/* 89:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.ExpressionStatement
 * JD-Core Version:    0.7.0.1
 */