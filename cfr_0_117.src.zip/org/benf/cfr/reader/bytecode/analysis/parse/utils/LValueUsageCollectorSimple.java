/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.utils;
/*  2:   */ 
/*  3:   */ import java.util.Collection;
/*  4:   */ import java.util.Set;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  6:   */ import org.benf.cfr.reader.util.SetFactory;
/*  7:   */ 
/*  8:   */ public class LValueUsageCollectorSimple
/*  9:   */   implements LValueUsageCollector
/* 10:   */ {
/* 11:10 */   private final Set<LValue> used = SetFactory.newSet();
/* 12:   */   
/* 13:   */   public void collect(LValue lValue)
/* 14:   */   {
/* 15:14 */     this.used.add(lValue);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public Collection<LValue> getUsedLValues()
/* 19:   */   {
/* 20:18 */     return this.used;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public boolean isUsed(LValue lValue)
/* 24:   */   {
/* 25:22 */     return this.used.contains(lValue);
/* 26:   */   }
/* 27:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollectorSimple
 * JD-Core Version:    0.7.0.1
 */