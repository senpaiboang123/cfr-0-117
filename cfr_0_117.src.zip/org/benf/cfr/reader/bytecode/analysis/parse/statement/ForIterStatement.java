/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 14:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 15:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredIter;
/* 16:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 17:   */ 
/* 18:   */ public class ForIterStatement
/* 19:   */   extends AbstractStatement
/* 20:   */ {
/* 21:   */   private BlockIdentifier blockIdentifier;
/* 22:   */   private LValue iterator;
/* 23:   */   private Expression list;
/* 24:   */   
/* 25:   */   public ForIterStatement(BlockIdentifier blockIdentifier, LValue iterator, Expression list)
/* 26:   */   {
/* 27:18 */     this.blockIdentifier = blockIdentifier;
/* 28:19 */     this.iterator = iterator;
/* 29:20 */     this.list = list;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public LValue getCreatedLValue()
/* 33:   */   {
/* 34:25 */     return this.iterator;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public Expression getList()
/* 38:   */   {
/* 39:29 */     return this.list;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public Dumper dump(Dumper dumper)
/* 43:   */   {
/* 44:34 */     dumper.print("for (");
/* 45:35 */     if (this.iterator.isFinal()) {
/* 46:35 */       dumper.print("final ");
/* 47:   */     }
/* 48:36 */     dumper.dump(this.iterator).print(" : ").dump(this.list).print(")");
/* 49:37 */     dumper.print(" // ends " + getTargetStatement(1).getContainer().getLabel() + ";\n");
/* 50:38 */     return dumper;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers)
/* 54:   */   {
/* 55:43 */     this.iterator.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer());
/* 56:   */   }
/* 57:   */   
/* 58:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/* 59:   */   {
/* 60:48 */     this.iterator = expressionRewriter.rewriteExpression(this.iterator, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE);
/* 61:49 */     this.list = expressionRewriter.rewriteExpression(this.list, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE);
/* 62:   */   }
/* 63:   */   
/* 64:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/* 65:   */   {
/* 66:54 */     this.list.collectUsedLValues(lValueUsageCollector);
/* 67:   */   }
/* 68:   */   
/* 69:   */   public StructuredStatement getStructuredStatement()
/* 70:   */   {
/* 71:59 */     return new UnstructuredIter(this.blockIdentifier, this.iterator, this.list);
/* 72:   */   }
/* 73:   */   
/* 74:   */   public BlockIdentifier getBlockIdentifier()
/* 75:   */   {
/* 76:63 */     return this.blockIdentifier;
/* 77:   */   }
/* 78:   */   
/* 79:   */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 80:   */   {
/* 81:68 */     if (o == null) {
/* 82:68 */       return false;
/* 83:   */     }
/* 84:69 */     if (o == this) {
/* 85:69 */       return true;
/* 86:   */     }
/* 87:70 */     if (getClass() != o.getClass()) {
/* 88:70 */       return false;
/* 89:   */     }
/* 90:71 */     ForIterStatement other = (ForIterStatement)o;
/* 91:72 */     if (!constraint.equivalent(this.iterator, other.iterator)) {
/* 92:72 */       return false;
/* 93:   */     }
/* 94:73 */     if (!constraint.equivalent(this.list, other.list)) {
/* 95:73 */       return false;
/* 96:   */     }
/* 97:74 */     return true;
/* 98:   */   }
/* 99:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.ForIterStatement
 * JD-Core Version:    0.7.0.1
 */