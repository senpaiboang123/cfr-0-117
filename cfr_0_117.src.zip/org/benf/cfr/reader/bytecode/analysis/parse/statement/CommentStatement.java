/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredComment;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  22:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  23:    */ 
/*  24:    */ public class CommentStatement
/*  25:    */   extends AbstractStatement
/*  26:    */ {
/*  27:    */   private final Expression text;
/*  28:    */   
/*  29:    */   public CommentStatement(String text)
/*  30:    */   {
/*  31: 27 */     this.text = new Literal(TypedLiteral.getString(text));
/*  32:    */   }
/*  33:    */   
/*  34:    */   public CommentStatement(Expression expression)
/*  35:    */   {
/*  36: 31 */     this.text = expression;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public CommentStatement(Statement statement)
/*  40:    */   {
/*  41: 35 */     this.text = new StatementExpression(statement, null);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public Dumper dump(Dumper dumper)
/*  45:    */   {
/*  46: 40 */     return dumper.dump(this.text);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers)
/*  50:    */   {
/*  51: 45 */     this.text.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer());
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/*  55:    */   {
/*  56: 50 */     this.text.applyExpressionRewriter(expressionRewriter, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/*  60:    */   {
/*  61: 55 */     this.text.collectUsedLValues(lValueUsageCollector);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public StructuredStatement getStructuredStatement()
/*  65:    */   {
/*  66: 60 */     return new StructuredComment(this.text);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public boolean equals(Object o)
/*  70:    */   {
/*  71: 65 */     if (this == o) {
/*  72: 65 */       return true;
/*  73:    */     }
/*  74: 66 */     if ((o == null) || (getClass() != o.getClass())) {
/*  75: 66 */       return false;
/*  76:    */     }
/*  77: 68 */     return true;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/*  81:    */   {
/*  82: 73 */     if (this == o) {
/*  83: 73 */       return true;
/*  84:    */     }
/*  85: 74 */     if ((o == null) || (getClass() != o.getClass())) {
/*  86: 74 */       return false;
/*  87:    */     }
/*  88: 75 */     return true;
/*  89:    */   }
/*  90:    */   
/*  91:    */   private static class StatementExpression
/*  92:    */     extends AbstractExpression
/*  93:    */   {
/*  94:    */     private Statement statement;
/*  95: 84 */     private static InferredJavaType javaType = new InferredJavaType(RawJavaType.VOID, InferredJavaType.Source.EXPRESSION);
/*  96:    */     
/*  97:    */     private StatementExpression(Statement statement)
/*  98:    */     {
/*  99: 87 */       super();
/* 100: 88 */       this.statement = statement;
/* 101:    */     }
/* 102:    */     
/* 103:    */     public boolean equals(Object o)
/* 104:    */     {
/* 105: 93 */       return false;
/* 106:    */     }
/* 107:    */     
/* 108:    */     public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/* 109:    */     {
/* 110: 98 */       this.statement.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers);
/* 111: 99 */       return this;
/* 112:    */     }
/* 113:    */     
/* 114:    */     public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 115:    */     {
/* 116:104 */       this.statement.rewriteExpressions(expressionRewriter, ssaIdentifiers);
/* 117:105 */       return this;
/* 118:    */     }
/* 119:    */     
/* 120:    */     public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 121:    */     {
/* 122:110 */       return applyExpressionRewriter(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/* 123:    */     }
/* 124:    */     
/* 125:    */     public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/* 126:    */     {
/* 127:115 */       this.statement.collectLValueUsage(lValueUsageCollector);
/* 128:    */     }
/* 129:    */     
/* 130:    */     public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 131:    */     {
/* 132:120 */       return false;
/* 133:    */     }
/* 134:    */     
/* 135:    */     public Expression deepClone(CloneHelper cloneHelper)
/* 136:    */     {
/* 137:125 */       return this;
/* 138:    */     }
/* 139:    */     
/* 140:    */     public Precedence getPrecedence()
/* 141:    */     {
/* 142:130 */       return Precedence.WEAKEST;
/* 143:    */     }
/* 144:    */     
/* 145:    */     public Dumper dumpInner(Dumper d)
/* 146:    */     {
/* 147:135 */       return d.dump(this.statement);
/* 148:    */     }
/* 149:    */   }
/* 150:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.CommentStatement
 * JD-Core Version:    0.7.0.1
 */