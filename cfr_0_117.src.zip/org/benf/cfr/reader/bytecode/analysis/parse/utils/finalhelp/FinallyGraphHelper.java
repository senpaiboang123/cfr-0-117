/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.utils.finalhelp;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.IdentityHashMap;
/*   5:    */ import java.util.LinkedList;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Map;
/*   8:    */ import java.util.Set;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.Nop;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.DefaultEquivalenceConstraint;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentCollector;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  23:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionTableEntry;
/*  24:    */ import org.benf.cfr.reader.util.ListFactory;
/*  25:    */ import org.benf.cfr.reader.util.MapFactory;
/*  26:    */ import org.benf.cfr.reader.util.SetFactory;
/*  27:    */ 
/*  28:    */ public class FinallyGraphHelper
/*  29:    */ {
/*  30:    */   private final FinallyCatchBody finallyCatchBody;
/*  31:    */   
/*  32:    */   public FinallyGraphHelper(FinallyCatchBody finallyCatchBody)
/*  33:    */   {
/*  34: 27 */     this.finallyCatchBody = finallyCatchBody;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public FinallyCatchBody getFinallyCatchBody()
/*  38:    */   {
/*  39: 31 */     return this.finallyCatchBody;
/*  40:    */   }
/*  41:    */   
/*  42:    */   private List<Op03SimpleStatement> filterFalseNegatives(List<Op03SimpleStatement> in, Set<Op03SimpleStatement> toRemove)
/*  43:    */   {
/*  44: 35 */     List<Op03SimpleStatement> res = ListFactory.newList();
/*  45: 36 */     for (Op03SimpleStatement i : in)
/*  46:    */     {
/*  47: 37 */       while ((i != null) && ((i.getStatement() instanceof Nop))) {
/*  48: 38 */         switch (i.getTargets().size())
/*  49:    */         {
/*  50:    */         case 0: 
/*  51: 40 */           i = null;
/*  52: 41 */           break;
/*  53:    */         case 1: 
/*  54: 43 */           if (toRemove != null) {
/*  55: 43 */             toRemove.add(i);
/*  56:    */           }
/*  57: 44 */           i = (Op03SimpleStatement)i.getTargets().get(0);
/*  58: 45 */           break;
/*  59:    */         default: 
/*  60: 47 */           throw new IllegalStateException();
/*  61:    */         }
/*  62:    */       }
/*  63: 50 */       if (i != null) {
/*  64: 50 */         res.add(i);
/*  65:    */       }
/*  66:    */     }
/*  67: 52 */     return res;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public Result match(Op03SimpleStatement test)
/*  71:    */   {
/*  72: 56 */     Set<BlockIdentifier> minBlockSet = SetFactory.newOrderedSet(test.getBlockIdentifiers());
/*  73: 57 */     Op03SimpleStatement finalThrowProxy = null;
/*  74: 58 */     Op03SimpleStatement finalThrow = this.finallyCatchBody.getThrowOp();
/*  75: 59 */     Map<Op03SimpleStatement, Op03SimpleStatement> matched = new IdentityHashMap();
/*  76: 60 */     Set<Op03SimpleStatement> toRemove = SetFactory.newOrderedSet();
/*  77: 61 */     LinkedList<Pair<Op03SimpleStatement, Op03SimpleStatement>> pending = ListFactory.newLinkedList();
/*  78: 62 */     if (this.finallyCatchBody.isEmpty()) {
/*  79: 63 */       return new Result(toRemove, null, null);
/*  80:    */     }
/*  81: 65 */     Pair<Op03SimpleStatement, Op03SimpleStatement> start = Pair.make(test, this.finallyCatchBody.getCatchCodeStart());
/*  82: 66 */     pending.add(start);
/*  83: 67 */     matched.put(start.getSecond(), start.getFirst());
/*  84:    */     
/*  85: 69 */     FinallyEquivalenceConstraint equivalenceConstraint = new FinallyEquivalenceConstraint(null);
/*  86:    */     
/*  87: 71 */     Set<Op03SimpleStatement> finalThrowProxySources = SetFactory.newOrderedSet();
/*  88: 72 */     while (!pending.isEmpty())
/*  89:    */     {
/*  90: 73 */       Pair<Op03SimpleStatement, Op03SimpleStatement> p = (Pair)pending.removeFirst();
/*  91: 74 */       Op03SimpleStatement a = (Op03SimpleStatement)p.getFirst();
/*  92: 75 */       Op03SimpleStatement b = (Op03SimpleStatement)p.getSecond();
/*  93: 76 */       Statement sa = a.getStatement();
/*  94: 77 */       Statement sb = b.getStatement();
/*  95:    */       
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100: 83 */       sa.collectLValueAssignments(equivalenceConstraint);
/* 101: 85 */       if (!sa.equivalentUnder(sb, equivalenceConstraint)) {
/* 102: 86 */         return Result.FAIL;
/* 103:    */       }
/* 104: 89 */       List<Op03SimpleStatement> tgta = ListFactory.newList(a.getTargets());
/* 105: 90 */       List<Op03SimpleStatement> tgtb = ListFactory.newList(b.getTargets());
/* 106:    */       
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110: 95 */       tgta = filterFalseNegatives(tgta, toRemove);
/* 111: 96 */       tgtb = filterFalseNegatives(tgtb, null);
/* 112: 98 */       if (tgta.size() != tgtb.size()) {
/* 113:101 */         if (tgta.size() != tgtb.size()) {
/* 114:102 */           return Result.FAIL;
/* 115:    */         }
/* 116:    */       }
/* 117:105 */       toRemove.add(a);
/* 118:    */       
/* 119:107 */       int x = 0;
/* 120:107 */       for (int len = tgta.size(); x < len; x++)
/* 121:    */       {
/* 122:108 */         Op03SimpleStatement tgttestx = (Op03SimpleStatement)tgta.get(x);
/* 123:109 */         Op03SimpleStatement tgthayx = (Op03SimpleStatement)tgtb.get(x);
/* 124:110 */         Op03SimpleStatement tgttestx2 = Misc.followNopGotoChain(tgttestx, false, false);
/* 125:111 */         Op03SimpleStatement tgthayx2 = Misc.followNopGotoChain(tgthayx, false, false);
/* 126:112 */         Op03SimpleStatement finalyThrowProxy2 = Misc.followNopGotoChain(finalThrowProxy, false, false);
/* 127:    */         
/* 128:    */ 
/* 129:    */ 
/* 130:116 */         Set<BlockIdentifier> newBlockIdentifiers = tgttestx.getBlockIdentifiers();
/* 131:117 */         if (newBlockIdentifiers.containsAll(minBlockSet))
/* 132:    */         {
/* 133:118 */           if (tgthayx2 == finalThrow)
/* 134:    */           {
/* 135:119 */             if ((finalThrowProxy != null) && (finalThrowProxy != tgttestx2) && (finalyThrowProxy2 != tgttestx2))
/* 136:    */             {
/* 137:124 */               Statement s1 = tgttestx.getStatement();
/* 138:125 */               Statement s2 = finalThrowProxy.getStatement();
/* 139:    */               int y;
/* 140:126 */               if ((s1.getClass() == GotoStatement.class) && (s1.equals(s2))) {
/* 141:128 */                 y = 1;
/* 142:    */               } else {
/* 143:130 */                 return Result.FAIL;
/* 144:    */               }
/* 145:    */             }
/* 146:133 */             if (finalThrowProxy == null) {
/* 147:134 */               finalThrowProxy = tgttestx;
/* 148:    */             }
/* 149:136 */             finalThrowProxySources.add(a);
/* 150:    */           }
/* 151:138 */           if ((!matched.containsKey(tgthayx)) && (this.finallyCatchBody.contains(tgthayx)))
/* 152:    */           {
/* 153:139 */             matched.put(tgthayx, tgttestx);
/* 154:140 */             pending.add(new Pair(tgttestx, tgthayx));
/* 155:    */           }
/* 156:    */         }
/* 157:    */       }
/* 158:    */     }
/* 159:146 */     return new Result(toRemove, test, Misc.followNopGotoChain(finalThrowProxy, false, false));
/* 160:    */   }
/* 161:    */   
/* 162:    */   private class FinallyEquivalenceConstraint
/* 163:    */     extends DefaultEquivalenceConstraint
/* 164:    */     implements LValueAssignmentCollector<Statement>
/* 165:    */   {
/* 166:154 */     private final Map<StackSSALabel, StackSSALabel> rhsToLhsMap = MapFactory.newMap();
/* 167:155 */     private final Map<LocalVariable, LocalVariable> rhsToLhsLVMap = MapFactory.newMap();
/* 168:156 */     private final Set<StackSSALabel> validSSA = SetFactory.newSet();
/* 169:157 */     private final Set<LocalVariable> validLocal = SetFactory.newSet();
/* 170:    */     
/* 171:    */     private FinallyEquivalenceConstraint() {}
/* 172:    */     
/* 173:    */     private StackSSALabel mapSSALabel(StackSSALabel s1, StackSSALabel s2)
/* 174:    */     {
/* 175:160 */       StackSSALabel r1 = (StackSSALabel)this.rhsToLhsMap.get(s2);
/* 176:161 */       if (r1 != null) {
/* 177:161 */         return r1;
/* 178:    */       }
/* 179:162 */       this.rhsToLhsMap.put(s2, s1);
/* 180:163 */       return s1;
/* 181:    */     }
/* 182:    */     
/* 183:    */     private LocalVariable mapLocalVariable(LocalVariable s1, LocalVariable s2)
/* 184:    */     {
/* 185:167 */       LocalVariable r1 = (LocalVariable)this.rhsToLhsLVMap.get(s2);
/* 186:168 */       if (r1 != null) {
/* 187:168 */         return r1;
/* 188:    */       }
/* 189:169 */       this.rhsToLhsLVMap.put(s2, s1);
/* 190:170 */       return s1;
/* 191:    */     }
/* 192:    */     
/* 193:    */     public boolean equivalent(Object o1, Object o2)
/* 194:    */     {
/* 195:176 */       if (o1 == null) {
/* 196:176 */         return o2 == null;
/* 197:    */       }
/* 198:177 */       if (((o1 instanceof Collection)) && ((o2 instanceof Collection))) {
/* 199:178 */         return equivalent((Collection)o1, (Collection)o2);
/* 200:    */       }
/* 201:    */       int x;
/* 202:180 */       if (((o1 instanceof StackSSALabel)) && ((o2 instanceof StackSSALabel))) {
/* 203:181 */         if (this.validSSA.contains(o1)) {
/* 204:182 */           o2 = mapSSALabel((StackSSALabel)o1, (StackSSALabel)o2);
/* 205:    */         } else {
/* 206:184 */           x = 1;
/* 207:    */         }
/* 208:    */       }
/* 209:    */       int x;
/* 210:187 */       if (((o1 instanceof LocalVariable)) && ((o2 instanceof LocalVariable))) {
/* 211:188 */         if (this.validLocal.contains(o1)) {
/* 212:189 */           o2 = mapLocalVariable((LocalVariable)o1, (LocalVariable)o2);
/* 213:    */         } else {
/* 214:191 */           x = 1;
/* 215:    */         }
/* 216:    */       }
/* 217:194 */       if (((o1 instanceof ExceptionTableEntry)) && ((o2 instanceof ExceptionTableEntry))) {
/* 218:195 */         return true;
/* 219:    */       }
/* 220:197 */       return super.equivalent(o1, o2);
/* 221:    */     }
/* 222:    */     
/* 223:    */     public void collect(StackSSALabel lValue, StatementContainer<Statement> statementContainer, Expression value)
/* 224:    */     {
/* 225:202 */       this.validSSA.add(lValue);
/* 226:    */     }
/* 227:    */     
/* 228:    */     public void collectMultiUse(StackSSALabel lValue, StatementContainer<Statement> statementContainer, Expression value)
/* 229:    */     {
/* 230:207 */       this.validSSA.add(lValue);
/* 231:    */     }
/* 232:    */     
/* 233:    */     public void collectMutatedLValue(LValue lValue, StatementContainer<Statement> statementContainer, Expression value)
/* 234:    */     {
/* 235:212 */       int x = 1;
/* 236:    */     }
/* 237:    */     
/* 238:    */     public void collectLocalVariableAssignment(LocalVariable localVariable, StatementContainer<Statement> statementContainer, Expression value)
/* 239:    */     {
/* 240:217 */       this.validLocal.add(localVariable);
/* 241:    */     }
/* 242:    */   }
/* 243:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.finalhelp.FinallyGraphHelper
 * JD-Core Version:    0.7.0.1
 */