/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractAssignmentExpression;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/* 14:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/* 15:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 16:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 17:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredFor;
/* 18:   */ import org.benf.cfr.reader.util.StringUtils;
/* 19:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 20:   */ 
/* 21:   */ public class ForStatement
/* 22:   */   extends AbstractStatement
/* 23:   */ {
/* 24:   */   private ConditionalExpression condition;
/* 25:   */   private BlockIdentifier blockIdentifier;
/* 26:   */   private AssignmentSimple initial;
/* 27:   */   private List<AbstractAssignmentExpression> assignments;
/* 28:   */   
/* 29:   */   public ForStatement(ConditionalExpression conditionalExpression, BlockIdentifier blockIdentifier, AssignmentSimple initial, List<AbstractAssignmentExpression> assignments)
/* 30:   */   {
/* 31:22 */     this.condition = conditionalExpression;
/* 32:23 */     this.blockIdentifier = blockIdentifier;
/* 33:24 */     this.initial = initial;
/* 34:25 */     this.assignments = assignments;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public Dumper dump(Dumper dumper)
/* 38:   */   {
/* 39:30 */     dumper.print("for (");
/* 40:31 */     if (this.initial != null) {
/* 41:31 */       dumper.dump(this.initial);
/* 42:   */     }
/* 43:32 */     dumper.print("; ").dump(this.condition).print("; ");
/* 44:33 */     boolean first = true;
/* 45:34 */     for (AbstractAssignmentExpression assignment : this.assignments)
/* 46:   */     {
/* 47:35 */       first = StringUtils.comma(first, dumper);
/* 48:36 */       dumper.dump(assignment);
/* 49:   */     }
/* 50:38 */     dumper.print(") ");
/* 51:39 */     dumper.print(" // ends " + getTargetStatement(1).getContainer().getLabel() + ";\n");
/* 52:40 */     return dumper;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers)
/* 56:   */   {
/* 57:45 */     for (AbstractAssignmentExpression assignment : this.assignments) {
/* 58:46 */       assignment.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer());
/* 59:   */     }
/* 60:   */   }
/* 61:   */   
/* 62:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/* 63:   */   {
/* 64:52 */     this.condition = expressionRewriter.rewriteExpression(this.condition, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE);
/* 65:53 */     int i = 0;
/* 66:53 */     for (int len = this.assignments.size(); i < len; i++) {
/* 67:54 */       this.assignments.set(i, (AbstractAssignmentExpression)expressionRewriter.rewriteExpression((Expression)this.assignments.get(i), ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE));
/* 68:   */     }
/* 69:   */   }
/* 70:   */   
/* 71:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/* 72:   */   {
/* 73:61 */     this.condition.collectUsedLValues(lValueUsageCollector);
/* 74:62 */     for (AbstractAssignmentExpression assignment : this.assignments) {
/* 75:63 */       assignment.collectUsedLValues(lValueUsageCollector);
/* 76:   */     }
/* 77:   */   }
/* 78:   */   
/* 79:   */   public StructuredStatement getStructuredStatement()
/* 80:   */   {
/* 81:69 */     return new UnstructuredFor(this.condition, this.blockIdentifier, this.initial, this.assignments);
/* 82:   */   }
/* 83:   */   
/* 84:   */   public BlockIdentifier getBlockIdentifier()
/* 85:   */   {
/* 86:73 */     return this.blockIdentifier;
/* 87:   */   }
/* 88:   */   
/* 89:   */   public ConditionalExpression getCondition()
/* 90:   */   {
/* 91:77 */     return this.condition;
/* 92:   */   }
/* 93:   */   
/* 94:   */   public AssignmentSimple getInitial()
/* 95:   */   {
/* 96:81 */     return this.initial;
/* 97:   */   }
/* 98:   */   
/* 99:   */   public List<AbstractAssignmentExpression> getAssignments()
/* :0:   */   {
/* :1:85 */     return this.assignments;
/* :2:   */   }
/* :3:   */   
/* :4:   */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* :5:   */   {
/* :6:90 */     if (o == null) {
/* :7:90 */       return false;
/* :8:   */     }
/* :9:91 */     if (o == this) {
/* ;0:91 */       return true;
/* ;1:   */     }
/* ;2:92 */     if (getClass() != o.getClass()) {
/* ;3:92 */       return false;
/* ;4:   */     }
/* ;5:93 */     ForStatement other = (ForStatement)o;
/* ;6:94 */     if (!constraint.equivalent(this.condition, other.condition)) {
/* ;7:94 */       return false;
/* ;8:   */     }
/* ;9:95 */     if (!constraint.equivalent(this.initial, other.initial)) {
/* <0:95 */       return false;
/* <1:   */     }
/* <2:96 */     if (!constraint.equivalent(this.assignments, other.assignments)) {
/* <3:96 */       return false;
/* <4:   */     }
/* <5:97 */     return true;
/* <6:   */   }
/* <7:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.ForStatement
 * JD-Core Version:    0.7.0.1
 */