/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.DeepCloneable;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentCollector;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifierFactory;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.types.annotated.JavaAnnotatedTypeInstance;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 14:   */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/* 15:   */ import org.benf.cfr.reader.util.TypeUsageCollectable;
/* 16:   */ import org.benf.cfr.reader.util.output.DumpableWithPrecedence;
/* 17:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 18:   */ 
/* 19:   */ public abstract interface LValue
/* 20:   */   extends DumpableWithPrecedence, DeepCloneable<LValue>, TypeUsageCollectable
/* 21:   */ {
/* 22:   */   public abstract int getNumberOfCreators();
/* 23:   */   
/* 24:   */   public abstract <T> void collectLValueAssignments(Expression paramExpression, StatementContainer<T> paramStatementContainer, LValueAssignmentCollector<T> paramLValueAssignmentCollector);
/* 25:   */   
/* 26:   */   public abstract boolean doesBlackListLValueReplacement(LValue paramLValue, Expression paramExpression);
/* 27:   */   
/* 28:   */   public abstract void collectLValueUsage(LValueUsageCollector paramLValueUsageCollector);
/* 29:   */   
/* 30:   */   public abstract SSAIdentifiers<LValue> collectVariableMutation(SSAIdentifierFactory<LValue> paramSSAIdentifierFactory);
/* 31:   */   
/* 32:   */   public abstract LValue replaceSingleUsageLValues(LValueRewriter paramLValueRewriter, SSAIdentifiers paramSSAIdentifiers, StatementContainer paramStatementContainer);
/* 33:   */   
/* 34:   */   public abstract LValue applyExpressionRewriter(ExpressionRewriter paramExpressionRewriter, SSAIdentifiers paramSSAIdentifiers, StatementContainer paramStatementContainer, ExpressionRewriterFlags paramExpressionRewriterFlags);
/* 35:   */   
/* 36:   */   public abstract InferredJavaType getInferredJavaType();
/* 37:   */   
/* 38:   */   public abstract JavaAnnotatedTypeInstance getAnnotatedCreationType();
/* 39:   */   
/* 40:   */   public abstract boolean canThrow(ExceptionCheck paramExceptionCheck);
/* 41:   */   
/* 42:   */   public abstract void markFinal();
/* 43:   */   
/* 44:   */   public abstract boolean isFinal();
/* 45:   */   
/* 46:   */   public static class Creation
/* 47:   */   {
/* 48:   */     public static Dumper dump(Dumper d, LValue lValue)
/* 49:   */     {
/* 50:42 */       JavaAnnotatedTypeInstance annotatedCreationType = lValue.getAnnotatedCreationType();
/* 51:43 */       if (annotatedCreationType != null)
/* 52:   */       {
/* 53:44 */         annotatedCreationType.dump(d);
/* 54:   */       }
/* 55:   */       else
/* 56:   */       {
/* 57:46 */         JavaTypeInstance t = lValue.getInferredJavaType().getJavaTypeInstance();
/* 58:47 */         d.dump(t);
/* 59:   */       }
/* 60:49 */       return d;
/* 61:   */     }
/* 62:   */   }
/* 63:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.LValue
 * JD-Core Version:    0.7.0.1
 */