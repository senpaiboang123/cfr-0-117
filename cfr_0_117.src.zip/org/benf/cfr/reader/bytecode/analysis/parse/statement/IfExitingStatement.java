/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 14:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.Block;
/* 15:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredIf;
/* 16:   */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/* 17:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 18:   */ 
/* 19:   */ public class IfExitingStatement
/* 20:   */   extends AbstractStatement
/* 21:   */ {
/* 22:   */   private ConditionalExpression condition;
/* 23:   */   private Statement statement;
/* 24:   */   
/* 25:   */   public IfExitingStatement(ConditionalExpression conditionalExpression, Statement statement)
/* 26:   */   {
/* 27:23 */     this.condition = conditionalExpression;
/* 28:24 */     this.statement = statement;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public Dumper dump(Dumper dumper)
/* 32:   */   {
/* 33:29 */     dumper.print("if (").dump(this.condition).print(") ");
/* 34:30 */     this.statement.dump(dumper);
/* 35:31 */     return dumper;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers)
/* 39:   */   {
/* 40:36 */     Expression replacementCondition = this.condition.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer());
/* 41:37 */     if (replacementCondition != this.condition) {
/* 42:38 */       this.condition = ((ConditionalExpression)replacementCondition);
/* 43:   */     }
/* 44:40 */     this.statement.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers);
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/* 48:   */   {
/* 49:45 */     this.condition = expressionRewriter.rewriteExpression(this.condition, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE);
/* 50:46 */     this.statement.rewriteExpressions(expressionRewriter, ssaIdentifiers);
/* 51:   */   }
/* 52:   */   
/* 53:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/* 54:   */   {
/* 55:51 */     this.condition.collectUsedLValues(lValueUsageCollector);
/* 56:52 */     this.statement.collectLValueUsage(lValueUsageCollector);
/* 57:   */   }
/* 58:   */   
/* 59:   */   public ConditionalExpression getCondition()
/* 60:   */   {
/* 61:56 */     return this.condition;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public Statement getExitStatement()
/* 65:   */   {
/* 66:60 */     return this.statement;
/* 67:   */   }
/* 68:   */   
/* 69:   */   public StructuredStatement getStructuredStatement()
/* 70:   */   {
/* 71:65 */     return new StructuredIf(this.condition, new Op04StructuredStatement(Block.getBlockFor(false, new StructuredStatement[] { this.statement.getStructuredStatement() })));
/* 72:   */   }
/* 73:   */   
/* 74:   */   public void optimiseForTypes()
/* 75:   */   {
/* 76:69 */     this.condition = this.condition.optimiseForType();
/* 77:   */   }
/* 78:   */   
/* 79:   */   public boolean equals(Object o)
/* 80:   */   {
/* 81:74 */     if (this == o) {
/* 82:74 */       return true;
/* 83:   */     }
/* 84:75 */     if ((o == null) || (getClass() != o.getClass())) {
/* 85:75 */       return false;
/* 86:   */     }
/* 87:77 */     IfExitingStatement that = (IfExitingStatement)o;
/* 88:79 */     if (this.condition != null ? !this.condition.equals(that.condition) : that.condition != null) {
/* 89:79 */       return false;
/* 90:   */     }
/* 91:80 */     if (!this.statement.equals(that.statement)) {
/* 92:80 */       return false;
/* 93:   */     }
/* 94:82 */     return true;
/* 95:   */   }
/* 96:   */   
/* 97:   */   public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 98:   */   {
/* 99:87 */     if (o == null) {
/* :0:87 */       return false;
/* :1:   */     }
/* :2:88 */     if (o == this) {
/* :3:88 */       return true;
/* :4:   */     }
/* :5:89 */     if (getClass() != o.getClass()) {
/* :6:89 */       return false;
/* :7:   */     }
/* :8:90 */     IfExitingStatement other = (IfExitingStatement)o;
/* :9:91 */     if (!constraint.equivalent(this.condition, other.condition)) {
/* ;0:91 */       return false;
/* ;1:   */     }
/* ;2:92 */     if (!constraint.equivalent(this.statement, other.statement)) {
/* ;3:92 */       return false;
/* ;4:   */     }
/* ;5:93 */     return true;
/* ;6:   */   }
/* ;7:   */   
/* ;8:   */   public boolean canThrow(ExceptionCheck caught)
/* ;9:   */   {
/* <0:98 */     return (this.condition.canThrow(caught)) || (this.statement.canThrow(caught));
/* <1:   */   }
/* <2:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.IfExitingStatement
 * JD-Core Version:    0.7.0.1
 */