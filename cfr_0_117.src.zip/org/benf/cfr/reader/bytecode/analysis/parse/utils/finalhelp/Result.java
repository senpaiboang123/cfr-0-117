/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.utils.finalhelp;
/*  2:   */ 
/*  3:   */ import java.util.Set;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  5:   */ 
/*  6:   */ public class Result
/*  7:   */ {
/*  8: 8 */   public static Result FAIL = new Result();
/*  9:   */   private final boolean res;
/* 10:   */   private final Set<Op03SimpleStatement> toRemove;
/* 11:   */   private final Op03SimpleStatement start;
/* 12:   */   private final Op03SimpleStatement afterEnd;
/* 13:   */   
/* 14:   */   private Result()
/* 15:   */   {
/* 16:16 */     this.res = false;
/* 17:17 */     this.toRemove = null;
/* 18:18 */     this.start = null;
/* 19:19 */     this.afterEnd = null;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public Result(Set<Op03SimpleStatement> toRemove, Op03SimpleStatement start, Op03SimpleStatement afterEnd)
/* 23:   */   {
/* 24:23 */     this.res = true;
/* 25:24 */     this.toRemove = toRemove;
/* 26:25 */     this.start = start;
/* 27:26 */     this.afterEnd = afterEnd;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public boolean isFail()
/* 31:   */   {
/* 32:30 */     return !this.res;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public boolean equals(Object o)
/* 36:   */   {
/* 37:35 */     if (this == o) {
/* 38:35 */       return true;
/* 39:   */     }
/* 40:36 */     if ((o == null) || (getClass() != o.getClass())) {
/* 41:36 */       return false;
/* 42:   */     }
/* 43:38 */     Result result = (Result)o;
/* 44:40 */     if (this.res != result.res) {
/* 45:40 */       return false;
/* 46:   */     }
/* 47:41 */     if (this.start != null ? !this.start.equals(result.start) : result.start != null) {
/* 48:41 */       return false;
/* 49:   */     }
/* 50:43 */     return true;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public int hashCode()
/* 54:   */   {
/* 55:48 */     int result = this.res ? 1 : 0;
/* 56:49 */     result = 31 * result + (this.start != null ? this.start.hashCode() : 0);
/* 57:50 */     return result;
/* 58:   */   }
/* 59:   */   
/* 60:   */   public Set<Op03SimpleStatement> getToRemove()
/* 61:   */   {
/* 62:54 */     return this.toRemove;
/* 63:   */   }
/* 64:   */   
/* 65:   */   public Op03SimpleStatement getStart()
/* 66:   */   {
/* 67:58 */     return this.start;
/* 68:   */   }
/* 69:   */   
/* 70:   */   public Op03SimpleStatement getAfterEnd()
/* 71:   */   {
/* 72:62 */     return this.afterEnd;
/* 73:   */   }
/* 74:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.finalhelp.Result
 * JD-Core Version:    0.7.0.1
 */