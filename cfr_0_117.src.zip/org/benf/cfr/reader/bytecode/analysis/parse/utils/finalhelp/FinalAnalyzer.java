/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.utils.finalhelp;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Map;
/*   8:    */ import java.util.Set;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.InstrIndex;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.CompareByIndex;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.TypeFilter;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.AssignmentSimple;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CaseStatement;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CatchStatement;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.CommentStatement;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.FinallyStatement;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.IfStatement;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.JumpingStatement;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.Nop;
/*  26:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ReturnStatement;
/*  27:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ReturnValueStatement;
/*  28:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.ThrowStatement;
/*  29:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.TryStatement;
/*  30:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  31:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifierFactory;
/*  32:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockType;
/*  33:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  34:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  35:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  36:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  37:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  38:    */ import org.benf.cfr.reader.entities.Method;
/*  39:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheckSimple;
/*  40:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionGroup;
/*  41:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionGroup.Entry;
/*  42:    */ import org.benf.cfr.reader.util.Functional;
/*  43:    */ import org.benf.cfr.reader.util.ListFactory;
/*  44:    */ import org.benf.cfr.reader.util.MapFactory;
/*  45:    */ import org.benf.cfr.reader.util.Predicate;
/*  46:    */ import org.benf.cfr.reader.util.SetFactory;
/*  47:    */ import org.benf.cfr.reader.util.SetUtil;
/*  48:    */ import org.benf.cfr.reader.util.functors.BinaryProcedure;
/*  49:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  50:    */ import org.benf.cfr.reader.util.graph.GraphVisitor;
/*  51:    */ import org.benf.cfr.reader.util.graph.GraphVisitorDFS;
/*  52:    */ 
/*  53:    */ public class FinalAnalyzer
/*  54:    */ {
/*  55:    */   public static boolean identifyFinally(Method method, Op03SimpleStatement in, List<Op03SimpleStatement> allStatements, BlockIdentifierFactory blockIdentifierFactory, Set<Op03SimpleStatement> analysedTries)
/*  56:    */   {
/*  57: 39 */     if (!(in.getStatement() instanceof TryStatement)) {
/*  58: 39 */       return true;
/*  59:    */     }
/*  60: 40 */     analysedTries.add(in);
/*  61:    */     
/*  62: 42 */     TryStatement tryStatement = (TryStatement)in.getStatement();
/*  63: 43 */     final BlockIdentifier tryBlockIdentifier = tryStatement.getBlockIdentifier();
/*  64:    */     
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69: 49 */     List<Op03SimpleStatement> targets = in.getTargets();
/*  70: 50 */     List<Op03SimpleStatement> catchStarts = Functional.filter(targets, new TypeFilter(CatchStatement.class));
/*  71: 51 */     Set<Op03SimpleStatement> possibleCatches = SetFactory.newOrderedSet();
/*  72: 52 */     for (Iterator i$ = catchStarts.iterator(); i$.hasNext();)
/*  73:    */     {
/*  74: 52 */       catchS = (Op03SimpleStatement)i$.next();
/*  75: 53 */       CatchStatement catchStatement = (CatchStatement)catchS.getStatement();
/*  76: 54 */       List<ExceptionGroup.Entry> exceptions = catchStatement.getExceptions();
/*  77: 55 */       for (ExceptionGroup.Entry exception : exceptions) {
/*  78: 56 */         if (exception.getExceptionGroup().getTryBlockIdentifier() == tryBlockIdentifier)
/*  79:    */         {
/*  80: 57 */           JavaRefTypeInstance catchType = exception.getCatchType();
/*  81: 58 */           if ("java.lang.Throwable".equals(catchType.getRawName())) {
/*  82: 59 */             possibleCatches.add(catchS);
/*  83:    */           }
/*  84:    */         }
/*  85:    */       }
/*  86:    */     }
/*  87:    */     Op03SimpleStatement catchS;
/*  88: 64 */     if (possibleCatches.isEmpty()) {
/*  89: 65 */       return false;
/*  90:    */     }
/*  91: 72 */     Op03SimpleStatement possibleFinallyCatch = findPossibleFinallyCatch(possibleCatches, allStatements);
/*  92:    */     
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96: 77 */     FinallyCatchBody finallyCatchBody = FinallyCatchBody.build(possibleFinallyCatch, allStatements);
/*  97: 78 */     if (finallyCatchBody == null) {
/*  98: 79 */       return false;
/*  99:    */     }
/* 100: 82 */     FinallyGraphHelper finallyGraphHelper = new FinallyGraphHelper(finallyCatchBody);
/* 101:    */     
/* 102: 84 */     PeerTries peerTries = new PeerTries(finallyGraphHelper, possibleFinallyCatch);
/* 103:    */     
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111: 93 */     peerTries.add(in);
/* 112: 94 */     Set<Result> results = SetFactory.newOrderedSet();
/* 113: 95 */     Set<Op03SimpleStatement> peerTrySeen = SetFactory.newSet();
/* 114: 96 */     while (peerTries.hasNext())
/* 115:    */     {
/* 116: 97 */       Op03SimpleStatement tryS = peerTries.removeNext();
/* 117: 98 */       if (peerTrySeen.add(tryS)) {
/* 118:101 */         if (!identifyFinally2(tryS, allStatements, peerTries, finallyGraphHelper, results)) {
/* 119:102 */           return false;
/* 120:    */         }
/* 121:    */       }
/* 122:    */     }
/* 123:106 */     if (results.isEmpty()) {
/* 124:108 */       return false;
/* 125:    */     }
/* 126:111 */     if (results.size() == 1) {
/* 127:113 */       return false;
/* 128:    */     }
/* 129:119 */     List<Op03SimpleStatement> originalTryTargets = ListFactory.newList(SetFactory.newOrderedSet(in.getTargets()));
/* 130:120 */     Collections.sort(originalTryTargets, new CompareByIndex());
/* 131:121 */     Op03SimpleStatement lastCatch = (Op03SimpleStatement)originalTryTargets.get(originalTryTargets.size() - 1);
/* 132:122 */     if (!(lastCatch.getStatement() instanceof CatchStatement)) {
/* 133:124 */       return false;
/* 134:    */     }
/* 135:132 */     List<PeerTries.PeerTrySet> triesByLevel = peerTries.getPeerTryGroups();
/* 136:    */     
/* 137:134 */     Set<Op03SimpleStatement> catchBlocksToNop = SetFactory.newOrderedSet();
/* 138:    */     
/* 139:136 */     Set<BlockIdentifier> blocksToRemoveCompletely = SetFactory.newSet();
/* 140:    */     
/* 141:138 */     Set<Op03SimpleStatement> protectedStatements = SetFactory.newSet();
/* 142:139 */     for (Result result : results)
/* 143:    */     {
/* 144:140 */       protectedStatements.add(result.getAfterEnd());
/* 145:141 */       protectedStatements.add(result.getStart());
/* 146:    */     }
/* 147:146 */     final PeerTries.PeerTrySet originalTryGroupPeers = (PeerTries.PeerTrySet)triesByLevel.get(0);
/* 148:147 */     for (Iterator i$ = triesByLevel.iterator(); i$.hasNext();)
/* 149:    */     {
/* 150:147 */       peerSet = (PeerTries.PeerTrySet)i$.next();
/* 151:148 */       firstTryInBlock = true;
/* 152:149 */       boolean artificalTry = true;
/* 153:151 */       for (Op03SimpleStatement peerTry : peerSet.getPeerTries()) {
/* 154:152 */         if (peerTry == in)
/* 155:    */         {
/* 156:153 */           peerTry.removeTarget(possibleFinallyCatch);
/* 157:154 */           possibleFinallyCatch.removeSource(peerTry);
/* 158:    */           
/* 159:    */ 
/* 160:    */ 
/* 161:    */ 
/* 162:159 */           firstTryInBlock = false;
/* 163:    */         }
/* 164:    */         else
/* 165:    */         {
/* 166:163 */           TryStatement peerTryStmt = (TryStatement)peerTry.getStatement();
/* 167:164 */           BlockIdentifier oldBlockIdent = peerTryStmt.getBlockIdentifier();
/* 168:    */           
/* 169:    */ 
/* 170:    */ 
/* 171:    */ 
/* 172:169 */           List<Op03SimpleStatement> handlers = ListFactory.newList(peerTry.getTargets());
/* 173:    */           
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:    */ 
/* 181:    */ 
/* 182:    */ 
/* 183:    */ 
/* 184:    */ 
/* 185:    */ 
/* 186:    */ 
/* 187:    */ 
/* 188:    */ 
/* 189:186 */           int x = 1;
/* 190:186 */           for (int len = handlers.size(); x < len; x++)
/* 191:    */           {
/* 192:187 */             Op03SimpleStatement tgt = (Op03SimpleStatement)handlers.get(x);
/* 193:188 */             tgt.removeSource(peerTry);
/* 194:189 */             peerTry.removeTarget(tgt);
/* 195:190 */             CatchStatement catchStatement = (CatchStatement)tgt.getStatement();
/* 196:191 */             BlockIdentifier catchBlockIdent = catchStatement.getCatchBlockIdent();
/* 197:192 */             catchStatement.removeCatchBlockFor(oldBlockIdent);
/* 198:    */             
/* 199:    */ 
/* 200:    */ 
/* 201:    */ 
/* 202:197 */             List<Op03SimpleStatement> catchSources = tgt.getSources();
/* 203:198 */             Set<BlockIdentifier> unionBlocks = SetFactory.newSet();
/* 204:199 */             for (Op03SimpleStatement catchSource : catchSources) {
/* 205:200 */               unionBlocks.addAll(catchSource.getBlockIdentifiers());
/* 206:    */             }
/* 207:206 */             final Set<BlockIdentifier> previousTgtBlocks = SetFactory.newSet(tgt.getBlockIdentifiers());
/* 208:207 */             previousTgtBlocks.removeAll(unionBlocks);
/* 209:    */             
/* 210:    */ 
/* 211:    */ 
/* 212:211 */             tgt.getBlockIdentifiers().removeAll(previousTgtBlocks);
/* 213:212 */             if (!previousTgtBlocks.isEmpty())
/* 214:    */             {
/* 215:213 */               tgt.getBlockIdentifiers().removeAll(previousTgtBlocks);
/* 216:214 */               GraphVisitor<Op03SimpleStatement> gv2 = new GraphVisitorDFS(tgt.getTargets(), new BinaryProcedure()
/* 217:    */               {
/* 218:    */                 public void call(Op03SimpleStatement arg1, GraphVisitor<Op03SimpleStatement> arg2)
/* 219:    */                 {
/* 220:217 */                   if (arg1.getBlockIdentifiers().contains(this.val$catchBlockIdent))
/* 221:    */                   {
/* 222:218 */                     arg1.getBlockIdentifiers().removeAll(previousTgtBlocks);
/* 223:219 */                     arg2.enqueue(arg1.getTargets());
/* 224:    */                   }
/* 225:    */                 }
/* 226:222 */               });
/* 227:223 */               gv2.process();
/* 228:    */             }
/* 229:226 */             if (tgt.getSources().isEmpty()) {
/* 230:230 */               catchBlocksToNop.add(tgt);
/* 231:    */             }
/* 232:    */           }
/* 233:235 */           if (protectedStatements.contains(peerTry)) {
/* 234:236 */             peerTry.replaceStatement(new Nop());
/* 235:    */           } else {
/* 236:238 */             peerTry.nopOut();
/* 237:    */           }
/* 238:242 */           if (peerSet.equals(originalTryGroupPeers)) {
/* 239:244 */             peerTry.getBlockIdentifiers().add(tryBlockIdentifier);
/* 240:    */           }
/* 241:246 */           GraphVisitor<Op03SimpleStatement> gvpeer = new GraphVisitorDFS(handlers.get(0), new BinaryProcedure()
/* 242:    */           {
/* 243:    */             public void call(Op03SimpleStatement arg1, GraphVisitor<Op03SimpleStatement> arg2)
/* 244:    */             {
/* 245:249 */               Set<BlockIdentifier> blockIdentifiers = arg1.getBlockIdentifiers();
/* 246:250 */               if (blockIdentifiers.remove(this.val$oldBlockIdent))
/* 247:    */               {
/* 248:251 */                 if (peerSet == originalTryGroupPeers) {
/* 249:252 */                   blockIdentifiers.add(tryBlockIdentifier);
/* 250:    */                 }
/* 251:254 */                 arg2.enqueue(arg1.getTargets());
/* 252:255 */                 arg2.enqueue(arg1.getLinearlyNext());
/* 253:    */               }
/* 254:    */             }
/* 255:258 */           });
/* 256:259 */           gvpeer.process();
/* 257:    */           
/* 258:261 */           blocksToRemoveCompletely.add(oldBlockIdent);
/* 259:    */         }
/* 260:    */       }
/* 261:    */     }
/* 262:    */     final PeerTries.PeerTrySet peerSet;
/* 263:    */     boolean firstTryInBlock;
/* 264:267 */     CatchStatement catchStatement = (CatchStatement)lastCatch.getStatement();
/* 265:268 */     BlockIdentifier lastCatchIdent = catchStatement.getCatchBlockIdent();
/* 266:269 */     int found = -1;
/* 267:270 */     for (int x = allStatements.size() - 1; x >= 0; x--) {
/* 268:271 */       if (((Op03SimpleStatement)allStatements.get(x)).getBlockIdentifiers().contains(lastCatchIdent))
/* 269:    */       {
/* 270:272 */         found = x;
/* 271:273 */         break;
/* 272:    */       }
/* 273:    */     }
/* 274:276 */     if (found == -1) {
/* 275:277 */       throw new IllegalStateException("Last catch has completely empty body");
/* 276:    */     }
/* 277:279 */     Op03SimpleStatement lastCatchContentStatement = (Op03SimpleStatement)allStatements.get(found);
/* 278:280 */     InstrIndex newIdx = lastCatchContentStatement.getIndex().justAfter();
/* 279:    */     
/* 280:    */ 
/* 281:283 */     Result cloneThis = (Result)results.iterator().next();
/* 282:284 */     List<Op03SimpleStatement> oldFinallyBody = ListFactory.newList(cloneThis.getToRemove());
/* 283:285 */     Collections.sort(oldFinallyBody, new CompareByIndex());
/* 284:286 */     List<Op03SimpleStatement> newFinallyBody = ListFactory.newList();
/* 285:287 */     Set<BlockIdentifier> oldStartBlocks = SetFactory.newOrderedSet(((Op03SimpleStatement)oldFinallyBody.get(0)).getBlockIdentifiers());
/* 286:    */     
/* 287:    */ 
/* 288:    */ 
/* 289:    */ 
/* 290:292 */     Set<BlockIdentifier> extraBlocks = SetFactory.newOrderedSet(in.getBlockIdentifiers());
/* 291:    */     
/* 292:    */ 
/* 293:    */ 
/* 294:296 */     BlockIdentifier finallyBlock = blockIdentifierFactory.getNextBlockIdentifier(BlockType.CATCHBLOCK);
/* 295:297 */     FinallyStatement finallyStatement = new FinallyStatement(finallyBlock);
/* 296:298 */     Op03SimpleStatement finallyOp = new Op03SimpleStatement(extraBlocks, finallyStatement, newIdx);
/* 297:299 */     newIdx = newIdx.justAfter();
/* 298:300 */     newFinallyBody.add(finallyOp);
/* 299:    */     
/* 300:302 */     extraBlocks.add(finallyBlock);
/* 301:303 */     Map<Op03SimpleStatement, Op03SimpleStatement> old2new = MapFactory.newMap();
/* 302:304 */     for (Op03SimpleStatement old : oldFinallyBody)
/* 303:    */     {
/* 304:305 */       Statement statement = old.getStatement();
/* 305:306 */       Set<BlockIdentifier> newblocks = SetFactory.newOrderedSet(old.getBlockIdentifiers());
/* 306:307 */       newblocks.removeAll(oldStartBlocks);
/* 307:308 */       newblocks.addAll(extraBlocks);
/* 308:309 */       Op03SimpleStatement newOp = new Op03SimpleStatement(newblocks, statement, old.getSSAIdentifiers(), newIdx);
/* 309:310 */       newFinallyBody.add(newOp);
/* 310:311 */       newIdx = newIdx.justAfter();
/* 311:312 */       old2new.put(old, newOp);
/* 312:    */     }
/* 313:314 */     if (newFinallyBody.size() > 1) {
/* 314:315 */       ((Op03SimpleStatement)newFinallyBody.get(1)).markFirstStatementInBlock(finallyBlock);
/* 315:    */     }
/* 316:327 */     Op03SimpleStatement endRewrite = null;
/* 317:328 */     for (Result r : results)
/* 318:    */     {
/* 319:329 */       Op03SimpleStatement rAfterEnd = r.getAfterEnd();
/* 320:330 */       if ((rAfterEnd != null) && (rAfterEnd.getIndex().isBackJumpFrom(r.getStart())))
/* 321:    */       {
/* 322:331 */         endRewrite = new Op03SimpleStatement(extraBlocks, new GotoStatement(), newIdx);
/* 323:332 */         endRewrite.addTarget(rAfterEnd);
/* 324:333 */         rAfterEnd.addSource(endRewrite);
/* 325:334 */         break;
/* 326:    */       }
/* 327:    */     }
/* 328:337 */     if (endRewrite == null) {
/* 329:338 */       endRewrite = new Op03SimpleStatement(extraBlocks, new CommentStatement(""), newIdx);
/* 330:    */     }
/* 331:341 */     newFinallyBody.add(endRewrite);
/* 332:343 */     for (Op03SimpleStatement old : oldFinallyBody)
/* 333:    */     {
/* 334:344 */       newOp = (Op03SimpleStatement)old2new.get(old);
/* 335:345 */       for (Op03SimpleStatement src : old.getSources())
/* 336:    */       {
/* 337:346 */         Op03SimpleStatement newSrc = (Op03SimpleStatement)old2new.get(src);
/* 338:347 */         if (newSrc != null) {
/* 339:353 */           newOp.addSource(newSrc);
/* 340:    */         }
/* 341:    */       }
/* 342:355 */       for (Op03SimpleStatement tgt : old.getTargets())
/* 343:    */       {
/* 344:356 */         Op03SimpleStatement newTgt = (Op03SimpleStatement)old2new.get(tgt);
/* 345:357 */         if (newTgt == null) {
/* 346:358 */           if (Misc.followNopGotoChain(tgt, false, false) == cloneThis.getAfterEnd())
/* 347:    */           {
/* 348:364 */             endRewrite.addSource(newOp);
/* 349:365 */             newTgt = endRewrite;
/* 350:    */           }
/* 351:    */           else
/* 352:    */           {
/* 353:373 */             if (!(newOp.getStatement() instanceof JumpingStatement)) {
/* 354:    */               continue;
/* 355:    */             }
/* 356:376 */             if (tgt.getIndex().isBackJumpFrom(endRewrite))
/* 357:    */             {
/* 358:377 */               newTgt = tgt;
/* 359:378 */               tgt.addSource(newOp);
/* 360:    */             }
/* 361:    */             else
/* 362:    */             {
/* 363:380 */               endRewrite.addSource(newOp);
/* 364:381 */               newOp.addTarget(endRewrite);
/* 365:384 */               if (endRewrite.getTargets().contains(tgt)) {
/* 366:    */                 continue;
/* 367:    */               }
/* 368:385 */               endRewrite.addTarget(tgt);
/* 369:386 */               tgt.addSource(endRewrite); continue;
/* 370:    */             }
/* 371:    */           }
/* 372:    */         }
/* 373:392 */         newOp.addTarget(newTgt);
/* 374:    */       }
/* 375:    */     }
/* 376:    */     Op03SimpleStatement newOp;
/* 377:395 */     if (newFinallyBody.size() >= 2)
/* 378:    */     {
/* 379:396 */       Op03SimpleStatement startFinallyCopy = (Op03SimpleStatement)newFinallyBody.get(1);
/* 380:397 */       startFinallyCopy.addSource(finallyOp);
/* 381:398 */       finallyOp.addTarget(startFinallyCopy);
/* 382:    */     }
/* 383:406 */     for (Result result : results)
/* 384:    */     {
/* 385:407 */       Op03SimpleStatement start = result.getStart();
/* 386:408 */       toRemove = result.getToRemove();
/* 387:409 */       afterEnd = result.getAfterEnd();
/* 388:    */       
/* 389:411 */       List<Op03SimpleStatement> startSources = ListFactory.newList(start.getSources());
/* 390:412 */       for (Op03SimpleStatement source : startSources) {
/* 391:413 */         if (!toRemove.contains(source)) {
/* 392:414 */           if (afterEnd != null)
/* 393:    */           {
/* 394:415 */             boolean canDirect = ((source.getStatement() instanceof JumpingStatement)) || (source.getIndex().isBackJumpFrom(afterEnd));
/* 395:416 */             if ((canDirect) && 
/* 396:417 */               (source.getStatement().getClass() == IfStatement.class) && 
/* 397:418 */               (start == source.getTargets().get(0))) {
/* 398:418 */               canDirect = false;
/* 399:    */             }
/* 400:421 */             if (canDirect)
/* 401:    */             {
/* 402:422 */               source.replaceTarget(start, afterEnd);
/* 403:423 */               afterEnd.addSource(source);
/* 404:    */             }
/* 405:    */             else
/* 406:    */             {
/* 407:425 */               Op03SimpleStatement afterSource = new Op03SimpleStatement(source.getBlockIdentifiers(), new GotoStatement(), source.getIndex().justAfter());
/* 408:426 */               afterEnd.addSource(afterSource);
/* 409:427 */               afterSource.addTarget(afterEnd);
/* 410:428 */               afterSource.addSource(source);
/* 411:429 */               source.replaceTarget(start, afterSource);
/* 412:430 */               allStatements.add(afterSource);
/* 413:    */             }
/* 414:    */           }
/* 415:    */           else
/* 416:    */           {
/* 417:433 */             Statement sourceStatement = source.getStatement();
/* 418:434 */             if (sourceStatement.getClass() == GotoStatement.class)
/* 419:    */             {
/* 420:435 */               source.replaceStatement(new Nop());
/* 421:436 */               source.removeTarget(start);
/* 422:    */             }
/* 423:437 */             else if (sourceStatement.getClass() == IfStatement.class)
/* 424:    */             {
/* 425:442 */               Op03SimpleStatement tgtNop = new Op03SimpleStatement(source.getBlockIdentifiers(), new Nop(), start.getIndex().justBefore());
/* 426:443 */               source.replaceTarget(start, tgtNop);
/* 427:444 */               tgtNop.addSource(source);
/* 428:445 */               allStatements.add(tgtNop);
/* 429:    */             }
/* 430:    */             else
/* 431:    */             {
/* 432:461 */               JavaTypeInstance returnType = method.getMethodPrototype().getReturnType();
/* 433:462 */               if (returnType == RawJavaType.VOID)
/* 434:    */               {
/* 435:463 */                 source.removeTarget(start);
/* 436:    */               }
/* 437:465 */               else if ((sourceStatement instanceof AssignmentSimple))
/* 438:    */               {
/* 439:466 */                 AssignmentSimple sourceAssignment = (AssignmentSimple)sourceStatement;
/* 440:467 */                 LValue lValue = sourceAssignment.getCreatedLValue();
/* 441:468 */                 JavaTypeInstance lValueType = lValue.getInferredJavaType().getJavaTypeInstance();
/* 442:469 */                 if (lValueType.implicitlyCastsTo(lValueType, null))
/* 443:    */                 {
/* 444:470 */                   Op03SimpleStatement afterSource = new Op03SimpleStatement(source.getBlockIdentifiers(), new ReturnValueStatement(new LValueExpression(lValue), returnType), source.getIndex().justAfter());
/* 445:471 */                   source.replaceTarget(start, afterSource);
/* 446:472 */                   afterSource.addSource(source);
/* 447:473 */                   allStatements.add(afterSource);
/* 448:    */                 }
/* 449:    */                 else
/* 450:    */                 {
/* 451:475 */                   source.removeTarget(start);
/* 452:    */                 }
/* 453:    */               }
/* 454:    */               else
/* 455:    */               {
/* 456:478 */                 source.removeTarget(start);
/* 457:    */               }
/* 458:    */             }
/* 459:    */           }
/* 460:    */         }
/* 461:    */       }
/* 462:485 */       for (Op03SimpleStatement remove : toRemove)
/* 463:    */       {
/* 464:486 */         for (Op03SimpleStatement source : remove.getSources()) {
/* 465:487 */           source.getTargets().remove(remove);
/* 466:    */         }
/* 467:489 */         for (Op03SimpleStatement target : remove.getTargets()) {
/* 468:490 */           target.getSources().remove(remove);
/* 469:    */         }
/* 470:492 */         remove.getSources().clear();
/* 471:493 */         remove.getTargets().clear();
/* 472:494 */         remove.nopOut();
/* 473:    */       }
/* 474:496 */       if (afterEnd != null)
/* 475:    */       {
/* 476:497 */         List<Op03SimpleStatement> endSources = ListFactory.newList(afterEnd.getSources());
/* 477:498 */         for (Op03SimpleStatement source : endSources) {
/* 478:499 */           if (toRemove.contains(source)) {
/* 479:500 */             afterEnd.removeSource(source);
/* 480:    */           }
/* 481:    */         }
/* 482:    */       }
/* 483:    */     }
/* 484:    */     Set<Op03SimpleStatement> toRemove;
/* 485:    */     Op03SimpleStatement afterEnd;
/* 486:514 */     for (Op03SimpleStatement topTry : originalTryGroupPeers.getPeerTries())
/* 487:    */     {
/* 488:519 */       Statement topStatement = topTry.getStatement();
/* 489:520 */       if ((topStatement instanceof TryStatement))
/* 490:    */       {
/* 491:522 */         TryStatement topTryStatement = (TryStatement)topStatement;
/* 492:523 */         topTryIdent = topTryStatement.getBlockIdentifier();
/* 493:    */         
/* 494:525 */         final Set<Op03SimpleStatement> peerTryExits = SetFactory.newOrderedSet();
/* 495:    */         
/* 496:527 */         GraphVisitor<Op03SimpleStatement> gv2 = new GraphVisitorDFS(topTry.getTargets().get(0), new BinaryProcedure()
/* 497:    */         {
/* 498:    */           public void call(Op03SimpleStatement arg1, GraphVisitor<Op03SimpleStatement> arg2)
/* 499:    */           {
/* 500:530 */             if (arg1.getBlockIdentifiers().contains(this.val$topTryIdent))
/* 501:    */             {
/* 502:531 */               arg2.enqueue(arg1.getTargets());
/* 503:532 */               return;
/* 504:    */             }
/* 505:538 */             if ((!arg1.getTargets().isEmpty()) && (!arg1.getStatement().canThrow(ExceptionCheckSimple.INSTANCE)))
/* 506:    */             {
/* 507:539 */               for (Op03SimpleStatement tgt : arg1.getTargets()) {
/* 508:540 */                 if (!tgt.getBlockIdentifiers().contains(this.val$topTryIdent)) {
/* 509:    */                   break label132;
/* 510:    */                 }
/* 511:    */               }
/* 512:542 */               arg1.getBlockIdentifiers().add(this.val$topTryIdent);
/* 513:543 */               arg2.enqueue(arg1.getTargets());
/* 514:544 */               return;
/* 515:    */             }
/* 516:    */             label132:
/* 517:547 */             peerTryExits.add(arg1);
/* 518:    */           }
/* 519:549 */         });
/* 520:550 */         gv2.process();
/* 521:556 */         for (Op03SimpleStatement peerTryExit : peerTryExits)
/* 522:    */         {
/* 523:557 */           Iterator i$ = peerTryExit.getSources().iterator();
/* 524:    */           for (;;)
/* 525:    */           {
/* 526:557 */             if (!i$.hasNext()) {
/* 527:    */               break label2813;
/* 528:    */             }
/* 529:557 */             Op03SimpleStatement source = (Op03SimpleStatement)i$.next();
/* 530:558 */             if (!source.getBlockIdentifiers().contains(topTryIdent)) {
/* 531:    */               break;
/* 532:    */             }
/* 533:    */           }
/* 534:562 */           if (peerTryExit.getIndex().isBackJumpFrom(finallyOp)) {
/* 535:563 */             peerTryExit.getBlockIdentifiers().add(topTryIdent);
/* 536:    */           }
/* 537:    */         }
/* 538:    */       }
/* 539:    */     }
/* 540:    */     BlockIdentifier topTryIdent;
/* 541:    */     label2813:
/* 542:572 */     for (Op03SimpleStatement stm : allStatements) {
/* 543:573 */       stm.getBlockIdentifiers().removeAll(blocksToRemoveCompletely);
/* 544:    */     }
/* 545:581 */     in.addTarget(finallyOp);
/* 546:582 */     finallyOp.addSource(in);
/* 547:583 */     allStatements.addAll(newFinallyBody);
/* 548:    */     
/* 549:585 */     return true;
/* 550:    */   }
/* 551:    */   
/* 552:    */   public static boolean identifyFinally2(Op03SimpleStatement in, List<Op03SimpleStatement> allStatements, PeerTries peerTries, FinallyGraphHelper finallyGraphHelper, Set<Result> results)
/* 553:    */   {
/* 554:593 */     if (!(in.getStatement() instanceof TryStatement)) {
/* 555:593 */       return false;
/* 556:    */     }
/* 557:594 */     TryStatement tryStatement = (TryStatement)in.getStatement();
/* 558:595 */     BlockIdentifier tryBlockIdentifier = tryStatement.getBlockIdentifier();
/* 559:    */     
/* 560:    */ 
/* 561:    */ 
/* 562:    */ 
/* 563:    */ 
/* 564:    */ 
/* 565:602 */     List<Op03SimpleStatement> targets = in.getTargets();
/* 566:603 */     List<Op03SimpleStatement> catchStarts = Functional.filter(targets, new TypeFilter(CatchStatement.class));
/* 567:604 */     Set<Op03SimpleStatement> possibleCatches = SetFactory.newOrderedSet();
/* 568:605 */     Set<Op03SimpleStatement> recTries = SetFactory.newSet();
/* 569:606 */     for (Iterator i$ = catchStarts.iterator(); i$.hasNext();)
/* 570:    */     {
/* 571:606 */       catchS = (Op03SimpleStatement)i$.next();
/* 572:607 */       CatchStatement catchStatement = (CatchStatement)catchS.getStatement();
/* 573:608 */       List<ExceptionGroup.Entry> exceptions = catchStatement.getExceptions();
/* 574:609 */       for (ExceptionGroup.Entry exception : exceptions) {
/* 575:610 */         if (exception.getExceptionGroup().getTryBlockIdentifier() == tryBlockIdentifier)
/* 576:    */         {
/* 577:611 */           JavaRefTypeInstance catchType = exception.getCatchType();
/* 578:612 */           if ("java.lang.Throwable".equals(catchType.getRawName()))
/* 579:    */           {
/* 580:613 */             possibleCatches.add(catchS);
/* 581:    */           }
/* 582:    */           else
/* 583:    */           {
/* 584:616 */             Op03SimpleStatement catchTgt = (Op03SimpleStatement)catchS.getTargets().get(0);
/* 585:617 */             if (catchTgt.getStatement().getClass() == TryStatement.class) {
/* 586:618 */               recTries.add(catchTgt);
/* 587:    */             }
/* 588:    */           }
/* 589:    */         }
/* 590:    */       }
/* 591:    */     }
/* 592:    */     Op03SimpleStatement catchS;
/* 593:624 */     if (possibleCatches.isEmpty()) {
/* 594:625 */       return false;
/* 595:    */     }
/* 596:627 */     boolean result = false;
/* 597:628 */     for (Op03SimpleStatement recTry : recTries) {
/* 598:629 */       result |= identifyFinally2(recTry, allStatements, peerTries, finallyGraphHelper, results);
/* 599:    */     }
/* 600:641 */     final Set<Op03SimpleStatement> exitPaths = SetFactory.newOrderedSet();
/* 601:642 */     for (int attempt = 0; attempt < 2; attempt++)
/* 602:    */     {
/* 603:643 */       final int attemptCopy = attempt;
/* 604:644 */       GraphVisitor<Op03SimpleStatement> gv = new GraphVisitorDFS(in.getTargets().get(0), new BinaryProcedure()
/* 605:    */       {
/* 606:    */         public void call(Op03SimpleStatement arg1, GraphVisitor<Op03SimpleStatement> arg2)
/* 607:    */         {
/* 608:647 */           if (arg1.getBlockIdentifiers().contains(this.val$tryBlockIdentifier))
/* 609:    */           {
/* 610:648 */             if ((arg1.isPossibleExitFor(this.val$tryBlockIdentifier)) && 
/* 611:649 */               (attemptCopy == 1)) {
/* 612:649 */               exitPaths.add(arg1);
/* 613:    */             }
/* 614:651 */             arg2.enqueue(arg1.getTargets());
/* 615:    */             
/* 616:653 */             Op03SimpleStatement linNext = arg1.getLinearlyNext();
/* 617:654 */             if ((linNext != null) && 
/* 618:655 */               (linNext.getBlockIdentifiers().contains(this.val$tryBlockIdentifier))) {
/* 619:656 */               arg2.enqueue(linNext);
/* 620:    */             }
/* 621:    */           }
/* 622:    */           else
/* 623:    */           {
/* 624:664 */             if ((arg1.getStatement() instanceof CaseStatement)) {
/* 625:665 */               arg1 = (Op03SimpleStatement)arg1.getTargets().get(0);
/* 626:    */             }
/* 627:667 */             exitPaths.add(arg1);
/* 628:    */           }
/* 629:    */         }
/* 630:670 */       });
/* 631:671 */       gv.process();
/* 632:672 */       if (!exitPaths.isEmpty()) {
/* 633:    */         break;
/* 634:    */       }
/* 635:    */     }
/* 636:683 */     addPeerTries(exitPaths, peerTries);
/* 637:    */     
/* 638:    */ 
/* 639:    */ 
/* 640:    */ 
/* 641:    */ 
/* 642:    */ 
/* 643:690 */     Set<BlockIdentifier> guessPeerTryBlocks = peerTries.getGuessPeerTryBlocks();
/* 644:691 */     Set<Op03SimpleStatement> guessPeerTryStarts = peerTries.getGuessPeerTryStarts();
/* 645:693 */     for (Op03SimpleStatement legitExitStart : exitPaths)
/* 646:    */     {
/* 647:694 */       Result legitExitResult = finallyGraphHelper.match(legitExitStart);
/* 648:695 */       if (legitExitResult.isFail())
/* 649:    */       {
/* 650:706 */         Set<BlockIdentifier> exitBlocks = legitExitStart.getBlockIdentifiers();
/* 651:    */         
/* 652:    */ 
/* 653:    */ 
/* 654:710 */         Set<BlockIdentifier> exitStartPeerBlocks = SetUtil.intersectionOrNull(guessPeerTryBlocks, exitBlocks);
/* 655:711 */         if ((exitStartPeerBlocks != null) && (exitStartPeerBlocks.size() == 1))
/* 656:    */         {
/* 657:713 */           Map<BlockIdentifier, Op03SimpleStatement> guessPeerTryMap = peerTries.getGuessPeerTryMap();
/* 658:714 */           Op03SimpleStatement tryStart = (Op03SimpleStatement)guessPeerTryMap.get(exitStartPeerBlocks.iterator().next());
/* 659:715 */           if (tryStart != null)
/* 660:    */           {
/* 661:716 */             peerTries.add(tryStart);
/* 662:717 */             continue;
/* 663:    */           }
/* 664:    */         }
/* 665:721 */         boolean ok = false;
/* 666:722 */         boolean allowDirect = !legitExitStart.getStatement().canThrow(ExceptionCheckSimple.INSTANCE);
/* 667:723 */         Set<Op03SimpleStatement> addPeerTries = SetFactory.newSet();
/* 668:724 */         if (allowDirect)
/* 669:    */         {
/* 670:725 */           ok = true;
/* 671:726 */           for (Op03SimpleStatement target : legitExitStart.getTargets()) {
/* 672:727 */             if (guessPeerTryStarts.contains(target))
/* 673:    */             {
/* 674:728 */               addPeerTries.add(target);
/* 675:    */             }
/* 676:    */             else
/* 677:    */             {
/* 678:731 */               exitStartPeerBlocks = SetUtil.intersectionOrNull(guessPeerTryBlocks, target.getBlockIdentifiers());
/* 679:732 */               if ((exitStartPeerBlocks != null) && (exitStartPeerBlocks.size() == 1))
/* 680:    */               {
/* 681:734 */                 Map<BlockIdentifier, Op03SimpleStatement> guessPeerTryMap = peerTries.getGuessPeerTryMap();
/* 682:735 */                 Op03SimpleStatement tryStart = (Op03SimpleStatement)guessPeerTryMap.get(exitStartPeerBlocks.iterator().next());
/* 683:736 */                 if (tryStart != null)
/* 684:    */                 {
/* 685:737 */                   peerTries.add(tryStart);
/* 686:738 */                   continue;
/* 687:    */                 }
/* 688:    */               }
/* 689:741 */               ok = false;
/* 690:    */             }
/* 691:    */           }
/* 692:    */         }
/* 693:745 */         if (ok) {
/* 694:746 */           for (Op03SimpleStatement addPeerTry : addPeerTries) {
/* 695:747 */             peerTries.add(addPeerTry);
/* 696:    */           }
/* 697:    */         } else {
/* 698:751 */           return result;
/* 699:    */         }
/* 700:    */       }
/* 701:    */       else
/* 702:    */       {
/* 703:753 */         results.add(legitExitResult);
/* 704:    */       }
/* 705:    */     }
/* 706:756 */     List<Op03SimpleStatement> tryTargets = in.getTargets();
/* 707:757 */     int x = 1;
/* 708:757 */     for (int len = tryTargets.size(); x < len; x++)
/* 709:    */     {
/* 710:758 */       Op03SimpleStatement tryCatch = (Op03SimpleStatement)tryTargets.get(x);
/* 711:759 */       if (!verifyCatchFinally(tryCatch, finallyGraphHelper, peerTries, results)) {
/* 712:763 */         return result;
/* 713:    */       }
/* 714:    */     }
/* 715:770 */     return true;
/* 716:    */   }
/* 717:    */   
/* 718:    */   private static void addPeerTries(Collection<Op03SimpleStatement> possibleFinally, PeerTries peerTries)
/* 719:    */   {
/* 720:774 */     Set<Op03SimpleStatement> res = SetFactory.newOrderedSet();
/* 721:775 */     for (Op03SimpleStatement possible : possibleFinally)
/* 722:    */     {
/* 723:776 */       if ((possible.getStatement() instanceof TryStatement)) {
/* 724:778 */         if (possible.getTargets().contains(peerTries.getOriginalFinally()))
/* 725:    */         {
/* 726:780 */           peerTries.add(possible);
/* 727:781 */           continue;
/* 728:    */         }
/* 729:    */       }
/* 730:784 */       res.add(possible);
/* 731:    */     }
/* 732:787 */     possibleFinally.clear();
/* 733:788 */     possibleFinally.addAll(res);
/* 734:    */   }
/* 735:    */   
/* 736:    */   private static boolean verifyCatchFinally(Op03SimpleStatement in, FinallyGraphHelper finallyGraphHelper, PeerTries peerTries, Set<Result> results)
/* 737:    */   {
/* 738:807 */     if (!(in.getStatement() instanceof CatchStatement)) {
/* 739:808 */       return false;
/* 740:    */     }
/* 741:810 */     if (in.getTargets().size() != 1) {
/* 742:811 */       return false;
/* 743:    */     }
/* 744:813 */     CatchStatement catchStatement = (CatchStatement)in.getStatement();
/* 745:814 */     BlockIdentifier catchBlockIdent = catchStatement.getCatchBlockIdent();
/* 746:815 */     Op03SimpleStatement firstStatementInCatch = (Op03SimpleStatement)in.getTargets().get(0);
/* 747:    */     
/* 748:    */ 
/* 749:818 */     final List<Op03SimpleStatement> statementsInCatch = ListFactory.newList();
/* 750:    */     
/* 751:820 */     final Set<Op03SimpleStatement> targetsOutsideCatch = SetFactory.newOrderedSet();
/* 752:821 */     final Set<Op03SimpleStatement> directExitsFromCatch = SetFactory.newOrderedSet();
/* 753:822 */     final Map<Op03SimpleStatement, Set<Op03SimpleStatement>> exitParents = MapFactory.newLazyMap(new UnaryFunction()
/* 754:    */     {
/* 755:    */       public Set<Op03SimpleStatement> invoke(Op03SimpleStatement arg)
/* 756:    */       {
/* 757:825 */         return SetFactory.newOrderedSet();
/* 758:    */       }
/* 759:827 */     });
/* 760:828 */     GraphVisitor<Op03SimpleStatement> gv = new GraphVisitorDFS(firstStatementInCatch, new BinaryProcedure()
/* 761:    */     {
/* 762:    */       public void call(Op03SimpleStatement arg1, GraphVisitor<Op03SimpleStatement> arg2)
/* 763:    */       {
/* 764:831 */         if (arg1.getBlockIdentifiers().contains(this.val$catchBlockIdent))
/* 765:    */         {
/* 766:832 */           statementsInCatch.add(arg1);
/* 767:833 */           arg2.enqueue(arg1.getTargets());
/* 768:834 */           for (Op03SimpleStatement tgt : arg1.getTargets()) {
/* 769:835 */             ((Set)exitParents.get(tgt)).add(arg1);
/* 770:    */           }
/* 771:837 */           Statement statement = arg1.getStatement();
/* 772:838 */           if ((statement instanceof ReturnStatement)) {
/* 773:839 */             directExitsFromCatch.add(arg1);
/* 774:    */           }
/* 775:    */         }
/* 776:    */         else
/* 777:    */         {
/* 778:843 */           targetsOutsideCatch.add(arg1);
/* 779:    */         }
/* 780:    */       }
/* 781:846 */     });
/* 782:847 */     gv.process();
/* 783:853 */     for (Op03SimpleStatement outsideCatch : targetsOutsideCatch) {
/* 784:854 */       directExitsFromCatch.addAll((Collection)exitParents.get(outsideCatch));
/* 785:    */     }
/* 786:862 */     Op03SimpleStatement finallyCodeStart = finallyGraphHelper.getFinallyCatchBody().getCatchCodeStart();
/* 787:866 */     if (finallyCodeStart == null) {
/* 788:867 */       return false;
/* 789:    */     }
/* 790:870 */     Statement finallyStartStatement = finallyCodeStart.getStatement();
/* 791:    */     
/* 792:872 */     List<Op03SimpleStatement> possibleFinalStarts = Functional.filter(statementsInCatch, new Predicate()
/* 793:    */     {
/* 794:    */       public boolean test(Op03SimpleStatement in)
/* 795:    */       {
/* 796:875 */         return in.getStatement().getClass() == this.val$finallyStartStatement.getClass();
/* 797:    */       }
/* 798:878 */     });
/* 799:879 */     List<Result> possibleFinallyBlocks = ListFactory.newList();
/* 800:880 */     for (Op03SimpleStatement possibleFinallyStart : possibleFinalStarts)
/* 801:    */     {
/* 802:881 */       Result res = finallyGraphHelper.match(possibleFinallyStart);
/* 803:882 */       if (!res.isFail()) {
/* 804:883 */         possibleFinallyBlocks.add(res);
/* 805:    */       }
/* 806:    */     }
/* 807:892 */     Map<Op03SimpleStatement, Result> matchedFinallyBlockMap = MapFactory.newMap();
/* 808:893 */     for (Iterator i$ = possibleFinallyBlocks.iterator(); i$.hasNext();)
/* 809:    */     {
/* 810:893 */       res = (Result)i$.next();
/* 811:894 */       for (Op03SimpleStatement b : res.getToRemove()) {
/* 812:895 */         matchedFinallyBlockMap.put(b, res);
/* 813:    */       }
/* 814:    */     }
/* 815:    */     Result res;
/* 816:904 */     List<Op03SimpleStatement> tryStatements = Functional.filter(statementsInCatch, new TypeFilter(TryStatement.class));
/* 817:905 */     addPeerTries(tryStatements, peerTries);
/* 818:    */     Iterator i$;
/* 819:    */     Op03SimpleStatement exit;
/* 820:    */     Result res;
/* 821:917 */     if (finallyGraphHelper.getFinallyCatchBody().hasThrowOp()) {
/* 822:921 */       for (i$ = directExitsFromCatch.iterator(); i$.hasNext();)
/* 823:    */       {
/* 824:921 */         exit = (Op03SimpleStatement)i$.next();
/* 825:922 */         res = (Result)matchedFinallyBlockMap.get(exit);
/* 826:923 */         if (res == null) {
/* 827:924 */           for (Op03SimpleStatement source : exit.getSources())
/* 828:    */           {
/* 829:925 */             res = (Result)matchedFinallyBlockMap.get(source);
/* 830:926 */             if (res == null)
/* 831:    */             {
/* 832:927 */               if (!(exit.getStatement() instanceof ThrowStatement)) {
/* 833:932 */                 return false;
/* 834:    */               }
/* 835:    */             }
/* 836:    */             else {
/* 837:934 */               results.add(res);
/* 838:    */             }
/* 839:    */           }
/* 840:    */         }
/* 841:    */       }
/* 842:    */     } else {
/* 843:942 */       for (Op03SimpleStatement exit : directExitsFromCatch)
/* 844:    */       {
/* 845:943 */         Result res = (Result)matchedFinallyBlockMap.get(exit);
/* 846:944 */         if (res == null)
/* 847:    */         {
/* 848:945 */           if (!(exit.getStatement() instanceof ThrowStatement)) {
/* 849:950 */             return false;
/* 850:    */           }
/* 851:    */         }
/* 852:    */         else {
/* 853:952 */           results.add(res);
/* 854:    */         }
/* 855:    */       }
/* 856:    */     }
/* 857:956 */     return true;
/* 858:    */   }
/* 859:    */   
/* 860:    */   private static Op03SimpleStatement findPossibleFinallyCatch(Set<Op03SimpleStatement> possibleCatches, List<Op03SimpleStatement> allStatements)
/* 861:    */   {
/* 862:964 */     List<Op03SimpleStatement> tmp = ListFactory.newList(possibleCatches);
/* 863:965 */     Collections.sort(tmp, new CompareByIndex());
/* 864:966 */     Op03SimpleStatement catchS = (Op03SimpleStatement)tmp.get(tmp.size() - 1);
/* 865:967 */     return catchS;
/* 866:    */   }
/* 867:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.finalhelp.FinalAnalyzer
 * JD-Core Version:    0.7.0.1
 */