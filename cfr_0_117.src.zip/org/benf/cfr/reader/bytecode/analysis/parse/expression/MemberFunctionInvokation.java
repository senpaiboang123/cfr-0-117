/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  9:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/* 10:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodRef;
/* 11:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 12:   */ import org.benf.cfr.reader.util.StringUtils;
/* 13:   */ import org.benf.cfr.reader.util.Troolean;
/* 14:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 15:   */ 
/* 16:   */ public class MemberFunctionInvokation
/* 17:   */   extends AbstractMemberFunctionInvokation
/* 18:   */ {
/* 19:   */   private final boolean special;
/* 20:   */   private final boolean isInitMethod;
/* 21:   */   
/* 22:   */   public MemberFunctionInvokation(ConstantPool cp, ConstantPoolEntryMethodRef function, Expression object, boolean special, List<Expression> args, List<Boolean> nulls)
/* 23:   */   {
/* 24:22 */     super(cp, function, object, args, nulls);
/* 25:   */     
/* 26:   */ 
/* 27:   */ 
/* 28:26 */     this.isInitMethod = function.isInitMethod();
/* 29:27 */     this.special = special;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public Expression deepClone(CloneHelper cloneHelper)
/* 33:   */   {
/* 34:32 */     return new MemberFunctionInvokation(getCp(), getFunction(), cloneHelper.replaceOrClone(getObject()), this.special, cloneHelper.replaceOrClone(getArgs()), getNulls());
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 38:   */   {
/* 39:37 */     super.collectTypeUsages(collector);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public Precedence getPrecedence()
/* 43:   */   {
/* 44:42 */     return Precedence.PAREN_SUB_MEMBER;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public Dumper dumpInner(Dumper d)
/* 48:   */   {
/* 49:47 */     getObject().dumpWithOuterPrecedence(d, getPrecedence(), Troolean.NEITHER);
/* 50:   */     
/* 51:49 */     MethodPrototype methodPrototype = getMethodPrototype();
/* 52:50 */     if (!this.isInitMethod) {
/* 53:50 */       d.print(".").identifier(getFixedName());
/* 54:   */     }
/* 55:51 */     d.print("(");
/* 56:52 */     List<Expression> args = getArgs();
/* 57:53 */     boolean first = true;
/* 58:54 */     for (int x = 0; x < args.size(); x++) {
/* 59:55 */       if (!methodPrototype.isHiddenArg(x))
/* 60:   */       {
/* 61:56 */         Expression arg = (Expression)args.get(x);
/* 62:57 */         first = StringUtils.comma(first, d);
/* 63:58 */         methodPrototype.dumpAppropriatelyCastedArgumentString(arg, x, d);
/* 64:   */       }
/* 65:   */     }
/* 66:60 */     d.print(")");
/* 67:61 */     return d;
/* 68:   */   }
/* 69:   */   
/* 70:   */   public boolean isInitMethod()
/* 71:   */   {
/* 72:65 */     return this.isInitMethod;
/* 73:   */   }
/* 74:   */   
/* 75:   */   public boolean equals(Object o)
/* 76:   */   {
/* 77:70 */     if (!super.equals(o)) {
/* 78:70 */       return false;
/* 79:   */     }
/* 80:71 */     if (o == this) {
/* 81:71 */       return true;
/* 82:   */     }
/* 83:72 */     if (!(o instanceof MemberFunctionInvokation)) {
/* 84:72 */       return false;
/* 85:   */     }
/* 86:73 */     return getName().equals(((MemberFunctionInvokation)o).getName());
/* 87:   */   }
/* 88:   */   
/* 89:   */   public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 90:   */   {
/* 91:78 */     if (!super.equivalentUnder(o, constraint)) {
/* 92:78 */       return false;
/* 93:   */     }
/* 94:79 */     if (o == this) {
/* 95:79 */       return true;
/* 96:   */     }
/* 97:80 */     if (!(o instanceof MemberFunctionInvokation)) {
/* 98:80 */       return false;
/* 99:   */     }
/* :0:81 */     MemberFunctionInvokation other = (MemberFunctionInvokation)o;
/* :1:82 */     return constraint.equivalent(getName(), other.getName());
/* :2:   */   }
/* :3:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.MemberFunctionInvokation
 * JD-Core Version:    0.7.0.1
 */