/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  15:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  16:    */ import org.benf.cfr.reader.util.Troolean;
/*  17:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  18:    */ 
/*  19:    */ public class ArithmeticMutationOperation
/*  20:    */   extends AbstractMutatingAssignmentExpression
/*  21:    */ {
/*  22:    */   private LValue mutated;
/*  23:    */   private final ArithOp op;
/*  24:    */   private Expression mutation;
/*  25:    */   
/*  26:    */   public ArithmeticMutationOperation(LValue mutated, Expression mutation, ArithOp op)
/*  27:    */   {
/*  28: 22 */     super(mutated.getInferredJavaType());
/*  29: 23 */     this.mutated = mutated;
/*  30: 24 */     this.op = op;
/*  31: 25 */     this.mutation = mutation;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  35:    */   {
/*  36: 30 */     return new ArithmeticMutationOperation(cloneHelper.replaceOrClone(this.mutated), cloneHelper.replaceOrClone(this.mutation), this.op);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  40:    */   {
/*  41: 35 */     this.mutated.collectTypeUsages(collector);
/*  42: 36 */     this.mutation.collectTypeUsages(collector);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public Precedence getPrecedence()
/*  46:    */   {
/*  47: 41 */     return Precedence.ASSIGNMENT;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public Dumper dumpInner(Dumper d)
/*  51:    */   {
/*  52: 46 */     d.dump(this.mutated).print(' ').print(this.op.getShowAs() + "=").print(' ');
/*  53: 47 */     this.mutation.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.NEITHER);
/*  54: 48 */     return d;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  58:    */   {
/*  59: 53 */     this.mutation = this.mutation.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/*  60: 54 */     return this;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  64:    */   {
/*  65: 59 */     this.mutated = expressionRewriter.rewriteExpression(this.mutated, ssaIdentifiers, statementContainer, ExpressionRewriterFlags.LANDRVALUE);
/*  66: 60 */     this.mutation = expressionRewriter.rewriteExpression(this.mutation, ssaIdentifiers, statementContainer, flags);
/*  67: 61 */     return this;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  71:    */   {
/*  72: 66 */     this.mutation = expressionRewriter.rewriteExpression(this.mutation, ssaIdentifiers, statementContainer, flags);
/*  73: 67 */     this.mutated = expressionRewriter.rewriteExpression(this.mutated, ssaIdentifiers, statementContainer, ExpressionRewriterFlags.LANDRVALUE);
/*  74: 68 */     return this;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public boolean isSelfMutatingOp1(LValue lValue, ArithOp arithOp)
/*  78:    */   {
/*  79: 73 */     return (this.mutated.equals(lValue)) && (this.op == arithOp) && (this.mutation.equals(new Literal(TypedLiteral.getInt(1))));
/*  80:    */   }
/*  81:    */   
/*  82:    */   public LValue getUpdatedLValue()
/*  83:    */   {
/*  84: 80 */     return this.mutated;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public ArithmeticPostMutationOperation getPostMutation()
/*  88:    */   {
/*  89: 85 */     return new ArithmeticPostMutationOperation(this.mutated, this.op);
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/*  93:    */   {
/*  94: 90 */     this.mutation.collectUsedLValues(lValueUsageCollector);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public boolean equals(Object o)
/*  98:    */   {
/*  99: 95 */     if (o == this) {
/* 100: 95 */       return true;
/* 101:    */     }
/* 102: 96 */     if (!(o instanceof ArithmeticMutationOperation)) {
/* 103: 96 */       return false;
/* 104:    */     }
/* 105: 98 */     ArithmeticMutationOperation other = (ArithmeticMutationOperation)o;
/* 106:    */     
/* 107:100 */     return (this.mutated.equals(other.mutated)) && (this.op.equals(other.op)) && (this.mutation.equals(other.mutation));
/* 108:    */   }
/* 109:    */   
/* 110:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 111:    */   {
/* 112:107 */     if (o == null) {
/* 113:107 */       return false;
/* 114:    */     }
/* 115:108 */     if (o == this) {
/* 116:108 */       return true;
/* 117:    */     }
/* 118:109 */     if (getClass() != o.getClass()) {
/* 119:109 */       return false;
/* 120:    */     }
/* 121:110 */     ArithmeticMutationOperation other = (ArithmeticMutationOperation)o;
/* 122:111 */     if (!constraint.equivalent(this.op, other.op)) {
/* 123:111 */       return false;
/* 124:    */     }
/* 125:112 */     if (!constraint.equivalent(this.mutated, other.mutated)) {
/* 126:112 */       return false;
/* 127:    */     }
/* 128:113 */     if (!constraint.equivalent(this.mutation, other.mutation)) {
/* 129:113 */       return false;
/* 130:    */     }
/* 131:114 */     return true;
/* 132:    */   }
/* 133:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithmeticMutationOperation
 * JD-Core Version:    0.7.0.1
 */