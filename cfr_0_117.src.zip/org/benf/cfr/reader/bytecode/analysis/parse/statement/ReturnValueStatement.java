/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CastExpression;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredReturn;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericPlaceholderTypeInstance;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  19:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/*  20:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  21:    */ 
/*  22:    */ public class ReturnValueStatement
/*  23:    */   extends ReturnStatement
/*  24:    */ {
/*  25:    */   private Expression rvalue;
/*  26:    */   private final JavaTypeInstance fnReturnType;
/*  27:    */   
/*  28:    */   public ReturnValueStatement(Expression rvalue, JavaTypeInstance fnReturnType)
/*  29:    */   {
/*  30: 23 */     this.rvalue = rvalue;
/*  31: 24 */     if ((fnReturnType instanceof JavaGenericPlaceholderTypeInstance)) {
/*  32: 25 */       this.rvalue = new CastExpression(new InferredJavaType(fnReturnType, InferredJavaType.Source.FUNCTION, true), this.rvalue);
/*  33:    */     }
/*  34: 27 */     this.fnReturnType = fnReturnType;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public ReturnStatement deepClone(CloneHelper cloneHelper)
/*  38:    */   {
/*  39: 32 */     return new ReturnValueStatement(cloneHelper.replaceOrClone(this.rvalue), this.fnReturnType);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public Dumper dump(Dumper dumper)
/*  43:    */   {
/*  44: 37 */     return dumper.print("return ").dump(this.rvalue).endCodeln();
/*  45:    */   }
/*  46:    */   
/*  47:    */   public Expression getReturnValue()
/*  48:    */   {
/*  49: 41 */     return this.rvalue;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public JavaTypeInstance getFnReturnType()
/*  53:    */   {
/*  54: 45 */     return this.fnReturnType;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers)
/*  58:    */   {
/*  59: 50 */     this.rvalue = this.rvalue.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer());
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/*  63:    */   {
/*  64: 55 */     this.rvalue = expressionRewriter.rewriteExpression(this.rvalue, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/*  68:    */   {
/*  69: 60 */     this.rvalue.collectUsedLValues(lValueUsageCollector);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public StructuredStatement getStructuredStatement()
/*  73:    */   {
/*  74: 69 */     Expression rvalueUse = this.rvalue;
/*  75: 70 */     if (((this.fnReturnType instanceof RawJavaType)) && 
/*  76: 71 */       (!this.rvalue.getInferredJavaType().getJavaTypeInstance().implicitlyCastsTo(this.fnReturnType, null)))
/*  77:    */     {
/*  78: 72 */       InferredJavaType inferredJavaType = new InferredJavaType(this.fnReturnType, InferredJavaType.Source.FUNCTION, true);
/*  79: 73 */       rvalueUse = new CastExpression(inferredJavaType, this.rvalue, true);
/*  80:    */     }
/*  81: 76 */     return new StructuredReturn(rvalueUse, this.fnReturnType);
/*  82:    */   }
/*  83:    */   
/*  84:    */   public boolean equals(Object o)
/*  85:    */   {
/*  86: 81 */     if (o == null) {
/*  87: 81 */       return false;
/*  88:    */     }
/*  89: 82 */     if (o == this) {
/*  90: 82 */       return true;
/*  91:    */     }
/*  92: 83 */     if (!(o instanceof ReturnValueStatement)) {
/*  93: 83 */       return false;
/*  94:    */     }
/*  95: 85 */     ReturnValueStatement other = (ReturnValueStatement)o;
/*  96: 86 */     return this.rvalue.equals(other.rvalue);
/*  97:    */   }
/*  98:    */   
/*  99:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 100:    */   {
/* 101: 91 */     if (o == null) {
/* 102: 91 */       return false;
/* 103:    */     }
/* 104: 92 */     if (o == this) {
/* 105: 92 */       return true;
/* 106:    */     }
/* 107: 93 */     if (getClass() != o.getClass()) {
/* 108: 93 */       return false;
/* 109:    */     }
/* 110: 94 */     ReturnValueStatement other = (ReturnValueStatement)o;
/* 111: 95 */     if (!constraint.equivalent(this.rvalue, other.rvalue)) {
/* 112: 95 */       return false;
/* 113:    */     }
/* 114: 96 */     return true;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public boolean canThrow(ExceptionCheck caught)
/* 118:    */   {
/* 119:101 */     return this.rvalue.canThrow(caught);
/* 120:    */   }
/* 121:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.ReturnValueStatement
 * JD-Core Version:    0.7.0.1
 */