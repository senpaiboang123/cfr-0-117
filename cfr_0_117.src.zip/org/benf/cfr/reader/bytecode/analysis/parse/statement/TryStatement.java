/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Set;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredTry;
/* 14:   */ import org.benf.cfr.reader.entities.exceptions.ExceptionGroup;
/* 15:   */ import org.benf.cfr.reader.entities.exceptions.ExceptionGroup.Entry;
/* 16:   */ import org.benf.cfr.reader.util.SetFactory;
/* 17:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 18:   */ 
/* 19:   */ public class TryStatement
/* 20:   */   extends AbstractStatement
/* 21:   */ {
/* 22:   */   private final ExceptionGroup exceptionGroup;
/* 23:19 */   private final Set<Expression> monitors = SetFactory.newSet();
/* 24:   */   
/* 25:   */   public TryStatement(ExceptionGroup exceptionGroup)
/* 26:   */   {
/* 27:22 */     this.exceptionGroup = exceptionGroup;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void addExitMutex(Expression e)
/* 31:   */   {
/* 32:26 */     this.monitors.add(e);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public Set<Expression> getMonitors()
/* 36:   */   {
/* 37:30 */     return this.monitors;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public Dumper dump(Dumper dumper)
/* 41:   */   {
/* 42:35 */     return dumper.print("try { ").print(this.exceptionGroup.getTryBlockIdentifier().toString()).print("\n");
/* 43:   */   }
/* 44:   */   
/* 45:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers) {}
/* 46:   */   
/* 47:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers) {}
/* 48:   */   
/* 49:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector) {}
/* 50:   */   
/* 51:   */   public StructuredStatement getStructuredStatement()
/* 52:   */   {
/* 53:52 */     return new UnstructuredTry(this.exceptionGroup);
/* 54:   */   }
/* 55:   */   
/* 56:   */   public BlockIdentifier getBlockIdentifier()
/* 57:   */   {
/* 58:56 */     return this.exceptionGroup.getTryBlockIdentifier();
/* 59:   */   }
/* 60:   */   
/* 61:   */   public List<ExceptionGroup.Entry> getEntries()
/* 62:   */   {
/* 63:60 */     return this.exceptionGroup.getEntries();
/* 64:   */   }
/* 65:   */   
/* 66:   */   public boolean equivalentUnder(Object other, EquivalenceConstraint constraint)
/* 67:   */   {
/* 68:64 */     return getClass() == other.getClass();
/* 69:   */   }
/* 70:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.TryStatement
 * JD-Core Version:    0.7.0.1
 */