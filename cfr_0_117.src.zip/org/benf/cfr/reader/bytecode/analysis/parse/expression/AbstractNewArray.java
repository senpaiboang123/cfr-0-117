/* 1:  */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/* 2:  */ 
/* 3:  */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/* 4:  */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/* 5:  */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 6:  */ 
/* 7:  */ public abstract class AbstractNewArray
/* 8:  */   extends AbstractExpression
/* 9:  */ {
/* ::  */   public AbstractNewArray(InferredJavaType inferredJavaType)
/* ;:  */   {
/* <:9 */     super(inferredJavaType);
/* =:  */   }
/* >:  */   
/* ?:  */   public abstract int getNumDims();
/* @:  */   
/* A:  */   public abstract int getNumSizedDims();
/* B:  */   
/* C:  */   public abstract Expression getDimSize(int paramInt);
/* D:  */   
/* E:  */   public abstract JavaTypeInstance getInnerType();
/* F:  */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractNewArray
 * JD-Core Version:    0.7.0.1
 */