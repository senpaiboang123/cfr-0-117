/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractAssignmentExpression;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractMutatingAssignmentExpression;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithOp;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.CreationCollector;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentCollector;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifierFactory;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredExpressionStatement;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  21:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/*  22:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  23:    */ 
/*  24:    */ public class AssignmentPreMutation
/*  25:    */   extends AbstractAssignment
/*  26:    */ {
/*  27:    */   private LValue lvalue;
/*  28:    */   private AbstractAssignmentExpression rvalue;
/*  29:    */   
/*  30:    */   public AssignmentPreMutation(LValue lvalue, AbstractMutatingAssignmentExpression rvalue)
/*  31:    */   {
/*  32: 43 */     this.lvalue = lvalue;
/*  33: 44 */     this.rvalue = rvalue;
/*  34: 45 */     lvalue.getInferredJavaType().chain(rvalue.getInferredJavaType());
/*  35:    */   }
/*  36:    */   
/*  37:    */   public Dumper dump(Dumper dumper)
/*  38:    */   {
/*  39: 50 */     return this.rvalue.dump(dumper).endCodeln();
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void collectLValueAssignments(LValueAssignmentCollector<Statement> lValueAssigmentCollector)
/*  43:    */   {
/*  44: 59 */     lValueAssigmentCollector.collectMutatedLValue(this.lvalue, getContainer(), this.rvalue);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/*  48:    */   {
/*  49: 64 */     this.rvalue.collectUsedLValues(lValueUsageCollector);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void collectObjectCreation(CreationCollector creationCollector)
/*  53:    */   {
/*  54: 69 */     creationCollector.collectCreation(this.lvalue, this.rvalue, getContainer());
/*  55:    */   }
/*  56:    */   
/*  57:    */   public SSAIdentifiers<LValue> collectLocallyMutatedVariables(SSAIdentifierFactory<LValue> ssaIdentifierFactory)
/*  58:    */   {
/*  59: 74 */     return this.lvalue.collectVariableMutation(ssaIdentifierFactory);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public LValue getCreatedLValue()
/*  63:    */   {
/*  64: 79 */     return this.lvalue;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public Expression getRValue()
/*  68:    */   {
/*  69: 84 */     return this.rvalue;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public boolean isSelfMutatingOperation()
/*  73:    */   {
/*  74: 89 */     return true;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public boolean isSelfMutatingOp1(LValue lValue, ArithOp arithOp)
/*  78:    */   {
/*  79: 95 */     return this.rvalue.isSelfMutatingOp1(lValue, arithOp);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public Expression getPostMutation()
/*  83:    */   {
/*  84:100 */     return this.rvalue.getPostMutation();
/*  85:    */   }
/*  86:    */   
/*  87:    */   public AbstractAssignmentExpression getInliningExpression()
/*  88:    */   {
/*  89:105 */     return this.rvalue;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers)
/*  93:    */   {
/*  94:110 */     this.lvalue = this.lvalue.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer());
/*  95:111 */     this.rvalue = ((AbstractAssignmentExpression)this.rvalue.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer()));
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/*  99:    */   {
/* 100:116 */     this.lvalue = expressionRewriter.rewriteExpression(this.lvalue, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.LVALUE);
/* 101:117 */     this.rvalue = ((AbstractAssignmentExpression)expressionRewriter.rewriteExpression(this.rvalue, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE));
/* 102:    */   }
/* 103:    */   
/* 104:    */   public StructuredStatement getStructuredStatement()
/* 105:    */   {
/* 106:122 */     return new StructuredExpressionStatement(this.rvalue, false);
/* 107:    */   }
/* 108:    */   
/* 109:    */   public boolean canThrow(ExceptionCheck caught)
/* 110:    */   {
/* 111:127 */     return this.rvalue.canThrow(caught);
/* 112:    */   }
/* 113:    */   
/* 114:    */   public boolean equals(Object o)
/* 115:    */   {
/* 116:132 */     if (o == this) {
/* 117:132 */       return true;
/* 118:    */     }
/* 119:133 */     if (!(o instanceof AssignmentPreMutation)) {
/* 120:133 */       return false;
/* 121:    */     }
/* 122:135 */     AssignmentPreMutation other = (AssignmentPreMutation)o;
/* 123:136 */     return (this.lvalue.equals(other.lvalue)) && (this.rvalue.equals(other.rvalue));
/* 124:    */   }
/* 125:    */   
/* 126:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 127:    */   {
/* 128:141 */     if (o == null) {
/* 129:141 */       return false;
/* 130:    */     }
/* 131:142 */     if (o == this) {
/* 132:142 */       return true;
/* 133:    */     }
/* 134:143 */     if (getClass() != o.getClass()) {
/* 135:143 */       return false;
/* 136:    */     }
/* 137:144 */     AssignmentPreMutation other = (AssignmentPreMutation)o;
/* 138:145 */     if (!constraint.equivalent(this.lvalue, other.lvalue)) {
/* 139:145 */       return false;
/* 140:    */     }
/* 141:146 */     if (!constraint.equivalent(this.rvalue, other.rvalue)) {
/* 142:146 */       return false;
/* 143:    */     }
/* 144:147 */     return true;
/* 145:    */   }
/* 146:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.AssignmentPreMutation
 * JD-Core Version:    0.7.0.1
 */