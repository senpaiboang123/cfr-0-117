/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.utils;
/*  2:   */ 
/*  3:   */ public class Triplet<X, Y, Z>
/*  4:   */ {
/*  5:   */   private final X x;
/*  6:   */   private final Y y;
/*  7:   */   private final Z z;
/*  8:   */   
/*  9:   */   public Triplet(X x, Y y, Z z)
/* 10:   */   {
/* 11: 9 */     this.x = x;
/* 12:10 */     this.y = y;
/* 13:11 */     this.z = z;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public X getFirst()
/* 17:   */   {
/* 18:15 */     return this.x;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public Y getSecond()
/* 22:   */   {
/* 23:19 */     return this.y;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public Z getThird()
/* 27:   */   {
/* 28:23 */     return this.z;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public static <A, B, C> Triplet<A, B, C> make(A a, B b, C c)
/* 32:   */   {
/* 33:27 */     return new Triplet(a, b, c);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public boolean equals(Object o)
/* 37:   */   {
/* 38:32 */     if (o == this) {
/* 39:32 */       return true;
/* 40:   */     }
/* 41:33 */     if (!(o instanceof Triplet)) {
/* 42:33 */       return false;
/* 43:   */     }
/* 44:35 */     Triplet other = (Triplet)o;
/* 45:37 */     if (this.x == null)
/* 46:   */     {
/* 47:38 */       if (other.x != null) {
/* 48:38 */         return false;
/* 49:   */       }
/* 50:   */     }
/* 51:40 */     else if (!this.x.equals(other.x)) {
/* 52:40 */       return false;
/* 53:   */     }
/* 54:42 */     if (this.y == null)
/* 55:   */     {
/* 56:43 */       if (other.y != null) {
/* 57:43 */         return false;
/* 58:   */       }
/* 59:   */     }
/* 60:45 */     else if (!this.y.equals(other.y)) {
/* 61:45 */       return false;
/* 62:   */     }
/* 63:47 */     if (this.z == null)
/* 64:   */     {
/* 65:48 */       if (other.z != null) {
/* 66:48 */         return false;
/* 67:   */       }
/* 68:   */     }
/* 69:50 */     else if (!this.z.equals(other.z)) {
/* 70:50 */       return false;
/* 71:   */     }
/* 72:52 */     return true;
/* 73:   */   }
/* 74:   */   
/* 75:   */   public int hashCode()
/* 76:   */   {
/* 77:57 */     int hashCode = 1;
/* 78:58 */     if (this.x != null) {
/* 79:58 */       hashCode = this.x.hashCode();
/* 80:   */     }
/* 81:59 */     if (this.y != null) {
/* 82:59 */       hashCode = hashCode * 31 + this.y.hashCode();
/* 83:   */     }
/* 84:60 */     if (this.z != null) {
/* 85:60 */       hashCode = hashCode * 31 + this.z.hashCode();
/* 86:   */     }
/* 87:61 */     return hashCode;
/* 88:   */   }
/* 89:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.Triplet
 * JD-Core Version:    0.7.0.1
 */