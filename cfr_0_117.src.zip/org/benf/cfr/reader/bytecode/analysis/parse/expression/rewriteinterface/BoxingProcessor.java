package org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface;

import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.PrimitiveBoxingRewriter;
import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;

public abstract interface BoxingProcessor
{
  public abstract boolean rewriteBoxing(PrimitiveBoxingRewriter paramPrimitiveBoxingRewriter);
  
  public abstract void applyNonArgExpressionRewriter(ExpressionRewriter paramExpressionRewriter, SSAIdentifiers paramSSAIdentifiers, StatementContainer paramStatementContainer, ExpressionRewriterFlags paramExpressionRewriterFlags);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface.BoxingProcessor
 * JD-Core Version:    0.7.0.1
 */