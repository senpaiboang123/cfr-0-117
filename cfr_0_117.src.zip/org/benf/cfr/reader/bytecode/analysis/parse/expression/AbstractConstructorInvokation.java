/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.PrimitiveBoxingRewriter;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface.BoxingProcessor;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterHelper;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.types.GenericTypeBinder;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericBaseInstance;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericRefTypeInstance;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  23:    */ import org.benf.cfr.reader.entities.classfilehelpers.OverloadMethodSet;
/*  24:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodRef;
/*  25:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  26:    */ 
/*  27:    */ public abstract class AbstractConstructorInvokation
/*  28:    */   extends AbstractExpression
/*  29:    */   implements BoxingProcessor
/*  30:    */ {
/*  31:    */   private final ConstantPoolEntryMethodRef function;
/*  32:    */   private final MethodPrototype methodPrototype;
/*  33:    */   private final List<Expression> args;
/*  34:    */   
/*  35:    */   public AbstractConstructorInvokation(InferredJavaType inferredJavaType, ConstantPoolEntryMethodRef function, List<Expression> args)
/*  36:    */   {
/*  37: 33 */     super(inferredJavaType);
/*  38: 34 */     this.args = args;
/*  39: 35 */     this.function = function;
/*  40: 36 */     this.methodPrototype = function.getMethodPrototype();
/*  41:    */   }
/*  42:    */   
/*  43:    */   protected AbstractConstructorInvokation(AbstractConstructorInvokation other, CloneHelper cloneHelper)
/*  44:    */   {
/*  45: 40 */     super(other.getInferredJavaType());
/*  46: 41 */     this.args = cloneHelper.replaceOrClone(other.args);
/*  47: 42 */     this.function = other.function;
/*  48: 43 */     this.methodPrototype = other.methodPrototype;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  52:    */   {
/*  53: 48 */     this.methodPrototype.collectTypeUsages(collector);
/*  54: 49 */     for (Expression arg : this.args) {
/*  55: 50 */       arg.collectTypeUsages(collector);
/*  56:    */     }
/*  57: 52 */     super.collectTypeUsages(collector);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public List<Expression> getArgs()
/*  61:    */   {
/*  62: 56 */     return this.args;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  66:    */   {
/*  67: 61 */     for (int x = this.args.size() - 1; x >= 0; x--) {
/*  68: 62 */       this.args.set(x, ((Expression)this.args.get(x)).replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer));
/*  69:    */     }
/*  70: 64 */     return this;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  74:    */   {
/*  75: 69 */     ExpressionRewriterHelper.applyForwards(this.args, expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  76: 70 */     return this;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  80:    */   {
/*  81: 75 */     ExpressionRewriterHelper.applyBackwards(this.args, expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  82: 76 */     return this;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public JavaTypeInstance getTypeInstance()
/*  86:    */   {
/*  87: 80 */     return getInferredJavaType().getJavaTypeInstance();
/*  88:    */   }
/*  89:    */   
/*  90:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/*  91:    */   {
/*  92: 85 */     for (Expression expression : this.args) {
/*  93: 86 */       expression.collectUsedLValues(lValueUsageCollector);
/*  94:    */     }
/*  95:    */   }
/*  96:    */   
/*  97:    */   public boolean equals(Object o)
/*  98:    */   {
/*  99: 92 */     if (o == this) {
/* 100: 92 */       return true;
/* 101:    */     }
/* 102: 93 */     if (o == null) {
/* 103: 93 */       return false;
/* 104:    */     }
/* 105: 95 */     if (!(o instanceof AbstractConstructorInvokation)) {
/* 106: 95 */       return false;
/* 107:    */     }
/* 108: 96 */     AbstractConstructorInvokation other = (AbstractConstructorInvokation)o;
/* 109: 98 */     if (!getTypeInstance().equals(other.getTypeInstance())) {
/* 110: 98 */       return false;
/* 111:    */     }
/* 112: 99 */     if (!this.args.equals(other.args)) {
/* 113: 99 */       return false;
/* 114:    */     }
/* 115:100 */     return true;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 119:    */   {
/* 120:105 */     if (o == this) {
/* 121:105 */       return true;
/* 122:    */     }
/* 123:106 */     if (o == null) {
/* 124:106 */       return false;
/* 125:    */     }
/* 126:108 */     if (!(o instanceof AbstractConstructorInvokation)) {
/* 127:108 */       return false;
/* 128:    */     }
/* 129:109 */     AbstractConstructorInvokation other = (AbstractConstructorInvokation)o;
/* 130:111 */     if (!constraint.equivalent(getTypeInstance(), other.getTypeInstance())) {
/* 131:111 */       return false;
/* 132:    */     }
/* 133:112 */     if (!constraint.equivalent(this.args, other.args)) {
/* 134:112 */       return false;
/* 135:    */     }
/* 136:113 */     return true;
/* 137:    */   }
/* 138:    */   
/* 139:    */   protected final OverloadMethodSet getOverloadMethodSet()
/* 140:    */   {
/* 141:122 */     OverloadMethodSet overloadMethodSet = this.function.getOverloadMethodSet();
/* 142:123 */     if (overloadMethodSet == null) {
/* 143:123 */       return null;
/* 144:    */     }
/* 145:124 */     JavaTypeInstance objectType = getInferredJavaType().getJavaTypeInstance();
/* 146:125 */     if ((objectType instanceof JavaGenericRefTypeInstance))
/* 147:    */     {
/* 148:126 */       JavaGenericRefTypeInstance genericType = (JavaGenericRefTypeInstance)objectType;
/* 149:127 */       return overloadMethodSet.specialiseTo(genericType);
/* 150:    */     }
/* 151:129 */     return overloadMethodSet;
/* 152:    */   }
/* 153:    */   
/* 154:    */   protected final MethodPrototype getMethodPrototype()
/* 155:    */   {
/* 156:133 */     return this.methodPrototype;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public boolean rewriteBoxing(PrimitiveBoxingRewriter boxingRewriter)
/* 160:    */   {
/* 161:139 */     List<Expression> args = getArgs();
/* 162:141 */     if (args.isEmpty()) {
/* 163:141 */       return false;
/* 164:    */     }
/* 165:146 */     OverloadMethodSet overloadMethodSet = getOverloadMethodSet();
/* 166:147 */     if (overloadMethodSet == null)
/* 167:    */     {
/* 168:151 */       boxingRewriter.removeRedundantCastOnly(args);
/* 169:152 */       return false;
/* 170:    */     }
/* 171:155 */     GenericTypeBinder gtb = this.methodPrototype.getTypeBinderFor(args);
/* 172:156 */     boolean callsCorrectEntireMethod = overloadMethodSet.callsCorrectEntireMethod(args, gtb);
/* 173:157 */     for (int x = 0; x < args.size(); x++)
/* 174:    */     {
/* 175:165 */       Expression arg = (Expression)args.get(x);
/* 176:170 */       if ((!callsCorrectEntireMethod) && (!overloadMethodSet.callsCorrectMethod(arg, x, null)))
/* 177:    */       {
/* 178:175 */         JavaTypeInstance argType = overloadMethodSet.getArgType(x, arg.getInferredJavaType().getJavaTypeInstance());
/* 179:176 */         boolean ignore = false;
/* 180:177 */         if ((argType instanceof JavaGenericBaseInstance)) {
/* 181:179 */           ignore = ((JavaGenericBaseInstance)argType).hasForeignUnbound(this.function.getCp());
/* 182:    */         }
/* 183:184 */         if (!ignore)
/* 184:    */         {
/* 185:185 */           ignore |= arg instanceof LambdaExpression;
/* 186:186 */           ignore |= arg instanceof LambdaExpressionFallback;
/* 187:    */         }
/* 188:188 */         if (!ignore) {
/* 189:189 */           arg = new CastExpression(new InferredJavaType(argType, InferredJavaType.Source.EXPRESSION, true), arg);
/* 190:    */         }
/* 191:    */       }
/* 192:193 */       arg = boxingRewriter.rewriteExpression(arg, null, null, null);
/* 193:194 */       arg = boxingRewriter.sugarParameterBoxing(arg, x, overloadMethodSet, null, this.methodPrototype);
/* 194:195 */       args.set(x, arg);
/* 195:    */     }
/* 196:197 */     return true;
/* 197:    */   }
/* 198:    */   
/* 199:    */   public void applyNonArgExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags) {}
/* 200:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractConstructorInvokation
 * JD-Core Version:    0.7.0.1
 */