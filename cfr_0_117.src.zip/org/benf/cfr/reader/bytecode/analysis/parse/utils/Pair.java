/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.utils;
/*  2:   */ 
/*  3:   */ public class Pair<X, Y>
/*  4:   */ {
/*  5:   */   private final X x;
/*  6:   */   private final Y y;
/*  7:   */   
/*  8:   */   public Pair(X x, Y y)
/*  9:   */   {
/* 10: 8 */     this.x = x;
/* 11: 9 */     this.y = y;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public X getFirst()
/* 15:   */   {
/* 16:13 */     return this.x;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public Y getSecond()
/* 20:   */   {
/* 21:17 */     return this.y;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public static <A, B> Pair<A, B> make(A a, B b)
/* 25:   */   {
/* 26:21 */     return new Pair(a, b);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public boolean equals(Object o)
/* 30:   */   {
/* 31:26 */     if (o == this) {
/* 32:26 */       return true;
/* 33:   */     }
/* 34:27 */     if (!(o instanceof Pair)) {
/* 35:27 */       return false;
/* 36:   */     }
/* 37:29 */     Pair other = (Pair)o;
/* 38:31 */     if (this.x == null)
/* 39:   */     {
/* 40:32 */       if (other.x != null) {
/* 41:32 */         return false;
/* 42:   */       }
/* 43:   */     }
/* 44:34 */     else if (!this.x.equals(other.x)) {
/* 45:34 */       return false;
/* 46:   */     }
/* 47:36 */     if (this.y == null)
/* 48:   */     {
/* 49:37 */       if (other.y != null) {
/* 50:37 */         return false;
/* 51:   */       }
/* 52:   */     }
/* 53:39 */     else if (!this.y.equals(other.y)) {
/* 54:39 */       return false;
/* 55:   */     }
/* 56:41 */     return true;
/* 57:   */   }
/* 58:   */   
/* 59:   */   public int hashCode()
/* 60:   */   {
/* 61:46 */     int hashCode = 1;
/* 62:47 */     if (this.x != null) {
/* 63:47 */       hashCode = this.x.hashCode();
/* 64:   */     }
/* 65:48 */     if (this.y != null) {
/* 66:48 */       hashCode = hashCode * 31 + this.y.hashCode();
/* 67:   */     }
/* 68:49 */     return hashCode;
/* 69:   */   }
/* 70:   */   
/* 71:   */   public String toString()
/* 72:   */   {
/* 73:54 */     return "P[" + this.x + "," + this.y + "]";
/* 74:   */   }
/* 75:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair
 * JD-Core Version:    0.7.0.1
 */