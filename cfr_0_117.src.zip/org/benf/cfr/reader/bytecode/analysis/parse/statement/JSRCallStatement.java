/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredComment;
/* 12:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 13:   */ 
/* 14:   */ public class JSRCallStatement
/* 15:   */   extends AbstractStatement
/* 16:   */ {
/* 17:   */   public Dumper dump(Dumper dumper)
/* 18:   */   {
/* 19:20 */     return dumper.print("CALL " + getTargetStatement(0).getContainer().getLabel() + ";\n");
/* 20:   */   }
/* 21:   */   
/* 22:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers) {}
/* 23:   */   
/* 24:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers) {}
/* 25:   */   
/* 26:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector) {}
/* 27:   */   
/* 28:   */   public StructuredStatement getStructuredStatement()
/* 29:   */   {
/* 30:37 */     return new StructuredComment("JSR Call");
/* 31:   */   }
/* 32:   */   
/* 33:   */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 34:   */   {
/* 35:43 */     if (o == null) {
/* 36:43 */       return false;
/* 37:   */     }
/* 38:44 */     if (o == this) {
/* 39:44 */       return true;
/* 40:   */     }
/* 41:45 */     if (getClass() != o.getClass()) {
/* 42:45 */       return false;
/* 43:   */     }
/* 44:46 */     return true;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public boolean fallsToNext()
/* 48:   */   {
/* 49:51 */     return false;
/* 50:   */   }
/* 51:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.JSRCallStatement
 * JD-Core Version:    0.7.0.1
 */