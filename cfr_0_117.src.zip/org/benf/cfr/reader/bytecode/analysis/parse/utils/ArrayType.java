/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.utils;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  5:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  6:   */ 
/*  7:   */ public enum ArrayType
/*  8:   */ {
/*  9: 8 */   T_BOOLEAN(4, "boolean", RawJavaType.BOOLEAN),  T_CHAR(5, "char", RawJavaType.CHAR),  T_FLOAT(6, "float", RawJavaType.FLOAT),  T_DOUBLE(7, "double", RawJavaType.DOUBLE),  T_BYTE(8, "byte", RawJavaType.BYTE),  T_SHORT(9, "short", RawJavaType.SHORT),  T_INT(10, "int", RawJavaType.INT),  T_LONG(11, "long", RawJavaType.LONG);
/* 10:   */   
/* 11:   */   private final int spec;
/* 12:   */   private final String name;
/* 13:   */   private final JavaTypeInstance javaTypeInstance;
/* 14:   */   
/* 15:   */   private ArrayType(int spec, String name, JavaTypeInstance javaTypeInstance)
/* 16:   */   {
/* 17:22 */     this.spec = spec;
/* 18:23 */     this.name = name;
/* 19:24 */     this.javaTypeInstance = javaTypeInstance;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public static ArrayType getArrayType(int id)
/* 23:   */   {
/* 24:28 */     switch (id)
/* 25:   */     {
/* 26:   */     case 4: 
/* 27:30 */       return T_BOOLEAN;
/* 28:   */     case 5: 
/* 29:32 */       return T_CHAR;
/* 30:   */     case 6: 
/* 31:34 */       return T_FLOAT;
/* 32:   */     case 7: 
/* 33:36 */       return T_DOUBLE;
/* 34:   */     case 8: 
/* 35:38 */       return T_BYTE;
/* 36:   */     case 9: 
/* 37:40 */       return T_SHORT;
/* 38:   */     case 10: 
/* 39:42 */       return T_INT;
/* 40:   */     case 11: 
/* 41:44 */       return T_LONG;
/* 42:   */     }
/* 43:46 */     throw new ConfusedCFRException("No such primitive array type " + id);
/* 44:   */   }
/* 45:   */   
/* 46:   */   public String toString()
/* 47:   */   {
/* 48:52 */     return this.name;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public JavaTypeInstance getJavaTypeInstance()
/* 52:   */   {
/* 53:56 */     return this.javaTypeInstance;
/* 54:   */   }
/* 55:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.ArrayType
 * JD-Core Version:    0.7.0.1
 */