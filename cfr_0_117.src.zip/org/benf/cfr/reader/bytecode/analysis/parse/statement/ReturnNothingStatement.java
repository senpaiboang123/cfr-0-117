/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredReturn;
/* 11:   */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/* 12:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 13:   */ 
/* 14:   */ public class ReturnNothingStatement
/* 15:   */   extends ReturnStatement
/* 16:   */ {
/* 17:   */   public ReturnStatement deepClone(CloneHelper cloneHelper)
/* 18:   */   {
/* 19:17 */     return new ReturnNothingStatement();
/* 20:   */   }
/* 21:   */   
/* 22:   */   public Dumper dump(Dumper dumper)
/* 23:   */   {
/* 24:22 */     return dumper.print("return;\n");
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers) {}
/* 28:   */   
/* 29:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers) {}
/* 30:   */   
/* 31:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector) {}
/* 32:   */   
/* 33:   */   public StructuredStatement getStructuredStatement()
/* 34:   */   {
/* 35:40 */     return new StructuredReturn();
/* 36:   */   }
/* 37:   */   
/* 38:   */   public boolean equals(Object o)
/* 39:   */   {
/* 40:45 */     return o instanceof ReturnNothingStatement;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 44:   */   {
/* 45:50 */     if (o == null) {
/* 46:50 */       return false;
/* 47:   */     }
/* 48:51 */     if (o == this) {
/* 49:51 */       return true;
/* 50:   */     }
/* 51:52 */     if (getClass() != o.getClass()) {
/* 52:52 */       return false;
/* 53:   */     }
/* 54:53 */     return true;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public boolean canThrow(ExceptionCheck caught)
/* 58:   */   {
/* 59:58 */     return false;
/* 60:   */   }
/* 61:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.ReturnNothingStatement
 * JD-Core Version:    0.7.0.1
 */