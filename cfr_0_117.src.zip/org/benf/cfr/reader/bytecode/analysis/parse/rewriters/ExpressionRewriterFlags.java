package org.benf.cfr.reader.bytecode.analysis.parse.rewriters;

public enum ExpressionRewriterFlags
{
  RVALUE,  LVALUE,  LANDRVALUE;
  
  private ExpressionRewriterFlags() {}
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags
 * JD-Core Version:    0.7.0.1
 */