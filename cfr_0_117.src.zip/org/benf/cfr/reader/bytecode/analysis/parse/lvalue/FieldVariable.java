/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.lvalue;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.variables.NamedVariable;
/*  15:    */ import org.benf.cfr.reader.entities.ClassFileField;
/*  16:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/*  17:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  18:    */ import org.benf.cfr.reader.util.Troolean;
/*  19:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  20:    */ 
/*  21:    */ public class FieldVariable
/*  22:    */   extends AbstractFieldVariable
/*  23:    */ {
/*  24:    */   private Expression object;
/*  25:    */   
/*  26:    */   public FieldVariable(Expression object, ConstantPoolEntry field)
/*  27:    */   {
/*  28: 27 */     super(field);
/*  29: 28 */     this.object = object;
/*  30:    */   }
/*  31:    */   
/*  32:    */   private FieldVariable(FieldVariable other, CloneHelper cloneHelper)
/*  33:    */   {
/*  34: 32 */     super(other);
/*  35: 33 */     this.object = cloneHelper.replaceOrClone(other.object);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  39:    */   {
/*  40: 38 */     super.collectTypeUsages(collector);
/*  41: 39 */     collector.collectFrom(this.object);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public LValue deepClone(CloneHelper cloneHelper)
/*  45:    */   {
/*  46: 44 */     return new FieldVariable(this, cloneHelper);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public boolean isOuterRef()
/*  50:    */   {
/*  51: 51 */     ClassFileField classFileField = getClassFileField();
/*  52: 52 */     return (classFileField != null) && (classFileField.isSyntheticOuterRef());
/*  53:    */   }
/*  54:    */   
/*  55:    */   public Expression getObject()
/*  56:    */   {
/*  57: 56 */     return this.object;
/*  58:    */   }
/*  59:    */   
/*  60:    */   private boolean objectIsThis()
/*  61:    */   {
/*  62: 60 */     if ((this.object instanceof LValueExpression))
/*  63:    */     {
/*  64: 61 */       LValue lValue = ((LValueExpression)this.object).getLValue();
/*  65: 62 */       if ((lValue instanceof LocalVariable)) {
/*  66: 63 */         return ((LocalVariable)lValue).getName().getStringName().equals("this");
/*  67:    */       }
/*  68:    */     }
/*  69: 66 */     return false;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public Precedence getPrecedence()
/*  73:    */   {
/*  74: 71 */     return Precedence.PAREN_SUB_MEMBER;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public Dumper dumpInner(Dumper d)
/*  78:    */   {
/*  79: 76 */     if ((isOuterRef()) && (objectIsThis())) {
/*  80: 77 */       return d.identifier(getFieldName());
/*  81:    */     }
/*  82: 79 */     this.object.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.NEITHER);
/*  83: 80 */     return d.print(".").identifier(getFieldName());
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/*  87:    */   {
/*  88: 86 */     this.object.collectUsedLValues(lValueUsageCollector);
/*  89:    */   }
/*  90:    */   
/*  91:    */   public LValue replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  92:    */   {
/*  93: 91 */     this.object = this.object.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/*  94: 92 */     return this;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public LValue applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  98:    */   {
/*  99: 97 */     this.object = expressionRewriter.rewriteExpression(this.object, ssaIdentifiers, statementContainer, flags);
/* 100: 98 */     return this;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public void rewriteLeftNestedSyntheticOuterRefs()
/* 104:    */   {
/* 105:102 */     if (isOuterRef()) {
/* 106:103 */       while ((this.object instanceof LValueExpression))
/* 107:    */       {
/* 108:104 */         LValue lValueLhs = ((LValueExpression)this.object).getLValue();
/* 109:105 */         if ((lValueLhs instanceof FieldVariable))
/* 110:    */         {
/* 111:106 */           FieldVariable lhs = (FieldVariable)lValueLhs;
/* 112:107 */           if (lhs.isOuterRef()) {
/* 113:108 */             this.object = lhs.object;
/* 114:    */           } else {}
/* 115:    */         }
/* 116:    */       }
/* 117:    */     }
/* 118:    */   }
/* 119:    */   
/* 120:    */   public boolean equals(Object o)
/* 121:    */   {
/* 122:119 */     if (o == this) {
/* 123:119 */       return true;
/* 124:    */     }
/* 125:121 */     if (!(o instanceof FieldVariable)) {
/* 126:121 */       return false;
/* 127:    */     }
/* 128:122 */     FieldVariable other = (FieldVariable)o;
/* 129:124 */     if (!super.equals(o)) {
/* 130:124 */       return false;
/* 131:    */     }
/* 132:125 */     if (!this.object.equals(other.object)) {
/* 133:125 */       return false;
/* 134:    */     }
/* 135:126 */     return true;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public int hashCode()
/* 139:    */   {
/* 140:132 */     return System.identityHashCode(this);
/* 141:    */   }
/* 142:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.lvalue.FieldVariable
 * JD-Core Version:    0.7.0.1
 */