/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.rewriters;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithmeticOperation;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 10:   */ 
/* 11:   */ public class XorRewriter
/* 12:   */   implements ExpressionRewriter
/* 13:   */ {
/* 14:   */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 15:   */   {
/* 16:28 */     if ((expression instanceof ArithmeticOperation))
/* 17:   */     {
/* 18:29 */       ArithmeticOperation arithmeticOperation = (ArithmeticOperation)expression;
/* 19:30 */       if (arithmeticOperation.isXorM1()) {
/* 20:31 */         expression = arithmeticOperation.getReplacementXorM1();
/* 21:   */       }
/* 22:   */     }
/* 23:34 */     return expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void handleStatement(StatementContainer statementContainer) {}
/* 27:   */   
/* 28:   */   public ConditionalExpression rewriteExpression(ConditionalExpression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 29:   */   {
/* 30:44 */     Expression res = expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 31:45 */     return (ConditionalExpression)res;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 35:   */   {
/* 36:56 */     return lValue;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public StackSSALabel rewriteExpression(StackSSALabel lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 40:   */   {
/* 41:61 */     return lValue;
/* 42:   */   }
/* 43:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.rewriters.XorRewriter
 * JD-Core Version:    0.7.0.1
 */