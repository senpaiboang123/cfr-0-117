/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredComment;
/* 10:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 11:   */ 
/* 12:   */ public class Nop
/* 13:   */   extends AbstractStatement
/* 14:   */ {
/* 15:   */   public Dumper dump(Dumper dumper)
/* 16:   */   {
/* 17:18 */     return dumper.print("NOP\n");
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers) {}
/* 21:   */   
/* 22:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers) {}
/* 23:   */   
/* 24:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector) {}
/* 25:   */   
/* 26:   */   public StructuredStatement getStructuredStatement()
/* 27:   */   {
/* 28:35 */     return new StructuredComment("");
/* 29:   */   }
/* 30:   */   
/* 31:   */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 32:   */   {
/* 33:40 */     if (o == null) {
/* 34:40 */       return false;
/* 35:   */     }
/* 36:41 */     if (o == this) {
/* 37:41 */       return true;
/* 38:   */     }
/* 39:42 */     if (getClass() != o.getClass()) {
/* 40:42 */       return false;
/* 41:   */     }
/* 42:43 */     return true;
/* 43:   */   }
/* 44:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.Nop
 * JD-Core Version:    0.7.0.1
 */