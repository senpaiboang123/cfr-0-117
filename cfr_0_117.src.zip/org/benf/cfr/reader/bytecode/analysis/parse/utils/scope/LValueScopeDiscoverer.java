package org.benf.cfr.reader.bytecode.analysis.parse.utils.scope;

import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentCollector;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;

public abstract interface LValueScopeDiscoverer
  extends LValueUsageCollector, LValueAssignmentCollector<StructuredStatement>
{
  public abstract void enterBlock(StructuredStatement paramStructuredStatement);
  
  public abstract void leaveBlock(StructuredStatement paramStructuredStatement);
  
  public abstract void collect(StackSSALabel paramStackSSALabel, StatementContainer<StructuredStatement> paramStatementContainer, Expression paramExpression);
  
  public abstract void collectMultiUse(StackSSALabel paramStackSSALabel, StatementContainer<StructuredStatement> paramStatementContainer, Expression paramExpression);
  
  public abstract void collectMutatedLValue(LValue paramLValue, StatementContainer<StructuredStatement> paramStatementContainer, Expression paramExpression);
  
  public abstract void collectLocalVariableAssignment(LocalVariable paramLocalVariable, StatementContainer<StructuredStatement> paramStatementContainer, Expression paramExpression);
  
  public abstract void collect(LValue paramLValue);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer
 * JD-Core Version:    0.7.0.1
 */