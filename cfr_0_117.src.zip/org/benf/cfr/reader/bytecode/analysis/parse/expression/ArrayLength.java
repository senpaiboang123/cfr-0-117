/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/* 14:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 15:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/* 16:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 17:   */ import org.benf.cfr.reader.util.Troolean;
/* 18:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 19:   */ 
/* 20:   */ public class ArrayLength
/* 21:   */   extends AbstractExpression
/* 22:   */ {
/* 23:   */   private Expression array;
/* 24:   */   
/* 25:   */   public ArrayLength(Expression array)
/* 26:   */   {
/* 27:20 */     super(new InferredJavaType(RawJavaType.INT, InferredJavaType.Source.INSTRUCTION));
/* 28:21 */     this.array = array;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public Expression deepClone(CloneHelper cloneHelper)
/* 32:   */   {
/* 33:26 */     return new ArrayLength(cloneHelper.replaceOrClone(this.array));
/* 34:   */   }
/* 35:   */   
/* 36:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 37:   */   {
/* 38:31 */     this.array.collectTypeUsages(collector);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public Precedence getPrecedence()
/* 42:   */   {
/* 43:36 */     return Precedence.PAREN_SUB_MEMBER;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public Dumper dumpInner(Dumper d)
/* 47:   */   {
/* 48:41 */     this.array.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.NEITHER);
/* 49:42 */     return d.print(".length");
/* 50:   */   }
/* 51:   */   
/* 52:   */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/* 53:   */   {
/* 54:47 */     this.array = this.array.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/* 55:48 */     return this;
/* 56:   */   }
/* 57:   */   
/* 58:   */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 59:   */   {
/* 60:53 */     this.array = expressionRewriter.rewriteExpression(this.array, ssaIdentifiers, statementContainer, flags);
/* 61:54 */     return this;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 65:   */   {
/* 66:59 */     return applyExpressionRewriter(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/* 67:   */   }
/* 68:   */   
/* 69:   */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/* 70:   */   {
/* 71:64 */     this.array.collectUsedLValues(lValueUsageCollector);
/* 72:   */   }
/* 73:   */   
/* 74:   */   public Expression getArray()
/* 75:   */   {
/* 76:68 */     return this.array;
/* 77:   */   }
/* 78:   */   
/* 79:   */   public boolean equals(Object o)
/* 80:   */   {
/* 81:73 */     if (o == this) {
/* 82:73 */       return true;
/* 83:   */     }
/* 84:74 */     if (!(o instanceof ArrayLength)) {
/* 85:74 */       return false;
/* 86:   */     }
/* 87:75 */     return this.array.equals(((ArrayLength)o).getArray());
/* 88:   */   }
/* 89:   */   
/* 90:   */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 91:   */   {
/* 92:80 */     if (o == null) {
/* 93:80 */       return false;
/* 94:   */     }
/* 95:81 */     if (o == this) {
/* 96:81 */       return true;
/* 97:   */     }
/* 98:82 */     if (getClass() != o.getClass()) {
/* 99:82 */       return false;
/* :0:   */     }
/* :1:83 */     ArrayLength other = (ArrayLength)o;
/* :2:84 */     if (!constraint.equivalent(this.array, other.array)) {
/* :3:84 */       return false;
/* :4:   */     }
/* :5:85 */     return true;
/* :6:   */   }
/* :7:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.ArrayLength
 * JD-Core Version:    0.7.0.1
 */