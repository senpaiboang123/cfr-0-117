/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.ConditionalUtils;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredIf;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredAnonymousBreak;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredBreak;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredContinue;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredIf;
/*  22:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/*  23:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  24:    */ 
/*  25:    */ public class IfStatement
/*  26:    */   extends GotoStatement
/*  27:    */ {
/*  28:    */   private static final int JUMP_NOT_TAKEN = 0;
/*  29:    */   private static final int JUMP_TAKEN = 1;
/*  30:    */   private ConditionalExpression condition;
/*  31: 24 */   private BlockIdentifier knownIfBlock = null;
/*  32: 25 */   private BlockIdentifier knownElseBlock = null;
/*  33:    */   
/*  34:    */   public IfStatement(ConditionalExpression conditionalExpression)
/*  35:    */   {
/*  36: 29 */     this.condition = conditionalExpression;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public Dumper dump(Dumper dumper)
/*  40:    */   {
/*  41: 34 */     dumper.print("if (").dump(this.condition).print(") ");
/*  42: 35 */     return super.dump(dumper);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers)
/*  46:    */   {
/*  47: 40 */     Expression replacementCondition = this.condition.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer());
/*  48: 41 */     if (replacementCondition != this.condition) {
/*  49: 42 */       this.condition = ((ConditionalExpression)replacementCondition);
/*  50:    */     }
/*  51:    */   }
/*  52:    */   
/*  53:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/*  54:    */   {
/*  55: 48 */     this.condition = expressionRewriter.rewriteExpression(this.condition, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/*  59:    */   {
/*  60: 53 */     this.condition.collectUsedLValues(lValueUsageCollector);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public ConditionalExpression getCondition()
/*  64:    */   {
/*  65: 57 */     return this.condition;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void setCondition(ConditionalExpression condition)
/*  69:    */   {
/*  70: 61 */     this.condition = condition;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void simplifyCondition()
/*  74:    */   {
/*  75: 65 */     this.condition = ConditionalUtils.simplify(this.condition);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void negateCondition()
/*  79:    */   {
/*  80: 69 */     this.condition = ConditionalUtils.simplify(this.condition.getNegated());
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void replaceWithWhileLoopStart(BlockIdentifier blockIdentifier)
/*  84:    */   {
/*  85: 73 */     WhileStatement replacement = new WhileStatement(ConditionalUtils.simplify(this.condition.getNegated()), blockIdentifier);
/*  86: 74 */     getContainer().replaceStatement(replacement);
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void replaceWithWhileLoopEnd(BlockIdentifier blockIdentifier)
/*  90:    */   {
/*  91: 78 */     WhileStatement replacement = new WhileStatement(ConditionalUtils.simplify(this.condition), blockIdentifier);
/*  92: 79 */     getContainer().replaceStatement(replacement);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public Statement getJumpTarget()
/*  96:    */   {
/*  97: 84 */     return getTargetStatement(1);
/*  98:    */   }
/*  99:    */   
/* 100:    */   public boolean isConditional()
/* 101:    */   {
/* 102: 89 */     return true;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public boolean canThrow(ExceptionCheck caught)
/* 106:    */   {
/* 107: 94 */     return this.condition.canThrow(caught);
/* 108:    */   }
/* 109:    */   
/* 110:    */   public StructuredStatement getStructuredStatement()
/* 111:    */   {
/* 112: 99 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$utils$JumpType[getJumpType().ordinal()])
/* 113:    */     {
/* 114:    */     case 1: 
/* 115:    */     case 2: 
/* 116:    */     case 3: 
/* 117:103 */       return new UnstructuredIf(this.condition, this.knownIfBlock, this.knownElseBlock);
/* 118:    */     case 4: 
/* 119:105 */       return new StructuredIf(this.condition, new Op04StructuredStatement(new UnstructuredContinue(getTargetStartBlock())));
/* 120:    */     case 5: 
/* 121:107 */       return new StructuredIf(this.condition, new Op04StructuredStatement(new UnstructuredBreak(getJumpTarget().getContainer().getBlocksEnded())));
/* 122:    */     case 6: 
/* 123:109 */       Statement target = getJumpTarget();
/* 124:110 */       if (!(target instanceof AnonBreakTarget)) {
/* 125:111 */         throw new IllegalStateException("Target of anonymous break unexpected.");
/* 126:    */       }
/* 127:113 */       AnonBreakTarget anonBreakTarget = (AnonBreakTarget)target;
/* 128:114 */       BlockIdentifier breakFrom = anonBreakTarget.getBlockIdentifier();
/* 129:115 */       Op04StructuredStatement unstructuredBreak = new Op04StructuredStatement(new UnstructuredAnonymousBreak(breakFrom));
/* 130:116 */       return new StructuredIf(this.condition, unstructuredBreak);
/* 131:    */     }
/* 132:119 */     throw new UnsupportedOperationException("Unexpected jump type in if block - " + getJumpType());
/* 133:    */   }
/* 134:    */   
/* 135:    */   public void setKnownBlocks(BlockIdentifier ifBlock, BlockIdentifier elseBlock)
/* 136:    */   {
/* 137:123 */     this.knownIfBlock = ifBlock;
/* 138:124 */     this.knownElseBlock = elseBlock;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public Pair<BlockIdentifier, BlockIdentifier> getBlocks()
/* 142:    */   {
/* 143:128 */     return Pair.make(this.knownIfBlock, this.knownElseBlock);
/* 144:    */   }
/* 145:    */   
/* 146:    */   public BlockIdentifier getKnownIfBlock()
/* 147:    */   {
/* 148:132 */     return this.knownIfBlock;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public boolean hasElseBlock()
/* 152:    */   {
/* 153:136 */     return this.knownElseBlock != null;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public void optimiseForTypes()
/* 157:    */   {
/* 158:140 */     this.condition = this.condition.optimiseForType();
/* 159:    */   }
/* 160:    */   
/* 161:    */   public boolean equals(Object o)
/* 162:    */   {
/* 163:145 */     if (this == o) {
/* 164:145 */       return true;
/* 165:    */     }
/* 166:146 */     if ((o == null) || (getClass() != o.getClass())) {
/* 167:146 */       return false;
/* 168:    */     }
/* 169:148 */     IfStatement that = (IfStatement)o;
/* 170:150 */     if (this.condition != null ? !this.condition.equals(that.condition) : that.condition != null) {
/* 171:150 */       return false;
/* 172:    */     }
/* 173:152 */     return true;
/* 174:    */   }
/* 175:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.IfStatement
 * JD-Core Version:    0.7.0.1
 */