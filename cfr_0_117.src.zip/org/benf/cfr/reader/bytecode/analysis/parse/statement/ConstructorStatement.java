/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.MemberFunctionInvokation;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.CreationCollector;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredExpressionStatement;
/* 14:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 15:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 16:   */ 
/* 17:   */ public class ConstructorStatement
/* 18:   */   extends AbstractStatement
/* 19:   */ {
/* 20:   */   private MemberFunctionInvokation invokation;
/* 21:   */   
/* 22:   */   public ConstructorStatement(MemberFunctionInvokation construction)
/* 23:   */   {
/* 24:21 */     this.invokation = construction;
/* 25:22 */     Expression object = this.invokation.getObject();
/* 26:23 */     object.getInferredJavaType().chain(this.invokation.getInferredJavaType());
/* 27:   */   }
/* 28:   */   
/* 29:   */   public Dumper dump(Dumper dumper)
/* 30:   */   {
/* 31:28 */     return dumper.print("<init>").dump(this.invokation).print(";\n");
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers)
/* 35:   */   {
/* 36:34 */     this.invokation.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer());
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/* 40:   */   {
/* 41:39 */     this.invokation.applyExpressionRewriter(expressionRewriter, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE);
/* 42:   */   }
/* 43:   */   
/* 44:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/* 45:   */   {
/* 46:44 */     this.invokation.collectUsedLValues(lValueUsageCollector);
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void collectObjectCreation(CreationCollector creationCollector)
/* 50:   */   {
/* 51:49 */     Expression object = this.invokation.getObject();
/* 52:50 */     creationCollector.collectConstruction(object, this.invokation, getContainer());
/* 53:   */   }
/* 54:   */   
/* 55:   */   public StructuredStatement getStructuredStatement()
/* 56:   */   {
/* 57:55 */     return new StructuredExpressionStatement(this.invokation, false);
/* 58:   */   }
/* 59:   */   
/* 60:   */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 61:   */   {
/* 62:60 */     if (o == null) {
/* 63:60 */       return false;
/* 64:   */     }
/* 65:61 */     if (o == this) {
/* 66:61 */       return true;
/* 67:   */     }
/* 68:62 */     if (getClass() != o.getClass()) {
/* 69:62 */       return false;
/* 70:   */     }
/* 71:63 */     ConstructorStatement other = (ConstructorStatement)o;
/* 72:64 */     if (!constraint.equivalent(this.invokation, other.invokation)) {
/* 73:64 */       return false;
/* 74:   */     }
/* 75:65 */     return true;
/* 76:   */   }
/* 77:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.ConstructorStatement
 * JD-Core Version:    0.7.0.1
 */