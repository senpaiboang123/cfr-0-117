/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.utils;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractAssignmentExpression;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractFunctionInvokation;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.BooleanOperation;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.TernaryExpression;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.AbstractExpressionRewriter;
/* 14:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/* 15:   */ 
/* 16:   */ public class LValueAssignmentExpressionRewriter
/* 17:   */   extends AbstractExpressionRewriter
/* 18:   */ {
/* 19:   */   private final LValue lValue;
/* 20:   */   private final AbstractAssignmentExpression lValueReplacement;
/* 21:   */   private final Op03SimpleStatement source;
/* 22:16 */   private boolean terminated = false;
/* 23:   */   
/* 24:   */   public LValueAssignmentExpressionRewriter(LValue lValue, AbstractAssignmentExpression lValueReplacement, Op03SimpleStatement source)
/* 25:   */   {
/* 26:19 */     this.lValue = lValue;
/* 27:20 */     this.lValueReplacement = lValueReplacement;
/* 28:21 */     this.source = source;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 32:   */   {
/* 33:30 */     if (this.terminated) {
/* 34:30 */       return expression;
/* 35:   */     }
/* 36:31 */     if ((expression instanceof BooleanOperation)) {
/* 37:32 */       return ((BooleanOperation)expression).applyLHSOnlyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 38:   */     }
/* 39:33 */     if ((expression instanceof TernaryExpression)) {
/* 40:34 */       return ((TernaryExpression)expression).applyConditionOnlyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/* 41:   */     }
/* 42:35 */     if ((expression instanceof LValueExpression))
/* 43:   */     {
/* 44:36 */       LValue lValue = ((LValueExpression)expression).getLValue();
/* 45:37 */       if (!lValue.equals(this.lValue)) {
/* 46:37 */         return expression;
/* 47:   */       }
/* 48:38 */       if (!ssaIdentifiers.isValidReplacement(lValue, statementContainer.getSSAIdentifiers())) {
/* 49:38 */         return expression;
/* 50:   */       }
/* 51:39 */       this.source.nopOut();
/* 52:40 */       this.terminated = true;
/* 53:41 */       return this.lValueReplacement;
/* 54:   */     }
/* 55:43 */     Expression res = super.rewriteExpression(expression, ssaIdentifiers, statementContainer, flags);
/* 56:44 */     if ((expression instanceof AbstractFunctionInvokation)) {
/* 57:45 */       this.terminated = true;
/* 58:   */     }
/* 59:47 */     return res;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public ConditionalExpression rewriteExpression(ConditionalExpression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 63:   */   {
/* 64:52 */     if (this.terminated) {
/* 65:52 */       return expression;
/* 66:   */     }
/* 67:53 */     return (ConditionalExpression)rewriteExpression(expression, ssaIdentifiers, statementContainer, flags);
/* 68:   */   }
/* 69:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentExpressionRewriter
 * JD-Core Version:    0.7.0.1
 */