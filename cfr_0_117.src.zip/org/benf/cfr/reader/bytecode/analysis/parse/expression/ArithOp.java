/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   4:    */ import org.benf.cfr.reader.bytecode.opcode.JVMInstr;
/*   5:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*   6:    */ 
/*   7:    */ public enum ArithOp
/*   8:    */ {
/*   9:  8 */   LCMP("LCMP", true, Precedence.WEAKEST),  DCMPL("DCMPL", true, Precedence.WEAKEST),  DCMPG("DCMPG", true, Precedence.WEAKEST),  FCMPL("FCMPL", true, Precedence.WEAKEST),  FCMPG("FCMPG", true, Precedence.WEAKEST),  PLUS("+", false, Precedence.ADD_SUB),  MINUS("-", false, Precedence.ADD_SUB),  MULTIPLY("*", false, Precedence.MUL_DIV_MOD),  DIVIDE("/", false, Precedence.MUL_DIV_MOD),  REM("%", false, Precedence.MUL_DIV_MOD),  OR("|", false, Precedence.BIT_OR),  AND("&", false, Precedence.BIT_AND),  SHR(">>", false, Precedence.BITWISE_SHIFT),  SHL("<<", false, Precedence.BITWISE_SHIFT),  SHRU(">>>", false, Precedence.BITWISE_SHIFT),  XOR("^", false, Precedence.BIT_XOR),  NEG("~", false, Precedence.UNARY_OTHER);
/*  10:    */   
/*  11:    */   private final String showAs;
/*  12:    */   private final boolean temporary;
/*  13:    */   private final Precedence precedence;
/*  14:    */   
/*  15:    */   private ArithOp(String showAs, boolean temporary, Precedence precedence)
/*  16:    */   {
/*  17: 31 */     this.showAs = showAs;
/*  18: 32 */     this.temporary = temporary;
/*  19: 33 */     this.precedence = precedence;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public String getShowAs()
/*  23:    */   {
/*  24: 37 */     return this.showAs;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public boolean isTemporary()
/*  28:    */   {
/*  29: 41 */     return this.temporary;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public Precedence getPrecedence()
/*  33:    */   {
/*  34: 45 */     return this.precedence;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static ArithOp getOpFor(JVMInstr instr)
/*  38:    */   {
/*  39: 49 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$opcode$JVMInstr[instr.ordinal()])
/*  40:    */     {
/*  41:    */     case 1: 
/*  42: 51 */       return LCMP;
/*  43:    */     case 2: 
/*  44: 53 */       return DCMPG;
/*  45:    */     case 3: 
/*  46: 55 */       return DCMPL;
/*  47:    */     case 4: 
/*  48: 57 */       return FCMPG;
/*  49:    */     case 5: 
/*  50: 59 */       return FCMPL;
/*  51:    */     case 6: 
/*  52:    */     case 7: 
/*  53:    */     case 8: 
/*  54:    */     case 9: 
/*  55: 64 */       return MINUS;
/*  56:    */     case 10: 
/*  57:    */     case 11: 
/*  58:    */     case 12: 
/*  59:    */     case 13: 
/*  60: 69 */       return MULTIPLY;
/*  61:    */     case 14: 
/*  62:    */     case 15: 
/*  63:    */     case 16: 
/*  64:    */     case 17: 
/*  65: 74 */       return PLUS;
/*  66:    */     case 18: 
/*  67:    */     case 19: 
/*  68:    */     case 20: 
/*  69:    */     case 21: 
/*  70: 79 */       return DIVIDE;
/*  71:    */     case 22: 
/*  72:    */     case 23: 
/*  73: 82 */       return OR;
/*  74:    */     case 24: 
/*  75:    */     case 25: 
/*  76: 85 */       return AND;
/*  77:    */     case 26: 
/*  78:    */     case 27: 
/*  79:    */     case 28: 
/*  80:    */     case 29: 
/*  81: 90 */       return REM;
/*  82:    */     case 30: 
/*  83:    */     case 31: 
/*  84: 93 */       return SHR;
/*  85:    */     case 32: 
/*  86:    */     case 33: 
/*  87: 96 */       return SHRU;
/*  88:    */     case 34: 
/*  89:    */     case 35: 
/*  90: 99 */       return SHL;
/*  91:    */     case 36: 
/*  92:    */     case 37: 
/*  93:102 */       return XOR;
/*  94:    */     }
/*  95:104 */     throw new ConfusedCFRException("Don't know arith op for " + instr);
/*  96:    */   }
/*  97:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithOp
 * JD-Core Version:    0.7.0.1
 */