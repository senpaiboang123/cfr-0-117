package org.benf.cfr.reader.bytecode.analysis.parse;

import java.util.Set;
import org.benf.cfr.reader.bytecode.analysis.opgraph.InstrIndex;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;

public abstract interface StatementContainer<T>
{
  public abstract T getStatement();
  
  public abstract T getTargetStatement(int paramInt);
  
  public abstract String getLabel();
  
  public abstract InstrIndex getIndex();
  
  public abstract void nopOut();
  
  public abstract void replaceStatement(T paramT);
  
  public abstract void nopOutConditional();
  
  public abstract SSAIdentifiers getSSAIdentifiers();
  
  public abstract Set<BlockIdentifier> getBlockIdentifiers();
  
  public abstract BlockIdentifier getBlockStarted();
  
  public abstract Set<BlockIdentifier> getBlocksEnded();
  
  public abstract void copyBlockInformationFrom(StatementContainer<T> paramStatementContainer);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer
 * JD-Core Version:    0.7.0.1
 */