/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.rewriters;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Map;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  7:   */ import org.benf.cfr.reader.util.ListFactory;
/*  8:   */ import org.benf.cfr.reader.util.MapFactory;
/*  9:   */ 
/* 10:   */ public class CloneHelper
/* 11:   */ {
/* 12:   */   private final Map<Expression, Expression> expressionMap;
/* 13:   */   private final Map<LValue, LValue> lValueMap;
/* 14:   */   
/* 15:   */   public CloneHelper()
/* 16:   */   {
/* 17:17 */     this.expressionMap = MapFactory.newMap();
/* 18:18 */     this.lValueMap = MapFactory.newMap();
/* 19:   */   }
/* 20:   */   
/* 21:   */   public CloneHelper(Map<Expression, Expression> expressionMap, Map<LValue, LValue> lValueMap)
/* 22:   */   {
/* 23:22 */     this.expressionMap = expressionMap;
/* 24:23 */     this.lValueMap = lValueMap;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public CloneHelper(Map<Expression, Expression> expressionMap)
/* 28:   */   {
/* 29:27 */     this.expressionMap = expressionMap;
/* 30:28 */     this.lValueMap = MapFactory.newMap();
/* 31:   */   }
/* 32:   */   
/* 33:   */   public <X extends DeepCloneable<X>> List<X> replaceOrClone(List<X> in)
/* 34:   */   {
/* 35:32 */     List<X> res = ListFactory.newList();
/* 36:33 */     for (X i : in) {
/* 37:34 */       res.add(i.outerDeepClone(this));
/* 38:   */     }
/* 39:36 */     return res;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public Expression replaceOrClone(Expression source)
/* 43:   */   {
/* 44:40 */     Expression replacement = (Expression)this.expressionMap.get(source);
/* 45:41 */     if (replacement == null) {
/* 46:41 */       return (Expression)source.deepClone(this);
/* 47:   */     }
/* 48:42 */     return replacement;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public LValue replaceOrClone(LValue source)
/* 52:   */   {
/* 53:46 */     LValue replacement = (LValue)this.lValueMap.get(source);
/* 54:47 */     if (replacement == null) {
/* 55:47 */       return (LValue)source.deepClone(this);
/* 56:   */     }
/* 57:48 */     return replacement;
/* 58:   */   }
/* 59:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper
 * JD-Core Version:    0.7.0.1
 */