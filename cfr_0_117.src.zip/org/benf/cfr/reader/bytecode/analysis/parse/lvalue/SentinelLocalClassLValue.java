/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.lvalue;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentCollector;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifierFactory;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  15:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  16:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  17:    */ 
/*  18:    */ public class SentinelLocalClassLValue
/*  19:    */   extends AbstractLValue
/*  20:    */ {
/*  21:    */   private final JavaTypeInstance localClassType;
/*  22:    */   
/*  23:    */   public SentinelLocalClassLValue(JavaTypeInstance localClassType)
/*  24:    */   {
/*  25: 25 */     super(null);
/*  26: 26 */     this.localClassType = localClassType;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void markFinal() {}
/*  30:    */   
/*  31:    */   public boolean isFinal()
/*  32:    */   {
/*  33: 36 */     return false;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public void collectTypeUsages(TypeUsageCollector collector) {}
/*  37:    */   
/*  38:    */   public int getNumberOfCreators()
/*  39:    */   {
/*  40: 46 */     throw new UnsupportedOperationException();
/*  41:    */   }
/*  42:    */   
/*  43:    */   public <T> void collectLValueAssignments(Expression assignedTo, StatementContainer<T> statementContainer, LValueAssignmentCollector<T> lValueAssigmentCollector)
/*  44:    */   {
/*  45: 51 */     throw new UnsupportedOperationException();
/*  46:    */   }
/*  47:    */   
/*  48:    */   public SSAIdentifiers<LValue> collectVariableMutation(SSAIdentifierFactory<LValue> ssaIdentifierFactory)
/*  49:    */   {
/*  50: 56 */     throw new UnsupportedOperationException();
/*  51:    */   }
/*  52:    */   
/*  53:    */   public LValue replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  54:    */   {
/*  55: 61 */     throw new UnsupportedOperationException();
/*  56:    */   }
/*  57:    */   
/*  58:    */   public LValue applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  59:    */   {
/*  60: 66 */     throw new UnsupportedOperationException();
/*  61:    */   }
/*  62:    */   
/*  63:    */   public LValue deepClone(CloneHelper cloneHelper)
/*  64:    */   {
/*  65: 71 */     throw new UnsupportedOperationException();
/*  66:    */   }
/*  67:    */   
/*  68:    */   public Precedence getPrecedence()
/*  69:    */   {
/*  70: 76 */     return Precedence.HIGHEST;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public Dumper dumpInner(Dumper d)
/*  74:    */   {
/*  75: 81 */     throw new UnsupportedOperationException();
/*  76:    */   }
/*  77:    */   
/*  78:    */   public JavaTypeInstance getLocalClassType()
/*  79:    */   {
/*  80: 85 */     return this.localClassType;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public boolean equals(Object o)
/*  84:    */   {
/*  85: 90 */     if (this == o) {
/*  86: 90 */       return true;
/*  87:    */     }
/*  88: 91 */     if ((o == null) || (getClass() != o.getClass())) {
/*  89: 91 */       return false;
/*  90:    */     }
/*  91: 93 */     SentinelLocalClassLValue that = (SentinelLocalClassLValue)o;
/*  92: 95 */     if (this.localClassType != null ? !this.localClassType.equals(that.localClassType) : that.localClassType != null) {
/*  93: 96 */       return false;
/*  94:    */     }
/*  95: 98 */     return true;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public int hashCode()
/*  99:    */   {
/* 100:103 */     return this.localClassType != null ? this.localClassType.hashCode() : 0;
/* 101:    */   }
/* 102:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.lvalue.SentinelLocalClassLValue
 * JD-Core Version:    0.7.0.1
 */