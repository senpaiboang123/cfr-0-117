package org.benf.cfr.reader.bytecode.analysis.parse.utils;

import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;

public abstract interface LValueAssignmentCollector<T>
{
  public abstract void collect(StackSSALabel paramStackSSALabel, StatementContainer<T> paramStatementContainer, Expression paramExpression);
  
  public abstract void collectMultiUse(StackSSALabel paramStackSSALabel, StatementContainer<T> paramStatementContainer, Expression paramExpression);
  
  public abstract void collectMutatedLValue(LValue paramLValue, StatementContainer<T> paramStatementContainer, Expression paramExpression);
  
  public abstract void collectLocalVariableAssignment(LocalVariable paramLocalVariable, StatementContainer<T> paramStatementContainer, Expression paramExpression);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentCollector
 * JD-Core Version:    0.7.0.1
 */