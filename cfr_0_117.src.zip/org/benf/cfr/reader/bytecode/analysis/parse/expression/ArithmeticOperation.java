/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.PrimitiveBoxingRewriter;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface.BoxingProcessor;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral.LiteralType;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  22:    */ import org.benf.cfr.reader.entities.exceptions.BasicExceptions;
/*  23:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/*  24:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  25:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  26:    */ import org.benf.cfr.reader.util.Troolean;
/*  27:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  28:    */ 
/*  29:    */ public class ArithmeticOperation
/*  30:    */   extends AbstractExpression
/*  31:    */   implements BoxingProcessor
/*  32:    */ {
/*  33:    */   private Expression lhs;
/*  34:    */   private Expression rhs;
/*  35:    */   private final ArithOp op;
/*  36:    */   
/*  37:    */   public ArithmeticOperation(Expression lhs, Expression rhs, ArithOp op)
/*  38:    */   {
/*  39: 32 */     super(inferredType(lhs.getInferredJavaType(), rhs.getInferredJavaType(), op));
/*  40: 33 */     this.lhs = lhs;
/*  41: 34 */     this.rhs = rhs;
/*  42: 35 */     this.op = op;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public ArithmeticOperation(InferredJavaType knownType, Expression lhs, Expression rhs, ArithOp op)
/*  46:    */   {
/*  47: 39 */     super(knownType);
/*  48: 40 */     this.lhs = lhs;
/*  49: 41 */     this.rhs = rhs;
/*  50: 42 */     this.op = op;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  54:    */   {
/*  55: 47 */     this.lhs.collectTypeUsages(collector);
/*  56: 48 */     this.rhs.collectTypeUsages(collector);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  60:    */   {
/*  61: 53 */     return new ArithmeticOperation(cloneHelper.replaceOrClone(this.lhs), cloneHelper.replaceOrClone(this.rhs), this.op);
/*  62:    */   }
/*  63:    */   
/*  64:    */   private static InferredJavaType inferredType(InferredJavaType a, InferredJavaType b, ArithOp op)
/*  65:    */   {
/*  66: 57 */     InferredJavaType.useInArithOp(a, b, op);
/*  67: 58 */     RawJavaType rawJavaType = a.getRawType();
/*  68: 61 */     if (rawJavaType.getStackType().equals(StackType.INT)) {
/*  69: 62 */       switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$expression$ArithOp[op.ordinal()])
/*  70:    */       {
/*  71:    */       case 1: 
/*  72:    */       case 2: 
/*  73:    */       case 3: 
/*  74: 66 */         if (rawJavaType.equals(RawJavaType.BOOLEAN)) {
/*  75:    */           break;
/*  76:    */         }
/*  77:    */       default: 
/*  78: 68 */         rawJavaType = RawJavaType.INT;
/*  79:    */       }
/*  80:    */     }
/*  81: 72 */     return new InferredJavaType(rawJavaType, InferredJavaType.Source.OPERATION);
/*  82:    */   }
/*  83:    */   
/*  84:    */   public Precedence getPrecedence()
/*  85:    */   {
/*  86: 77 */     return this.op.getPrecedence();
/*  87:    */   }
/*  88:    */   
/*  89:    */   public Dumper dumpInner(Dumper d)
/*  90:    */   {
/*  91: 82 */     this.lhs.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.TRUE);
/*  92: 83 */     d.print(" " + this.op.getShowAs() + " ");
/*  93: 84 */     this.rhs.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.FALSE);
/*  94: 85 */     return d;
/*  95:    */   }
/*  96:    */   
/*  97:    */   private boolean isLValueExprFor(LValueExpression expression, LValue lValue)
/*  98:    */   {
/*  99: 89 */     LValue contained = expression.getLValue();
/* 100: 90 */     return lValue.equals(contained);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public boolean isLiteralFunctionOf(LValue lValue)
/* 104:    */   {
/* 105: 97 */     if (((this.lhs instanceof LValueExpression)) && ((this.rhs instanceof Literal))) {
/* 106: 98 */       return isLValueExprFor((LValueExpression)this.lhs, lValue);
/* 107:    */     }
/* 108:100 */     if (((this.rhs instanceof LValueExpression)) && ((this.lhs instanceof Literal))) {
/* 109:101 */       return isLValueExprFor((LValueExpression)this.rhs, lValue);
/* 110:    */     }
/* 111:103 */     return false;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public boolean isXorM1()
/* 115:    */   {
/* 116:107 */     return (this.op == ArithOp.XOR) && (this.rhs.equals(Literal.MINUS_ONE));
/* 117:    */   }
/* 118:    */   
/* 119:    */   public Expression getReplacementXorM1()
/* 120:    */   {
/* 121:111 */     return new ArithmeticMonOperation(this.lhs, ArithOp.NEG);
/* 122:    */   }
/* 123:    */   
/* 124:    */   public boolean isMutationOf(LValue lValue)
/* 125:    */   {
/* 126:115 */     if (!(this.lhs instanceof LValueExpression)) {
/* 127:115 */       return false;
/* 128:    */     }
/* 129:116 */     if (!isLValueExprFor((LValueExpression)this.lhs, lValue)) {
/* 130:116 */       return false;
/* 131:    */     }
/* 132:117 */     if (this.op.isTemporary()) {
/* 133:117 */       return false;
/* 134:    */     }
/* 135:118 */     return true;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public AbstractMutatingAssignmentExpression getMutationOf(LValue lValue)
/* 139:    */   {
/* 140:122 */     if (!isMutationOf(lValue)) {
/* 141:123 */       throw new ConfusedCFRException("Can't get a mutation where none exists");
/* 142:    */     }
/* 143:125 */     if ((this.lhs.getInferredJavaType().getJavaTypeInstance() != RawJavaType.BOOLEAN) && (Literal.equalsAnyOne(this.rhs))) {
/* 144:127 */       switch (this.op)
/* 145:    */       {
/* 146:    */       case PLUS: 
/* 147:    */       case MINUS: 
/* 148:130 */         return new ArithmeticPreMutationOperation(lValue, this.op);
/* 149:    */       }
/* 150:    */     }
/* 151:133 */     return new ArithmeticMutationOperation(lValue, this.rhs, this.op);
/* 152:    */   }
/* 153:    */   
/* 154:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/* 155:    */   {
/* 156:138 */     this.rhs = this.rhs.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/* 157:139 */     this.lhs = this.lhs.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/* 158:140 */     return this;
/* 159:    */   }
/* 160:    */   
/* 161:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 162:    */   {
/* 163:145 */     this.lhs = expressionRewriter.rewriteExpression(this.lhs, ssaIdentifiers, statementContainer, flags);
/* 164:146 */     this.rhs = expressionRewriter.rewriteExpression(this.rhs, ssaIdentifiers, statementContainer, flags);
/* 165:147 */     return this;
/* 166:    */   }
/* 167:    */   
/* 168:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 169:    */   {
/* 170:152 */     this.rhs = expressionRewriter.rewriteExpression(this.rhs, ssaIdentifiers, statementContainer, flags);
/* 171:153 */     this.lhs = expressionRewriter.rewriteExpression(this.lhs, ssaIdentifiers, statementContainer, flags);
/* 172:154 */     return this;
/* 173:    */   }
/* 174:    */   
/* 175:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/* 176:    */   {
/* 177:159 */     this.lhs.collectUsedLValues(lValueUsageCollector);
/* 178:160 */     this.rhs.collectUsedLValues(lValueUsageCollector);
/* 179:    */   }
/* 180:    */   
/* 181:    */   public boolean canPushDownInto()
/* 182:    */   {
/* 183:165 */     return this.op.isTemporary();
/* 184:    */   }
/* 185:    */   
/* 186:    */   public boolean equals(Object o)
/* 187:    */   {
/* 188:170 */     if (o == this) {
/* 189:170 */       return true;
/* 190:    */     }
/* 191:171 */     if (!(o instanceof ArithmeticOperation)) {
/* 192:171 */       return false;
/* 193:    */     }
/* 194:172 */     ArithmeticOperation other = (ArithmeticOperation)o;
/* 195:173 */     if (this.op != other.op) {
/* 196:173 */       return false;
/* 197:    */     }
/* 198:174 */     if (!this.lhs.equals(other.lhs)) {
/* 199:174 */       return false;
/* 200:    */     }
/* 201:175 */     if (!this.rhs.equals(other.rhs)) {
/* 202:175 */       return false;
/* 203:    */     }
/* 204:176 */     return true;
/* 205:    */   }
/* 206:    */   
/* 207:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 208:    */   {
/* 209:181 */     if (o == null) {
/* 210:181 */       return false;
/* 211:    */     }
/* 212:182 */     if (o == this) {
/* 213:182 */       return true;
/* 214:    */     }
/* 215:183 */     if (getClass() != o.getClass()) {
/* 216:183 */       return false;
/* 217:    */     }
/* 218:184 */     ArithmeticOperation other = (ArithmeticOperation)o;
/* 219:185 */     if (this.op != other.op) {
/* 220:185 */       return false;
/* 221:    */     }
/* 222:186 */     if (!constraint.equivalent(this.lhs, other.lhs)) {
/* 223:186 */       return false;
/* 224:    */     }
/* 225:187 */     if (!constraint.equivalent(this.rhs, other.rhs)) {
/* 226:187 */       return false;
/* 227:    */     }
/* 228:188 */     return true;
/* 229:    */   }
/* 230:    */   
/* 231:    */   private static CompOp rewriteXCMPCompOp(CompOp from, int on)
/* 232:    */   {
/* 233:193 */     if (on == 0) {
/* 234:193 */       return from;
/* 235:    */     }
/* 236:194 */     if (on < 0)
/* 237:    */     {
/* 238:195 */       switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$expression$CompOp[from.ordinal()])
/* 239:    */       {
/* 240:    */       case 1: 
/* 241:197 */         throw new IllegalStateException("Bad CMP");
/* 242:    */       case 2: 
/* 243:199 */         return CompOp.LT;
/* 244:    */       case 3: 
/* 245:201 */         throw new IllegalStateException("Bad CMP");
/* 246:    */       case 4: 
/* 247:203 */         return CompOp.GTE;
/* 248:    */       case 5: 
/* 249:205 */         return CompOp.LT;
/* 250:    */       case 6: 
/* 251:207 */         return CompOp.GTE;
/* 252:    */       }
/* 253:209 */       throw new IllegalStateException("Unknown enum");
/* 254:    */     }
/* 255:212 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$expression$CompOp[from.ordinal()])
/* 256:    */     {
/* 257:    */     case 1: 
/* 258:214 */       return CompOp.LTE;
/* 259:    */     case 2: 
/* 260:216 */       throw new IllegalStateException("Bad CMP");
/* 261:    */     case 3: 
/* 262:218 */       return CompOp.GT;
/* 263:    */     case 4: 
/* 264:220 */       throw new IllegalStateException("Bad CMP");
/* 265:    */     case 5: 
/* 266:222 */       return CompOp.GT;
/* 267:    */     case 6: 
/* 268:224 */       return CompOp.LTE;
/* 269:    */     }
/* 270:226 */     throw new IllegalStateException("Unknown enum");
/* 271:    */   }
/* 272:    */   
/* 273:    */   public boolean canThrow(ExceptionCheck caught)
/* 274:    */   {
/* 275:233 */     return (this.lhs.canThrow(caught)) || (this.rhs.canThrow(caught)) || (caught.checkAgainst(BasicExceptions.instances));
/* 276:    */   }
/* 277:    */   
/* 278:    */   public boolean rewriteBoxing(PrimitiveBoxingRewriter boxingRewriter)
/* 279:    */   {
/* 280:240 */     this.lhs = boxingRewriter.sugarUnboxing(this.lhs);
/* 281:241 */     this.rhs = boxingRewriter.sugarUnboxing(this.rhs);
/* 282:    */     
/* 283:    */ 
/* 284:    */ 
/* 285:    */ 
/* 286:    */ 
/* 287:    */ 
/* 288:    */ 
/* 289:    */ 
/* 290:250 */     return false;
/* 291:    */   }
/* 292:    */   
/* 293:    */   public void applyNonArgExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags) {}
/* 294:    */   
/* 295:    */   public Expression getLhs()
/* 296:    */   {
/* 297:258 */     return this.lhs;
/* 298:    */   }
/* 299:    */   
/* 300:    */   public Expression getRhs()
/* 301:    */   {
/* 302:262 */     return this.rhs;
/* 303:    */   }
/* 304:    */   
/* 305:    */   public ArithOp getOp()
/* 306:    */   {
/* 307:266 */     return this.op;
/* 308:    */   }
/* 309:    */   
/* 310:    */   public Expression pushDown(Expression toPush, Expression parent)
/* 311:    */   {
/* 312:275 */     if (!(parent instanceof ComparisonOperation)) {
/* 313:275 */       return null;
/* 314:    */     }
/* 315:276 */     if (!this.op.isTemporary()) {
/* 316:276 */       return null;
/* 317:    */     }
/* 318:277 */     if (!(toPush instanceof Literal)) {
/* 319:278 */       throw new ConfusedCFRException("Pushing with a non-literal as pushee.");
/* 320:    */     }
/* 321:280 */     ComparisonOperation comparisonOperation = (ComparisonOperation)parent;
/* 322:281 */     CompOp compOp = comparisonOperation.getOp();
/* 323:282 */     Literal literal = (Literal)toPush;
/* 324:283 */     TypedLiteral typedLiteral = literal.getValue();
/* 325:284 */     if (typedLiteral.getType() != TypedLiteral.LiteralType.Integer) {
/* 326:285 */       throw new ConfusedCFRException("<xCMP> , non integer!");
/* 327:    */     }
/* 328:287 */     int litVal = ((Integer)typedLiteral.getValue()).intValue();
/* 329:288 */     switch (litVal)
/* 330:    */     {
/* 331:    */     case -1: 
/* 332:    */     case 0: 
/* 333:    */     case 1: 
/* 334:    */       break;
/* 335:    */     default: 
/* 336:294 */       throw new ConfusedCFRException("Invalid literal value " + litVal + " in xCMP");
/* 337:    */     }
/* 338:299 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$expression$ArithOp[this.op.ordinal()])
/* 339:    */     {
/* 340:    */     case 6: 
/* 341:    */     case 7: 
/* 342:    */     case 8: 
/* 343:    */     case 9: 
/* 344:    */     case 10: 
/* 345:    */       break;
/* 346:    */     default: 
/* 347:307 */       throw new ConfusedCFRException("Shouldn't be here.");
/* 348:    */     }
/* 349:319 */     compOp = rewriteXCMPCompOp(compOp, litVal);
/* 350:320 */     return new ComparisonOperation(this.lhs, this.rhs, compOp);
/* 351:    */   }
/* 352:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithmeticOperation
 * JD-Core Version:    0.7.0.1
 */