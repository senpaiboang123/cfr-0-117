/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.rewriters;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithOp;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithmeticOperation;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CastExpression;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationSimple;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.MemberFunctionInvokation;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StackSSALabel;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.TypeConstants;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  22:    */ import org.benf.cfr.reader.util.ClassFileVersion;
/*  23:    */ import org.benf.cfr.reader.util.ListFactory;
/*  24:    */ import org.benf.cfr.reader.util.getopt.Options;
/*  25:    */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*  26:    */ 
/*  27:    */ public class StringBuilderRewriter
/*  28:    */   implements ExpressionRewriter
/*  29:    */ {
/*  30:    */   private final boolean stringBuilderEnabled;
/*  31:    */   private final boolean stringBufferEnabled;
/*  32:    */   
/*  33:    */   public StringBuilderRewriter(Options options, ClassFileVersion classFileVersion)
/*  34:    */   {
/*  35: 27 */     this.stringBufferEnabled = ((Boolean)options.getOption(OptionsImpl.SUGAR_STRINGBUFFER, classFileVersion)).booleanValue();
/*  36: 28 */     this.stringBuilderEnabled = ((Boolean)options.getOption(OptionsImpl.SUGAR_STRINGBUILDER, classFileVersion)).booleanValue();
/*  37:    */   }
/*  38:    */   
/*  39:    */   public Expression rewriteExpression(Expression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  40:    */   {
/*  41: 33 */     if ((expression instanceof MemberFunctionInvokation))
/*  42:    */     {
/*  43: 34 */       MemberFunctionInvokation memberFunctionInvokation = (MemberFunctionInvokation)expression;
/*  44: 35 */       if ("toString".equals(memberFunctionInvokation.getName()))
/*  45:    */       {
/*  46: 36 */         Expression lhs = memberFunctionInvokation.getObject();
/*  47: 37 */         Expression result = testAppendChain(lhs);
/*  48: 38 */         if (result != null) {
/*  49: 38 */           return result;
/*  50:    */         }
/*  51:    */       }
/*  52:    */     }
/*  53: 41 */     return expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void handleStatement(StatementContainer statementContainer) {}
/*  57:    */   
/*  58:    */   public ConditionalExpression rewriteExpression(ConditionalExpression expression, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  59:    */   {
/*  60: 51 */     Expression res = expression.applyExpressionRewriter(this, ssaIdentifiers, statementContainer, flags);
/*  61: 52 */     return (ConditionalExpression)res;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public LValue rewriteExpression(LValue lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  65:    */   {
/*  66: 63 */     return lValue;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public StackSSALabel rewriteExpression(StackSSALabel lValue, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  70:    */   {
/*  71: 68 */     return lValue;
/*  72:    */   }
/*  73:    */   
/*  74:    */   private Expression testAppendChain(Expression lhs)
/*  75:    */   {
/*  76: 72 */     List<Expression> reverseAppendChain = ListFactory.newList();
/*  77:    */     do
/*  78:    */     {
/*  79: 74 */       if ((lhs instanceof MemberFunctionInvokation))
/*  80:    */       {
/*  81: 75 */         MemberFunctionInvokation memberFunctionInvokation = (MemberFunctionInvokation)lhs;
/*  82: 76 */         if ((memberFunctionInvokation.getName().equals("append")) && (memberFunctionInvokation.getArgs().size() == 1))
/*  83:    */         {
/*  84: 78 */           lhs = memberFunctionInvokation.getObject();
/*  85: 79 */           Expression e = memberFunctionInvokation.getAppropriatelyCastArgument(0);
/*  86: 80 */           if ((e instanceof CastExpression))
/*  87:    */           {
/*  88: 81 */             Expression ce = ((CastExpression)e).getChild();
/*  89: 82 */             if (ce.getInferredJavaType().getJavaTypeInstance().implicitlyCastsTo(e.getInferredJavaType().getJavaTypeInstance(), null)) {
/*  90: 83 */               e = ce;
/*  91:    */             }
/*  92:    */           }
/*  93: 86 */           reverseAppendChain.add(e);
/*  94:    */         }
/*  95:    */         else
/*  96:    */         {
/*  97: 88 */           return null;
/*  98:    */         }
/*  99:    */       }
/* 100:    */       else
/* 101:    */       {
/* 102: 90 */         if ((lhs instanceof ConstructorInvokationSimple))
/* 103:    */         {
/* 104: 91 */           ConstructorInvokationSimple newObject = (ConstructorInvokationSimple)lhs;
/* 105: 92 */           String rawName = newObject.getTypeInstance().getRawName();
/* 106: 93 */           if (((this.stringBuilderEnabled) && (rawName.equals("java.lang.StringBuilder"))) || ((this.stringBufferEnabled) && (rawName.equals("java.lang.StringBuffer"))))
/* 107:    */           {
/* 108: 97 */             switch (newObject.getArgs().size())
/* 109:    */             {
/* 110:    */             default: 
/* 111: 99 */               return null;
/* 112:    */             case 1: 
/* 113:101 */               Expression e = (Expression)newObject.getArgs().get(0);
/* 114:102 */               String typeName = e.getInferredJavaType().getJavaTypeInstance().getRawName();
/* 115:103 */               if (typeName.equals("java.lang.String"))
/* 116:    */               {
/* 117:105 */                 if ((e instanceof CastExpression))
/* 118:    */                 {
/* 119:106 */                   Expression ce = ((CastExpression)e).getChild();
/* 120:107 */                   if (ce.getInferredJavaType().getJavaTypeInstance().implicitlyCastsTo(e.getInferredJavaType().getJavaTypeInstance(), null)) {
/* 121:108 */                     e = ce;
/* 122:    */                   }
/* 123:    */                 }
/* 124:111 */                 reverseAppendChain.add(e);
/* 125:    */               }
/* 126:    */               else
/* 127:    */               {
/* 128:113 */                 return null;
/* 129:    */               }
/* 130:    */               break;
/* 131:    */             }
/* 132:118 */             return genStringConcat(reverseAppendChain);
/* 133:    */           }
/* 134:121 */           return null;
/* 135:    */         }
/* 136:124 */         return null;
/* 137:    */       }
/* 138:126 */     } while (lhs != null);
/* 139:127 */     return null;
/* 140:    */   }
/* 141:    */   
/* 142:    */   private Expression genStringConcat(List<Expression> revList)
/* 143:    */   {
/* 144:132 */     JavaTypeInstance lastType = ((Expression)revList.get(revList.size() - 1)).getInferredJavaType().getJavaTypeInstance();
/* 145:133 */     if ((lastType instanceof RawJavaType)) {
/* 146:134 */       revList.add(new Literal(TypedLiteral.getString("\"\"")));
/* 147:    */     }
/* 148:137 */     int x = revList.size() - 1;
/* 149:138 */     if (x < 0) {
/* 150:138 */       return null;
/* 151:    */     }
/* 152:139 */     Expression head = (Expression)revList.get(x);
/* 153:    */     
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:144 */     InferredJavaType inferredJavaType = new InferredJavaType(TypeConstants.STRING, InferredJavaType.Source.STRING_TRANSFORM, true);
/* 158:145 */     for (x--; x >= 0; x--)
/* 159:    */     {
/* 160:146 */       Expression appendee = (Expression)revList.get(x);
/* 161:    */       
/* 162:    */ 
/* 163:    */ 
/* 164:150 */       head = new ArithmeticOperation(inferredJavaType, head, appendee, ArithOp.PLUS);
/* 165:    */     }
/* 166:152 */     return head;
/* 167:    */   }
/* 168:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.rewriters.StringBuilderRewriter
 * JD-Core Version:    0.7.0.1
 */