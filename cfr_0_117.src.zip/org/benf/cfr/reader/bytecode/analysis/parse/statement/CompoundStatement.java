/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueAssignmentCollector;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 14:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/* 15:   */ import org.benf.cfr.reader.util.ListFactory;
/* 16:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 17:   */ 
/* 18:   */ public class CompoundStatement
/* 19:   */   extends AbstractStatement
/* 20:   */ {
/* 21:   */   private List<Statement> statements;
/* 22:   */   
/* 23:   */   public CompoundStatement(Statement... statements)
/* 24:   */   {
/* 25:23 */     this.statements = ListFactory.newList(statements);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public Dumper dump(Dumper dumper)
/* 29:   */   {
/* 30:28 */     dumper.print("{\n");
/* 31:29 */     for (Statement statement : this.statements) {
/* 32:30 */       statement.dump(dumper);
/* 33:   */     }
/* 34:32 */     dumper.print("}\n");
/* 35:33 */     return dumper;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void collectLValueAssignments(LValueAssignmentCollector<Statement> lValueAssigmentCollector)
/* 39:   */   {
/* 40:38 */     throw new ConfusedCFRException("Should not be using compound statements here");
/* 41:   */   }
/* 42:   */   
/* 43:   */   public LValue getCreatedLValue()
/* 44:   */   {
/* 45:43 */     throw new ConfusedCFRException("Should not be using compound statements here");
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/* 49:   */   {
/* 50:48 */     throw new ConfusedCFRException("Should not be using compound statements here");
/* 51:   */   }
/* 52:   */   
/* 53:   */   public Expression getRValue()
/* 54:   */   {
/* 55:53 */     throw new ConfusedCFRException("Should not be using compound statements here");
/* 56:   */   }
/* 57:   */   
/* 58:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers)
/* 59:   */   {
/* 60:58 */     throw new ConfusedCFRException("Should not be using compound statements here");
/* 61:   */   }
/* 62:   */   
/* 63:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/* 64:   */   {
/* 65:63 */     throw new ConfusedCFRException("Should not be using compound statements here");
/* 66:   */   }
/* 67:   */   
/* 68:   */   public boolean isCompound()
/* 69:   */   {
/* 70:68 */     return true;
/* 71:   */   }
/* 72:   */   
/* 73:   */   public List<Statement> getCompoundParts()
/* 74:   */   {
/* 75:73 */     return this.statements;
/* 76:   */   }
/* 77:   */   
/* 78:   */   public StructuredStatement getStructuredStatement()
/* 79:   */   {
/* 80:78 */     throw new UnsupportedOperationException();
/* 81:   */   }
/* 82:   */   
/* 83:   */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 84:   */   {
/* 85:83 */     if (o == null) {
/* 86:83 */       return false;
/* 87:   */     }
/* 88:84 */     if (o == this) {
/* 89:84 */       return true;
/* 90:   */     }
/* 91:85 */     if (getClass() != o.getClass()) {
/* 92:85 */       return false;
/* 93:   */     }
/* 94:86 */     CompoundStatement other = (CompoundStatement)o;
/* 95:87 */     if (!constraint.equivalent(this.statements, other.statements)) {
/* 96:87 */       return false;
/* 97:   */     }
/* 98:88 */     return true;
/* 99:   */   }
/* :0:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.CompoundStatement
 * JD-Core Version:    0.7.0.1
 */