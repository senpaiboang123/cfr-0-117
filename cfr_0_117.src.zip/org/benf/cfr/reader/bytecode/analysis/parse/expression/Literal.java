/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import java.util.Map;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  16:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/*  17:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  18:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  19:    */ 
/*  20:    */ public class Literal
/*  21:    */   extends AbstractExpression
/*  22:    */ {
/*  23: 19 */   public static final Literal FALSE = new Literal(TypedLiteral.getBoolean(0));
/*  24: 20 */   public static final Literal TRUE = new Literal(TypedLiteral.getBoolean(1));
/*  25: 21 */   public static final Literal MINUS_ONE = new Literal(TypedLiteral.getInt(-1));
/*  26: 22 */   public static final Literal NULL = new Literal(TypedLiteral.getNull());
/*  27: 25 */   public static final Literal INT_ZERO = new Literal(TypedLiteral.getInt(0));
/*  28: 26 */   public static final Literal INT_ONE = new Literal(TypedLiteral.getInt(1));
/*  29: 27 */   private static final Literal LONG_ONE = new Literal(TypedLiteral.getLong(1L));
/*  30:    */   private final TypedLiteral value;
/*  31:    */   
/*  32:    */   public Literal(TypedLiteral value)
/*  33:    */   {
/*  34: 33 */     super(value.getInferredJavaType());
/*  35: 34 */     this.value = value;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public Precedence getPrecedence()
/*  39:    */   {
/*  40: 39 */     return Precedence.HIGHEST;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public Dumper dumpInner(Dumper d)
/*  44:    */   {
/*  45: 44 */     return d.dump(this.value);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  49:    */   {
/*  50: 49 */     this.value.collectTypeUsages(collector);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public boolean isSimple()
/*  54:    */   {
/*  55: 54 */     return true;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  59:    */   {
/*  60: 59 */     return this;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  64:    */   {
/*  65: 64 */     return this;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  69:    */   {
/*  70: 69 */     return this;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  74:    */   {
/*  75: 74 */     return this;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector) {}
/*  79:    */   
/*  80:    */   public TypedLiteral getValue()
/*  81:    */   {
/*  82: 82 */     return this.value;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public boolean canThrow(ExceptionCheck caught)
/*  86:    */   {
/*  87: 87 */     return false;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public boolean equals(Object o)
/*  91:    */   {
/*  92: 92 */     if (o == this) {
/*  93: 92 */       return true;
/*  94:    */     }
/*  95: 93 */     if (!(o instanceof Literal)) {
/*  96: 93 */       return false;
/*  97:    */     }
/*  98: 94 */     Literal other = (Literal)o;
/*  99: 95 */     return this.value.equals(other.value);
/* 100:    */   }
/* 101:    */   
/* 102:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 103:    */   {
/* 104:100 */     if (o == null) {
/* 105:100 */       return false;
/* 106:    */     }
/* 107:101 */     if (o == this) {
/* 108:101 */       return true;
/* 109:    */     }
/* 110:102 */     if (getClass() != o.getClass()) {
/* 111:102 */       return false;
/* 112:    */     }
/* 113:103 */     Literal other = (Literal)o;
/* 114:104 */     if (!constraint.equivalent(this.value, other.value)) {
/* 115:104 */       return false;
/* 116:    */     }
/* 117:105 */     return true;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public Literal getComputedLiteral(Map<LValue, Literal> display)
/* 121:    */   {
/* 122:110 */     return this;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public static boolean equalsAnyOne(Expression expression)
/* 126:    */   {
/* 127:114 */     return (expression.equals(INT_ONE)) || (expression.equals(LONG_ONE));
/* 128:    */   }
/* 129:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal
 * JD-Core Version:    0.7.0.1
 */