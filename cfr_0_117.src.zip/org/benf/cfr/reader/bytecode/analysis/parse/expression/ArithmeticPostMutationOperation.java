/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  14:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  15:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  16:    */ 
/*  17:    */ public class ArithmeticPostMutationOperation
/*  18:    */   extends AbstractMutatingAssignmentExpression
/*  19:    */ {
/*  20:    */   private LValue mutated;
/*  21:    */   private final ArithOp op;
/*  22:    */   
/*  23:    */   public ArithmeticPostMutationOperation(LValue mutated, ArithOp op)
/*  24:    */   {
/*  25: 22 */     super(mutated.getInferredJavaType());
/*  26: 23 */     this.mutated = mutated;
/*  27: 24 */     this.op = op;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public void collectTypeUsages(TypeUsageCollector collector) {}
/*  31:    */   
/*  32:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  33:    */   {
/*  34: 33 */     return new ArithmeticPostMutationOperation(cloneHelper.replaceOrClone(this.mutated), this.op);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public LValue getUpdatedLValue()
/*  38:    */   {
/*  39: 38 */     return this.mutated;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public Precedence getPrecedence()
/*  43:    */   {
/*  44: 43 */     return Precedence.UNARY_POST;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public Dumper dumpInner(Dumper d)
/*  48:    */   {
/*  49: 48 */     return d.dump(this.mutated).print(this.op == ArithOp.PLUS ? "++" : "--");
/*  50:    */   }
/*  51:    */   
/*  52:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  53:    */   {
/*  54: 53 */     return this;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  58:    */   {
/*  59: 58 */     this.mutated = expressionRewriter.rewriteExpression(this.mutated, ssaIdentifiers, statementContainer, ExpressionRewriterFlags.LANDRVALUE);
/*  60: 59 */     return this;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  64:    */   {
/*  65: 64 */     return applyExpressionRewriter(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public ArithmeticPostMutationOperation getPostMutation()
/*  69:    */   {
/*  70: 69 */     throw new IllegalStateException();
/*  71:    */   }
/*  72:    */   
/*  73:    */   public boolean isSelfMutatingOp1(LValue lValue, ArithOp arithOp)
/*  74:    */   {
/*  75: 74 */     return (this.mutated.equals(lValue)) && (this.op == arithOp);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/*  79:    */   {
/*  80: 80 */     lValueUsageCollector.collect(this.mutated);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public boolean equals(Object o)
/*  84:    */   {
/*  85: 85 */     if (o == this) {
/*  86: 85 */       return true;
/*  87:    */     }
/*  88: 86 */     if (!(o instanceof ArithmeticPostMutationOperation)) {
/*  89: 86 */       return false;
/*  90:    */     }
/*  91: 88 */     ArithmeticPostMutationOperation other = (ArithmeticPostMutationOperation)o;
/*  92:    */     
/*  93: 90 */     return (this.mutated.equals(other.mutated)) && (this.op.equals(other.op));
/*  94:    */   }
/*  95:    */   
/*  96:    */   public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/*  97:    */   {
/*  98: 96 */     if (o == this) {
/*  99: 96 */       return true;
/* 100:    */     }
/* 101: 97 */     if (!(o instanceof ArithmeticPostMutationOperation)) {
/* 102: 97 */       return false;
/* 103:    */     }
/* 104: 99 */     ArithmeticPostMutationOperation other = (ArithmeticPostMutationOperation)o;
/* 105:100 */     if (!constraint.equivalent(this.mutated, other.mutated)) {
/* 106:100 */       return false;
/* 107:    */     }
/* 108:101 */     if (!constraint.equivalent(this.op, other.op)) {
/* 109:101 */       return false;
/* 110:    */     }
/* 111:102 */     return true;
/* 112:    */   }
/* 113:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithmeticPostMutationOperation
 * JD-Core Version:    0.7.0.1
 */