/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractAssignmentExpression;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/* 14:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/* 15:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 16:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 17:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredWhile;
/* 18:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/* 19:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 20:   */ 
/* 21:   */ public class WhileStatement
/* 22:   */   extends AbstractStatement
/* 23:   */ {
/* 24:   */   private ConditionalExpression condition;
/* 25:   */   private BlockIdentifier blockIdentifier;
/* 26:   */   
/* 27:   */   public WhileStatement(ConditionalExpression conditionalExpression, BlockIdentifier blockIdentifier)
/* 28:   */   {
/* 29:21 */     this.condition = conditionalExpression;
/* 30:22 */     this.blockIdentifier = blockIdentifier;
/* 31:   */   }
/* 32:   */   
/* 33:   */   private int getBackJumpIndex()
/* 34:   */   {
/* 35:26 */     return this.condition == null ? 0 : 1;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public Dumper dump(Dumper dumper)
/* 39:   */   {
/* 40:31 */     dumper.print("while (");
/* 41:32 */     if (this.condition == null) {
/* 42:33 */       dumper.print("true");
/* 43:   */     } else {
/* 44:35 */       dumper.dump(this.condition);
/* 45:   */     }
/* 46:37 */     dumper.print(") ");
/* 47:38 */     dumper.print(" // ends " + getTargetStatement(getBackJumpIndex()).getContainer().getLabel() + ";\n");
/* 48:39 */     return dumper;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public void replaceWithForLoop(AssignmentSimple initial, List<AbstractAssignmentExpression> assignment)
/* 52:   */   {
/* 53:43 */     if (this.condition == null) {
/* 54:44 */       throw new UnsupportedOperationException();
/* 55:   */     }
/* 56:46 */     ForStatement forStatement = new ForStatement(this.condition, this.blockIdentifier, initial, assignment);
/* 57:47 */     getContainer().replaceStatement(forStatement);
/* 58:   */   }
/* 59:   */   
/* 60:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers)
/* 61:   */   {
/* 62:52 */     if (this.condition == null) {
/* 63:52 */       return;
/* 64:   */     }
/* 65:53 */     Expression replacementCondition = this.condition.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer());
/* 66:54 */     if (replacementCondition != this.condition) {
/* 67:54 */       throw new ConfusedCFRException("Can't yet support replacing conditions");
/* 68:   */     }
/* 69:   */   }
/* 70:   */   
/* 71:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/* 72:   */   {
/* 73:59 */     if (this.condition == null) {
/* 74:59 */       return;
/* 75:   */     }
/* 76:60 */     this.condition = expressionRewriter.rewriteExpression(this.condition, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE);
/* 77:   */   }
/* 78:   */   
/* 79:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/* 80:   */   {
/* 81:65 */     if (this.condition != null) {
/* 82:65 */       this.condition.collectUsedLValues(lValueUsageCollector);
/* 83:   */     }
/* 84:   */   }
/* 85:   */   
/* 86:   */   public StructuredStatement getStructuredStatement()
/* 87:   */   {
/* 88:70 */     return new UnstructuredWhile(this.condition, this.blockIdentifier, getTargetStatement(getBackJumpIndex()).getContainer().getBlocksEnded());
/* 89:   */   }
/* 90:   */   
/* 91:   */   public BlockIdentifier getBlockIdentifier()
/* 92:   */   {
/* 93:74 */     return this.blockIdentifier;
/* 94:   */   }
/* 95:   */   
/* 96:   */   public ConditionalExpression getCondition()
/* 97:   */   {
/* 98:78 */     return this.condition;
/* 99:   */   }
/* :0:   */   
/* :1:   */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* :2:   */   {
/* :3:83 */     if (o == null) {
/* :4:83 */       return false;
/* :5:   */     }
/* :6:84 */     if (o == this) {
/* :7:84 */       return true;
/* :8:   */     }
/* :9:85 */     if (getClass() != o.getClass()) {
/* ;0:85 */       return false;
/* ;1:   */     }
/* ;2:86 */     WhileStatement other = (WhileStatement)o;
/* ;3:87 */     if (!constraint.equivalent(this.condition, other.condition)) {
/* ;4:87 */       return false;
/* ;5:   */     }
/* ;6:88 */     return true;
/* ;7:   */   }
/* ;8:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.WhileStatement
 * JD-Core Version:    0.7.0.1
 */