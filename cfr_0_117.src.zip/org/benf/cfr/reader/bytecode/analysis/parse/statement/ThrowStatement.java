/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredThrow;
/* 13:   */ import org.benf.cfr.reader.entities.exceptions.ExceptionCheck;
/* 14:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 15:   */ 
/* 16:   */ public class ThrowStatement
/* 17:   */   extends ReturnStatement
/* 18:   */ {
/* 19:   */   private Expression rvalue;
/* 20:   */   
/* 21:   */   public ThrowStatement(Expression rvalue)
/* 22:   */   {
/* 23:20 */     this.rvalue = rvalue;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public ReturnStatement deepClone(CloneHelper cloneHelper)
/* 27:   */   {
/* 28:25 */     return new ThrowStatement(cloneHelper.replaceOrClone(this.rvalue));
/* 29:   */   }
/* 30:   */   
/* 31:   */   public Dumper dump(Dumper dumper)
/* 32:   */   {
/* 33:30 */     return dumper.print("throw ").dump(this.rvalue).endCodeln();
/* 34:   */   }
/* 35:   */   
/* 36:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers)
/* 37:   */   {
/* 38:35 */     this.rvalue = this.rvalue.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer());
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/* 42:   */   {
/* 43:40 */     this.rvalue = expressionRewriter.rewriteExpression(this.rvalue, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE);
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/* 47:   */   {
/* 48:45 */     this.rvalue.collectUsedLValues(lValueUsageCollector);
/* 49:   */   }
/* 50:   */   
/* 51:   */   public StructuredStatement getStructuredStatement()
/* 52:   */   {
/* 53:50 */     return new StructuredThrow(this.rvalue);
/* 54:   */   }
/* 55:   */   
/* 56:   */   public boolean equals(Object o)
/* 57:   */   {
/* 58:55 */     if (o == this) {
/* 59:55 */       return true;
/* 60:   */     }
/* 61:56 */     if (!(o instanceof ThrowStatement)) {
/* 62:56 */       return false;
/* 63:   */     }
/* 64:57 */     ThrowStatement other = (ThrowStatement)o;
/* 65:58 */     return this.rvalue.equals(other.rvalue);
/* 66:   */   }
/* 67:   */   
/* 68:   */   public boolean canThrow(ExceptionCheck caught)
/* 69:   */   {
/* 70:66 */     return caught.checkAgainstException(this.rvalue);
/* 71:   */   }
/* 72:   */   
/* 73:   */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 74:   */   {
/* 75:71 */     if (o == null) {
/* 76:71 */       return false;
/* 77:   */     }
/* 78:72 */     if (o == this) {
/* 79:72 */       return true;
/* 80:   */     }
/* 81:73 */     if (getClass() != o.getClass()) {
/* 82:73 */       return false;
/* 83:   */     }
/* 84:74 */     ThrowStatement other = (ThrowStatement)o;
/* 85:75 */     if (!constraint.equivalent(this.rvalue, other.rvalue)) {
/* 86:75 */       return false;
/* 87:   */     }
/* 88:76 */     return true;
/* 89:   */   }
/* 90:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.ThrowStatement
 * JD-Core Version:    0.7.0.1
 */