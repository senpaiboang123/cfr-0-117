/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.lvalue;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 13:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/* 14:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 15:   */ 
/* 16:   */ public class StaticVariable
/* 17:   */   extends AbstractFieldVariable
/* 18:   */ {
/* 19:   */   private final boolean knownSimple;
/* 20:   */   
/* 21:   */   public StaticVariable(ConstantPoolEntry field)
/* 22:   */   {
/* 23:20 */     super(field);
/* 24:21 */     this.knownSimple = false;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public StaticVariable(InferredJavaType type, JavaTypeInstance clazz, String varName)
/* 28:   */   {
/* 29:28 */     super(type, clazz, varName);
/* 30:29 */     this.knownSimple = false;
/* 31:   */   }
/* 32:   */   
/* 33:   */   private StaticVariable(StaticVariable other, boolean knownSimple)
/* 34:   */   {
/* 35:33 */     super(other);
/* 36:34 */     this.knownSimple = knownSimple;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public StaticVariable getSimpleCopy()
/* 40:   */   {
/* 41:41 */     return new StaticVariable(this, true);
/* 42:   */   }
/* 43:   */   
/* 44:   */   public Precedence getPrecedence()
/* 45:   */   {
/* 46:47 */     return Precedence.HIGHEST;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public Dumper dumpInner(Dumper d)
/* 50:   */   {
/* 51:52 */     if (this.knownSimple) {
/* 52:53 */       return d.identifier(getFieldName());
/* 53:   */     }
/* 54:55 */     return d.dump(getOwningClassType()).print(".").identifier(getFieldName());
/* 55:   */   }
/* 56:   */   
/* 57:   */   public LValue deepClone(CloneHelper cloneHelper)
/* 58:   */   {
/* 59:61 */     return this;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public LValue replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/* 63:   */   {
/* 64:66 */     return this;
/* 65:   */   }
/* 66:   */   
/* 67:   */   public LValue applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 68:   */   {
/* 69:71 */     return this;
/* 70:   */   }
/* 71:   */   
/* 72:   */   public boolean equals(Object o)
/* 73:   */   {
/* 74:76 */     if (o == this) {
/* 75:76 */       return true;
/* 76:   */     }
/* 77:77 */     if (!(o instanceof StaticVariable)) {
/* 78:77 */       return false;
/* 79:   */     }
/* 80:78 */     if (!super.equals(o)) {
/* 81:78 */       return false;
/* 82:   */     }
/* 83:79 */     StaticVariable other = (StaticVariable)o;
/* 84:80 */     return true;
/* 85:   */   }
/* 86:   */   
/* 87:   */   public int hashCode()
/* 88:   */   {
/* 89:86 */     return super.hashCode();
/* 90:   */   }
/* 91:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StaticVariable
 * JD-Core Version:    0.7.0.1
 */