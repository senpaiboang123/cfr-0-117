/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredSynchronized;
/* 13:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 14:   */ 
/* 15:   */ public class MonitorEnterStatement
/* 16:   */   extends MonitorStatement
/* 17:   */ {
/* 18:   */   private Expression monitor;
/* 19:   */   private final BlockIdentifier blockIdentifier;
/* 20:   */   
/* 21:   */   public MonitorEnterStatement(Expression monitor, BlockIdentifier blockIdentifier)
/* 22:   */   {
/* 23:16 */     this.monitor = monitor;
/* 24:17 */     this.blockIdentifier = blockIdentifier;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public Dumper dump(Dumper dumper)
/* 28:   */   {
/* 29:22 */     return dumper.print("MONITORENTER : ").dump(this.monitor);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers)
/* 33:   */   {
/* 34:27 */     this.monitor = this.monitor.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer());
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/* 38:   */   {
/* 39:32 */     this.monitor = expressionRewriter.rewriteExpression(this.monitor, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/* 43:   */   {
/* 44:37 */     this.monitor.collectUsedLValues(lValueUsageCollector);
/* 45:   */   }
/* 46:   */   
/* 47:   */   public Expression getMonitor()
/* 48:   */   {
/* 49:41 */     return this.monitor;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public BlockIdentifier getBlockIdentifier()
/* 53:   */   {
/* 54:45 */     return this.blockIdentifier;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public StructuredStatement getStructuredStatement()
/* 58:   */   {
/* 59:50 */     return new UnstructuredSynchronized(this.monitor, this.blockIdentifier);
/* 60:   */   }
/* 61:   */   
/* 62:   */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 63:   */   {
/* 64:55 */     if (o == null) {
/* 65:55 */       return false;
/* 66:   */     }
/* 67:56 */     if (o == this) {
/* 68:56 */       return true;
/* 69:   */     }
/* 70:57 */     if (getClass() != o.getClass()) {
/* 71:57 */       return false;
/* 72:   */     }
/* 73:58 */     MonitorEnterStatement other = (MonitorEnterStatement)o;
/* 74:59 */     if (!constraint.equivalent(this.monitor, other.monitor)) {
/* 75:59 */       return false;
/* 76:   */     }
/* 77:60 */     return true;
/* 78:   */   }
/* 79:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.MonitorEnterStatement
 * JD-Core Version:    0.7.0.1
 */