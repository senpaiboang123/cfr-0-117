/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.parse.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Statement;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 14:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 15:   */ import org.benf.cfr.reader.bytecode.opcode.DecodedSwitch;
/* 16:   */ import org.benf.cfr.reader.bytecode.opcode.DecodedSwitchEntry;
/* 17:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 18:   */ 
/* 19:   */ public class RawSwitchStatement
/* 20:   */   extends AbstractStatement
/* 21:   */ {
/* 22:   */   private Expression switchOn;
/* 23:   */   private final DecodedSwitch switchData;
/* 24:   */   
/* 25:   */   public RawSwitchStatement(Expression switchOn, DecodedSwitch switchData)
/* 26:   */   {
/* 27:25 */     this.switchOn = switchOn;
/* 28:26 */     this.switchData = switchData;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public Dumper dump(Dumper dumper)
/* 32:   */   {
/* 33:31 */     dumper.print("switch (").dump(this.switchOn).print(") {\n");
/* 34:32 */     List<DecodedSwitchEntry> targets = this.switchData.getJumpTargets();
/* 35:33 */     int targetIdx = 1;
/* 36:34 */     for (DecodedSwitchEntry decodedSwitchEntry : targets)
/* 37:   */     {
/* 38:35 */       String tgtLbl = getTargetStatement(targetIdx++).getContainer().getLabel();
/* 39:36 */       dumper.print(" case " + decodedSwitchEntry.getValue() + ": goto " + tgtLbl + ";\n");
/* 40:   */     }
/* 41:38 */     dumper.print(" default: goto " + getTargetStatement(0).getContainer().getLabel() + ";\n");
/* 42:39 */     dumper.print("}\n");
/* 43:40 */     return dumper;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers)
/* 47:   */   {
/* 48:45 */     this.switchOn = this.switchOn.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, getContainer());
/* 49:   */   }
/* 50:   */   
/* 51:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers)
/* 52:   */   {
/* 53:50 */     this.switchOn = expressionRewriter.rewriteExpression(this.switchOn, ssaIdentifiers, getContainer(), ExpressionRewriterFlags.RVALUE);
/* 54:   */   }
/* 55:   */   
/* 56:   */   public void collectLValueUsage(LValueUsageCollector lValueUsageCollector)
/* 57:   */   {
/* 58:55 */     this.switchOn.collectUsedLValues(lValueUsageCollector);
/* 59:   */   }
/* 60:   */   
/* 61:   */   public DecodedSwitch getSwitchData()
/* 62:   */   {
/* 63:59 */     return this.switchData;
/* 64:   */   }
/* 65:   */   
/* 66:   */   public Expression getSwitchOn()
/* 67:   */   {
/* 68:63 */     return this.switchOn;
/* 69:   */   }
/* 70:   */   
/* 71:   */   public StructuredStatement getStructuredStatement()
/* 72:   */   {
/* 73:68 */     throw new RuntimeException("Can't convert a raw switch statement to a structured statement");
/* 74:   */   }
/* 75:   */   
/* 76:   */   public SwitchStatement getSwitchStatement(BlockIdentifier blockIdentifier)
/* 77:   */   {
/* 78:72 */     return new SwitchStatement(this.switchOn, blockIdentifier);
/* 79:   */   }
/* 80:   */   
/* 81:   */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 82:   */   {
/* 83:77 */     if (o == null) {
/* 84:77 */       return false;
/* 85:   */     }
/* 86:78 */     if (o == this) {
/* 87:78 */       return true;
/* 88:   */     }
/* 89:79 */     if (getClass() != o.getClass()) {
/* 90:79 */       return false;
/* 91:   */     }
/* 92:80 */     RawSwitchStatement other = (RawSwitchStatement)o;
/* 93:81 */     if (!constraint.equivalent(this.switchOn, other.switchOn)) {
/* 94:81 */       return false;
/* 95:   */     }
/* 96:82 */     return true;
/* 97:   */   }
/* 98:   */   
/* 99:   */   public boolean fallsToNext()
/* :0:   */   {
/* :1:87 */     return false;
/* :2:   */   }
/* :3:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.statement.RawSwitchStatement
 * JD-Core Version:    0.7.0.1
 */