/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  14:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  15:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  16:    */ 
/*  17:    */ public class ArithmeticPreMutationOperation
/*  18:    */   extends AbstractMutatingAssignmentExpression
/*  19:    */ {
/*  20:    */   private LValue mutated;
/*  21:    */   private final ArithOp op;
/*  22:    */   
/*  23:    */   public ArithmeticPreMutationOperation(LValue mutated, ArithOp op)
/*  24:    */   {
/*  25: 20 */     super(mutated.getInferredJavaType());
/*  26: 21 */     this.mutated = mutated;
/*  27: 22 */     this.op = op;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  31:    */   {
/*  32: 27 */     return new ArithmeticPreMutationOperation(cloneHelper.replaceOrClone(this.mutated), this.op);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void collectTypeUsages(TypeUsageCollector collector) {}
/*  36:    */   
/*  37:    */   public Dumper dumpInner(Dumper d)
/*  38:    */   {
/*  39: 36 */     return d.print(this.op == ArithOp.PLUS ? "++" : "--").dump(this.mutated);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/*  43:    */   {
/*  44: 41 */     return this;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  48:    */   {
/*  49: 46 */     this.mutated = expressionRewriter.rewriteExpression(this.mutated, ssaIdentifiers, statementContainer, ExpressionRewriterFlags.LANDRVALUE);
/*  50: 47 */     return this;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/*  54:    */   {
/*  55: 52 */     return applyExpressionRewriter(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public boolean isSelfMutatingOp1(LValue lValue, ArithOp arithOp)
/*  59:    */   {
/*  60: 57 */     return (this.mutated.equals(lValue)) && (this.op == arithOp);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public Precedence getPrecedence()
/*  64:    */   {
/*  65: 63 */     return Precedence.UNARY_OTHER;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public ArithmeticPostMutationOperation getPostMutation()
/*  69:    */   {
/*  70: 68 */     return new ArithmeticPostMutationOperation(this.mutated, this.op);
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/*  74:    */   {
/*  75: 73 */     lValueUsageCollector.collect(this.mutated);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public LValue getUpdatedLValue()
/*  79:    */   {
/*  80: 78 */     return this.mutated;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public boolean equals(Object o)
/*  84:    */   {
/*  85: 83 */     if (o == this) {
/*  86: 83 */       return true;
/*  87:    */     }
/*  88: 84 */     if (!(o instanceof ArithmeticPreMutationOperation)) {
/*  89: 84 */       return false;
/*  90:    */     }
/*  91: 86 */     ArithmeticPreMutationOperation other = (ArithmeticPreMutationOperation)o;
/*  92:    */     
/*  93: 88 */     return (this.mutated.equals(other.mutated)) && (this.op.equals(other.op));
/*  94:    */   }
/*  95:    */   
/*  96:    */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/*  97:    */   {
/*  98: 94 */     if (o == null) {
/*  99: 94 */       return false;
/* 100:    */     }
/* 101: 95 */     if (o == this) {
/* 102: 95 */       return true;
/* 103:    */     }
/* 104: 96 */     if (getClass() != o.getClass()) {
/* 105: 96 */       return false;
/* 106:    */     }
/* 107: 97 */     ArithmeticPreMutationOperation other = (ArithmeticPreMutationOperation)o;
/* 108: 98 */     if (this.op != other.op) {
/* 109: 98 */       return false;
/* 110:    */     }
/* 111: 99 */     if (!constraint.equivalent(this.mutated, other.mutated)) {
/* 112: 99 */       return false;
/* 113:    */     }
/* 114:100 */     return true;
/* 115:    */   }
/* 116:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithmeticPreMutationOperation
 * JD-Core Version:    0.7.0.1
 */