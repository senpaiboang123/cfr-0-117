/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.parse.expression;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.PrimitiveBoxingRewriter;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface.BoxingProcessor;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.types.GenericTypeBinder;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaWildcardTypeInstance;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  20:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  21:    */ import org.benf.cfr.reader.util.Troolean;
/*  22:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  23:    */ 
/*  24:    */ public class CastExpression
/*  25:    */   extends AbstractExpression
/*  26:    */   implements BoxingProcessor
/*  27:    */ {
/*  28:    */   private Expression child;
/*  29:    */   private boolean forced;
/*  30:    */   
/*  31:    */   public CastExpression(InferredJavaType knownType, Expression child)
/*  32:    */   {
/*  33: 26 */     super(knownType);
/*  34: 27 */     this.child = child;
/*  35: 28 */     this.forced = false;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public CastExpression(InferredJavaType knownType, Expression child, boolean forced)
/*  39:    */   {
/*  40: 32 */     super(knownType);
/*  41: 33 */     this.child = child;
/*  42: 34 */     this.forced = forced;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public boolean isForced()
/*  46:    */   {
/*  47: 38 */     return this.forced;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public Expression deepClone(CloneHelper cloneHelper)
/*  51:    */   {
/*  52: 43 */     return new CastExpression(getInferredJavaType(), cloneHelper.replaceOrClone(this.child), this.forced);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public boolean couldBeImplicit(GenericTypeBinder gtb)
/*  56:    */   {
/*  57: 47 */     if (this.forced) {
/*  58: 47 */       return false;
/*  59:    */     }
/*  60: 48 */     JavaTypeInstance childType = this.child.getInferredJavaType().getJavaTypeInstance();
/*  61: 49 */     JavaTypeInstance tgtType = getInferredJavaType().getJavaTypeInstance();
/*  62: 50 */     return childType.implicitlyCastsTo(tgtType, gtb);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public boolean couldBeImplicit(JavaTypeInstance tgtType, GenericTypeBinder gtb)
/*  66:    */   {
/*  67: 54 */     if (this.forced) {
/*  68: 54 */       return false;
/*  69:    */     }
/*  70: 55 */     JavaTypeInstance childType = this.child.getInferredJavaType().getJavaTypeInstance();
/*  71: 56 */     return childType.implicitlyCastsTo(tgtType, gtb);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  75:    */   {
/*  76: 61 */     collector.collect(getInferredJavaType().getJavaTypeInstance());
/*  77: 62 */     this.child.collectTypeUsages(collector);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public Precedence getPrecedence()
/*  81:    */   {
/*  82: 67 */     return Precedence.UNARY_OTHER;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public Dumper dumpInner(Dumper d)
/*  86:    */   {
/*  87: 75 */     JavaTypeInstance castType = getInferredJavaType().getJavaTypeInstance();
/*  88: 76 */     while ((castType instanceof JavaWildcardTypeInstance)) {
/*  89: 77 */       castType = ((JavaWildcardTypeInstance)castType).getUnderlyingType();
/*  90:    */     }
/*  91: 79 */     JavaTypeInstance childType = this.child.getInferredJavaType().getJavaTypeInstance();
/*  92: 80 */     if ((childType == RawJavaType.BOOLEAN) && (!RawJavaType.BOOLEAN.implicitlyCastsTo(castType, null)))
/*  93:    */     {
/*  94: 84 */       d.print("(").dump(castType).print(")");
/*  95: 85 */       this.child.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.NEITHER);
/*  96: 86 */       d.print(" ? 1 : 0");
/*  97:    */     }
/*  98: 87 */     else if (castType == RawJavaType.NULL)
/*  99:    */     {
/* 100: 88 */       this.child.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.NEITHER);
/* 101:    */     }
/* 102:    */     else
/* 103:    */     {
/* 104: 90 */       d.print("(").dump(castType).print(")");
/* 105: 91 */       this.child.dumpWithOuterPrecedence(d, getPrecedence(), Troolean.NEITHER);
/* 106:    */     }
/* 107: 93 */     return d;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/* 111:    */   {
/* 112: 99 */     this.child = this.child.replaceSingleUsageLValues(lValueRewriter, ssaIdentifiers, statementContainer);
/* 113:100 */     return this;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 117:    */   {
/* 118:105 */     this.child = expressionRewriter.rewriteExpression(this.child, ssaIdentifiers, statementContainer, flags);
/* 119:106 */     return this;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 123:    */   {
/* 124:111 */     return applyExpressionRewriter(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/* 125:    */   }
/* 126:    */   
/* 127:    */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector)
/* 128:    */   {
/* 129:116 */     this.child.collectUsedLValues(lValueUsageCollector);
/* 130:    */   }
/* 131:    */   
/* 132:    */   public Expression getChild()
/* 133:    */   {
/* 134:120 */     return this.child;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public boolean equals(Object o)
/* 138:    */   {
/* 139:125 */     if (o == this) {
/* 140:125 */       return true;
/* 141:    */     }
/* 142:126 */     if (!(o instanceof CastExpression)) {
/* 143:126 */       return false;
/* 144:    */     }
/* 145:127 */     return this.child.equals(((CastExpression)o).child);
/* 146:    */   }
/* 147:    */   
/* 148:    */   public boolean rewriteBoxing(PrimitiveBoxingRewriter boxingRewriter)
/* 149:    */   {
/* 150:133 */     if (isForced()) {
/* 151:134 */       return false;
/* 152:    */     }
/* 153:136 */     while ((this.child instanceof CastExpression))
/* 154:    */     {
/* 155:137 */       CastExpression childCast = (CastExpression)this.child;
/* 156:138 */       JavaTypeInstance thisType = getInferredJavaType().getJavaTypeInstance();
/* 157:139 */       JavaTypeInstance childType = childCast.getInferredJavaType().getJavaTypeInstance();
/* 158:140 */       Expression grandChild = childCast.child;
/* 159:141 */       JavaTypeInstance grandChildType = grandChild.getInferredJavaType().getJavaTypeInstance();
/* 160:147 */       if ((Literal.NULL.equals(grandChild)) && (!thisType.isObject()) && (childType.isObject())) {
/* 161:    */         break;
/* 162:    */       }
/* 163:150 */       if ((grandChildType.implicitlyCastsTo(childType, null)) && (childType.implicitlyCastsTo(thisType, null)))
/* 164:    */       {
/* 165:151 */         this.child = childCast.child;
/* 166:    */       }
/* 167:    */       else
/* 168:    */       {
/* 169:153 */         if ((!(grandChildType instanceof RawJavaType)) || (!(childType instanceof RawJavaType)) || (!(thisType instanceof RawJavaType)) || 
/* 170:154 */           (grandChildType.implicitlyCastsTo(childType, null)) || (childType.implicitlyCastsTo(thisType, null))) {
/* 171:    */           break;
/* 172:    */         }
/* 173:155 */         this.child = childCast.child;
/* 174:    */       }
/* 175:    */     }
/* 176:162 */     Expression newchild = boxingRewriter.sugarNonParameterBoxing(this.child, getInferredJavaType().getJavaTypeInstance());
/* 177:163 */     if ((this.child != newchild) && (newchild.getInferredJavaType().getJavaTypeInstance().implicitlyCastsTo(this.child.getInferredJavaType().getJavaTypeInstance(), null))) {
/* 178:165 */       this.child = newchild;
/* 179:    */     }
/* 180:167 */     return false;
/* 181:    */   }
/* 182:    */   
/* 183:    */   public void applyNonArgExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags) {}
/* 184:    */   
/* 185:    */   public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 186:    */   {
/* 187:176 */     if (o == null) {
/* 188:176 */       return false;
/* 189:    */     }
/* 190:177 */     if (o == this) {
/* 191:177 */       return true;
/* 192:    */     }
/* 193:178 */     if (getClass() != o.getClass()) {
/* 194:178 */       return false;
/* 195:    */     }
/* 196:179 */     CastExpression other = (CastExpression)o;
/* 197:180 */     if (!constraint.equivalent(getInferredJavaType().getJavaTypeInstance(), other.getInferredJavaType().getJavaTypeInstance())) {
/* 198:181 */       return false;
/* 199:    */     }
/* 200:182 */     if (!constraint.equivalent(this.child, other.child)) {
/* 201:182 */       return false;
/* 202:    */     }
/* 203:183 */     return true;
/* 204:    */   }
/* 205:    */   
/* 206:    */   public static Expression removeImplicit(Expression e)
/* 207:    */   {
/* 208:187 */     while (((e instanceof CastExpression)) && (((CastExpression)e).couldBeImplicit(null))) {
/* 209:188 */       e = ((CastExpression)e).getChild();
/* 210:    */     }
/* 211:190 */     return e;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public static Expression removeImplicitOuterType(Expression e, GenericTypeBinder gtb, boolean rawArg)
/* 215:    */   {
/* 216:194 */     JavaTypeInstance t = e.getInferredJavaType().getJavaTypeInstance();
/* 217:195 */     while (((e instanceof CastExpression)) && (((CastExpression)e).couldBeImplicit(gtb)) && (((CastExpression)e).couldBeImplicit(t, gtb)))
/* 218:    */     {
/* 219:198 */       Expression newE = ((CastExpression)e).getChild();
/* 220:199 */       if (!rawArg)
/* 221:    */       {
/* 222:200 */         boolean wasRaw = e.getInferredJavaType().getJavaTypeInstance() instanceof RawJavaType;
/* 223:201 */         boolean isRaw = newE.getInferredJavaType().getJavaTypeInstance() instanceof RawJavaType;
/* 224:202 */         if ((wasRaw) && (wasRaw != isRaw)) {
/* 225:    */           break;
/* 226:    */         }
/* 227:    */       }
/* 228:206 */       e = newE;
/* 229:    */     }
/* 230:208 */     return e;
/* 231:    */   }
/* 232:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.parse.expression.CastExpression
 * JD-Core Version:    0.7.0.1
 */