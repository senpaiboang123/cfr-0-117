/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.types;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  5:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  6:   */ import org.benf.cfr.reader.util.ListFactory;
/*  7:   */ import org.benf.cfr.reader.util.TypeUsageCollectable;
/*  8:   */ 
/*  9:   */ public class ClassSignature
/* 10:   */   implements TypeUsageCollectable
/* 11:   */ {
/* 12:   */   private final List<FormalTypeParameter> formalTypeParameters;
/* 13:   */   private final JavaTypeInstance superClass;
/* 14:   */   private final List<JavaTypeInstance> interfaces;
/* 15:   */   
/* 16:   */   public ClassSignature(List<FormalTypeParameter> formalTypeParameters, JavaTypeInstance superClass, List<JavaTypeInstance> interfaces)
/* 17:   */   {
/* 18:17 */     this.formalTypeParameters = formalTypeParameters;
/* 19:18 */     this.superClass = superClass;
/* 20:19 */     this.interfaces = interfaces;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public List<FormalTypeParameter> getFormalTypeParameters()
/* 24:   */   {
/* 25:23 */     return this.formalTypeParameters;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public JavaTypeInstance getSuperClass()
/* 29:   */   {
/* 30:27 */     return this.superClass;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public List<JavaTypeInstance> getInterfaces()
/* 34:   */   {
/* 35:31 */     return this.interfaces;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 39:   */   {
/* 40:36 */     collector.collect(this.superClass);
/* 41:37 */     collector.collectFrom(this.formalTypeParameters);
/* 42:38 */     collector.collect(this.interfaces);
/* 43:   */   }
/* 44:   */   
/* 45:   */   public JavaTypeInstance getThisGeneralTypeClass(JavaTypeInstance nonGenericInstance, ConstantPool cp)
/* 46:   */   {
/* 47:43 */     if ((nonGenericInstance instanceof JavaGenericBaseInstance)) {
/* 48:43 */       return nonGenericInstance;
/* 49:   */     }
/* 50:44 */     if ((this.formalTypeParameters == null) || (this.formalTypeParameters.isEmpty())) {
/* 51:44 */       return nonGenericInstance;
/* 52:   */     }
/* 53:45 */     List<JavaTypeInstance> typeParameterNames = ListFactory.newList();
/* 54:46 */     for (FormalTypeParameter formalTypeParameter : this.formalTypeParameters) {
/* 55:47 */       typeParameterNames.add(new JavaGenericPlaceholderTypeInstance(formalTypeParameter.getName(), cp));
/* 56:   */     }
/* 57:49 */     JavaTypeInstance res = new JavaGenericRefTypeInstance(nonGenericInstance, typeParameterNames);
/* 58:50 */     return res;
/* 59:   */   }
/* 60:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.ClassSignature
 * JD-Core Version:    0.7.0.1
 */