/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.types;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.Arrays;
/*  5:   */ import java.util.List;
/*  6:   */ 
/*  7:   */ public class StackTypes
/*  8:   */   extends ArrayList<StackType>
/*  9:   */ {
/* 10:11 */   public static final StackTypes EMPTY = new StackTypes(new StackType[0]);
/* 11:   */   
/* 12:   */   public StackTypes(StackType... stackTypes)
/* 13:   */   {
/* 14:14 */     super(Arrays.asList(stackTypes));
/* 15:   */   }
/* 16:   */   
/* 17:   */   public StackTypes(List<StackType> stackTypes)
/* 18:   */   {
/* 19:18 */     super(stackTypes);
/* 20:   */   }
/* 21:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.StackTypes
 * JD-Core Version:    0.7.0.1
 */