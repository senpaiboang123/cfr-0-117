package org.benf.cfr.reader.bytecode.analysis.types.annotated;

import org.benf.cfr.reader.bytecode.analysis.types.JavaAnnotatedTypeIterator;
import org.benf.cfr.reader.util.output.Dumpable;

public abstract interface JavaAnnotatedTypeInstance
  extends Dumpable
{
  public abstract JavaAnnotatedTypeIterator pathIterator();
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.annotated.JavaAnnotatedTypeInstance
 * JD-Core Version:    0.7.0.1
 */