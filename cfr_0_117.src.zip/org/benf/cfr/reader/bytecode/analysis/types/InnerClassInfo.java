/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.types;
/*  2:   */ 
/*  3:   */ import java.util.Set;
/*  4:   */ 
/*  5:   */ public abstract interface InnerClassInfo
/*  6:   */ {
/*  7:36 */   public static final InnerClassInfo NOT = new InnerClassInfo()
/*  8:   */   {
/*  9:   */     public boolean isInnerClass()
/* 10:   */     {
/* 11:39 */       return false;
/* 12:   */     }
/* 13:   */     
/* 14:   */     public void collectTransitiveDegenericParents(Set<JavaTypeInstance> parents) {}
/* 15:   */     
/* 16:   */     public boolean isAnonymousClass()
/* 17:   */     {
/* 18:48 */       return false;
/* 19:   */     }
/* 20:   */     
/* 21:   */     public boolean isMethodScopedClass()
/* 22:   */     {
/* 23:53 */       return false;
/* 24:   */     }
/* 25:   */     
/* 26:   */     public void markMethodScoped(boolean isAnonymous) {}
/* 27:   */     
/* 28:   */     public boolean isInnerClassOf(JavaTypeInstance possibleParent)
/* 29:   */     {
/* 30:62 */       return false;
/* 31:   */     }
/* 32:   */     
/* 33:   */     public boolean isTransitiveInnerClassOf(JavaTypeInstance possibleParent)
/* 34:   */     {
/* 35:67 */       return false;
/* 36:   */     }
/* 37:   */     
/* 38:   */     public void setHideSyntheticThis()
/* 39:   */     {
/* 40:72 */       throw new IllegalStateException();
/* 41:   */     }
/* 42:   */     
/* 43:   */     public void hideSyntheticFriendClass()
/* 44:   */     {
/* 45:77 */       throw new IllegalStateException();
/* 46:   */     }
/* 47:   */     
/* 48:   */     public boolean isSyntheticFriendClass()
/* 49:   */     {
/* 50:82 */       return false;
/* 51:   */     }
/* 52:   */     
/* 53:   */     public JavaRefTypeInstance getOuterClass()
/* 54:   */     {
/* 55:87 */       throw new IllegalStateException();
/* 56:   */     }
/* 57:   */     
/* 58:   */     public boolean isHideSyntheticThis()
/* 59:   */     {
/* 60:92 */       return false;
/* 61:   */     }
/* 62:   */   };
/* 63:   */   
/* 64:   */   public abstract void collectTransitiveDegenericParents(Set<JavaTypeInstance> paramSet);
/* 65:   */   
/* 66:   */   public abstract boolean isInnerClass();
/* 67:   */   
/* 68:   */   public abstract boolean isInnerClassOf(JavaTypeInstance paramJavaTypeInstance);
/* 69:   */   
/* 70:   */   public abstract boolean isTransitiveInnerClassOf(JavaTypeInstance paramJavaTypeInstance);
/* 71:   */   
/* 72:   */   public abstract void hideSyntheticFriendClass();
/* 73:   */   
/* 74:   */   public abstract boolean isSyntheticFriendClass();
/* 75:   */   
/* 76:   */   public abstract void setHideSyntheticThis();
/* 77:   */   
/* 78:   */   public abstract boolean isHideSyntheticThis();
/* 79:   */   
/* 80:   */   public abstract void markMethodScoped(boolean paramBoolean);
/* 81:   */   
/* 82:   */   public abstract boolean isAnonymousClass();
/* 83:   */   
/* 84:   */   public abstract boolean isMethodScopedClass();
/* 85:   */   
/* 86:   */   public abstract JavaRefTypeInstance getOuterClass();
/* 87:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.InnerClassInfo
 * JD-Core Version:    0.7.0.1
 */