/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.types;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.entities.annotations.AnnotationTableEntry;
/*  5:   */ import org.benf.cfr.reader.entities.attributes.AttributeParameterAnnotations;
/*  6:   */ import org.benf.cfr.reader.entities.attributes.AttributeRuntimeInvisibleParameterAnnotations;
/*  7:   */ import org.benf.cfr.reader.entities.attributes.AttributeRuntimeVisibleParameterAnnotations;
/*  8:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  9:   */ 
/* 10:   */ public class MethodPrototypeAnnotationsHelper
/* 11:   */ {
/* 12:   */   private final AttributeRuntimeVisibleParameterAnnotations runtimeVisibleParameterAnnotations;
/* 13:   */   private final AttributeRuntimeInvisibleParameterAnnotations runtimeInvisibleParameterAnnotations;
/* 14:   */   
/* 15:   */   public MethodPrototypeAnnotationsHelper(AttributeRuntimeVisibleParameterAnnotations runtimeVisibleParameterAnnotations, AttributeRuntimeInvisibleParameterAnnotations runtimeInvisibleParameterAnnotations)
/* 16:   */   {
/* 17:16 */     this.runtimeVisibleParameterAnnotations = runtimeVisibleParameterAnnotations;
/* 18:17 */     this.runtimeInvisibleParameterAnnotations = runtimeInvisibleParameterAnnotations;
/* 19:   */   }
/* 20:   */   
/* 21:   */   private static void addAnnotation(AttributeParameterAnnotations annotations, int idx, Dumper d)
/* 22:   */   {
/* 23:21 */     if (annotations == null) {
/* 24:21 */       return;
/* 25:   */     }
/* 26:22 */     List<AnnotationTableEntry> annotationTableEntries = annotations.getAnnotationsForParamIdx(idx);
/* 27:23 */     if ((annotationTableEntries == null) || (annotationTableEntries.isEmpty())) {
/* 28:23 */       return;
/* 29:   */     }
/* 30:24 */     for (AnnotationTableEntry annotationTableEntry : annotationTableEntries)
/* 31:   */     {
/* 32:25 */       annotationTableEntry.dump(d);
/* 33:26 */       d.print(' ');
/* 34:   */     }
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void addAnnotationTextForParameterInto(int idx, Dumper d)
/* 38:   */   {
/* 39:31 */     addAnnotation(this.runtimeVisibleParameterAnnotations, idx, d);
/* 40:32 */     addAnnotation(this.runtimeInvisibleParameterAnnotations, idx, d);
/* 41:   */   }
/* 42:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.MethodPrototypeAnnotationsHelper
 * JD-Core Version:    0.7.0.1
 */