/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.types;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  4:   */ import org.benf.cfr.reader.util.TypeUsageCollectable;
/*  5:   */ import org.benf.cfr.reader.util.output.Dumpable;
/*  6:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  7:   */ 
/*  8:   */ public class FormalTypeParameter
/*  9:   */   implements Dumpable, TypeUsageCollectable
/* 10:   */ {
/* 11:   */   String name;
/* 12:   */   JavaTypeInstance classBound;
/* 13:   */   JavaTypeInstance interfaceBound;
/* 14:   */   
/* 15:   */   public FormalTypeParameter(String name, JavaTypeInstance classBound, JavaTypeInstance interfaceBound)
/* 16:   */   {
/* 17:14 */     this.name = name;
/* 18:15 */     this.classBound = classBound;
/* 19:16 */     this.interfaceBound = interfaceBound;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String getName()
/* 23:   */   {
/* 24:20 */     return this.name;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 28:   */   {
/* 29:25 */     collector.collect(this.classBound);
/* 30:26 */     collector.collect(this.interfaceBound);
/* 31:   */   }
/* 32:   */   
/* 33:   */   public Dumper dump(Dumper d)
/* 34:   */   {
/* 35:31 */     JavaTypeInstance dispInterface = this.classBound == null ? this.interfaceBound : this.classBound;
/* 36:32 */     d.print(this.name);
/* 37:33 */     if ((dispInterface != null) && 
/* 38:34 */       (!"java.lang.Object".equals(dispInterface.getRawName()))) {
/* 39:35 */       d.print(" extends ").dump(dispInterface);
/* 40:   */     }
/* 41:38 */     return d;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public String toString()
/* 45:   */   {
/* 46:43 */     throw new IllegalStateException();
/* 47:   */   }
/* 48:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.FormalTypeParameter
 * JD-Core Version:    0.7.0.1
 */