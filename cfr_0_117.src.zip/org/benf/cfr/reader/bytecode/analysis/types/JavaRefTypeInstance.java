/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.types;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Map;
/*   5:    */ import java.util.Set;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.types.annotated.JavaAnnotatedTypeInstance;
/*   8:    */ import org.benf.cfr.reader.entities.ClassFile;
/*   9:    */ import org.benf.cfr.reader.entities.annotations.AnnotationTableTypeEntry;
/*  10:    */ import org.benf.cfr.reader.state.ClassCache;
/*  11:    */ import org.benf.cfr.reader.state.DCCommonState;
/*  12:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  13:    */ import org.benf.cfr.reader.state.TypeUsageInformation;
/*  14:    */ import org.benf.cfr.reader.util.CannotLoadClassException;
/*  15:    */ import org.benf.cfr.reader.util.DecompilerComments;
/*  16:    */ import org.benf.cfr.reader.util.ListFactory;
/*  17:    */ import org.benf.cfr.reader.util.MapFactory;
/*  18:    */ import org.benf.cfr.reader.util.annotation.Nullable;
/*  19:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  20:    */ import org.benf.cfr.reader.util.output.ToStringDumper;
/*  21:    */ 
/*  22:    */ public class JavaRefTypeInstance
/*  23:    */   implements JavaTypeInstance
/*  24:    */ {
/*  25:    */   private final String className;
/*  26:    */   private transient String shortName;
/*  27:    */   private transient String suggestedVarName;
/*  28:    */   private transient InnerClassInfo innerClassInfo;
/*  29:    */   private final DCCommonState dcCommonState;
/*  30: 26 */   private BindingSuperContainer cachedBindingSupers = BindingSuperContainer.POISON;
/*  31:    */   
/*  32:    */   private JavaRefTypeInstance(String className, DCCommonState dcCommonState)
/*  33:    */   {
/*  34: 29 */     this.innerClassInfo = InnerClassInfo.NOT;
/*  35: 30 */     this.dcCommonState = dcCommonState;
/*  36: 35 */     if (className.contains("$"))
/*  37:    */     {
/*  38: 36 */       String outer = className.substring(0, className.lastIndexOf('$'));
/*  39: 37 */       JavaRefTypeInstance outerClassTmp = dcCommonState.getClassCache().getRefClassFor(outer);
/*  40: 38 */       this.innerClassInfo = new RefTypeInnerClassInfo(outerClassTmp, null);
/*  41:    */     }
/*  42: 40 */     this.className = className;
/*  43: 41 */     this.shortName = getShortName(className, this.innerClassInfo);
/*  44:    */   }
/*  45:    */   
/*  46:    */   private JavaRefTypeInstance(String className, JavaRefTypeInstance knownOuter, DCCommonState dcCommonState)
/*  47:    */   {
/*  48: 45 */     this.className = className;
/*  49: 46 */     this.dcCommonState = dcCommonState;
/*  50: 47 */     String innerSub = className.substring(knownOuter.className.length());
/*  51: 53 */     if (innerSub.charAt(0) == '$') {
/*  52: 54 */       innerSub = innerSub.substring(1);
/*  53:    */     }
/*  54: 56 */     this.innerClassInfo = new RefTypeInnerClassInfo(knownOuter, null);
/*  55: 57 */     this.shortName = innerSub;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public JavaAnnotatedTypeInstance getAnnotatedInstance()
/*  59:    */   {
/*  60: 62 */     JavaRefTypeInstance rti = this;
/*  61: 63 */     JavaAnnotatedTypeInstance prev = null;
/*  62:    */     do
/*  63:    */     {
/*  64: 65 */       InnerClassInfo ici = rti.getInnerClassHereInfo();
/*  65: 66 */       boolean isInner = ici.isInnerClass();
/*  66: 67 */       prev = new Annotated(prev, rti, isInner, null);
/*  67: 68 */       if (isInner) {
/*  68: 69 */         rti = ici.getOuterClass();
/*  69:    */       } else {
/*  70: 71 */         rti = null;
/*  71:    */       }
/*  72: 73 */     } while (rti != null);
/*  73: 74 */     return prev;
/*  74:    */   }
/*  75:    */   
/*  76:    */   private static class Annotated
/*  77:    */     implements JavaAnnotatedTypeInstance
/*  78:    */   {
/*  79: 78 */     private final List<AnnotationTableTypeEntry> entries = ListFactory.newList();
/*  80:    */     private final JavaAnnotatedTypeInstance inner;
/*  81:    */     private final JavaRefTypeInstance outerThis;
/*  82:    */     private final boolean isInner;
/*  83:    */     
/*  84:    */     private Annotated(JavaAnnotatedTypeInstance inner, JavaRefTypeInstance outerThis, boolean isInner)
/*  85:    */     {
/*  86: 84 */       this.inner = inner;
/*  87: 85 */       this.outerThis = outerThis;
/*  88: 86 */       this.isInner = isInner;
/*  89:    */     }
/*  90:    */     
/*  91:    */     public JavaAnnotatedTypeIterator pathIterator()
/*  92:    */     {
/*  93: 90 */       return new Iterator(null);
/*  94:    */     }
/*  95:    */     
/*  96:    */     public Dumper dump(Dumper d)
/*  97:    */     {
/*  98: 95 */       if (!this.entries.isEmpty())
/*  99:    */       {
/* 100: 96 */         if (this.isInner) {
/* 101: 96 */           d.print(' ');
/* 102:    */         }
/* 103: 97 */         for (AnnotationTableTypeEntry entry : this.entries)
/* 104:    */         {
/* 105: 98 */           entry.dump(d);
/* 106: 99 */           d.print(' ');
/* 107:    */         }
/* 108:    */       }
/* 109:102 */       d.print(this.outerThis.getRawShortName());
/* 110:103 */       if (this.inner != null)
/* 111:    */       {
/* 112:104 */         d.print('.');
/* 113:105 */         this.inner.dump(d);
/* 114:    */       }
/* 115:107 */       return d;
/* 116:    */     }
/* 117:    */     
/* 118:    */     private class Iterator
/* 119:    */       implements JavaAnnotatedTypeIterator
/* 120:    */     {
/* 121:    */       private Iterator() {}
/* 122:    */       
/* 123:    */       public JavaAnnotatedTypeIterator moveArray(DecompilerComments comments)
/* 124:    */       {
/* 125:114 */         return this;
/* 126:    */       }
/* 127:    */       
/* 128:    */       public JavaAnnotatedTypeIterator moveBound(DecompilerComments comments)
/* 129:    */       {
/* 130:119 */         return this;
/* 131:    */       }
/* 132:    */       
/* 133:    */       public JavaAnnotatedTypeIterator moveNested(DecompilerComments comments)
/* 134:    */       {
/* 135:124 */         return JavaRefTypeInstance.Annotated.this.inner.pathIterator();
/* 136:    */       }
/* 137:    */       
/* 138:    */       public JavaAnnotatedTypeIterator moveParameterized(int index, DecompilerComments comments)
/* 139:    */       {
/* 140:129 */         return this;
/* 141:    */       }
/* 142:    */       
/* 143:    */       public void apply(AnnotationTableTypeEntry entry)
/* 144:    */       {
/* 145:134 */         JavaRefTypeInstance.Annotated.this.entries.add(entry);
/* 146:    */       }
/* 147:    */     }
/* 148:    */   }
/* 149:    */   
/* 150:    */   public boolean isObject()
/* 151:    */   {
/* 152:142 */     return true;
/* 153:    */   }
/* 154:    */   
/* 155:    */   public void markNotInner()
/* 156:    */   {
/* 157:146 */     this.innerClassInfo = InnerClassInfo.NOT;
/* 158:147 */     this.shortName = getShortName(this.className, this.innerClassInfo);
/* 159:148 */     this.suggestedVarName = null;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public String suggestVarName()
/* 163:    */   {
/* 164:153 */     if (this.suggestedVarName != null) {
/* 165:153 */       return this.suggestedVarName;
/* 166:    */     }
/* 167:155 */     String displayName = this.shortName;
/* 168:156 */     if (displayName.isEmpty()) {
/* 169:156 */       return null;
/* 170:    */     }
/* 171:157 */     char[] chars = displayName.toCharArray();
/* 172:158 */     int x = 0;
/* 173:159 */     int len = chars.length;
/* 174:160 */     for (x = 0; x < len; x++)
/* 175:    */     {
/* 176:161 */       char c = chars[x];
/* 177:162 */       if ((c < '0') || (c > '9')) {
/* 178:    */         break;
/* 179:    */       }
/* 180:    */     }
/* 181:165 */     if (x >= len) {
/* 182:165 */       return null;
/* 183:    */     }
/* 184:166 */     chars[x] = Character.toLowerCase(chars[x]);
/* 185:167 */     this.suggestedVarName = new String(chars, x, len - x);
/* 186:168 */     return this.suggestedVarName;
/* 187:    */   }
/* 188:    */   
/* 189:    */   private JavaRefTypeInstance(String className, String displayableName, JavaRefTypeInstance[] supers)
/* 190:    */   {
/* 191:172 */     this.innerClassInfo = InnerClassInfo.NOT;
/* 192:173 */     this.dcCommonState = null;
/* 193:174 */     this.className = className;
/* 194:175 */     this.shortName = displayableName;
/* 195:176 */     Map<JavaRefTypeInstance, JavaGenericRefTypeInstance> tmp = MapFactory.newMap();
/* 196:177 */     Map<JavaRefTypeInstance, BindingSuperContainer.Route> routes = MapFactory.newMap();
/* 197:178 */     for (JavaRefTypeInstance supr : supers)
/* 198:    */     {
/* 199:179 */       tmp.put(supr, null);
/* 200:180 */       routes.put(supr, BindingSuperContainer.Route.EXTENSION);
/* 201:    */     }
/* 202:182 */     tmp.put(this, null);
/* 203:    */     
/* 204:184 */     this.cachedBindingSupers = new BindingSuperContainer(null, tmp, routes);
/* 205:    */   }
/* 206:    */   
/* 207:    */   public static JavaRefTypeInstance create(String rawClassName, DCCommonState dcCommonState)
/* 208:    */   {
/* 209:191 */     return new JavaRefTypeInstance(rawClassName, dcCommonState);
/* 210:    */   }
/* 211:    */   
/* 212:    */   public static Pair<JavaRefTypeInstance, JavaRefTypeInstance> createKnownInnerOuter(String inner, String outer, JavaRefTypeInstance outerType, DCCommonState dcCommonState)
/* 213:    */   {
/* 214:195 */     if (outerType == null) {
/* 215:195 */       outerType = new JavaRefTypeInstance(outer, dcCommonState);
/* 216:    */     }
/* 217:    */     JavaRefTypeInstance innerType;
/* 218:    */     JavaRefTypeInstance innerType;
/* 219:197 */     if (!inner.startsWith(outer)) {
/* 220:199 */       innerType = new JavaRefTypeInstance(inner, dcCommonState);
/* 221:    */     } else {
/* 222:201 */       innerType = new JavaRefTypeInstance(inner, outerType, dcCommonState);
/* 223:    */     }
/* 224:203 */     return Pair.make(innerType, outerType);
/* 225:    */   }
/* 226:    */   
/* 227:    */   public static JavaRefTypeInstance createTypeConstant(String rawClassName, String displayableName, JavaRefTypeInstance... supers)
/* 228:    */   {
/* 229:210 */     return new JavaRefTypeInstance(rawClassName, displayableName, supers);
/* 230:    */   }
/* 231:    */   
/* 232:    */   public StackType getStackType()
/* 233:    */   {
/* 234:215 */     return StackType.REF;
/* 235:    */   }
/* 236:    */   
/* 237:    */   public void dumpInto(Dumper d, TypeUsageInformation typeUsageInformation)
/* 238:    */   {
/* 239:220 */     String res = typeUsageInformation.getName(this);
/* 240:221 */     if (res == null) {
/* 241:221 */       throw new IllegalStateException();
/* 242:    */     }
/* 243:222 */     d.print(res);
/* 244:    */   }
/* 245:    */   
/* 246:    */   public String getPackageName()
/* 247:    */   {
/* 248:226 */     return (String)ClassNameUtils.getPackageAndClassNames(getRawName()).getFirst();
/* 249:    */   }
/* 250:    */   
/* 251:    */   public String toString()
/* 252:    */   {
/* 253:231 */     return new ToStringDumper().dump(this).toString();
/* 254:    */   }
/* 255:    */   
/* 256:    */   public JavaTypeInstance getArrayStrippedType()
/* 257:    */   {
/* 258:236 */     return this;
/* 259:    */   }
/* 260:    */   
/* 261:    */   public int getNumArrayDimensions()
/* 262:    */   {
/* 263:241 */     return 0;
/* 264:    */   }
/* 265:    */   
/* 266:    */   public String getRawName()
/* 267:    */   {
/* 268:246 */     return this.className;
/* 269:    */   }
/* 270:    */   
/* 271:    */   public String getRawShortName()
/* 272:    */   {
/* 273:250 */     return this.shortName;
/* 274:    */   }
/* 275:    */   
/* 276:    */   public int hashCode()
/* 277:    */   {
/* 278:255 */     return 31 + this.className.hashCode();
/* 279:    */   }
/* 280:    */   
/* 281:    */   public InnerClassInfo getInnerClassHereInfo()
/* 282:    */   {
/* 283:260 */     return this.innerClassInfo;
/* 284:    */   }
/* 285:    */   
/* 286:    */   public BindingSuperContainer getBindingSupers()
/* 287:    */   {
/* 288:265 */     if (this.cachedBindingSupers != BindingSuperContainer.POISON) {
/* 289:265 */       return this.cachedBindingSupers;
/* 290:    */     }
/* 291:    */     try
/* 292:    */     {
/* 293:267 */       ClassFile classFile = getClassFile();
/* 294:268 */       this.cachedBindingSupers = (classFile == null ? null : classFile.getBindingSupers());
/* 295:    */     }
/* 296:    */     catch (CannotLoadClassException e)
/* 297:    */     {
/* 298:270 */       this.cachedBindingSupers = null;
/* 299:    */     }
/* 300:272 */     return this.cachedBindingSupers;
/* 301:    */   }
/* 302:    */   
/* 303:    */   public boolean equals(Object o)
/* 304:    */   {
/* 305:277 */     if (o == this) {
/* 306:277 */       return true;
/* 307:    */     }
/* 308:278 */     if (!(o instanceof JavaRefTypeInstance)) {
/* 309:278 */       return false;
/* 310:    */     }
/* 311:279 */     JavaRefTypeInstance other = (JavaRefTypeInstance)o;
/* 312:280 */     return other.className.equals(this.className);
/* 313:    */   }
/* 314:    */   
/* 315:    */   public boolean isComplexType()
/* 316:    */   {
/* 317:285 */     return true;
/* 318:    */   }
/* 319:    */   
/* 320:    */   public boolean isUsableType()
/* 321:    */   {
/* 322:290 */     return true;
/* 323:    */   }
/* 324:    */   
/* 325:    */   public JavaTypeInstance removeAnArrayIndirection()
/* 326:    */   {
/* 327:299 */     return this;
/* 328:    */   }
/* 329:    */   
/* 330:    */   public JavaTypeInstance getDeGenerifiedType()
/* 331:    */   {
/* 332:304 */     return this;
/* 333:    */   }
/* 334:    */   
/* 335:    */   public RawJavaType getRawTypeOfSimpleType()
/* 336:    */   {
/* 337:309 */     return RawJavaType.REF;
/* 338:    */   }
/* 339:    */   
/* 340:    */   public boolean implicitlyCastsTo(JavaTypeInstance other, @Nullable GenericTypeBinder gtb)
/* 341:    */   {
/* 342:314 */     if (equals(other)) {
/* 343:314 */       return true;
/* 344:    */     }
/* 345:315 */     if ((other instanceof RawJavaType))
/* 346:    */     {
/* 347:319 */       RawJavaType thisAsRaw = RawJavaType.getUnboxedTypeFor(this);
/* 348:320 */       if (thisAsRaw != null) {
/* 349:321 */         return thisAsRaw.implicitlyCastsTo(other, gtb);
/* 350:    */       }
/* 351:    */     }
/* 352:324 */     if ((gtb != null) && ((other instanceof JavaGenericPlaceholderTypeInstance)))
/* 353:    */     {
/* 354:325 */       other = gtb.getBindingFor(other);
/* 355:326 */       if (!(other instanceof JavaGenericPlaceholderTypeInstance)) {
/* 356:327 */         return implicitlyCastsTo(other, gtb);
/* 357:    */       }
/* 358:    */     }
/* 359:330 */     if ((other instanceof JavaGenericPlaceholderTypeInstance)) {
/* 360:331 */       return false;
/* 361:    */     }
/* 362:333 */     JavaTypeInstance otherRaw = other.getDeGenerifiedType();
/* 363:334 */     BindingSuperContainer thisBindingSuper = getBindingSupers();
/* 364:335 */     if (thisBindingSuper == null) {
/* 365:336 */       return false;
/* 366:    */     }
/* 367:338 */     return thisBindingSuper.containsBase(otherRaw);
/* 368:    */   }
/* 369:    */   
/* 370:    */   public boolean impreciseCanCastTo(JavaTypeInstance other, GenericTypeBinder gtb)
/* 371:    */   {
/* 372:346 */     if ((this == other) || (equals(other))) {
/* 373:346 */       return true;
/* 374:    */     }
/* 375:347 */     if ((other instanceof RawJavaType))
/* 376:    */     {
/* 377:351 */       RawJavaType thisAsRaw = RawJavaType.getUnboxedTypeFor(this);
/* 378:352 */       if (thisAsRaw != null) {
/* 379:353 */         return thisAsRaw.equals(other);
/* 380:    */       }
/* 381:355 */       return true;
/* 382:    */     }
/* 383:357 */     return true;
/* 384:    */   }
/* 385:    */   
/* 386:    */   public boolean correctCanCastTo(JavaTypeInstance other, GenericTypeBinder gtb)
/* 387:    */   {
/* 388:362 */     if ((this == other) || (equals(other))) {
/* 389:362 */       return true;
/* 390:    */     }
/* 391:363 */     if ((other instanceof RawJavaType))
/* 392:    */     {
/* 393:367 */       RawJavaType thisAsRaw = RawJavaType.getUnboxedTypeFor(this);
/* 394:368 */       if (thisAsRaw != null) {
/* 395:369 */         return thisAsRaw.equals(other);
/* 396:    */       }
/* 397:371 */       return true;
/* 398:    */     }
/* 399:373 */     BindingSuperContainer bindingSuperContainer = getBindingSupers();
/* 400:374 */     if (bindingSuperContainer == null) {
/* 401:376 */       return true;
/* 402:    */     }
/* 403:378 */     if (bindingSuperContainer.containsBase(other)) {
/* 404:379 */       return true;
/* 405:    */     }
/* 406:381 */     bindingSuperContainer = other.getBindingSupers();
/* 407:382 */     if (bindingSuperContainer == null) {
/* 408:383 */       return true;
/* 409:    */     }
/* 410:385 */     if (bindingSuperContainer.containsBase(this)) {
/* 411:386 */       return true;
/* 412:    */     }
/* 413:388 */     return false;
/* 414:    */   }
/* 415:    */   
/* 416:    */   public ClassFile getClassFile()
/* 417:    */   {
/* 418:393 */     if (this.dcCommonState == null) {
/* 419:393 */       return null;
/* 420:    */     }
/* 421:    */     try
/* 422:    */     {
/* 423:395 */       return this.dcCommonState.getClassFile(this);
/* 424:    */     }
/* 425:    */     catch (CannotLoadClassException e) {}
/* 426:398 */     return null;
/* 427:    */   }
/* 428:    */   
/* 429:    */   private static String getShortName(String fullClassName, InnerClassInfo innerClassInfo)
/* 430:    */   {
/* 431:403 */     if (innerClassInfo.isInnerClass()) {
/* 432:404 */       fullClassName = fullClassName.replace('$', '.');
/* 433:    */     }
/* 434:406 */     int idxlast = fullClassName.lastIndexOf('.');
/* 435:407 */     String partname = idxlast == -1 ? fullClassName : fullClassName.substring(idxlast + 1);
/* 436:408 */     return partname;
/* 437:    */   }
/* 438:    */   
/* 439:    */   public void collectInto(TypeUsageCollector typeUsageCollector)
/* 440:    */   {
/* 441:413 */     typeUsageCollector.collectRefType(this);
/* 442:    */   }
/* 443:    */   
/* 444:    */   private static class RefTypeInnerClassInfo
/* 445:    */     implements InnerClassInfo
/* 446:    */   {
/* 447:    */     private final JavaRefTypeInstance outerClass;
/* 448:418 */     private boolean isAnonymous = false;
/* 449:419 */     private boolean isMethodScoped = false;
/* 450:420 */     private boolean hideSyntheticThis = false;
/* 451:421 */     private boolean hideSyntheticFriendClass = false;
/* 452:    */     
/* 453:    */     private RefTypeInnerClassInfo(JavaRefTypeInstance outerClass)
/* 454:    */     {
/* 455:424 */       this.outerClass = outerClass;
/* 456:    */     }
/* 457:    */     
/* 458:    */     public void collectTransitiveDegenericParents(Set<JavaTypeInstance> parents)
/* 459:    */     {
/* 460:430 */       parents.add(this.outerClass);
/* 461:431 */       this.outerClass.getInnerClassHereInfo().collectTransitiveDegenericParents(parents);
/* 462:    */     }
/* 463:    */     
/* 464:    */     public boolean isInnerClass()
/* 465:    */     {
/* 466:436 */       return true;
/* 467:    */     }
/* 468:    */     
/* 469:    */     public boolean isAnonymousClass()
/* 470:    */     {
/* 471:441 */       return this.isAnonymous;
/* 472:    */     }
/* 473:    */     
/* 474:    */     public boolean isMethodScopedClass()
/* 475:    */     {
/* 476:446 */       return this.isMethodScoped;
/* 477:    */     }
/* 478:    */     
/* 479:    */     public void markMethodScoped(boolean isAnonymous)
/* 480:    */     {
/* 481:451 */       this.isAnonymous = isAnonymous;
/* 482:452 */       this.isMethodScoped = true;
/* 483:    */     }
/* 484:    */     
/* 485:    */     public boolean isInnerClassOf(JavaTypeInstance possibleParent)
/* 486:    */     {
/* 487:457 */       if (this.outerClass == null) {
/* 488:457 */         return false;
/* 489:    */       }
/* 490:458 */       return possibleParent.equals(this.outerClass);
/* 491:    */     }
/* 492:    */     
/* 493:    */     public boolean isTransitiveInnerClassOf(JavaTypeInstance possibleParent)
/* 494:    */     {
/* 495:463 */       if (this.outerClass == null) {
/* 496:463 */         return false;
/* 497:    */       }
/* 498:464 */       if (possibleParent.equals(this.outerClass)) {
/* 499:464 */         return true;
/* 500:    */       }
/* 501:465 */       InnerClassInfo upper = this.outerClass.getInnerClassHereInfo();
/* 502:466 */       if (!upper.isInnerClass()) {
/* 503:466 */         return false;
/* 504:    */       }
/* 505:467 */       return upper.isTransitiveInnerClassOf(possibleParent);
/* 506:    */     }
/* 507:    */     
/* 508:    */     public void setHideSyntheticThis()
/* 509:    */     {
/* 510:472 */       this.hideSyntheticThis = true;
/* 511:    */     }
/* 512:    */     
/* 513:    */     public void hideSyntheticFriendClass()
/* 514:    */     {
/* 515:477 */       this.hideSyntheticFriendClass = true;
/* 516:    */     }
/* 517:    */     
/* 518:    */     public boolean isSyntheticFriendClass()
/* 519:    */     {
/* 520:482 */       return this.hideSyntheticFriendClass;
/* 521:    */     }
/* 522:    */     
/* 523:    */     public JavaRefTypeInstance getOuterClass()
/* 524:    */     {
/* 525:487 */       return this.outerClass;
/* 526:    */     }
/* 527:    */     
/* 528:    */     public boolean isHideSyntheticThis()
/* 529:    */     {
/* 530:492 */       return this.hideSyntheticThis;
/* 531:    */     }
/* 532:    */   }
/* 533:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance
 * JD-Core Version:    0.7.0.1
 */