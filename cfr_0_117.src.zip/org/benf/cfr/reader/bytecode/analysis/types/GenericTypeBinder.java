/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.types;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Map;
/*   5:    */ import java.util.Map.Entry;
/*   6:    */ import java.util.Set;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*   8:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*   9:    */ import org.benf.cfr.reader.util.MapFactory;
/*  10:    */ import org.benf.cfr.reader.util.SetFactory;
/*  11:    */ 
/*  12:    */ public class GenericTypeBinder
/*  13:    */ {
/*  14:    */   private final Map<String, JavaTypeInstance> nameToBoundType;
/*  15:    */   
/*  16:    */   private GenericTypeBinder(Map<String, JavaTypeInstance> nameToBoundType)
/*  17:    */   {
/*  18: 19 */     this.nameToBoundType = nameToBoundType;
/*  19:    */   }
/*  20:    */   
/*  21:    */   public static GenericTypeBinder createEmpty()
/*  22:    */   {
/*  23: 24 */     return new GenericTypeBinder(MapFactory.newMap());
/*  24:    */   }
/*  25:    */   
/*  26:    */   public static GenericTypeBinder bind(List<FormalTypeParameter> methodFormalTypeParameters, ClassSignature classSignature, List<JavaTypeInstance> args, JavaGenericRefTypeInstance boundInstance, List<JavaTypeInstance> boundArgs)
/*  27:    */   {
/*  28: 30 */     Map<String, JavaTypeInstance> nameToBoundType = MapFactory.newMap();
/*  29: 32 */     if (boundInstance != null)
/*  30:    */     {
/*  31: 33 */       List<FormalTypeParameter> unboundParameters = classSignature.getFormalTypeParameters();
/*  32: 34 */       List<JavaTypeInstance> boundParameters = boundInstance.getGenericTypes();
/*  33: 36 */       if ((unboundParameters == null) || (boundParameters.size() != unboundParameters.size())) {
/*  34: 41 */         return null;
/*  35:    */       }
/*  36: 44 */       for (int x = 0; x < boundParameters.size(); x++) {
/*  37: 45 */         nameToBoundType.put(((FormalTypeParameter)unboundParameters.get(x)).getName(), boundParameters.get(x));
/*  38:    */       }
/*  39:    */     }
/*  40: 49 */     List<FormalTypeParameter> classFormalTypeParamters = classSignature.getFormalTypeParameters();
/*  41:    */     
/*  42:    */ 
/*  43: 52 */     GenericTypeBinder res = new GenericTypeBinder(nameToBoundType);
/*  44: 54 */     if (((methodFormalTypeParameters != null) && (!methodFormalTypeParameters.isEmpty())) || ((classFormalTypeParamters != null) && (!classFormalTypeParamters.isEmpty())))
/*  45:    */     {
/*  46: 56 */       if (args.size() != boundArgs.size()) {
/*  47: 57 */         throw new IllegalArgumentException();
/*  48:    */       }
/*  49: 60 */       for (int x = 0; x < args.size(); x++)
/*  50:    */       {
/*  51: 61 */         JavaTypeInstance unbound = (JavaTypeInstance)args.get(x);
/*  52: 62 */         JavaTypeInstance bound = (JavaTypeInstance)boundArgs.get(x);
/*  53: 63 */         if (((unbound instanceof JavaArrayTypeInstance)) && ((bound instanceof JavaArrayTypeInstance)) && 
/*  54: 64 */           (unbound.getNumArrayDimensions() == bound.getNumArrayDimensions()))
/*  55:    */         {
/*  56: 65 */           unbound = unbound.getArrayStrippedType();
/*  57: 66 */           bound = bound.getArrayStrippedType();
/*  58:    */         }
/*  59: 69 */         if ((unbound instanceof JavaGenericBaseInstance))
/*  60:    */         {
/*  61: 70 */           JavaGenericBaseInstance unboundGeneric = (JavaGenericBaseInstance)unbound;
/*  62: 71 */           unboundGeneric.tryFindBinding(bound, res);
/*  63:    */         }
/*  64:    */       }
/*  65:    */     }
/*  66: 76 */     return res;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static GenericTypeBinder buildIdentityBindings(JavaGenericRefTypeInstance unbound)
/*  70:    */   {
/*  71: 80 */     List<JavaTypeInstance> typeParameters = unbound.getGenericTypes();
/*  72:    */     
/*  73: 82 */     Map<String, JavaTypeInstance> unboundNames = MapFactory.newMap();
/*  74: 83 */     int x = 0;
/*  75: 83 */     for (int len = typeParameters.size(); x < len; x++)
/*  76:    */     {
/*  77: 84 */       JavaTypeInstance unboundParam = (JavaTypeInstance)typeParameters.get(x);
/*  78: 85 */       if (!(unboundParam instanceof JavaGenericPlaceholderTypeInstance)) {
/*  79: 86 */         throw new ConfusedCFRException("Unbound parameter expected to be placeholder!");
/*  80:    */       }
/*  81: 88 */       unboundNames.put(unboundParam.getRawName(), unboundParam);
/*  82:    */     }
/*  83: 90 */     return new GenericTypeBinder(unboundNames);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public static GenericTypeBinder extractBaseBindings(JavaGenericBaseInstance unbound, JavaTypeInstance maybeBound)
/*  87:    */   {
/*  88: 97 */     if (!(unbound instanceof JavaGenericRefTypeInstance)) {
/*  89: 97 */       return extractBindings(unbound, maybeBound);
/*  90:    */     }
/*  91: 98 */     if (!(maybeBound instanceof JavaGenericRefTypeInstance)) {
/*  92: 98 */       return extractBindings(unbound, maybeBound);
/*  93:    */     }
/*  94:100 */     JavaGenericRefTypeInstance unboundGeneric = (JavaGenericRefTypeInstance)unbound;
/*  95:101 */     JavaGenericRefTypeInstance maybeBoundGeneric = (JavaGenericRefTypeInstance)maybeBound;
/*  96:    */     
/*  97:103 */     BindingSuperContainer maybeBindingContainer = maybeBound.getBindingSupers();
/*  98:104 */     JavaTypeInstance boundAssignable = maybeBindingContainer.getBoundAssignable(maybeBoundGeneric, unboundGeneric);
/*  99:    */     
/* 100:106 */     BindingSuperContainer thisBindingContainer = unbound.getBindingSupers();
/* 101:107 */     GenericTypeBinder binder = extractBindings(unboundGeneric, boundAssignable);
/* 102:    */     
/* 103:109 */     return binder;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public static GenericTypeBinder extractBindings(JavaGenericBaseInstance unbound, JavaTypeInstance maybeBound)
/* 107:    */   {
/* 108:114 */     Map<String, JavaTypeInstance> boundNames = MapFactory.newMap();
/* 109:115 */     doBind(boundNames, unbound, maybeBound);
/* 110:116 */     return new GenericTypeBinder(boundNames);
/* 111:    */   }
/* 112:    */   
/* 113:    */   private static void doBind(Map<String, JavaTypeInstance> boundNames, JavaGenericBaseInstance unbound, JavaTypeInstance maybeBound)
/* 114:    */   {
/* 115:122 */     if (unbound.getClass() == JavaGenericPlaceholderTypeInstance.class)
/* 116:    */     {
/* 117:123 */       JavaGenericPlaceholderTypeInstance placeholder = (JavaGenericPlaceholderTypeInstance)unbound;
/* 118:124 */       boundNames.put(placeholder.getRawName(), maybeBound);
/* 119:125 */       return;
/* 120:    */     }
/* 121:128 */     List<JavaTypeInstance> typeParameters = unbound.getGenericTypes();
/* 122:131 */     if (!(maybeBound instanceof JavaGenericBaseInstance)) {
/* 123:132 */       return;
/* 124:    */     }
/* 125:135 */     JavaGenericBaseInstance bound = (JavaGenericBaseInstance)maybeBound;
/* 126:136 */     List<JavaTypeInstance> boundTypeParameters = bound.getGenericTypes();
/* 127:137 */     if (typeParameters.size() != boundTypeParameters.size()) {
/* 128:138 */       return;
/* 129:    */     }
/* 130:142 */     int x = 0;
/* 131:142 */     for (int len = typeParameters.size(); x < len; x++)
/* 132:    */     {
/* 133:143 */       JavaTypeInstance unboundParam = (JavaTypeInstance)typeParameters.get(x);
/* 134:144 */       JavaTypeInstance boundParam = (JavaTypeInstance)boundTypeParameters.get(x);
/* 135:145 */       if ((unboundParam instanceof JavaGenericBaseInstance)) {
/* 136:148 */         doBind(boundNames, (JavaGenericBaseInstance)unboundParam, boundParam);
/* 137:    */       }
/* 138:    */     }
/* 139:    */   }
/* 140:    */   
/* 141:    */   public void removeBinding(JavaGenericPlaceholderTypeInstance type)
/* 142:    */   {
/* 143:153 */     String name = type.getRawName();
/* 144:154 */     this.nameToBoundType.remove(name);
/* 145:    */   }
/* 146:    */   
/* 147:    */   public JavaTypeInstance getBindingFor(FormalTypeParameter formalTypeParameter)
/* 148:    */   {
/* 149:158 */     return (JavaTypeInstance)this.nameToBoundType.get(formalTypeParameter.getName());
/* 150:    */   }
/* 151:    */   
/* 152:    */   public JavaTypeInstance getBindingFor(JavaTypeInstance maybeUnbound)
/* 153:    */   {
/* 154:162 */     if ((maybeUnbound instanceof JavaGenericPlaceholderTypeInstance))
/* 155:    */     {
/* 156:163 */       JavaGenericPlaceholderTypeInstance placeholder = (JavaGenericPlaceholderTypeInstance)maybeUnbound;
/* 157:164 */       String name = placeholder.getRawName();
/* 158:165 */       JavaTypeInstance bound = (JavaTypeInstance)this.nameToBoundType.get(name);
/* 159:166 */       if (bound != null) {
/* 160:167 */         return bound;
/* 161:    */       }
/* 162:    */     }
/* 163:169 */     else if ((maybeUnbound instanceof JavaGenericBaseInstance))
/* 164:    */     {
/* 165:171 */       return ((JavaGenericBaseInstance)maybeUnbound).getBoundInstance(this);
/* 166:    */     }
/* 167:173 */     return maybeUnbound;
/* 168:    */   }
/* 169:    */   
/* 170:    */   private static boolean isBetterBinding(JavaTypeInstance isBetter, JavaTypeInstance than)
/* 171:    */   {
/* 172:178 */     if (than == null) {
/* 173:178 */       return true;
/* 174:    */     }
/* 175:179 */     if ((isBetter instanceof JavaGenericPlaceholderTypeInstance)) {
/* 176:179 */       return false;
/* 177:    */     }
/* 178:180 */     return true;
/* 179:    */   }
/* 180:    */   
/* 181:    */   public void suggestOnlyNullBinding(JavaGenericPlaceholderTypeInstance type)
/* 182:    */   {
/* 183:184 */     String name = type.getRawName();
/* 184:185 */     if (this.nameToBoundType.containsKey(name)) {
/* 185:185 */       return;
/* 186:    */     }
/* 187:186 */     this.nameToBoundType.put(name, TypeConstants.OBJECT);
/* 188:    */   }
/* 189:    */   
/* 190:    */   public void suggestBindingFor(String name, JavaTypeInstance binding)
/* 191:    */   {
/* 192:190 */     JavaTypeInstance alreadyBound = (JavaTypeInstance)this.nameToBoundType.get(name);
/* 193:191 */     if (isBetterBinding(binding, alreadyBound)) {
/* 194:192 */       this.nameToBoundType.put(name, binding);
/* 195:    */     }
/* 196:    */   }
/* 197:    */   
/* 198:    */   public GenericTypeBinder mergeWith(GenericTypeBinder other, boolean mergeToCommonClass)
/* 199:    */   {
/* 200:197 */     Set<String> keys = SetFactory.newSet(this.nameToBoundType.keySet());
/* 201:198 */     keys.addAll(other.nameToBoundType.keySet());
/* 202:199 */     Map<String, JavaTypeInstance> res = MapFactory.newMap();
/* 203:200 */     for (String key : keys)
/* 204:    */     {
/* 205:201 */       JavaTypeInstance t1 = (JavaTypeInstance)this.nameToBoundType.get(key);
/* 206:202 */       JavaTypeInstance t2 = (JavaTypeInstance)other.nameToBoundType.get(key);
/* 207:203 */       if (t1 == null) {
/* 208:204 */         res.put(key, t2);
/* 209:207 */       } else if (t2 == null) {
/* 210:208 */         res.put(key, t1);
/* 211:215 */       } else if (mergeToCommonClass)
/* 212:    */       {
/* 213:216 */         if (t1.implicitlyCastsTo(t2, other))
/* 214:    */         {
/* 215:217 */           res.put(key, t2);
/* 216:    */         }
/* 217:220 */         else if (t2.implicitlyCastsTo(t1, other))
/* 218:    */         {
/* 219:221 */           res.put(key, t1);
/* 220:    */         }
/* 221:    */         else
/* 222:    */         {
/* 223:227 */           InferredJavaType clash = InferredJavaType.mkClash(new JavaTypeInstance[] { t1, t2 });
/* 224:228 */           clash.collapseTypeClash();
/* 225:229 */           res.put(key, clash.getJavaTypeInstance());
/* 226:    */         }
/* 227:    */       }
/* 228:    */       else {
/* 229:232 */         return null;
/* 230:    */       }
/* 231:    */     }
/* 232:234 */     return new GenericTypeBinder(res);
/* 233:    */   }
/* 234:    */   
/* 235:    */   public GenericTypeBinder createAssignmentRhsBindings(GenericTypeBinder rhsBinder)
/* 236:    */   {
/* 237:255 */     if (!this.nameToBoundType.keySet().equals(rhsBinder.nameToBoundType.keySet())) {
/* 238:255 */       return null;
/* 239:    */     }
/* 240:257 */     Map<String, JavaTypeInstance> resultMap = MapFactory.newMap();
/* 241:258 */     for (Map.Entry<String, JavaTypeInstance> entry : this.nameToBoundType.entrySet())
/* 242:    */     {
/* 243:259 */       String key = (String)entry.getKey();
/* 244:260 */       JavaTypeInstance lhstype = (JavaTypeInstance)entry.getValue();
/* 245:261 */       JavaTypeInstance rhstype = (JavaTypeInstance)rhsBinder.nameToBoundType.get(key);
/* 246:262 */       JavaTypeInstance lhsStripped = lhstype.getDeGenerifiedType();
/* 247:263 */       JavaTypeInstance rhsStripped = rhstype.getDeGenerifiedType();
/* 248:264 */       if ((!lhsStripped.equals(rhsStripped)) && (!(rhstype instanceof JavaGenericPlaceholderTypeInstance)))
/* 249:    */       {
/* 250:265 */         BindingSuperContainer rhsBoundSupers = rhstype.getBindingSupers();
/* 251:266 */         if ((rhsBoundSupers == null) || (!rhsBoundSupers.containsBase(lhstype.getDeGenerifiedType()))) {
/* 252:266 */           return null;
/* 253:    */         }
/* 254:    */       }
/* 255:269 */       JavaTypeInstance bestGuess = null;
/* 256:270 */       if ((lhstype instanceof JavaWildcardTypeInstance)) {
/* 257:271 */         bestGuess = rhstype;
/* 258:    */       } else {
/* 259:273 */         bestGuess = lhstype;
/* 260:    */       }
/* 261:275 */       if ((bestGuess instanceof JavaGenericPlaceholderTypeInstance)) {
/* 262:275 */         return null;
/* 263:    */       }
/* 264:276 */       resultMap.put(key, bestGuess);
/* 265:    */     }
/* 266:278 */     return new GenericTypeBinder(resultMap);
/* 267:    */   }
/* 268:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.GenericTypeBinder
 * JD-Core Version:    0.7.0.1
 */