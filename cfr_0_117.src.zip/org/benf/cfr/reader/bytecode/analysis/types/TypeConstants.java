/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.types;
/*  2:   */ 
/*  3:   */ public abstract interface TypeConstants
/*  4:   */ {
/*  5: 4 */   public static final JavaRefTypeInstance OBJECT = JavaRefTypeInstance.createTypeConstant("java.lang.Object", "Object", new JavaRefTypeInstance[0]);
/*  6: 5 */   public static final JavaRefTypeInstance ENUM = JavaRefTypeInstance.createTypeConstant("java.lang.Enum", "Enum", new JavaRefTypeInstance[] { OBJECT });
/*  7: 6 */   public static final JavaRefTypeInstance ASSERTION_ERROR = JavaRefTypeInstance.createTypeConstant("java.lang.AssertionError", "AssertionError", new JavaRefTypeInstance[] { OBJECT });
/*  8: 7 */   public static final JavaRefTypeInstance CHAR_SEQUENCE = JavaRefTypeInstance.createTypeConstant("java.lang.CharSequence", "CharSequence", new JavaRefTypeInstance[] { OBJECT });
/*  9: 8 */   public static final JavaRefTypeInstance STRING = JavaRefTypeInstance.createTypeConstant("java.lang.String", "String", new JavaRefTypeInstance[] { OBJECT, CHAR_SEQUENCE });
/* 10: 9 */   public static final JavaRefTypeInstance CLASS = JavaRefTypeInstance.createTypeConstant("java.lang.Class", "Class", new JavaRefTypeInstance[] { OBJECT });
/* 11:10 */   public static final JavaRefTypeInstance ITERABLE = JavaRefTypeInstance.createTypeConstant("java.lang.Iterable", "Iterable", new JavaRefTypeInstance[] { OBJECT });
/* 12:11 */   public static final JavaRefTypeInstance CLOSEABLE = JavaRefTypeInstance.createTypeConstant("java.io.Closeable", "Closeable", new JavaRefTypeInstance[] { OBJECT });
/* 13:12 */   public static final JavaRefTypeInstance THROWABLE = JavaRefTypeInstance.createTypeConstant("java.lang.Throwable", "Throwable", new JavaRefTypeInstance[] { OBJECT });
/* 14:13 */   public static final JavaRefTypeInstance SUPPLIER = JavaRefTypeInstance.createTypeConstant("java.util.function.Supplier", "Object", new JavaRefTypeInstance[0]);
/* 15:14 */   public static final JavaRefTypeInstance SCALA_SIGNATURE = JavaRefTypeInstance.createTypeConstant("scala.reflect.ScalaSignature", "Object", new JavaRefTypeInstance[0]);
/* 16:   */   public static final String boxingNameBoolean = "java.lang.Boolean";
/* 17:   */   public static final String boxingNameByte = "java.lang.Byte";
/* 18:   */   public static final String boxingNameShort = "java.lang.Short";
/* 19:   */   public static final String boxingNameChar = "java.lang.Character";
/* 20:   */   public static final String boxingNameInt = "java.lang.Integer";
/* 21:   */   public static final String boxingNameLong = "java.lang.Long";
/* 22:   */   public static final String boxingNameFloat = "java.lang.Float";
/* 23:   */   public static final String boxingNameDouble = "java.lang.Double";
/* 24:   */   public static final String boxingNameNumber = "java.lang.Number";
/* 25:   */   public static final String throwableName = "java.lang.Throwable";
/* 26:   */   public static final String stringName = "java.lang.String";
/* 27:   */   public static final String charSequenceName = "java.lang.CharSequence";
/* 28:   */   public static final String stringBuilderName = "java.lang.StringBuilder";
/* 29:   */   public static final String stringBufferName = "java.lang.StringBuffer";
/* 30:   */   public static final String className = "java.lang.Class";
/* 31:   */   public static final String objectName = "java.lang.Object";
/* 32:   */   public static final String lambdaMetaFactoryName = "java.lang.invoke.LambdaMetafactory";
/* 33:   */   public static final String supplierName = "java.util.function.Supplier";
/* 34:   */   public static final String runtimeExceptionPath = "java/lang/RuntimeException.class";
/* 35:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.TypeConstants
 * JD-Core Version:    0.7.0.1
 */