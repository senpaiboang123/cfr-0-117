/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.types;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Map;
/*  5:   */ import org.benf.cfr.reader.entities.ClassFile;
/*  6:   */ import org.benf.cfr.reader.util.ListFactory;
/*  7:   */ 
/*  8:   */ public class BindingSuperContainer
/*  9:   */ {
/* 10:   */   public static enum Route
/* 11:   */   {
/* 12:12 */     IDENTITY,  EXTENSION,  INTERFACE;
/* 13:   */     
/* 14:   */     private Route() {}
/* 15:   */   }
/* 16:   */   
/* 17:17 */   public static BindingSuperContainer POISON = new BindingSuperContainer(null, null, null);
/* 18:   */   private final ClassFile thisClass;
/* 19:   */   private final Map<JavaRefTypeInstance, JavaGenericRefTypeInstance> boundSuperClasses;
/* 20:   */   private final Map<JavaRefTypeInstance, Route> boundSuperRoute;
/* 21:   */   
/* 22:   */   public BindingSuperContainer(ClassFile thisClass, Map<JavaRefTypeInstance, JavaGenericRefTypeInstance> boundSuperClasses, Map<JavaRefTypeInstance, Route> boundSuperRoute)
/* 23:   */   {
/* 24:25 */     this.thisClass = thisClass;
/* 25:26 */     this.boundSuperClasses = boundSuperClasses;
/* 26:27 */     this.boundSuperRoute = boundSuperRoute;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public JavaGenericRefTypeInstance getBoundAssignable(JavaGenericRefTypeInstance assignable, JavaGenericRefTypeInstance superType)
/* 30:   */   {
/* 31:31 */     JavaRefTypeInstance baseKey = superType.getDeGenerifiedType();
/* 32:   */     
/* 33:33 */     JavaGenericRefTypeInstance reboundBase = (JavaGenericRefTypeInstance)this.boundSuperClasses.get(baseKey);
/* 34:34 */     if (reboundBase == null) {
/* 35:36 */       return assignable;
/* 36:   */     }
/* 37:38 */     GenericTypeBinder genericTypeBinder = GenericTypeBinder.extractBindings(reboundBase, superType);
/* 38:39 */     JavaGenericRefTypeInstance boundAssignable = assignable.getBoundInstance(genericTypeBinder);
/* 39:40 */     return boundAssignable;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public boolean containsBase(JavaTypeInstance possBase)
/* 43:   */   {
/* 44:44 */     if (!(possBase instanceof JavaRefTypeInstance)) {
/* 45:44 */       return false;
/* 46:   */     }
/* 47:45 */     return this.boundSuperClasses.containsKey(possBase);
/* 48:   */   }
/* 49:   */   
/* 50:   */   public Map<JavaRefTypeInstance, JavaGenericRefTypeInstance> getBoundSuperClasses()
/* 51:   */   {
/* 52:49 */     return this.boundSuperClasses;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public JavaTypeInstance getMostLikelyAnonymousType(JavaTypeInstance original)
/* 56:   */   {
/* 57:64 */     List<JavaRefTypeInstance> orderedTypes = ListFactory.newList(this.boundSuperClasses.keySet());
/* 58:65 */     if ((orderedTypes.isEmpty()) || (orderedTypes.size() == 1)) {
/* 59:65 */       return original;
/* 60:   */     }
/* 61:66 */     JavaRefTypeInstance candidate = (JavaRefTypeInstance)orderedTypes.get(1);
/* 62:67 */     if (candidate.equals(TypeConstants.OBJECT)) {
/* 63:68 */       if (orderedTypes.size() >= 3) {
/* 64:69 */         candidate = (JavaRefTypeInstance)orderedTypes.get(2);
/* 65:   */       } else {
/* 66:71 */         return original;
/* 67:   */       }
/* 68:   */     }
/* 69:74 */     JavaTypeInstance generic = (JavaTypeInstance)this.boundSuperClasses.get(candidate);
/* 70:75 */     if (generic == null) {
/* 71:76 */       return candidate;
/* 72:   */     }
/* 73:78 */     return generic;
/* 74:   */   }
/* 75:   */   
/* 76:   */   public JavaGenericRefTypeInstance getBoundSuperForBase(JavaTypeInstance possBase)
/* 77:   */   {
/* 78:83 */     if (!(possBase instanceof JavaRefTypeInstance)) {
/* 79:83 */       return null;
/* 80:   */     }
/* 81:84 */     return (JavaGenericRefTypeInstance)this.boundSuperClasses.get(possBase);
/* 82:   */   }
/* 83:   */   
/* 84:   */   public Map<JavaRefTypeInstance, Route> getBoundSuperRoute()
/* 85:   */   {
/* 86:88 */     return this.boundSuperRoute;
/* 87:   */   }
/* 88:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.BindingSuperContainer
 * JD-Core Version:    0.7.0.1
 */