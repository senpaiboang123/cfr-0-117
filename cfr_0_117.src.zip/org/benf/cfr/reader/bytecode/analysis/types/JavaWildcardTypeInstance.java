/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.types;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.types.annotated.JavaAnnotatedTypeInstance;
/*   5:    */ import org.benf.cfr.reader.entities.annotations.AnnotationTableTypeEntry;
/*   6:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*   7:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*   8:    */ import org.benf.cfr.reader.state.TypeUsageInformation;
/*   9:    */ import org.benf.cfr.reader.util.DecompilerComments;
/*  10:    */ import org.benf.cfr.reader.util.ListFactory;
/*  11:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  12:    */ import org.benf.cfr.reader.util.output.ToStringDumper;
/*  13:    */ 
/*  14:    */ public class JavaWildcardTypeInstance
/*  15:    */   implements JavaGenericBaseInstance
/*  16:    */ {
/*  17:    */   private final WildcardType wildcardType;
/*  18:    */   private final JavaTypeInstance underlyingType;
/*  19:    */   
/*  20:    */   public JavaWildcardTypeInstance(WildcardType wildcardType, JavaTypeInstance underlyingType)
/*  21:    */   {
/*  22: 20 */     this.wildcardType = wildcardType;
/*  23: 21 */     this.underlyingType = underlyingType;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public JavaTypeInstance getBoundInstance(GenericTypeBinder genericTypeBinder)
/*  27:    */   {
/*  28: 27 */     if ((this.underlyingType instanceof JavaGenericBaseInstance)) {
/*  29: 28 */       return ((JavaGenericBaseInstance)this.underlyingType).getBoundInstance(genericTypeBinder);
/*  30:    */     }
/*  31: 30 */     return this.underlyingType;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public JavaAnnotatedTypeInstance getAnnotatedInstance()
/*  35:    */   {
/*  36: 36 */     return new Annotated(null);
/*  37:    */   }
/*  38:    */   
/*  39:    */   private class Annotated
/*  40:    */     implements JavaAnnotatedTypeInstance
/*  41:    */   {
/*  42: 40 */     private final List<AnnotationTableTypeEntry> entries = ListFactory.newList();
/*  43:    */     private final JavaAnnotatedTypeInstance underlyingAnnotated;
/*  44:    */     
/*  45:    */     private Annotated()
/*  46:    */     {
/*  47: 44 */       this.underlyingAnnotated = JavaWildcardTypeInstance.this.underlyingType.getAnnotatedInstance();
/*  48:    */     }
/*  49:    */     
/*  50:    */     public JavaAnnotatedTypeIterator pathIterator()
/*  51:    */     {
/*  52: 49 */       return new Iterator(null);
/*  53:    */     }
/*  54:    */     
/*  55:    */     public Dumper dump(Dumper d)
/*  56:    */     {
/*  57: 54 */       for (AnnotationTableTypeEntry entry : this.entries)
/*  58:    */       {
/*  59: 55 */         entry.dump(d);
/*  60: 56 */         d.print(' ');
/*  61:    */       }
/*  62: 58 */       d.print("? ").print(JavaWildcardTypeInstance.this.wildcardType.toString()).print(' ');
/*  63: 59 */       this.underlyingAnnotated.dump(d);
/*  64: 60 */       return d;
/*  65:    */     }
/*  66:    */     
/*  67:    */     private class Iterator
/*  68:    */       extends JavaAnnotatedTypeIterator.BaseAnnotatedTypeIterator
/*  69:    */     {
/*  70:    */       private Iterator() {}
/*  71:    */       
/*  72:    */       public JavaAnnotatedTypeIterator moveBound(DecompilerComments comments)
/*  73:    */       {
/*  74: 67 */         return JavaWildcardTypeInstance.Annotated.this.underlyingAnnotated.pathIterator();
/*  75:    */       }
/*  76:    */       
/*  77:    */       public void apply(AnnotationTableTypeEntry entry)
/*  78:    */       {
/*  79: 72 */         JavaWildcardTypeInstance.Annotated.this.entries.add(entry);
/*  80:    */       }
/*  81:    */     }
/*  82:    */   }
/*  83:    */   
/*  84:    */   public boolean hasL01Wildcard()
/*  85:    */   {
/*  86: 80 */     return true;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public JavaTypeInstance getWithoutL01Wildcard()
/*  90:    */   {
/*  91: 85 */     return this.underlyingType;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public JavaTypeInstance getUnderlyingType()
/*  95:    */   {
/*  96: 89 */     return this.underlyingType;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public boolean tryFindBinding(JavaTypeInstance other, GenericTypeBinder target)
/* 100:    */   {
/* 101: 94 */     if ((this.underlyingType instanceof JavaGenericBaseInstance)) {
/* 102: 95 */       return ((JavaGenericBaseInstance)this.underlyingType).tryFindBinding(other, target);
/* 103:    */     }
/* 104: 97 */     return false;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public StackType getStackType()
/* 108:    */   {
/* 109:102 */     return StackType.REF;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public boolean hasUnbound()
/* 113:    */   {
/* 114:107 */     if ((this.underlyingType instanceof JavaGenericBaseInstance)) {
/* 115:108 */       return ((JavaGenericBaseInstance)this.underlyingType).hasUnbound();
/* 116:    */     }
/* 117:110 */     return false;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public boolean hasForeignUnbound(ConstantPool cp)
/* 121:    */   {
/* 122:115 */     if ((this.underlyingType instanceof JavaGenericBaseInstance)) {
/* 123:116 */       return ((JavaGenericBaseInstance)this.underlyingType).hasForeignUnbound(cp);
/* 124:    */     }
/* 125:118 */     return false;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public boolean isObject()
/* 129:    */   {
/* 130:123 */     return true;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public List<JavaTypeInstance> getGenericTypes()
/* 134:    */   {
/* 135:128 */     if ((this.underlyingType instanceof JavaGenericBaseInstance)) {
/* 136:129 */       return ((JavaGenericBaseInstance)this.underlyingType).getGenericTypes();
/* 137:    */     }
/* 138:131 */     return ListFactory.newList();
/* 139:    */   }
/* 140:    */   
/* 141:    */   public void dumpInto(Dumper d, TypeUsageInformation typeUsageInformation)
/* 142:    */   {
/* 143:136 */     d.print("? ").print(this.wildcardType.toString()).print(' ');
/* 144:137 */     d.dump(this.underlyingType);
/* 145:    */   }
/* 146:    */   
/* 147:    */   public String toString()
/* 148:    */   {
/* 149:142 */     return new ToStringDumper().dump(this).toString();
/* 150:    */   }
/* 151:    */   
/* 152:    */   public String getRawName()
/* 153:    */   {
/* 154:147 */     return toString();
/* 155:    */   }
/* 156:    */   
/* 157:    */   public void collectInto(TypeUsageCollector typeUsageCollector)
/* 158:    */   {
/* 159:152 */     this.underlyingType.collectInto(typeUsageCollector);
/* 160:    */   }
/* 161:    */   
/* 162:    */   public InnerClassInfo getInnerClassHereInfo()
/* 163:    */   {
/* 164:157 */     return this.underlyingType.getInnerClassHereInfo();
/* 165:    */   }
/* 166:    */   
/* 167:    */   public BindingSuperContainer getBindingSupers()
/* 168:    */   {
/* 169:162 */     return this.underlyingType.getBindingSupers();
/* 170:    */   }
/* 171:    */   
/* 172:    */   public JavaTypeInstance getArrayStrippedType()
/* 173:    */   {
/* 174:167 */     return this.underlyingType.getArrayStrippedType();
/* 175:    */   }
/* 176:    */   
/* 177:    */   public int getNumArrayDimensions()
/* 178:    */   {
/* 179:172 */     return this.underlyingType.getNumArrayDimensions();
/* 180:    */   }
/* 181:    */   
/* 182:    */   public int hashCode()
/* 183:    */   {
/* 184:177 */     return this.wildcardType.hashCode() * 31 + this.underlyingType.hashCode();
/* 185:    */   }
/* 186:    */   
/* 187:    */   public boolean equals(Object o)
/* 188:    */   {
/* 189:182 */     if (this == o) {
/* 190:182 */       return true;
/* 191:    */     }
/* 192:183 */     if (!(o instanceof JavaWildcardTypeInstance)) {
/* 193:183 */       return false;
/* 194:    */     }
/* 195:184 */     JavaWildcardTypeInstance other = (JavaWildcardTypeInstance)o;
/* 196:185 */     return (other.wildcardType == this.wildcardType) && (other.underlyingType.equals(this.underlyingType));
/* 197:    */   }
/* 198:    */   
/* 199:    */   public boolean isComplexType()
/* 200:    */   {
/* 201:190 */     return true;
/* 202:    */   }
/* 203:    */   
/* 204:    */   public boolean isUsableType()
/* 205:    */   {
/* 206:195 */     return true;
/* 207:    */   }
/* 208:    */   
/* 209:    */   public JavaTypeInstance removeAnArrayIndirection()
/* 210:    */   {
/* 211:202 */     return this.underlyingType.removeAnArrayIndirection();
/* 212:    */   }
/* 213:    */   
/* 214:    */   public JavaTypeInstance getDeGenerifiedType()
/* 215:    */   {
/* 216:207 */     return this.underlyingType;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public RawJavaType getRawTypeOfSimpleType()
/* 220:    */   {
/* 221:212 */     return this.underlyingType.getRawTypeOfSimpleType();
/* 222:    */   }
/* 223:    */   
/* 224:    */   public boolean implicitlyCastsTo(JavaTypeInstance other, GenericTypeBinder gtb)
/* 225:    */   {
/* 226:217 */     return false;
/* 227:    */   }
/* 228:    */   
/* 229:    */   public boolean impreciseCanCastTo(JavaTypeInstance other, GenericTypeBinder gtb)
/* 230:    */   {
/* 231:222 */     return true;
/* 232:    */   }
/* 233:    */   
/* 234:    */   public boolean correctCanCastTo(JavaTypeInstance other, GenericTypeBinder gtb)
/* 235:    */   {
/* 236:227 */     return impreciseCanCastTo(other, gtb);
/* 237:    */   }
/* 238:    */   
/* 239:    */   public String suggestVarName()
/* 240:    */   {
/* 241:232 */     return null;
/* 242:    */   }
/* 243:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.JavaWildcardTypeInstance
 * JD-Core Version:    0.7.0.1
 */