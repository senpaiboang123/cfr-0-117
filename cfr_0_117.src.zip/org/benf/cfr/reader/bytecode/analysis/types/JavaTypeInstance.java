package org.benf.cfr.reader.bytecode.analysis.types;

import org.benf.cfr.reader.bytecode.analysis.types.annotated.JavaAnnotatedTypeInstance;
import org.benf.cfr.reader.state.TypeUsageCollector;
import org.benf.cfr.reader.state.TypeUsageInformation;
import org.benf.cfr.reader.util.output.Dumper;

public abstract interface JavaTypeInstance
{
  public abstract JavaAnnotatedTypeInstance getAnnotatedInstance();
  
  public abstract StackType getStackType();
  
  public abstract boolean isComplexType();
  
  public abstract boolean isUsableType();
  
  public abstract RawJavaType getRawTypeOfSimpleType();
  
  public abstract JavaTypeInstance removeAnArrayIndirection();
  
  public abstract JavaTypeInstance getArrayStrippedType();
  
  public abstract JavaTypeInstance getDeGenerifiedType();
  
  public abstract int getNumArrayDimensions();
  
  public abstract String getRawName();
  
  public abstract InnerClassInfo getInnerClassHereInfo();
  
  public abstract BindingSuperContainer getBindingSupers();
  
  public abstract boolean implicitlyCastsTo(JavaTypeInstance paramJavaTypeInstance, GenericTypeBinder paramGenericTypeBinder);
  
  public abstract boolean impreciseCanCastTo(JavaTypeInstance paramJavaTypeInstance, GenericTypeBinder paramGenericTypeBinder);
  
  public abstract boolean correctCanCastTo(JavaTypeInstance paramJavaTypeInstance, GenericTypeBinder paramGenericTypeBinder);
  
  public abstract String suggestVarName();
  
  public abstract void dumpInto(Dumper paramDumper, TypeUsageInformation paramTypeUsageInformation);
  
  public abstract void collectInto(TypeUsageCollector paramTypeUsageCollector);
  
  public abstract boolean isObject();
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance
 * JD-Core Version:    0.7.0.1
 */