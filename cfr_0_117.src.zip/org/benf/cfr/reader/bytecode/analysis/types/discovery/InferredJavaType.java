/*    1:     */ package org.benf.cfr.reader.bytecode.analysis.types.discovery;
/*    2:     */ 
/*    3:     */ import java.util.Collection;
/*    4:     */ import java.util.Iterator;
/*    5:     */ import java.util.List;
/*    6:     */ import java.util.Map;
/*    7:     */ import java.util.Map.Entry;
/*    8:     */ import java.util.Set;
/*    9:     */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   10:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithOp;
/*   11:     */ import org.benf.cfr.reader.bytecode.analysis.types.BindingSuperContainer;
/*   12:     */ import org.benf.cfr.reader.bytecode.analysis.types.BindingSuperContainer.Route;
/*   13:     */ import org.benf.cfr.reader.bytecode.analysis.types.GenericTypeBinder;
/*   14:     */ import org.benf.cfr.reader.bytecode.analysis.types.JavaArrayTypeInstance;
/*   15:     */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericBaseInstance;
/*   16:     */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericPlaceholderTypeInstance;
/*   17:     */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericRefTypeInstance;
/*   18:     */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*   19:     */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*   20:     */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*   21:     */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/*   22:     */ import org.benf.cfr.reader.bytecode.analysis.types.TypeConstants;
/*   23:     */ import org.benf.cfr.reader.entities.ClassFile;
/*   24:     */ import org.benf.cfr.reader.util.BoolPair;
/*   25:     */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*   26:     */ import org.benf.cfr.reader.util.ListFactory;
/*   27:     */ import org.benf.cfr.reader.util.MapFactory;
/*   28:     */ import org.benf.cfr.reader.util.MiscUtils;
/*   29:     */ import org.benf.cfr.reader.util.SetFactory;
/*   30:     */ 
/*   31:     */ public class InferredJavaType
/*   32:     */ {
/*   33:     */   public static enum Source
/*   34:     */   {
/*   35:  37 */     TEST,  UNKNOWN,  LITERAL,  FIELD,  FUNCTION,  OPERATION,  EXPRESSION,  INSTRUCTION,  GENERICCALL,  EXCEPTION,  STRING_TRANSFORM,  IMPROVED_ITERATION,  RESOLVE_CLASH;
/*   36:     */     
/*   37:     */     private Source() {}
/*   38:     */   }
/*   39:     */   
/*   40:  53 */   private static int global_id = 0;
/*   41:     */   private IJTInternal value;
/*   42:     */   
/*   43:     */   private static enum ClashState
/*   44:     */   {
/*   45:  56 */     None,  Clash,  Resolved;
/*   46:     */     
/*   47:     */     private ClashState() {}
/*   48:     */   }
/*   49:     */   
/*   50:     */   private static abstract interface IJTInternal
/*   51:     */   {
/*   52:     */     public abstract RawJavaType getRawType();
/*   53:     */     
/*   54:     */     public abstract JavaTypeInstance getJavaTypeInstance();
/*   55:     */     
/*   56:     */     public abstract InferredJavaType.Source getSource();
/*   57:     */     
/*   58:     */     public abstract int getLocalId();
/*   59:     */     
/*   60:     */     public abstract int getFinalId();
/*   61:     */     
/*   62:     */     public abstract InferredJavaType.ClashState getClashState();
/*   63:     */     
/*   64:     */     public abstract void collapseTypeClash();
/*   65:     */     
/*   66:     */     public abstract void mkDelegate(IJTInternal paramIJTInternal);
/*   67:     */     
/*   68:     */     public abstract void forceType(JavaTypeInstance paramJavaTypeInstance, boolean paramBoolean);
/*   69:     */     
/*   70:     */     public abstract void markKnownBaseClass(JavaTypeInstance paramJavaTypeInstance);
/*   71:     */     
/*   72:     */     public abstract JavaTypeInstance getKnownBaseType();
/*   73:     */     
/*   74:     */     public abstract void markClashState(InferredJavaType.ClashState paramClashState);
/*   75:     */     
/*   76:     */     public abstract boolean isLocked();
/*   77:     */     
/*   78:     */     public abstract IJTInternal getFirstLocked();
/*   79:     */     
/*   80:     */     public abstract int getTaggedBytecodeLocation();
/*   81:     */     
/*   82:     */     public abstract void setTaggedBytecodeLocation(int paramInt);
/*   83:     */   }
/*   84:     */   
/*   85:     */   private static class IJTInternal_Clash
/*   86:     */     implements InferredJavaType.IJTInternal
/*   87:     */   {
/*   88:  97 */     private boolean resolved = false;
/*   89:     */     private List<InferredJavaType.IJTInternal> clashes;
/*   90:     */     private final int id;
/*   91: 102 */     private JavaTypeInstance type = null;
/*   92:     */     
/*   93:     */     private IJTInternal_Clash(Collection<InferredJavaType.IJTInternal> clashes)
/*   94:     */     {
/*   95: 106 */       this.id = InferredJavaType.access$008();
/*   96: 107 */       this.clashes = ListFactory.newList(clashes);
/*   97:     */     }
/*   98:     */     
/*   99:     */     private static Map<JavaTypeInstance, JavaGenericRefTypeInstance> getMatches(List<InferredJavaType.IJTInternal> clashes)
/*  100:     */     {
/*  101: 111 */       Map<JavaTypeInstance, JavaGenericRefTypeInstance> matches = MapFactory.newMap();
/*  102:     */       
/*  103: 113 */       InferredJavaType.IJTInternal clash = (InferredJavaType.IJTInternal)clashes.get(0);
/*  104: 114 */       JavaTypeInstance clashType = clash.getJavaTypeInstance();
/*  105: 115 */       BindingSuperContainer otherSupers = clashType.getBindingSupers();
/*  106: 116 */       if (otherSupers != null)
/*  107:     */       {
/*  108: 117 */         Map<JavaRefTypeInstance, JavaGenericRefTypeInstance> boundSupers = otherSupers.getBoundSuperClasses();
/*  109: 118 */         matches.putAll(boundSupers);
/*  110:     */       }
/*  111: 121 */       int x = 1;
/*  112: 121 */       for (int len = clashes.size(); x < len; x++)
/*  113:     */       {
/*  114: 122 */         InferredJavaType.IJTInternal clash = (InferredJavaType.IJTInternal)clashes.get(x);
/*  115: 123 */         JavaTypeInstance clashType = clash.getJavaTypeInstance();
/*  116: 124 */         BindingSuperContainer otherSupers = clashType.getBindingSupers();
/*  117: 125 */         if (otherSupers != null)
/*  118:     */         {
/*  119: 128 */           Map<JavaRefTypeInstance, JavaGenericRefTypeInstance> boundSupers = otherSupers.getBoundSuperClasses();
/*  120: 129 */           Iterator<Map.Entry<JavaTypeInstance, JavaGenericRefTypeInstance>> iterator = matches.entrySet().iterator();
/*  121: 130 */           while (iterator.hasNext())
/*  122:     */           {
/*  123: 131 */             Map.Entry<JavaTypeInstance, JavaGenericRefTypeInstance> entry = (Map.Entry)iterator.next();
/*  124: 132 */             if (!boundSupers.containsKey(entry.getKey())) {
/*  125: 133 */               iterator.remove();
/*  126:     */             }
/*  127:     */           }
/*  128:     */         }
/*  129:     */       }
/*  130: 137 */       return matches;
/*  131:     */     }
/*  132:     */     
/*  133:     */     private static InferredJavaType.IJTInternal mkClash(InferredJavaType.IJTInternal delegate1, InferredJavaType.IJTInternal delegate2)
/*  134:     */     {
/*  135: 141 */       List<InferredJavaType.IJTInternal> clashes = ListFactory.newList();
/*  136: 142 */       if ((delegate1 instanceof IJTInternal_Clash)) {
/*  137: 143 */         for (InferredJavaType.IJTInternal clash : ((IJTInternal_Clash)delegate1).clashes) {
/*  138: 144 */           clashes.add(clash);
/*  139:     */         }
/*  140:     */       } else {
/*  141: 147 */         clashes.add(delegate1);
/*  142:     */       }
/*  143: 149 */       if ((delegate2 instanceof IJTInternal_Clash)) {
/*  144: 150 */         for (InferredJavaType.IJTInternal clash : ((IJTInternal_Clash)delegate2).clashes) {
/*  145: 151 */           clashes.add(clash);
/*  146:     */         }
/*  147:     */       } else {
/*  148: 154 */         clashes.add(delegate2);
/*  149:     */       }
/*  150: 160 */       Map<JavaTypeInstance, JavaGenericRefTypeInstance> matches = getMatches(clashes);
/*  151: 161 */       if (matches.isEmpty()) {
/*  152: 162 */         return new InferredJavaType.IJTInternal_Impl(TypeConstants.OBJECT, InferredJavaType.Source.RESOLVE_CLASH, true, null);
/*  153:     */       }
/*  154: 164 */       if (matches.size() == 1) {
/*  155: 165 */         return new InferredJavaType.IJTInternal_Impl((JavaTypeInstance)matches.keySet().iterator().next(), InferredJavaType.Source.RESOLVE_CLASH, true, null);
/*  156:     */       }
/*  157: 167 */       return new IJTInternal_Clash(clashes);
/*  158:     */     }
/*  159:     */     
/*  160:     */     public void collapseTypeClash()
/*  161:     */     {
/*  162: 172 */       if (this.resolved) {
/*  163: 172 */         return;
/*  164:     */       }
/*  165: 174 */       Map<JavaTypeInstance, JavaGenericRefTypeInstance> matches = getMatches(this.clashes);
/*  166: 175 */       if (matches.isEmpty())
/*  167:     */       {
/*  168: 176 */         this.type = TypeConstants.OBJECT;
/*  169: 177 */         this.resolved = true;
/*  170: 178 */         return;
/*  171:     */       }
/*  172: 186 */       List<JavaTypeInstance> poss = ListFactory.newList(matches.keySet());
/*  173: 187 */       boolean effect = true;
/*  174:     */       do
/*  175:     */       {
/*  176: 189 */         effect = false;
/*  177: 190 */         for (JavaTypeInstance pos : poss)
/*  178:     */         {
/*  179: 191 */           BindingSuperContainer superContainer = pos.getBindingSupers();
/*  180: 192 */           if (superContainer != null)
/*  181:     */           {
/*  182: 193 */             Set<JavaRefTypeInstance> supers = SetFactory.newSet(superContainer.getBoundSuperClasses().keySet());
/*  183:     */             
/*  184: 195 */             supers.remove(pos);
/*  185: 196 */             if (poss.removeAll(supers))
/*  186:     */             {
/*  187: 197 */               effect = true;
/*  188: 198 */               break;
/*  189:     */             }
/*  190:     */           }
/*  191:     */         }
/*  192: 201 */       } while (effect);
/*  193: 205 */       JavaTypeInstance oneClash = ((InferredJavaType.IJTInternal)this.clashes.get(0)).getJavaTypeInstance();
/*  194: 206 */       Map<JavaRefTypeInstance, BindingSuperContainer.Route> routes = oneClash.getBindingSupers().getBoundSuperRoute();
/*  195: 207 */       if (poss.isEmpty()) {
/*  196: 209 */         poss = ListFactory.newList(matches.keySet());
/*  197:     */       }
/*  198: 211 */       for (JavaTypeInstance pos : poss) {
/*  199: 212 */         if (BindingSuperContainer.Route.EXTENSION == routes.get(pos))
/*  200:     */         {
/*  201: 213 */           this.type = pos;
/*  202: 214 */           this.resolved = true;
/*  203: 215 */           return;
/*  204:     */         }
/*  205:     */       }
/*  206: 218 */       this.type = ((JavaTypeInstance)poss.get(0));
/*  207: 219 */       this.resolved = true;
/*  208:     */     }
/*  209:     */     
/*  210:     */     public RawJavaType getRawType()
/*  211:     */     {
/*  212: 224 */       if (this.resolved) {
/*  213: 225 */         return this.type.getRawTypeOfSimpleType();
/*  214:     */       }
/*  215: 227 */       return ((InferredJavaType.IJTInternal)this.clashes.get(0)).getRawType();
/*  216:     */     }
/*  217:     */     
/*  218:     */     public int getTaggedBytecodeLocation()
/*  219:     */     {
/*  220: 233 */       return -1;
/*  221:     */     }
/*  222:     */     
/*  223:     */     public void setTaggedBytecodeLocation(int location) {}
/*  224:     */     
/*  225:     */     public JavaTypeInstance getJavaTypeInstance()
/*  226:     */     {
/*  227: 243 */       if (this.resolved) {
/*  228: 244 */         return this.type;
/*  229:     */       }
/*  230: 246 */       return ((InferredJavaType.IJTInternal)this.clashes.get(0)).getJavaTypeInstance();
/*  231:     */     }
/*  232:     */     
/*  233:     */     public InferredJavaType.Source getSource()
/*  234:     */     {
/*  235: 252 */       return ((InferredJavaType.IJTInternal)this.clashes.get(0)).getSource();
/*  236:     */     }
/*  237:     */     
/*  238:     */     public int getFinalId()
/*  239:     */     {
/*  240: 257 */       return this.id;
/*  241:     */     }
/*  242:     */     
/*  243:     */     public int getLocalId()
/*  244:     */     {
/*  245: 262 */       return this.id;
/*  246:     */     }
/*  247:     */     
/*  248:     */     public InferredJavaType.ClashState getClashState()
/*  249:     */     {
/*  250: 267 */       if (this.resolved) {
/*  251: 268 */         return InferredJavaType.ClashState.Resolved;
/*  252:     */       }
/*  253: 270 */       return InferredJavaType.ClashState.Clash;
/*  254:     */     }
/*  255:     */     
/*  256:     */     public void mkDelegate(InferredJavaType.IJTInternal newDelegate) {}
/*  257:     */     
/*  258:     */     public void forceType(JavaTypeInstance rawJavaType, boolean ignoreLock)
/*  259:     */     {
/*  260: 284 */       this.type = rawJavaType;
/*  261: 285 */       this.resolved = true;
/*  262:     */     }
/*  263:     */     
/*  264:     */     public void markKnownBaseClass(JavaTypeInstance knownBase) {}
/*  265:     */     
/*  266:     */     public JavaTypeInstance getKnownBaseType()
/*  267:     */     {
/*  268: 294 */       return null;
/*  269:     */     }
/*  270:     */     
/*  271:     */     public void markClashState(InferredJavaType.ClashState newClashState) {}
/*  272:     */     
/*  273:     */     public boolean isLocked()
/*  274:     */     {
/*  275: 303 */       return this.resolved;
/*  276:     */     }
/*  277:     */     
/*  278:     */     public InferredJavaType.IJTInternal getFirstLocked()
/*  279:     */     {
/*  280: 308 */       return null;
/*  281:     */     }
/*  282:     */     
/*  283:     */     public String toString()
/*  284:     */     {
/*  285: 312 */       if (this.resolved) {
/*  286: 313 */         return "#" + this.id + " " + this.type.toString();
/*  287:     */       }
/*  288: 315 */       StringBuilder sb = new StringBuilder();
/*  289: 316 */       for (InferredJavaType.IJTInternal clash : this.clashes) {
/*  290: 317 */         sb.append(this.id).append(" -> ").append(clash.toString()).append(", ");
/*  291:     */       }
/*  292: 319 */       return sb.toString();
/*  293:     */     }
/*  294:     */   }
/*  295:     */   
/*  296:     */   private static class IJTInternal_Impl
/*  297:     */     implements InferredJavaType.IJTInternal
/*  298:     */   {
/*  299: 327 */     private boolean isDelegate = false;
/*  300:     */     private final boolean locked;
/*  301:     */     private JavaTypeInstance type;
/*  302:     */     private JavaTypeInstance knownBase;
/*  303: 335 */     private int taggedBytecodeLocation = -1;
/*  304:     */     private final InferredJavaType.Source source;
/*  305:     */     private final int id;
/*  306:     */     private InferredJavaType.IJTInternal delegate;
/*  307:     */     
/*  308:     */     private IJTInternal_Impl(JavaTypeInstance type, InferredJavaType.Source source, boolean locked)
/*  309:     */     {
/*  310: 345 */       this.type = type;
/*  311: 346 */       this.source = source;
/*  312: 347 */       this.id = InferredJavaType.access$008();
/*  313: 348 */       this.locked = locked;
/*  314:     */     }
/*  315:     */     
/*  316:     */     public RawJavaType getRawType()
/*  317:     */     {
/*  318: 354 */       if (this.isDelegate) {
/*  319: 355 */         return this.delegate.getRawType();
/*  320:     */       }
/*  321: 357 */       return this.type.getRawTypeOfSimpleType();
/*  322:     */     }
/*  323:     */     
/*  324:     */     public int getTaggedBytecodeLocation()
/*  325:     */     {
/*  326: 363 */       if (this.isDelegate) {
/*  327: 364 */         return this.delegate.getTaggedBytecodeLocation();
/*  328:     */       }
/*  329: 366 */       return this.taggedBytecodeLocation;
/*  330:     */     }
/*  331:     */     
/*  332:     */     public void setTaggedBytecodeLocation(int location)
/*  333:     */     {
/*  334: 372 */       if (this.isDelegate) {
/*  335: 373 */         this.delegate.setTaggedBytecodeLocation(location);
/*  336:     */       } else {
/*  337: 375 */         this.taggedBytecodeLocation = location;
/*  338:     */       }
/*  339:     */     }
/*  340:     */     
/*  341:     */     public JavaTypeInstance getJavaTypeInstance()
/*  342:     */     {
/*  343: 380 */       if (this.isDelegate) {
/*  344: 381 */         return this.delegate.getJavaTypeInstance();
/*  345:     */       }
/*  346: 383 */       return this.type;
/*  347:     */     }
/*  348:     */     
/*  349:     */     public InferredJavaType.Source getSource()
/*  350:     */     {
/*  351: 388 */       if (this.isDelegate) {
/*  352: 389 */         return this.delegate.getSource();
/*  353:     */       }
/*  354: 391 */       return this.source;
/*  355:     */     }
/*  356:     */     
/*  357:     */     public void collapseTypeClash()
/*  358:     */     {
/*  359: 397 */       if (this.isDelegate) {
/*  360: 398 */         this.delegate.collapseTypeClash();
/*  361:     */       }
/*  362:     */     }
/*  363:     */     
/*  364:     */     public int getFinalId()
/*  365:     */     {
/*  366: 403 */       if (this.isDelegate) {
/*  367: 404 */         return this.delegate.getFinalId();
/*  368:     */       }
/*  369: 406 */       return this.id;
/*  370:     */     }
/*  371:     */     
/*  372:     */     public int getLocalId()
/*  373:     */     {
/*  374: 411 */       return this.id;
/*  375:     */     }
/*  376:     */     
/*  377:     */     public InferredJavaType.ClashState getClashState()
/*  378:     */     {
/*  379: 415 */       return InferredJavaType.ClashState.None;
/*  380:     */     }
/*  381:     */     
/*  382:     */     public void mkDelegate(InferredJavaType.IJTInternal newDelegate)
/*  383:     */     {
/*  384: 422 */       if (this.isDelegate)
/*  385:     */       {
/*  386: 423 */         this.delegate.mkDelegate(newDelegate);
/*  387:     */       }
/*  388:     */       else
/*  389:     */       {
/*  390: 426 */         this.isDelegate = true;
/*  391: 427 */         this.delegate = newDelegate;
/*  392:     */       }
/*  393:     */     }
/*  394:     */     
/*  395:     */     public void markKnownBaseClass(JavaTypeInstance newKnownBase)
/*  396:     */     {
/*  397: 433 */       if (this.isDelegate)
/*  398:     */       {
/*  399: 434 */         this.delegate.markKnownBaseClass(newKnownBase);
/*  400: 435 */         return;
/*  401:     */       }
/*  402: 437 */       if (this.knownBase == null)
/*  403:     */       {
/*  404: 438 */         this.knownBase = newKnownBase;
/*  405:     */       }
/*  406:     */       else
/*  407:     */       {
/*  408: 440 */         BindingSuperContainer boundSupers = this.knownBase.getBindingSupers();
/*  409: 441 */         if ((boundSupers == null) || (!boundSupers.containsBase(newKnownBase.getDeGenerifiedType()))) {
/*  410: 442 */           this.knownBase = newKnownBase;
/*  411:     */         }
/*  412:     */       }
/*  413:     */     }
/*  414:     */     
/*  415:     */     public JavaTypeInstance getKnownBaseType()
/*  416:     */     {
/*  417: 449 */       if (this.isDelegate) {
/*  418: 449 */         return this.delegate.getKnownBaseType();
/*  419:     */       }
/*  420: 450 */       return this.knownBase;
/*  421:     */     }
/*  422:     */     
/*  423:     */     public void forceType(JavaTypeInstance rawJavaType, boolean ignoreLock)
/*  424:     */     {
/*  425: 454 */       if ((!ignoreLock) && (isLocked())) {
/*  426: 454 */         return;
/*  427:     */       }
/*  428: 455 */       if ((this.isDelegate) && (this.delegate.isLocked()) && (!ignoreLock)) {
/*  429: 456 */         this.isDelegate = false;
/*  430:     */       }
/*  431: 458 */       if (this.isDelegate) {
/*  432: 459 */         this.delegate.forceType(rawJavaType, ignoreLock);
/*  433:     */       } else {
/*  434: 461 */         this.type = rawJavaType;
/*  435:     */       }
/*  436:     */     }
/*  437:     */     
/*  438:     */     public void markClashState(InferredJavaType.ClashState newClashState)
/*  439:     */     {
/*  440: 466 */       throw new UnsupportedOperationException();
/*  441:     */     }
/*  442:     */     
/*  443:     */     public String toString()
/*  444:     */     {
/*  445: 477 */       if (this.isDelegate) {
/*  446: 478 */         return "#" + this.id + " -> " + this.delegate.toString();
/*  447:     */       }
/*  448: 480 */       return "#" + this.id + " " + this.type.toString();
/*  449:     */     }
/*  450:     */     
/*  451:     */     public boolean isLocked()
/*  452:     */     {
/*  453: 485 */       return this.locked;
/*  454:     */     }
/*  455:     */     
/*  456:     */     public InferredJavaType.IJTInternal getFirstLocked()
/*  457:     */     {
/*  458: 489 */       if (this.locked) {
/*  459: 489 */         return this;
/*  460:     */       }
/*  461: 490 */       if (this.delegate != null) {
/*  462: 490 */         return this.delegate.getFirstLocked();
/*  463:     */       }
/*  464: 491 */       return null;
/*  465:     */     }
/*  466:     */   }
/*  467:     */   
/*  468: 497 */   public static final InferredJavaType IGNORE = new InferredJavaType();
/*  469:     */   
/*  470:     */   public InferredJavaType()
/*  471:     */   {
/*  472: 500 */     this.value = new IJTInternal_Impl(RawJavaType.VOID, Source.UNKNOWN, false, null);
/*  473:     */   }
/*  474:     */   
/*  475:     */   public InferredJavaType(JavaTypeInstance type, Source source)
/*  476:     */   {
/*  477: 504 */     this.value = new IJTInternal_Impl(type, source, false, null);
/*  478:     */   }
/*  479:     */   
/*  480:     */   public InferredJavaType(JavaTypeInstance type, Source source, boolean locked)
/*  481:     */   {
/*  482: 508 */     this.value = new IJTInternal_Impl(type, source, locked, null);
/*  483:     */   }
/*  484:     */   
/*  485:     */   private InferredJavaType(IJTInternal_Clash clash)
/*  486:     */   {
/*  487: 512 */     this.value = clash;
/*  488:     */   }
/*  489:     */   
/*  490:     */   public static InferredJavaType mkClash(JavaTypeInstance... types)
/*  491:     */   {
/*  492: 516 */     List<IJTInternal> ints = ListFactory.newList();
/*  493: 517 */     for (JavaTypeInstance type : types) {
/*  494: 518 */       ints.add(new IJTInternal_Impl(type, Source.UNKNOWN, false, null));
/*  495:     */     }
/*  496: 520 */     return new InferredJavaType(new IJTInternal_Clash(ints, null));
/*  497:     */   }
/*  498:     */   
/*  499:     */   public Source getSource()
/*  500:     */   {
/*  501: 524 */     return this.value.getSource();
/*  502:     */   }
/*  503:     */   
/*  504:     */   private void mergeGenericInfo(JavaGenericRefTypeInstance otherTypeInstance)
/*  505:     */   {
/*  506: 528 */     if (this.value.isLocked()) {
/*  507: 528 */       return;
/*  508:     */     }
/*  509: 529 */     JavaGenericRefTypeInstance thisType = (JavaGenericRefTypeInstance)this.value.getJavaTypeInstance();
/*  510: 530 */     if (!thisType.hasUnbound()) {
/*  511: 530 */       return;
/*  512:     */     }
/*  513: 531 */     ClassFile degenerifiedThisClassFile = thisType.getDeGenerifiedType().getClassFile();
/*  514: 532 */     if (degenerifiedThisClassFile == null) {
/*  515: 533 */       return;
/*  516:     */     }
/*  517: 535 */     JavaTypeInstance boundThisType = degenerifiedThisClassFile.getBindingSupers().getBoundAssignable(thisType, otherTypeInstance);
/*  518: 536 */     if (!boundThisType.equals(thisType)) {
/*  519: 537 */       mkDelegate(this.value, new IJTInternal_Impl(boundThisType, Source.GENERICCALL, true, null));
/*  520:     */     }
/*  521:     */   }
/*  522:     */   
/*  523:     */   public void noteUseAs(JavaTypeInstance type)
/*  524:     */   {
/*  525: 542 */     if (this.value.getClashState() == ClashState.Clash)
/*  526:     */     {
/*  527: 543 */       BindingSuperContainer bindingSuperContainer = getJavaTypeInstance().getBindingSupers();
/*  528: 544 */       if (bindingSuperContainer.containsBase(type.getDeGenerifiedType()))
/*  529:     */       {
/*  530: 545 */         this.value.forceType(type, false);
/*  531: 546 */         this.value.markClashState(ClashState.Resolved);
/*  532:     */       }
/*  533:     */     }
/*  534:     */   }
/*  535:     */   
/*  536:     */   public void forceType(JavaTypeInstance type, boolean ignoreLockIfResolveClash)
/*  537:     */   {
/*  538: 552 */     boolean ignoreLock = (this.value.isLocked()) && (this.value.getSource() == Source.RESOLVE_CLASH);
/*  539: 553 */     this.value.forceType(type, ignoreLock);
/*  540:     */   }
/*  541:     */   
/*  542:     */   public boolean isClash()
/*  543:     */   {
/*  544: 557 */     return this.value.getClashState() == ClashState.Clash;
/*  545:     */   }
/*  546:     */   
/*  547:     */   public void collapseTypeClash()
/*  548:     */   {
/*  549: 561 */     this.value.collapseTypeClash();
/*  550:     */   }
/*  551:     */   
/*  552:     */   public int getLocalId()
/*  553:     */   {
/*  554: 565 */     return this.value.getLocalId();
/*  555:     */   }
/*  556:     */   
/*  557:     */   public int getTaggedBytecodeLocation()
/*  558:     */   {
/*  559: 569 */     return this.value.getTaggedBytecodeLocation();
/*  560:     */   }
/*  561:     */   
/*  562:     */   public void setTaggedBytecodeLocation(int location)
/*  563:     */   {
/*  564: 573 */     this.value.setTaggedBytecodeLocation(location);
/*  565:     */   }
/*  566:     */   
/*  567:     */   private boolean checkGenericCompatibility(JavaGenericRefTypeInstance thisType, JavaGenericRefTypeInstance otherType)
/*  568:     */   {
/*  569: 580 */     List<JavaTypeInstance> thisTypes = thisType.getGenericTypes();
/*  570: 581 */     List<JavaTypeInstance> otherTypes = otherType.getGenericTypes();
/*  571: 582 */     if (thisTypes.size() != otherTypes.size()) {
/*  572: 582 */       return true;
/*  573:     */     }
/*  574: 583 */     int x = 0;
/*  575: 583 */     for (int len = thisTypes.size(); x < len; x++)
/*  576:     */     {
/*  577: 584 */       JavaTypeInstance this1 = (JavaTypeInstance)thisTypes.get(x);
/*  578: 585 */       JavaTypeInstance other1 = (JavaTypeInstance)otherTypes.get(x);
/*  579: 586 */       if (!checkBaseCompatibility(this1, other1)) {
/*  580: 587 */         return false;
/*  581:     */       }
/*  582:     */     }
/*  583: 590 */     return true;
/*  584:     */   }
/*  585:     */   
/*  586:     */   private boolean checkBaseCompatibility(JavaTypeInstance otherType)
/*  587:     */   {
/*  588: 594 */     return checkBaseCompatibility(getJavaTypeInstance(), otherType);
/*  589:     */   }
/*  590:     */   
/*  591:     */   private boolean checkBaseCompatibility(JavaTypeInstance thisType, JavaTypeInstance otherType)
/*  592:     */   {
/*  593: 599 */     if (((thisType instanceof JavaGenericPlaceholderTypeInstance)) || ((otherType instanceof JavaGenericPlaceholderTypeInstance))) {
/*  594: 600 */       return thisType.equals(otherType);
/*  595:     */     }
/*  596: 603 */     JavaTypeInstance thisStripped = thisType.getDeGenerifiedType();
/*  597: 604 */     JavaTypeInstance otherStripped = otherType.getDeGenerifiedType();
/*  598: 605 */     if (thisStripped.equals(otherStripped))
/*  599:     */     {
/*  600: 606 */       boolean genericThis = thisType instanceof JavaGenericRefTypeInstance;
/*  601: 607 */       boolean genericThat = otherType instanceof JavaGenericRefTypeInstance;
/*  602: 608 */       if ((genericThis) && (genericThat)) {
/*  603: 609 */         return checkGenericCompatibility((JavaGenericRefTypeInstance)thisType, (JavaGenericRefTypeInstance)otherType);
/*  604:     */       }
/*  605: 614 */       return true;
/*  606:     */     }
/*  607: 618 */     BindingSuperContainer otherSupers = otherType.getBindingSupers();
/*  608: 619 */     if (otherSupers == null) {
/*  609: 621 */       return true;
/*  610:     */     }
/*  611: 623 */     return otherSupers.containsBase(thisStripped);
/*  612:     */   }
/*  613:     */   
/*  614:     */   private CastAction chainFrom(InferredJavaType other)
/*  615:     */   {
/*  616: 628 */     if (this == other) {
/*  617: 628 */       return CastAction.None;
/*  618:     */     }
/*  619: 630 */     JavaTypeInstance thisTypeInstance = this.value.getJavaTypeInstance();
/*  620: 631 */     JavaTypeInstance otherTypeInstance = other.value.getJavaTypeInstance();
/*  621: 633 */     if (thisTypeInstance != RawJavaType.VOID)
/*  622:     */     {
/*  623: 637 */       boolean basecast = false;
/*  624: 638 */       if ((thisTypeInstance.isComplexType()) && (otherTypeInstance.isComplexType()))
/*  625:     */       {
/*  626: 639 */         if (!checkBaseCompatibility(other.getJavaTypeInstance()))
/*  627:     */         {
/*  628: 641 */           this.value = IJTInternal_Clash.mkClash(this.value, other.value);
/*  629:     */           
/*  630: 643 */           return CastAction.None;
/*  631:     */         }
/*  632: 644 */         if (this.value.getClashState() == ClashState.Resolved) {
/*  633: 645 */           return CastAction.None;
/*  634:     */         }
/*  635: 646 */         if (thisTypeInstance.getClass() == otherTypeInstance.getClass()) {
/*  636: 647 */           basecast = true;
/*  637:     */         }
/*  638:     */       }
/*  639: 654 */       if (((otherTypeInstance instanceof JavaGenericRefTypeInstance)) && 
/*  640: 655 */         ((thisTypeInstance instanceof JavaGenericRefTypeInstance))) {
/*  641: 656 */         other.mergeGenericInfo((JavaGenericRefTypeInstance)thisTypeInstance);
/*  642:     */       }
/*  643: 660 */       if (basecast) {
/*  644: 661 */         return CastAction.None;
/*  645:     */       }
/*  646: 664 */       if ((otherTypeInstance instanceof JavaGenericPlaceholderTypeInstance ^ thisTypeInstance instanceof JavaGenericPlaceholderTypeInstance)) {
/*  647: 665 */         return CastAction.InsertExplicit;
/*  648:     */       }
/*  649:     */     }
/*  650: 669 */     mkDelegate(this.value, other.value);
/*  651: 670 */     if (!other.value.isLocked()) {
/*  652: 671 */       this.value = other.value;
/*  653:     */     }
/*  654: 673 */     return CastAction.None;
/*  655:     */   }
/*  656:     */   
/*  657:     */   private static void mkDelegate(IJTInternal a, IJTInternal b)
/*  658:     */   {
/*  659: 677 */     if (a.getFinalId() != b.getFinalId()) {
/*  660: 678 */       a.mkDelegate(b);
/*  661:     */     }
/*  662:     */   }
/*  663:     */   
/*  664:     */   public void forceDelegate(InferredJavaType other)
/*  665:     */   {
/*  666: 683 */     mkDelegate(this.value, other.value);
/*  667:     */   }
/*  668:     */   
/*  669:     */   private CastAction chainIntegralTypes(InferredJavaType other)
/*  670:     */   {
/*  671: 694 */     if (this == other) {
/*  672: 694 */       return CastAction.None;
/*  673:     */     }
/*  674: 695 */     int pri = getRawType().compareTypePriorityTo(other.getRawType());
/*  675: 696 */     if (pri >= 0)
/*  676:     */     {
/*  677: 697 */       if (other.value.isLocked())
/*  678:     */       {
/*  679: 698 */         if (pri > 0) {
/*  680: 699 */           return CastAction.InsertExplicit;
/*  681:     */         }
/*  682: 701 */         return CastAction.None;
/*  683:     */       }
/*  684: 704 */       if (pri > 0)
/*  685:     */       {
/*  686: 706 */         IJTInternal otherLocked = other.value.getFirstLocked();
/*  687: 707 */         if ((otherLocked != null) && (otherLocked.getJavaTypeInstance() == other.getJavaTypeInstance())) {
/*  688: 708 */           return CastAction.InsertExplicit;
/*  689:     */         }
/*  690:     */       }
/*  691: 712 */       mkDelegate(other.value, this.value);
/*  692:     */     }
/*  693:     */     else
/*  694:     */     {
/*  695: 714 */       if (this.value.isLocked()) {
/*  696: 715 */         return CastAction.InsertExplicit;
/*  697:     */       }
/*  698: 717 */       mkDelegate(this.value, other.value);
/*  699: 718 */       this.value = other.value;
/*  700:     */     }
/*  701: 720 */     return CastAction.None;
/*  702:     */   }
/*  703:     */   
/*  704:     */   public static void compareAsWithoutCasting(InferredJavaType a, InferredJavaType b, boolean aLit, boolean bLit)
/*  705:     */   {
/*  706: 727 */     if (a == IGNORE) {
/*  707: 727 */       return;
/*  708:     */     }
/*  709: 728 */     if (b == IGNORE) {
/*  710: 728 */       return;
/*  711:     */     }
/*  712: 730 */     RawJavaType art = a.getRawType();
/*  713: 731 */     RawJavaType brt = b.getRawType();
/*  714: 732 */     if ((art.getStackType() != StackType.INT) || (brt.getStackType() != StackType.INT)) {
/*  715: 733 */       return;
/*  716:     */     }
/*  717: 735 */     InferredJavaType litType = null;
/*  718: 736 */     InferredJavaType betterType = null;
/*  719: 737 */     Expression litExp = null;
/*  720: 738 */     BoolPair whichLit = BoolPair.get(a.getSource() == Source.LITERAL, b.getSource() == Source.LITERAL);
/*  721: 741 */     if (whichLit.getCount() != 1) {
/*  722: 741 */       whichLit = BoolPair.get(aLit, bLit);
/*  723:     */     }
/*  724: 742 */     if ((art == RawJavaType.BOOLEAN) && (brt.getStackType() == StackType.INT) && (brt.compareTypePriorityTo(art) > 0))
/*  725:     */     {
/*  726: 745 */       litType = a;
/*  727: 746 */       betterType = b;
/*  728:     */     }
/*  729: 747 */     else if ((brt == RawJavaType.BOOLEAN) && (art.getStackType() == StackType.INT) && (art.compareTypePriorityTo(brt) > 0))
/*  730:     */     {
/*  731: 750 */       litType = b;
/*  732: 751 */       betterType = a;
/*  733:     */     }
/*  734:     */     else
/*  735:     */     {
/*  736: 753 */       switch (1.$SwitchMap$org$benf$cfr$reader$util$BoolPair[whichLit.ordinal()])
/*  737:     */       {
/*  738:     */       case 1: 
/*  739: 755 */         litType = a;
/*  740: 756 */         betterType = b;
/*  741: 757 */         break;
/*  742:     */       case 2: 
/*  743: 759 */         litType = b;
/*  744: 760 */         betterType = a;
/*  745: 761 */         break;
/*  746:     */       case 3: 
/*  747:     */       case 4: 
/*  748: 764 */         return;
/*  749:     */       }
/*  750:     */     }
/*  751: 771 */     litType.chainFrom(betterType);
/*  752:     */   }
/*  753:     */   
/*  754:     */   public void useAsWithCast(RawJavaType otherRaw)
/*  755:     */   {
/*  756: 779 */     if (this == IGNORE) {
/*  757: 779 */       return;
/*  758:     */     }
/*  759: 781 */     this.value = new IJTInternal_Impl(otherRaw, Source.OPERATION, true, null);
/*  760:     */   }
/*  761:     */   
/*  762:     */   public void useInArithOp(InferredJavaType other, RawJavaType otherRaw, boolean forbidBool)
/*  763:     */   {
/*  764: 785 */     if (this == IGNORE) {
/*  765: 785 */       return;
/*  766:     */     }
/*  767: 786 */     if (other == IGNORE) {
/*  768: 786 */       return;
/*  769:     */     }
/*  770: 787 */     RawJavaType thisRaw = getRawType();
/*  771: 788 */     if (thisRaw.getStackType() != otherRaw.getStackType()) {
/*  772: 792 */       return;
/*  773:     */     }
/*  774: 794 */     if (thisRaw.getStackType() == StackType.INT)
/*  775:     */     {
/*  776: 797 */       int cmp = thisRaw.compareTypePriorityTo(otherRaw);
/*  777: 798 */       if (cmp < 0)
/*  778:     */       {
/*  779: 799 */         if ((thisRaw == RawJavaType.BOOLEAN) && (forbidBool)) {
/*  780: 800 */           this.value.forceType(otherRaw, false);
/*  781:     */         }
/*  782:     */       }
/*  783: 803 */       else if ((cmp == 0) && 
/*  784: 804 */         (thisRaw == RawJavaType.BOOLEAN) && (forbidBool)) {
/*  785: 805 */         this.value.forceType(RawJavaType.INT, false);
/*  786:     */       }
/*  787:     */     }
/*  788:     */   }
/*  789:     */   
/*  790:     */   public static void useInArithOp(InferredJavaType lhs, InferredJavaType rhs, ArithOp op)
/*  791:     */   {
/*  792: 812 */     boolean forbidBool = true;
/*  793: 813 */     if (((op == ArithOp.OR) || (op == ArithOp.AND) || (op == ArithOp.XOR)) && 
/*  794: 814 */       (lhs.getJavaTypeInstance() == RawJavaType.BOOLEAN) && (rhs.getJavaTypeInstance() == RawJavaType.BOOLEAN)) {
/*  795: 816 */       forbidBool = false;
/*  796:     */     }
/*  797: 819 */     lhs.useInArithOp(rhs, rhs.getRawType(), forbidBool);
/*  798: 820 */     RawJavaType lhsRawType = lhs.getRawType();
/*  799: 821 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$expression$ArithOp[op.ordinal()])
/*  800:     */     {
/*  801:     */     case 1: 
/*  802:     */     case 2: 
/*  803:     */     case 3: 
/*  804: 825 */       lhsRawType = RawJavaType.INT;
/*  805:     */     }
/*  806: 828 */     rhs.useInArithOp(lhs, lhsRawType, forbidBool);
/*  807:     */   }
/*  808:     */   
/*  809:     */   public void useAsWithoutCasting(JavaTypeInstance otherTypeInstance)
/*  810:     */   {
/*  811: 840 */     if (this == IGNORE) {
/*  812: 840 */       return;
/*  813:     */     }
/*  814: 843 */     if (otherTypeInstance == TypeConstants.OBJECT) {
/*  815: 843 */       return;
/*  816:     */     }
/*  817: 845 */     JavaTypeInstance thisTypeInstance = getJavaTypeInstance();
/*  818: 846 */     if (thisTypeInstance == RawJavaType.NULL) {
/*  819: 847 */       this.value.markKnownBaseClass(otherTypeInstance);
/*  820:     */     }
/*  821: 854 */     if (((thisTypeInstance instanceof RawJavaType)) && ((otherTypeInstance instanceof RawJavaType)))
/*  822:     */     {
/*  823: 856 */       RawJavaType otherRaw = otherTypeInstance.getRawTypeOfSimpleType();
/*  824: 857 */       RawJavaType thisRaw = getRawType();
/*  825: 858 */       if (thisRaw.getStackType() != otherRaw.getStackType()) {
/*  826: 858 */         return;
/*  827:     */       }
/*  828: 859 */       if (thisRaw.getStackType() == StackType.INT)
/*  829:     */       {
/*  830: 861 */         int cmp = thisRaw.compareTypePriorityTo(otherRaw);
/*  831: 862 */         if (cmp > 0) {
/*  832: 863 */           this.value.forceType(otherRaw, false);
/*  833: 864 */         } else if (cmp < 0) {
/*  834: 868 */           if (thisRaw == RawJavaType.BOOLEAN) {
/*  835: 869 */             this.value.forceType(otherRaw, false);
/*  836:     */           }
/*  837:     */         }
/*  838:     */       }
/*  839:     */     }
/*  840: 873 */     else if (((thisTypeInstance instanceof JavaArrayTypeInstance)) && ((otherTypeInstance instanceof JavaArrayTypeInstance)))
/*  841:     */     {
/*  842: 875 */       JavaArrayTypeInstance thisArrayTypeInstance = (JavaArrayTypeInstance)thisTypeInstance;
/*  843: 876 */       JavaArrayTypeInstance otherArrayTypeInstance = (JavaArrayTypeInstance)otherTypeInstance;
/*  844: 877 */       if (thisArrayTypeInstance.getNumArrayDimensions() != otherArrayTypeInstance.getNumArrayDimensions()) {
/*  845: 877 */         return;
/*  846:     */       }
/*  847: 879 */       JavaTypeInstance thisStripped = thisArrayTypeInstance.getArrayStrippedType().getDeGenerifiedType();
/*  848: 880 */       JavaTypeInstance otherArrayStripped = otherArrayTypeInstance.getArrayStrippedType();
/*  849:     */       
/*  850:     */ 
/*  851: 883 */       JavaTypeInstance otherStripped = otherArrayStripped.getDeGenerifiedType();
/*  852: 884 */       if ((otherArrayStripped instanceof JavaGenericBaseInstance)) {
/*  853: 884 */         return;
/*  854:     */       }
/*  855: 886 */       if (((thisStripped instanceof JavaRefTypeInstance)) && ((otherStripped instanceof JavaRefTypeInstance)))
/*  856:     */       {
/*  857: 888 */         JavaRefTypeInstance thisRef = (JavaRefTypeInstance)thisStripped;
/*  858: 889 */         JavaRefTypeInstance otherRef = (JavaRefTypeInstance)otherStripped;
/*  859: 890 */         BindingSuperContainer bindingSuperContainer = thisRef.getBindingSupers();
/*  860: 891 */         if (bindingSuperContainer == null)
/*  861:     */         {
/*  862: 892 */           if (otherRef == TypeConstants.OBJECT) {
/*  863: 893 */             this.value.forceType(otherTypeInstance, false);
/*  864:     */           }
/*  865:     */         }
/*  866: 896 */         else if (bindingSuperContainer.containsBase(otherRef)) {
/*  867: 897 */           this.value.forceType(otherTypeInstance, false);
/*  868:     */         }
/*  869:     */       }
/*  870:     */     }
/*  871: 901 */     else if (((thisTypeInstance instanceof JavaGenericRefTypeInstance)) && ((otherTypeInstance instanceof JavaGenericRefTypeInstance)))
/*  872:     */     {
/*  873: 903 */       improveGenericType((JavaGenericRefTypeInstance)otherTypeInstance);
/*  874:     */     }
/*  875:     */   }
/*  876:     */   
/*  877:     */   private void improveGenericType(JavaGenericRefTypeInstance otherGeneric)
/*  878:     */   {
/*  879: 908 */     JavaTypeInstance thisTypeInstance = getJavaTypeInstance();
/*  880: 909 */     if (!(thisTypeInstance instanceof JavaGenericRefTypeInstance)) {
/*  881: 909 */       throw new IllegalStateException();
/*  882:     */     }
/*  883: 910 */     JavaGenericRefTypeInstance thisGeneric = (JavaGenericRefTypeInstance)thisTypeInstance;
/*  884: 911 */     JavaRefTypeInstance other = otherGeneric.getDeGenerifiedType();
/*  885:     */     
/*  886:     */ 
/*  887:     */ 
/*  888:     */ 
/*  889:     */ 
/*  890:     */ 
/*  891:     */ 
/*  892: 919 */     BindingSuperContainer thisBindingContainer = thisTypeInstance.getBindingSupers();
/*  893: 920 */     if (thisBindingContainer == null) {
/*  894: 920 */       return;
/*  895:     */     }
/*  896: 921 */     JavaGenericRefTypeInstance otherUnbound = thisBindingContainer.getBoundSuperForBase(other);
/*  897: 922 */     if (otherUnbound == null) {
/*  898: 922 */       return;
/*  899:     */     }
/*  900: 923 */     GenericTypeBinder otherBindings = GenericTypeBinder.extractBindings(otherUnbound, otherGeneric);
/*  901: 924 */     JavaGenericRefTypeInstance thisUnbound = thisBindingContainer.getBoundSuperForBase(thisGeneric.getDeGenerifiedType());
/*  902: 925 */     GenericTypeBinder thisBindings = GenericTypeBinder.extractBindings(thisUnbound, thisGeneric);
/*  903:     */     
/*  904: 927 */     GenericTypeBinder improvementBindings = otherBindings.createAssignmentRhsBindings(thisBindings);
/*  905: 928 */     if (improvementBindings == null) {
/*  906: 928 */       return;
/*  907:     */     }
/*  908: 931 */     if (thisUnbound == null) {
/*  909: 931 */       return;
/*  910:     */     }
/*  911: 932 */     JavaTypeInstance thisRebound = improvementBindings.getBindingFor(thisUnbound);
/*  912: 933 */     if ((thisRebound == null) || (thisRebound.equals(thisGeneric))) {
/*  913: 933 */       return;
/*  914:     */     }
/*  915: 934 */     if (!(thisRebound instanceof JavaGenericRefTypeInstance)) {
/*  916: 934 */       return;
/*  917:     */     }
/*  918: 936 */     this.value.forceType(thisRebound, true);
/*  919:     */   }
/*  920:     */   
/*  921:     */   public void deGenerify(JavaTypeInstance other)
/*  922:     */   {
/*  923: 940 */     JavaTypeInstance typeInstanceThis = getJavaTypeInstance().getDeGenerifiedType();
/*  924: 941 */     JavaTypeInstance typeInstanceOther = other.getDeGenerifiedType();
/*  925: 942 */     if ((!typeInstanceOther.equals(typeInstanceThis)) && 
/*  926: 943 */       (TypeConstants.OBJECT != typeInstanceThis)) {
/*  927: 944 */       throw new ConfusedCFRException("Incompatible types : " + typeInstanceThis.getClass() + "[" + typeInstanceThis + "] / " + typeInstanceOther.getClass() + "[" + typeInstanceOther + "]");
/*  928:     */     }
/*  929: 947 */     this.value.forceType(other, true);
/*  930:     */   }
/*  931:     */   
/*  932:     */   public void applyKnownBaseType()
/*  933:     */   {
/*  934: 952 */     JavaTypeInstance type = this.value.getKnownBaseType();
/*  935: 953 */     if (type == null) {
/*  936: 954 */       return;
/*  937:     */     }
/*  938: 956 */     this.value.forceType(type, false);
/*  939:     */   }
/*  940:     */   
/*  941:     */   public CastAction chain(InferredJavaType other)
/*  942:     */   {
/*  943: 964 */     if (this == IGNORE) {
/*  944: 964 */       return CastAction.None;
/*  945:     */     }
/*  946: 965 */     if (other == IGNORE) {
/*  947: 965 */       return CastAction.None;
/*  948:     */     }
/*  949: 967 */     if (other.getRawType() == RawJavaType.VOID) {
/*  950: 968 */       return CastAction.None;
/*  951:     */     }
/*  952: 971 */     RawJavaType thisRaw = this.value.getRawType();
/*  953: 972 */     RawJavaType otherRaw = other.getRawType();
/*  954: 974 */     if (thisRaw == RawJavaType.VOID) {
/*  955: 975 */       return chainFrom(other);
/*  956:     */     }
/*  957: 978 */     if (thisRaw.getStackType() != otherRaw.getStackType())
/*  958:     */     {
/*  959: 980 */       if (MiscUtils.xor(thisRaw.getStackType(), otherRaw.getStackType(), StackType.REF)) {
/*  960: 981 */         this.value = IJTInternal_Clash.mkClash(this.value, other.value);
/*  961:     */       }
/*  962: 983 */       return CastAction.InsertExplicit;
/*  963:     */     }
/*  964: 985 */     if ((thisRaw == otherRaw) && (thisRaw.getStackType() != StackType.INT)) {
/*  965: 986 */       return chainFrom(other);
/*  966:     */     }
/*  967: 988 */     if ((thisRaw == RawJavaType.NULL) && ((otherRaw == RawJavaType.NULL) || (otherRaw == RawJavaType.REF))) {
/*  968: 989 */       return chainFrom(other);
/*  969:     */     }
/*  970: 991 */     if ((thisRaw == RawJavaType.REF) && (otherRaw == RawJavaType.NULL)) {
/*  971: 992 */       return CastAction.None;
/*  972:     */     }
/*  973: 994 */     if (thisRaw.getStackType() == StackType.INT)
/*  974:     */     {
/*  975: 995 */       if (otherRaw.getStackType() != StackType.INT) {
/*  976: 996 */         throw new IllegalStateException();
/*  977:     */       }
/*  978: 998 */       return chainIntegralTypes(other);
/*  979:     */     }
/*  980:1000 */     throw new ConfusedCFRException("Don't know how to tighten from " + thisRaw + " to " + otherRaw);
/*  981:     */   }
/*  982:     */   
/*  983:     */   public RawJavaType getRawType()
/*  984:     */   {
/*  985:1005 */     return this.value.getRawType();
/*  986:     */   }
/*  987:     */   
/*  988:     */   public JavaTypeInstance getJavaTypeInstance()
/*  989:     */   {
/*  990:1013 */     return this.value.getJavaTypeInstance();
/*  991:     */   }
/*  992:     */   
/*  993:     */   public boolean equals(Object o)
/*  994:     */   {
/*  995:1018 */     throw new UnsupportedOperationException();
/*  996:     */   }
/*  997:     */   
/*  998:     */   public int hashCode()
/*  999:     */   {
/* 1000:1023 */     throw new UnsupportedOperationException();
/* 1001:     */   }
/* 1002:     */   
/* 1003:     */   public String toString()
/* 1004:     */   {
/* 1005:1028 */     return this.value.getClashState() == ClashState.Clash ? " /* !! */ " : "";
/* 1006:     */   }
/* 1007:     */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType
 * JD-Core Version:    0.7.0.1
 */