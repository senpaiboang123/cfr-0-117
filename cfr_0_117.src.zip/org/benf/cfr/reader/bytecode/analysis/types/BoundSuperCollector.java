/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.types;
/*  2:   */ 
/*  3:   */ import java.util.Map;
/*  4:   */ import org.benf.cfr.reader.entities.ClassFile;
/*  5:   */ import org.benf.cfr.reader.util.MapFactory;
/*  6:   */ 
/*  7:   */ public class BoundSuperCollector
/*  8:   */ {
/*  9:   */   private final ClassFile classFile;
/* 10:   */   private final Map<JavaRefTypeInstance, JavaGenericRefTypeInstance> boundSupers;
/* 11:   */   private final Map<JavaRefTypeInstance, BindingSuperContainer.Route> boundSuperRoute;
/* 12:   */   
/* 13:   */   public BoundSuperCollector(ClassFile classFile)
/* 14:   */   {
/* 15:16 */     this.classFile = classFile;
/* 16:17 */     this.boundSupers = MapFactory.newLinkedMap();
/* 17:18 */     this.boundSuperRoute = MapFactory.newLinkedMap();
/* 18:   */   }
/* 19:   */   
/* 20:   */   public BindingSuperContainer getBoundSupers()
/* 21:   */   {
/* 22:22 */     return new BindingSuperContainer(this.classFile, this.boundSupers, this.boundSuperRoute);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void collect(JavaGenericRefTypeInstance boundBase, BindingSuperContainer.Route route)
/* 26:   */   {
/* 27:26 */     JavaRefTypeInstance key = boundBase.getDeGenerifiedType();
/* 28:27 */     JavaGenericRefTypeInstance prev = (JavaGenericRefTypeInstance)this.boundSupers.put(key, boundBase);
/* 29:28 */     this.boundSuperRoute.put(key, route);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void collect(JavaRefTypeInstance boundBase, BindingSuperContainer.Route route)
/* 33:   */   {
/* 34:33 */     JavaGenericRefTypeInstance prev = (JavaGenericRefTypeInstance)this.boundSupers.put(boundBase, null);
/* 35:34 */     this.boundSuperRoute.put(boundBase, route);
/* 36:   */   }
/* 37:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.BoundSuperCollector
 * JD-Core Version:    0.7.0.1
 */