/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.types;
/*   2:    */ 
/*   3:    */ import java.util.Map;
/*   4:    */ import java.util.Set;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.types.annotated.JavaAnnotatedTypeInstance;
/*   6:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*   7:    */ import org.benf.cfr.reader.state.TypeUsageInformation;
/*   8:    */ import org.benf.cfr.reader.util.MapFactory;
/*   9:    */ import org.benf.cfr.reader.util.SetFactory;
/*  10:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  11:    */ 
/*  12:    */ public enum RawJavaType
/*  13:    */   implements JavaTypeInstance
/*  14:    */ {
/*  15: 15 */   BOOLEAN("boolean", "bl", StackType.INT, true, "java.lang.Boolean", false, false),  BYTE("byte", "by", StackType.INT, true, "java.lang.Byte", true, false),  CHAR("char", "c", StackType.INT, true, "java.lang.Character", false, false),  SHORT("short", "s", StackType.INT, true, "java.lang.Short", true, false),  INT("int", "n", StackType.INT, true, "java.lang.Integer", true, false),  LONG("long", "l", StackType.LONG, true, "java.lang.Long", true, false),  FLOAT("float", "f", StackType.FLOAT, true, "java.lang.Float", true, false),  DOUBLE("double", "d", StackType.DOUBLE, true, "java.lang.Double", true, false),  VOID("void", null, StackType.VOID, false, false),  REF("reference", null, StackType.REF, false, true),  RETURNADDRESS("returnaddress", null, StackType.RETURNADDRESS, false, true),  RETURNADDRESSORREF("returnaddress or ref", null, StackType.RETURNADDRESSORREF, false, true),  NULL("null", null, StackType.REF, false, true);
/*  16:    */   
/*  17:    */   private final String name;
/*  18:    */   private final String suggestedVarName;
/*  19:    */   private final StackType stackType;
/*  20:    */   private final boolean usableType;
/*  21:    */   private final String boxedName;
/*  22:    */   private final boolean isNumber;
/*  23:    */   private final boolean isObject;
/*  24:    */   private static final Map<RawJavaType, Set<RawJavaType>> implicitCasts;
/*  25:    */   private static final Map<String, RawJavaType> boxingTypes;
/*  26:    */   
/*  27:    */   static
/*  28:    */   {
/*  29: 37 */     implicitCasts = MapFactory.newMap();
/*  30: 38 */     boxingTypes = MapFactory.newMap();
/*  31:    */     
/*  32:    */ 
/*  33: 41 */     implicitCasts.put(FLOAT, SetFactory.newSet(new RawJavaType[] { DOUBLE }));
/*  34: 42 */     implicitCasts.put(LONG, SetFactory.newSet(new RawJavaType[] { FLOAT, DOUBLE }));
/*  35: 43 */     implicitCasts.put(INT, SetFactory.newSet(new RawJavaType[] { LONG, FLOAT, DOUBLE }));
/*  36: 44 */     implicitCasts.put(CHAR, SetFactory.newSet(new RawJavaType[] { INT, LONG, FLOAT, DOUBLE }));
/*  37: 45 */     implicitCasts.put(SHORT, SetFactory.newSet(new RawJavaType[] { INT, LONG, FLOAT, DOUBLE }));
/*  38: 46 */     implicitCasts.put(BYTE, SetFactory.newSet(new RawJavaType[] { SHORT, INT, LONG, FLOAT, DOUBLE }));
/*  39: 47 */     for (RawJavaType type : values()) {
/*  40: 48 */       if (type.boxedName != null) {
/*  41: 49 */         boxingTypes.put(type.boxedName, type);
/*  42:    */       }
/*  43:    */     }
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static RawJavaType getUnboxedTypeFor(JavaTypeInstance type)
/*  47:    */   {
/*  48: 55 */     String rawName = type.getRawName();
/*  49: 56 */     RawJavaType tgt = (RawJavaType)boxingTypes.get(rawName);
/*  50: 57 */     return tgt;
/*  51:    */   }
/*  52:    */   
/*  53:    */   private RawJavaType(String name, String suggestedVarName, StackType stackType, boolean usableType, String boxedName, boolean isNumber, boolean objectType)
/*  54:    */   {
/*  55: 62 */     this.name = name;
/*  56: 63 */     this.stackType = stackType;
/*  57: 64 */     this.usableType = usableType;
/*  58: 65 */     this.boxedName = boxedName;
/*  59: 66 */     this.suggestedVarName = suggestedVarName;
/*  60: 67 */     this.isNumber = isNumber;
/*  61: 68 */     this.isObject = objectType;
/*  62:    */   }
/*  63:    */   
/*  64:    */   private RawJavaType(String name, String suggestedVarName, StackType stackType, boolean usableType, boolean objectType)
/*  65:    */   {
/*  66: 72 */     this(name, suggestedVarName, stackType, usableType, null, false, objectType);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public String getName()
/*  70:    */   {
/*  71: 78 */     return this.name;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public JavaAnnotatedTypeInstance getAnnotatedInstance()
/*  75:    */   {
/*  76: 83 */     return new Annotated(null);
/*  77:    */   }
/*  78:    */   
/*  79:    */   private class Annotated
/*  80:    */     implements JavaAnnotatedTypeInstance
/*  81:    */   {
/*  82:    */     private Annotated() {}
/*  83:    */     
/*  84:    */     public JavaAnnotatedTypeIterator pathIterator()
/*  85:    */     {
/*  86: 89 */       throw new UnsupportedOperationException();
/*  87:    */     }
/*  88:    */     
/*  89:    */     public Dumper dump(Dumper d)
/*  90:    */     {
/*  91: 94 */       return d;
/*  92:    */     }
/*  93:    */   }
/*  94:    */   
/*  95:    */   public StackType getStackType()
/*  96:    */   {
/*  97:100 */     return this.stackType;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public boolean isComplexType()
/* 101:    */   {
/* 102:105 */     return false;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public boolean isObject()
/* 106:    */   {
/* 107:109 */     return this.isObject;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public int compareTypePriorityTo(RawJavaType other)
/* 111:    */   {
/* 112:118 */     if (this.stackType != StackType.INT) {
/* 113:118 */       throw new IllegalArgumentException();
/* 114:    */     }
/* 115:119 */     if (other.stackType != StackType.INT) {
/* 116:119 */       throw new IllegalArgumentException();
/* 117:    */     }
/* 118:120 */     return ordinal() - other.ordinal();
/* 119:    */   }
/* 120:    */   
/* 121:    */   public int compareAllPriorityTo(RawJavaType other)
/* 122:    */   {
/* 123:124 */     return ordinal() - other.ordinal();
/* 124:    */   }
/* 125:    */   
/* 126:    */   public boolean isUsableType()
/* 127:    */   {
/* 128:129 */     return this.usableType;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public RawJavaType getRawTypeOfSimpleType()
/* 132:    */   {
/* 133:134 */     return this;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public JavaTypeInstance removeAnArrayIndirection()
/* 137:    */   {
/* 138:139 */     return VOID;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public JavaTypeInstance getArrayStrippedType()
/* 142:    */   {
/* 143:144 */     return this;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public JavaTypeInstance getDeGenerifiedType()
/* 147:    */   {
/* 148:149 */     return this;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public int getNumArrayDimensions()
/* 152:    */   {
/* 153:155 */     return 0;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public String getRawName()
/* 157:    */   {
/* 158:160 */     return this.name;
/* 159:    */   }
/* 160:    */   
/* 161:    */   public InnerClassInfo getInnerClassHereInfo()
/* 162:    */   {
/* 163:165 */     return InnerClassInfo.NOT;
/* 164:    */   }
/* 165:    */   
/* 166:    */   public BindingSuperContainer getBindingSupers()
/* 167:    */   {
/* 168:170 */     return null;
/* 169:    */   }
/* 170:    */   
/* 171:    */   private boolean implicitlyCastsTo(RawJavaType other)
/* 172:    */   {
/* 173:174 */     if (other == this) {
/* 174:174 */       return true;
/* 175:    */     }
/* 176:175 */     Set<RawJavaType> tgt = (Set)implicitCasts.get(this);
/* 177:176 */     if (tgt == null) {
/* 178:176 */       return false;
/* 179:    */     }
/* 180:177 */     return tgt.contains(other);
/* 181:    */   }
/* 182:    */   
/* 183:    */   public boolean implicitlyCastsTo(JavaTypeInstance other, GenericTypeBinder gtb)
/* 184:    */   {
/* 185:183 */     if ((other instanceof RawJavaType)) {
/* 186:184 */       return implicitlyCastsTo((RawJavaType)other);
/* 187:    */     }
/* 188:186 */     if (this == NULL) {
/* 189:186 */       return true;
/* 190:    */     }
/* 191:187 */     if (this == REF) {
/* 192:187 */       return true;
/* 193:    */     }
/* 194:189 */     if ((other instanceof JavaGenericPlaceholderTypeInstance)) {
/* 195:191 */       return true;
/* 196:    */     }
/* 197:196 */     if ((other instanceof JavaRefTypeInstance))
/* 198:    */     {
/* 199:197 */       if (other == TypeConstants.OBJECT) {
/* 200:198 */         return true;
/* 201:    */       }
/* 202:200 */       RawJavaType tgt = getUnboxedTypeFor((JavaRefTypeInstance)other);
/* 203:201 */       if (tgt == null)
/* 204:    */       {
/* 205:203 */         if (other.getRawName().equals("java.lang.Number")) {
/* 206:204 */           return this.isNumber;
/* 207:    */         }
/* 208:206 */         return false;
/* 209:    */       }
/* 210:209 */       return equals(tgt);
/* 211:    */     }
/* 212:211 */     return false;
/* 213:    */   }
/* 214:    */   
/* 215:    */   public boolean impreciseCanCastTo(JavaTypeInstance other, GenericTypeBinder gtb)
/* 216:    */   {
/* 217:216 */     if ((this.boxedName != null) && ((other instanceof JavaRefTypeInstance)))
/* 218:    */     {
/* 219:217 */       RawJavaType tgt = getUnboxedTypeFor((JavaRefTypeInstance)other);
/* 220:218 */       if (tgt == null)
/* 221:    */       {
/* 222:219 */         if (other == TypeConstants.OBJECT) {
/* 223:220 */           return true;
/* 224:    */         }
/* 225:222 */         if (other.getRawName().equals("java.lang.Number")) {
/* 226:223 */           return this.isNumber;
/* 227:    */         }
/* 228:226 */         return false;
/* 229:    */       }
/* 230:228 */       return (implicitlyCastsTo(tgt)) || (tgt.implicitlyCastsTo(this));
/* 231:    */     }
/* 232:232 */     return true;
/* 233:    */   }
/* 234:    */   
/* 235:    */   public boolean correctCanCastTo(JavaTypeInstance other, GenericTypeBinder gtb)
/* 236:    */   {
/* 237:237 */     return impreciseCanCastTo(other, gtb);
/* 238:    */   }
/* 239:    */   
/* 240:    */   public String suggestVarName()
/* 241:    */   {
/* 242:243 */     return this.suggestedVarName;
/* 243:    */   }
/* 244:    */   
/* 245:    */   public void dumpInto(Dumper d, TypeUsageInformation typeUsageInformation)
/* 246:    */   {
/* 247:248 */     if (this == NULL)
/* 248:    */     {
/* 249:249 */       TypeConstants.OBJECT.dumpInto(d, typeUsageInformation);
/* 250:250 */       return;
/* 251:    */     }
/* 252:252 */     d.print(toString());
/* 253:    */   }
/* 254:    */   
/* 255:    */   public String toString()
/* 256:    */   {
/* 257:261 */     return this.name;
/* 258:    */   }
/* 259:    */   
/* 260:    */   public void collectInto(TypeUsageCollector typeUsageCollector) {}
/* 261:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.RawJavaType
 * JD-Core Version:    0.7.0.1
 */