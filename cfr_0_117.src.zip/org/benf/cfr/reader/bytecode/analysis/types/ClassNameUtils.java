/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.types;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  4:   */ 
/*  5:   */ public class ClassNameUtils
/*  6:   */ {
/*  7:   */   public static String convertFromPath(String from)
/*  8:   */   {
/*  9: 7 */     return from.replace('/', '.');
/* 10:   */   }
/* 11:   */   
/* 12:   */   public static String convertToPath(String from)
/* 13:   */   {
/* 14:12 */     return from.replace('.', '/');
/* 15:   */   }
/* 16:   */   
/* 17:   */   public static Pair<String, String> getPackageAndClassNames(String rawName)
/* 18:   */   {
/* 19:16 */     String full = convertFromPath(rawName);
/* 20:17 */     int idx = full.lastIndexOf('.');
/* 21:18 */     if (idx == -1) {
/* 22:18 */       return Pair.make("", rawName);
/* 23:   */     }
/* 24:19 */     return Pair.make(full.substring(0, idx), full.substring(idx + 1));
/* 25:   */   }
/* 26:   */   
/* 27:   */   public static String getTypeFixPrefix(JavaTypeInstance typ)
/* 28:   */   {
/* 29:23 */     String rawName = typ.getRawName();
/* 30:24 */     rawName = rawName.replace("[]", "_arr").replaceAll("[*?<>. ]", "_");
/* 31:25 */     return rawName + "_";
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.ClassNameUtils
 * JD-Core Version:    0.7.0.1
 */