/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.types;
/*  2:   */ 
/*  3:   */ public enum StackType
/*  4:   */ {
/*  5: 7 */   INT("int", 1, true),  FLOAT("float", 1, true),  REF("reference", 1, false),  RETURNADDRESS("returnaddress", 1, false),  RETURNADDRESSORREF("returnaddress or ref", 1, false),  LONG("long", 2, true),  DOUBLE("double", 2, true),  VOID("void", 0, false);
/*  6:   */   
/*  7:   */   private final String name;
/*  8:   */   private final int computationCategory;
/*  9:   */   private final StackTypes asList;
/* 10:   */   private final boolean closed;
/* 11:   */   
/* 12:   */   private StackType(String name, int computationCategory, boolean closed)
/* 13:   */   {
/* 14:22 */     this.name = name;
/* 15:23 */     this.computationCategory = computationCategory;
/* 16:24 */     this.asList = new StackTypes(new StackType[] { this });
/* 17:25 */     this.closed = closed;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public int getComputationCategory()
/* 21:   */   {
/* 22:29 */     return this.computationCategory;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public StackTypes asList()
/* 26:   */   {
/* 27:33 */     return this.asList;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public boolean isClosed()
/* 31:   */   {
/* 32:37 */     return this.closed;
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.StackType
 * JD-Core Version:    0.7.0.1
 */