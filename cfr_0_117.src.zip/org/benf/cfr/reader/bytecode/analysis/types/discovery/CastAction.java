package org.benf.cfr.reader.bytecode.analysis.types.discovery;

import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
import org.benf.cfr.reader.bytecode.analysis.parse.expression.CastExpression;
import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;

public enum CastAction
{
  None,  InsertExplicit;
  
  private CastAction() {}
  
  public abstract Expression performCastAction(Expression paramExpression, InferredJavaType paramInferredJavaType);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.discovery.CastAction
 * JD-Core Version:    0.7.0.1
 */