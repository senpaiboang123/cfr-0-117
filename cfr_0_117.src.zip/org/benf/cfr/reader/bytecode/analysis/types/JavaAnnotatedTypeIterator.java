/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.types;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.entities.annotations.AnnotationTableTypeEntry;
/*  4:   */ import org.benf.cfr.reader.util.DecompilerComment;
/*  5:   */ import org.benf.cfr.reader.util.DecompilerComments;
/*  6:   */ 
/*  7:   */ public abstract interface JavaAnnotatedTypeIterator
/*  8:   */ {
/*  9:   */   public abstract JavaAnnotatedTypeIterator moveArray(DecompilerComments paramDecompilerComments);
/* 10:   */   
/* 11:   */   public abstract JavaAnnotatedTypeIterator moveBound(DecompilerComments paramDecompilerComments);
/* 12:   */   
/* 13:   */   public abstract JavaAnnotatedTypeIterator moveNested(DecompilerComments paramDecompilerComments);
/* 14:   */   
/* 15:   */   public abstract JavaAnnotatedTypeIterator moveParameterized(int paramInt, DecompilerComments paramDecompilerComments);
/* 16:   */   
/* 17:   */   public abstract void apply(AnnotationTableTypeEntry paramAnnotationTableTypeEntry);
/* 18:   */   
/* 19:   */   public static abstract class BaseAnnotatedTypeIterator
/* 20:   */     implements JavaAnnotatedTypeIterator
/* 21:   */   {
/* 22:   */     protected void addBadComment(DecompilerComments comments)
/* 23:   */     {
/* 24:18 */       comments.addComment(DecompilerComment.BAD_ANNOTATION);
/* 25:   */     }
/* 26:   */     
/* 27:   */     public JavaAnnotatedTypeIterator moveParameterized(int index, DecompilerComments comments)
/* 28:   */     {
/* 29:23 */       addBadComment(comments);
/* 30:24 */       return this;
/* 31:   */     }
/* 32:   */     
/* 33:   */     public JavaAnnotatedTypeIterator moveNested(DecompilerComments comments)
/* 34:   */     {
/* 35:29 */       addBadComment(comments);
/* 36:30 */       return this;
/* 37:   */     }
/* 38:   */     
/* 39:   */     public JavaAnnotatedTypeIterator moveBound(DecompilerComments comments)
/* 40:   */     {
/* 41:35 */       addBadComment(comments);
/* 42:36 */       return this;
/* 43:   */     }
/* 44:   */     
/* 45:   */     public JavaAnnotatedTypeIterator moveArray(DecompilerComments comments)
/* 46:   */     {
/* 47:41 */       addBadComment(comments);
/* 48:42 */       return this;
/* 49:   */     }
/* 50:   */   }
/* 51:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.JavaAnnotatedTypeIterator
 * JD-Core Version:    0.7.0.1
 */