/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.types;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.types.annotated.JavaAnnotatedTypeInstance;
/*   5:    */ import org.benf.cfr.reader.entities.annotations.AnnotationTableTypeEntry;
/*   6:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*   7:    */ import org.benf.cfr.reader.state.TypeUsageInformation;
/*   8:    */ import org.benf.cfr.reader.util.DecompilerComments;
/*   9:    */ import org.benf.cfr.reader.util.ListFactory;
/*  10:    */ import org.benf.cfr.reader.util.StringUtils;
/*  11:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  12:    */ import org.benf.cfr.reader.util.output.ToStringDumper;
/*  13:    */ 
/*  14:    */ public class JavaArrayTypeInstance
/*  15:    */   implements JavaTypeInstance
/*  16:    */ {
/*  17:    */   private final int dimensions;
/*  18:    */   private final JavaTypeInstance underlyingType;
/*  19:    */   private JavaTypeInstance cachedDegenerifiedType;
/*  20:    */   
/*  21:    */   public JavaArrayTypeInstance(int dimensions, JavaTypeInstance underlyingType)
/*  22:    */   {
/*  23: 21 */     this.dimensions = dimensions;
/*  24: 22 */     this.underlyingType = underlyingType;
/*  25:    */   }
/*  26:    */   
/*  27:    */   private class Annotated
/*  28:    */     implements JavaAnnotatedTypeInstance
/*  29:    */   {
/*  30:    */     private final List<List<AnnotationTableTypeEntry>> entries;
/*  31:    */     private final JavaAnnotatedTypeInstance annotatedUnderlyingType;
/*  32:    */     
/*  33:    */     public Annotated()
/*  34:    */     {
/*  35: 30 */       this.entries = ListFactory.newList();
/*  36: 31 */       for (int x = 0; x < JavaArrayTypeInstance.this.dimensions; x++) {
/*  37: 32 */         this.entries.add(ListFactory.newList());
/*  38:    */       }
/*  39: 34 */       this.annotatedUnderlyingType = JavaArrayTypeInstance.this.underlyingType.getAnnotatedInstance();
/*  40:    */     }
/*  41:    */     
/*  42:    */     public Dumper dump(Dumper d)
/*  43:    */     {
/*  44: 39 */       this.annotatedUnderlyingType.dump(d);
/*  45: 40 */       boolean isFirst = !((List)this.entries.get(0)).isEmpty();
/*  46: 41 */       for (List<AnnotationTableTypeEntry> entry : this.entries)
/*  47:    */       {
/*  48: 42 */         if (!entry.isEmpty())
/*  49:    */         {
/*  50: 43 */           isFirst = StringUtils.space(isFirst, d);
/*  51: 44 */           for (AnnotationTableTypeEntry oneEntry : entry)
/*  52:    */           {
/*  53: 45 */             oneEntry.dump(d);
/*  54: 46 */             d.print(' ');
/*  55:    */           }
/*  56:    */         }
/*  57: 49 */         d.print("[]");
/*  58:    */       }
/*  59: 51 */       return d;
/*  60:    */     }
/*  61:    */     
/*  62:    */     public JavaAnnotatedTypeIterator pathIterator()
/*  63:    */     {
/*  64: 56 */       return new Iterator(null);
/*  65:    */     }
/*  66:    */     
/*  67:    */     private class Iterator
/*  68:    */       extends JavaAnnotatedTypeIterator.BaseAnnotatedTypeIterator
/*  69:    */     {
/*  70:    */       private int curIdx;
/*  71:    */       
/*  72:    */       private Iterator()
/*  73:    */       {
/*  74: 63 */         this.curIdx = 0;
/*  75:    */       }
/*  76:    */       
/*  77:    */       private Iterator(int idx)
/*  78:    */       {
/*  79: 67 */         this.curIdx = idx;
/*  80:    */       }
/*  81:    */       
/*  82:    */       public JavaAnnotatedTypeIterator moveArray(DecompilerComments comments)
/*  83:    */       {
/*  84: 72 */         if (this.curIdx + 1 < JavaArrayTypeInstance.this.dimensions) {
/*  85: 72 */           return new Iterator(JavaArrayTypeInstance.Annotated.this, this.curIdx + 1);
/*  86:    */         }
/*  87: 73 */         return JavaArrayTypeInstance.Annotated.this.annotatedUnderlyingType.pathIterator();
/*  88:    */       }
/*  89:    */       
/*  90:    */       public void apply(AnnotationTableTypeEntry entry)
/*  91:    */       {
/*  92: 78 */         ((List)JavaArrayTypeInstance.Annotated.this.entries.get(this.curIdx)).add(entry);
/*  93:    */       }
/*  94:    */     }
/*  95:    */   }
/*  96:    */   
/*  97:    */   public JavaAnnotatedTypeInstance getAnnotatedInstance()
/*  98:    */   {
/*  99: 85 */     return new Annotated();
/* 100:    */   }
/* 101:    */   
/* 102:    */   public StackType getStackType()
/* 103:    */   {
/* 104: 90 */     return StackType.REF;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void dumpInto(Dumper d, TypeUsageInformation typeUsageInformation)
/* 108:    */   {
/* 109: 95 */     toCommonString(getNumArrayDimensions(), d);
/* 110:    */   }
/* 111:    */   
/* 112:    */   public String toString()
/* 113:    */   {
/* 114:100 */     return new ToStringDumper().dump(this).toString();
/* 115:    */   }
/* 116:    */   
/* 117:    */   private void toCommonString(int numDims, Dumper d)
/* 118:    */   {
/* 119:104 */     d.dump(this.underlyingType.getArrayStrippedType());
/* 120:105 */     for (int x = 0; x < numDims; x++) {
/* 121:106 */       d.print("[]");
/* 122:    */     }
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void toVarargString(Dumper d)
/* 126:    */   {
/* 127:111 */     toCommonString(getNumArrayDimensions() - 1, d);
/* 128:112 */     d.print(" ...");
/* 129:    */   }
/* 130:    */   
/* 131:    */   public boolean isObject()
/* 132:    */   {
/* 133:117 */     return true;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public String getRawName()
/* 137:    */   {
/* 138:122 */     return new ToStringDumper().dump(this).toString();
/* 139:    */   }
/* 140:    */   
/* 141:    */   public InnerClassInfo getInnerClassHereInfo()
/* 142:    */   {
/* 143:127 */     return InnerClassInfo.NOT;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public BindingSuperContainer getBindingSupers()
/* 147:    */   {
/* 148:132 */     return null;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public JavaTypeInstance getArrayStrippedType()
/* 152:    */   {
/* 153:137 */     if ((this.underlyingType instanceof JavaArrayTypeInstance)) {
/* 154:138 */       return this.underlyingType.getArrayStrippedType();
/* 155:    */     }
/* 156:140 */     return this.underlyingType;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public int getNumArrayDimensions()
/* 160:    */   {
/* 161:145 */     return this.dimensions + this.underlyingType.getNumArrayDimensions();
/* 162:    */   }
/* 163:    */   
/* 164:    */   public int hashCode()
/* 165:    */   {
/* 166:150 */     return this.dimensions * 31 + this.underlyingType.hashCode();
/* 167:    */   }
/* 168:    */   
/* 169:    */   public boolean equals(Object o)
/* 170:    */   {
/* 171:155 */     if (this == o) {
/* 172:155 */       return true;
/* 173:    */     }
/* 174:156 */     if (!(o instanceof JavaArrayTypeInstance)) {
/* 175:156 */       return false;
/* 176:    */     }
/* 177:157 */     JavaArrayTypeInstance other = (JavaArrayTypeInstance)o;
/* 178:158 */     return (other.dimensions == this.dimensions) && (other.underlyingType.equals(this.underlyingType));
/* 179:    */   }
/* 180:    */   
/* 181:    */   public boolean isComplexType()
/* 182:    */   {
/* 183:163 */     return true;
/* 184:    */   }
/* 185:    */   
/* 186:    */   public boolean isUsableType()
/* 187:    */   {
/* 188:168 */     return true;
/* 189:    */   }
/* 190:    */   
/* 191:    */   public JavaTypeInstance removeAnArrayIndirection()
/* 192:    */   {
/* 193:174 */     if (this.dimensions == 1) {
/* 194:174 */       return this.underlyingType;
/* 195:    */     }
/* 196:175 */     return new JavaArrayTypeInstance(this.dimensions - 1, this.underlyingType);
/* 197:    */   }
/* 198:    */   
/* 199:    */   public JavaTypeInstance getDeGenerifiedType()
/* 200:    */   {
/* 201:180 */     if (this.cachedDegenerifiedType == null) {
/* 202:181 */       this.cachedDegenerifiedType = new JavaArrayTypeInstance(this.dimensions, this.underlyingType.getDeGenerifiedType());
/* 203:    */     }
/* 204:183 */     return this.cachedDegenerifiedType;
/* 205:    */   }
/* 206:    */   
/* 207:    */   public RawJavaType getRawTypeOfSimpleType()
/* 208:    */   {
/* 209:188 */     return RawJavaType.REF;
/* 210:    */   }
/* 211:    */   
/* 212:    */   public void collectInto(TypeUsageCollector typeUsageCollector)
/* 213:    */   {
/* 214:193 */     typeUsageCollector.collect(this.underlyingType);
/* 215:    */   }
/* 216:    */   
/* 217:    */   public boolean implicitlyCastsTo(JavaTypeInstance other, GenericTypeBinder gtb)
/* 218:    */   {
/* 219:198 */     if (other == TypeConstants.OBJECT) {
/* 220:198 */       return true;
/* 221:    */     }
/* 222:199 */     if ((other instanceof JavaArrayTypeInstance))
/* 223:    */     {
/* 224:200 */       JavaArrayTypeInstance arrayOther = (JavaArrayTypeInstance)other;
/* 225:201 */       if (getNumArrayDimensions() != arrayOther.getNumArrayDimensions()) {
/* 226:201 */         return false;
/* 227:    */       }
/* 228:202 */       return getArrayStrippedType().implicitlyCastsTo(arrayOther.getArrayStrippedType(), gtb);
/* 229:    */     }
/* 230:204 */     return false;
/* 231:    */   }
/* 232:    */   
/* 233:    */   public boolean impreciseCanCastTo(JavaTypeInstance other, GenericTypeBinder gtb)
/* 234:    */   {
/* 235:209 */     return true;
/* 236:    */   }
/* 237:    */   
/* 238:    */   public boolean correctCanCastTo(JavaTypeInstance other, GenericTypeBinder gtb)
/* 239:    */   {
/* 240:215 */     return impreciseCanCastTo(other, gtb);
/* 241:    */   }
/* 242:    */   
/* 243:    */   public String suggestVarName()
/* 244:    */   {
/* 245:220 */     return "arr" + this.underlyingType.suggestVarName();
/* 246:    */   }
/* 247:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.JavaArrayTypeInstance
 * JD-Core Version:    0.7.0.1
 */