/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.types;
/*  2:   */ 
/*  3:   */ public enum WildcardType
/*  4:   */ {
/*  5: 4 */   NONE(""),  SUPER("super"),  EXTENDS("extends");
/*  6:   */   
/*  7:   */   private final String name;
/*  8:   */   
/*  9:   */   private WildcardType(String name)
/* 10:   */   {
/* 11:11 */     this.name = name;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String toString()
/* 15:   */   {
/* 16:17 */     return this.name;
/* 17:   */   }
/* 18:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.WildcardType
 * JD-Core Version:    0.7.0.1
 */