/* 1:  */ package org.benf.cfr.reader.bytecode.analysis.types;
/* 2:  */ 
/* 3:  */ public class InnerClassInfoUtils
/* 4:  */ {
/* 5:  */   public static JavaRefTypeInstance getTransitiveOuterClass(JavaRefTypeInstance type)
/* 6:  */   {
/* 7:5 */     while (type.getInnerClassHereInfo().isInnerClass()) {
/* 8:6 */       type = type.getInnerClassHereInfo().getOuterClass();
/* 9:  */     }
/* ::8 */     return type;
/* ;:  */   }
/* <:  */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.InnerClassInfoUtils
 * JD-Core Version:    0.7.0.1
 */