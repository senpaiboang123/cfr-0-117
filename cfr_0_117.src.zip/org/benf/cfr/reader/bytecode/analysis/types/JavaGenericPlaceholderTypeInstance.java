/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.types;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.types.annotated.JavaAnnotatedTypeInstance;
/*   5:    */ import org.benf.cfr.reader.entities.annotations.AnnotationTableTypeEntry;
/*   6:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*   7:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*   8:    */ import org.benf.cfr.reader.state.TypeUsageInformation;
/*   9:    */ import org.benf.cfr.reader.util.ListFactory;
/*  10:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  11:    */ 
/*  12:    */ public class JavaGenericPlaceholderTypeInstance
/*  13:    */   implements JavaGenericBaseInstance
/*  14:    */ {
/*  15:    */   private final String className;
/*  16:    */   private final ConstantPool cp;
/*  17:    */   
/*  18:    */   public JavaGenericPlaceholderTypeInstance(String className, ConstantPool cp)
/*  19:    */   {
/*  20: 20 */     this.className = className;
/*  21: 21 */     this.cp = cp;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public JavaTypeInstance getBoundInstance(GenericTypeBinder genericTypeBinder)
/*  25:    */   {
/*  26: 26 */     return genericTypeBinder.getBindingFor(this);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public JavaAnnotatedTypeInstance getAnnotatedInstance()
/*  30:    */   {
/*  31: 31 */     return new Annotated(null);
/*  32:    */   }
/*  33:    */   
/*  34:    */   private class Annotated
/*  35:    */     implements JavaAnnotatedTypeInstance
/*  36:    */   {
/*  37:    */     private final List<AnnotationTableTypeEntry> entries;
/*  38:    */     
/*  39:    */     private Annotated()
/*  40:    */     {
/*  41: 35 */       this.entries = ListFactory.newList();
/*  42:    */     }
/*  43:    */     
/*  44:    */     public JavaAnnotatedTypeIterator pathIterator()
/*  45:    */     {
/*  46: 39 */       return new Iterator(null);
/*  47:    */     }
/*  48:    */     
/*  49:    */     public Dumper dump(Dumper d)
/*  50:    */     {
/*  51: 44 */       if (!this.entries.isEmpty()) {
/*  52: 45 */         for (AnnotationTableTypeEntry entry : this.entries)
/*  53:    */         {
/*  54: 46 */           entry.dump(d);
/*  55: 47 */           d.print(' ');
/*  56:    */         }
/*  57:    */       }
/*  58: 50 */       d.print(JavaGenericPlaceholderTypeInstance.this.className);
/*  59: 51 */       return d;
/*  60:    */     }
/*  61:    */     
/*  62:    */     private class Iterator
/*  63:    */       extends JavaAnnotatedTypeIterator.BaseAnnotatedTypeIterator
/*  64:    */     {
/*  65:    */       private Iterator() {}
/*  66:    */       
/*  67:    */       public void apply(AnnotationTableTypeEntry entry)
/*  68:    */       {
/*  69: 57 */         JavaGenericPlaceholderTypeInstance.Annotated.this.entries.add(entry);
/*  70:    */       }
/*  71:    */     }
/*  72:    */   }
/*  73:    */   
/*  74:    */   public boolean isObject()
/*  75:    */   {
/*  76: 64 */     return true;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public boolean hasUnbound()
/*  80:    */   {
/*  81: 69 */     return true;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public boolean hasL01Wildcard()
/*  85:    */   {
/*  86: 74 */     return false;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public JavaTypeInstance getWithoutL01Wildcard()
/*  90:    */   {
/*  91: 79 */     return this;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public List<JavaTypeInstance> getGenericTypes()
/*  95:    */   {
/*  96: 84 */     return ListFactory.newList(new JavaTypeInstance[] { this });
/*  97:    */   }
/*  98:    */   
/*  99:    */   public boolean hasForeignUnbound(ConstantPool cp)
/* 100:    */   {
/* 101: 91 */     if (this.className.equals("?")) {
/* 102: 91 */       return true;
/* 103:    */     }
/* 104: 92 */     return !cp.equals(this.cp);
/* 105:    */   }
/* 106:    */   
/* 107:    */   public boolean tryFindBinding(JavaTypeInstance other, GenericTypeBinder target)
/* 108:    */   {
/* 109:100 */     target.suggestBindingFor(this.className, other);
/* 110:101 */     return true;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public StackType getStackType()
/* 114:    */   {
/* 115:106 */     return StackType.REF;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public void dumpInto(Dumper d, TypeUsageInformation typeUsageInformation)
/* 119:    */   {
/* 120:111 */     d.print(toString());
/* 121:    */   }
/* 122:    */   
/* 123:    */   public String toString()
/* 124:    */   {
/* 125:116 */     return this.className;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public JavaTypeInstance getArrayStrippedType()
/* 129:    */   {
/* 130:121 */     return this;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public int getNumArrayDimensions()
/* 134:    */   {
/* 135:126 */     return 0;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public String getRawName()
/* 139:    */   {
/* 140:131 */     return this.className;
/* 141:    */   }
/* 142:    */   
/* 143:    */   public InnerClassInfo getInnerClassHereInfo()
/* 144:    */   {
/* 145:136 */     return InnerClassInfo.NOT;
/* 146:    */   }
/* 147:    */   
/* 148:    */   public BindingSuperContainer getBindingSupers()
/* 149:    */   {
/* 150:141 */     return null;
/* 151:    */   }
/* 152:    */   
/* 153:    */   public int hashCode()
/* 154:    */   {
/* 155:147 */     return 31 + this.className.hashCode();
/* 156:    */   }
/* 157:    */   
/* 158:    */   public boolean equals(Object o)
/* 159:    */   {
/* 160:152 */     if (o == this) {
/* 161:152 */       return true;
/* 162:    */     }
/* 163:153 */     if (!(o instanceof JavaGenericPlaceholderTypeInstance)) {
/* 164:153 */       return false;
/* 165:    */     }
/* 166:154 */     JavaGenericPlaceholderTypeInstance other = (JavaGenericPlaceholderTypeInstance)o;
/* 167:155 */     return other.className.equals(this.className);
/* 168:    */   }
/* 169:    */   
/* 170:    */   public boolean isComplexType()
/* 171:    */   {
/* 172:160 */     return true;
/* 173:    */   }
/* 174:    */   
/* 175:    */   public boolean isUsableType()
/* 176:    */   {
/* 177:165 */     return true;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public JavaTypeInstance removeAnArrayIndirection()
/* 181:    */   {
/* 182:170 */     return this;
/* 183:    */   }
/* 184:    */   
/* 185:    */   public JavaTypeInstance getDeGenerifiedType()
/* 186:    */   {
/* 187:175 */     return TypeConstants.OBJECT;
/* 188:    */   }
/* 189:    */   
/* 190:    */   public RawJavaType getRawTypeOfSimpleType()
/* 191:    */   {
/* 192:180 */     return RawJavaType.REF;
/* 193:    */   }
/* 194:    */   
/* 195:    */   public void collectInto(TypeUsageCollector typeUsageCollector) {}
/* 196:    */   
/* 197:    */   public boolean implicitlyCastsTo(JavaTypeInstance other, GenericTypeBinder gtb)
/* 198:    */   {
/* 199:189 */     if (other == TypeConstants.OBJECT) {
/* 200:189 */       return true;
/* 201:    */     }
/* 202:190 */     if (other.equals(this)) {
/* 203:190 */       return true;
/* 204:    */     }
/* 205:191 */     return false;
/* 206:    */   }
/* 207:    */   
/* 208:    */   public boolean impreciseCanCastTo(JavaTypeInstance other, GenericTypeBinder gtb)
/* 209:    */   {
/* 210:196 */     return true;
/* 211:    */   }
/* 212:    */   
/* 213:    */   public boolean correctCanCastTo(JavaTypeInstance other, GenericTypeBinder gtb)
/* 214:    */   {
/* 215:201 */     return impreciseCanCastTo(other, gtb);
/* 216:    */   }
/* 217:    */   
/* 218:    */   public String suggestVarName()
/* 219:    */   {
/* 220:206 */     if (this.className.equals("?")) {
/* 221:206 */       return "obj";
/* 222:    */     }
/* 223:207 */     return this.className;
/* 224:    */   }
/* 225:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.JavaGenericPlaceholderTypeInstance
 * JD-Core Version:    0.7.0.1
 */