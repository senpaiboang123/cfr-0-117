/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.types;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Map;
/*   5:    */ import java.util.Map.Entry;
/*   6:    */ import java.util.Set;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.CastExpression;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdent;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifierFactory;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType.Source;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.variables.Ident;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.variables.Slot;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.variables.VariableNamer;
/*  17:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  18:    */ import org.benf.cfr.reader.entities.Method.MethodConstructor;
/*  19:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  20:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  21:    */ import org.benf.cfr.reader.util.DecompilerComment;
/*  22:    */ import org.benf.cfr.reader.util.DecompilerComments;
/*  23:    */ import org.benf.cfr.reader.util.ListFactory;
/*  24:    */ import org.benf.cfr.reader.util.MapFactory;
/*  25:    */ import org.benf.cfr.reader.util.SetFactory;
/*  26:    */ import org.benf.cfr.reader.util.StringUtils;
/*  27:    */ import org.benf.cfr.reader.util.TypeUsageCollectable;
/*  28:    */ import org.benf.cfr.reader.util.annotation.Nullable;
/*  29:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  30:    */ 
/*  31:    */ public class MethodPrototype
/*  32:    */   implements TypeUsageCollectable
/*  33:    */ {
/*  34:    */   private final List<FormalTypeParameter> formalTypeParameters;
/*  35:    */   private final List<JavaTypeInstance> args;
/*  36: 27 */   private final Set<Integer> hidden = SetFactory.newSet();
/*  37: 28 */   private boolean innerOuterThis = false;
/*  38:    */   private JavaTypeInstance result;
/*  39:    */   private final VariableNamer variableNamer;
/*  40:    */   private final boolean instanceMethod;
/*  41:    */   private final boolean varargs;
/*  42:    */   private final String name;
/*  43:    */   @Nullable
/*  44:    */   private String fixedName;
/*  45:    */   private final ClassFile classFile;
/*  46: 38 */   private final List<Slot> syntheticArgs = ListFactory.newList();
/*  47: 39 */   private transient List<LocalVariable> parameterLValues = null;
/*  48:    */   
/*  49:    */   public MethodPrototype(ClassFile classFile, JavaTypeInstance classType, String name, boolean instanceMethod, Method.MethodConstructor constructorFlag, List<FormalTypeParameter> formalTypeParameters, List<JavaTypeInstance> args, JavaTypeInstance result, boolean varargs, VariableNamer variableNamer, boolean synthetic)
/*  50:    */   {
/*  51: 42 */     this.formalTypeParameters = formalTypeParameters;
/*  52: 43 */     this.instanceMethod = instanceMethod;
/*  53: 56 */     if ((constructorFlag.equals(Method.MethodConstructor.ENUM_CONSTRUCTOR)) && (!synthetic))
/*  54:    */     {
/*  55: 57 */       List<JavaTypeInstance> args2 = ListFactory.newList();
/*  56: 58 */       args2.add(TypeConstants.STRING);
/*  57: 59 */       args2.add(RawJavaType.INT);
/*  58: 60 */       args2.addAll(args);
/*  59: 61 */       hide(0);
/*  60: 62 */       hide(1);
/*  61:    */       
/*  62: 64 */       args = args2;
/*  63:    */     }
/*  64: 67 */     this.args = args;
/*  65:    */     JavaTypeInstance resultType;
/*  66:    */     JavaTypeInstance resultType;
/*  67: 70 */     if ("<init>".equals(name))
/*  68:    */     {
/*  69:    */       JavaTypeInstance resultType;
/*  70: 71 */       if (classFile == null) {
/*  71: 72 */         resultType = classType;
/*  72:    */       } else {
/*  73: 74 */         resultType = null;
/*  74:    */       }
/*  75:    */     }
/*  76:    */     else
/*  77:    */     {
/*  78: 77 */       resultType = result;
/*  79:    */     }
/*  80: 79 */     this.result = resultType;
/*  81: 80 */     this.varargs = varargs;
/*  82: 81 */     this.variableNamer = variableNamer;
/*  83: 82 */     this.name = name;
/*  84: 83 */     this.fixedName = null;
/*  85: 84 */     this.classFile = classFile;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void unbreakEnumConstructor()
/*  89:    */   {
/*  90: 88 */     this.args.remove(0);
/*  91: 89 */     this.args.remove(0);
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  95:    */   {
/*  96: 94 */     collector.collect(this.result);
/*  97: 95 */     collector.collect(this.args);
/*  98: 96 */     collector.collectFrom(this.formalTypeParameters);
/*  99:    */   }
/* 100:    */   
/* 101:    */   public void hide(int x)
/* 102:    */   {
/* 103:100 */     this.hidden.add(Integer.valueOf(x));
/* 104:    */   }
/* 105:    */   
/* 106:    */   public void setInnerOuterThis()
/* 107:    */   {
/* 108:104 */     this.innerOuterThis = true;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public boolean isHiddenArg(int x)
/* 112:    */   {
/* 113:108 */     return this.hidden.contains(Integer.valueOf(x));
/* 114:    */   }
/* 115:    */   
/* 116:    */   public boolean isInnerOuterThis()
/* 117:    */   {
/* 118:112 */     return this.innerOuterThis;
/* 119:    */   }
/* 120:    */   
/* 121:    */   public void dumpDeclarationSignature(Dumper d, String methName, Method.MethodConstructor isConstructor, MethodPrototypeAnnotationsHelper annotationsHelper)
/* 122:    */   {
/* 123:117 */     if (this.formalTypeParameters != null)
/* 124:    */     {
/* 125:118 */       d.print('<');
/* 126:119 */       boolean first = true;
/* 127:120 */       for (FormalTypeParameter formalTypeParameter : this.formalTypeParameters)
/* 128:    */       {
/* 129:121 */         first = StringUtils.comma(first, d);
/* 130:122 */         d.dump(formalTypeParameter);
/* 131:    */       }
/* 132:124 */       d.print("> ");
/* 133:    */     }
/* 134:126 */     if (!isConstructor.isConstructor()) {
/* 135:127 */       d.dump(this.result).print(" ");
/* 136:    */     }
/* 137:129 */     d.identifier(methName).print("(");
/* 138:    */     
/* 139:    */ 
/* 140:    */ 
/* 141:133 */     List<LocalVariable> parameterLValues = getComputedParameters();
/* 142:134 */     int argssize = this.args.size();
/* 143:    */     int x;
/* 144:135 */     if (parameterLValues.size() != this.args.size()) {
/* 145:136 */       x = 1;
/* 146:    */     }
/* 147:138 */     boolean first = true;
/* 148:139 */     for (int i = 0; i < argssize; i++)
/* 149:    */     {
/* 150:140 */       JavaTypeInstance arg = (JavaTypeInstance)this.args.get(i);
/* 151:141 */       if (!this.hidden.contains(Integer.valueOf(i)))
/* 152:    */       {
/* 153:142 */         first = StringUtils.comma(first, d);
/* 154:    */         
/* 155:144 */         LocalVariable param = (LocalVariable)parameterLValues.get(i);
/* 156:145 */         if (param.isFinal()) {
/* 157:145 */           d.print("final ");
/* 158:    */         }
/* 159:146 */         annotationsHelper.addAnnotationTextForParameterInto(i, d);
/* 160:147 */         if ((this.varargs) && (i == argssize - 1))
/* 161:    */         {
/* 162:148 */           if (!(arg instanceof JavaArrayTypeInstance)) {
/* 163:149 */             throw new ConfusedCFRException("VARARGS method doesn't have an array as last arg!!");
/* 164:    */           }
/* 165:151 */           ((JavaArrayTypeInstance)arg).toVarargString(d);
/* 166:    */         }
/* 167:    */         else
/* 168:    */         {
/* 169:153 */           d.dump(arg);
/* 170:    */         }
/* 171:155 */         d.print(" ").dump(param.getName());
/* 172:    */       }
/* 173:    */     }
/* 174:157 */     d.print(")");
/* 175:    */   }
/* 176:    */   
/* 177:    */   public boolean parametersComputed()
/* 178:    */   {
/* 179:161 */     return this.parameterLValues != null;
/* 180:    */   }
/* 181:    */   
/* 182:    */   public List<LocalVariable> getComputedParameters()
/* 183:    */   {
/* 184:165 */     if (this.parameterLValues == null) {
/* 185:166 */       throw new IllegalStateException("Parameters not created");
/* 186:    */     }
/* 187:168 */     return this.parameterLValues;
/* 188:    */   }
/* 189:    */   
/* 190:    */   public void setSyntheticConstructorParameters(Method.MethodConstructor constructorFlag, DecompilerComments comments, Map<Integer, JavaTypeInstance> synthetics)
/* 191:    */   {
/* 192:172 */     this.syntheticArgs.clear();
/* 193:    */     
/* 194:174 */     int offset = 0;
/* 195:175 */     switch (1.$SwitchMap$org$benf$cfr$reader$entities$Method$MethodConstructor[constructorFlag.ordinal()])
/* 196:    */     {
/* 197:    */     case 1: 
/* 198:177 */       offset = 3;
/* 199:178 */       break;
/* 200:    */     default: 
/* 201:181 */       if (isInstanceMethod()) {
/* 202:181 */         offset = 1;
/* 203:    */       }
/* 204:    */       break;
/* 205:    */     }
/* 206:185 */     List<Slot> tmp = ListFactory.newList();
/* 207:186 */     for (Map.Entry<Integer, JavaTypeInstance> entry : synthetics.entrySet()) {
/* 208:187 */       tmp.add(new Slot((JavaTypeInstance)entry.getValue(), ((Integer)entry.getKey()).intValue()));
/* 209:    */     }
/* 210:190 */     if (!tmp.isEmpty())
/* 211:    */     {
/* 212:191 */       Slot test = (Slot)tmp.get(0);
/* 213:192 */       if (offset != test.getIdx())
/* 214:    */       {
/* 215:199 */         List<Slot> replacements = ListFactory.newList();
/* 216:200 */         for (Slot synthetic : tmp)
/* 217:    */         {
/* 218:201 */           JavaTypeInstance type = synthetic.getJavaTypeInstance();
/* 219:202 */           Slot replacement = new Slot(type, offset);
/* 220:203 */           offset += type.getStackType().getComputationCategory();
/* 221:204 */           replacements.add(replacement);
/* 222:    */         }
/* 223:206 */         this.syntheticArgs.addAll(replacements);
/* 224:207 */         comments.addComment(DecompilerComment.PARAMETER_CORRUPTION);
/* 225:    */       }
/* 226:    */       else
/* 227:    */       {
/* 228:209 */         this.syntheticArgs.addAll(tmp);
/* 229:    */       }
/* 230:    */     }
/* 231:    */   }
/* 232:    */   
/* 233:    */   public Map<Slot, SSAIdent> collectInitialSlotUsage(Method.MethodConstructor constructorFlag, SSAIdentifierFactory<Slot> ssaIdentifierFactory)
/* 234:    */   {
/* 235:219 */     Map<Slot, SSAIdent> res = MapFactory.newLinkedMap();
/* 236:220 */     int offset = 0;
/* 237:221 */     switch (1.$SwitchMap$org$benf$cfr$reader$entities$Method$MethodConstructor[constructorFlag.ordinal()])
/* 238:    */     {
/* 239:    */     }
/* 240:233 */     if (this.instanceMethod)
/* 241:    */     {
/* 242:234 */       Slot tgt = new Slot(this.classFile.getClassType(), 0);
/* 243:235 */       res.put(tgt, ssaIdentifierFactory.getIdent(tgt));
/* 244:236 */       offset = 1;
/* 245:    */     }
/* 246:241 */     if (!this.syntheticArgs.isEmpty()) {
/* 247:242 */       for (Slot synthetic : this.syntheticArgs)
/* 248:    */       {
/* 249:243 */         if (offset != synthetic.getIdx()) {
/* 250:244 */           throw new IllegalStateException("Synthetic arg - offset is " + offset + ", but got " + synthetic.getIdx());
/* 251:    */         }
/* 252:246 */         res.put(synthetic, ssaIdentifierFactory.getIdent(synthetic));
/* 253:247 */         offset += synthetic.getJavaTypeInstance().getStackType().getComputationCategory();
/* 254:    */       }
/* 255:    */     }
/* 256:250 */     for (JavaTypeInstance arg : this.args)
/* 257:    */     {
/* 258:251 */       Slot tgt = new Slot(arg, offset);
/* 259:252 */       res.put(tgt, ssaIdentifierFactory.getIdent(tgt));
/* 260:253 */       offset += arg.getStackType().getComputationCategory();
/* 261:    */     }
/* 262:255 */     return res;
/* 263:    */   }
/* 264:    */   
/* 265:    */   public List<LocalVariable> computeParameters(Method.MethodConstructor constructorFlag, Map<Integer, Ident> slotToIdentMap)
/* 266:    */   {
/* 267:259 */     if (this.parameterLValues != null) {
/* 268:260 */       return this.parameterLValues;
/* 269:    */     }
/* 270:263 */     this.parameterLValues = ListFactory.newList();
/* 271:264 */     int offset = 0;
/* 272:265 */     if (this.instanceMethod)
/* 273:    */     {
/* 274:266 */       this.variableNamer.forceName((Ident)slotToIdentMap.get(Integer.valueOf(0)), 0L, "this");
/* 275:267 */       offset = 1;
/* 276:    */     }
/* 277:269 */     if (constructorFlag != Method.MethodConstructor.ENUM_CONSTRUCTOR) {
/* 278:278 */       for (Slot synthetic : this.syntheticArgs)
/* 279:    */       {
/* 280:279 */         JavaTypeInstance typeInstance = synthetic.getJavaTypeInstance();
/* 281:280 */         this.parameterLValues.add(new LocalVariable(offset, (Ident)slotToIdentMap.get(Integer.valueOf(synthetic.getIdx())), this.variableNamer, 0, new InferredJavaType(typeInstance, InferredJavaType.Source.FIELD, true)));
/* 282:281 */         offset += typeInstance.getStackType().getComputationCategory();
/* 283:    */       }
/* 284:    */     }
/* 285:285 */     for (JavaTypeInstance arg : this.args)
/* 286:    */     {
/* 287:286 */       Ident ident = (Ident)slotToIdentMap.get(Integer.valueOf(offset));
/* 288:287 */       this.parameterLValues.add(new LocalVariable(offset, ident, this.variableNamer, 0, new InferredJavaType(arg, InferredJavaType.Source.FIELD, true)));
/* 289:288 */       offset += arg.getStackType().getComputationCategory();
/* 290:    */     }
/* 291:290 */     return this.parameterLValues;
/* 292:    */   }
/* 293:    */   
/* 294:    */   public JavaTypeInstance getReturnType()
/* 295:    */   {
/* 296:294 */     return this.result;
/* 297:    */   }
/* 298:    */   
/* 299:    */   public String getName()
/* 300:    */   {
/* 301:298 */     return this.name;
/* 302:    */   }
/* 303:    */   
/* 304:    */   public String getFixedName()
/* 305:    */   {
/* 306:303 */     return this.fixedName != null ? this.fixedName : this.name;
/* 307:    */   }
/* 308:    */   
/* 309:    */   public boolean hasNameBeenFixed()
/* 310:    */   {
/* 311:307 */     return this.fixedName != null;
/* 312:    */   }
/* 313:    */   
/* 314:    */   public void setFixedName(String name)
/* 315:    */   {
/* 316:311 */     this.fixedName = name;
/* 317:    */   }
/* 318:    */   
/* 319:    */   public boolean hasFormalTypeParameters()
/* 320:    */   {
/* 321:315 */     return (this.formalTypeParameters != null) && (!this.formalTypeParameters.isEmpty());
/* 322:    */   }
/* 323:    */   
/* 324:    */   public List<JavaTypeInstance> getExplicitGenericUsage(GenericTypeBinder binder)
/* 325:    */   {
/* 326:319 */     List<JavaTypeInstance> types = ListFactory.newList();
/* 327:320 */     for (FormalTypeParameter parameter : this.formalTypeParameters)
/* 328:    */     {
/* 329:321 */       JavaTypeInstance type = binder.getBindingFor(parameter);
/* 330:322 */       if (type == null) {
/* 331:322 */         return null;
/* 332:    */       }
/* 333:323 */       types.add(type);
/* 334:    */     }
/* 335:325 */     return types;
/* 336:    */   }
/* 337:    */   
/* 338:    */   public JavaTypeInstance getClassType()
/* 339:    */   {
/* 340:329 */     if (this.classFile == null) {
/* 341:329 */       return null;
/* 342:    */     }
/* 343:330 */     return this.classFile.getClassType();
/* 344:    */   }
/* 345:    */   
/* 346:    */   public JavaTypeInstance getReturnType(JavaTypeInstance thisTypeInstance, List<Expression> invokingArgs)
/* 347:    */   {
/* 348:334 */     if (this.classFile == null) {
/* 349:335 */       return this.result;
/* 350:    */     }
/* 351:338 */     if (this.result == null) {
/* 352:339 */       if ("<init>".equals(getName())) {
/* 353:340 */         this.result = this.classFile.getClassSignature().getThisGeneralTypeClass(this.classFile.getClassType(), this.classFile.getConstantPool());
/* 354:    */       } else {
/* 355:342 */         throw new IllegalStateException();
/* 356:    */       }
/* 357:    */     }
/* 358:345 */     if ((hasFormalTypeParameters()) || (this.classFile.hasFormalTypeParameters()))
/* 359:    */     {
/* 360:350 */       JavaGenericRefTypeInstance genericRefTypeInstance = null;
/* 361:351 */       if ((thisTypeInstance instanceof JavaGenericRefTypeInstance)) {
/* 362:352 */         genericRefTypeInstance = (JavaGenericRefTypeInstance)thisTypeInstance;
/* 363:    */       }
/* 364:361 */       JavaTypeInstance boundResult = getResultBoundAccordingly(this.result, genericRefTypeInstance, invokingArgs);
/* 365:    */       
/* 366:    */ 
/* 367:    */ 
/* 368:    */ 
/* 369:366 */       return boundResult;
/* 370:    */     }
/* 371:368 */     return this.result;
/* 372:    */   }
/* 373:    */   
/* 374:    */   public List<JavaTypeInstance> getArgs()
/* 375:    */   {
/* 376:373 */     return this.args;
/* 377:    */   }
/* 378:    */   
/* 379:    */   public int getVisibleArgCount()
/* 380:    */   {
/* 381:377 */     return this.args.size() - this.hidden.size();
/* 382:    */   }
/* 383:    */   
/* 384:    */   public boolean isInstanceMethod()
/* 385:    */   {
/* 386:381 */     return this.instanceMethod;
/* 387:    */   }
/* 388:    */   
/* 389:    */   public Expression getAppropriatelyCastedArgument(Expression expression, int argidx)
/* 390:    */   {
/* 391:385 */     JavaTypeInstance type = (JavaTypeInstance)this.args.get(argidx);
/* 392:386 */     if (type.isComplexType()) {
/* 393:387 */       return expression;
/* 394:    */     }
/* 395:389 */     RawJavaType expectedRawJavaType = type.getRawTypeOfSimpleType();
/* 396:390 */     RawJavaType providedRawJavaType = expression.getInferredJavaType().getRawType();
/* 397:392 */     if (expectedRawJavaType.compareAllPriorityTo(providedRawJavaType) == 0) {
/* 398:393 */       return expression;
/* 399:    */     }
/* 400:395 */     return new CastExpression(new InferredJavaType(expectedRawJavaType, InferredJavaType.Source.EXPRESSION, true), expression);
/* 401:    */   }
/* 402:    */   
/* 403:    */   public Dumper dumpAppropriatelyCastedArgumentString(Expression expression, int argidx, Dumper d)
/* 404:    */   {
/* 405:401 */     return expression.dump(d);
/* 406:    */   }
/* 407:    */   
/* 408:    */   public void tightenArgs(Expression object, List<Expression> expressions)
/* 409:    */   {
/* 410:421 */     if (expressions.size() != this.args.size()) {
/* 411:422 */       throw new ConfusedCFRException("expr arg size mismatch");
/* 412:    */     }
/* 413:424 */     if ((object != null) && (this.classFile != null) && (!"<init>".equals(this.name))) {
/* 414:425 */       object.getInferredJavaType().noteUseAs(this.classFile.getClassType());
/* 415:    */     }
/* 416:429 */     int length = this.args.size();
/* 417:430 */     for (int x = 0; x < length; x++)
/* 418:    */     {
/* 419:431 */       Expression expression = (Expression)expressions.get(x);
/* 420:432 */       JavaTypeInstance type = (JavaTypeInstance)this.args.get(x);
/* 421:433 */       expression.getInferredJavaType().useAsWithoutCasting(type);
/* 422:    */     }
/* 423:436 */     GenericTypeBinder genericTypeBinder = null;
/* 424:437 */     if ((object != null) && ((object.getInferredJavaType().getJavaTypeInstance() instanceof JavaGenericBaseInstance)))
/* 425:    */     {
/* 426:438 */       JavaTypeInstance objectType = object.getInferredJavaType().getJavaTypeInstance();
/* 427:439 */       List<JavaTypeInstance> invokingTypes = ListFactory.newList();
/* 428:440 */       for (Expression invokingArg : expressions) {
/* 429:441 */         invokingTypes.add(invokingArg.getInferredJavaType().getJavaTypeInstance());
/* 430:    */       }
/* 431:448 */       JavaGenericRefTypeInstance boundInstance = (objectType instanceof JavaGenericRefTypeInstance) ? (JavaGenericRefTypeInstance)objectType : null;
/* 432:449 */       if (this.classFile != null) {
/* 433:450 */         genericTypeBinder = GenericTypeBinder.bind(this.formalTypeParameters, this.classFile.getClassSignature(), this.args, boundInstance, invokingTypes);
/* 434:    */       }
/* 435:    */     }
/* 436:458 */     for (int x = 0; x < length; x++)
/* 437:    */     {
/* 438:459 */       Expression expression = (Expression)expressions.get(x);
/* 439:460 */       JavaTypeInstance type = (JavaTypeInstance)this.args.get(x);
/* 440:    */       
/* 441:    */ 
/* 442:    */ 
/* 443:    */ 
/* 444:465 */       JavaTypeInstance exprType = expression.getInferredJavaType().getJavaTypeInstance();
/* 445:466 */       if (!isGenericArg(exprType))
/* 446:    */       {
/* 447:469 */         if (genericTypeBinder != null) {
/* 448:470 */           type = genericTypeBinder.getBindingFor(type);
/* 449:    */         }
/* 450:472 */         if (!isGenericArg(type)) {
/* 451:475 */           expressions.set(x, new CastExpression(new InferredJavaType(type, InferredJavaType.Source.FUNCTION, true), expression));
/* 452:    */         }
/* 453:    */       }
/* 454:    */     }
/* 455:    */   }
/* 456:    */   
/* 457:    */   private static boolean isGenericArg(JavaTypeInstance arg)
/* 458:    */   {
/* 459:480 */     arg = arg.getArrayStrippedType();
/* 460:481 */     if ((arg instanceof JavaGenericBaseInstance)) {
/* 461:481 */       return true;
/* 462:    */     }
/* 463:482 */     return false;
/* 464:    */   }
/* 465:    */   
/* 466:    */   public String getComparableString()
/* 467:    */   {
/* 468:486 */     StringBuilder sb = new StringBuilder();
/* 469:487 */     sb.append(getName()).append('(');
/* 470:488 */     for (JavaTypeInstance arg : this.args) {
/* 471:489 */       sb.append(arg.getRawName()).append(" ");
/* 472:    */     }
/* 473:491 */     sb.append(')');
/* 474:492 */     return sb.toString();
/* 475:    */   }
/* 476:    */   
/* 477:    */   public String toString()
/* 478:    */   {
/* 479:497 */     return getComparableString();
/* 480:    */   }
/* 481:    */   
/* 482:    */   public boolean equalsGeneric(MethodPrototype other)
/* 483:    */   {
/* 484:501 */     GenericTypeBinder genericTypeBinder = GenericTypeBinder.createEmpty();
/* 485:    */     
/* 486:    */ 
/* 487:504 */     return equalsGeneric(other, genericTypeBinder);
/* 488:    */   }
/* 489:    */   
/* 490:    */   public boolean equalsGeneric(MethodPrototype other, GenericTypeBinder genericTypeBinder)
/* 491:    */   {
/* 492:508 */     List<FormalTypeParameter> otherTypeParameters = other.formalTypeParameters;
/* 493:509 */     List<JavaTypeInstance> otherArgs = other.args;
/* 494:511 */     if (otherArgs.size() != this.args.size()) {
/* 495:512 */       return false;
/* 496:    */     }
/* 497:515 */     JavaTypeInstance otherRes = other.getReturnType();
/* 498:516 */     JavaTypeInstance res = getReturnType();
/* 499:517 */     if ((res != null) && (otherRes != null))
/* 500:    */     {
/* 501:518 */       JavaTypeInstance deGenerifiedRes = res.getDeGenerifiedType();
/* 502:519 */       JavaTypeInstance deGenerifiedResOther = otherRes.getDeGenerifiedType();
/* 503:520 */       if (!deGenerifiedRes.equals(deGenerifiedResOther)) {
/* 504:521 */         if ((res instanceof JavaGenericBaseInstance))
/* 505:    */         {
/* 506:522 */           if (!((JavaGenericBaseInstance)res).tryFindBinding(otherRes, genericTypeBinder)) {
/* 507:523 */             return false;
/* 508:    */           }
/* 509:    */         }
/* 510:    */         else {
/* 511:526 */           return false;
/* 512:    */         }
/* 513:    */       }
/* 514:    */     }
/* 515:532 */     for (int x = 0; x < this.args.size(); x++)
/* 516:    */     {
/* 517:533 */       JavaTypeInstance lhs = (JavaTypeInstance)this.args.get(x);
/* 518:534 */       JavaTypeInstance rhs = (JavaTypeInstance)otherArgs.get(x);
/* 519:535 */       JavaTypeInstance deGenerifiedLhs = lhs.getDeGenerifiedType();
/* 520:536 */       JavaTypeInstance deGenerifiedRhs = rhs.getDeGenerifiedType();
/* 521:537 */       if (!deGenerifiedLhs.equals(deGenerifiedRhs)) {
/* 522:540 */         if ((lhs instanceof JavaGenericBaseInstance))
/* 523:    */         {
/* 524:541 */           if (!((JavaGenericBaseInstance)lhs).tryFindBinding(rhs, genericTypeBinder)) {
/* 525:542 */             return false;
/* 526:    */           }
/* 527:    */         }
/* 528:    */         else {
/* 529:545 */           return false;
/* 530:    */         }
/* 531:    */       }
/* 532:    */     }
/* 533:549 */     return true;
/* 534:    */   }
/* 535:    */   
/* 536:    */   public GenericTypeBinder getTypeBinderForTypes(List<JavaTypeInstance> invokingArgTypes)
/* 537:    */   {
/* 538:556 */     if (this.classFile == null) {
/* 539:557 */       return null;
/* 540:    */     }
/* 541:564 */     if (invokingArgTypes.size() != this.args.size()) {
/* 542:565 */       return null;
/* 543:    */     }
/* 544:568 */     GenericTypeBinder genericTypeBinder = GenericTypeBinder.bind(this.formalTypeParameters, this.classFile.getClassSignature(), this.args, null, invokingArgTypes);
/* 545:569 */     return genericTypeBinder;
/* 546:    */   }
/* 547:    */   
/* 548:    */   public GenericTypeBinder getTypeBinderFor(List<Expression> invokingArgs)
/* 549:    */   {
/* 550:574 */     List<JavaTypeInstance> invokingTypes = ListFactory.newList();
/* 551:575 */     for (Expression invokingArg : invokingArgs) {
/* 552:576 */       invokingTypes.add(invokingArg.getInferredJavaType().getJavaTypeInstance());
/* 553:    */     }
/* 554:578 */     return getTypeBinderForTypes(invokingTypes);
/* 555:    */   }
/* 556:    */   
/* 557:    */   private JavaTypeInstance getResultBoundAccordingly(JavaTypeInstance result, JavaGenericRefTypeInstance boundInstance, List<Expression> invokingArgs)
/* 558:    */   {
/* 559:582 */     if ((result instanceof JavaArrayTypeInstance))
/* 560:    */     {
/* 561:583 */       JavaArrayTypeInstance arrayTypeInstance = (JavaArrayTypeInstance)result;
/* 562:584 */       JavaTypeInstance stripped = result.getArrayStrippedType();
/* 563:585 */       JavaTypeInstance tmp = getResultBoundAccordinglyInner(stripped, boundInstance, invokingArgs);
/* 564:586 */       if (tmp == stripped) {
/* 565:586 */         return result;
/* 566:    */       }
/* 567:587 */       return new JavaArrayTypeInstance(arrayTypeInstance.getNumArrayDimensions(), tmp);
/* 568:    */     }
/* 569:589 */     return getResultBoundAccordinglyInner(result, boundInstance, invokingArgs);
/* 570:    */   }
/* 571:    */   
/* 572:    */   private JavaTypeInstance getResultBoundAccordinglyInner(JavaTypeInstance result, JavaGenericRefTypeInstance boundInstance, List<Expression> invokingArgs)
/* 573:    */   {
/* 574:594 */     if (!(result instanceof JavaGenericBaseInstance)) {
/* 575:596 */       return result;
/* 576:    */     }
/* 577:599 */     List<JavaTypeInstance> invokingTypes = ListFactory.newList();
/* 578:600 */     for (Expression invokingArg : invokingArgs) {
/* 579:601 */       invokingTypes.add(invokingArg.getInferredJavaType().getJavaTypeInstance());
/* 580:    */     }
/* 581:608 */     GenericTypeBinder genericTypeBinder = GenericTypeBinder.bind(this.formalTypeParameters, this.classFile.getClassSignature(), this.args, boundInstance, invokingTypes);
/* 582:609 */     if (genericTypeBinder == null) {
/* 583:610 */       return result;
/* 584:    */     }
/* 585:613 */     JavaGenericBaseInstance genericResult = (JavaGenericBaseInstance)result;
/* 586:614 */     JavaTypeInstance boundResultInstance = genericResult.getBoundInstance(genericTypeBinder);
/* 587:618 */     if ((boundResultInstance instanceof JavaWildcardTypeInstance)) {
/* 588:619 */       boundResultInstance = ((JavaWildcardTypeInstance)boundResultInstance).getUnderlyingType();
/* 589:    */     }
/* 590:621 */     return boundResultInstance;
/* 591:    */   }
/* 592:    */   
/* 593:    */   public boolean isVarArgs()
/* 594:    */   {
/* 595:626 */     return this.varargs;
/* 596:    */   }
/* 597:    */   
/* 598:    */   public boolean equalsMatch(MethodPrototype other)
/* 599:    */   {
/* 600:634 */     if (other == this) {
/* 601:634 */       return true;
/* 602:    */     }
/* 603:635 */     if (other == null) {
/* 604:635 */       return false;
/* 605:    */     }
/* 606:636 */     if (!this.name.equals(other.name)) {
/* 607:636 */       return false;
/* 608:    */     }
/* 609:637 */     List<JavaTypeInstance> otherArgs = other.getArgs();
/* 610:638 */     if (!this.args.equals(otherArgs)) {
/* 611:638 */       return false;
/* 612:    */     }
/* 613:639 */     if ((this.result != null) && (other.result != null)) {
/* 614:641 */       if (!this.result.equals(other.result))
/* 615:    */       {
/* 616:642 */         BindingSuperContainer otherBindingSupers = other.result.getBindingSupers();
/* 617:643 */         if (otherBindingSupers == null) {
/* 618:643 */           return false;
/* 619:    */         }
/* 620:644 */         if (otherBindingSupers.containsBase(this.result)) {
/* 621:644 */           return true;
/* 622:    */         }
/* 623:645 */         return false;
/* 624:    */       }
/* 625:    */     }
/* 626:648 */     return true;
/* 627:    */   }
/* 628:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype
 * JD-Core Version:    0.7.0.1
 */