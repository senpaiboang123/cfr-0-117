/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.types;
/*  2:   */ 
/*  3:   */ public enum DynamicInvokeType
/*  4:   */ {
/*  5: 4 */   UNKNOWN("?"),  BOOTSTRAP("bootstrap"),  METAFACTORY_1("metaFactory"),  METAFACTORY_2("metafactory"),  ALTMETAFACTORY_1("altMetaFactory"),  ALTMETAFACTORY_2("altMetafactory");
/*  6:   */   
/*  7:   */   private final String constName;
/*  8:   */   
/*  9:   */   private DynamicInvokeType(String constName)
/* 10:   */   {
/* 11:14 */     this.constName = constName;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getConstName()
/* 15:   */   {
/* 16:18 */     return this.constName;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public static DynamicInvokeType lookup(String name)
/* 20:   */   {
/* 21:22 */     if (name.equals(METAFACTORY_1.constName)) {
/* 22:22 */       return METAFACTORY_1;
/* 23:   */     }
/* 24:23 */     if (name.equals(METAFACTORY_2.constName)) {
/* 25:23 */       return METAFACTORY_2;
/* 26:   */     }
/* 27:24 */     if (name.equals(ALTMETAFACTORY_1.constName)) {
/* 28:24 */       return ALTMETAFACTORY_1;
/* 29:   */     }
/* 30:25 */     if (name.equals(ALTMETAFACTORY_2.constName)) {
/* 31:25 */       return ALTMETAFACTORY_2;
/* 32:   */     }
/* 33:26 */     if (name.equals(BOOTSTRAP.constName)) {
/* 34:26 */       return BOOTSTRAP;
/* 35:   */     }
/* 36:27 */     return UNKNOWN;
/* 37:   */   }
/* 38:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.DynamicInvokeType
 * JD-Core Version:    0.7.0.1
 */