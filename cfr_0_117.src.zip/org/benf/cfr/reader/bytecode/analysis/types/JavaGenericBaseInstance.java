package org.benf.cfr.reader.bytecode.analysis.types;

import java.util.List;
import org.benf.cfr.reader.entities.constantpool.ConstantPool;

public abstract interface JavaGenericBaseInstance
  extends JavaTypeInstance
{
  public abstract JavaTypeInstance getBoundInstance(GenericTypeBinder paramGenericTypeBinder);
  
  public abstract boolean tryFindBinding(JavaTypeInstance paramJavaTypeInstance, GenericTypeBinder paramGenericTypeBinder);
  
  public abstract boolean hasUnbound();
  
  public abstract boolean hasL01Wildcard();
  
  public abstract JavaTypeInstance getWithoutL01Wildcard();
  
  public abstract boolean hasForeignUnbound(ConstantPool paramConstantPool);
  
  public abstract List<JavaTypeInstance> getGenericTypes();
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.JavaGenericBaseInstance
 * JD-Core Version:    0.7.0.1
 */