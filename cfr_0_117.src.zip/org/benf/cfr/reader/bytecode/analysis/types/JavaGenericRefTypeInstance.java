/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.types;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.ComparableUnderEC;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.DefaultEquivalenceConstraint;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.types.annotated.JavaAnnotatedTypeInstance;
/*   8:    */ import org.benf.cfr.reader.entities.annotations.AnnotationTableTypeEntry;
/*   9:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  10:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  11:    */ import org.benf.cfr.reader.state.TypeUsageInformation;
/*  12:    */ import org.benf.cfr.reader.util.DecompilerComments;
/*  13:    */ import org.benf.cfr.reader.util.ListFactory;
/*  14:    */ import org.benf.cfr.reader.util.StringUtils;
/*  15:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  16:    */ import org.benf.cfr.reader.util.output.ToStringDumper;
/*  17:    */ 
/*  18:    */ public class JavaGenericRefTypeInstance
/*  19:    */   implements JavaGenericBaseInstance, ComparableUnderEC
/*  20:    */ {
/*  21: 21 */   private static final WildcardConstraint WILDCARD_CONSTRAINT = new WildcardConstraint();
/*  22:    */   private final JavaRefTypeInstance typeInstance;
/*  23:    */   private final List<JavaTypeInstance> genericTypes;
/*  24:    */   private final boolean hasUnbound;
/*  25:    */   
/*  26:    */   public JavaGenericRefTypeInstance(JavaTypeInstance typeInstance, List<JavaTypeInstance> genericTypes)
/*  27:    */   {
/*  28: 28 */     if (!(typeInstance instanceof JavaRefTypeInstance)) {
/*  29: 29 */       throw new IllegalStateException("Generic sitting on top of non reftype");
/*  30:    */     }
/*  31: 31 */     this.typeInstance = ((JavaRefTypeInstance)typeInstance);
/*  32: 32 */     this.genericTypes = genericTypes;
/*  33: 33 */     boolean unbound = false;
/*  34: 34 */     for (JavaTypeInstance type : genericTypes) {
/*  35: 35 */       if (((type instanceof JavaGenericBaseInstance)) && 
/*  36: 36 */         (((JavaGenericBaseInstance)type).hasUnbound()))
/*  37:    */       {
/*  38: 37 */         unbound = true;
/*  39: 38 */         break;
/*  40:    */       }
/*  41:    */     }
/*  42: 42 */     this.hasUnbound = unbound;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void collectInto(TypeUsageCollector typeUsageCollector)
/*  46:    */   {
/*  47: 47 */     typeUsageCollector.collectRefType(this.typeInstance);
/*  48: 48 */     for (JavaTypeInstance genericType : this.genericTypes) {
/*  49: 49 */       typeUsageCollector.collect(genericType);
/*  50:    */     }
/*  51:    */   }
/*  52:    */   
/*  53:    */   public JavaAnnotatedTypeInstance getAnnotatedInstance()
/*  54:    */   {
/*  55: 55 */     JavaAnnotatedTypeInstance typeAnnotated = this.typeInstance.getAnnotatedInstance();
/*  56: 56 */     List<JavaAnnotatedTypeInstance> genericTypeAnnotated = ListFactory.newList();
/*  57: 57 */     for (JavaTypeInstance genericType : this.genericTypes) {
/*  58: 58 */       genericTypeAnnotated.add(genericType.getAnnotatedInstance());
/*  59:    */     }
/*  60: 60 */     return new Annotated(typeAnnotated, genericTypeAnnotated, null);
/*  61:    */   }
/*  62:    */   
/*  63:    */   private class Annotated
/*  64:    */     implements JavaAnnotatedTypeInstance
/*  65:    */   {
/*  66:    */     JavaAnnotatedTypeInstance typeAnnotated;
/*  67:    */     List<JavaAnnotatedTypeInstance> genericTypeAnnotated;
/*  68:    */     
/*  69:    */     private Annotated(List<JavaAnnotatedTypeInstance> typeAnnotated)
/*  70:    */     {
/*  71: 68 */       this.typeAnnotated = typeAnnotated;
/*  72: 69 */       this.genericTypeAnnotated = genericTypeAnnotated;
/*  73:    */     }
/*  74:    */     
/*  75:    */     public JavaAnnotatedTypeIterator pathIterator()
/*  76:    */     {
/*  77: 74 */       return new Iterator(null);
/*  78:    */     }
/*  79:    */     
/*  80:    */     public Dumper dump(Dumper d)
/*  81:    */     {
/*  82: 79 */       this.typeAnnotated.dump(d).print('<');
/*  83: 80 */       boolean first = true;
/*  84: 81 */       for (JavaAnnotatedTypeInstance type : this.genericTypeAnnotated)
/*  85:    */       {
/*  86: 82 */         first = StringUtils.comma(first, d);
/*  87: 83 */         type.dump(d);
/*  88:    */       }
/*  89: 85 */       d.print('>');
/*  90: 86 */       return d;
/*  91:    */     }
/*  92:    */     
/*  93:    */     private class Iterator
/*  94:    */       extends JavaAnnotatedTypeIterator.BaseAnnotatedTypeIterator
/*  95:    */     {
/*  96:    */       private Iterator() {}
/*  97:    */       
/*  98:    */       public JavaAnnotatedTypeIterator moveArray(DecompilerComments comments)
/*  99:    */       {
/* 100: 93 */         return JavaGenericRefTypeInstance.Annotated.this.typeAnnotated.pathIterator().moveArray(comments);
/* 101:    */       }
/* 102:    */       
/* 103:    */       public JavaAnnotatedTypeIterator moveBound(DecompilerComments comments)
/* 104:    */       {
/* 105: 98 */         return JavaGenericRefTypeInstance.Annotated.this.typeAnnotated.pathIterator().moveBound(comments);
/* 106:    */       }
/* 107:    */       
/* 108:    */       public JavaAnnotatedTypeIterator moveNested(DecompilerComments comments)
/* 109:    */       {
/* 110:103 */         return JavaGenericRefTypeInstance.Annotated.this.typeAnnotated.pathIterator().moveNested(comments);
/* 111:    */       }
/* 112:    */       
/* 113:    */       public JavaAnnotatedTypeIterator moveParameterized(int index, DecompilerComments comments)
/* 114:    */       {
/* 115:108 */         return ((JavaAnnotatedTypeInstance)JavaGenericRefTypeInstance.Annotated.this.genericTypeAnnotated.get(index)).pathIterator();
/* 116:    */       }
/* 117:    */       
/* 118:    */       public void apply(AnnotationTableTypeEntry entry)
/* 119:    */       {
/* 120:113 */         JavaGenericRefTypeInstance.Annotated.this.typeAnnotated.pathIterator().apply(entry);
/* 121:    */       }
/* 122:    */     }
/* 123:    */   }
/* 124:    */   
/* 125:    */   public boolean hasUnbound()
/* 126:    */   {
/* 127:120 */     return this.hasUnbound;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public boolean hasForeignUnbound(ConstantPool cp)
/* 131:    */   {
/* 132:125 */     if (!this.hasUnbound) {
/* 133:125 */       return false;
/* 134:    */     }
/* 135:126 */     for (JavaTypeInstance type : this.genericTypes) {
/* 136:127 */       if (((type instanceof JavaGenericBaseInstance)) && 
/* 137:128 */         (((JavaGenericBaseInstance)type).hasForeignUnbound(cp))) {
/* 138:128 */         return true;
/* 139:    */       }
/* 140:    */     }
/* 141:131 */     return false;
/* 142:    */   }
/* 143:    */   
/* 144:    */   public boolean isObject()
/* 145:    */   {
/* 146:136 */     return true;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public boolean hasL01Wildcard()
/* 150:    */   {
/* 151:141 */     for (JavaTypeInstance type : this.genericTypes) {
/* 152:142 */       if ((type instanceof JavaWildcardTypeInstance)) {
/* 153:142 */         return true;
/* 154:    */       }
/* 155:    */     }
/* 156:144 */     return false;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public JavaTypeInstance getWithoutL01Wildcard()
/* 160:    */   {
/* 161:149 */     List<JavaTypeInstance> unwildCarded = ListFactory.newList();
/* 162:150 */     for (JavaTypeInstance type : this.genericTypes)
/* 163:    */     {
/* 164:151 */       if ((type instanceof JavaWildcardTypeInstance)) {
/* 165:151 */         type = ((JavaWildcardTypeInstance)type).getWithoutL01Wildcard();
/* 166:    */       }
/* 167:152 */       unwildCarded.add(type);
/* 168:    */     }
/* 169:154 */     return new JavaGenericRefTypeInstance(this.typeInstance, unwildCarded);
/* 170:    */   }
/* 171:    */   
/* 172:    */   public JavaGenericRefTypeInstance getBoundInstance(GenericTypeBinder genericTypeBinder)
/* 173:    */   {
/* 174:159 */     if (genericTypeBinder == null) {
/* 175:160 */       return this;
/* 176:    */     }
/* 177:162 */     List<JavaTypeInstance> res = ListFactory.newList();
/* 178:163 */     for (JavaTypeInstance genericType : this.genericTypes) {
/* 179:164 */       res.add(genericTypeBinder.getBindingFor(genericType));
/* 180:    */     }
/* 181:166 */     return new JavaGenericRefTypeInstance(this.typeInstance, res);
/* 182:    */   }
/* 183:    */   
/* 184:    */   public boolean tryFindBinding(JavaTypeInstance other, GenericTypeBinder target)
/* 185:    */   {
/* 186:171 */     boolean res = false;
/* 187:172 */     if ((other instanceof JavaGenericRefTypeInstance))
/* 188:    */     {
/* 189:174 */       JavaGenericRefTypeInstance otherJavaGenericRef = (JavaGenericRefTypeInstance)other;
/* 190:175 */       if (this.genericTypes.size() == otherJavaGenericRef.genericTypes.size()) {
/* 191:176 */         for (int x = 0; x < this.genericTypes.size(); x++)
/* 192:    */         {
/* 193:177 */           JavaTypeInstance genericType = (JavaTypeInstance)this.genericTypes.get(x);
/* 194:178 */           if ((genericType instanceof JavaGenericBaseInstance))
/* 195:    */           {
/* 196:179 */             JavaGenericBaseInstance genericBaseInstance = (JavaGenericBaseInstance)genericType;
/* 197:180 */             res |= genericBaseInstance.tryFindBinding((JavaTypeInstance)otherJavaGenericRef.genericTypes.get(x), target);
/* 198:    */           }
/* 199:    */         }
/* 200:    */       }
/* 201:    */     }
/* 202:185 */     return res;
/* 203:    */   }
/* 204:    */   
/* 205:    */   public StackType getStackType()
/* 206:    */   {
/* 207:190 */     return StackType.REF;
/* 208:    */   }
/* 209:    */   
/* 210:    */   public void dumpInto(Dumper d, TypeUsageInformation typeUsageInformation)
/* 211:    */   {
/* 212:195 */     d.dump(this.typeInstance).print('<');
/* 213:196 */     boolean first = true;
/* 214:197 */     for (JavaTypeInstance type : this.genericTypes)
/* 215:    */     {
/* 216:198 */       first = StringUtils.comma(first, d);
/* 217:199 */       d.dump(type);
/* 218:    */     }
/* 219:201 */     d.print('>');
/* 220:    */   }
/* 221:    */   
/* 222:    */   public String toString()
/* 223:    */   {
/* 224:206 */     return new ToStringDumper().dump(this).toString();
/* 225:    */   }
/* 226:    */   
/* 227:    */   public JavaTypeInstance getArrayStrippedType()
/* 228:    */   {
/* 229:211 */     return this;
/* 230:    */   }
/* 231:    */   
/* 232:    */   public List<JavaTypeInstance> getGenericTypes()
/* 233:    */   {
/* 234:216 */     return this.genericTypes;
/* 235:    */   }
/* 236:    */   
/* 237:    */   public JavaRefTypeInstance getDeGenerifiedType()
/* 238:    */   {
/* 239:221 */     return this.typeInstance;
/* 240:    */   }
/* 241:    */   
/* 242:    */   public int getNumArrayDimensions()
/* 243:    */   {
/* 244:226 */     return 0;
/* 245:    */   }
/* 246:    */   
/* 247:    */   public int hashCode()
/* 248:    */   {
/* 249:231 */     int hash = 31 + this.typeInstance.hashCode();
/* 250:232 */     return hash;
/* 251:    */   }
/* 252:    */   
/* 253:    */   public String getRawName()
/* 254:    */   {
/* 255:237 */     return new ToStringDumper().dump(this).toString();
/* 256:    */   }
/* 257:    */   
/* 258:    */   public InnerClassInfo getInnerClassHereInfo()
/* 259:    */   {
/* 260:242 */     return this.typeInstance.getInnerClassHereInfo();
/* 261:    */   }
/* 262:    */   
/* 263:    */   public JavaTypeInstance getTypeInstance()
/* 264:    */   {
/* 265:246 */     return this.typeInstance;
/* 266:    */   }
/* 267:    */   
/* 268:    */   public BindingSuperContainer getBindingSupers()
/* 269:    */   {
/* 270:251 */     return this.typeInstance.getBindingSupers();
/* 271:    */   }
/* 272:    */   
/* 273:    */   public boolean equals(Object o)
/* 274:    */   {
/* 275:257 */     return equivalentUnder(o, DefaultEquivalenceConstraint.INSTANCE);
/* 276:    */   }
/* 277:    */   
/* 278:    */   public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 279:    */   {
/* 280:262 */     if (o == this) {
/* 281:262 */       return true;
/* 282:    */     }
/* 283:263 */     if (!(o instanceof JavaGenericRefTypeInstance)) {
/* 284:263 */       return false;
/* 285:    */     }
/* 286:264 */     JavaGenericRefTypeInstance other = (JavaGenericRefTypeInstance)o;
/* 287:265 */     if (!constraint.equivalent(this.typeInstance, other.typeInstance)) {
/* 288:265 */       return false;
/* 289:    */     }
/* 290:266 */     if (!constraint.equivalent(this.genericTypes, other.genericTypes)) {
/* 291:266 */       return false;
/* 292:    */     }
/* 293:267 */     return true;
/* 294:    */   }
/* 295:    */   
/* 296:    */   public boolean isComplexType()
/* 297:    */   {
/* 298:273 */     return true;
/* 299:    */   }
/* 300:    */   
/* 301:    */   public boolean isUsableType()
/* 302:    */   {
/* 303:278 */     return true;
/* 304:    */   }
/* 305:    */   
/* 306:    */   public JavaTypeInstance removeAnArrayIndirection()
/* 307:    */   {
/* 308:283 */     return this;
/* 309:    */   }
/* 310:    */   
/* 311:    */   public RawJavaType getRawTypeOfSimpleType()
/* 312:    */   {
/* 313:288 */     return RawJavaType.REF;
/* 314:    */   }
/* 315:    */   
/* 316:    */   public boolean implicitlyCastsTo(JavaTypeInstance other, GenericTypeBinder gtb)
/* 317:    */   {
/* 318:293 */     if (other == TypeConstants.OBJECT) {
/* 319:293 */       return true;
/* 320:    */     }
/* 321:294 */     if (equivalentUnder(other, WILDCARD_CONSTRAINT)) {
/* 322:294 */       return true;
/* 323:    */     }
/* 324:295 */     BindingSuperContainer bindingSuperContainer = getBindingSupers();
/* 325:296 */     if (bindingSuperContainer == null) {
/* 326:296 */       return false;
/* 327:    */     }
/* 328:297 */     JavaTypeInstance degenerifiedOther = other.getDeGenerifiedType();
/* 329:298 */     JavaTypeInstance degenerifiedThis = getDeGenerifiedType();
/* 330:299 */     if (degenerifiedThis.equals(other)) {
/* 331:299 */       return true;
/* 332:    */     }
/* 333:301 */     if (!bindingSuperContainer.containsBase(degenerifiedOther)) {
/* 334:301 */       return false;
/* 335:    */     }
/* 336:303 */     JavaTypeInstance boundBase = bindingSuperContainer.getBoundSuperForBase(degenerifiedOther);
/* 337:304 */     if (other.equals(boundBase)) {
/* 338:304 */       return true;
/* 339:    */     }
/* 340:305 */     if (degenerifiedOther.equals(other)) {
/* 341:305 */       return true;
/* 342:    */     }
/* 343:307 */     if (gtb != null)
/* 344:    */     {
/* 345:308 */       JavaTypeInstance reboundBase = gtb.getBindingFor(boundBase);
/* 346:309 */       if (other.equals(reboundBase)) {
/* 347:309 */         return true;
/* 348:    */       }
/* 349:312 */       JavaTypeInstance reboundOther = gtb.getBindingFor(other);
/* 350:313 */       if (equivalentUnder(reboundOther, WILDCARD_CONSTRAINT)) {
/* 351:313 */         return true;
/* 352:    */       }
/* 353:    */     }
/* 354:315 */     return false;
/* 355:    */   }
/* 356:    */   
/* 357:    */   public boolean impreciseCanCastTo(JavaTypeInstance other, GenericTypeBinder gtb)
/* 358:    */   {
/* 359:320 */     return true;
/* 360:    */   }
/* 361:    */   
/* 362:    */   public boolean correctCanCastTo(JavaTypeInstance other, GenericTypeBinder gtb)
/* 363:    */   {
/* 364:325 */     return impreciseCanCastTo(other, gtb);
/* 365:    */   }
/* 366:    */   
/* 367:    */   public String suggestVarName()
/* 368:    */   {
/* 369:330 */     return this.typeInstance.suggestVarName();
/* 370:    */   }
/* 371:    */   
/* 372:    */   public static class WildcardConstraint
/* 373:    */     extends DefaultEquivalenceConstraint
/* 374:    */   {
/* 375:    */     public boolean equivalent(Object o1, Object o2)
/* 376:    */     {
/* 377:339 */       if (((o2 instanceof JavaGenericPlaceholderTypeInstance)) && 
/* 378:340 */         (((JavaGenericPlaceholderTypeInstance)o2).getRawName().equals("?"))) {
/* 379:341 */         return true;
/* 380:    */       }
/* 381:343 */       return super.equivalent(o1, o2);
/* 382:    */     }
/* 383:    */   }
/* 384:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.types.JavaGenericRefTypeInstance
 * JD-Core Version:    0.7.0.1
 */