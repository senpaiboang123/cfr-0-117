/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.Block;
/*  7:   */ 
/*  8:   */ public class BeginBlock
/*  9:   */   extends AbstractPlaceholder
/* 10:   */ {
/* 11:   */   private final Block block;
/* 12:   */   
/* 13:   */   public BeginBlock(Block block)
/* 14:   */   {
/* 15:12 */     this.block = block;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 19:   */   {
/* 20:17 */     StructuredStatement current = (StructuredStatement)matchIterator.getCurrent();
/* 21:18 */     if ((current instanceof BeginBlock))
/* 22:   */     {
/* 23:19 */       BeginBlock other = (BeginBlock)current;
/* 24:20 */       if ((this.block == null) || (this.block.equals(other.block)))
/* 25:   */       {
/* 26:21 */         matchIterator.advance();
/* 27:22 */         return true;
/* 28:   */       }
/* 29:   */     }
/* 30:25 */     return false;
/* 31:   */   }
/* 32:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.BeginBlock
 * JD-Core Version:    0.7.0.1
 */