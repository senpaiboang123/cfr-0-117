/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  8:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  9:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 10:   */ 
/* 11:   */ public class UnstructuredAnonBreakTarget
/* 12:   */   extends AbstractUnStructuredStatement
/* 13:   */ {
/* 14:   */   private BlockIdentifier blockIdentifier;
/* 15:   */   
/* 16:   */   public UnstructuredAnonBreakTarget(BlockIdentifier blockIdentifier)
/* 17:   */   {
/* 18:16 */     this.blockIdentifier = blockIdentifier;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void collectTypeUsages(TypeUsageCollector collector) {}
/* 22:   */   
/* 23:   */   public Dumper dump(Dumper dumper)
/* 24:   */   {
/* 25:25 */     return dumper;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer) {}
/* 29:   */   
/* 30:   */   public void linearizeInto(List<StructuredStatement> out) {}
/* 31:   */   
/* 32:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter) {}
/* 33:   */   
/* 34:   */   public BlockIdentifier getBlockIdentifier()
/* 35:   */   {
/* 36:42 */     return this.blockIdentifier;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public boolean isEffectivelyNOP()
/* 40:   */   {
/* 41:47 */     return true;
/* 42:   */   }
/* 43:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredAnonBreakTarget
 * JD-Core Version:    0.7.0.1
 */