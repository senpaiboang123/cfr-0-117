/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*   2:    */ 
/*   3:    */ import java.util.LinkedList;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Vector;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.CanRemovePointlessBlock;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.ElseBlock;
/*  18:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  19:    */ import org.benf.cfr.reader.util.ListFactory;
/*  20:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  21:    */ 
/*  22:    */ public class StructuredIf
/*  23:    */   extends AbstractStructuredStatement
/*  24:    */   implements CanRemovePointlessBlock
/*  25:    */ {
/*  26:    */   ConditionalExpression conditionalExpression;
/*  27:    */   Op04StructuredStatement ifTaken;
/*  28:    */   Op04StructuredStatement elseBlock;
/*  29:    */   
/*  30:    */   public StructuredIf(ConditionalExpression conditionalExpression, Op04StructuredStatement ifTaken)
/*  31:    */   {
/*  32: 30 */     this(conditionalExpression, ifTaken, null);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public StructuredIf(ConditionalExpression conditionalExpression, Op04StructuredStatement ifTaken, Op04StructuredStatement elseBlock)
/*  36:    */   {
/*  37: 34 */     this.conditionalExpression = conditionalExpression;
/*  38: 35 */     this.ifTaken = ifTaken;
/*  39: 36 */     this.elseBlock = elseBlock;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  43:    */   {
/*  44: 42 */     this.conditionalExpression.collectTypeUsages(collector);
/*  45: 43 */     collector.collectFrom(this.ifTaken);
/*  46: 44 */     collector.collectFrom(this.elseBlock);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public Dumper dump(Dumper dumper)
/*  50:    */   {
/*  51: 49 */     dumper.print("if (").dump(this.conditionalExpression).print(") ");
/*  52: 50 */     this.ifTaken.dump(dumper);
/*  53: 51 */     if (this.elseBlock != null)
/*  54:    */     {
/*  55: 52 */       dumper.removePendingCarriageReturn();
/*  56: 53 */       dumper.print(" else ");
/*  57: 54 */       this.elseBlock.dump(dumper);
/*  58:    */     }
/*  59: 56 */     return dumper;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public boolean hasElseBlock()
/*  63:    */   {
/*  64: 60 */     return this.elseBlock != null;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public ConditionalExpression getConditionalExpression()
/*  68:    */   {
/*  69: 64 */     return this.conditionalExpression;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public Op04StructuredStatement getIfTaken()
/*  73:    */   {
/*  74: 68 */     return this.ifTaken;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public StructuredStatement informBlockHeirachy(Vector<BlockIdentifier> blockIdentifiers)
/*  78:    */   {
/*  79: 73 */     this.ifTaken.informBlockMembership(blockIdentifiers);
/*  80: 74 */     if (this.elseBlock != null) {
/*  81: 74 */       this.elseBlock.informBlockMembership(blockIdentifiers);
/*  82:    */     }
/*  83: 75 */     return null;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope)
/*  87:    */   {
/*  88: 80 */     scope.add(this);
/*  89:    */     try
/*  90:    */     {
/*  91: 82 */       this.ifTaken.transform(transformer, scope);
/*  92: 83 */       if (this.elseBlock != null) {
/*  93: 83 */         this.elseBlock.transform(transformer, scope);
/*  94:    */       }
/*  95:    */     }
/*  96:    */     finally
/*  97:    */     {
/*  98: 85 */       scope.remove(this);
/*  99:    */     }
/* 100:    */   }
/* 101:    */   
/* 102:    */   public void linearizeInto(List<StructuredStatement> out)
/* 103:    */   {
/* 104: 91 */     out.add(this);
/* 105: 92 */     this.ifTaken.linearizeStatementsInto(out);
/* 106: 93 */     if (this.elseBlock != null)
/* 107:    */     {
/* 108: 94 */       out.add(new ElseBlock());
/* 109: 95 */       this.elseBlock.linearizeStatementsInto(out);
/* 110:    */     }
/* 111:    */   }
/* 112:    */   
/* 113:    */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer)
/* 114:    */   {
/* 115:101 */     this.conditionalExpression.collectUsedLValues(scopeDiscoverer);
/* 116:102 */     this.ifTaken.traceLocalVariableScope(scopeDiscoverer);
/* 117:103 */     if (this.elseBlock != null) {
/* 118:104 */       this.elseBlock.traceLocalVariableScope(scopeDiscoverer);
/* 119:    */     }
/* 120:    */   }
/* 121:    */   
/* 122:    */   public boolean isRecursivelyStructured()
/* 123:    */   {
/* 124:110 */     if (!this.ifTaken.isFullyStructured()) {
/* 125:110 */       return false;
/* 126:    */     }
/* 127:111 */     if ((this.elseBlock != null) && (!this.elseBlock.isFullyStructured())) {
/* 128:111 */       return false;
/* 129:    */     }
/* 130:112 */     return true;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public boolean fallsNopToNext()
/* 134:    */   {
/* 135:117 */     return true;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 139:    */   {
/* 140:122 */     StructuredStatement o = (StructuredStatement)matchIterator.getCurrent();
/* 141:123 */     if (!(o instanceof StructuredIf)) {
/* 142:123 */       return false;
/* 143:    */     }
/* 144:124 */     StructuredIf other = (StructuredIf)o;
/* 145:125 */     if (!this.conditionalExpression.equals(other.conditionalExpression)) {
/* 146:125 */       return false;
/* 147:    */     }
/* 148:127 */     matchIterator.advance();
/* 149:128 */     return true;
/* 150:    */   }
/* 151:    */   
/* 152:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter)
/* 153:    */   {
/* 154:133 */     this.conditionalExpression = expressionRewriter.rewriteExpression(this.conditionalExpression, null, getContainer(), null);
/* 155:    */   }
/* 156:    */   
/* 157:    */   public StructuredStatement convertToAssertion(StructuredAssert structuredAssert)
/* 158:    */   {
/* 159:137 */     if (this.elseBlock == null) {
/* 160:138 */       return structuredAssert;
/* 161:    */     }
/* 162:143 */     LinkedList<Op04StructuredStatement> list = ListFactory.newLinkedList();
/* 163:144 */     list.add(new Op04StructuredStatement(structuredAssert));
/* 164:145 */     list.add(this.elseBlock);
/* 165:146 */     return new Block(list, false);
/* 166:    */   }
/* 167:    */   
/* 168:    */   public void removePointlessBlocks(StructuredScope scope)
/* 169:    */   {
/* 170:151 */     if ((this.elseBlock != null) && (this.elseBlock.getStatement().isEffectivelyNOP())) {
/* 171:152 */       this.elseBlock = null;
/* 172:    */     }
/* 173:    */   }
/* 174:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredIf
 * JD-Core Version:    0.7.0.1
 */