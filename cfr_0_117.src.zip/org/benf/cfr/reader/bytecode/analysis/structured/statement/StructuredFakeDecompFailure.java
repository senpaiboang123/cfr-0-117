/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  4:   */ 
/*  5:   */ public class StructuredFakeDecompFailure
/*  6:   */   extends StructuredComment
/*  7:   */ {
/*  8:   */   private Exception e;
/*  9:   */   
/* 10:   */   public StructuredFakeDecompFailure(Exception e)
/* 11:   */   {
/* 12: 9 */     super("");
/* 13:10 */     this.e = e;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public Dumper dump(Dumper dumper)
/* 17:   */   {
/* 18:15 */     dumper.print("{");
/* 19:16 */     dumper.indent(1);
/* 20:17 */     dumper.newln();
/* 21:18 */     dumper.print("// This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.").newln();
/* 22:19 */     dumper.print("// ").print(this.e.toString()).newln();
/* 23:20 */     for (StackTraceElement ste : this.e.getStackTrace()) {
/* 24:21 */       dumper.print("// ").print(ste.toString()).newln();
/* 25:   */     }
/* 26:23 */     dumper.print("throw new IllegalStateException(\"Decompilation failed\")").endCodeln();
/* 27:24 */     dumper.indent(-1);
/* 28:25 */     dumper.print("}");
/* 29:26 */     dumper.enqueuePendingCarriageReturn();
/* 30:   */     
/* 31:28 */     return dumper;
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredFakeDecompFailure
 * JD-Core Version:    0.7.0.1
 */