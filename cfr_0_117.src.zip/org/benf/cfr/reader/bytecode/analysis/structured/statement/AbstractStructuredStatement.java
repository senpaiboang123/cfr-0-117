/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Vector;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  14:    */ import org.benf.cfr.reader.util.Predicate;
/*  15:    */ import org.benf.cfr.reader.util.output.ToStringDumper;
/*  16:    */ 
/*  17:    */ public abstract class AbstractStructuredStatement
/*  18:    */   implements StructuredStatement
/*  19:    */ {
/*  20:    */   Op04StructuredStatement container;
/*  21:    */   
/*  22:    */   public Op04StructuredStatement getContainer()
/*  23:    */   {
/*  24: 23 */     return this.container;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public void setContainer(Op04StructuredStatement container)
/*  28:    */   {
/*  29: 28 */     this.container = container;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void transformStructuredChildrenInReverse(StructuredStatementTransformer transformer, StructuredScope scope)
/*  33:    */   {
/*  34: 33 */     transformStructuredChildren(transformer, scope);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public StructuredStatement claimBlock(Op04StructuredStatement innerBlock, BlockIdentifier blockIdentifier, Vector<BlockIdentifier> blocksCurrentlyIn)
/*  38:    */   {
/*  39: 38 */     return null;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public StructuredStatement informBlockHeirachy(Vector<BlockIdentifier> blockIdentifiers)
/*  43:    */   {
/*  44: 43 */     return null;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public boolean isProperlyStructured()
/*  48:    */   {
/*  49: 48 */     return true;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public boolean isRecursivelyStructured()
/*  53:    */   {
/*  54: 53 */     return true;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public BlockIdentifier getBreakableBlockOrNull()
/*  58:    */   {
/*  59: 64 */     return null;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/*  63:    */   {
/*  64: 69 */     throw new UnsupportedOperationException();
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void markCreator(LValue scopedEntity)
/*  68:    */   {
/*  69: 74 */     throw new IllegalArgumentException("Shouldn't be calling markCreator on " + this);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public boolean alwaysDefines(LValue scopedEntity)
/*  73:    */   {
/*  74: 79 */     return false;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public boolean canDefine(LValue scopedEntity)
/*  78:    */   {
/*  79: 84 */     return true;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public List<LValue> findCreatedHere()
/*  83:    */   {
/*  84: 89 */     return null;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public String suggestName(LocalVariable createdHere, Predicate<String> testNameUsedFn)
/*  88:    */   {
/*  89: 94 */     return null;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public final String toString()
/*  93:    */   {
/*  94: 99 */     return ToStringDumper.toString(this);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public boolean inlineable()
/*  98:    */   {
/*  99:104 */     return false;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public Op04StructuredStatement getInline()
/* 103:    */   {
/* 104:109 */     throw new UnsupportedOperationException();
/* 105:    */   }
/* 106:    */   
/* 107:    */   public boolean isEffectivelyNOP()
/* 108:    */   {
/* 109:114 */     return false;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public boolean fallsNopToNext()
/* 113:    */   {
/* 114:119 */     return false;
/* 115:    */   }
/* 116:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.AbstractStructuredStatement
 * JD-Core Version:    0.7.0.1
 */