/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.Set;
/*  4:   */ import java.util.Vector;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  7:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  8:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  9:   */ 
/* 10:   */ public class UnstructuredBreak
/* 11:   */   extends AbstractUnStructuredStatement
/* 12:   */ {
/* 13:   */   private final Set<BlockIdentifier> blocksEnding;
/* 14:   */   
/* 15:   */   public UnstructuredBreak(Set<BlockIdentifier> blocksEnding)
/* 16:   */   {
/* 17:16 */     this.blocksEnding = blocksEnding;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public Dumper dump(Dumper dumper)
/* 21:   */   {
/* 22:21 */     return dumper.print("** break;\n");
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void collectTypeUsages(TypeUsageCollector collector) {}
/* 26:   */   
/* 27:   */   public StructuredStatement informBlockHeirachy(Vector<BlockIdentifier> blockIdentifiers)
/* 28:   */   {
/* 29:33 */     int index = 2147483647;
/* 30:34 */     BlockIdentifier bestBlock = null;
/* 31:35 */     for (BlockIdentifier block : this.blocksEnding)
/* 32:   */     {
/* 33:36 */       int posn = blockIdentifiers.indexOf(block);
/* 34:37 */       if ((posn >= 0) && (index > posn))
/* 35:   */       {
/* 36:38 */         index = posn;
/* 37:39 */         bestBlock = block;
/* 38:   */       }
/* 39:   */     }
/* 40:42 */     if (bestBlock == null) {
/* 41:44 */       return null;
/* 42:   */     }
/* 43:46 */     boolean localBreak = false;
/* 44:47 */     BlockIdentifier outermostBreakable = BlockIdentifier.getInnermostBreakable(blockIdentifiers);
/* 45:48 */     if (outermostBreakable == bestBlock) {
/* 46:49 */       localBreak = true;
/* 47:   */     } else {
/* 48:51 */       bestBlock.addForeignRef();
/* 49:   */     }
/* 50:53 */     return new StructuredBreak(bestBlock, localBreak);
/* 51:   */   }
/* 52:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredBreak
 * JD-Core Version:    0.7.0.1
 */