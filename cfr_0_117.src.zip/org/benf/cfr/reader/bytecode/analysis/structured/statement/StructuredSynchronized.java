/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 14:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 15:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 16:   */ 
/* 17:   */ public class StructuredSynchronized
/* 18:   */   extends AbstractStructuredBlockStatement
/* 19:   */ {
/* 20:   */   private Expression monitor;
/* 21:   */   private BlockIdentifier blockIdentifier;
/* 22:   */   
/* 23:   */   public StructuredSynchronized(Expression monitor, BlockIdentifier blockIdentifier, Op04StructuredStatement body)
/* 24:   */   {
/* 25:23 */     super(body);
/* 26:24 */     this.monitor = monitor;
/* 27:25 */     this.blockIdentifier = blockIdentifier;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 31:   */   {
/* 32:30 */     this.monitor.collectTypeUsages(collector);
/* 33:31 */     super.collectTypeUsages(collector);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public Dumper dump(Dumper dumper)
/* 37:   */   {
/* 38:36 */     dumper.print("synchronized (").dump(this.monitor).print(") ");
/* 39:37 */     getBody().dump(dumper);
/* 40:38 */     return dumper;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public boolean isProperlyStructured()
/* 44:   */   {
/* 45:43 */     return true;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public boolean fallsNopToNext()
/* 49:   */   {
/* 50:48 */     return true;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope)
/* 54:   */   {
/* 55:53 */     scope.add(this);
/* 56:   */     try
/* 57:   */     {
/* 58:55 */       getBody().transform(transformer, scope);
/* 59:   */     }
/* 60:   */     finally
/* 61:   */     {
/* 62:57 */       scope.remove(this);
/* 63:   */     }
/* 64:   */   }
/* 65:   */   
/* 66:   */   public void linearizeInto(List<StructuredStatement> out)
/* 67:   */   {
/* 68:63 */     out.add(this);
/* 69:64 */     getBody().linearizeStatementsInto(out);
/* 70:   */   }
/* 71:   */   
/* 72:   */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer)
/* 73:   */   {
/* 74:69 */     this.monitor.collectUsedLValues(scopeDiscoverer);
/* 75:70 */     getBody().traceLocalVariableScope(scopeDiscoverer);
/* 76:   */   }
/* 77:   */   
/* 78:   */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 79:   */   {
/* 80:75 */     throw new UnsupportedOperationException();
/* 81:   */   }
/* 82:   */   
/* 83:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter)
/* 84:   */   {
/* 85:80 */     this.monitor = expressionRewriter.rewriteExpression(this.monitor, null, getContainer(), null);
/* 86:   */   }
/* 87:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredSynchronized
 * JD-Core Version:    0.7.0.1
 */