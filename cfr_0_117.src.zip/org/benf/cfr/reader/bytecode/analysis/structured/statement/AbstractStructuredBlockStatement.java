/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  4:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  5:   */ 
/*  6:   */ public abstract class AbstractStructuredBlockStatement
/*  7:   */   extends AbstractStructuredStatement
/*  8:   */ {
/*  9:   */   private Op04StructuredStatement body;
/* 10:   */   
/* 11:   */   public AbstractStructuredBlockStatement(Op04StructuredStatement body)
/* 12:   */   {
/* 13:11 */     this.body = body;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public Op04StructuredStatement getBody()
/* 17:   */   {
/* 18:15 */     return this.body;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public boolean isRecursivelyStructured()
/* 22:   */   {
/* 23:20 */     return this.body.isFullyStructured();
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 27:   */   {
/* 28:25 */     this.body.collectTypeUsages(collector);
/* 29:   */   }
/* 30:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.AbstractStructuredBlockStatement
 * JD-Core Version:    0.7.0.1
 */