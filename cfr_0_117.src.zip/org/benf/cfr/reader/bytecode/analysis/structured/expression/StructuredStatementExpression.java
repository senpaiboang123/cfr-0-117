/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.expression;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.misc.Precedence;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.CloneHelper;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueRewriter;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.LValueUsageCollector;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/* 14:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 15:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 16:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 17:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 18:   */ 
/* 19:   */ public class StructuredStatementExpression
/* 20:   */   extends AbstractExpression
/* 21:   */ {
/* 22:   */   private StructuredStatement content;
/* 23:   */   
/* 24:   */   public StructuredStatementExpression(InferredJavaType inferredJavaType, StructuredStatement content)
/* 25:   */   {
/* 26:24 */     super(inferredJavaType);
/* 27:25 */     this.content = content;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public Expression deepClone(CloneHelper cloneHelper)
/* 31:   */   {
/* 32:34 */     return this;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 36:   */   {
/* 37:39 */     this.content.collectTypeUsages(collector);
/* 38:   */   }
/* 39:   */   
/* 40:   */   public Expression replaceSingleUsageLValues(LValueRewriter lValueRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer)
/* 41:   */   {
/* 42:44 */     throw new UnsupportedOperationException();
/* 43:   */   }
/* 44:   */   
/* 45:   */   public Expression applyExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 46:   */   {
/* 47:49 */     return this;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public Expression applyReverseExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 51:   */   {
/* 52:54 */     return applyExpressionRewriter(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/* 53:   */   }
/* 54:   */   
/* 55:   */   public void collectUsedLValues(LValueUsageCollector lValueUsageCollector) {}
/* 56:   */   
/* 57:   */   public Precedence getPrecedence()
/* 58:   */   {
/* 59:64 */     return Precedence.WEAKEST;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public Dumper dumpInner(Dumper d)
/* 63:   */   {
/* 64:70 */     return this.content.dump(d);
/* 65:   */   }
/* 66:   */   
/* 67:   */   public boolean equals(Object o)
/* 68:   */   {
/* 69:75 */     if (this == o) {
/* 70:75 */       return true;
/* 71:   */     }
/* 72:76 */     if ((o == null) || (getClass() != o.getClass())) {
/* 73:76 */       return false;
/* 74:   */     }
/* 75:78 */     StructuredStatementExpression that = (StructuredStatementExpression)o;
/* 76:80 */     if (!this.content.equals(that.content)) {
/* 77:80 */       return false;
/* 78:   */     }
/* 79:82 */     return true;
/* 80:   */   }
/* 81:   */   
/* 82:   */   public final boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 83:   */   {
/* 84:87 */     if (o == null) {
/* 85:87 */       return false;
/* 86:   */     }
/* 87:88 */     if (o == this) {
/* 88:88 */       return true;
/* 89:   */     }
/* 90:89 */     if (getClass() != o.getClass()) {
/* 91:89 */       return false;
/* 92:   */     }
/* 93:90 */     StructuredStatementExpression other = (StructuredStatementExpression)o;
/* 94:91 */     if (!constraint.equivalent(this.content, other.content)) {
/* 95:91 */       return false;
/* 96:   */     }
/* 97:92 */     return true;
/* 98:   */   }
/* 99:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.expression.StructuredStatementExpression
 * JD-Core Version:    0.7.0.1
 */