/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue.Creation;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.SentinelLocalClassLValue;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/* 14:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 15:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/* 16:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/* 17:   */ import org.benf.cfr.reader.entities.ClassFile;
/* 18:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 19:   */ import org.benf.cfr.reader.util.ListFactory;
/* 20:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 21:   */ 
/* 22:   */ public class StructuredDefinition
/* 23:   */   extends AbstractStructuredStatement
/* 24:   */ {
/* 25:   */   private LValue scopedEntity;
/* 26:   */   
/* 27:   */   public StructuredDefinition(LValue scopedEntity)
/* 28:   */   {
/* 29:27 */     this.scopedEntity = scopedEntity;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 33:   */   {
/* 34:32 */     this.scopedEntity.collectTypeUsages(collector);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public Dumper dump(Dumper dumper)
/* 38:   */   {
/* 39:37 */     Class<?> clazz = this.scopedEntity.getClass();
/* 40:38 */     if (clazz == LocalVariable.class) {
/* 41:39 */       return LValue.Creation.dump(dumper, this.scopedEntity).print(" ").dump(this.scopedEntity).endCodeln();
/* 42:   */     }
/* 43:40 */     if (clazz == SentinelLocalClassLValue.class)
/* 44:   */     {
/* 45:41 */       JavaTypeInstance type = ((SentinelLocalClassLValue)this.scopedEntity).getLocalClassType().getDeGenerifiedType();
/* 46:42 */       if ((type instanceof JavaRefTypeInstance))
/* 47:   */       {
/* 48:43 */         ClassFile classFile = ((JavaRefTypeInstance)type).getClassFile();
/* 49:44 */         if (classFile != null) {
/* 50:45 */           return classFile.dumpAsInlineClass(dumper);
/* 51:   */         }
/* 52:   */       }
/* 53:   */     }
/* 54:49 */     return dumper;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope) {}
/* 58:   */   
/* 59:   */   public void linearizeInto(List<StructuredStatement> out)
/* 60:   */   {
/* 61:58 */     out.add(this);
/* 62:   */   }
/* 63:   */   
/* 64:   */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer) {}
/* 65:   */   
/* 66:   */   public LValue getLvalue()
/* 67:   */   {
/* 68:66 */     return this.scopedEntity;
/* 69:   */   }
/* 70:   */   
/* 71:   */   public List<LValue> findCreatedHere()
/* 72:   */   {
/* 73:71 */     return ListFactory.newList(new LValue[] { this.scopedEntity });
/* 74:   */   }
/* 75:   */   
/* 76:   */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 77:   */   {
/* 78:76 */     StructuredStatement o = (StructuredStatement)matchIterator.getCurrent();
/* 79:77 */     if (!equals(o)) {
/* 80:77 */       return false;
/* 81:   */     }
/* 82:78 */     matchIterator.advance();
/* 83:79 */     return true;
/* 84:   */   }
/* 85:   */   
/* 86:   */   public boolean equals(Object o)
/* 87:   */   {
/* 88:84 */     if (o == this) {
/* 89:84 */       return true;
/* 90:   */     }
/* 91:85 */     if (o == null) {
/* 92:85 */       return false;
/* 93:   */     }
/* 94:86 */     if (!(o instanceof StructuredDefinition)) {
/* 95:86 */       return false;
/* 96:   */     }
/* 97:87 */     StructuredDefinition other = (StructuredDefinition)o;
/* 98:88 */     if (!this.scopedEntity.equals(other.scopedEntity)) {
/* 99:88 */       return false;
/* :0:   */     }
/* :1:89 */     return true;
/* :2:   */   }
/* :3:   */   
/* :4:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter) {}
/* :5:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredDefinition
 * JD-Core Version:    0.7.0.1
 */