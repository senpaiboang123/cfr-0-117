/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*   2:    */ 
/*   3:    */ import java.util.LinkedList;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Vector;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockType;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.ConditionalUtils;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  12:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  13:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  14:    */ import org.benf.cfr.reader.util.ListFactory;
/*  15:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  16:    */ 
/*  17:    */ public class UnstructuredIf
/*  18:    */   extends AbstractUnStructuredStatement
/*  19:    */ {
/*  20:    */   private ConditionalExpression conditionalExpression;
/*  21:    */   private Op04StructuredStatement setIfBlock;
/*  22:    */   private BlockIdentifier knownIfBlock;
/*  23:    */   private BlockIdentifier knownElseBlock;
/*  24:    */   
/*  25:    */   public UnstructuredIf(ConditionalExpression conditionalExpression, BlockIdentifier knownIfBlock, BlockIdentifier knownElseBlock)
/*  26:    */   {
/*  27: 24 */     this.conditionalExpression = conditionalExpression;
/*  28: 25 */     this.knownIfBlock = knownIfBlock;
/*  29: 26 */     this.knownElseBlock = knownElseBlock;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  33:    */   {
/*  34: 31 */     collector.collectFrom(this.conditionalExpression);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public Dumper dump(Dumper dumper)
/*  38:    */   {
/*  39: 36 */     dumper.print("** if (").dump(this.conditionalExpression).print(") goto " + getContainer().getTargetLabel(1) + "\n");
/*  40: 37 */     if (this.setIfBlock != null) {
/*  41: 38 */       dumper.dump(this.setIfBlock);
/*  42:    */     }
/*  43: 40 */     return dumper;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public StructuredStatement claimBlock(Op04StructuredStatement innerBlock, BlockIdentifier blockIdentifier, Vector<BlockIdentifier> blocksCurrentlyIn)
/*  47:    */   {
/*  48: 45 */     if (blockIdentifier == this.knownIfBlock)
/*  49:    */     {
/*  50: 46 */       if (this.knownElseBlock == null)
/*  51:    */       {
/*  52: 47 */         Op04StructuredStatement fakeElse = new Op04StructuredStatement(new UnstructuredGoto());
/*  53: 48 */         Op04StructuredStatement fakeElseTarget = (Op04StructuredStatement)getContainer().getTargets().get(1);
/*  54: 49 */         fakeElse.addTarget(fakeElseTarget);
/*  55: 50 */         fakeElseTarget.addSource(fakeElse);
/*  56: 51 */         LinkedList<Op04StructuredStatement> fakeBlockContent = ListFactory.newLinkedList();
/*  57: 52 */         fakeBlockContent.add(fakeElse);
/*  58: 53 */         Op04StructuredStatement fakeElseBlock = new Op04StructuredStatement(new Block(fakeBlockContent, true));
/*  59: 54 */         return new StructuredIf(ConditionalUtils.simplify(this.conditionalExpression.getNegated()), innerBlock, fakeElseBlock);
/*  60:    */       }
/*  61: 56 */       this.setIfBlock = innerBlock;
/*  62: 57 */       return this;
/*  63:    */     }
/*  64: 59 */     if (blockIdentifier == this.knownElseBlock)
/*  65:    */     {
/*  66: 60 */       if (this.setIfBlock == null) {
/*  67: 61 */         throw new ConfusedCFRException("Set else block before setting IF block");
/*  68:    */       }
/*  69: 66 */       if (this.knownIfBlock.getBlockType() == BlockType.SIMPLE_IF_TAKEN) {
/*  70: 67 */         this.setIfBlock.removeLastGoto();
/*  71:    */       }
/*  72: 69 */       innerBlock = unpackElseIfBlock(innerBlock);
/*  73: 70 */       return new StructuredIf(ConditionalUtils.simplify(this.conditionalExpression.getNegated()), this.setIfBlock, innerBlock);
/*  74:    */     }
/*  75: 72 */     return null;
/*  76:    */   }
/*  77:    */   
/*  78:    */   private static Op04StructuredStatement unpackElseIfBlock(Op04StructuredStatement elseBlock)
/*  79:    */   {
/*  80: 81 */     StructuredStatement elseStmt = elseBlock.getStatement();
/*  81: 82 */     if (!(elseStmt instanceof Block)) {
/*  82: 82 */       return elseBlock;
/*  83:    */     }
/*  84: 83 */     Block block = (Block)elseStmt;
/*  85: 84 */     if (!block.isJustOneStatement()) {
/*  86: 87 */       return elseBlock;
/*  87:    */     }
/*  88: 89 */     Op04StructuredStatement inner = block.getSingleStatement();
/*  89: 90 */     if ((inner.getStatement() instanceof StructuredIf)) {
/*  90: 91 */       return inner;
/*  91:    */     }
/*  92: 93 */     return elseBlock;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public StructuredStatement convertEmptyToGoto()
/*  96:    */   {
/*  97:101 */     if ((this.knownIfBlock != null) || (this.knownElseBlock != null) || (this.setIfBlock != null)) {
/*  98:101 */       return this;
/*  99:    */     }
/* 100:102 */     Op04StructuredStatement gotoStm = new Op04StructuredStatement(new UnstructuredGoto());
/* 101:    */     
/* 102:    */ 
/* 103:105 */     Op04StructuredStatement target = (Op04StructuredStatement)getContainer().getTargets().get(1);
/* 104:106 */     gotoStm.addTarget(target);
/* 105:107 */     target.getSources().remove(getContainer());
/* 106:108 */     target.addSource(gotoStm);
/* 107:109 */     return new StructuredIf(this.conditionalExpression, gotoStm);
/* 108:    */   }
/* 109:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredIf
 * JD-Core Version:    0.7.0.1
 */