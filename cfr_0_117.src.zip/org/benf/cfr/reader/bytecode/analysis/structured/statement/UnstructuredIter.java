/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.Vector;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  9:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 10:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 11:   */ 
/* 12:   */ public class UnstructuredIter
/* 13:   */   extends AbstractUnStructuredStatement
/* 14:   */ {
/* 15:   */   private BlockIdentifier blockIdentifier;
/* 16:   */   private LValue iterator;
/* 17:   */   private Expression list;
/* 18:   */   
/* 19:   */   public UnstructuredIter(BlockIdentifier blockIdentifier, LValue iterator, Expression list)
/* 20:   */   {
/* 21:19 */     this.blockIdentifier = blockIdentifier;
/* 22:20 */     this.iterator = iterator;
/* 23:21 */     this.list = list;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public Dumper dump(Dumper dumper)
/* 27:   */   {
/* 28:26 */     return dumper.print("** for (").dump(this.iterator).print(" : ").dump(this.list).print(")\n");
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 32:   */   {
/* 33:31 */     this.iterator.collectTypeUsages(collector);
/* 34:32 */     collector.collectFrom(this.list);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public StructuredStatement claimBlock(Op04StructuredStatement innerBlock, BlockIdentifier blockIdentifier, Vector<BlockIdentifier> blocksCurrentlyIn)
/* 38:   */   {
/* 39:37 */     if (blockIdentifier != this.blockIdentifier) {
/* 40:38 */       throw new RuntimeException("ForIter statement claiming wrong block");
/* 41:   */     }
/* 42:40 */     innerBlock.removeLastContinue(blockIdentifier);
/* 43:41 */     return new StructuredIter(blockIdentifier, this.iterator, this.list, innerBlock);
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredIter
 * JD-Core Version:    0.7.0.1
 */