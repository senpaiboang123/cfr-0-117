/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  14:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  15:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  16:    */ 
/*  17:    */ public class StructuredDo
/*  18:    */   extends AbstractStructuredBlockStatement
/*  19:    */ {
/*  20:    */   private ConditionalExpression condition;
/*  21:    */   private final BlockIdentifier block;
/*  22:    */   
/*  23:    */   public StructuredDo(ConditionalExpression condition, Op04StructuredStatement body, BlockIdentifier block)
/*  24:    */   {
/*  25: 23 */     super(body);
/*  26: 24 */     this.condition = condition;
/*  27: 25 */     this.block = block;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public Dumper dump(Dumper dumper)
/*  31:    */   {
/*  32: 30 */     if (this.block.hasForeignReferences()) {
/*  33: 30 */       dumper.print(this.block.getName() + " : ");
/*  34:    */     }
/*  35: 31 */     dumper.print("do ");
/*  36: 32 */     getBody().dump(dumper);
/*  37: 33 */     dumper.removePendingCarriageReturn();
/*  38: 34 */     dumper.print(" while (");
/*  39: 35 */     if (this.condition == null) {
/*  40: 36 */       dumper.print("true");
/*  41:    */     } else {
/*  42: 38 */       dumper.dump(this.condition);
/*  43:    */     }
/*  44: 40 */     return dumper.print(");\n");
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  48:    */   {
/*  49: 45 */     collector.collectFrom(this.condition);
/*  50: 46 */     super.collectTypeUsages(collector);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope)
/*  54:    */   {
/*  55: 51 */     scope.add(this);
/*  56:    */     try
/*  57:    */     {
/*  58: 53 */       getBody().transform(transformer, scope);
/*  59:    */     }
/*  60:    */     finally
/*  61:    */     {
/*  62: 55 */       scope.remove(this);
/*  63:    */     }
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer)
/*  67:    */   {
/*  68: 61 */     if (this.condition != null) {
/*  69: 61 */       this.condition.collectUsedLValues(scopeDiscoverer);
/*  70:    */     }
/*  71: 62 */     getBody().traceLocalVariableScope(scopeDiscoverer);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void linearizeInto(List<StructuredStatement> out)
/*  75:    */   {
/*  76: 67 */     out.add(this);
/*  77: 68 */     getBody().linearizeStatementsInto(out);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter)
/*  81:    */   {
/*  82: 73 */     if (this.condition != null) {
/*  83: 74 */       this.condition = expressionRewriter.rewriteExpression(this.condition, null, getContainer(), null);
/*  84:    */     }
/*  85:    */   }
/*  86:    */   
/*  87:    */   public BlockIdentifier getBlock()
/*  88:    */   {
/*  89: 79 */     return this.block;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public ConditionalExpression getCondition()
/*  93:    */   {
/*  94: 83 */     return this.condition;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public BlockIdentifier getBreakableBlockOrNull()
/*  98:    */   {
/*  99: 88 */     return this.block;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 103:    */   {
/* 104: 93 */     StructuredStatement o = (StructuredStatement)matchIterator.getCurrent();
/* 105: 94 */     if (!(o instanceof StructuredDo)) {
/* 106: 94 */       return false;
/* 107:    */     }
/* 108: 95 */     StructuredDo other = (StructuredDo)o;
/* 109: 96 */     if (this.condition == null)
/* 110:    */     {
/* 111: 97 */       if (other.condition != null) {
/* 112: 97 */         return false;
/* 113:    */       }
/* 114:    */     }
/* 115: 99 */     else if (!this.condition.equals(other.condition)) {
/* 116: 99 */       return false;
/* 117:    */     }
/* 118:101 */     if (!this.block.equals(other.block)) {
/* 119:101 */       return false;
/* 120:    */     }
/* 121:103 */     matchIterator.advance();
/* 122:104 */     return true;
/* 123:    */   }
/* 124:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredDo
 * JD-Core Version:    0.7.0.1
 */