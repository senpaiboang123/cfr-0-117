/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.Vector;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  8:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  9:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 10:   */ 
/* 11:   */ public class UnstructuredSynchronized
/* 12:   */   extends AbstractUnStructuredStatement
/* 13:   */ {
/* 14:   */   private Expression monitor;
/* 15:   */   private BlockIdentifier blockIdentifier;
/* 16:   */   
/* 17:   */   public UnstructuredSynchronized(Expression monitor, BlockIdentifier blockIdentifier)
/* 18:   */   {
/* 19:17 */     this.monitor = monitor;
/* 20:18 */     this.blockIdentifier = blockIdentifier;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 24:   */   {
/* 25:23 */     this.monitor.collectTypeUsages(collector);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public Dumper dump(Dumper dumper)
/* 29:   */   {
/* 30:28 */     return dumper.print("** synchronized (").dump(this.monitor).print(")\n");
/* 31:   */   }
/* 32:   */   
/* 33:   */   public StructuredStatement claimBlock(Op04StructuredStatement innerBlock, BlockIdentifier blockIdentifier, Vector<BlockIdentifier> blocksCurrentlyIn)
/* 34:   */   {
/* 35:33 */     if (blockIdentifier != this.blockIdentifier) {
/* 36:34 */       throw new RuntimeException("MONITOREXIT statement claiming wrong block");
/* 37:   */     }
/* 38:37 */     return new StructuredSynchronized(this.monitor, blockIdentifier, innerBlock);
/* 39:   */   }
/* 40:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredSynchronized
 * JD-Core Version:    0.7.0.1
 */