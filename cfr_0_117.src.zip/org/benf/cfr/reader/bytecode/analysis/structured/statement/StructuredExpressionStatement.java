/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 12:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 13:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 14:   */ 
/* 15:   */ public class StructuredExpressionStatement
/* 16:   */   extends AbstractStructuredStatement
/* 17:   */ {
/* 18:   */   private Expression expression;
/* 19:   */   private boolean inline;
/* 20:   */   
/* 21:   */   public StructuredExpressionStatement(Expression expression, boolean inline)
/* 22:   */   {
/* 23:21 */     this.expression = expression;
/* 24:22 */     this.inline = inline;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public Dumper dump(Dumper dumper)
/* 28:   */   {
/* 29:27 */     dumper.dump(this.expression);
/* 30:28 */     if (!this.inline) {
/* 31:28 */       dumper.endCodeln();
/* 32:   */     }
/* 33:29 */     return dumper;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 37:   */   {
/* 38:34 */     collector.collectFrom(this.expression);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope) {}
/* 42:   */   
/* 43:   */   public void linearizeInto(List<StructuredStatement> out)
/* 44:   */   {
/* 45:43 */     out.add(this);
/* 46:   */   }
/* 47:   */   
/* 48:   */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 49:   */   {
/* 50:48 */     StructuredStatement o = (StructuredStatement)matchIterator.getCurrent();
/* 51:49 */     if (!(o instanceof StructuredExpressionStatement)) {
/* 52:49 */       return false;
/* 53:   */     }
/* 54:50 */     StructuredExpressionStatement other = (StructuredExpressionStatement)o;
/* 55:51 */     if (!this.expression.equals(other.expression)) {
/* 56:51 */       return false;
/* 57:   */     }
/* 58:52 */     matchIterator.advance();
/* 59:53 */     return true;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer)
/* 63:   */   {
/* 64:58 */     this.expression.collectUsedLValues(scopeDiscoverer);
/* 65:   */   }
/* 66:   */   
/* 67:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter)
/* 68:   */   {
/* 69:63 */     this.expression = expressionRewriter.rewriteExpression(this.expression, null, getContainer(), null);
/* 70:   */   }
/* 71:   */   
/* 72:   */   public Expression getExpression()
/* 73:   */   {
/* 74:67 */     return this.expression;
/* 75:   */   }
/* 76:   */   
/* 77:   */   public boolean equals(Object o)
/* 78:   */   {
/* 79:72 */     if (o == this) {
/* 80:72 */       return true;
/* 81:   */     }
/* 82:73 */     if (o == null) {
/* 83:73 */       return false;
/* 84:   */     }
/* 85:75 */     if (!(o instanceof StructuredExpressionStatement)) {
/* 86:75 */       return false;
/* 87:   */     }
/* 88:77 */     StructuredExpressionStatement other = (StructuredExpressionStatement)o;
/* 89:78 */     return this.expression.equals(other.expression);
/* 90:   */   }
/* 91:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredExpressionStatement
 * JD-Core Version:    0.7.0.1
 */