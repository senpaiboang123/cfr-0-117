/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Vector;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 14:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 15:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 16:   */ 
/* 17:   */ public class StructuredAssert
/* 18:   */   extends AbstractStructuredStatement
/* 19:   */ {
/* 20:   */   ConditionalExpression conditionalExpression;
/* 21:   */   
/* 22:   */   public StructuredAssert(ConditionalExpression conditionalExpression)
/* 23:   */   {
/* 24:23 */     this.conditionalExpression = conditionalExpression;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 28:   */   {
/* 29:28 */     this.conditionalExpression.collectTypeUsages(collector);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public Dumper dump(Dumper dumper)
/* 33:   */   {
/* 34:33 */     return dumper.print("assert (").dump(this.conditionalExpression).print(")").endCodeln();
/* 35:   */   }
/* 36:   */   
/* 37:   */   public StructuredStatement informBlockHeirachy(Vector<BlockIdentifier> blockIdentifiers)
/* 38:   */   {
/* 39:38 */     throw new UnsupportedOperationException();
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope) {}
/* 43:   */   
/* 44:   */   public void linearizeInto(List<StructuredStatement> out)
/* 45:   */   {
/* 46:47 */     out.add(this);
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer)
/* 50:   */   {
/* 51:52 */     this.conditionalExpression.collectUsedLValues(scopeDiscoverer);
/* 52:   */   }
/* 53:   */   
/* 54:   */   public boolean isRecursivelyStructured()
/* 55:   */   {
/* 56:57 */     return true;
/* 57:   */   }
/* 58:   */   
/* 59:   */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 60:   */   {
/* 61:62 */     StructuredStatement o = (StructuredStatement)matchIterator.getCurrent();
/* 62:63 */     if (!(o instanceof StructuredAssert)) {
/* 63:63 */       return false;
/* 64:   */     }
/* 65:64 */     StructuredAssert other = (StructuredAssert)o;
/* 66:65 */     if (!this.conditionalExpression.equals(other.conditionalExpression)) {
/* 67:65 */       return false;
/* 68:   */     }
/* 69:67 */     matchIterator.advance();
/* 70:68 */     return true;
/* 71:   */   }
/* 72:   */   
/* 73:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter)
/* 74:   */   {
/* 75:73 */     this.conditionalExpression = expressionRewriter.rewriteExpression(this.conditionalExpression, null, getContainer(), null);
/* 76:   */   }
/* 77:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredAssert
 * JD-Core Version:    0.7.0.1
 */