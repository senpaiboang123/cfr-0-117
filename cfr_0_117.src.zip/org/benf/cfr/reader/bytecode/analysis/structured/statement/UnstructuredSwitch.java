/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Vector;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  9:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 10:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/* 11:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 12:   */ 
/* 13:   */ public class UnstructuredSwitch
/* 14:   */   extends AbstractUnStructuredStatement
/* 15:   */ {
/* 16:   */   private Expression switchOn;
/* 17:   */   private final BlockIdentifier blockIdentifier;
/* 18:   */   
/* 19:   */   public UnstructuredSwitch(Expression switchOn, BlockIdentifier blockIdentifier)
/* 20:   */   {
/* 21:20 */     this.switchOn = switchOn;
/* 22:21 */     this.blockIdentifier = blockIdentifier;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public Dumper dump(Dumper dumper)
/* 26:   */   {
/* 27:26 */     return dumper.print("** switch (").dump(this.switchOn).print(")\n");
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 31:   */   {
/* 32:31 */     collector.collectFrom(this.switchOn);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public StructuredStatement claimBlock(Op04StructuredStatement innerBlock, BlockIdentifier blockIdentifier, Vector<BlockIdentifier> blocksCurrentlyIn)
/* 36:   */   {
/* 37:36 */     if (blockIdentifier != this.blockIdentifier) {
/* 38:37 */       throw new ConfusedCFRException("Unstructured switch being asked to claim wrong block. [" + blockIdentifier + " != " + this.blockIdentifier + "]");
/* 39:   */     }
/* 40:43 */     if ((innerBlock.getStatement() instanceof Block))
/* 41:   */     {
/* 42:44 */       Block block = (Block)innerBlock.getStatement();
/* 43:45 */       List<Op04StructuredStatement> statements = block.getBlockStatements();
/* 44:46 */       Op04StructuredStatement last = (Op04StructuredStatement)statements.get(statements.size() - 1);
/* 45:47 */       if ((last.getStatement() instanceof UnstructuredCase))
/* 46:   */       {
/* 47:48 */         UnstructuredCase caseStatement = (UnstructuredCase)last.getStatement();
/* 48:49 */         last.replaceContainedStatement(caseStatement.getEmptyStructuredCase());
/* 49:   */       }
/* 50:   */     }
/* 51:52 */     return new StructuredSwitch(this.switchOn, innerBlock, blockIdentifier);
/* 52:   */   }
/* 53:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredSwitch
 * JD-Core Version:    0.7.0.1
 */