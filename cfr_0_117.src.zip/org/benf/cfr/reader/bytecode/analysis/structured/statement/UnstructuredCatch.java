/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Map;
/*  5:   */ import java.util.Set;
/*  6:   */ import java.util.Vector;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/* 12:   */ import org.benf.cfr.reader.entities.exceptions.ExceptionGroup.Entry;
/* 13:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 14:   */ import org.benf.cfr.reader.util.MapFactory;
/* 15:   */ import org.benf.cfr.reader.util.SetFactory;
/* 16:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 17:   */ 
/* 18:   */ public class UnstructuredCatch
/* 19:   */   extends AbstractUnStructuredStatement
/* 20:   */ {
/* 21:   */   private final List<ExceptionGroup.Entry> exceptions;
/* 22:   */   private final BlockIdentifier blockIdentifier;
/* 23:   */   private final LValue catching;
/* 24:   */   
/* 25:   */   public UnstructuredCatch(List<ExceptionGroup.Entry> exceptions, BlockIdentifier blockIdentifier, LValue catching)
/* 26:   */   {
/* 27:25 */     this.exceptions = exceptions;
/* 28:26 */     this.blockIdentifier = blockIdentifier;
/* 29:27 */     this.catching = catching;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public Dumper dump(Dumper dumper)
/* 33:   */   {
/* 34:32 */     dumper.print("** catch " + this.exceptions + " { \n");
/* 35:33 */     return dumper;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 39:   */   {
/* 40:38 */     for (ExceptionGroup.Entry entry : this.exceptions) {
/* 41:39 */       collector.collect(entry.getCatchType());
/* 42:   */     }
/* 43:   */   }
/* 44:   */   
/* 45:   */   public StructuredStatement getCatchFor(Op04StructuredStatement innerBlock)
/* 46:   */   {
/* 47:47 */     Map<String, JavaRefTypeInstance> catchTypes = MapFactory.newTreeMap();
/* 48:48 */     Set<BlockIdentifier> possibleTryBlocks = SetFactory.newSet();
/* 49:49 */     for (ExceptionGroup.Entry entry : this.exceptions)
/* 50:   */     {
/* 51:50 */       JavaRefTypeInstance typ = entry.getCatchType();
/* 52:51 */       catchTypes.put(typ.getRawName(), typ);
/* 53:52 */       possibleTryBlocks.add(entry.getTryBlockIdentifier());
/* 54:   */     }
/* 55:54 */     return new StructuredCatch(catchTypes.values(), innerBlock, this.catching, possibleTryBlocks);
/* 56:   */   }
/* 57:   */   
/* 58:   */   public StructuredStatement getCatchForEmpty()
/* 59:   */   {
/* 60:58 */     return getCatchFor(new Op04StructuredStatement(Block.getEmptyBlock(true)));
/* 61:   */   }
/* 62:   */   
/* 63:   */   public StructuredStatement claimBlock(Op04StructuredStatement innerBlock, BlockIdentifier blockIdentifier, Vector<BlockIdentifier> blocksCurrentlyIn)
/* 64:   */   {
/* 65:63 */     if (blockIdentifier == this.blockIdentifier) {
/* 66:67 */       return getCatchFor(innerBlock);
/* 67:   */     }
/* 68:69 */     return null;
/* 69:   */   }
/* 70:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredCatch
 * JD-Core Version:    0.7.0.1
 */