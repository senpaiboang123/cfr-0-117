/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 12:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 13:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 14:   */ 
/* 15:   */ public class StructuredFinally
/* 16:   */   extends AbstractStructuredStatement
/* 17:   */ {
/* 18:   */   private final Op04StructuredStatement catchBlock;
/* 19:   */   
/* 20:   */   public StructuredFinally(Op04StructuredStatement catchBlock)
/* 21:   */   {
/* 22:20 */     this.catchBlock = catchBlock;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public Dumper dump(Dumper dumper)
/* 26:   */   {
/* 27:25 */     dumper.print("finally ");
/* 28:26 */     this.catchBlock.dump(dumper);
/* 29:27 */     return dumper;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 33:   */   {
/* 34:32 */     collector.collectFrom(this.catchBlock);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public boolean isProperlyStructured()
/* 38:   */   {
/* 39:37 */     return true;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public boolean fallsNopToNext()
/* 43:   */   {
/* 44:42 */     return true;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope)
/* 48:   */   {
/* 49:47 */     scope.add(this);
/* 50:   */     try
/* 51:   */     {
/* 52:49 */       this.catchBlock.transform(transformer, scope);
/* 53:   */     }
/* 54:   */     finally
/* 55:   */     {
/* 56:51 */       scope.remove(this);
/* 57:   */     }
/* 58:   */   }
/* 59:   */   
/* 60:   */   public void linearizeInto(List<StructuredStatement> out)
/* 61:   */   {
/* 62:57 */     out.add(this);
/* 63:58 */     this.catchBlock.linearizeStatementsInto(out);
/* 64:   */   }
/* 65:   */   
/* 66:   */   public Op04StructuredStatement getCatchBlock()
/* 67:   */   {
/* 68:62 */     return this.catchBlock;
/* 69:   */   }
/* 70:   */   
/* 71:   */   public boolean isRecursivelyStructured()
/* 72:   */   {
/* 73:67 */     return this.catchBlock.isFullyStructured();
/* 74:   */   }
/* 75:   */   
/* 76:   */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 77:   */   {
/* 78:73 */     StructuredStatement o = (StructuredStatement)matchIterator.getCurrent();
/* 79:74 */     if (!(o instanceof StructuredFinally)) {
/* 80:74 */       return false;
/* 81:   */     }
/* 82:75 */     StructuredFinally other = (StructuredFinally)o;
/* 83:   */     
/* 84:77 */     matchIterator.advance();
/* 85:78 */     return true;
/* 86:   */   }
/* 87:   */   
/* 88:   */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer)
/* 89:   */   {
/* 90:83 */     this.catchBlock.traceLocalVariableScope(scopeDiscoverer);
/* 91:   */   }
/* 92:   */   
/* 93:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter) {}
/* 94:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredFinally
 * JD-Core Version:    0.7.0.1
 */