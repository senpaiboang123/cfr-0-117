/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*   2:    */ 
/*   3:    */ import java.util.Iterator;
/*   4:    */ import java.util.LinkedList;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Set;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.InstrIndex;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.BeginBlock;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.EndBlock;
/*  20:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  21:    */ import org.benf.cfr.reader.util.ListFactory;
/*  22:    */ import org.benf.cfr.reader.util.SetFactory;
/*  23:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  24:    */ 
/*  25:    */ public class Block
/*  26:    */   extends AbstractStructuredStatement
/*  27:    */ {
/*  28:    */   private LinkedList<Op04StructuredStatement> containedStatements;
/*  29:    */   private boolean indenting;
/*  30:    */   private BlockIdentifier blockIdentifier;
/*  31: 34 */   private static final LinkedList<Op04StructuredStatement> emptyBlockStatements = ;
/*  32:    */   
/*  33:    */   public Block(LinkedList<Op04StructuredStatement> containedStatements, boolean indenting)
/*  34:    */   {
/*  35: 37 */     this(containedStatements, indenting, null);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public Block(LinkedList<Op04StructuredStatement> containedStatements, boolean indenting, BlockIdentifier blockIdentifier)
/*  39:    */   {
/*  40: 41 */     this.containedStatements = containedStatements;
/*  41: 42 */     this.indenting = indenting;
/*  42: 43 */     this.blockIdentifier = blockIdentifier;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static Block getEmptyBlock()
/*  46:    */   {
/*  47: 47 */     return new Block(emptyBlockStatements, false);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static Block getEmptyBlock(boolean indenting)
/*  51:    */   {
/*  52: 51 */     return new Block(emptyBlockStatements, indenting);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static Block getBlockFor(boolean indenting, StructuredStatement... statements)
/*  56:    */   {
/*  57: 55 */     LinkedList<Op04StructuredStatement> tmp = ListFactory.newLinkedList();
/*  58: 56 */     for (StructuredStatement statement : statements) {
/*  59: 57 */       tmp.add(new Op04StructuredStatement(statement));
/*  60:    */     }
/*  61: 59 */     return new Block(tmp, indenting);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  65:    */   {
/*  66: 64 */     for (Op04StructuredStatement statement : this.containedStatements) {
/*  67: 65 */       statement.collectTypeUsages(collector);
/*  68:    */     }
/*  69:    */   }
/*  70:    */   
/*  71:    */   public boolean removeLastContinue(BlockIdentifier block)
/*  72:    */   {
/*  73: 70 */     StructuredStatement structuredStatement = ((Op04StructuredStatement)this.containedStatements.getLast()).getStatement();
/*  74: 71 */     if ((structuredStatement instanceof AbstractStructuredContinue))
/*  75:    */     {
/*  76: 72 */       AbstractStructuredContinue structuredContinue = (AbstractStructuredContinue)structuredStatement;
/*  77: 73 */       if (structuredContinue.getContinueTgt() == block)
/*  78:    */       {
/*  79: 74 */         Op04StructuredStatement continueStmt = (Op04StructuredStatement)this.containedStatements.getLast();
/*  80: 75 */         continueStmt.replaceStatementWithNOP("");
/*  81: 76 */         return true;
/*  82:    */       }
/*  83: 78 */       return false;
/*  84:    */     }
/*  85: 81 */     return false;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public boolean removeLastNVReturn()
/*  89:    */   {
/*  90: 86 */     StructuredStatement structuredStatement = ((Op04StructuredStatement)this.containedStatements.getLast()).getStatement();
/*  91: 87 */     if ((structuredStatement instanceof StructuredReturn))
/*  92:    */     {
/*  93: 88 */       Op04StructuredStatement oldReturn = (Op04StructuredStatement)this.containedStatements.getLast();
/*  94: 89 */       StructuredReturn structuredReturn = (StructuredReturn)structuredStatement;
/*  95: 90 */       if (structuredReturn.getValue() == null) {
/*  96: 91 */         oldReturn.replaceStatementWithNOP("");
/*  97:    */       }
/*  98: 93 */       return true;
/*  99:    */     }
/* 100: 95 */     return false;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public boolean removeLastGoto()
/* 104:    */   {
/* 105:101 */     StructuredStatement structuredStatement = ((Op04StructuredStatement)this.containedStatements.getLast()).getStatement();
/* 106:102 */     if ((structuredStatement instanceof UnstructuredGoto))
/* 107:    */     {
/* 108:103 */       Op04StructuredStatement oldGoto = (Op04StructuredStatement)this.containedStatements.getLast();
/* 109:104 */       oldGoto.replaceStatementWithNOP("");
/* 110:105 */       return true;
/* 111:    */     }
/* 112:107 */     return false;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public boolean removeLastGoto(Op04StructuredStatement toHere)
/* 116:    */   {
/* 117:112 */     StructuredStatement structuredStatement = ((Op04StructuredStatement)this.containedStatements.getLast()).getStatement();
/* 118:113 */     if ((structuredStatement instanceof UnstructuredGoto))
/* 119:    */     {
/* 120:114 */       Op04StructuredStatement oldGoto = (Op04StructuredStatement)this.containedStatements.getLast();
/* 121:115 */       if (oldGoto.getTargets().get(0) == toHere)
/* 122:    */       {
/* 123:116 */         oldGoto.replaceStatementWithNOP("");
/* 124:117 */         return true;
/* 125:    */       }
/* 126:    */     }
/* 127:120 */     return false;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public UnstructuredWhile removeLastEndWhile()
/* 131:    */   {
/* 132:124 */     StructuredStatement structuredStatement = ((Op04StructuredStatement)this.containedStatements.getLast()).getStatement();
/* 133:125 */     if ((structuredStatement instanceof UnstructuredWhile))
/* 134:    */     {
/* 135:126 */       Op04StructuredStatement endWhile = (Op04StructuredStatement)this.containedStatements.getLast();
/* 136:127 */       endWhile.replaceStatementWithNOP("");
/* 137:128 */       return (UnstructuredWhile)structuredStatement;
/* 138:    */     }
/* 139:131 */     return null;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public boolean isJustOneStatement()
/* 143:    */   {
/* 144:136 */     int count = 0;
/* 145:137 */     for (Op04StructuredStatement statement : this.containedStatements) {
/* 146:139 */       if (!(statement.getStatement() instanceof StructuredComment)) {
/* 147:140 */         count++;
/* 148:    */       }
/* 149:    */     }
/* 150:143 */     return count == 1;
/* 151:    */   }
/* 152:    */   
/* 153:    */   public Op04StructuredStatement getSingleStatement()
/* 154:    */   {
/* 155:147 */     for (Op04StructuredStatement statement : this.containedStatements) {
/* 156:149 */       if (!(statement.getStatement() instanceof StructuredComment)) {
/* 157:150 */         return statement;
/* 158:    */       }
/* 159:    */     }
/* 160:153 */     throw new IllegalStateException();
/* 161:    */   }
/* 162:    */   
/* 163:    */   public boolean inlineable()
/* 164:    */   {
/* 165:158 */     for (Iterator i$ = this.containedStatements.iterator(); i$.hasNext(); return false)
/* 166:    */     {
/* 167:158 */       Op04StructuredStatement in = (Op04StructuredStatement)i$.next();
/* 168:159 */       StructuredStatement s = in.getStatement();
/* 169:160 */       Class<?> c = s.getClass();
/* 170:161 */       if ((c == StructuredReturn.class) || (c == UnstructuredGoto.class)) {}
/* 171:    */     }
/* 172:163 */     return true;
/* 173:    */   }
/* 174:    */   
/* 175:    */   public Op04StructuredStatement getInline()
/* 176:    */   {
/* 177:168 */     return getContainer();
/* 178:    */   }
/* 179:    */   
/* 180:    */   public void combineInlineable()
/* 181:    */   {
/* 182:172 */     boolean inline = false;
/* 183:173 */     for (Op04StructuredStatement in : this.containedStatements) {
/* 184:174 */       if (in.getStatement().inlineable())
/* 185:    */       {
/* 186:175 */         inline = true;
/* 187:176 */         break;
/* 188:    */       }
/* 189:    */     }
/* 190:179 */     if (!inline) {
/* 191:179 */       return;
/* 192:    */     }
/* 193:180 */     LinkedList<Op04StructuredStatement> newContained = ListFactory.newLinkedList();
/* 194:181 */     for (Op04StructuredStatement in : this.containedStatements)
/* 195:    */     {
/* 196:182 */       StructuredStatement s = in.getStatement();
/* 197:183 */       if (s.inlineable())
/* 198:    */       {
/* 199:184 */         Op04StructuredStatement inlinedOp = s.getInline();
/* 200:185 */         StructuredStatement inlined = inlinedOp.getStatement();
/* 201:186 */         if ((inlined instanceof Block))
/* 202:    */         {
/* 203:187 */           List<Op04StructuredStatement> inlinedBlocks = ((Block)inlined).getBlockStatements();
/* 204:188 */           newContained.addAll(((Block)inlined).getBlockStatements());
/* 205:189 */           replaceInlineSource(in, (Op04StructuredStatement)inlinedBlocks.get(0));
/* 206:    */         }
/* 207:    */         else
/* 208:    */         {
/* 209:191 */           newContained.add(inlinedOp);
/* 210:192 */           replaceInlineSource(in, inlinedOp);
/* 211:    */         }
/* 212:    */       }
/* 213:    */       else
/* 214:    */       {
/* 215:195 */         newContained.add(in);
/* 216:    */       }
/* 217:    */     }
/* 218:198 */     this.containedStatements = newContained;
/* 219:    */   }
/* 220:    */   
/* 221:    */   private void replaceInlineSource(Op04StructuredStatement oldS, Op04StructuredStatement newS)
/* 222:    */   {
/* 223:202 */     for (Op04StructuredStatement src : oldS.getSources())
/* 224:    */     {
/* 225:203 */       src.replaceTarget(oldS, newS);
/* 226:204 */       newS.addSource(src);
/* 227:    */     }
/* 228:206 */     newS.getSources().remove(oldS);
/* 229:    */   }
/* 230:    */   
/* 231:    */   public void extractLabelledBlocks()
/* 232:    */   {
/* 233:210 */     Iterator<Op04StructuredStatement> iterator = this.containedStatements.descendingIterator();
/* 234:211 */     while (iterator.hasNext())
/* 235:    */     {
/* 236:212 */       Op04StructuredStatement stm = (Op04StructuredStatement)iterator.next();
/* 237:213 */       StructuredStatement statement = stm.getStatement();
/* 238:214 */       if (statement.getClass() == UnstructuredAnonBreakTarget.class)
/* 239:    */       {
/* 240:215 */         UnstructuredAnonBreakTarget breakTarget = (UnstructuredAnonBreakTarget)statement;
/* 241:216 */         BlockIdentifier blockIdentifier = breakTarget.getBlockIdentifier();
/* 242:    */         
/* 243:    */ 
/* 244:    */ 
/* 245:220 */         LinkedList<Op04StructuredStatement> inner = ListFactory.newLinkedList();
/* 246:221 */         iterator.remove();
/* 247:222 */         while (iterator.hasNext())
/* 248:    */         {
/* 249:223 */           inner.addFirst(iterator.next());
/* 250:224 */           iterator.remove();
/* 251:    */         }
/* 252:226 */         Block nested = new Block(inner, true, blockIdentifier);
/* 253:227 */         Set<BlockIdentifier> outerIdents = getContainer().getBlockIdentifiers();
/* 254:228 */         Set<BlockIdentifier> innerIdents = SetFactory.newSet(outerIdents);
/* 255:229 */         innerIdents.add(blockIdentifier);
/* 256:230 */         InstrIndex newIdx = getContainer().getIndex().justAfter();
/* 257:231 */         Op04StructuredStatement newStm = new Op04StructuredStatement(newIdx, innerIdents, nested);
/* 258:    */         
/* 259:    */ 
/* 260:    */ 
/* 261:    */ 
/* 262:236 */         this.containedStatements.addFirst(newStm);
/* 263:    */         
/* 264:238 */         List<Op04StructuredStatement> sources = stm.getSources();
/* 265:242 */         for (Op04StructuredStatement source : sources)
/* 266:    */         {
/* 267:243 */           StructuredStatement maybeBreak = source.getStatement();
/* 268:245 */           if (maybeBreak.getClass() == StructuredIf.class)
/* 269:    */           {
/* 270:247 */             StructuredIf structuredIf = (StructuredIf)maybeBreak;
/* 271:248 */             source = structuredIf.getIfTaken();
/* 272:249 */             maybeBreak = source.getStatement();
/* 273:    */           }
/* 274:251 */           if (maybeBreak.getClass() == UnstructuredAnonymousBreak.class)
/* 275:    */           {
/* 276:252 */             UnstructuredAnonymousBreak unstructuredBreak = (UnstructuredAnonymousBreak)maybeBreak;
/* 277:253 */             source.replaceStatement(unstructuredBreak.tryExplicitlyPlaceInBlock(blockIdentifier));
/* 278:    */           }
/* 279:    */         }
/* 280:258 */         stm.replaceStatement(new StructuredComment(""));
/* 281:    */       }
/* 282:    */     }
/* 283:    */   }
/* 284:    */   
/* 285:    */   public void combineTryCatch()
/* 286:    */   {
/* 287:265 */     Set<Class<?>> skipThese = SetFactory.newSet(new Class[] { StructuredCatch.class, StructuredFinally.class, StructuredTry.class, UnstructuredTry.class });
/* 288:    */     
/* 289:    */ 
/* 290:    */ 
/* 291:    */ 
/* 292:    */ 
/* 293:271 */     int size = this.containedStatements.size();
/* 294:272 */     boolean finished = false;
/* 295:    */     label543:
/* 296:274 */     for (int x = 0; (x < size) && (!finished); x++)
/* 297:    */     {
/* 298:275 */       Op04StructuredStatement statement = (Op04StructuredStatement)this.containedStatements.get(x);
/* 299:276 */       StructuredStatement innerStatement = statement.getStatement();
/* 300:280 */       if ((innerStatement instanceof UnstructuredTry))
/* 301:    */       {
/* 302:281 */         UnstructuredTry unstructuredTry = (UnstructuredTry)innerStatement;
/* 303:282 */         if (x < size - 1)
/* 304:    */         {
/* 305:283 */           StructuredStatement nextStatement = ((Op04StructuredStatement)this.containedStatements.get(x + 1)).getStatement();
/* 306:284 */           if (((nextStatement instanceof StructuredCatch)) || ((nextStatement instanceof StructuredFinally)))
/* 307:    */           {
/* 308:286 */             Op04StructuredStatement replacement = new Op04StructuredStatement(unstructuredTry.getEmptyTry());
/* 309:287 */             Op04StructuredStatement.replaceInTargets(statement, replacement);
/* 310:288 */             Op04StructuredStatement.replaceInSources(statement, replacement);
/* 311:289 */             statement = replacement;
/* 312:290 */             this.containedStatements.set(x, statement);
/* 313:291 */             innerStatement = statement.getStatement();
/* 314:    */           }
/* 315:    */         }
/* 316:    */       }
/* 317:295 */       if ((innerStatement instanceof StructuredTry))
/* 318:    */       {
/* 319:296 */         StructuredTry structuredTry = (StructuredTry)innerStatement;
/* 320:297 */         BlockIdentifier tryBlockIdent = structuredTry.getTryBlockIdentifier();
/* 321:298 */         x++;
/* 322:299 */         Op04StructuredStatement next = x < size ? (Op04StructuredStatement)this.containedStatements.get(x) : null;
/* 323:305 */         if (next != null)
/* 324:    */         {
/* 325:306 */           StructuredStatement nextStatement = next.getStatement();
/* 326:307 */           if (!skipThese.contains(nextStatement.getClass())) {
/* 327:308 */             for (int y = x + 1; y < size; y++)
/* 328:    */             {
/* 329:309 */               StructuredStatement test = ((Op04StructuredStatement)this.containedStatements.get(y)).getStatement();
/* 330:310 */               if (((test instanceof StructuredTry)) || ((test instanceof UnstructuredTry))) {
/* 331:    */                 break label543;
/* 332:    */               }
/* 333:314 */               if ((test instanceof StructuredCatch))
/* 334:    */               {
/* 335:315 */                 Set<BlockIdentifier> blocks = ((StructuredCatch)test).getPossibleTryBlocks();
/* 336:316 */                 if (blocks.contains(tryBlockIdent))
/* 337:    */                 {
/* 338:317 */                   x = y;
/* 339:318 */                   next = (Op04StructuredStatement)this.containedStatements.get(y);
/* 340:319 */                   break;
/* 341:    */                 }
/* 342:    */               }
/* 343:    */             }
/* 344:    */           }
/* 345:    */         }
/* 346:326 */         while ((x < size) && (next != null))
/* 347:    */         {
/* 348:327 */           x++;
/* 349:328 */           StructuredStatement nextStatement = next.getStatement();
/* 350:329 */           if ((nextStatement instanceof StructuredComment))
/* 351:    */           {
/* 352:330 */             next.nopThis();
/* 353:    */           }
/* 354:332 */           else if ((nextStatement instanceof StructuredCatch))
/* 355:    */           {
/* 356:333 */             Set<BlockIdentifier> blocks = ((StructuredCatch)nextStatement).getPossibleTryBlocks();
/* 357:334 */             if (!blocks.contains(tryBlockIdent))
/* 358:    */             {
/* 359:335 */               x--;
/* 360:336 */               break;
/* 361:    */             }
/* 362:338 */             structuredTry.addCatch(next.nopThisAndReplace());
/* 363:339 */             if (x < size)
/* 364:    */             {
/* 365:340 */               next = (Op04StructuredStatement)this.containedStatements.get(x);
/* 366:    */             }
/* 367:    */             else
/* 368:    */             {
/* 369:343 */               next = null;
/* 370:344 */               finished = true;
/* 371:    */             }
/* 372:    */           }
/* 373:346 */           else if ((next.getStatement() instanceof StructuredFinally))
/* 374:    */           {
/* 375:347 */             structuredTry.addFinally(next.nopThisAndReplace());
/* 376:348 */             if (x < size)
/* 377:    */             {
/* 378:349 */               next = (Op04StructuredStatement)this.containedStatements.get(x);
/* 379:    */             }
/* 380:    */             else
/* 381:    */             {
/* 382:352 */               next = null;
/* 383:353 */               finished = true;
/* 384:    */             }
/* 385:    */           }
/* 386:    */           else
/* 387:    */           {
/* 388:356 */             x--;
/* 389:357 */             break;
/* 390:    */           }
/* 391:    */         }
/* 392:360 */         x--;
/* 393:    */       }
/* 394:    */     }
/* 395:    */   }
/* 396:    */   
/* 397:    */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope)
/* 398:    */   {
/* 399:373 */     scope.add(this);
/* 400:    */     try
/* 401:    */     {
/* 402:375 */       int x = 0;
/* 403:375 */       for (int len = this.containedStatements.size(); x < len; x++)
/* 404:    */       {
/* 405:376 */         Op04StructuredStatement structuredBlock = (Op04StructuredStatement)this.containedStatements.get(x);
/* 406:377 */         scope.setNextAtThisLevel(this, x < len - 1 ? x + 1 : -1);
/* 407:378 */         structuredBlock.transform(transformer, scope);
/* 408:    */       }
/* 409:    */     }
/* 410:    */     finally
/* 411:    */     {
/* 412:381 */       scope.remove(this);
/* 413:    */     }
/* 414:    */   }
/* 415:    */   
/* 416:    */   public void transformStructuredChildrenInReverse(StructuredStatementTransformer transformer, StructuredScope scope)
/* 417:    */   {
/* 418:388 */     scope.add(this);
/* 419:    */     try
/* 420:    */     {
/* 421:390 */       int last = this.containedStatements.size() - 1;
/* 422:391 */       for (int x = last; x >= 0; x--)
/* 423:    */       {
/* 424:392 */         Op04StructuredStatement structuredBlock = (Op04StructuredStatement)this.containedStatements.get(x);
/* 425:393 */         scope.setNextAtThisLevel(this, x < last ? x + 1 : -1);
/* 426:394 */         structuredBlock.transform(transformer, scope);
/* 427:    */       }
/* 428:    */     }
/* 429:    */     finally
/* 430:    */     {
/* 431:397 */       scope.remove(this);
/* 432:    */     }
/* 433:    */   }
/* 434:    */   
/* 435:    */   public Set<Op04StructuredStatement> getNextAfter(int x)
/* 436:    */   {
/* 437:402 */     Set<Op04StructuredStatement> res = SetFactory.newSet();
/* 438:403 */     if ((x == -1) || (x > this.containedStatements.size())) {
/* 439:403 */       return res;
/* 440:    */     }
/* 441:404 */     while ((x != -1) && (x < this.containedStatements.size()))
/* 442:    */     {
/* 443:405 */       Op04StructuredStatement next = (Op04StructuredStatement)this.containedStatements.get(x);
/* 444:406 */       res.add(this.containedStatements.get(x));
/* 445:407 */       if (!(next.getStatement() instanceof StructuredComment)) {
/* 446:    */         break;
/* 447:    */       }
/* 448:408 */       x++;
/* 449:    */     }
/* 450:413 */     return res;
/* 451:    */   }
/* 452:    */   
/* 453:    */   public boolean statementIsLast(Op04StructuredStatement needle)
/* 454:    */   {
/* 455:418 */     for (int x = this.containedStatements.size() - 1; x >= 0; x--)
/* 456:    */     {
/* 457:419 */       Op04StructuredStatement statement = (Op04StructuredStatement)this.containedStatements.get(x);
/* 458:420 */       if (statement == needle) {
/* 459:420 */         return true;
/* 460:    */       }
/* 461:421 */       if (!(statement.getStatement() instanceof StructuredComment)) {
/* 462:    */         break;
/* 463:    */       }
/* 464:    */     }
/* 465:424 */     return false;
/* 466:    */   }
/* 467:    */   
/* 468:    */   public BlockIdentifier getBreakableBlockOrNull()
/* 469:    */   {
/* 470:429 */     return (this.blockIdentifier != null) && (this.blockIdentifier.hasForeignReferences()) ? this.blockIdentifier : null;
/* 471:    */   }
/* 472:    */   
/* 473:    */   public boolean isRecursivelyStructured()
/* 474:    */   {
/* 475:434 */     for (Op04StructuredStatement structuredStatement : this.containedStatements) {
/* 476:435 */       if (!structuredStatement.isFullyStructured()) {
/* 477:435 */         return false;
/* 478:    */       }
/* 479:    */     }
/* 480:437 */     return true;
/* 481:    */   }
/* 482:    */   
/* 483:    */   public List<Op04StructuredStatement> getBlockStatements()
/* 484:    */   {
/* 485:441 */     return this.containedStatements;
/* 486:    */   }
/* 487:    */   
/* 488:    */   public void linearizeInto(List<StructuredStatement> out)
/* 489:    */   {
/* 490:446 */     out.add(new BeginBlock(this));
/* 491:447 */     for (Op04StructuredStatement structuredBlock : this.containedStatements) {
/* 492:448 */       structuredBlock.linearizeStatementsInto(out);
/* 493:    */     }
/* 494:450 */     out.add(new EndBlock(this));
/* 495:    */   }
/* 496:    */   
/* 497:    */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer)
/* 498:    */   {
/* 499:455 */     scopeDiscoverer.enterBlock(this);
/* 500:457 */     for (Op04StructuredStatement item : this.containedStatements) {
/* 501:458 */       item.traceLocalVariableScope(scopeDiscoverer);
/* 502:    */     }
/* 503:460 */     scopeDiscoverer.leaveBlock(this);
/* 504:    */   }
/* 505:    */   
/* 506:    */   public void markCreator(LValue scopedEntity)
/* 507:    */   {
/* 508:468 */     this.containedStatements.addFirst(new Op04StructuredStatement(new StructuredDefinition(scopedEntity)));
/* 509:    */   }
/* 510:    */   
/* 511:    */   public boolean alwaysDefines(LValue scopedEntity)
/* 512:    */   {
/* 513:473 */     return false;
/* 514:    */   }
/* 515:    */   
/* 516:    */   public Dumper dump(Dumper d)
/* 517:    */   {
/* 518:478 */     boolean isIndenting = isIndenting();
/* 519:479 */     if (this.blockIdentifier != null) {
/* 520:480 */       if (this.blockIdentifier.hasForeignReferences())
/* 521:    */       {
/* 522:481 */         d.print(this.blockIdentifier.getName() + " : ");
/* 523:482 */         isIndenting = true;
/* 524:    */       }
/* 525:    */       else
/* 526:    */       {
/* 527:484 */         isIndenting = false;
/* 528:    */       }
/* 529:    */     }
/* 530:487 */     if (this.containedStatements.isEmpty())
/* 531:    */     {
/* 532:488 */       if (isIndenting) {
/* 533:489 */         d.print("{}\n");
/* 534:    */       } else {
/* 535:491 */         d.print("\n");
/* 536:    */       }
/* 537:493 */       return d;
/* 538:    */     }
/* 539:    */     try
/* 540:    */     {
/* 541:496 */       if (isIndenting)
/* 542:    */       {
/* 543:497 */         d.print("{\n");
/* 544:498 */         d.indent(1);
/* 545:    */       }
/* 546:500 */       for (Op04StructuredStatement structuredBlock : this.containedStatements) {
/* 547:501 */         structuredBlock.dump(d);
/* 548:    */       }
/* 549:    */     }
/* 550:    */     finally
/* 551:    */     {
/* 552:504 */       if (isIndenting)
/* 553:    */       {
/* 554:505 */         d.indent(-1);
/* 555:506 */         d.print("}");
/* 556:507 */         d.enqueuePendingCarriageReturn();
/* 557:    */       }
/* 558:    */     }
/* 559:510 */     return d;
/* 560:    */   }
/* 561:    */   
/* 562:    */   public boolean isIndenting()
/* 563:    */   {
/* 564:514 */     return this.indenting;
/* 565:    */   }
/* 566:    */   
/* 567:    */   public void setIndenting(boolean indenting)
/* 568:    */   {
/* 569:518 */     this.indenting = indenting;
/* 570:    */   }
/* 571:    */   
/* 572:    */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 573:    */   {
/* 574:523 */     throw new UnsupportedOperationException();
/* 575:    */   }
/* 576:    */   
/* 577:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter) {}
/* 578:    */   
/* 579:    */   public boolean isEffectivelyNOP()
/* 580:    */   {
/* 581:533 */     for (Op04StructuredStatement statement : this.containedStatements) {
/* 582:534 */       if (!statement.getStatement().isEffectivelyNOP()) {
/* 583:534 */         return false;
/* 584:    */       }
/* 585:    */     }
/* 586:536 */     return true;
/* 587:    */   }
/* 588:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.Block
 * JD-Core Version:    0.7.0.1
 */