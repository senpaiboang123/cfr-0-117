/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Set;
/*   5:    */ import java.util.Stack;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Triplet;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  16:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  17:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  18:    */ 
/*  19:    */ public class StructuredBreak
/*  20:    */   extends AbstractStructuredStatement
/*  21:    */ {
/*  22:    */   private final BlockIdentifier breakBlock;
/*  23:    */   private final boolean localBreak;
/*  24:    */   
/*  25:    */   public StructuredBreak(BlockIdentifier breakBlock, boolean localBreak)
/*  26:    */   {
/*  27: 27 */     this.breakBlock = breakBlock;
/*  28: 28 */     this.localBreak = localBreak;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public Dumper dump(Dumper dumper)
/*  32:    */   {
/*  33: 33 */     if (this.localBreak) {
/*  34: 34 */       dumper.print("break;\n");
/*  35:    */     } else {
/*  36: 36 */       dumper.print("break " + this.breakBlock.getName() + ";\n");
/*  37:    */     }
/*  38: 38 */     return dumper;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void collectTypeUsages(TypeUsageCollector collector) {}
/*  42:    */   
/*  43:    */   public BlockIdentifier getBreakBlock()
/*  44:    */   {
/*  45: 46 */     return this.breakBlock;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope) {}
/*  49:    */   
/*  50:    */   public void linearizeInto(List<StructuredStatement> out)
/*  51:    */   {
/*  52: 55 */     out.add(this);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/*  56:    */   {
/*  57: 60 */     StructuredStatement o = (StructuredStatement)matchIterator.getCurrent();
/*  58: 61 */     if (!(o instanceof StructuredBreak)) {
/*  59: 61 */       return false;
/*  60:    */     }
/*  61: 62 */     StructuredBreak other = (StructuredBreak)o;
/*  62: 63 */     if (!this.breakBlock.equals(other.breakBlock)) {
/*  63: 63 */       return false;
/*  64:    */     }
/*  65: 65 */     matchIterator.advance();
/*  66: 66 */     return true;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer) {}
/*  70:    */   
/*  71:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter) {}
/*  72:    */   
/*  73:    */   public StructuredBreak maybeTightenToLocal(Stack<Triplet<StructuredStatement, BlockIdentifier, Set<Op04StructuredStatement>>> scopes)
/*  74:    */   {
/*  75: 78 */     if (this.localBreak) {
/*  76: 78 */       return this;
/*  77:    */     }
/*  78: 83 */     Triplet<StructuredStatement, BlockIdentifier, Set<Op04StructuredStatement>> local = (Triplet)scopes.peek();
/*  79: 84 */     if (local.getSecond() == this.breakBlock) {
/*  80: 86 */       return this;
/*  81:    */     }
/*  82: 88 */     for (int i = scopes.size() - 2; i >= 0; i--)
/*  83:    */     {
/*  84: 89 */       Triplet<StructuredStatement, BlockIdentifier, Set<Op04StructuredStatement>> scope = (Triplet)scopes.get(i);
/*  85: 90 */       if (scope.getSecond() == this.breakBlock)
/*  86:    */       {
/*  87: 92 */         Set<Op04StructuredStatement> localNext = (Set)local.getThird();
/*  88: 93 */         Set<Op04StructuredStatement> actualNext = (Set)scope.getThird();
/*  89: 94 */         if (localNext.containsAll(actualNext))
/*  90:    */         {
/*  91: 95 */           this.breakBlock.releaseForeignRef();
/*  92: 96 */           return new StructuredBreak((BlockIdentifier)local.getSecond(), true);
/*  93:    */         }
/*  94: 98 */         return this;
/*  95:    */       }
/*  96:    */     }
/*  97:102 */     return this;
/*  98:    */   }
/*  99:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredBreak
 * JD-Core Version:    0.7.0.1
 */