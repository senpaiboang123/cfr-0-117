/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  4:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  5:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  6:   */ 
/*  7:   */ public class UnstructuredGoto
/*  8:   */   extends AbstractUnStructuredStatement
/*  9:   */ {
/* 10:   */   public Dumper dump(Dumper dumper)
/* 11:   */   {
/* 12:13 */     return dumper.print("** GOTO " + getContainer().getTargetLabel(0) + "\n");
/* 13:   */   }
/* 14:   */   
/* 15:   */   public void collectTypeUsages(TypeUsageCollector collector) {}
/* 16:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredGoto
 * JD-Core Version:    0.7.0.1
 */