/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  6:   */ 
/*  7:   */ public class ElseBlock
/*  8:   */   extends AbstractPlaceholder
/*  9:   */ {
/* 10:   */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 11:   */   {
/* 12:10 */     if ((matchIterator.getCurrent() instanceof ElseBlock))
/* 13:   */     {
/* 14:11 */       matchIterator.advance();
/* 15:12 */       return true;
/* 16:   */     }
/* 17:14 */     return false;
/* 18:   */   }
/* 19:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.ElseBlock
 * JD-Core Version:    0.7.0.1
 */