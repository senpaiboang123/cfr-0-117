/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 12:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 13:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 14:   */ 
/* 15:   */ public class StructuredThrow
/* 16:   */   extends AbstractStructuredStatement
/* 17:   */ {
/* 18:   */   private Expression value;
/* 19:   */   
/* 20:   */   public StructuredThrow(Expression value)
/* 21:   */   {
/* 22:20 */     this.value = value;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 26:   */   {
/* 27:25 */     this.value.collectTypeUsages(collector);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public Dumper dump(Dumper dumper)
/* 31:   */   {
/* 32:30 */     return dumper.print("throw ").dump(this.value).endCodeln();
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope) {}
/* 36:   */   
/* 37:   */   public void linearizeInto(List<StructuredStatement> out)
/* 38:   */   {
/* 39:39 */     out.add(this);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter)
/* 43:   */   {
/* 44:44 */     this.value = expressionRewriter.rewriteExpression(this.value, null, getContainer(), null);
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer)
/* 48:   */   {
/* 49:49 */     this.value.collectUsedLValues(scopeDiscoverer);
/* 50:   */   }
/* 51:   */   
/* 52:   */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 53:   */   {
/* 54:54 */     StructuredStatement o = (StructuredStatement)matchIterator.getCurrent();
/* 55:55 */     if (!(o instanceof StructuredThrow)) {
/* 56:55 */       return false;
/* 57:   */     }
/* 58:56 */     StructuredThrow other = (StructuredThrow)o;
/* 59:57 */     if (!this.value.equals(other.value)) {
/* 60:57 */       return false;
/* 61:   */     }
/* 62:59 */     matchIterator.advance();
/* 63:60 */     return true;
/* 64:   */   }
/* 65:   */   
/* 66:   */   public boolean equals(Object o)
/* 67:   */   {
/* 68:65 */     if (this == o) {
/* 69:65 */       return true;
/* 70:   */     }
/* 71:66 */     if ((o == null) || (getClass() != o.getClass())) {
/* 72:66 */       return false;
/* 73:   */     }
/* 74:68 */     StructuredThrow that = (StructuredThrow)o;
/* 75:70 */     if (this.value != null ? !this.value.equals(that.value) : that.value != null) {
/* 76:70 */       return false;
/* 77:   */     }
/* 78:72 */     return true;
/* 79:   */   }
/* 80:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredThrow
 * JD-Core Version:    0.7.0.1
 */