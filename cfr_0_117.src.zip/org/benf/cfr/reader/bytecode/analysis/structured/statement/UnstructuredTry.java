/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.Vector;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  7:   */ import org.benf.cfr.reader.entities.exceptions.ExceptionGroup;
/*  8:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  9:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 10:   */ 
/* 11:   */ public class UnstructuredTry
/* 12:   */   extends AbstractUnStructuredStatement
/* 13:   */ {
/* 14:   */   private final ExceptionGroup exceptionGroup;
/* 15:   */   
/* 16:   */   public UnstructuredTry(ExceptionGroup exceptionGroup)
/* 17:   */   {
/* 18:16 */     this.exceptionGroup = exceptionGroup;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public Dumper dump(Dumper dumper)
/* 22:   */   {
/* 23:21 */     return dumper.print("** try " + this.exceptionGroup + " { \n");
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void collectTypeUsages(TypeUsageCollector collector) {}
/* 27:   */   
/* 28:   */   public StructuredStatement getEmptyTry()
/* 29:   */   {
/* 30:29 */     return new StructuredTry(this.exceptionGroup, new Op04StructuredStatement(Block.getEmptyBlock(true)), this.exceptionGroup.getTryBlockIdentifier());
/* 31:   */   }
/* 32:   */   
/* 33:   */   public StructuredStatement claimBlock(Op04StructuredStatement innerBlock, BlockIdentifier blockIdentifier, Vector<BlockIdentifier> blocksCurrentlyIn)
/* 34:   */   {
/* 35:34 */     if (blockIdentifier == this.exceptionGroup.getTryBlockIdentifier()) {
/* 36:35 */       return new StructuredTry(this.exceptionGroup, innerBlock, blockIdentifier);
/* 37:   */     }
/* 38:37 */     return null;
/* 39:   */   }
/* 40:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredTry
 * JD-Core Version:    0.7.0.1
 */