/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  13:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionGroup;
/*  14:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  15:    */ import org.benf.cfr.reader.util.ListFactory;
/*  16:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  17:    */ 
/*  18:    */ public class StructuredTry
/*  19:    */   extends AbstractStructuredStatement
/*  20:    */ {
/*  21:    */   private final ExceptionGroup exceptionGroup;
/*  22:    */   private Op04StructuredStatement tryBlock;
/*  23: 22 */   private List<Op04StructuredStatement> catchBlocks = ListFactory.newList();
/*  24:    */   private Op04StructuredStatement finallyBlock;
/*  25:    */   private final BlockIdentifier tryBlockIdentifier;
/*  26:    */   
/*  27:    */   public StructuredTry(ExceptionGroup exceptionGroup, Op04StructuredStatement tryBlock, BlockIdentifier tryBlockIdentifier)
/*  28:    */   {
/*  29: 27 */     this.exceptionGroup = exceptionGroup;
/*  30: 28 */     this.tryBlock = tryBlock;
/*  31: 29 */     this.finallyBlock = null;
/*  32: 30 */     this.tryBlockIdentifier = tryBlockIdentifier;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public Dumper dump(Dumper dumper)
/*  36:    */   {
/*  37: 35 */     dumper.print("try ");
/*  38: 36 */     this.tryBlock.dump(dumper);
/*  39: 37 */     for (Op04StructuredStatement catchBlock : this.catchBlocks) {
/*  40: 38 */       catchBlock.dump(dumper);
/*  41:    */     }
/*  42: 40 */     if (this.finallyBlock != null) {
/*  43: 41 */       this.finallyBlock.dump(dumper);
/*  44:    */     }
/*  45: 43 */     return dumper;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  49:    */   {
/*  50: 48 */     collector.collectFrom(this.tryBlock);
/*  51: 49 */     collector.collectFrom(this.catchBlocks);
/*  52: 50 */     collector.collectFrom(this.finallyBlock);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public boolean isProperlyStructured()
/*  56:    */   {
/*  57: 55 */     return true;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public boolean fallsNopToNext()
/*  61:    */   {
/*  62: 60 */     return true;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void addCatch(Op04StructuredStatement catchStatement)
/*  66:    */   {
/*  67: 64 */     this.catchBlocks.add(catchStatement);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public void addFinally(Op04StructuredStatement finallyBlock)
/*  71:    */   {
/*  72: 68 */     this.finallyBlock = finallyBlock;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void removeFinalJumpsTo(Op04StructuredStatement after)
/*  76:    */   {
/*  77: 72 */     this.tryBlock.removeLastGoto(after);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope)
/*  81:    */   {
/*  82: 77 */     scope.add(this);
/*  83:    */     try
/*  84:    */     {
/*  85: 79 */       this.tryBlock.transform(transformer, scope);
/*  86: 80 */       for (Op04StructuredStatement catchBlock : this.catchBlocks) {
/*  87: 81 */         catchBlock.getStatement().transformStructuredChildren(transformer, scope);
/*  88:    */       }
/*  89: 83 */       if (this.finallyBlock != null) {
/*  90: 84 */         this.finallyBlock.getStatement().transformStructuredChildren(transformer, scope);
/*  91:    */       }
/*  92:    */     }
/*  93:    */     finally
/*  94:    */     {
/*  95: 87 */       scope.remove(this);
/*  96:    */     }
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void linearizeInto(List<StructuredStatement> out)
/* 100:    */   {
/* 101: 93 */     out.add(this);
/* 102: 94 */     this.tryBlock.linearizeStatementsInto(out);
/* 103: 95 */     for (Op04StructuredStatement catchBlock : this.catchBlocks) {
/* 104: 96 */       catchBlock.linearizeStatementsInto(out);
/* 105:    */     }
/* 106: 98 */     if (this.finallyBlock != null) {
/* 107: 99 */       this.finallyBlock.linearizeStatementsInto(out);
/* 108:    */     }
/* 109:    */   }
/* 110:    */   
/* 111:    */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer)
/* 112:    */   {
/* 113:106 */     this.tryBlock.traceLocalVariableScope(scopeDiscoverer);
/* 114:107 */     for (Op04StructuredStatement catchBlock : this.catchBlocks) {
/* 115:108 */       catchBlock.traceLocalVariableScope(scopeDiscoverer);
/* 116:    */     }
/* 117:110 */     if (this.finallyBlock != null) {
/* 118:111 */       this.finallyBlock.traceLocalVariableScope(scopeDiscoverer);
/* 119:    */     }
/* 120:    */   }
/* 121:    */   
/* 122:    */   public boolean isRecursivelyStructured()
/* 123:    */   {
/* 124:117 */     if (!this.tryBlock.isFullyStructured()) {
/* 125:117 */       return false;
/* 126:    */     }
/* 127:118 */     for (Op04StructuredStatement catchBlock : this.catchBlocks) {
/* 128:119 */       if (!catchBlock.isFullyStructured()) {
/* 129:119 */         return false;
/* 130:    */       }
/* 131:    */     }
/* 132:121 */     if ((this.finallyBlock != null) && 
/* 133:122 */       (!this.finallyBlock.isFullyStructured())) {
/* 134:122 */       return false;
/* 135:    */     }
/* 136:124 */     return true;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 140:    */   {
/* 141:129 */     StructuredStatement o = (StructuredStatement)matchIterator.getCurrent();
/* 142:130 */     if (!(o instanceof StructuredTry)) {
/* 143:130 */       return false;
/* 144:    */     }
/* 145:131 */     StructuredTry other = (StructuredTry)o;
/* 146:    */     
/* 147:133 */     matchIterator.advance();
/* 148:134 */     return true;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter) {}
/* 152:    */   
/* 153:    */   private boolean isPointlessTry()
/* 154:    */   {
/* 155:142 */     if (!this.catchBlocks.isEmpty()) {
/* 156:142 */       return false;
/* 157:    */     }
/* 158:143 */     if (this.finallyBlock == null) {
/* 159:143 */       return true;
/* 160:    */     }
/* 161:145 */     if (!(this.finallyBlock.getStatement() instanceof StructuredFinally)) {
/* 162:145 */       return false;
/* 163:    */     }
/* 164:146 */     StructuredFinally structuredFinally = (StructuredFinally)this.finallyBlock.getStatement();
/* 165:147 */     Op04StructuredStatement finallyCode = structuredFinally.getCatchBlock();
/* 166:148 */     if (!(finallyCode.getStatement() instanceof Block)) {
/* 167:148 */       return false;
/* 168:    */     }
/* 169:149 */     Block block = (Block)finallyCode.getStatement();
/* 170:150 */     if (block.isEffectivelyNOP()) {
/* 171:150 */       return true;
/* 172:    */     }
/* 173:151 */     return false;
/* 174:    */   }
/* 175:    */   
/* 176:    */   private boolean isJustTryCatchThrow()
/* 177:    */   {
/* 178:155 */     if (this.finallyBlock != null) {
/* 179:155 */       return false;
/* 180:    */     }
/* 181:156 */     if (this.catchBlocks.size() != 1) {
/* 182:156 */       return false;
/* 183:    */     }
/* 184:157 */     Op04StructuredStatement catchBlock = (Op04StructuredStatement)this.catchBlocks.get(0);
/* 185:158 */     StructuredStatement catchS = catchBlock.getStatement();
/* 186:159 */     if (!(catchS instanceof StructuredCatch)) {
/* 187:159 */       return false;
/* 188:    */     }
/* 189:160 */     StructuredCatch structuredCatch = (StructuredCatch)catchS;
/* 190:161 */     return structuredCatch.isRethrow();
/* 191:    */   }
/* 192:    */   
/* 193:    */   public boolean inlineable()
/* 194:    */   {
/* 195:168 */     if ((isPointlessTry()) || (isJustTryCatchThrow())) {
/* 196:169 */       return true;
/* 197:    */     }
/* 198:171 */     return false;
/* 199:    */   }
/* 200:    */   
/* 201:    */   public BlockIdentifier getTryBlockIdentifier()
/* 202:    */   {
/* 203:176 */     return this.tryBlockIdentifier;
/* 204:    */   }
/* 205:    */   
/* 206:    */   public Op04StructuredStatement getInline()
/* 207:    */   {
/* 208:181 */     return this.tryBlock;
/* 209:    */   }
/* 210:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredTry
 * JD-Core Version:    0.7.0.1
 */