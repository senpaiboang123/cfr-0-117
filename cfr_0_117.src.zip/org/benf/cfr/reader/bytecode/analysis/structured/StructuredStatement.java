package org.benf.cfr.reader.bytecode.analysis.structured;

import java.util.List;
import java.util.Vector;
import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.Matcher;
import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
import org.benf.cfr.reader.util.Predicate;
import org.benf.cfr.reader.util.TypeUsageCollectable;
import org.benf.cfr.reader.util.output.Dumpable;

public abstract interface StructuredStatement
  extends Dumpable, TypeUsageCollectable, Matcher<StructuredStatement>
{
  public abstract Op04StructuredStatement getContainer();
  
  public abstract void setContainer(Op04StructuredStatement paramOp04StructuredStatement);
  
  public abstract StructuredStatement claimBlock(Op04StructuredStatement paramOp04StructuredStatement, BlockIdentifier paramBlockIdentifier, Vector<BlockIdentifier> paramVector);
  
  public abstract StructuredStatement informBlockHeirachy(Vector<BlockIdentifier> paramVector);
  
  public abstract void transformStructuredChildren(StructuredStatementTransformer paramStructuredStatementTransformer, StructuredScope paramStructuredScope);
  
  public abstract void transformStructuredChildrenInReverse(StructuredStatementTransformer paramStructuredStatementTransformer, StructuredScope paramStructuredScope);
  
  public abstract void rewriteExpressions(ExpressionRewriter paramExpressionRewriter);
  
  public abstract boolean isProperlyStructured();
  
  public abstract boolean isRecursivelyStructured();
  
  public abstract BlockIdentifier getBreakableBlockOrNull();
  
  public abstract void linearizeInto(List<StructuredStatement> paramList);
  
  public abstract void traceLocalVariableScope(LValueScopeDiscoverer paramLValueScopeDiscoverer);
  
  public abstract void markCreator(LValue paramLValue);
  
  public abstract boolean alwaysDefines(LValue paramLValue);
  
  public abstract boolean canDefine(LValue paramLValue);
  
  public abstract boolean inlineable();
  
  public abstract Op04StructuredStatement getInline();
  
  public abstract boolean isEffectivelyNOP();
  
  public abstract boolean fallsNopToNext();
  
  public abstract List<LValue> findCreatedHere();
  
  public abstract String suggestName(LocalVariable paramLocalVariable, Predicate<String> paramPredicate);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement
 * JD-Core Version:    0.7.0.1
 */