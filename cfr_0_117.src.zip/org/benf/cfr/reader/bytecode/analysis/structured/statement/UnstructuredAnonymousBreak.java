/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.Vector;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  6:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  7:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  8:   */ 
/*  9:   */ public class UnstructuredAnonymousBreak
/* 10:   */   extends AbstractUnStructuredStatement
/* 11:   */ {
/* 12:   */   private final BlockIdentifier blockEnding;
/* 13:   */   
/* 14:   */   public UnstructuredAnonymousBreak(BlockIdentifier blockEnding)
/* 15:   */   {
/* 16:16 */     this.blockEnding = blockEnding;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public Dumper dump(Dumper dumper)
/* 20:   */   {
/* 21:21 */     return dumper.print("** break ").print(this.blockEnding.getName()).print("\n");
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void collectTypeUsages(TypeUsageCollector collector) {}
/* 25:   */   
/* 26:   */   public StructuredStatement informBlockHeirachy(Vector<BlockIdentifier> blockIdentifiers)
/* 27:   */   {
/* 28:30 */     return null;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public StructuredStatement tryExplicitlyPlaceInBlock(BlockIdentifier block)
/* 32:   */   {
/* 33:34 */     if (block != this.blockEnding) {
/* 34:35 */       return this;
/* 35:   */     }
/* 36:37 */     block.addForeignRef();
/* 37:38 */     return new StructuredBreak(block, false);
/* 38:   */   }
/* 39:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredAnonymousBreak
 * JD-Core Version:    0.7.0.1
 */