/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.LinkedList;
/*  4:   */ import java.util.Set;
/*  5:   */ import java.util.Vector;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 10:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 11:   */ import org.benf.cfr.reader.util.ListFactory;
/* 12:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 13:   */ 
/* 14:   */ public class UnstructuredWhile
/* 15:   */   extends AbstractUnStructuredStatement
/* 16:   */ {
/* 17:   */   private ConditionalExpression condition;
/* 18:   */   private BlockIdentifier blockIdentifier;
/* 19:   */   private Set<BlockIdentifier> blocksEndedAfter;
/* 20:   */   
/* 21:   */   public UnstructuredWhile(ConditionalExpression condition, BlockIdentifier blockIdentifier, Set<BlockIdentifier> blocksEndedAfter)
/* 22:   */   {
/* 23:23 */     this.condition = condition;
/* 24:24 */     this.blockIdentifier = blockIdentifier;
/* 25:   */     
/* 26:   */ 
/* 27:27 */     this.blocksEndedAfter = blocksEndedAfter;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public Dumper dump(Dumper dumper)
/* 31:   */   {
/* 32:32 */     dumper.print("** while (");
/* 33:33 */     if (this.condition == null) {
/* 34:34 */       dumper.print("true");
/* 35:   */     } else {
/* 36:36 */       dumper.dump(this.condition);
/* 37:   */     }
/* 38:38 */     return dumper.print(")\n");
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 42:   */   {
/* 43:43 */     collector.collectFrom(this.condition);
/* 44:   */   }
/* 45:   */   
/* 46:   */   public StructuredStatement informBlockHeirachy(Vector<BlockIdentifier> blockIdentifiers)
/* 47:   */   {
/* 48:48 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$parse$utils$BlockType[this.blockIdentifier.getBlockType().ordinal()])
/* 49:   */     {
/* 50:   */     case 1: 
/* 51:   */     case 2: 
/* 52:   */       break;
/* 53:   */     default: 
/* 54:53 */       return null;
/* 55:   */     }
/* 56:55 */     if (blockIdentifiers.isEmpty()) {
/* 57:55 */       return null;
/* 58:   */     }
/* 59:56 */     if (this.blockIdentifier != blockIdentifiers.get(blockIdentifiers.size() - 1))
/* 60:   */     {
/* 61:60 */       StructuredStatement res = new UnstructuredContinue(this.blockIdentifier);
/* 62:61 */       StructuredStatement resInform = res.informBlockHeirachy(blockIdentifiers);
/* 63:62 */       if (resInform != null) {
/* 64:62 */         res = resInform;
/* 65:   */       }
/* 66:64 */       if (this.condition == null) {
/* 67:64 */         return res;
/* 68:   */       }
/* 69:66 */       StructuredIf fakeIf = new StructuredIf(this.condition, new Op04StructuredStatement(res));
/* 70:67 */       return fakeIf;
/* 71:   */     }
/* 72:69 */     return null;
/* 73:   */   }
/* 74:   */   
/* 75:   */   public StructuredStatement claimBlock(Op04StructuredStatement innerBlock, BlockIdentifier blockIdentifier, Vector<BlockIdentifier> blocksCurrentlyIn)
/* 76:   */   {
/* 77:74 */     if (blockIdentifier != this.blockIdentifier) {
/* 78:75 */       throw new RuntimeException("While statement claiming wrong block");
/* 79:   */     }
/* 80:77 */     innerBlock.removeLastContinue(blockIdentifier);
/* 81:   */     
/* 82:   */ 
/* 83:   */ 
/* 84:81 */     StructuredStatement whileLoop = new StructuredWhile(this.condition, innerBlock, blockIdentifier);
/* 85:   */     
/* 86:83 */     BlockIdentifier externalBreak = BlockIdentifier.getOutermostEnding(blocksCurrentlyIn, this.blocksEndedAfter);
/* 87:84 */     if (externalBreak == null) {
/* 88:85 */       return whileLoop;
/* 89:   */     }
/* 90:89 */     LinkedList<Op04StructuredStatement> lst = ListFactory.newLinkedList();
/* 91:90 */     lst.add(new Op04StructuredStatement(whileLoop));
/* 92:91 */     lst.add(new Op04StructuredStatement(new StructuredBreak(externalBreak, false)));
/* 93:92 */     return new Block(lst, false);
/* 94:   */   }
/* 95:   */   
/* 96:   */   public ConditionalExpression getCondition()
/* 97:   */   {
/* 98:98 */     return this.condition;
/* 99:   */   }
/* :0:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredWhile
 * JD-Core Version:    0.7.0.1
 */