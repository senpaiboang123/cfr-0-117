/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Vector;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  14:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  15:    */ import org.benf.cfr.reader.util.Predicate;
/*  16:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  17:    */ 
/*  18:    */ public abstract class AbstractPlaceholder
/*  19:    */   implements StructuredStatement
/*  20:    */ {
/*  21:    */   public void linearizeInto(List<StructuredStatement> out)
/*  22:    */   {
/*  23: 22 */     throw new UnsupportedOperationException();
/*  24:    */   }
/*  25:    */   
/*  26:    */   public void collectTypeUsages(TypeUsageCollector collector) {}
/*  27:    */   
/*  28:    */   public boolean isProperlyStructured()
/*  29:    */   {
/*  30: 31 */     return false;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public boolean isRecursivelyStructured()
/*  34:    */   {
/*  35: 36 */     return false;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public BlockIdentifier getBreakableBlockOrNull()
/*  39:    */   {
/*  40: 41 */     return null;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public boolean fallsNopToNext()
/*  44:    */   {
/*  45: 46 */     return false;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope)
/*  49:    */   {
/*  50: 51 */     throw new UnsupportedOperationException();
/*  51:    */   }
/*  52:    */   
/*  53:    */   public void transformStructuredChildrenInReverse(StructuredStatementTransformer transformer, StructuredScope scope)
/*  54:    */   {
/*  55: 56 */     throw new UnsupportedOperationException();
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter) {}
/*  59:    */   
/*  60:    */   public StructuredStatement informBlockHeirachy(Vector<BlockIdentifier> blockIdentifiers)
/*  61:    */   {
/*  62: 65 */     throw new UnsupportedOperationException();
/*  63:    */   }
/*  64:    */   
/*  65:    */   public StructuredStatement claimBlock(Op04StructuredStatement innerBlock, BlockIdentifier blockIdentifier, Vector<BlockIdentifier> blocksCurrentlyIn)
/*  66:    */   {
/*  67: 70 */     throw new UnsupportedOperationException();
/*  68:    */   }
/*  69:    */   
/*  70:    */   public Op04StructuredStatement getContainer()
/*  71:    */   {
/*  72: 75 */     throw new UnsupportedOperationException();
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void setContainer(Op04StructuredStatement container)
/*  76:    */   {
/*  77: 80 */     throw new UnsupportedOperationException();
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer)
/*  81:    */   {
/*  82: 86 */     throw new UnsupportedOperationException();
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void markCreator(LValue scopedEntity)
/*  86:    */   {
/*  87: 91 */     throw new UnsupportedOperationException();
/*  88:    */   }
/*  89:    */   
/*  90:    */   public boolean alwaysDefines(LValue scopedEntity)
/*  91:    */   {
/*  92: 96 */     return false;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public boolean canDefine(LValue scopedEntity)
/*  96:    */   {
/*  97:101 */     return false;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public List<LValue> findCreatedHere()
/* 101:    */   {
/* 102:106 */     return null;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public String suggestName(LocalVariable createdHere, Predicate<String> testNameUsedFn)
/* 106:    */   {
/* 107:111 */     throw new UnsupportedOperationException();
/* 108:    */   }
/* 109:    */   
/* 110:    */   public Dumper dump(Dumper dumper)
/* 111:    */   {
/* 112:116 */     return dumper;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public boolean inlineable()
/* 116:    */   {
/* 117:121 */     throw new UnsupportedOperationException();
/* 118:    */   }
/* 119:    */   
/* 120:    */   public Op04StructuredStatement getInline()
/* 121:    */   {
/* 122:126 */     throw new UnsupportedOperationException();
/* 123:    */   }
/* 124:    */   
/* 125:    */   public boolean isEffectivelyNOP()
/* 126:    */   {
/* 127:131 */     throw new UnsupportedOperationException();
/* 128:    */   }
/* 129:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.AbstractPlaceholder
 * JD-Core Version:    0.7.0.1
 */