/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 12:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 13:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 14:   */ 
/* 15:   */ public class StructuredComment
/* 16:   */   extends AbstractStructuredStatement
/* 17:   */ {
/* 18:   */   private Expression expression;
/* 19:   */   
/* 20:   */   public StructuredComment(Expression expression)
/* 21:   */   {
/* 22:20 */     this.expression = expression;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public StructuredComment(String text)
/* 26:   */   {
/* 27:24 */     this.expression = new Literal(TypedLiteral.getString(text));
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void collectTypeUsages(TypeUsageCollector collector) {}
/* 31:   */   
/* 32:   */   public Dumper dump(Dumper dumper)
/* 33:   */   {
/* 34:33 */     String comment = this.expression.toString();
/* 35:34 */     if (comment.length() > 0)
/* 36:   */     {
/* 37:35 */       dumper.print("// ");
/* 38:36 */       dumper.print(comment + "\n");
/* 39:   */     }
/* 40:39 */     return dumper;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer) {}
/* 44:   */   
/* 45:   */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope) {}
/* 46:   */   
/* 47:   */   public void linearizeInto(List<StructuredStatement> out) {}
/* 48:   */   
/* 49:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter) {}
/* 50:   */   
/* 51:   */   public boolean isEffectivelyNOP()
/* 52:   */   {
/* 53:61 */     return true;
/* 54:   */   }
/* 55:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredComment
 * JD-Core Version:    0.7.0.1
 */