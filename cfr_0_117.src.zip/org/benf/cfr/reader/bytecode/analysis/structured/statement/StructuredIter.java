/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue.Creation;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  17:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  18:    */ import org.benf.cfr.reader.util.ListFactory;
/*  19:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  20:    */ 
/*  21:    */ public class StructuredIter
/*  22:    */   extends AbstractStructuredBlockStatement
/*  23:    */ {
/*  24:    */   private final BlockIdentifier block;
/*  25:    */   private LValue iterator;
/*  26:    */   private Expression list;
/*  27:    */   private boolean creator;
/*  28:    */   
/*  29:    */   public StructuredIter(BlockIdentifier block, LValue iterator, Expression list, Op04StructuredStatement body)
/*  30:    */   {
/*  31: 27 */     super(body);
/*  32: 28 */     this.block = block;
/*  33: 29 */     this.iterator = iterator;
/*  34: 30 */     this.list = list;
/*  35: 31 */     this.creator = false;
/*  36:    */     
/*  37:    */ 
/*  38:    */ 
/*  39: 35 */     JavaTypeInstance itertype = iterator.getInferredJavaType().getJavaTypeInstance();
/*  40: 36 */     if (!itertype.isUsableType()) {}
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  44:    */   {
/*  45: 43 */     this.iterator.collectTypeUsages(collector);
/*  46: 44 */     this.list.collectTypeUsages(collector);
/*  47: 45 */     super.collectTypeUsages(collector);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public Dumper dump(Dumper dumper)
/*  51:    */   {
/*  52: 50 */     if (this.block.hasForeignReferences()) {
/*  53: 50 */       dumper.print(this.block.getName() + " : ");
/*  54:    */     }
/*  55: 51 */     dumper.print("for (");
/*  56: 52 */     if (this.iterator.isFinal()) {
/*  57: 52 */       dumper.print("final ");
/*  58:    */     }
/*  59: 53 */     LValue.Creation.dump(dumper, this.iterator).print(" ");
/*  60: 54 */     dumper.dump(this.iterator).print(" : ").dump(this.list).print(") ");
/*  61: 55 */     getBody().dump(dumper);
/*  62: 56 */     return dumper;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope)
/*  66:    */   {
/*  67: 61 */     scope.add(this);
/*  68:    */     try
/*  69:    */     {
/*  70: 63 */       getBody().transform(transformer, scope);
/*  71:    */     }
/*  72:    */     finally
/*  73:    */     {
/*  74: 65 */       scope.remove(this);
/*  75:    */     }
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void linearizeInto(List<StructuredStatement> out)
/*  79:    */   {
/*  80: 71 */     out.add(this);
/*  81: 72 */     getBody().linearizeStatementsInto(out);
/*  82:    */   }
/*  83:    */   
/*  84:    */   public BlockIdentifier getBreakableBlockOrNull()
/*  85:    */   {
/*  86: 77 */     return this.block;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer)
/*  90:    */   {
/*  91: 84 */     scopeDiscoverer.enterBlock(this);
/*  92: 85 */     this.list.collectUsedLValues(scopeDiscoverer);
/*  93: 86 */     this.iterator.collectLValueAssignments(null, getContainer(), scopeDiscoverer);
/*  94: 87 */     getBody().traceLocalVariableScope(scopeDiscoverer);
/*  95: 88 */     scopeDiscoverer.leaveBlock(this);
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void markCreator(LValue scopedEntity)
/*  99:    */   {
/* 100: 94 */     this.creator = true;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public boolean alwaysDefines(LValue scopedEntity)
/* 104:    */   {
/* 105: 99 */     if (scopedEntity == null) {
/* 106: 99 */       return false;
/* 107:    */     }
/* 108:100 */     return scopedEntity.equals(this.iterator);
/* 109:    */   }
/* 110:    */   
/* 111:    */   public boolean canDefine(LValue scopedEntity)
/* 112:    */   {
/* 113:105 */     if (scopedEntity == null) {
/* 114:105 */       return false;
/* 115:    */     }
/* 116:106 */     return scopedEntity.equals(this.iterator);
/* 117:    */   }
/* 118:    */   
/* 119:    */   public List<LValue> findCreatedHere()
/* 120:    */   {
/* 121:111 */     if (!(this.iterator instanceof LocalVariable)) {
/* 122:111 */       return null;
/* 123:    */     }
/* 124:112 */     return ListFactory.newList(new LValue[] { this.iterator });
/* 125:    */   }
/* 126:    */   
/* 127:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter)
/* 128:    */   {
/* 129:118 */     this.iterator = expressionRewriter.rewriteExpression(this.iterator, null, getContainer(), null);
/* 130:119 */     this.list = expressionRewriter.rewriteExpression(this.list, null, getContainer(), null);
/* 131:    */   }
/* 132:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredIter
 * JD-Core Version:    0.7.0.1
 */