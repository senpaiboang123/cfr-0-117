/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StaticVariable;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  21:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  22:    */ import org.benf.cfr.reader.util.annotation.Nullable;
/*  23:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  24:    */ 
/*  25:    */ public class StructuredCase
/*  26:    */   extends AbstractStructuredBlockStatement
/*  27:    */ {
/*  28:    */   private List<Expression> values;
/*  29:    */   private final BlockIdentifier blockIdentifier;
/*  30:    */   @Nullable
/*  31:    */   private final InferredJavaType inferredJavaTypeOfSwitch;
/*  32:    */   private final boolean enumSwitch;
/*  33:    */   
/*  34:    */   public StructuredCase(List<Expression> values, InferredJavaType inferredJavaTypeOfSwitch, Op04StructuredStatement body, BlockIdentifier blockIdentifier)
/*  35:    */   {
/*  36: 36 */     this(values, inferredJavaTypeOfSwitch, body, blockIdentifier, false);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public StructuredCase(List<Expression> values, InferredJavaType inferredJavaTypeOfSwitch, Op04StructuredStatement body, BlockIdentifier blockIdentifier, boolean enumSwitch)
/*  40:    */   {
/*  41: 40 */     super(body);
/*  42: 41 */     this.blockIdentifier = blockIdentifier;
/*  43: 42 */     this.enumSwitch = enumSwitch;
/*  44: 43 */     this.inferredJavaTypeOfSwitch = inferredJavaTypeOfSwitch;
/*  45: 44 */     if ((inferredJavaTypeOfSwitch != null) && (inferredJavaTypeOfSwitch.getJavaTypeInstance() == RawJavaType.CHAR)) {
/*  46: 45 */       for (Expression value : values) {
/*  47: 46 */         if ((value instanceof Literal))
/*  48:    */         {
/*  49: 47 */           TypedLiteral typedLiteral = ((Literal)value).getValue();
/*  50: 48 */           typedLiteral.getInferredJavaType().useAsWithoutCasting(inferredJavaTypeOfSwitch.getJavaTypeInstance());
/*  51:    */         }
/*  52:    */       }
/*  53:    */     }
/*  54: 52 */     this.values = values;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  58:    */   {
/*  59: 57 */     if (this.inferredJavaTypeOfSwitch != null) {
/*  60: 57 */       collector.collect(this.inferredJavaTypeOfSwitch.getJavaTypeInstance());
/*  61:    */     }
/*  62: 58 */     collector.collectFrom(this.values);
/*  63: 59 */     super.collectTypeUsages(collector);
/*  64:    */   }
/*  65:    */   
/*  66:    */   private static StaticVariable getEnumStatic(Expression expression)
/*  67:    */   {
/*  68: 63 */     if (!(expression instanceof LValueExpression)) {
/*  69: 63 */       return null;
/*  70:    */     }
/*  71: 64 */     LValue lValue = ((LValueExpression)expression).getLValue();
/*  72: 65 */     if (!(lValue instanceof StaticVariable)) {
/*  73: 65 */       return null;
/*  74:    */     }
/*  75: 66 */     return (StaticVariable)lValue;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public Dumper dump(Dumper dumper)
/*  79:    */   {
/*  80: 71 */     if (this.values.isEmpty())
/*  81:    */     {
/*  82: 72 */       dumper.print("default: ");
/*  83:    */     }
/*  84:    */     else
/*  85:    */     {
/*  86: 74 */       int x = 0;int len = this.values.size();
/*  87: 74 */       for (int last = len - 1; x < len; x++)
/*  88:    */       {
/*  89: 75 */         Expression value = (Expression)this.values.get(x);
/*  90: 76 */         if (this.enumSwitch)
/*  91:    */         {
/*  92: 79 */           StaticVariable enumStatic = getEnumStatic(value);
/*  93: 80 */           if (enumStatic != null)
/*  94:    */           {
/*  95: 81 */             dumper.print("case " + enumStatic.getFieldName() + ": ");
/*  96: 82 */             if (x == last) {
/*  97:    */               continue;
/*  98:    */             }
/*  99: 82 */             dumper.newln(); continue;
/* 100:    */           }
/* 101:    */         }
/* 102: 86 */         dumper.print("case ").dump(value).print(": ");
/* 103: 87 */         if (x != last) {
/* 104: 87 */           dumper.newln();
/* 105:    */         }
/* 106:    */       }
/* 107:    */     }
/* 108: 90 */     getBody().dump(dumper);
/* 109: 91 */     return dumper;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public boolean isProperlyStructured()
/* 113:    */   {
/* 114: 96 */     return true;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public List<Expression> getValues()
/* 118:    */   {
/* 119:100 */     return this.values;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public Op04StructuredStatement getBody()
/* 123:    */   {
/* 124:104 */     return super.getBody();
/* 125:    */   }
/* 126:    */   
/* 127:    */   public BlockIdentifier getBlockIdentifier()
/* 128:    */   {
/* 129:108 */     return this.blockIdentifier;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope)
/* 133:    */   {
/* 134:113 */     getBody().transform(transformer, scope);
/* 135:    */   }
/* 136:    */   
/* 137:    */   public void linearizeInto(List<StructuredStatement> out)
/* 138:    */   {
/* 139:118 */     out.add(this);
/* 140:119 */     getBody().linearizeStatementsInto(out);
/* 141:    */   }
/* 142:    */   
/* 143:    */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer)
/* 144:    */   {
/* 145:124 */     for (Expression expression : this.values) {
/* 146:125 */       expression.collectUsedLValues(scopeDiscoverer);
/* 147:    */     }
/* 148:128 */     getBody().traceLocalVariableScope(scopeDiscoverer);
/* 149:    */   }
/* 150:    */   
/* 151:    */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 152:    */   {
/* 153:133 */     StructuredStatement o = (StructuredStatement)matchIterator.getCurrent();
/* 154:134 */     if (!(o instanceof StructuredCase)) {
/* 155:134 */       return false;
/* 156:    */     }
/* 157:135 */     StructuredCase other = (StructuredCase)o;
/* 158:136 */     if (!this.values.equals(other.values)) {
/* 159:136 */       return false;
/* 160:    */     }
/* 161:137 */     if (!this.blockIdentifier.equals(other.blockIdentifier)) {
/* 162:137 */       return false;
/* 163:    */     }
/* 164:138 */     matchIterator.advance();
/* 165:139 */     return true;
/* 166:    */   }
/* 167:    */   
/* 168:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter) {}
/* 169:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredCase
 * JD-Core Version:    0.7.0.1
 */