/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Vector;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.InstrIndex;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 11:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 12:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/* 13:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 14:   */ 
/* 15:   */ public class UnstructuredCase
/* 16:   */   extends AbstractUnStructuredStatement
/* 17:   */ {
/* 18:   */   private final List<Expression> values;
/* 19:   */   private final BlockIdentifier blockIdentifier;
/* 20:   */   private final InferredJavaType caseType;
/* 21:   */   
/* 22:   */   public UnstructuredCase(List<Expression> values, InferredJavaType caseType, BlockIdentifier blockIdentifier)
/* 23:   */   {
/* 24:21 */     this.values = values;
/* 25:22 */     this.caseType = caseType;
/* 26:23 */     this.blockIdentifier = blockIdentifier;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public Dumper dump(Dumper dumper)
/* 30:   */   {
/* 31:28 */     if (this.values.isEmpty()) {
/* 32:29 */       dumper.print("** default:\n");
/* 33:   */     } else {
/* 34:31 */       for (Expression value : this.values) {
/* 35:32 */         dumper.print("** case ").dump(value).print(":\n");
/* 36:   */       }
/* 37:   */     }
/* 38:35 */     return dumper;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 42:   */   {
/* 43:40 */     collector.collectFrom(this.values);
/* 44:41 */     collector.collect(this.caseType.getJavaTypeInstance());
/* 45:   */   }
/* 46:   */   
/* 47:   */   public StructuredStatement getEmptyStructuredCase()
/* 48:   */   {
/* 49:45 */     Op04StructuredStatement container = getContainer();
/* 50:46 */     return new StructuredCase(this.values, this.caseType, new Op04StructuredStatement(container.getIndex().justAfter(), container.getBlockMembership(), Block.getEmptyBlock()), this.blockIdentifier);
/* 51:   */   }
/* 52:   */   
/* 53:   */   public StructuredStatement claimBlock(Op04StructuredStatement innerBlock, BlockIdentifier blockIdentifier, Vector<BlockIdentifier> blocksCurrentlyIn)
/* 54:   */   {
/* 55:56 */     if (blockIdentifier != this.blockIdentifier) {
/* 56:57 */       throw new ConfusedCFRException("Unstructured case being asked to claim wrong block. [" + blockIdentifier + " != " + this.blockIdentifier + "]");
/* 57:   */     }
/* 58:59 */     return new StructuredCase(this.values, this.caseType, innerBlock, blockIdentifier);
/* 59:   */   }
/* 60:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredCase
 * JD-Core Version:    0.7.0.1
 */