/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Vector;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractAssignmentExpression;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.AssignmentSimple;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 11:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 12:   */ import org.benf.cfr.reader.util.StringUtils;
/* 13:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 14:   */ 
/* 15:   */ public class UnstructuredFor
/* 16:   */   extends AbstractUnStructuredStatement
/* 17:   */ {
/* 18:   */   private ConditionalExpression condition;
/* 19:   */   private BlockIdentifier blockIdentifier;
/* 20:   */   private AssignmentSimple initial;
/* 21:   */   private List<AbstractAssignmentExpression> assignments;
/* 22:   */   
/* 23:   */   public UnstructuredFor(ConditionalExpression condition, BlockIdentifier blockIdentifier, AssignmentSimple initial, List<AbstractAssignmentExpression> assignments)
/* 24:   */   {
/* 25:23 */     this.condition = condition;
/* 26:24 */     this.blockIdentifier = blockIdentifier;
/* 27:25 */     this.initial = initial;
/* 28:26 */     this.assignments = assignments;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 32:   */   {
/* 33:31 */     collector.collectFrom(this.condition);
/* 34:32 */     collector.collectFrom(this.assignments);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public Dumper dump(Dumper dumper)
/* 38:   */   {
/* 39:38 */     dumper.print("** for (").dump(this.initial).print("; ").dump(this.condition).print("; ");
/* 40:39 */     boolean first = true;
/* 41:40 */     for (AbstractAssignmentExpression assignment : this.assignments)
/* 42:   */     {
/* 43:41 */       first = StringUtils.comma(first, dumper);
/* 44:42 */       dumper.dump(assignment);
/* 45:   */     }
/* 46:44 */     return dumper.print(")\n");
/* 47:   */   }
/* 48:   */   
/* 49:   */   public StructuredStatement claimBlock(Op04StructuredStatement innerBlock, BlockIdentifier blockIdentifier, Vector<BlockIdentifier> blocksCurrentlyIn)
/* 50:   */   {
/* 51:49 */     if (blockIdentifier != this.blockIdentifier) {
/* 52:50 */       throw new RuntimeException("For statement claiming wrong block");
/* 53:   */     }
/* 54:52 */     innerBlock.removeLastContinue(blockIdentifier);
/* 55:53 */     return new StructuredFor(this.condition, this.initial, this.assignments, innerBlock, blockIdentifier);
/* 56:   */   }
/* 57:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredFor
 * JD-Core Version:    0.7.0.1
 */