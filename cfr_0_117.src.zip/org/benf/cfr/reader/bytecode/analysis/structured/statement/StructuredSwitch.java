/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.PrimitiveBoxingRewriter;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface.BoxingProcessor;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  19:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  20:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  21:    */ 
/*  22:    */ public class StructuredSwitch
/*  23:    */   extends AbstractStructuredBlockStatement
/*  24:    */   implements BoxingProcessor
/*  25:    */ {
/*  26:    */   private Expression switchOn;
/*  27:    */   private final BlockIdentifier blockIdentifier;
/*  28:    */   
/*  29:    */   public StructuredSwitch(Expression switchOn, Op04StructuredStatement body, BlockIdentifier blockIdentifier)
/*  30:    */   {
/*  31: 28 */     super(body);
/*  32: 29 */     this.switchOn = switchOn;
/*  33: 30 */     this.blockIdentifier = blockIdentifier;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  37:    */   {
/*  38: 35 */     this.switchOn.collectTypeUsages(collector);
/*  39: 36 */     super.collectTypeUsages(collector);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public Dumper dump(Dumper dumper)
/*  43:    */   {
/*  44: 41 */     if (this.blockIdentifier.hasForeignReferences()) {
/*  45: 41 */       dumper.print(this.blockIdentifier.getName() + " : ");
/*  46:    */     }
/*  47: 42 */     dumper.print("switch (").dump(this.switchOn).print(") ");
/*  48: 43 */     getBody().dump(dumper);
/*  49: 44 */     return dumper;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public BlockIdentifier getBreakableBlockOrNull()
/*  53:    */   {
/*  54: 49 */     return this.blockIdentifier;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public boolean isProperlyStructured()
/*  58:    */   {
/*  59: 54 */     return true;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope)
/*  63:    */   {
/*  64: 59 */     scope.add(this);
/*  65:    */     try
/*  66:    */     {
/*  67: 61 */       getBody().transform(transformer, scope);
/*  68:    */     }
/*  69:    */     finally
/*  70:    */     {
/*  71: 63 */       scope.remove(this);
/*  72:    */     }
/*  73:    */   }
/*  74:    */   
/*  75:    */   public boolean rewriteBoxing(PrimitiveBoxingRewriter boxingRewriter)
/*  76:    */   {
/*  77: 68 */     this.switchOn = boxingRewriter.sugarUnboxing(this.switchOn);
/*  78: 69 */     return true;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void applyNonArgExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags) {}
/*  82:    */   
/*  83:    */   public Expression getSwitchOn()
/*  84:    */   {
/*  85: 77 */     return this.switchOn;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public Op04StructuredStatement getBody()
/*  89:    */   {
/*  90: 81 */     return super.getBody();
/*  91:    */   }
/*  92:    */   
/*  93:    */   public BlockIdentifier getBlockIdentifier()
/*  94:    */   {
/*  95: 85 */     return this.blockIdentifier;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void linearizeInto(List<StructuredStatement> out)
/*  99:    */   {
/* 100: 90 */     out.add(this);
/* 101: 91 */     getBody().linearizeStatementsInto(out);
/* 102:    */   }
/* 103:    */   
/* 104:    */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer)
/* 105:    */   {
/* 106: 96 */     this.switchOn.collectUsedLValues(scopeDiscoverer);
/* 107: 97 */     getBody().traceLocalVariableScope(scopeDiscoverer);
/* 108:    */   }
/* 109:    */   
/* 110:    */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 111:    */   {
/* 112:102 */     StructuredStatement o = (StructuredStatement)matchIterator.getCurrent();
/* 113:103 */     if (!(o instanceof StructuredSwitch)) {
/* 114:103 */       return false;
/* 115:    */     }
/* 116:104 */     StructuredSwitch other = (StructuredSwitch)o;
/* 117:105 */     if (!this.switchOn.equals(other.switchOn)) {
/* 118:105 */       return false;
/* 119:    */     }
/* 120:106 */     if (!this.blockIdentifier.equals(other.blockIdentifier)) {
/* 121:106 */       return false;
/* 122:    */     }
/* 123:107 */     matchIterator.advance();
/* 124:108 */     return true;
/* 125:    */   }
/* 126:    */   
/* 127:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter)
/* 128:    */   {
/* 129:113 */     expressionRewriter.handleStatement(getContainer());
/* 130:114 */     this.switchOn = expressionRewriter.rewriteExpression(this.switchOn, null, getContainer(), null);
/* 131:    */   }
/* 132:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredSwitch
 * JD-Core Version:    0.7.0.1
 */