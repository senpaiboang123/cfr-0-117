/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue.Creation;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractAssignmentExpression;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractMutatingAssignmentExpression;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.statement.AssignmentSimple;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  24:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  25:    */ import org.benf.cfr.reader.util.ListFactory;
/*  26:    */ import org.benf.cfr.reader.util.Predicate;
/*  27:    */ import org.benf.cfr.reader.util.StringUtils;
/*  28:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  29:    */ 
/*  30:    */ public class StructuredFor
/*  31:    */   extends AbstractStructuredBlockStatement
/*  32:    */ {
/*  33:    */   private ConditionalExpression condition;
/*  34:    */   private AssignmentSimple initial;
/*  35:    */   private List<AbstractAssignmentExpression> assignments;
/*  36:    */   private final BlockIdentifier block;
/*  37:    */   private boolean isCreator;
/*  38:    */   
/*  39:    */   public StructuredFor(ConditionalExpression condition, AssignmentSimple initial, List<AbstractAssignmentExpression> assignments, Op04StructuredStatement body, BlockIdentifier block)
/*  40:    */   {
/*  41: 35 */     super(body);
/*  42: 36 */     this.condition = condition;
/*  43: 37 */     this.initial = initial;
/*  44: 38 */     this.assignments = assignments;
/*  45: 39 */     this.block = block;
/*  46: 40 */     this.isCreator = false;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  50:    */   {
/*  51: 45 */     collector.collectFrom(this.condition);
/*  52: 46 */     collector.collectFrom(this.assignments);
/*  53: 47 */     super.collectTypeUsages(collector);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public Dumper dump(Dumper dumper)
/*  57:    */   {
/*  58: 52 */     if (this.block.hasForeignReferences()) {
/*  59: 52 */       dumper.print(this.block.getName() + " : ");
/*  60:    */     }
/*  61: 53 */     dumper.print("for (");
/*  62: 54 */     if (this.initial != null)
/*  63:    */     {
/*  64: 56 */       if (this.isCreator) {
/*  65: 57 */         LValue.Creation.dump(dumper, this.initial.getCreatedLValue()).print(" ");
/*  66:    */       }
/*  67: 59 */       dumper.dump(this.initial);
/*  68: 60 */       dumper.removePendingCarriageReturn();
/*  69:    */     }
/*  70:    */     else
/*  71:    */     {
/*  72: 62 */       dumper.print(";");
/*  73:    */     }
/*  74: 64 */     dumper.print(" ").dump(this.condition).print("; ");
/*  75: 65 */     boolean first = true;
/*  76: 66 */     for (Expression assignment : this.assignments)
/*  77:    */     {
/*  78: 67 */       first = StringUtils.comma(first, dumper);
/*  79: 68 */       dumper.dump(assignment);
/*  80:    */     }
/*  81: 70 */     dumper.print(") ");
/*  82: 71 */     getBody().dump(dumper);
/*  83: 72 */     return dumper;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope)
/*  87:    */   {
/*  88: 77 */     scope.add(this);
/*  89:    */     try
/*  90:    */     {
/*  91: 79 */       getBody().transform(transformer, scope);
/*  92:    */     }
/*  93:    */     finally
/*  94:    */     {
/*  95: 81 */       scope.remove(this);
/*  96:    */     }
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void linearizeInto(List<StructuredStatement> out)
/* 100:    */   {
/* 101: 88 */     out.add(this);
/* 102: 89 */     getBody().linearizeStatementsInto(out);
/* 103:    */   }
/* 104:    */   
/* 105:    */   public BlockIdentifier getBreakableBlockOrNull()
/* 106:    */   {
/* 107: 94 */     return this.block;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer)
/* 111:    */   {
/* 112:101 */     scopeDiscoverer.enterBlock(this);
/* 113:102 */     for (Expression assignment : this.assignments) {
/* 114:103 */       assignment.collectUsedLValues(scopeDiscoverer);
/* 115:    */     }
/* 116:105 */     this.condition.collectUsedLValues(scopeDiscoverer);
/* 117:106 */     if (this.initial != null)
/* 118:    */     {
/* 119:107 */       LValue lValue = this.initial.getCreatedLValue();
/* 120:108 */       Expression expression = this.initial.getRValue();
/* 121:109 */       lValue.collectLValueAssignments(expression, getContainer(), scopeDiscoverer);
/* 122:    */     }
/* 123:111 */     getBody().traceLocalVariableScope(scopeDiscoverer);
/* 124:112 */     scopeDiscoverer.leaveBlock(this);
/* 125:    */   }
/* 126:    */   
/* 127:    */   public void markCreator(LValue scopedEntity)
/* 128:    */   {
/* 129:117 */     LValue lValue = null;
/* 130:118 */     if (this.initial != null) {
/* 131:118 */       lValue = this.initial.getCreatedLValue();
/* 132:    */     }
/* 133:119 */     if (!scopedEntity.equals(lValue)) {
/* 134:120 */       throw new IllegalStateException("Being asked to define something I can't define.");
/* 135:    */     }
/* 136:122 */     this.isCreator = true;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public boolean canDefine(LValue scopedEntity)
/* 140:    */   {
/* 141:127 */     LValue lValue = null;
/* 142:128 */     if (this.initial != null) {
/* 143:128 */       lValue = this.initial.getCreatedLValue();
/* 144:    */     }
/* 145:129 */     if (scopedEntity == null) {
/* 146:129 */       return false;
/* 147:    */     }
/* 148:130 */     return scopedEntity.equals(lValue);
/* 149:    */   }
/* 150:    */   
/* 151:    */   public List<LValue> findCreatedHere()
/* 152:    */   {
/* 153:135 */     if (!this.isCreator) {
/* 154:135 */       return null;
/* 155:    */     }
/* 156:136 */     if (this.initial == null) {
/* 157:136 */       return null;
/* 158:    */     }
/* 159:137 */     LValue created = this.initial.getCreatedLValue();
/* 160:138 */     if (!(created instanceof LocalVariable)) {
/* 161:138 */       return null;
/* 162:    */     }
/* 163:140 */     return ListFactory.newList(new LValue[] { created });
/* 164:    */   }
/* 165:    */   
/* 166:    */   public String suggestName(LocalVariable createdHere, Predicate<String> testNameUsedFn)
/* 167:    */   {
/* 168:145 */     JavaTypeInstance loopType = createdHere.getInferredJavaType().getJavaTypeInstance();
/* 169:147 */     if (!(this.assignments.get(0) instanceof AbstractMutatingAssignmentExpression)) {
/* 170:147 */       return null;
/* 171:    */     }
/* 172:149 */     if (!(loopType instanceof RawJavaType)) {
/* 173:149 */       return null;
/* 174:    */     }
/* 175:150 */     RawJavaType rawJavaType = (RawJavaType)loopType;
/* 176:151 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$analysis$types$RawJavaType[rawJavaType.ordinal()])
/* 177:    */     {
/* 178:    */     case 1: 
/* 179:    */     case 2: 
/* 180:    */     case 3: 
/* 181:    */       break;
/* 182:    */     default: 
/* 183:157 */       return null;
/* 184:    */     }
/* 185:159 */     String[] poss = { "i", "j", "k" };
/* 186:160 */     for (String posss : poss) {
/* 187:161 */       if (!testNameUsedFn.test(posss)) {
/* 188:162 */         return posss;
/* 189:    */       }
/* 190:    */     }
/* 191:165 */     return "i";
/* 192:    */   }
/* 193:    */   
/* 194:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter)
/* 195:    */   {
/* 196:170 */     this.condition = expressionRewriter.rewriteExpression(this.condition, null, getContainer(), null);
/* 197:    */   }
/* 198:    */   
/* 199:    */   public BlockIdentifier getBlock()
/* 200:    */   {
/* 201:174 */     return this.block;
/* 202:    */   }
/* 203:    */   
/* 204:    */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 205:    */   {
/* 206:179 */     StructuredStatement o = (StructuredStatement)matchIterator.getCurrent();
/* 207:180 */     if (!(o instanceof StructuredFor)) {
/* 208:180 */       return false;
/* 209:    */     }
/* 210:181 */     StructuredFor other = (StructuredFor)o;
/* 211:182 */     if (!this.initial.equals(other.initial)) {
/* 212:182 */       return false;
/* 213:    */     }
/* 214:183 */     if (this.condition == null)
/* 215:    */     {
/* 216:184 */       if (other.condition != null) {
/* 217:184 */         return false;
/* 218:    */       }
/* 219:    */     }
/* 220:186 */     else if (!this.condition.equals(other.condition)) {
/* 221:186 */       return false;
/* 222:    */     }
/* 223:188 */     if (!this.assignments.equals(other.assignments)) {
/* 224:188 */       return false;
/* 225:    */     }
/* 226:189 */     if (!this.block.equals(other.block)) {
/* 227:189 */       return false;
/* 228:    */     }
/* 229:191 */     matchIterator.advance();
/* 230:192 */     return true;
/* 231:    */   }
/* 232:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredFor
 * JD-Core Version:    0.7.0.1
 */