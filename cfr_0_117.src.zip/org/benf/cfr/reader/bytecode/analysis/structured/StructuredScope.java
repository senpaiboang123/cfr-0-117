/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured;
/*  2:   */ 
/*  3:   */ import java.util.LinkedList;
/*  4:   */ import java.util.Set;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.Block;
/*  7:   */ import org.benf.cfr.reader.util.ListFactory;
/*  8:   */ import org.benf.cfr.reader.util.SetFactory;
/*  9:   */ 
/* 10:   */ public class StructuredScope
/* 11:   */ {
/* 12:   */   private final LinkedList<AtLevel> scope;
/* 13:   */   
/* 14:   */   public StructuredScope()
/* 15:   */   {
/* 16:16 */     this.scope = ListFactory.newLinkedList();
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void add(StructuredStatement statement)
/* 20:   */   {
/* 21:19 */     this.scope.addFirst(new AtLevel(statement, null));
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void remove(StructuredStatement statement)
/* 25:   */   {
/* 26:23 */     AtLevel old = (AtLevel)this.scope.removeFirst();
/* 27:24 */     if (statement != old.statement) {
/* 28:25 */       throw new IllegalStateException();
/* 29:   */     }
/* 30:   */   }
/* 31:   */   
/* 32:   */   public StructuredStatement getInnermost()
/* 33:   */   {
/* 34:30 */     if (this.scope.isEmpty()) {
/* 35:30 */       return null;
/* 36:   */     }
/* 37:31 */     return ((AtLevel)this.scope.getFirst()).statement;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void setNextAtThisLevel(StructuredStatement statement, int next)
/* 41:   */   {
/* 42:35 */     AtLevel atLevel = (AtLevel)this.scope.getFirst();
/* 43:36 */     if (atLevel.statement != statement) {
/* 44:37 */       throw new IllegalStateException();
/* 45:   */     }
/* 46:39 */     atLevel.next = next;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public Set<Op04StructuredStatement> getNextFallThrough(StructuredStatement structuredStatement)
/* 50:   */   {
/* 51:43 */     Op04StructuredStatement current = structuredStatement.getContainer();
/* 52:44 */     Set<Op04StructuredStatement> res = SetFactory.newSet();
/* 53:45 */     for (AtLevel atLevel : this.scope) {
/* 54:46 */       if ((atLevel.statement instanceof Block))
/* 55:   */       {
/* 56:47 */         if (atLevel.next != -1) {
/* 57:48 */           res.addAll(((Block)atLevel.statement).getNextAfter(atLevel.next));
/* 58:   */         }
/* 59:50 */         if (!((Block)atLevel.statement).statementIsLast(current)) {
/* 60:   */           break;
/* 61:   */         }
/* 62:51 */         current = atLevel.statement.getContainer();
/* 63:   */       }
/* 64:   */       else
/* 65:   */       {
/* 66:55 */         if (!atLevel.statement.fallsNopToNext()) {
/* 67:   */           break;
/* 68:   */         }
/* 69:56 */         current = atLevel.statement.getContainer();
/* 70:   */       }
/* 71:   */     }
/* 72:61 */     return res;
/* 73:   */   }
/* 74:   */   
/* 75:   */   public Set<Op04StructuredStatement> getDirectFallThrough(StructuredStatement structuredStatement)
/* 76:   */   {
/* 77:65 */     AtLevel atLevel = (AtLevel)this.scope.getFirst();
/* 78:66 */     if (((atLevel.statement instanceof Block)) && 
/* 79:67 */       (atLevel.next != -1)) {
/* 80:68 */       return ((Block)atLevel.statement).getNextAfter(atLevel.next);
/* 81:   */     }
/* 82:71 */     return SetFactory.newSet();
/* 83:   */   }
/* 84:   */   
/* 85:   */   public boolean statementIsLast(StructuredStatement statement)
/* 86:   */   {
/* 87:76 */     AtLevel atLevel = (AtLevel)this.scope.getFirst();
/* 88:77 */     int x = 1;
/* 89:78 */     StructuredStatement s = atLevel.statement;
/* 90:79 */     if ((s instanceof Block)) {
/* 91:80 */       return ((Block)s).statementIsLast(statement.getContainer());
/* 92:   */     }
/* 93:82 */     return statement == s;
/* 94:   */   }
/* 95:   */   
/* 96:   */   protected static class AtLevel
/* 97:   */   {
/* 98:   */     StructuredStatement statement;
/* 99:   */     int next;
/* :0:   */     
/* :1:   */     private AtLevel(StructuredStatement statement)
/* :2:   */     {
/* :3:91 */       this.statement = statement;
/* :4:92 */       this.next = 0;
/* :5:   */     }
/* :6:   */     
/* :7:   */     public String toString()
/* :8:   */     {
/* :9:97 */       return this.statement.toString();
/* ;0:   */     }
/* ;1:   */   }
/* ;2:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope
 * JD-Core Version:    0.7.0.1
 */