/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.PrimitiveBoxingRewriter;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface.BoxingProcessor;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  18:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  19:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  20:    */ 
/*  21:    */ public class StructuredReturn
/*  22:    */   extends AbstractStructuredStatement
/*  23:    */   implements BoxingProcessor
/*  24:    */ {
/*  25:    */   private Expression value;
/*  26:    */   private final JavaTypeInstance fnReturnType;
/*  27:    */   
/*  28:    */   public StructuredReturn()
/*  29:    */   {
/*  30: 32 */     this.value = null;
/*  31: 33 */     this.fnReturnType = null;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public StructuredReturn(Expression value, JavaTypeInstance fnReturnType)
/*  35:    */   {
/*  36: 37 */     this.value = value;
/*  37: 38 */     this.fnReturnType = fnReturnType;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  41:    */   {
/*  42: 43 */     collector.collect(this.fnReturnType);
/*  43: 44 */     collector.collectFrom(this.value);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public Dumper dump(Dumper dumper)
/*  47:    */   {
/*  48: 49 */     if (this.value == null) {
/*  49: 50 */       dumper.print("return;\n");
/*  50:    */     } else {
/*  51: 52 */       dumper.print("return ").dump(this.value).print(";\n");
/*  52:    */     }
/*  53: 54 */     return dumper;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public Expression getValue()
/*  57:    */   {
/*  58: 58 */     return this.value;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope) {}
/*  62:    */   
/*  63:    */   public void linearizeInto(List<StructuredStatement> out)
/*  64:    */   {
/*  65: 67 */     out.add(this);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer)
/*  69:    */   {
/*  70: 72 */     if (this.value != null) {
/*  71: 72 */       this.value.collectUsedLValues(scopeDiscoverer);
/*  72:    */     }
/*  73:    */   }
/*  74:    */   
/*  75:    */   public boolean rewriteBoxing(PrimitiveBoxingRewriter boxingRewriter)
/*  76:    */   {
/*  77: 77 */     if (this.value == null) {
/*  78: 77 */       return false;
/*  79:    */     }
/*  80: 78 */     this.value = boxingRewriter.sugarNonParameterBoxing(this.value, this.fnReturnType);
/*  81: 79 */     return false;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public void applyNonArgExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags) {}
/*  85:    */   
/*  86:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter)
/*  87:    */   {
/*  88: 88 */     expressionRewriter.handleStatement(getContainer());
/*  89: 89 */     if (this.value != null) {
/*  90: 90 */       this.value = expressionRewriter.rewriteExpression(this.value, null, getContainer(), null);
/*  91:    */     }
/*  92:    */   }
/*  93:    */   
/*  94:    */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/*  95:    */   {
/*  96: 96 */     StructuredStatement o = (StructuredStatement)matchIterator.getCurrent();
/*  97: 97 */     if (!(o instanceof StructuredReturn)) {
/*  98: 97 */       return false;
/*  99:    */     }
/* 100: 98 */     StructuredReturn other = (StructuredReturn)o;
/* 101: 99 */     if (this.value == null)
/* 102:    */     {
/* 103:100 */       if (other.value != null) {
/* 104:100 */         return false;
/* 105:    */       }
/* 106:    */     }
/* 107:102 */     else if (!this.value.equals(other.value)) {
/* 108:102 */       return false;
/* 109:    */     }
/* 110:105 */     matchIterator.advance();
/* 111:106 */     return true;
/* 112:    */   }
/* 113:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredReturn
 * JD-Core Version:    0.7.0.1
 */