/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Set;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  19:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  20:    */ import org.benf.cfr.reader.util.ListFactory;
/*  21:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  22:    */ 
/*  23:    */ public class StructuredCatch
/*  24:    */   extends AbstractStructuredStatement
/*  25:    */ {
/*  26:    */   private final List<JavaRefTypeInstance> catchTypes;
/*  27:    */   private final Op04StructuredStatement catchBlock;
/*  28:    */   private final LValue catching;
/*  29:    */   private final Set<BlockIdentifier> possibleTryBlocks;
/*  30:    */   
/*  31:    */   public StructuredCatch(Collection<JavaRefTypeInstance> catchTypes, Op04StructuredStatement catchBlock, LValue catching, Set<BlockIdentifier> possibleTryBlocks)
/*  32:    */   {
/*  33: 31 */     this.catchTypes = (catchTypes == null ? null : ListFactory.newList(catchTypes));
/*  34: 32 */     this.catchBlock = catchBlock;
/*  35: 33 */     this.catching = catching;
/*  36: 34 */     this.possibleTryBlocks = possibleTryBlocks;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  40:    */   {
/*  41: 39 */     collector.collect(this.catchTypes);
/*  42: 40 */     this.catchBlock.collectTypeUsages(collector);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public Dumper dump(Dumper dumper)
/*  46:    */   {
/*  47: 45 */     boolean first = true;
/*  48: 46 */     dumper.print("catch (");
/*  49: 47 */     for (JavaRefTypeInstance catchType : this.catchTypes)
/*  50:    */     {
/*  51: 48 */       if (!first) {
/*  52: 48 */         dumper.print(" | ");
/*  53:    */       }
/*  54: 49 */       dumper.dump(catchType);
/*  55: 50 */       first = false;
/*  56:    */     }
/*  57: 52 */     dumper.print(" ").dump(this.catching).print(") ");
/*  58: 53 */     this.catchBlock.dump(dumper);
/*  59: 54 */     return dumper;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public boolean isProperlyStructured()
/*  63:    */   {
/*  64: 60 */     return true;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public boolean fallsNopToNext()
/*  68:    */   {
/*  69: 65 */     return true;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope)
/*  73:    */   {
/*  74: 70 */     scope.add(this);
/*  75:    */     try
/*  76:    */     {
/*  77: 72 */       this.catchBlock.transform(transformer, scope);
/*  78:    */     }
/*  79:    */     finally
/*  80:    */     {
/*  81: 74 */       scope.remove(this);
/*  82:    */     }
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void linearizeInto(List<StructuredStatement> out)
/*  86:    */   {
/*  87: 80 */     out.add(this);
/*  88: 81 */     this.catchBlock.linearizeStatementsInto(out);
/*  89:    */   }
/*  90:    */   
/*  91:    */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/*  92:    */   {
/*  93: 86 */     StructuredStatement o = (StructuredStatement)matchIterator.getCurrent();
/*  94: 87 */     if (!(o instanceof StructuredCatch)) {
/*  95: 87 */       return false;
/*  96:    */     }
/*  97: 88 */     StructuredCatch other = (StructuredCatch)o;
/*  98:    */     
/*  99: 90 */     matchIterator.advance();
/* 100: 91 */     return true;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public boolean isRethrow()
/* 104:    */   {
/* 105: 95 */     StructuredStatement statement = this.catchBlock.getStatement();
/* 106: 96 */     if (!(statement instanceof Block)) {
/* 107: 96 */       return false;
/* 108:    */     }
/* 109: 97 */     Block block = (Block)statement;
/* 110: 98 */     if (!block.isJustOneStatement()) {
/* 111: 98 */       return false;
/* 112:    */     }
/* 113: 99 */     StructuredStatement inBlock = block.getSingleStatement().getStatement();
/* 114:100 */     StructuredThrow test = new StructuredThrow(new LValueExpression(this.catching));
/* 115:101 */     return test.equals(inBlock);
/* 116:    */   }
/* 117:    */   
/* 118:    */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer)
/* 119:    */   {
/* 120:106 */     if ((this.catching instanceof LocalVariable)) {
/* 121:107 */       scopeDiscoverer.collectLocalVariableAssignment((LocalVariable)this.catching, getContainer(), null);
/* 122:    */     }
/* 123:109 */     this.catchBlock.traceLocalVariableScope(scopeDiscoverer);
/* 124:    */   }
/* 125:    */   
/* 126:    */   public List<LValue> findCreatedHere()
/* 127:    */   {
/* 128:114 */     return ListFactory.newList(new LValue[] { this.catching });
/* 129:    */   }
/* 130:    */   
/* 131:    */   public void markCreator(LValue scopedEntity) {}
/* 132:    */   
/* 133:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter) {}
/* 134:    */   
/* 135:    */   public Set<BlockIdentifier> getPossibleTryBlocks()
/* 136:    */   {
/* 137:126 */     return this.possibleTryBlocks;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public boolean isRecursivelyStructured()
/* 141:    */   {
/* 142:131 */     return this.catchBlock.isFullyStructured();
/* 143:    */   }
/* 144:    */   
/* 145:    */   public boolean equals(Object o)
/* 146:    */   {
/* 147:136 */     if (this == o) {
/* 148:136 */       return true;
/* 149:    */     }
/* 150:137 */     if ((o == null) || (getClass() != o.getClass())) {
/* 151:137 */       return false;
/* 152:    */     }
/* 153:139 */     StructuredCatch that = (StructuredCatch)o;
/* 154:141 */     if (this.catching != null ? !this.catching.equals(that.catching) : that.catching != null) {
/* 155:141 */       return false;
/* 156:    */     }
/* 157:143 */     return true;
/* 158:    */   }
/* 159:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredCatch
 * JD-Core Version:    0.7.0.1
 */