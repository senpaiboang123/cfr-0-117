/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.Block;
/*  7:   */ 
/*  8:   */ public class EndBlock
/*  9:   */   extends AbstractPlaceholder
/* 10:   */ {
/* 11:   */   private final Block block;
/* 12:   */   
/* 13:   */   public EndBlock(Block block)
/* 14:   */   {
/* 15:13 */     this.block = block;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 19:   */   {
/* 20:18 */     StructuredStatement current = (StructuredStatement)matchIterator.getCurrent();
/* 21:19 */     if ((current instanceof EndBlock))
/* 22:   */     {
/* 23:20 */       EndBlock other = (EndBlock)current;
/* 24:21 */       if ((this.block == null) || (this.block.equals(other.block)))
/* 25:   */       {
/* 26:22 */         matchIterator.advance();
/* 27:23 */         return true;
/* 28:   */       }
/* 29:   */     }
/* 30:26 */     return false;
/* 31:   */   }
/* 32:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.placeholder.EndBlock
 * JD-Core Version:    0.7.0.1
 */