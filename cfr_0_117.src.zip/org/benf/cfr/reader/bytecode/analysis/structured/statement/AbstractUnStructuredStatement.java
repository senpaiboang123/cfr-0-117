/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 14:   */ import org.benf.cfr.reader.util.Predicate;
/* 15:   */ 
/* 16:   */ public abstract class AbstractUnStructuredStatement
/* 17:   */   extends AbstractStructuredStatement
/* 18:   */ {
/* 19:   */   public final void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope) {}
/* 20:   */   
/* 21:   */   public final void transformStructuredChildrenInReverse(StructuredStatementTransformer transformer, StructuredScope scope) {}
/* 22:   */   
/* 23:   */   public final boolean isProperlyStructured()
/* 24:   */   {
/* 25:29 */     return false;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public BlockIdentifier getBreakableBlockOrNull()
/* 29:   */   {
/* 30:34 */     return null;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public final boolean isRecursivelyStructured()
/* 34:   */   {
/* 35:39 */     return false;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void linearizeInto(List<StructuredStatement> out)
/* 39:   */   {
/* 40:44 */     throw new UnsupportedOperationException("Can't linearise an unstructured statement");
/* 41:   */   }
/* 42:   */   
/* 43:   */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer) {}
/* 44:   */   
/* 45:   */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 46:   */   {
/* 47:53 */     throw new UnsupportedOperationException();
/* 48:   */   }
/* 49:   */   
/* 50:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter) {}
/* 51:   */   
/* 52:   */   public boolean isEffectivelyNOP()
/* 53:   */   {
/* 54:62 */     return false;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public List<LValue> findCreatedHere()
/* 58:   */   {
/* 59:67 */     return null;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public String suggestName(LocalVariable createdHere, Predicate<String> testNameUsedFn)
/* 63:   */   {
/* 64:72 */     return null;
/* 65:   */   }
/* 66:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.AbstractUnStructuredStatement
 * JD-Core Version:    0.7.0.1
 */