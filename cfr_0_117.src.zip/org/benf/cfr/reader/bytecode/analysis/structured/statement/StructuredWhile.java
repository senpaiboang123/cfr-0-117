/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/* 13:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 14:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 15:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 16:   */ 
/* 17:   */ public class StructuredWhile
/* 18:   */   extends AbstractStructuredBlockStatement
/* 19:   */ {
/* 20:   */   private ConditionalExpression condition;
/* 21:   */   private final BlockIdentifier block;
/* 22:   */   
/* 23:   */   public StructuredWhile(ConditionalExpression condition, Op04StructuredStatement body, BlockIdentifier block)
/* 24:   */   {
/* 25:23 */     super(body);
/* 26:24 */     this.condition = condition;
/* 27:25 */     this.block = block;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 31:   */   {
/* 32:30 */     collector.collectFrom(this.condition);
/* 33:31 */     super.collectTypeUsages(collector);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public Dumper dump(Dumper dumper)
/* 37:   */   {
/* 38:36 */     if (this.block.hasForeignReferences()) {
/* 39:36 */       dumper.print(this.block.getName() + " : ");
/* 40:   */     }
/* 41:37 */     dumper.print("while (").dump(this.condition).print(") ");
/* 42:38 */     getBody().dump(dumper);
/* 43:39 */     return dumper;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public BlockIdentifier getBlock()
/* 47:   */   {
/* 48:43 */     return this.block;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope)
/* 52:   */   {
/* 53:48 */     scope.add(this);
/* 54:   */     try
/* 55:   */     {
/* 56:50 */       getBody().transform(transformer, scope);
/* 57:   */     }
/* 58:   */     finally
/* 59:   */     {
/* 60:52 */       scope.remove(this);
/* 61:   */     }
/* 62:   */   }
/* 63:   */   
/* 64:   */   public BlockIdentifier getBreakableBlockOrNull()
/* 65:   */   {
/* 66:58 */     return this.block;
/* 67:   */   }
/* 68:   */   
/* 69:   */   public void linearizeInto(List<StructuredStatement> out)
/* 70:   */   {
/* 71:63 */     out.add(this);
/* 72:64 */     getBody().linearizeStatementsInto(out);
/* 73:   */   }
/* 74:   */   
/* 75:   */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer)
/* 76:   */   {
/* 77:69 */     this.condition.collectUsedLValues(scopeDiscoverer);
/* 78:70 */     getBody().traceLocalVariableScope(scopeDiscoverer);
/* 79:   */   }
/* 80:   */   
/* 81:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter)
/* 82:   */   {
/* 83:75 */     this.condition = expressionRewriter.rewriteExpression(this.condition, null, getContainer(), null);
/* 84:   */   }
/* 85:   */   
/* 86:   */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 87:   */   {
/* 88:80 */     StructuredStatement o = (StructuredStatement)matchIterator.getCurrent();
/* 89:81 */     if (!(o instanceof StructuredWhile)) {
/* 90:81 */       return false;
/* 91:   */     }
/* 92:82 */     StructuredWhile other = (StructuredWhile)o;
/* 93:83 */     if (this.condition == null)
/* 94:   */     {
/* 95:84 */       if (other.condition != null) {
/* 96:84 */         return false;
/* 97:   */       }
/* 98:   */     }
/* 99:86 */     else if (!this.condition.equals(other.condition)) {
/* :0:86 */       return false;
/* :1:   */     }
/* :2:88 */     if (!this.block.equals(other.block)) {
/* :3:88 */       return false;
/* :4:   */     }
/* :5:90 */     matchIterator.advance();
/* :6:91 */     return true;
/* :7:   */   }
/* :8:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredWhile
 * JD-Core Version:    0.7.0.1
 */