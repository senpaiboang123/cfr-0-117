/*   1:    */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.PrimitiveBoxingRewriter;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.LValue.Creation;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.StatementContainer;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.rewriteinterface.BoxingProcessor;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.LocalVariable;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterFlags;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.SSAIdentifiers;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  21:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  22:    */ import org.benf.cfr.reader.util.ListFactory;
/*  23:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  24:    */ 
/*  25:    */ public class StructuredAssignment
/*  26:    */   extends AbstractStructuredStatement
/*  27:    */   implements BoxingProcessor
/*  28:    */ {
/*  29:    */   private LValue lvalue;
/*  30:    */   private Expression rvalue;
/*  31:    */   boolean isCreator;
/*  32:    */   
/*  33:    */   public StructuredAssignment(LValue lvalue, Expression rvalue)
/*  34:    */   {
/*  35: 32 */     this.lvalue = lvalue;
/*  36: 33 */     this.rvalue = rvalue;
/*  37: 34 */     this.isCreator = false;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public StructuredAssignment(LValue lvalue, Expression rvalue, boolean isCreator)
/*  41:    */   {
/*  42: 38 */     this.lvalue = lvalue;
/*  43: 39 */     this.rvalue = rvalue;
/*  44: 40 */     this.isCreator = isCreator;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void collectTypeUsages(TypeUsageCollector collector)
/*  48:    */   {
/*  49: 45 */     this.lvalue.collectTypeUsages(collector);
/*  50: 46 */     collector.collectFrom(this.rvalue);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public Dumper dump(Dumper dumper)
/*  54:    */   {
/*  55: 51 */     if (this.isCreator)
/*  56:    */     {
/*  57: 52 */       if (this.lvalue.isFinal()) {
/*  58: 52 */         dumper.print("final ");
/*  59:    */       }
/*  60: 53 */       LValue.Creation.dump(dumper, this.lvalue).print(" ");
/*  61:    */     }
/*  62: 55 */     dumper.dump(this.lvalue).print(" = ").dump(this.rvalue).endCodeln();
/*  63: 56 */     return dumper;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope) {}
/*  67:    */   
/*  68:    */   public void linearizeInto(List<StructuredStatement> out)
/*  69:    */   {
/*  70: 65 */     out.add(this);
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer)
/*  74:    */   {
/*  75: 70 */     this.rvalue.collectUsedLValues(scopeDiscoverer);
/*  76:    */     
/*  77: 72 */     this.lvalue.collectLValueAssignments(this.rvalue, getContainer(), scopeDiscoverer);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void markCreator(LValue scopedEntity)
/*  81:    */   {
/*  82: 78 */     if ((scopedEntity instanceof LocalVariable))
/*  83:    */     {
/*  84: 79 */       LocalVariable localVariable = (LocalVariable)scopedEntity;
/*  85: 80 */       if (!localVariable.equals(this.lvalue)) {
/*  86: 81 */         throw new IllegalArgumentException("Being asked to mark creator for wrong variable");
/*  87:    */       }
/*  88: 83 */       this.isCreator = true;
/*  89: 84 */       InferredJavaType inferredJavaType = localVariable.getInferredJavaType();
/*  90: 85 */       if (inferredJavaType.isClash()) {
/*  91: 86 */         inferredJavaType.collapseTypeClash();
/*  92:    */       }
/*  93:    */     }
/*  94:    */   }
/*  95:    */   
/*  96:    */   public List<LValue> findCreatedHere()
/*  97:    */   {
/*  98: 93 */     if (this.isCreator) {
/*  99: 94 */       return ListFactory.newList(new LValue[] { this.lvalue });
/* 100:    */     }
/* 101: 96 */     return null;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public LValue getLvalue()
/* 105:    */   {
/* 106:101 */     return this.lvalue;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public Expression getRvalue()
/* 110:    */   {
/* 111:105 */     return this.rvalue;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 115:    */   {
/* 116:110 */     StructuredStatement o = (StructuredStatement)matchIterator.getCurrent();
/* 117:111 */     if (!equals(o)) {
/* 118:111 */       return false;
/* 119:    */     }
/* 120:112 */     matchIterator.advance();
/* 121:113 */     return true;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public boolean equals(Object o)
/* 125:    */   {
/* 126:118 */     if (o == this) {
/* 127:118 */       return true;
/* 128:    */     }
/* 129:119 */     if (o == null) {
/* 130:119 */       return false;
/* 131:    */     }
/* 132:120 */     if (!(o instanceof StructuredAssignment)) {
/* 133:120 */       return false;
/* 134:    */     }
/* 135:121 */     StructuredAssignment other = (StructuredAssignment)o;
/* 136:122 */     if (!this.lvalue.equals(other.lvalue)) {
/* 137:122 */       return false;
/* 138:    */     }
/* 139:123 */     if (!this.rvalue.equals(other.rvalue)) {
/* 140:123 */       return false;
/* 141:    */     }
/* 142:125 */     return true;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public void rewriteExpressions(ExpressionRewriter expressionRewriter)
/* 146:    */   {
/* 147:130 */     expressionRewriter.handleStatement(getContainer());
/* 148:131 */     this.lvalue = expressionRewriter.rewriteExpression(this.lvalue, null, getContainer(), null);
/* 149:132 */     this.rvalue = expressionRewriter.rewriteExpression(this.rvalue, null, getContainer(), null);
/* 150:    */   }
/* 151:    */   
/* 152:    */   public boolean rewriteBoxing(PrimitiveBoxingRewriter boxingRewriter)
/* 153:    */   {
/* 154:137 */     this.rvalue = boxingRewriter.sugarNonParameterBoxing(this.rvalue, this.lvalue.getInferredJavaType().getJavaTypeInstance());
/* 155:138 */     return true;
/* 156:    */   }
/* 157:    */   
/* 158:    */   public void applyNonArgExpressionRewriter(ExpressionRewriter expressionRewriter, SSAIdentifiers ssaIdentifiers, StatementContainer statementContainer, ExpressionRewriterFlags flags)
/* 159:    */   {
/* 160:143 */     this.lvalue = this.lvalue.applyExpressionRewriter(expressionRewriter, ssaIdentifiers, statementContainer, flags);
/* 161:    */   }
/* 162:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredAssignment
 * JD-Core Version:    0.7.0.1
 */