/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.LinkedList;
/*  4:   */ import java.util.List;
/*  5:   */ import java.util.Vector;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConditionalExpression;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 10:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 11:   */ import org.benf.cfr.reader.util.ListFactory;
/* 12:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 13:   */ 
/* 14:   */ public class UnstructuredDo
/* 15:   */   extends AbstractUnStructuredStatement
/* 16:   */ {
/* 17:   */   private BlockIdentifier blockIdentifier;
/* 18:   */   
/* 19:   */   public UnstructuredDo(BlockIdentifier blockIdentifier)
/* 20:   */   {
/* 21:18 */     this.blockIdentifier = blockIdentifier;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public Dumper dump(Dumper dumper)
/* 25:   */   {
/* 26:23 */     return dumper.print("** do \n");
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void collectTypeUsages(TypeUsageCollector collector) {}
/* 30:   */   
/* 31:   */   public StructuredStatement claimBlock(Op04StructuredStatement innerBlock, BlockIdentifier blockIdentifier, Vector<BlockIdentifier> blocksCurrentlyIn)
/* 32:   */   {
/* 33:32 */     if (blockIdentifier != this.blockIdentifier) {
/* 34:33 */       throw new RuntimeException("Do statement claiming wrong block");
/* 35:   */     }
/* 36:35 */     UnstructuredWhile lastEndWhile = innerBlock.removeLastEndWhile();
/* 37:36 */     if (lastEndWhile != null)
/* 38:   */     {
/* 39:37 */       ConditionalExpression condition = lastEndWhile.getCondition();
/* 40:38 */       return new StructuredDo(condition, innerBlock, blockIdentifier);
/* 41:   */     }
/* 42:59 */     StructuredStatement inner = innerBlock.getStatement();
/* 43:60 */     if (!(inner instanceof Block))
/* 44:   */     {
/* 45:61 */       LinkedList<Op04StructuredStatement> blockContent = ListFactory.newLinkedList();
/* 46:62 */       blockContent.add(new Op04StructuredStatement(inner));
/* 47:63 */       inner = new Block(blockContent, true);
/* 48:64 */       innerBlock.replaceContainedStatement(inner);
/* 49:   */     }
/* 50:66 */     Block block = (Block)inner;
/* 51:67 */     if (block.isJustOneStatement())
/* 52:   */     {
/* 53:68 */       Op04StructuredStatement singleStatement = block.getSingleStatement();
/* 54:69 */       StructuredStatement stm = singleStatement.getStatement();
/* 55:70 */       boolean canRemove = true;
/* 56:71 */       if ((stm instanceof StructuredBreak))
/* 57:   */       {
/* 58:72 */         StructuredBreak brk = (StructuredBreak)stm;
/* 59:73 */         if (brk.getBreakBlock().equals(blockIdentifier)) {
/* 60:73 */           canRemove = false;
/* 61:   */         }
/* 62:   */       }
/* 63:74 */       else if ((stm instanceof StructuredContinue))
/* 64:   */       {
/* 65:75 */         StructuredContinue cnt = (StructuredContinue)stm;
/* 66:76 */         if (cnt.getContinueTgt().equals(blockIdentifier)) {
/* 67:76 */           canRemove = false;
/* 68:   */         }
/* 69:   */       }
/* 70:   */       else
/* 71:   */       {
/* 72:78 */         canRemove = false;
/* 73:   */       }
/* 74:80 */       if (canRemove) {
/* 75:81 */         return stm;
/* 76:   */       }
/* 77:   */     }
/* 78:84 */     block.getBlockStatements().add(new Op04StructuredStatement(new StructuredBreak(blockIdentifier, true)));
/* 79:   */     
/* 80:86 */     return new StructuredDo(null, innerBlock, blockIdentifier);
/* 81:   */   }
/* 82:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredDo
 * JD-Core Version:    0.7.0.1
 */