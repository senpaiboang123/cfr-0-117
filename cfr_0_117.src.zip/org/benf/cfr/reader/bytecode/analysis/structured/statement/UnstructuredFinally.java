/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.Vector;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  7:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  8:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  9:   */ 
/* 10:   */ public class UnstructuredFinally
/* 11:   */   extends AbstractUnStructuredStatement
/* 12:   */ {
/* 13:   */   private final BlockIdentifier blockIdentifier;
/* 14:   */   
/* 15:   */   public UnstructuredFinally(BlockIdentifier blockIdentifier)
/* 16:   */   {
/* 17:19 */     this.blockIdentifier = blockIdentifier;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void collectTypeUsages(TypeUsageCollector collector) {}
/* 21:   */   
/* 22:   */   public Dumper dump(Dumper dumper)
/* 23:   */   {
/* 24:28 */     dumper.print("** finally { \n");
/* 25:29 */     return dumper;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public StructuredStatement claimBlock(Op04StructuredStatement innerBlock, BlockIdentifier blockIdentifier, Vector<BlockIdentifier> blocksCurrentlyIn)
/* 29:   */   {
/* 30:34 */     if (blockIdentifier == this.blockIdentifier) {
/* 31:35 */       return new StructuredFinally(innerBlock);
/* 32:   */     }
/* 33:37 */     return null;
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredFinally
 * JD-Core Version:    0.7.0.1
 */