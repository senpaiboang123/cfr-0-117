/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 10:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 11:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 12:   */ 
/* 13:   */ public class StructuredContinue
/* 14:   */   extends AbstractStructuredContinue
/* 15:   */ {
/* 16:   */   private final BlockIdentifier continueTgt;
/* 17:   */   private final boolean localContinue;
/* 18:   */   
/* 19:   */   public StructuredContinue(BlockIdentifier continueTgt, boolean localContinue)
/* 20:   */   {
/* 21:20 */     this.continueTgt = continueTgt;
/* 22:21 */     this.localContinue = localContinue;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public Dumper dump(Dumper dumper)
/* 26:   */   {
/* 27:26 */     if (this.localContinue) {
/* 28:27 */       dumper.print("continue;\n");
/* 29:   */     } else {
/* 30:29 */       dumper.print("continue " + this.continueTgt.getName() + ";\n");
/* 31:   */     }
/* 32:31 */     return dumper;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void collectTypeUsages(TypeUsageCollector collector) {}
/* 36:   */   
/* 37:   */   public BlockIdentifier getContinueTgt()
/* 38:   */   {
/* 39:40 */     return this.continueTgt;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope) {}
/* 43:   */   
/* 44:   */   public void linearizeInto(List<StructuredStatement> out)
/* 45:   */   {
/* 46:49 */     out.add(this);
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer) {}
/* 50:   */   
/* 51:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter) {}
/* 52:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredContinue
 * JD-Core Version:    0.7.0.1
 */