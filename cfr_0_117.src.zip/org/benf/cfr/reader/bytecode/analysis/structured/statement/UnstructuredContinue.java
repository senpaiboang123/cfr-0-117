/*  1:   */ package org.benf.cfr.reader.bytecode.analysis.structured.statement;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Vector;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchIterator;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchResultCollector;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.StructuredStatementTransformer;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.scope.LValueScopeDiscoverer;
/* 11:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredScope;
/* 12:   */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/* 13:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 14:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 15:   */ 
/* 16:   */ public class UnstructuredContinue
/* 17:   */   extends AbstractStructuredContinue
/* 18:   */ {
/* 19:   */   private final BlockIdentifier continueTgt;
/* 20:   */   
/* 21:   */   public UnstructuredContinue(BlockIdentifier continueTgt)
/* 22:   */   {
/* 23:22 */     this.continueTgt = continueTgt;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public Dumper dump(Dumper dumper)
/* 27:   */   {
/* 28:27 */     return dumper.print("** continue;\n");
/* 29:   */   }
/* 30:   */   
/* 31:   */   public BlockIdentifier getContinueTgt()
/* 32:   */   {
/* 33:32 */     return this.continueTgt;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public void collectTypeUsages(TypeUsageCollector collector) {}
/* 37:   */   
/* 38:   */   public StructuredStatement informBlockHeirachy(Vector<BlockIdentifier> blockIdentifiers)
/* 39:   */   {
/* 40:42 */     boolean localBreak = false;
/* 41:43 */     BlockIdentifier outermostBreakable = BlockIdentifier.getInnermostBreakable(blockIdentifiers);
/* 42:44 */     if (!blockIdentifiers.contains(this.continueTgt)) {
/* 43:45 */       return null;
/* 44:   */     }
/* 45:47 */     if (outermostBreakable == this.continueTgt) {
/* 46:48 */       localBreak = true;
/* 47:   */     } else {
/* 48:50 */       this.continueTgt.addForeignRef();
/* 49:   */     }
/* 50:52 */     return new StructuredContinue(this.continueTgt, localBreak);
/* 51:   */   }
/* 52:   */   
/* 53:   */   public boolean isProperlyStructured()
/* 54:   */   {
/* 55:57 */     return false;
/* 56:   */   }
/* 57:   */   
/* 58:   */   public boolean isRecursivelyStructured()
/* 59:   */   {
/* 60:62 */     return false;
/* 61:   */   }
/* 62:   */   
/* 63:   */   public void transformStructuredChildren(StructuredStatementTransformer transformer, StructuredScope scope) {}
/* 64:   */   
/* 65:   */   public void linearizeInto(List<StructuredStatement> out)
/* 66:   */   {
/* 67:71 */     throw new UnsupportedOperationException();
/* 68:   */   }
/* 69:   */   
/* 70:   */   public boolean match(MatchIterator<StructuredStatement> matchIterator, MatchResultCollector matchResultCollector)
/* 71:   */   {
/* 72:76 */     throw new UnsupportedOperationException();
/* 73:   */   }
/* 74:   */   
/* 75:   */   public void traceLocalVariableScope(LValueScopeDiscoverer scopeDiscoverer) {}
/* 76:   */   
/* 77:   */   public void rewriteExpressions(ExpressionRewriter expressionRewriter) {}
/* 78:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.UnstructuredContinue
 * JD-Core Version:    0.7.0.1
 */