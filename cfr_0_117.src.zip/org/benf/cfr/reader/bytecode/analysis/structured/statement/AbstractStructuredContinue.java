package org.benf.cfr.reader.bytecode.analysis.structured.statement;

import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;

public abstract class AbstractStructuredContinue
  extends AbstractStructuredStatement
{
  public abstract BlockIdentifier getContinueTgt();
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.analysis.structured.statement.AbstractStructuredContinue
 * JD-Core Version:    0.7.0.1
 */