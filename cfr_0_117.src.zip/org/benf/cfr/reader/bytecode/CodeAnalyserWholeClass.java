/*   1:    */ package org.benf.cfr.reader.bytecode;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Set;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.AssertRewriter;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.EnumClassRewriter;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.IllegalGenericRewriter;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.J14ClassObjectRewriter;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.NonStaticLifter;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.ScopeHidingVariableRewriter;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.StaticLifter;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.DeadMethodRemover;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.ConstructorUtils;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.util.MiscStatementTools;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.FieldVariable;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriter;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.structured.StructuredStatement;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.InnerClassInfo;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  24:    */ import org.benf.cfr.reader.entities.AccessFlag;
/*  25:    */ import org.benf.cfr.reader.entities.AccessFlagMethod;
/*  26:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  27:    */ import org.benf.cfr.reader.entities.ClassFileField;
/*  28:    */ import org.benf.cfr.reader.entities.Method;
/*  29:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  30:    */ import org.benf.cfr.reader.state.ClassCache;
/*  31:    */ import org.benf.cfr.reader.state.DCCommonState;
/*  32:    */ import org.benf.cfr.reader.util.Functional;
/*  33:    */ import org.benf.cfr.reader.util.Predicate;
/*  34:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  35:    */ import org.benf.cfr.reader.util.getopt.Options;
/*  36:    */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*  37:    */ 
/*  38:    */ public class CodeAnalyserWholeClass
/*  39:    */ {
/*  40:    */   public static void wholeClassAnalysisPass1(ClassFile classFile, DCCommonState state)
/*  41:    */   {
/*  42: 39 */     Options options = state.getOptions();
/*  43:    */     
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48: 45 */     EnumClassRewriter.rewriteEnumClass(classFile, state);
/*  49: 52 */     if (((Boolean)options.getOption(OptionsImpl.REMOVE_BAD_GENERICS)).booleanValue()) {
/*  50: 53 */       removeIllegalGenerics(classFile, options);
/*  51:    */     }
/*  52: 56 */     if (((Boolean)options.getOption(OptionsImpl.SUGAR_ASSERTS)).booleanValue()) {
/*  53: 57 */       resugarAsserts(classFile, options);
/*  54:    */     }
/*  55: 60 */     if (((Boolean)options.getOption(OptionsImpl.LIFT_CONSTRUCTOR_INIT)).booleanValue())
/*  56:    */     {
/*  57: 61 */       liftStaticInitialisers(classFile, options);
/*  58: 62 */       liftNonStaticInitialisers(classFile, options);
/*  59:    */     }
/*  60: 65 */     if (((Boolean)options.getOption(OptionsImpl.JAVA_4_CLASS_OBJECTS, classFile.getClassFileVersion())).booleanValue()) {
/*  61: 66 */       resugarJava14classObjects(classFile, state);
/*  62:    */     }
/*  63: 69 */     if (((Boolean)options.getOption(OptionsImpl.REMOVE_BOILERPLATE)).booleanValue()) {
/*  64: 70 */       removeBoilerplateMethods(classFile);
/*  65:    */     }
/*  66: 73 */     if (((Boolean)options.getOption(OptionsImpl.REMOVE_INNER_CLASS_SYNTHETICS)).booleanValue())
/*  67:    */     {
/*  68: 74 */       if (classFile.isInnerClass()) {
/*  69: 75 */         removeInnerClassOuterThis(classFile);
/*  70:    */       }
/*  71: 78 */       removeInnerClassSyntheticConstructorFriends(classFile);
/*  72:    */     }
/*  73:    */   }
/*  74:    */   
/*  75:    */   private static void replaceNestedSyntheticOuterRefs(ClassFile classFile)
/*  76:    */   {
/*  77: 84 */     for (Method method : classFile.getMethods()) {
/*  78: 85 */       if (method.hasCodeAttribute())
/*  79:    */       {
/*  80: 86 */         Op04StructuredStatement code = method.getAnalysis();
/*  81: 87 */         Op04StructuredStatement.replaceNestedSyntheticOuterRefs(code);
/*  82:    */       }
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   private static void inlineAccessors(DCCommonState state, ClassFile classFile)
/*  87:    */   {
/*  88: 93 */     for (Method method : classFile.getMethods()) {
/*  89: 94 */       if (method.hasCodeAttribute())
/*  90:    */       {
/*  91: 95 */         Op04StructuredStatement code = method.getAnalysis();
/*  92: 96 */         Op04StructuredStatement.inlineSyntheticAccessors(state, method, code);
/*  93:    */       }
/*  94:    */     }
/*  95:    */   }
/*  96:    */   
/*  97:    */   private static void renameAnonymousScopeHidingVariables(ClassFile classFile, ClassCache classCache)
/*  98:    */   {
/*  99:102 */     List<ClassFileField> fields = Functional.filter(classFile.getFields(), new Predicate()
/* 100:    */     {
/* 101:    */       public boolean test(ClassFileField in)
/* 102:    */       {
/* 103:105 */         return in.isSyntheticOuterRef();
/* 104:    */       }
/* 105:    */     });
/* 106:108 */     if (fields.isEmpty()) {
/* 107:108 */       return;
/* 108:    */     }
/* 109:111 */     for (Method method : classFile.getMethods()) {
/* 110:112 */       if (method.hasCodeAttribute())
/* 111:    */       {
/* 112:117 */         ScopeHidingVariableRewriter rewriter = new ScopeHidingVariableRewriter(fields, method, classCache);
/* 113:118 */         rewriter.rewrite(method.getAnalysis());
/* 114:    */       }
/* 115:    */     }
/* 116:    */   }
/* 117:    */   
/* 118:    */   private static void fixInnerClassConstructorSyntheticOuterArgs(ClassFile classFile)
/* 119:    */   {
/* 120:127 */     for (Method method : classFile.getConstructors()) {
/* 121:128 */       Op04StructuredStatement.fixInnerClassConstructorSyntheticOuterArgs(classFile, method, method.getAnalysis());
/* 122:    */     }
/* 123:    */   }
/* 124:    */   
/* 125:    */   private static void removeInnerClassSyntheticConstructorFriends(ClassFile classFile)
/* 126:    */   {
/* 127:140 */     for (Method method : classFile.getConstructors())
/* 128:    */     {
/* 129:141 */       Set<AccessFlagMethod> flags = method.getAccessFlags();
/* 130:142 */       if ((flags.contains(AccessFlagMethod.ACC_SYNTHETIC)) && 
/* 131:143 */         (!flags.contains(AccessFlagMethod.ACC_PUBLIC)))
/* 132:    */       {
/* 133:145 */         MethodPrototype chainPrototype = ConstructorUtils.getDelegatingPrototype(method);
/* 134:146 */         if (chainPrototype != null)
/* 135:    */         {
/* 136:148 */           MethodPrototype prototype = method.getMethodPrototype();
/* 137:    */           
/* 138:150 */           List<JavaTypeInstance> argsThis = prototype.getArgs();
/* 139:151 */           if (!argsThis.isEmpty())
/* 140:    */           {
/* 141:152 */             List<JavaTypeInstance> argsThat = chainPrototype.getArgs();
/* 142:153 */             if (argsThis.size() == argsThat.size() + 1)
/* 143:    */             {
/* 144:154 */               JavaTypeInstance last = (JavaTypeInstance)argsThis.get(argsThis.size() - 1);
/* 145:    */               
/* 146:156 */               UnaryFunction<JavaTypeInstance, JavaTypeInstance> degenerifier = new UnaryFunction()
/* 147:    */               {
/* 148:    */                 public JavaTypeInstance invoke(JavaTypeInstance arg)
/* 149:    */                 {
/* 150:159 */                   return arg.getDeGenerifiedType();
/* 151:    */                 }
/* 152:161 */               };
/* 153:162 */               argsThis = Functional.map(argsThis, degenerifier);
/* 154:163 */               argsThat = Functional.map(argsThat, degenerifier);
/* 155:164 */               argsThis.remove(argsThis.size() - 1);
/* 156:171 */               if (argsThis.equals(argsThat))
/* 157:    */               {
/* 158:180 */                 InnerClassInfo innerClassInfo = last.getInnerClassHereInfo();
/* 159:181 */                 if (innerClassInfo.isInnerClass())
/* 160:    */                 {
/* 161:183 */                   innerClassInfo.hideSyntheticFriendClass();
/* 162:184 */                   prototype.hide(argsThis.size());
/* 163:185 */                   method.hideSynthetic();
/* 164:    */                 }
/* 165:    */               }
/* 166:    */             }
/* 167:    */           }
/* 168:    */         }
/* 169:    */       }
/* 170:    */     }
/* 171:    */   }
/* 172:    */   
/* 173:    */   private static void removeInnerClassOuterThis(ClassFile classFile)
/* 174:    */   {
/* 175:197 */     if (classFile.testAccessFlag(AccessFlag.ACC_STATIC)) {
/* 176:197 */       return;
/* 177:    */     }
/* 178:204 */     FieldVariable foundOuterThis = null;
/* 179:205 */     for (Method method : classFile.getConstructors()) {
/* 180:206 */       if (!ConstructorUtils.isDelegating(method))
/* 181:    */       {
/* 182:207 */         FieldVariable outerThis = Op04StructuredStatement.findInnerClassOuterThis(method, method.getAnalysis());
/* 183:208 */         if (outerThis == null) {
/* 184:208 */           return;
/* 185:    */         }
/* 186:209 */         if (foundOuterThis == null) {
/* 187:210 */           foundOuterThis = outerThis;
/* 188:211 */         } else if (foundOuterThis != outerThis) {
/* 189:212 */           return;
/* 190:    */         }
/* 191:    */       }
/* 192:    */     }
/* 193:215 */     if (foundOuterThis == null) {
/* 194:215 */       return;
/* 195:    */     }
/* 196:217 */     ClassFileField classFileField = foundOuterThis.getClassFileField();
/* 197:218 */     classFileField.markHidden();
/* 198:219 */     classFileField.markSyntheticOuterRef();
/* 199:221 */     for (Method method : classFile.getConstructors())
/* 200:    */     {
/* 201:222 */       if (ConstructorUtils.isDelegating(method))
/* 202:    */       {
/* 203:224 */         MethodPrototype prototype = method.getMethodPrototype();
/* 204:225 */         prototype.setInnerOuterThis();
/* 205:226 */         prototype.hide(0);
/* 206:    */       }
/* 207:228 */       Op04StructuredStatement.removeInnerClassOuterThis(method, method.getAnalysis());
/* 208:    */     }
/* 209:232 */     String originalName = foundOuterThis.getFieldName();
/* 210:    */     
/* 211:    */ 
/* 212:    */ 
/* 213:    */ 
/* 214:    */ 
/* 215:    */ 
/* 216:239 */     JavaTypeInstance fieldType = foundOuterThis.getInferredJavaType().getJavaTypeInstance();
/* 217:240 */     if (!(fieldType instanceof JavaRefTypeInstance)) {
/* 218:241 */       return;
/* 219:    */     }
/* 220:243 */     JavaRefTypeInstance fieldRefType = (JavaRefTypeInstance)fieldType.getDeGenerifiedType();
/* 221:244 */     String name = fieldRefType.getRawShortName();
/* 222:245 */     classFileField.overrideName(name + ".this");
/* 223:246 */     classFileField.markSyntheticOuterRef();
/* 224:    */     try
/* 225:    */     {
/* 226:253 */       ClassFileField localClassFileField = classFile.getFieldByName(originalName, fieldType);
/* 227:254 */       localClassFileField.overrideName(name + ".this");
/* 228:255 */       localClassFileField.markSyntheticOuterRef();
/* 229:    */     }
/* 230:    */     catch (NoSuchFieldException e) {}
/* 231:258 */     classFile.getClassType().getInnerClassHereInfo().setHideSyntheticThis();
/* 232:    */   }
/* 233:    */   
/* 234:    */   private static Method getStaticConstructor(ClassFile classFile)
/* 235:    */   {
/* 236:    */     Method staticInit;
/* 237:    */     try
/* 238:    */     {
/* 239:264 */       staticInit = (Method)classFile.getMethodByName("<clinit>").get(0);
/* 240:    */     }
/* 241:    */     catch (NoSuchMethodException e)
/* 242:    */     {
/* 243:266 */       return null;
/* 244:    */     }
/* 245:268 */     return staticInit;
/* 246:    */   }
/* 247:    */   
/* 248:    */   private static void liftStaticInitialisers(ClassFile classFile, Options state)
/* 249:    */   {
/* 250:279 */     Method staticInit = getStaticConstructor(classFile);
/* 251:280 */     if (staticInit == null) {
/* 252:280 */       return;
/* 253:    */     }
/* 254:281 */     new StaticLifter(classFile).liftStatics(staticInit);
/* 255:    */   }
/* 256:    */   
/* 257:    */   private static void liftNonStaticInitialisers(ClassFile classFile, Options state)
/* 258:    */   {
/* 259:285 */     new NonStaticLifter(classFile).liftNonStatics();
/* 260:    */   }
/* 261:    */   
/* 262:    */   private static void removeDeadMethods(ClassFile classFile)
/* 263:    */   {
/* 264:297 */     Method staticInit = getStaticConstructor(classFile);
/* 265:298 */     if (staticInit != null) {
/* 266:299 */       DeadMethodRemover.removeDeadMethod(classFile, staticInit);
/* 267:    */     }
/* 268:304 */     tryRemoveConstructor(classFile);
/* 269:    */   }
/* 270:    */   
/* 271:    */   private static void removeBoilerplateMethods(ClassFile classFile)
/* 272:    */   {
/* 273:308 */     String[] removeThese = { "$deserializeLambda$" };
/* 274:309 */     for (String methName : removeThese)
/* 275:    */     {
/* 276:310 */       List<Method> methods = classFile.getMethodsByNameOrNull(methName);
/* 277:311 */       if (methods != null) {
/* 278:312 */         for (Method method : methods) {
/* 279:313 */           method.hideSynthetic();
/* 280:    */         }
/* 281:    */       }
/* 282:    */     }
/* 283:    */   }
/* 284:    */   
/* 285:    */   private static void tryRemoveConstructor(ClassFile classFile)
/* 286:    */   {
/* 287:320 */     List<Method> constructors = classFile.getConstructors();
/* 288:321 */     if (constructors.size() != 1) {
/* 289:321 */       return;
/* 290:    */     }
/* 291:322 */     Method constructor = (Method)constructors.get(0);
/* 292:    */     
/* 293:    */ 
/* 294:325 */     MethodPrototype methodPrototype = constructor.getMethodPrototype();
/* 295:326 */     if (methodPrototype.getVisibleArgCount() > 0) {
/* 296:326 */       return;
/* 297:    */     }
/* 298:328 */     if (constructor.testAccessFlag(AccessFlagMethod.ACC_FINAL)) {
/* 299:328 */       return;
/* 300:    */     }
/* 301:329 */     if (!constructor.testAccessFlag(AccessFlagMethod.ACC_PUBLIC)) {
/* 302:329 */       return;
/* 303:    */     }
/* 304:331 */     if (!MiscStatementTools.isDeadCode(constructor.getAnalysis())) {
/* 305:331 */       return;
/* 306:    */     }
/* 307:332 */     classFile.removePointlessMethod(constructor);
/* 308:    */   }
/* 309:    */   
/* 310:    */   private static void removeIllegalGenerics(ClassFile classFile, Options state)
/* 311:    */   {
/* 312:337 */     ConstantPool cp = classFile.getConstantPool();
/* 313:338 */     ExpressionRewriter r = new IllegalGenericRewriter(cp);
/* 314:340 */     for (Method m : classFile.getMethods())
/* 315:    */     {
/* 316:341 */       if (!m.hasCodeAttribute()) {
/* 317:341 */         return;
/* 318:    */       }
/* 319:342 */       Op04StructuredStatement code = m.getAnalysis();
/* 320:343 */       if (code.isFullyStructured())
/* 321:    */       {
/* 322:345 */         List<StructuredStatement> statements = MiscStatementTools.linearise(code);
/* 323:346 */         if (statements == null) {
/* 324:346 */           return;
/* 325:    */         }
/* 326:348 */         for (StructuredStatement statement : statements) {
/* 327:349 */           statement.rewriteExpressions(r);
/* 328:    */         }
/* 329:354 */         Op04StructuredStatement.removePrimitiveDeconversion(state, m, code);
/* 330:    */       }
/* 331:    */     }
/* 332:    */   }
/* 333:    */   
/* 334:    */   private static void resugarAsserts(ClassFile classFile, Options state)
/* 335:    */   {
/* 336:360 */     Method staticInit = getStaticConstructor(classFile);
/* 337:361 */     if (staticInit != null) {
/* 338:362 */       new AssertRewriter(classFile).sugarAsserts(staticInit);
/* 339:    */     }
/* 340:    */   }
/* 341:    */   
/* 342:    */   private static void resugarJava14classObjects(ClassFile classFile, DCCommonState state)
/* 343:    */   {
/* 344:367 */     new J14ClassObjectRewriter(classFile, state).rewrite();
/* 345:    */   }
/* 346:    */   
/* 347:    */   public static void wholeClassAnalysisPass2(ClassFile classFile, DCCommonState state)
/* 348:    */   {
/* 349:376 */     Options options = state.getOptions();
/* 350:380 */     if (((Boolean)options.getOption(OptionsImpl.REMOVE_INNER_CLASS_SYNTHETICS)).booleanValue())
/* 351:    */     {
/* 352:386 */       if (classFile.isInnerClass()) {
/* 353:387 */         fixInnerClassConstructorSyntheticOuterArgs(classFile);
/* 354:    */       }
/* 355:390 */       replaceNestedSyntheticOuterRefs(classFile);
/* 356:    */       
/* 357:392 */       inlineAccessors(state, classFile);
/* 358:    */       
/* 359:    */ 
/* 360:    */ 
/* 361:    */ 
/* 362:    */ 
/* 363:398 */       renameAnonymousScopeHidingVariables(classFile, state.getClassCache());
/* 364:    */     }
/* 365:402 */     if (((Boolean)options.getOption(OptionsImpl.REMOVE_DEAD_METHODS)).booleanValue()) {
/* 366:403 */       removeDeadMethods(classFile);
/* 367:    */     }
/* 368:    */   }
/* 369:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.CodeAnalyserWholeClass
 * JD-Core Version:    0.7.0.1
 */