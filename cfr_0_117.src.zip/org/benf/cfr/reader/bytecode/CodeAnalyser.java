/*   1:    */ package org.benf.cfr.reader.bytecode;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.SortedMap;
/*   8:    */ import java.util.TreeMap;
/*   9:    */ import java.util.logging.Logger;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03Blocks;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters.GetClassTestInnerConstructor;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters.GetClassTestLambda;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters.Op02GetClassRewriter;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters.Op02RedundantStoreRewriter;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters.TypeHintRecovery;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters.TypeHintRecoveryImpl;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op2rewriters.TypeHintRecoveryNone;
/*  22:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.AnonymousArray;
/*  23:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner;
/*  24:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter;
/*  25:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.FinallyRewriter;
/*  26:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.GenericInferer;
/*  27:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.InlineDeAssigner;
/*  28:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.IterLoopRewriter;
/*  29:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LValueProp;
/*  30:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LValuePropSimple;
/*  31:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier;
/*  32:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopLivenessClash;
/*  33:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc;
/*  34:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.NullTypedLValueRewriter;
/*  35:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.RemoveDeterministicJumps;
/*  36:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.StaticInitReturnRewriter;
/*  37:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer;
/*  38:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SynchronizedBlocks;
/*  39:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchEnumRewriter;
/*  40:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter;
/*  41:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.checker.LooseCatchChecker;
/*  42:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExplicitTypeCallRewriter;
/*  43:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.StringBuilderRewriter;
/*  44:    */ import org.benf.cfr.reader.bytecode.analysis.parse.rewriters.XorRewriter;
/*  45:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifierFactory;
/*  46:    */ import org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredFakeDecompFailure;
/*  47:    */ import org.benf.cfr.reader.bytecode.analysis.variables.VariableFactory;
/*  48:    */ import org.benf.cfr.reader.bytecode.opcode.JVMInstr;
/*  49:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  50:    */ import org.benf.cfr.reader.entities.Method;
/*  51:    */ import org.benf.cfr.reader.entities.attributes.AttributeCode;
/*  52:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  53:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionAggregator;
/*  54:    */ import org.benf.cfr.reader.state.DCCommonState;
/*  55:    */ import org.benf.cfr.reader.state.TypeUsageInformationEmpty;
/*  56:    */ import org.benf.cfr.reader.util.ClassFileVersion;
/*  57:    */ import org.benf.cfr.reader.util.DecompilerComment;
/*  58:    */ import org.benf.cfr.reader.util.DecompilerComments;
/*  59:    */ import org.benf.cfr.reader.util.ListFactory;
/*  60:    */ import org.benf.cfr.reader.util.Troolean;
/*  61:    */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  62:    */ import org.benf.cfr.reader.util.bytestream.OffsettingByteData;
/*  63:    */ import org.benf.cfr.reader.util.getopt.Options;
/*  64:    */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*  65:    */ import org.benf.cfr.reader.util.getopt.PermittedOptionProvider.Argument;
/*  66:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  67:    */ import org.benf.cfr.reader.util.output.IllegalIdentifierDump.Nop;
/*  68:    */ import org.benf.cfr.reader.util.output.LoggerFactory;
/*  69:    */ import org.benf.cfr.reader.util.output.StdIODumper;
/*  70:    */ 
/*  71:    */ public class CodeAnalyser
/*  72:    */ {
/*  73:    */   private static final int SHOW_L2_RAW = 1;
/*  74:    */   private static final int SHOW_L2_OPS = 2;
/*  75:    */   private static final int SHOW_L3_RAW = 3;
/*  76:    */   private static final int SHOW_L3_ORDERED = 4;
/*  77:    */   private static final int SHOW_L3_CAUGHT = 5;
/*  78:    */   private static final int SHOW_L3_JUMPS = 6;
/*  79:    */   private static final int SHOW_L3_LOOPS1 = 7;
/*  80:    */   private static final int SHOW_L3_EXCEPTION_BLOCKS = 8;
/*  81:    */   private static final int SHOW_L4_FINAL_OP3 = 9;
/*  82: 48 */   private static final Logger logger = LoggerFactory.create(CodeAnalyser.class);
/*  83:    */   private final AttributeCode originalCodeAttribute;
/*  84:    */   private final ConstantPool cp;
/*  85:    */   private Method method;
/*  86:    */   private Op04StructuredStatement analysed;
/*  87:    */   
/*  88:    */   public CodeAnalyser(AttributeCode attributeCode)
/*  89:    */   {
/*  90: 59 */     this.originalCodeAttribute = attributeCode;
/*  91: 60 */     this.cp = attributeCode.getConstantPool();
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void setMethod(Method method)
/*  95:    */   {
/*  96: 64 */     this.method = method;
/*  97:    */   }
/*  98:    */   
/*  99:    */   private static class AnalysisResult
/* 100:    */   {
/* 101:    */     public DecompilerComments comments;
/* 102:    */     public Op04StructuredStatement code;
/* 103:    */     public AnonymousClassUsage anonymousClassUsage;
/* 104:    */     public boolean failed;
/* 105:    */     public boolean exception;
/* 106:    */     
/* 107:    */     private AnalysisResult(DecompilerComments comments, Op04StructuredStatement code, AnonymousClassUsage anonymousClassUsage)
/* 108:    */     {
/* 109: 75 */       this.anonymousClassUsage = anonymousClassUsage;
/* 110: 76 */       this.comments = comments;
/* 111: 77 */       this.code = code;
/* 112: 78 */       boolean failed = false;
/* 113: 79 */       boolean exception = false;
/* 114: 80 */       for (DecompilerComment comment : comments.getCommentCollection())
/* 115:    */       {
/* 116: 81 */         if (comment.isFailed()) {
/* 117: 82 */           failed = true;
/* 118:    */         }
/* 119: 84 */         if (comment.isException()) {
/* 120: 85 */           exception = true;
/* 121:    */         }
/* 122:    */       }
/* 123: 88 */       this.failed = failed;
/* 124: 89 */       this.exception = exception;
/* 125:    */     }
/* 126:    */   }
/* 127:    */   
/* 128: 93 */   private static final RecoveryOptions recover0 = new RecoveryOptions(new RecoveryOption[] { new RecoveryOption.TrooleanRO(OptionsImpl.RECOVER_TYPECLASHES, Troolean.TRUE, BytecodeMeta.hasAnyFlag(new BytecodeMeta.CodeInfoFlag[] { BytecodeMeta.CodeInfoFlag.LIVENESS_CLASH })), new RecoveryOption.TrooleanRO(OptionsImpl.USE_RECOVERED_ITERATOR_TYPE_HINTS, Troolean.TRUE, BytecodeMeta.hasAnyFlag(new BytecodeMeta.CodeInfoFlag[] { BytecodeMeta.CodeInfoFlag.ITERATED_TYPE_HINTS })), new RecoveryOption.BooleanRO(OptionsImpl.STATIC_INIT_RETURN, Boolean.FALSE.booleanValue()) });
/* 129: 99 */   private static final RecoveryOptions recoverExAgg = new RecoveryOptions(new RecoveryOption[] { new RecoveryOption.TrooleanRO(OptionsImpl.RECOVER_TYPECLASHES, Troolean.TRUE, BytecodeMeta.hasAnyFlag(new BytecodeMeta.CodeInfoFlag[] { BytecodeMeta.CodeInfoFlag.LIVENESS_CLASH })), new RecoveryOption.TrooleanRO(OptionsImpl.USE_RECOVERED_ITERATOR_TYPE_HINTS, Troolean.TRUE, BytecodeMeta.hasAnyFlag(new BytecodeMeta.CodeInfoFlag[] { BytecodeMeta.CodeInfoFlag.ITERATED_TYPE_HINTS })), new RecoveryOption.TrooleanRO(OptionsImpl.FORCE_AGGRESSIVE_EXCEPTION_AGG, Troolean.TRUE, BytecodeMeta.hasAnyFlag(new BytecodeMeta.CodeInfoFlag[] { BytecodeMeta.CodeInfoFlag.USES_EXCEPTIONS }), DecompilerComment.AGGRESSIVE_EXCEPTION_AGG) });
/* 130:105 */   private static final RecoveryOptions recover0a = new RecoveryOptions(recover0, new RecoveryOption[] { new RecoveryOption.TrooleanRO(OptionsImpl.FORCE_COND_PROPAGATE, Troolean.TRUE, DecompilerComment.COND_PROPAGATE), new RecoveryOption.TrooleanRO(OptionsImpl.FORCE_RETURNING_IFS, Troolean.TRUE, DecompilerComment.RETURNING_IFS) });
/* 131:110 */   private static final RecoveryOptions recover1 = new RecoveryOptions(recover0, new RecoveryOption[] { new RecoveryOption.TrooleanRO(OptionsImpl.FORCE_TOPSORT, Troolean.TRUE, DecompilerComment.AGGRESSIVE_TOPOLOGICAL_SORT), new RecoveryOption.TrooleanRO(OptionsImpl.FOR_LOOP_CAPTURE, Troolean.TRUE), new RecoveryOption.BooleanRO(OptionsImpl.LENIENT, Boolean.TRUE.booleanValue()), new RecoveryOption.TrooleanRO(OptionsImpl.FORCE_COND_PROPAGATE, Troolean.TRUE), new RecoveryOption.TrooleanRO(OptionsImpl.FORCE_PRUNE_EXCEPTIONS, Troolean.TRUE, BytecodeMeta.hasAnyFlag(new BytecodeMeta.CodeInfoFlag[] { BytecodeMeta.CodeInfoFlag.USES_EXCEPTIONS }), DecompilerComment.PRUNE_EXCEPTIONS), new RecoveryOption.TrooleanRO(OptionsImpl.FORCE_AGGRESSIVE_EXCEPTION_AGG, Troolean.TRUE, BytecodeMeta.hasAnyFlag(new BytecodeMeta.CodeInfoFlag[] { BytecodeMeta.CodeInfoFlag.USES_EXCEPTIONS }), DecompilerComment.AGGRESSIVE_EXCEPTION_AGG) });
/* 132:119 */   private static final RecoveryOptions recover2 = new RecoveryOptions(recover1, new RecoveryOption[] { new RecoveryOption.TrooleanRO(OptionsImpl.FORCE_TOPSORT_EXTRA, Troolean.TRUE) });
/* 133:123 */   private static final RecoveryOptions recover3 = new RecoveryOptions(recover1, new RecoveryOption[] { new RecoveryOption.BooleanRO(OptionsImpl.COMMENT_MONITORS, Boolean.TRUE.booleanValue(), BytecodeMeta.hasAnyFlag(new BytecodeMeta.CodeInfoFlag[] { BytecodeMeta.CodeInfoFlag.USES_MONITORS }), DecompilerComment.COMMENT_MONITORS), new RecoveryOption.TrooleanRO(OptionsImpl.FORCE_RETURNING_IFS, Troolean.TRUE, DecompilerComment.RETURNING_IFS) });
/* 134:128 */   private static final RecoveryOptions[] recoveryOptionsArr = { recover0, recover0a, recover1, recover2, recoverExAgg, recover3 };
/* 135:    */   
/* 136:    */   public Op04StructuredStatement getAnalysis(DCCommonState dcCommonState)
/* 137:    */   {
/* 138:134 */     if (this.analysed != null) {
/* 139:134 */       return this.analysed;
/* 140:    */     }
/* 141:136 */     Options options = dcCommonState.getOptions();
/* 142:137 */     List<Op01WithProcessedDataAndByteJumps> instrs = getInstrs();
/* 143:    */     
/* 144:139 */     AnalysisResult res = null;
/* 145:    */     
/* 146:    */ 
/* 147:    */ 
/* 148:    */ 
/* 149:144 */     BytecodeMeta bytecodeMeta = new BytecodeMeta(instrs, this.originalCodeAttribute);
/* 150:146 */     if (options.optionIsSet(OptionsImpl.FORCE_PASS))
/* 151:    */     {
/* 152:147 */       int pass = ((Integer)options.getOption(OptionsImpl.FORCE_PASS)).intValue();
/* 153:148 */       if ((pass < 0) || (pass >= recoveryOptionsArr.length)) {
/* 154:149 */         throw new IllegalArgumentException("Illegal recovery pass idx");
/* 155:    */       }
/* 156:151 */       RecoveryOptions.Applied applied = recoveryOptionsArr[pass].apply(dcCommonState, options, bytecodeMeta);
/* 157:152 */       res = getAnalysisOrWrapFail(pass, instrs, dcCommonState, applied.options, applied.comments, bytecodeMeta);
/* 158:    */     }
/* 159:    */     else
/* 160:    */     {
/* 161:155 */       res = getAnalysisOrWrapFail(0, instrs, dcCommonState, options, null, bytecodeMeta);
/* 162:157 */       if ((res.failed) && (((Boolean)options.getOption(OptionsImpl.RECOVER)).booleanValue()))
/* 163:    */       {
/* 164:158 */         int passIdx = 1;
/* 165:159 */         for (RecoveryOptions recoveryOptions : recoveryOptionsArr)
/* 166:    */         {
/* 167:160 */           RecoveryOptions.Applied applied = recoveryOptions.apply(dcCommonState, options, bytecodeMeta);
/* 168:161 */           if (applied.valid)
/* 169:    */           {
/* 170:162 */             AnalysisResult nextRes = getAnalysisOrWrapFail(passIdx++, instrs, dcCommonState, applied.options, applied.comments, bytecodeMeta);
/* 171:163 */             if (nextRes != null) {
/* 172:164 */               if ((res.failed) && (nextRes.failed))
/* 173:    */               {
/* 174:167 */                 if ((res.exception) || (!nextRes.exception)) {
/* 175:167 */                   res = nextRes;
/* 176:    */                 }
/* 177:    */               }
/* 178:    */               else {
/* 179:169 */                 res = nextRes;
/* 180:    */               }
/* 181:    */             }
/* 182:172 */             if (!res.failed) {
/* 183:    */               break;
/* 184:    */             }
/* 185:    */           }
/* 186:    */         }
/* 187:    */       }
/* 188:    */     }
/* 189:178 */     if (res.comments != null) {
/* 190:179 */       this.method.setComments(res.comments);
/* 191:    */     }
/* 192:185 */     res.anonymousClassUsage.useNotes();
/* 193:    */     
/* 194:187 */     this.analysed = res.code;
/* 195:188 */     return this.analysed;
/* 196:    */   }
/* 197:    */   
/* 198:    */   private List<Op01WithProcessedDataAndByteJumps> getInstrs()
/* 199:    */   {
/* 200:195 */     ByteData rawCode = this.originalCodeAttribute.getRawData();
/* 201:196 */     long codeLength = this.originalCodeAttribute.getCodeLength();
/* 202:197 */     ArrayList<Op01WithProcessedDataAndByteJumps> instrs = new ArrayList();
/* 203:198 */     OffsettingByteData bdCode = rawCode.getOffsettingOffsetData(0L);
/* 204:199 */     int offset = 0;
/* 205:    */     
/* 206:    */ 
/* 207:    */ 
/* 208:203 */     instrs.add(JVMInstr.NOP.createOperation(null, this.cp, -1));
/* 209:    */     do
/* 210:    */     {
/* 211:205 */       JVMInstr instr = JVMInstr.find(bdCode.getS1At(0L));
/* 212:206 */       Op01WithProcessedDataAndByteJumps oc = instr.createOperation(bdCode, this.cp, offset);
/* 213:207 */       int length = oc.getInstructionLength();
/* 214:208 */       instrs.add(oc);
/* 215:209 */       offset += length;
/* 216:210 */       bdCode.advance(length);
/* 217:211 */     } while (offset < codeLength);
/* 218:212 */     return instrs;
/* 219:    */   }
/* 220:    */   
/* 221:    */   private AnalysisResult getAnalysisOrWrapFail(int passIdx, List<Op01WithProcessedDataAndByteJumps> instrs, DCCommonState commonState, Options options, List<DecompilerComment> extraComments, BytecodeMeta bytecodeMeta)
/* 222:    */   {
/* 223:    */     try
/* 224:    */     {
/* 225:217 */       AnalysisResult res = getAnalysisInner(instrs, commonState, options, bytecodeMeta, passIdx);
/* 226:218 */       if (extraComments != null) {
/* 227:218 */         res.comments.addComments(extraComments);
/* 228:    */       }
/* 229:219 */       return res;
/* 230:    */     }
/* 231:    */     catch (RuntimeException e)
/* 232:    */     {
/* 233:221 */       Op04StructuredStatement coderes = new Op04StructuredStatement(new StructuredFakeDecompFailure(e));
/* 234:222 */       DecompilerComments comments = new DecompilerComments();
/* 235:223 */       comments.addComment(new DecompilerComment("Exception decompiling", e));
/* 236:224 */       return new AnalysisResult(comments, coderes, new AnonymousClassUsage(), null);
/* 237:    */     }
/* 238:    */   }
/* 239:    */   
/* 240:    */   private AnalysisResult getAnalysisInner(List<Op01WithProcessedDataAndByteJumps> instrs, DCCommonState dcCommonState, Options options, BytecodeMeta bytecodeMeta, int passIdx)
/* 241:    */   {
/* 242:236 */     boolean willSort = options.getOption(OptionsImpl.FORCE_TOPSORT) == Troolean.TRUE;
/* 243:    */     
/* 244:238 */     int showOpsLevel = ((Integer)options.getOption(OptionsImpl.SHOWOPS)).intValue();
/* 245:    */     
/* 246:240 */     ClassFile classFile = this.method.getClassFile();
/* 247:241 */     ClassFileVersion classFileVersion = classFile.getClassFileVersion();
/* 248:    */     
/* 249:243 */     DecompilerComments comments = new DecompilerComments();
/* 250:    */     
/* 251:245 */     boolean aggressiveSizeReductions = ((Integer)options.getOption(OptionsImpl.AGGRESSIVE_SIZE_REDUCTION_THRESHOLD)).intValue() < instrs.size();
/* 252:246 */     if (aggressiveSizeReductions) {
/* 253:247 */       comments.addComment("Opcode count of " + instrs.size() + " triggered aggressive code reduction.  Override with --" + OptionsImpl.AGGRESSIVE_SIZE_REDUCTION_THRESHOLD.getName() + ".");
/* 254:    */     }
/* 255:250 */     Dumper debugDumper = new StdIODumper(new TypeUsageInformationEmpty(), options, new IllegalIdentifierDump.Nop());
/* 256:251 */     SortedMap<Integer, Integer> lutByOffset = new TreeMap();
/* 257:252 */     Map<Integer, Integer> lutByIdx = new HashMap();
/* 258:253 */     int idx2 = 0;
/* 259:254 */     int offset2 = -1;
/* 260:255 */     for (Op01WithProcessedDataAndByteJumps op : instrs)
/* 261:    */     {
/* 262:256 */       lutByOffset.put(Integer.valueOf(offset2), Integer.valueOf(idx2));
/* 263:257 */       lutByIdx.put(Integer.valueOf(idx2), Integer.valueOf(offset2));
/* 264:258 */       offset2 += op.getInstructionLength();
/* 265:259 */       idx2++;
/* 266:    */     }
/* 267:261 */     lutByIdx.put(Integer.valueOf(0), Integer.valueOf(-1));
/* 268:262 */     lutByOffset.put(Integer.valueOf(-1), Integer.valueOf(0));
/* 269:    */     
/* 270:264 */     List<Op01WithProcessedDataAndByteJumps> op1list = ListFactory.newList();
/* 271:265 */     List<Op02WithProcessedDataAndRefs> op2list = ListFactory.newList();
/* 272:267 */     for (int x = 0; x < instrs.size(); x++)
/* 273:    */     {
/* 274:268 */       Op01WithProcessedDataAndByteJumps op1 = (Op01WithProcessedDataAndByteJumps)instrs.get(x);
/* 275:269 */       op1list.add(op1);
/* 276:270 */       Op02WithProcessedDataAndRefs op2 = op1.createOp2(this.cp, x);
/* 277:271 */       op2list.add(op2);
/* 278:    */     }
/* 279:275 */     int x = 0;
/* 280:275 */     for (int len = instrs.size(); x < len; x++)
/* 281:    */     {
/* 282:276 */       int offsetOfThisInstruction = ((Integer)lutByIdx.get(Integer.valueOf(x))).intValue();
/* 283:277 */       int[] targetIdxs = ((Op01WithProcessedDataAndByteJumps)op1list.get(x)).getAbsoluteIndexJumps(offsetOfThisInstruction, lutByOffset);
/* 284:278 */       Op02WithProcessedDataAndRefs source = (Op02WithProcessedDataAndRefs)op2list.get(x);
/* 285:279 */       for (int targetIdx : targetIdxs) {
/* 286:280 */         if (targetIdx < len)
/* 287:    */         {
/* 288:281 */           Op02WithProcessedDataAndRefs target = (Op02WithProcessedDataAndRefs)op2list.get(targetIdx);
/* 289:282 */           source.addTarget(target);
/* 290:283 */           target.addSource(source);
/* 291:    */         }
/* 292:    */       }
/* 293:    */     }
/* 294:289 */     BlockIdentifierFactory blockIdentifierFactory = new BlockIdentifierFactory();
/* 295:    */     
/* 296:    */ 
/* 297:292 */     ExceptionAggregator exceptions = new ExceptionAggregator(this.originalCodeAttribute.getExceptionTableEntries(), blockIdentifierFactory, lutByOffset, lutByIdx, instrs, options, this.cp, this.method);
/* 298:293 */     if (exceptions.RemovedLoopingExceptions()) {
/* 299:294 */       comments.addComment(DecompilerComment.LOOPING_EXCEPTIONS);
/* 300:    */     }
/* 301:299 */     if (showOpsLevel == 1)
/* 302:    */     {
/* 303:300 */       debugDumper.print("Op2 statements:\n");
/* 304:301 */       debugDumper.dump(op2list);
/* 305:302 */       debugDumper.newln().newln();
/* 306:    */     }
/* 307:308 */     if (options.getOption(OptionsImpl.FORCE_PRUNE_EXCEPTIONS) == Troolean.TRUE)
/* 308:    */     {
/* 309:313 */       exceptions.aggressivePruning(lutByOffset, lutByIdx, instrs);
/* 310:    */       
/* 311:    */ 
/* 312:    */ 
/* 313:317 */       exceptions.removeSynchronisedHandlers(lutByOffset, lutByIdx, instrs);
/* 314:    */     }
/* 315:326 */     if ((((Boolean)options.getOption(OptionsImpl.REWRITE_LAMBDAS, classFileVersion)).booleanValue()) && (bytecodeMeta.has(BytecodeMeta.CodeInfoFlag.USES_INVOKEDYNAMIC))) {
/* 316:328 */       Op02GetClassRewriter.removeInvokeGetClass(classFile, op2list, GetClassTestLambda.INSTANCE);
/* 317:    */     }
/* 318:330 */     Op02GetClassRewriter.removeInvokeGetClass(classFile, op2list, GetClassTestInnerConstructor.INSTANCE);
/* 319:    */     
/* 320:332 */     long codeLength = this.originalCodeAttribute.getCodeLength();
/* 321:333 */     op2list = Op02WithProcessedDataAndRefs.insertExceptionBlocks(op2list, exceptions, lutByOffset, this.cp, codeLength, dcCommonState, options);
/* 322:343 */     if (aggressiveSizeReductions) {
/* 323:344 */       Op02RedundantStoreRewriter.rewrite(op2list, this.originalCodeAttribute.getMaxLocals());
/* 324:    */     }
/* 325:352 */     Op02WithProcessedDataAndRefs.populateStackInfo(op2list, this.method);
/* 326:354 */     if (showOpsLevel == 2)
/* 327:    */     {
/* 328:355 */       debugDumper.print("Op2 statements:\n");
/* 329:356 */       debugDumper.dump(op2list);
/* 330:357 */       debugDumper.newln().newln();
/* 331:    */     }
/* 332:368 */     if (Op02WithProcessedDataAndRefs.processJSR(op2list)) {
/* 333:370 */       Op02WithProcessedDataAndRefs.populateStackInfo(op2list, this.method);
/* 334:    */     }
/* 335:378 */     Op02WithProcessedDataAndRefs.unlinkUnreachable(op2list);
/* 336:    */     
/* 337:    */ 
/* 338:    */ 
/* 339:382 */     Op02WithProcessedDataAndRefs.discoverStorageLiveness(this.method, comments, op2list, bytecodeMeta, options);
/* 340:    */     
/* 341:    */ 
/* 342:385 */     VariableFactory variableFactory = new VariableFactory(this.method);
/* 343:    */     
/* 344:387 */     TypeHintRecovery typeHintRecovery = options.optionIsSet(OptionsImpl.USE_RECOVERED_ITERATOR_TYPE_HINTS) ? new TypeHintRecoveryImpl(bytecodeMeta) : TypeHintRecoveryNone.INSTANCE;
/* 345:    */     
/* 346:    */ 
/* 347:390 */     List<Op03SimpleStatement> op03SimpleParseNodes = Op02WithProcessedDataAndRefs.convertToOp03List(op2list, this.method, variableFactory, blockIdentifierFactory, dcCommonState, typeHintRecovery);
/* 348:    */     
/* 349:392 */     op03SimpleParseNodes = Cleaner.sortAndRenumber(op03SimpleParseNodes);
/* 350:395 */     if (showOpsLevel == 3)
/* 351:    */     {
/* 352:396 */       debugDumper.print("Raw Op3 statements:\n");
/* 353:397 */       for (Op03SimpleStatement node : op03SimpleParseNodes) {
/* 354:398 */         node.dumpInner(debugDumper);
/* 355:    */       }
/* 356:400 */       debugDumper.print("\n\n");
/* 357:    */     }
/* 358:403 */     if (showOpsLevel == 4)
/* 359:    */     {
/* 360:404 */       debugDumper.newln().newln();
/* 361:405 */       debugDumper.print("Linked Op3 statements:\n");
/* 362:406 */       ((Op03SimpleStatement)op03SimpleParseNodes.get(0)).dump(debugDumper);
/* 363:407 */       debugDumper.print("\n\n");
/* 364:    */     }
/* 365:411 */     Misc.flattenCompoundStatements(op03SimpleParseNodes);
/* 366:    */     
/* 367:    */ 
/* 368:414 */     Op03SimpleStatement.rewriteWith(op03SimpleParseNodes, new NullTypedLValueRewriter());
/* 369:    */     
/* 370:    */ 
/* 371:    */ 
/* 372:    */ 
/* 373:    */ 
/* 374:420 */     GenericInferer.inferGenericObjectInfoFromCalls(op03SimpleParseNodes);
/* 375:    */     
/* 376:    */ 
/* 377:423 */     SwitchReplacer.replaceRawSwitches(this.method, op03SimpleParseNodes, blockIdentifierFactory, options);
/* 378:424 */     op03SimpleParseNodes = Cleaner.sortAndRenumber(op03SimpleParseNodes);
/* 379:    */     
/* 380:    */ 
/* 381:427 */     Op03SimpleStatement.removePointlessJumps(op03SimpleParseNodes);
/* 382:    */     
/* 383:429 */     op03SimpleParseNodes = Cleaner.sortAndRenumber(op03SimpleParseNodes);
/* 384:431 */     if (aggressiveSizeReductions) {
/* 385:432 */       op03SimpleParseNodes = LValuePropSimple.condenseSimpleLValues(op03SimpleParseNodes);
/* 386:    */     }
/* 387:435 */     Op03SimpleStatement.assignSSAIdentifiers(this.method, op03SimpleParseNodes);
/* 388:    */     
/* 389:    */ 
/* 390:438 */     LValueProp.condenseLValues(op03SimpleParseNodes);
/* 391:439 */     op03SimpleParseNodes = Cleaner.sortAndRenumber(op03SimpleParseNodes);
/* 392:    */     
/* 393:    */ 
/* 394:    */ 
/* 395:443 */     op03SimpleParseNodes = Op03SimpleStatement.eliminateCatchTemporaries(op03SimpleParseNodes);
/* 396:    */     
/* 397:445 */     logger.info("identifyCatchBlocks");
/* 398:446 */     Op03SimpleStatement.identifyCatchBlocks(op03SimpleParseNodes, blockIdentifierFactory);
/* 399:    */     
/* 400:448 */     Op03SimpleStatement.combineTryCatchBlocks(op03SimpleParseNodes, blockIdentifierFactory);
/* 401:450 */     if (((Boolean)options.getOption(OptionsImpl.COMMENT_MONITORS)).booleanValue()) {
/* 402:451 */       Op03SimpleStatement.commentMonitors(op03SimpleParseNodes);
/* 403:    */     }
/* 404:455 */     if (showOpsLevel == 5)
/* 405:    */     {
/* 406:456 */       debugDumper.newln().newln();
/* 407:457 */       debugDumper.print("After catchblocks.:\n");
/* 408:458 */       ((Op03SimpleStatement)op03SimpleParseNodes.get(0)).dump(debugDumper);
/* 409:    */     }
/* 410:465 */     AnonymousClassUsage anonymousClassUsage = new AnonymousClassUsage();
/* 411:    */     
/* 412:    */ 
/* 413:    */ 
/* 414:    */ 
/* 415:    */ 
/* 416:    */ 
/* 417:    */ 
/* 418:    */ 
/* 419:    */ 
/* 420:475 */     Op03SimpleStatement.condenseConstruction(dcCommonState, this.method, op03SimpleParseNodes, anonymousClassUsage);
/* 421:476 */     LValueProp.condenseLValues(op03SimpleParseNodes);
/* 422:477 */     Op03SimpleStatement.condenseLValueChain1(op03SimpleParseNodes);
/* 423:    */     
/* 424:479 */     op03SimpleParseNodes = StaticInitReturnRewriter.rewrite(options, this.method, op03SimpleParseNodes);
/* 425:    */     
/* 426:481 */     op03SimpleParseNodes = Op03SimpleStatement.removeRedundantTries(op03SimpleParseNodes);
/* 427:    */     
/* 428:483 */     FinallyRewriter.identifyFinally(options, this.method, op03SimpleParseNodes, blockIdentifierFactory);
/* 429:    */     
/* 430:485 */     op03SimpleParseNodes = Cleaner.removeUnreachableCode(op03SimpleParseNodes, !willSort);
/* 431:486 */     op03SimpleParseNodes = Cleaner.sortAndRenumber(op03SimpleParseNodes);
/* 432:    */     
/* 433:    */ 
/* 434:    */ 
/* 435:    */ 
/* 436:    */ 
/* 437:492 */     Op03SimpleStatement.extendTryBlocks(dcCommonState, op03SimpleParseNodes);
/* 438:493 */     Op03SimpleStatement.combineTryCatchEnds(op03SimpleParseNodes);
/* 439:    */     
/* 440:    */ 
/* 441:496 */     Op03SimpleStatement.removePointlessExpressionStatements(op03SimpleParseNodes);
/* 442:497 */     op03SimpleParseNodes = Cleaner.removeUnreachableCode(op03SimpleParseNodes, !willSort);
/* 443:    */     
/* 444:    */ 
/* 445:    */ 
/* 446:    */ 
/* 447:502 */     Op03SimpleStatement.replacePrePostChangeAssignments(op03SimpleParseNodes);
/* 448:    */     
/* 449:    */ 
/* 450:505 */     Op03SimpleStatement.pushPreChangeBack(op03SimpleParseNodes);
/* 451:    */     
/* 452:507 */     Op03SimpleStatement.condenseLValueChain2(op03SimpleParseNodes);
/* 453:    */     
/* 454:    */ 
/* 455:    */ 
/* 456:    */ 
/* 457:512 */     Op03SimpleStatement.collapseAssignmentsIntoConditionals(op03SimpleParseNodes, options);
/* 458:513 */     LValueProp.condenseLValues(op03SimpleParseNodes);
/* 459:514 */     op03SimpleParseNodes = Cleaner.sortAndRenumber(op03SimpleParseNodes);
/* 460:516 */     if (options.getOption(OptionsImpl.FORCE_COND_PROPAGATE) == Troolean.TRUE) {
/* 461:517 */       op03SimpleParseNodes = RemoveDeterministicJumps.apply(this.method, op03SimpleParseNodes);
/* 462:    */     }
/* 463:520 */     if (options.getOption(OptionsImpl.FORCE_TOPSORT) == Troolean.TRUE)
/* 464:    */     {
/* 465:521 */       if (options.getOption(OptionsImpl.FORCE_RETURNING_IFS) == Troolean.TRUE) {
/* 466:522 */         Op03SimpleStatement.replaceReturningIfs(op03SimpleParseNodes, true);
/* 467:    */       }
/* 468:524 */       if (options.getOption(OptionsImpl.FORCE_COND_PROPAGATE) == Troolean.TRUE) {
/* 469:525 */         Op03SimpleStatement.propagateToReturn2(this.method, op03SimpleParseNodes);
/* 470:    */       }
/* 471:528 */       op03SimpleParseNodes = Cleaner.removeUnreachableCode(op03SimpleParseNodes, false);
/* 472:    */       
/* 473:    */ 
/* 474:531 */       op03SimpleParseNodes = Op03Blocks.topologicalSort(this.method, op03SimpleParseNodes, comments, options);
/* 475:532 */       Op03SimpleStatement.removePointlessJumps(op03SimpleParseNodes);
/* 476:    */       
/* 477:    */ 
/* 478:    */ 
/* 479:    */ 
/* 480:537 */       SwitchReplacer.rebuildSwitches(op03SimpleParseNodes, options);
/* 481:    */       
/* 482:    */ 
/* 483:    */ 
/* 484:    */ 
/* 485:542 */       Op03SimpleStatement.rejoinBlocks(op03SimpleParseNodes);
/* 486:543 */       Op03SimpleStatement.extendTryBlocks(dcCommonState, op03SimpleParseNodes);
/* 487:544 */       op03SimpleParseNodes = Op03Blocks.combineTryBlocks(this.method, op03SimpleParseNodes);
/* 488:545 */       Op03SimpleStatement.combineTryCatchEnds(op03SimpleParseNodes);
/* 489:546 */       Op03SimpleStatement.rewriteTryBackJumps(op03SimpleParseNodes);
/* 490:547 */       FinallyRewriter.identifyFinally(options, this.method, op03SimpleParseNodes, blockIdentifierFactory);
/* 491:548 */       if (options.getOption(OptionsImpl.FORCE_RETURNING_IFS) == Troolean.TRUE) {
/* 492:549 */         Op03SimpleStatement.replaceReturningIfs(op03SimpleParseNodes, true);
/* 493:    */       }
/* 494:    */     }
/* 495:557 */     if (options.getOption(OptionsImpl.FORCE_COND_PROPAGATE) == Troolean.TRUE) {
/* 496:558 */       RemoveDeterministicJumps.propagateToReturn(this.method, op03SimpleParseNodes);
/* 497:    */     }
/* 498:561 */     logger.info("sugarAnyonymousArrays");
/* 499:562 */     AnonymousArray.resugarAnonymousArrays(op03SimpleParseNodes);
/* 500:    */     
/* 501:564 */     boolean reloop = false;
/* 502:    */     do
/* 503:    */     {
/* 504:566 */       Op03SimpleStatement.rewriteNegativeJumps(op03SimpleParseNodes, true);
/* 505:    */       
/* 506:568 */       logger.info("collapseAssignmentsIntoConditionals");
/* 507:569 */       Op03SimpleStatement.collapseAssignmentsIntoConditionals(op03SimpleParseNodes, options);
/* 508:    */       
/* 509:    */ 
/* 510:572 */       logger.info("condenseConditionals");
/* 511:573 */       reloop = Op03SimpleStatement.condenseConditionals(op03SimpleParseNodes);
/* 512:    */       
/* 513:    */ 
/* 514:    */ 
/* 515:577 */       reloop |= Op03SimpleStatement.condenseConditionals2(op03SimpleParseNodes);
/* 516:578 */       reloop |= Op03SimpleStatement.normalizeDupAssigns(op03SimpleParseNodes);
/* 517:579 */       if (reloop) {
/* 518:580 */         LValueProp.condenseLValues(op03SimpleParseNodes);
/* 519:    */       }
/* 520:582 */       op03SimpleParseNodes = Cleaner.removeUnreachableCode(op03SimpleParseNodes, true);
/* 521:584 */     } while (reloop);
/* 522:586 */     logger.info("simplifyConditionals");
/* 523:587 */     Op03SimpleStatement.simplifyConditionals(op03SimpleParseNodes, false);
/* 524:588 */     op03SimpleParseNodes = Cleaner.sortAndRenumber(op03SimpleParseNodes);
/* 525:    */     
/* 526:    */ 
/* 527:591 */     logger.info("rewriteNegativeJumps");
/* 528:592 */     Op03SimpleStatement.rewriteNegativeJumps(op03SimpleParseNodes, false);
/* 529:    */     
/* 530:594 */     Op03SimpleStatement.optimiseForTypes(op03SimpleParseNodes);
/* 531:596 */     if (showOpsLevel == 6)
/* 532:    */     {
/* 533:597 */       debugDumper.newln().newln();
/* 534:598 */       debugDumper.print("After jumps.:\n");
/* 535:599 */       ((Op03SimpleStatement)op03SimpleParseNodes.get(0)).dump(debugDumper);
/* 536:    */     }
/* 537:616 */     if (((Boolean)options.getOption(OptionsImpl.ECLIPSE)).booleanValue()) {
/* 538:617 */       Op03SimpleStatement.eclipseLoopPass(op03SimpleParseNodes);
/* 539:    */     }
/* 540:622 */     logger.info("identifyLoops1");
/* 541:623 */     op03SimpleParseNodes = Cleaner.removeUnreachableCode(op03SimpleParseNodes, true);
/* 542:624 */     LoopIdentifier.identifyLoops1(this.method, op03SimpleParseNodes, blockIdentifierFactory);
/* 543:    */     
/* 544:    */ 
/* 545:627 */     op03SimpleParseNodes = Op03SimpleStatement.pushThroughGoto(this.method, op03SimpleParseNodes);
/* 546:631 */     if (options.getOption(OptionsImpl.FORCE_RETURNING_IFS) == Troolean.TRUE) {
/* 547:632 */       Op03SimpleStatement.replaceReturningIfs(op03SimpleParseNodes, false);
/* 548:    */     }
/* 549:635 */     if (showOpsLevel == 7)
/* 550:    */     {
/* 551:636 */       debugDumper.newln().newln();
/* 552:637 */       debugDumper.print("After loops.:\n");
/* 553:638 */       ((Op03SimpleStatement)op03SimpleParseNodes.get(0)).dump(debugDumper);
/* 554:    */     }
/* 555:641 */     op03SimpleParseNodes = Cleaner.sortAndRenumber(op03SimpleParseNodes);
/* 556:642 */     op03SimpleParseNodes = Cleaner.removeUnreachableCode(op03SimpleParseNodes, true);
/* 557:644 */     if (showOpsLevel == 8)
/* 558:    */     {
/* 559:645 */       debugDumper.newln().newln();
/* 560:646 */       debugDumper.print("After exception.:\n");
/* 561:647 */       ((Op03SimpleStatement)op03SimpleParseNodes.get(0)).dump(debugDumper);
/* 562:    */     }
/* 563:652 */     logger.info("rewriteBreakStatements");
/* 564:653 */     Op03SimpleStatement.rewriteBreakStatements(op03SimpleParseNodes);
/* 565:654 */     logger.info("rewriteWhilesAsFors");
/* 566:655 */     Op03SimpleStatement.rewriteDoWhileTruePredAsWhile(op03SimpleParseNodes);
/* 567:656 */     Op03SimpleStatement.rewriteWhilesAsFors(options, op03SimpleParseNodes);
/* 568:    */     
/* 569:    */ 
/* 570:659 */     logger.info("removeSynchronizedCatchBlocks");
/* 571:660 */     Op03SimpleStatement.removeSynchronizedCatchBlocks(options, op03SimpleParseNodes);
/* 572:    */     
/* 573:    */ 
/* 574:    */ 
/* 575:664 */     logger.info("identifyNonjumpingConditionals");
/* 576:    */     
/* 577:666 */     op03SimpleParseNodes = Op03SimpleStatement.removeUselessNops(op03SimpleParseNodes);
/* 578:667 */     Op03SimpleStatement.removePointlessJumps(op03SimpleParseNodes);
/* 579:    */     
/* 580:    */ 
/* 581:    */ 
/* 582:    */ 
/* 583:    */ 
/* 584:673 */     Op03SimpleStatement.extractExceptionJumps(op03SimpleParseNodes);
/* 585:674 */     Op03SimpleStatement.extractAssertionJumps(op03SimpleParseNodes);
/* 586:675 */     op03SimpleParseNodes = Cleaner.removeUnreachableCode(op03SimpleParseNodes, true);
/* 587:    */     
/* 588:    */ 
/* 589:    */ 
/* 590:679 */     ConditionalRewriter.identifyNonjumpingConditionals(op03SimpleParseNodes, blockIdentifierFactory);
/* 591:    */     
/* 592:681 */     LValueProp.condenseLValues(op03SimpleParseNodes);
/* 593:682 */     if (options.getOption(OptionsImpl.FORCE_COND_PROPAGATE) == Troolean.TRUE) {
/* 594:683 */       Op03SimpleStatement.propagateToReturn2(this.method, op03SimpleParseNodes);
/* 595:    */     }
/* 596:686 */     logger.info("removeUselessNops");
/* 597:687 */     op03SimpleParseNodes = Op03SimpleStatement.removeUselessNops(op03SimpleParseNodes);
/* 598:    */     
/* 599:    */ 
/* 600:    */ 
/* 601:    */ 
/* 602:692 */     logger.info("removePointlessJumps");
/* 603:693 */     Op03SimpleStatement.removePointlessJumps(op03SimpleParseNodes);
/* 604:694 */     logger.info("rewriteBreakStatements");
/* 605:695 */     Op03SimpleStatement.rewriteBreakStatements(op03SimpleParseNodes);
/* 606:    */     
/* 607:    */ 
/* 608:    */ 
/* 609:    */ 
/* 610:    */ 
/* 611:    */ 
/* 612:702 */     Op03SimpleStatement.classifyGotos(op03SimpleParseNodes);
/* 613:703 */     if (((Boolean)options.getOption(OptionsImpl.LABELLED_BLOCKS)).booleanValue()) {
/* 614:704 */       Op03SimpleStatement.classifyAnonymousBlockGotos(op03SimpleParseNodes);
/* 615:    */     }
/* 616:712 */     ConditionalRewriter.identifyNonjumpingConditionals(op03SimpleParseNodes, blockIdentifierFactory);
/* 617:    */     
/* 618:    */ 
/* 619:    */ 
/* 620:    */ 
/* 621:    */ 
/* 622:718 */     InlineDeAssigner.extractAssignments(op03SimpleParseNodes);
/* 623:    */     
/* 624:    */ 
/* 625:721 */     logger.info("rewriteArrayForLoops");
/* 626:722 */     boolean checkLoopTypeClash = false;
/* 627:723 */     if (((Boolean)options.getOption(OptionsImpl.ARRAY_ITERATOR, classFileVersion)).booleanValue())
/* 628:    */     {
/* 629:724 */       IterLoopRewriter.rewriteArrayForLoops(op03SimpleParseNodes);
/* 630:725 */       checkLoopTypeClash = true;
/* 631:    */     }
/* 632:728 */     logger.info("rewriteIteratorWhileLoops");
/* 633:729 */     if (((Boolean)options.getOption(OptionsImpl.COLLECTION_ITERATOR, classFileVersion)).booleanValue())
/* 634:    */     {
/* 635:730 */       IterLoopRewriter.rewriteIteratorWhileLoops(op03SimpleParseNodes);
/* 636:731 */       checkLoopTypeClash = true;
/* 637:    */     }
/* 638:734 */     logger.info("findSynchronizedBlocks");
/* 639:735 */     SynchronizedBlocks.findSynchronizedBlocks(op03SimpleParseNodes);
/* 640:    */     
/* 641:737 */     logger.info("removePointlessSwitchDefaults");
/* 642:738 */     Op03SimpleStatement.removePointlessSwitchDefaults(op03SimpleParseNodes);
/* 643:    */     
/* 644:    */ 
/* 645:    */ 
/* 646:    */ 
/* 647:    */ 
/* 648:744 */     logger.info("removeUselessNops");
/* 649:745 */     op03SimpleParseNodes = Op03SimpleStatement.removeUselessNops(op03SimpleParseNodes);
/* 650:    */     
/* 651:    */ 
/* 652:    */ 
/* 653:    */ 
/* 654:    */ 
/* 655:    */ 
/* 656:752 */     Op03SimpleStatement.rewriteWith(op03SimpleParseNodes, new StringBuilderRewriter(options, classFileVersion));
/* 657:753 */     Op03SimpleStatement.rewriteWith(op03SimpleParseNodes, new XorRewriter());
/* 658:758 */     if (showOpsLevel == 9)
/* 659:    */     {
/* 660:759 */       debugDumper.newln().newln();
/* 661:760 */       debugDumper.print("Final Op3 statements:\n");
/* 662:761 */       ((Op03SimpleStatement)op03SimpleParseNodes.get(0)).dump(debugDumper);
/* 663:    */     }
/* 664:763 */     op03SimpleParseNodes = Cleaner.removeUnreachableCode(op03SimpleParseNodes, true);
/* 665:765 */     if (((Boolean)options.getOption(OptionsImpl.LABELLED_BLOCKS)).booleanValue()) {
/* 666:770 */       Op03SimpleStatement.labelAnonymousBlocks(op03SimpleParseNodes, blockIdentifierFactory);
/* 667:    */     }
/* 668:780 */     Op03SimpleStatement.simplifyConditionals(op03SimpleParseNodes, true);
/* 669:781 */     Op03SimpleStatement.extractExceptionMiddle(op03SimpleParseNodes);
/* 670:782 */     Op03SimpleStatement.removePointlessJumps(op03SimpleParseNodes);
/* 671:    */     
/* 672:    */ 
/* 673:    */ 
/* 674:    */ 
/* 675:    */ 
/* 676:    */ 
/* 677:    */ 
/* 678:790 */     Op03SimpleStatement.replaceStackVarsWithLocals(op03SimpleParseNodes);
/* 679:    */     
/* 680:    */ 
/* 681:    */ 
/* 682:    */ 
/* 683:    */ 
/* 684:    */ 
/* 685:    */ 
/* 686:    */ 
/* 687:799 */     Op03SimpleStatement.narrowAssignmentTypes(this.method, op03SimpleParseNodes);
/* 688:801 */     if (((Boolean)options.getOption(OptionsImpl.SHOW_INFERRABLE, classFileVersion)).booleanValue()) {
/* 689:802 */       Op03SimpleStatement.rewriteWith(op03SimpleParseNodes, new ExplicitTypeCallRewriter());
/* 690:    */     }
/* 691:809 */     if ((passIdx == 0) && (checkLoopTypeClash))
/* 692:    */     {
/* 693:810 */       if (LoopLivenessClash.detect(op03SimpleParseNodes, bytecodeMeta)) {
/* 694:811 */         comments.addComment(DecompilerComment.TYPE_CLASHES);
/* 695:    */       }
/* 696:813 */       if (bytecodeMeta.has(BytecodeMeta.CodeInfoFlag.ITERATED_TYPE_HINTS)) {
/* 697:814 */         comments.addComment(DecompilerComment.ITERATED_TYPE_HINTS);
/* 698:    */       }
/* 699:    */     }
/* 700:818 */     Cleaner.reindexInPlace(op03SimpleParseNodes);
/* 701:    */     
/* 702:    */ 
/* 703:    */ 
/* 704:    */ 
/* 705:    */ 
/* 706:    */ 
/* 707:825 */     Op04StructuredStatement block = Op03SimpleStatement.createInitialStructuredBlock(op03SimpleParseNodes);
/* 708:    */     
/* 709:827 */     Op04StructuredStatement.tidyEmptyCatch(block);
/* 710:828 */     Op04StructuredStatement.tidyTryCatch(block);
/* 711:829 */     Op04StructuredStatement.convertUnstructuredIf(block);
/* 712:830 */     Op04StructuredStatement.inlinePossibles(block);
/* 713:831 */     Op04StructuredStatement.removeStructuredGotos(block);
/* 714:832 */     Op04StructuredStatement.removePointlessBlocks(block);
/* 715:833 */     Op04StructuredStatement.removePointlessReturn(block);
/* 716:834 */     Op04StructuredStatement.removePrimitiveDeconversion(options, this.method, block);
/* 717:835 */     if (((Boolean)options.getOption(OptionsImpl.LABELLED_BLOCKS)).booleanValue()) {
/* 718:836 */       Op04StructuredStatement.insertLabelledBlocks(block);
/* 719:    */     }
/* 720:840 */     Op04StructuredStatement.removeUnnecessaryLabelledBreaks(block);
/* 721:846 */     if (!block.isFullyStructured())
/* 722:    */     {
/* 723:847 */       comments.addComment(DecompilerComment.UNABLE_TO_STRUCTURE);
/* 724:    */     }
/* 725:    */     else
/* 726:    */     {
/* 727:849 */       Op04StructuredStatement.tidyTypedBooleans(block);
/* 728:850 */       Op04StructuredStatement.prettifyBadLoops(block);
/* 729:    */       
/* 730:    */ 
/* 731:    */ 
/* 732:854 */       new SwitchStringRewriter(options, classFileVersion).rewrite(block);
/* 733:855 */       new SwitchEnumRewriter(dcCommonState, classFileVersion).rewrite(block);
/* 734:    */       
/* 735:    */ 
/* 736:    */ 
/* 737:    */ 
/* 738:    */ 
/* 739:    */ 
/* 740:862 */       Op04StructuredStatement.discoverVariableScopes(this.method, block, variableFactory);
/* 741:869 */       if ((((Boolean)options.getOption(OptionsImpl.REMOVE_BOILERPLATE)).booleanValue()) && 
/* 742:870 */         (this.method.isConstructor())) {
/* 743:870 */         Op04StructuredStatement.removeConstructorBoilerplate(block);
/* 744:    */       }
/* 745:873 */       Op04StructuredStatement.rewriteLambdas(dcCommonState, this.method, block);
/* 746:    */       
/* 747:    */ 
/* 748:876 */       Op04StructuredStatement.removeUnnecessaryVarargArrays(options, this.method, block);
/* 749:    */       
/* 750:878 */       Op04StructuredStatement.removePrimitiveDeconversion(options, this.method, block);
/* 751:    */       
/* 752:    */ 
/* 753:881 */       Op04StructuredStatement.rewriteBadCastChains(options, this.method, block);
/* 754:    */       
/* 755:    */ 
/* 756:884 */       Op04StructuredStatement.tidyVariableNames(this.method, block, bytecodeMeta, comments, this.cp.getClassCache());
/* 757:    */       
/* 758:886 */       Op04StructuredStatement.miscKeyholeTransforms(block);
/* 759:    */       
/* 760:    */ 
/* 761:    */ 
/* 762:    */ 
/* 763:891 */       Op04StructuredStatement.applyChecker(new LooseCatchChecker(), block, comments);
/* 764:    */       
/* 765:    */ 
/* 766:    */ 
/* 767:    */ 
/* 768:896 */       Op04StructuredStatement.applyTypeAnnotations(this.originalCodeAttribute, block, lutByOffset, comments);
/* 769:    */     }
/* 770:900 */     if ((passIdx == 0) && 
/* 771:901 */       (Op04StructuredStatement.checkTypeClashes(block, bytecodeMeta))) {
/* 772:902 */       comments.addComment(DecompilerComment.TYPE_CLASHES);
/* 773:    */     }
/* 774:906 */     return new AnalysisResult(comments, block, anonymousClassUsage, null);
/* 775:    */   }
/* 776:    */   
/* 777:    */   public void dump(Dumper d)
/* 778:    */   {
/* 779:911 */     d.newln();
/* 780:912 */     this.analysed.dump(d);
/* 781:    */   }
/* 782:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.CodeAnalyser
 * JD-Core Version:    0.7.0.1
 */