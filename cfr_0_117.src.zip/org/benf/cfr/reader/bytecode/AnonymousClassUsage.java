/*  1:   */ package org.benf.cfr.reader.bytecode;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationAnonymousInner;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  6:   */ import org.benf.cfr.reader.entities.ClassFile;
/*  7:   */ import org.benf.cfr.reader.util.ListFactory;
/*  8:   */ 
/*  9:   */ public class AnonymousClassUsage
/* 10:   */ {
/* 11:16 */   private final List<Pair<ClassFile, ConstructorInvokationAnonymousInner>> noted = ListFactory.newList();
/* 12:   */   
/* 13:   */   public void note(ClassFile classFile, ConstructorInvokationAnonymousInner constructorInvokationAnonymousInner)
/* 14:   */   {
/* 15:19 */     this.noted.add(Pair.make(classFile, constructorInvokationAnonymousInner));
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void useNotes()
/* 19:   */   {
/* 20:23 */     for (Pair<ClassFile, ConstructorInvokationAnonymousInner> note : this.noted) {
/* 21:24 */       ((ClassFile)note.getFirst()).noteAnonymousUse((ConstructorInvokationAnonymousInner)note.getSecond());
/* 22:   */     }
/* 23:   */   }
/* 24:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.AnonymousClassUsage
 * JD-Core Version:    0.7.0.1
 */