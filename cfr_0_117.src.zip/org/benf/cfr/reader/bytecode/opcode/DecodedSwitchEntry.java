/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.util.StringUtils;
/*  5:   */ 
/*  6:   */ public class DecodedSwitchEntry
/*  7:   */ {
/*  8:   */   private final List<Integer> value;
/*  9:   */   private final int bytecodeTarget;
/* 10:   */   
/* 11:   */   public DecodedSwitchEntry(List<Integer> value, int bytecodeTarget)
/* 12:   */   {
/* 13:12 */     this.bytecodeTarget = bytecodeTarget;
/* 14:13 */     this.value = value;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public List<Integer> getValue()
/* 18:   */   {
/* 19:17 */     return this.value;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public int getBytecodeTarget()
/* 23:   */   {
/* 24:21 */     return this.bytecodeTarget;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public String toString()
/* 28:   */   {
/* 29:26 */     StringBuilder sb = new StringBuilder();
/* 30:27 */     boolean first = true;
/* 31:28 */     sb.append("case ");
/* 32:29 */     for (Integer val : this.value)
/* 33:   */     {
/* 34:30 */       first = StringUtils.comma(first, sb);
/* 35:31 */       sb.append(val == null ? "default" : val);
/* 36:   */     }
/* 37:33 */     sb.append(" -> ").append(this.bytecodeTarget);
/* 38:34 */     return sb.toString();
/* 39:   */   }
/* 40:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.DecodedSwitchEntry
 * JD-Core Version:    0.7.0.1
 */