/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDelta;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDeltaImpl;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackEntry;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackSim;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackTypes;
/* 11:   */ import org.benf.cfr.reader.entities.Method;
/* 12:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/* 13:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/* 14:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/* 15:   */ import org.benf.cfr.reader.util.ListFactory;
/* 16:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/* 17:   */ 
/* 18:   */ public class OperationFactoryFakeCatch
/* 19:   */   extends OperationFactoryDefault
/* 20:   */ {
/* 21:   */   public StackDelta getStackDelta(JVMInstr instr, byte[] data, ConstantPoolEntry[] cpEntries, StackSim stackSim, Method method)
/* 22:   */   {
/* 23:23 */     StackTypes pushed = StackType.REF.asList();
/* 24:24 */     List<StackType> popped = ListFactory.newList();
/* 25:25 */     for (int x = 0; x < stackSim.getDepth(); x++) {
/* 26:26 */       popped.add(stackSim.getEntry(x).getType());
/* 27:   */     }
/* 28:28 */     return new StackDeltaImpl(new StackTypes(popped), pushed);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public Op01WithProcessedDataAndByteJumps createOperation(JVMInstr instr, ByteData bd, ConstantPool cp, int offset)
/* 32:   */   {
/* 33:33 */     throw new ConfusedCFRException("Fake catch should never be created from bytecode");
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryFakeCatch
 * JD-Core Version:    0.7.0.1
 */