/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDelta;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDeltaImpl;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackSim;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackTypes;
/*  8:   */ import org.benf.cfr.reader.entities.Method;
/*  9:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/* 10:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryFieldRef;
/* 11:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/* 12:   */ 
/* 13:   */ public class OperationFactoryPutField
/* 14:   */   extends OperationFactoryCPEntryW
/* 15:   */ {
/* 16:   */   public StackDelta getStackDelta(JVMInstr instr, byte[] data, ConstantPoolEntry[] cpEntries, StackSim stackSim, Method method)
/* 17:   */   {
/* 18:19 */     ConstantPoolEntryFieldRef fieldRef = (ConstantPoolEntryFieldRef)cpEntries[0];
/* 19:20 */     if (fieldRef == null) {
/* 20:20 */       throw new ConfusedCFRException("Expecting fieldRef");
/* 21:   */     }
/* 22:21 */     StackType stackType = fieldRef.getStackType();
/* 23:22 */     return new StackDeltaImpl(new StackTypes(new StackType[] { StackType.REF, stackType }), StackTypes.EMPTY);
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryPutField
 * JD-Core Version:    0.7.0.1
 */