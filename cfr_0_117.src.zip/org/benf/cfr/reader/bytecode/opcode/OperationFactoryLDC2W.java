/* 1:  */ package org.benf.cfr.reader.bytecode.opcode;
/* 2:  */ 
/* 3:  */ public class OperationFactoryLDC2W
/* 4:  */   extends OperationFactoryLDCW
/* 5:  */ {
/* 6:  */   protected int getRequiredComputationCategory()
/* 7:  */   {
/* 8:6 */     return 2;
/* 9:  */   }
/* ::  */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC2W
 * JD-Core Version:    0.7.0.1
 */