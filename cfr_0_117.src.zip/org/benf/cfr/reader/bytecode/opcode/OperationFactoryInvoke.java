/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDelta;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackSim;
/*  6:   */ import org.benf.cfr.reader.entities.Method;
/*  7:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  8:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/*  9:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodRef;
/* 10:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryNameAndType;
/* 11:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/* 12:   */ 
/* 13:   */ public class OperationFactoryInvoke
/* 14:   */   extends OperationFactoryDefault
/* 15:   */ {
/* 16:   */   private static final int LENGTH_OF_DATA = 2;
/* 17:   */   private static final int OFFSET_OF_METHOD_INDEX = 1;
/* 18:   */   private final boolean instance;
/* 19:   */   
/* 20:   */   public OperationFactoryInvoke(boolean instance)
/* 21:   */   {
/* 22:18 */     this.instance = instance;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public Op01WithProcessedDataAndByteJumps createOperation(JVMInstr instr, ByteData bd, ConstantPool cp, int offset)
/* 26:   */   {
/* 27:23 */     byte[] args = bd.getBytesAt(2, 1L);
/* 28:24 */     int[] targetOffsets = null;
/* 29:25 */     ConstantPoolEntry[] cpEntries = { cp.getEntry(bd.getS2At(1L)) };
/* 30:   */     
/* 31:   */ 
/* 32:28 */     return new Op01WithProcessedDataAndByteJumps(instr, args, targetOffsets, offset, cpEntries);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public StackDelta getStackDelta(JVMInstr instr, byte[] data, ConstantPoolEntry[] cpEntries, StackSim stackSim, Method method)
/* 36:   */   {
/* 37:34 */     ConstantPoolEntryMethodRef methodRef = (ConstantPoolEntryMethodRef)cpEntries[0];
/* 38:   */     
/* 39:36 */     return methodRef.getNameAndTypeEntry().getStackDelta(this.instance);
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryInvoke
 * JD-Core Version:    0.7.0.1
 */