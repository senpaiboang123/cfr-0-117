/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Map;
/*  5:   */ import java.util.Map.Entry;
/*  6:   */ import java.util.TreeMap;
/*  7:   */ import org.benf.cfr.reader.util.ListFactory;
/*  8:   */ import org.benf.cfr.reader.util.MapFactory;
/*  9:   */ import org.benf.cfr.reader.util.bytestream.BaseByteData;
/* 10:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/* 11:   */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/* 12:   */ 
/* 13:   */ public class DecodedTableSwitch
/* 14:   */   implements DecodedSwitch
/* 15:   */ {
/* 16:   */   private static final int OFFSET_OF_DEFAULT = 0;
/* 17:   */   private static final int OFFSET_OF_LOWBYTE = 4;
/* 18:   */   private static final int OFFSET_OF_HIGHBYTE = 8;
/* 19:   */   private static final int OFFSET_OF_OFFSETS = 12;
/* 20:   */   private final int startValue;
/* 21:   */   private final int endValue;
/* 22:   */   private final int defaultTarget;
/* 23:   */   private final List<DecodedSwitchEntry> jumpTargets;
/* 24:   */   
/* 25:   */   public DecodedTableSwitch(byte[] data, int offsetOfOriginalInstruction)
/* 26:   */   {
/* 27:28 */     int curoffset = offsetOfOriginalInstruction + 1;
/* 28:29 */     int overflow = curoffset % 4;
/* 29:30 */     int offset = overflow > 0 ? 4 - overflow : 0;
/* 30:   */     
/* 31:32 */     ByteData bd = new BaseByteData(data);
/* 32:33 */     int defaultvalue = bd.getS4At(offset + 0);
/* 33:34 */     int lowvalue = bd.getS4At(offset + 4);
/* 34:35 */     int highvalue = bd.getS4At(offset + 8);
/* 35:36 */     int numoffsets = highvalue - lowvalue + 1;
/* 36:37 */     this.defaultTarget = defaultvalue;
/* 37:38 */     this.startValue = lowvalue;
/* 38:39 */     this.endValue = highvalue;
/* 39:   */     
/* 40:   */ 
/* 41:42 */     Map<Integer, List<Integer>> uniqueTargets = MapFactory.newLazyMap(new TreeMap(), new UnaryFunction()
/* 42:   */     {
/* 43:   */       public List<Integer> invoke(Integer arg)
/* 44:   */       {
/* 45:47 */         return ListFactory.newList();
/* 46:   */       }
/* 47:49 */     });
/* 48:50 */     ((List)uniqueTargets.get(Integer.valueOf(this.defaultTarget))).add(null);
/* 49:51 */     for (int x = 0; x < numoffsets; x++)
/* 50:   */     {
/* 51:52 */       int target = bd.getS4At(offset + 12 + x * 4);
/* 52:53 */       if (target != this.defaultTarget) {
/* 53:54 */         ((List)uniqueTargets.get(Integer.valueOf(target))).add(Integer.valueOf(this.startValue + x));
/* 54:   */       }
/* 55:   */     }
/* 56:58 */     this.jumpTargets = ListFactory.newList();
/* 57:59 */     for (Map.Entry<Integer, List<Integer>> entry : uniqueTargets.entrySet()) {
/* 58:60 */       this.jumpTargets.add(new DecodedSwitchEntry((List)entry.getValue(), ((Integer)entry.getKey()).intValue()));
/* 59:   */     }
/* 60:   */   }
/* 61:   */   
/* 62:   */   public List<DecodedSwitchEntry> getJumpTargets()
/* 63:   */   {
/* 64:67 */     return this.jumpTargets;
/* 65:   */   }
/* 66:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.DecodedTableSwitch
 * JD-Core Version:    0.7.0.1
 */