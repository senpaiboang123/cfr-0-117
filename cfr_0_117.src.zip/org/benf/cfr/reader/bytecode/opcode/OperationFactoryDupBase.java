package org.benf.cfr.reader.bytecode.opcode;

public abstract class OperationFactoryDupBase
  extends OperationFactoryDefault
{}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryDupBase
 * JD-Core Version:    0.7.0.1
 */