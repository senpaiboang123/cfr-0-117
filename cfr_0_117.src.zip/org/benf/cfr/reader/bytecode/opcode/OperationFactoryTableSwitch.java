/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  5:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  6:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  7:   */ 
/*  8:   */ public class OperationFactoryTableSwitch
/*  9:   */   extends OperationFactoryDefault
/* 10:   */ {
/* 11:   */   private static final int OFFSET_OF_LOWBYTE = 4;
/* 12:   */   private static final int OFFSET_OF_HIGHBYTE = 8;
/* 13:   */   private static final int OFFSET_OF_OFFSETS = 12;
/* 14:   */   
/* 15:   */   public Op01WithProcessedDataAndByteJumps createOperation(JVMInstr instr, ByteData bd, ConstantPool cp, int offset)
/* 16:   */   {
/* 17:19 */     int curoffset = offset + 1;
/* 18:   */     
/* 19:21 */     int overflow = curoffset % 4;
/* 20:22 */     overflow = overflow > 0 ? 4 - overflow : 0;
/* 21:23 */     int startdata = 1 + overflow;
/* 22:24 */     int lowvalue = bd.getS4At(startdata + 4);
/* 23:25 */     int highvalue = bd.getS4At(startdata + 8);
/* 24:26 */     int numoffsets = highvalue - lowvalue + 1;
/* 25:27 */     int size = overflow + 12 + 4 * numoffsets;
/* 26:28 */     byte[] rawData = bd.getBytesAt(size, 1L);
/* 27:   */     
/* 28:30 */     DecodedSwitch dts = new DecodedTableSwitch(rawData, offset);
/* 29:31 */     List<DecodedSwitchEntry> targets = dts.getJumpTargets();
/* 30:32 */     int[] targetOffsets = new int[targets.size()];
/* 31:33 */     int out = 0;
/* 32:34 */     for (DecodedSwitchEntry target : targets) {
/* 33:35 */       targetOffsets[(out++)] = target.getBytecodeTarget();
/* 34:   */     }
/* 35:38 */     return new Op01WithProcessedDataAndByteJumps(instr, rawData, targetOffsets, offset);
/* 36:   */   }
/* 37:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryTableSwitch
 * JD-Core Version:    0.7.0.1
 */