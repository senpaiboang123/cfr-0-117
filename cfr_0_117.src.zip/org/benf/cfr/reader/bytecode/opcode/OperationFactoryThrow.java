/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  4:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  5:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  6:   */ 
/*  7:   */ public class OperationFactoryThrow
/*  8:   */   extends OperationFactoryDefault
/*  9:   */ {
/* 10:   */   public Op01WithProcessedDataAndByteJumps createOperation(JVMInstr instr, ByteData bd, ConstantPool cp, int offset)
/* 11:   */   {
/* 12:11 */     byte[] args = instr.getRawLength() == 0 ? null : bd.getBytesAt(instr.getRawLength(), 1L);
/* 13:12 */     int[] targetOffsets = new int[0];
/* 14:13 */     return new Op01WithProcessedDataAndByteJumps(instr, args, targetOffsets, offset);
/* 15:   */   }
/* 16:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryThrow
 * JD-Core Version:    0.7.0.1
 */