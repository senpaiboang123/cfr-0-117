/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  5:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  6:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  7:   */ 
/*  8:   */ public class OperationFactoryLookupSwitch
/*  9:   */   extends OperationFactoryDefault
/* 10:   */ {
/* 11:   */   private static final int OFFSET_OF_NPAIRS = 4;
/* 12:   */   private static final int OFFSET_OF_OFFSETS = 8;
/* 13:   */   
/* 14:   */   public Op01WithProcessedDataAndByteJumps createOperation(JVMInstr instr, ByteData bd, ConstantPool cp, int offset)
/* 15:   */   {
/* 16:18 */     int curoffset = offset + 1;
/* 17:   */     
/* 18:20 */     int overflow = curoffset % 4;
/* 19:21 */     overflow = overflow > 0 ? 4 - overflow : 0;
/* 20:22 */     int startdata = 1 + overflow;
/* 21:23 */     int npairs = bd.getS4At(startdata + 4);
/* 22:24 */     int size = overflow + 8 + 8 * npairs;
/* 23:25 */     byte[] rawData = bd.getBytesAt(size, 1L);
/* 24:   */     
/* 25:27 */     DecodedSwitch dts = new DecodedLookupSwitch(rawData, offset);
/* 26:28 */     List<DecodedSwitchEntry> targets = dts.getJumpTargets();
/* 27:29 */     int[] targetOffsets = new int[targets.size()];
/* 28:30 */     int out = 0;
/* 29:31 */     for (DecodedSwitchEntry target : targets) {
/* 30:32 */       targetOffsets[(out++)] = target.getBytecodeTarget();
/* 31:   */     }
/* 32:35 */     return new Op01WithProcessedDataAndByteJumps(instr, rawData, targetOffsets, offset);
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryLookupSwitch
 * JD-Core Version:    0.7.0.1
 */