/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDelta;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDeltaImpl;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackSim;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackTypes;
/*  8:   */ import org.benf.cfr.reader.entities.Method;
/*  9:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/* 10:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/* 11:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/* 12:   */ 
/* 13:   */ public class OperationFactorySwap
/* 14:   */   extends OperationFactoryDefault
/* 15:   */ {
/* 16:   */   public StackDelta getStackDelta(JVMInstr instr, byte[] data, ConstantPoolEntry[] cpEntries, StackSim stackSim, Method method)
/* 17:   */   {
/* 18:18 */     StackTypes popped = getStackTypes(stackSim, new Integer[] { Integer.valueOf(1), Integer.valueOf(0) });
/* 19:19 */     StackTypes pushed = getStackTypes(stackSim, new Integer[] { Integer.valueOf(0), Integer.valueOf(1) });
/* 20:20 */     return new StackDeltaImpl(popped, pushed);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public Op01WithProcessedDataAndByteJumps createOperation(JVMInstr instr, ByteData bd, ConstantPool cp, int offset)
/* 24:   */   {
/* 25:25 */     byte[] args = null;
/* 26:26 */     int[] targetOffsets = null;
/* 27:27 */     return new Op01WithProcessedDataAndByteJumps(instr, args, targetOffsets, offset);
/* 28:   */   }
/* 29:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactorySwap
 * JD-Core Version:    0.7.0.1
 */