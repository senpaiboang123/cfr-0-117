/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDelta;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDeltaImpl;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackSim;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackTypes;
/*  8:   */ import org.benf.cfr.reader.entities.Method;
/*  9:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/* 10:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryLiteral;
/* 11:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/* 12:   */ 
/* 13:   */ public class OperationFactoryLDCW
/* 14:   */   extends OperationFactoryCPEntryW
/* 15:   */ {
/* 16:   */   public StackDelta getStackDelta(JVMInstr instr, byte[] data, ConstantPoolEntry[] cpEntries, StackSim stackSim, Method method)
/* 17:   */   {
/* 18:19 */     ConstantPoolEntryLiteral constantPoolEntryLiteral = (ConstantPoolEntryLiteral)cpEntries[0];
/* 19:20 */     if (constantPoolEntryLiteral == null) {
/* 20:21 */       throw new ConfusedCFRException("Expecting ConstantPoolEntryLiteral");
/* 21:   */     }
/* 22:23 */     StackType stackType = constantPoolEntryLiteral.getStackType();
/* 23:24 */     int requiredComputationCategory = getRequiredComputationCategory();
/* 24:25 */     if (stackType.getComputationCategory() != requiredComputationCategory) {
/* 25:26 */       throw new ConfusedCFRException("Got a literal, but expected a different category");
/* 26:   */     }
/* 27:29 */     return new StackDeltaImpl(StackTypes.EMPTY, stackType.asList());
/* 28:   */   }
/* 29:   */   
/* 30:   */   protected int getRequiredComputationCategory()
/* 31:   */   {
/* 32:33 */     return 1;
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDCW
 * JD-Core Version:    0.7.0.1
 */