package org.benf.cfr.reader.bytecode.opcode;

import java.util.List;

public abstract interface DecodedSwitch
{
  public abstract List<DecodedSwitchEntry> getJumpTargets();
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.DecodedSwitch
 * JD-Core Version:    0.7.0.1
 */