/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  4:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  5:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  6:   */ 
/*  7:   */ public class OperationFactoryGoto
/*  8:   */   extends OperationFactoryDefault
/*  9:   */ {
/* 10:   */   private static final long OFFSET_OF_TARGET = 1L;
/* 11:   */   
/* 12:   */   public Op01WithProcessedDataAndByteJumps createOperation(JVMInstr instr, ByteData bd, ConstantPool cp, int offset)
/* 13:   */   {
/* 14:14 */     byte[] args = bd.getBytesAt(instr.getRawLength(), 1L);
/* 15:   */     
/* 16:16 */     short targetOffset = bd.getS2At(1L);
/* 17:   */     
/* 18:18 */     int[] targetOffsets = new int[1];
/* 19:19 */     targetOffsets[0] = targetOffset;
/* 20:   */     
/* 21:21 */     return new Op01WithProcessedDataAndByteJumps(instr, args, targetOffsets, offset);
/* 22:   */   }
/* 23:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryGoto
 * JD-Core Version:    0.7.0.1
 */