/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDelta;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDeltaImpl;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackSim;
/*  7:   */ import org.benf.cfr.reader.entities.Method;
/*  8:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  9:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/* 10:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/* 11:   */ 
/* 12:   */ public class OperationFactoryDup2
/* 13:   */   extends OperationFactoryDupBase
/* 14:   */ {
/* 15:   */   public StackDelta getStackDelta(JVMInstr instr, byte[] data, ConstantPoolEntry[] cpEntries, StackSim stackSim, Method method)
/* 16:   */   {
/* 17:17 */     if (getCat(stackSim, 0) == 1)
/* 18:   */     {
/* 19:18 */       checkCat(stackSim, 1, 1);
/* 20:19 */       return new StackDeltaImpl(getStackTypes(stackSim, new Integer[] { Integer.valueOf(0), Integer.valueOf(1) }), getStackTypes(stackSim, new Integer[] { Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(1) }));
/* 21:   */     }
/* 22:24 */     return new StackDeltaImpl(getStackTypes(stackSim, new Integer[] { Integer.valueOf(0) }), getStackTypes(stackSim, new Integer[] { Integer.valueOf(0), Integer.valueOf(0) }));
/* 23:   */   }
/* 24:   */   
/* 25:   */   public Op01WithProcessedDataAndByteJumps createOperation(JVMInstr instr, ByteData bd, ConstantPool cp, int offset)
/* 26:   */   {
/* 27:33 */     byte[] args = null;
/* 28:34 */     int[] targetOffsets = null;
/* 29:35 */     return new Op01WithProcessedDataAndByteJumps(instr, args, targetOffsets, offset);
/* 30:   */   }
/* 31:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryDup2
 * JD-Core Version:    0.7.0.1
 */