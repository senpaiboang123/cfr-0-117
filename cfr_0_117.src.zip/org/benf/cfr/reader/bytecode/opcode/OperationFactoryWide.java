/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  4:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  5:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  6:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  7:   */ 
/*  8:   */ public class OperationFactoryWide
/*  9:   */   extends OperationFactoryDefault
/* 10:   */ {
/* 11:   */   private static JVMInstr getWideInstrVersion(JVMInstr instr)
/* 12:   */   {
/* 13:11 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$opcode$JVMInstr[instr.ordinal()])
/* 14:   */     {
/* 15:   */     case 1: 
/* 16:13 */       return JVMInstr.IINC_WIDE;
/* 17:   */     case 2: 
/* 18:15 */       return JVMInstr.ILOAD_WIDE;
/* 19:   */     case 3: 
/* 20:17 */       return JVMInstr.FLOAD_WIDE;
/* 21:   */     case 4: 
/* 22:19 */       return JVMInstr.ALOAD_WIDE;
/* 23:   */     case 5: 
/* 24:21 */       return JVMInstr.LLOAD_WIDE;
/* 25:   */     case 6: 
/* 26:23 */       return JVMInstr.DLOAD_WIDE;
/* 27:   */     case 7: 
/* 28:25 */       return JVMInstr.ISTORE_WIDE;
/* 29:   */     case 8: 
/* 30:27 */       return JVMInstr.FSTORE_WIDE;
/* 31:   */     case 9: 
/* 32:29 */       return JVMInstr.ASTORE_WIDE;
/* 33:   */     case 10: 
/* 34:31 */       return JVMInstr.LSTORE_WIDE;
/* 35:   */     case 11: 
/* 36:33 */       return JVMInstr.DSTORE_WIDE;
/* 37:   */     case 12: 
/* 38:35 */       return JVMInstr.RET_WIDE;
/* 39:   */     }
/* 40:37 */     throw new ConfusedCFRException("Wide is not defined for instr " + instr);
/* 41:   */   }
/* 42:   */   
/* 43:   */   public Op01WithProcessedDataAndByteJumps createOperation(JVMInstr instr, ByteData bd, ConstantPool cp, int offset)
/* 44:   */   {
/* 45:43 */     JVMInstr widenedInstr = getWideInstrVersion(JVMInstr.find(bd.getS1At(1L)));
/* 46:44 */     return widenedInstr.createOperation(bd, cp, offset);
/* 47:   */   }
/* 48:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryWide
 * JD-Core Version:    0.7.0.1
 */