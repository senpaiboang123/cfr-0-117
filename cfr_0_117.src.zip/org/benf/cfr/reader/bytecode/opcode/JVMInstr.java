/*   1:    */ package org.benf.cfr.reader.bytecode.opcode;
/*   2:    */ 
/*   3:    */ import java.util.HashMap;
/*   4:    */ import java.util.Map;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDelta;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.stack.StackSim;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.types.StackTypes;
/*  11:    */ import org.benf.cfr.reader.entities.Method;
/*  12:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  13:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/*  14:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  15:    */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  16:    */ 
/*  17:    */ public enum JVMInstr
/*  18:    */ {
/*  19: 21 */   AALOAD(50, 0, new StackTypes(new StackType[] { StackType.REF, StackType.INT }), StackType.REF.asList(), RawJavaType.VOID),  AASTORE(83, 0, new StackTypes(new StackType[] { StackType.REF, StackType.INT, StackType.REF }), StackTypes.EMPTY, RawJavaType.VOID),  ACONST_NULL(1, 0, StackTypes.EMPTY, StackType.REF.asList(), RawJavaType.NULL, true),  ALOAD(25, 1, StackTypes.EMPTY, StackType.REF.asList(), RawJavaType.VOID, true),  ALOAD_WIDE(-1, 3, StackTypes.EMPTY, StackType.REF.asList(), RawJavaType.VOID, true),  ALOAD_0(42, 0, StackTypes.EMPTY, StackType.REF.asList(), RawJavaType.REF, true),  ALOAD_1(43, 0, StackTypes.EMPTY, StackType.REF.asList(), RawJavaType.REF, true),  ALOAD_2(44, 0, StackTypes.EMPTY, StackType.REF.asList(), RawJavaType.REF, true),  ALOAD_3(45, 0, StackTypes.EMPTY, StackType.REF.asList(), RawJavaType.REF, true),  ANEWARRAY(189, 2, StackType.INT.asList(), StackType.REF.asList(), null, new OperationFactoryCPEntryW()),  ARETURN(176, 0, StackType.REF.asList(), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryReturn(), true),  ARRAYLENGTH(190, 0, StackType.REF.asList(), StackType.INT.asList(), RawJavaType.INT),  ASTORE(58, 1, StackType.RETURNADDRESSORREF.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  ASTORE_WIDE(-1, 3, StackType.RETURNADDRESSORREF.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  ASTORE_0(75, 0, StackType.RETURNADDRESSORREF.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  ASTORE_1(76, 0, StackType.RETURNADDRESSORREF.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  ASTORE_2(77, 0, StackType.RETURNADDRESSORREF.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  ASTORE_3(78, 0, StackType.RETURNADDRESSORREF.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  ATHROW(191, 0, StackType.REF.asList(), StackType.REF.asList(), RawJavaType.VOID, new OperationFactoryThrow()),  BALOAD(51, 0, new StackTypes(new StackType[] { StackType.REF, StackType.INT }), StackType.INT.asList(), null),  BASTORE(84, 0, new StackTypes(new StackType[] { StackType.REF, StackType.INT, StackType.INT }), StackTypes.EMPTY, RawJavaType.VOID),  BIPUSH(16, 1, StackTypes.EMPTY, StackType.INT.asList(), RawJavaType.VOID),  CALOAD(52, 0, new StackTypes(new StackType[] { StackType.REF, StackType.INT }), StackType.INT.asList(), RawJavaType.CHAR),  CASTORE(85, 0, new StackTypes(new StackType[] { StackType.REF, StackType.INT, StackType.INT }), StackTypes.EMPTY, RawJavaType.VOID),  CHECKCAST(192, 2, StackType.REF.asList(), StackType.REF.asList(), RawJavaType.REF, new OperationFactoryCPEntryW()),  D2F(144, 0, StackType.DOUBLE.asList(), StackType.FLOAT.asList(), RawJavaType.FLOAT),  D2I(142, 0, StackType.DOUBLE.asList(), StackType.INT.asList(), RawJavaType.INT),  D2L(143, 0, StackType.DOUBLE.asList(), StackType.LONG.asList(), RawJavaType.LONG),  DADD(99, 0, new StackTypes(new StackType[] { StackType.DOUBLE, StackType.DOUBLE }), StackType.DOUBLE.asList(), RawJavaType.DOUBLE),  DALOAD(49, 0, new StackTypes(new StackType[] { StackType.REF, StackType.INT }), StackType.DOUBLE.asList(), RawJavaType.DOUBLE),  DASTORE(82, 0, new StackTypes(new StackType[] { StackType.REF, StackType.INT, StackType.DOUBLE }), StackTypes.EMPTY, RawJavaType.VOID),  DCMPG(152, 0, new StackTypes(new StackType[] { StackType.DOUBLE, StackType.DOUBLE }), StackType.INT.asList(), RawJavaType.INT),  DCMPL(151, 0, new StackTypes(new StackType[] { StackType.DOUBLE, StackType.DOUBLE }), StackType.INT.asList(), RawJavaType.INT),  DCONST_0(14, 0, StackTypes.EMPTY, StackType.DOUBLE.asList(), RawJavaType.DOUBLE, true),  DCONST_1(15, 0, StackTypes.EMPTY, StackType.DOUBLE.asList(), RawJavaType.DOUBLE, true),  DDIV(111, 0, new StackTypes(new StackType[] { StackType.DOUBLE, StackType.DOUBLE }), StackType.DOUBLE.asList(), RawJavaType.DOUBLE),  DLOAD(24, 1, StackTypes.EMPTY, StackType.DOUBLE.asList(), RawJavaType.DOUBLE, true),  DLOAD_WIDE(-1, 3, StackTypes.EMPTY, StackType.DOUBLE.asList(), RawJavaType.DOUBLE, true),  DLOAD_0(38, 0, StackTypes.EMPTY, StackType.DOUBLE.asList(), RawJavaType.DOUBLE, true),  DLOAD_1(39, 0, StackTypes.EMPTY, StackType.DOUBLE.asList(), RawJavaType.DOUBLE, true),  DLOAD_2(40, 0, StackTypes.EMPTY, StackType.DOUBLE.asList(), RawJavaType.DOUBLE, true),  DLOAD_3(41, 0, StackTypes.EMPTY, StackType.DOUBLE.asList(), RawJavaType.DOUBLE, true),  DMUL(107, 0, new StackTypes(new StackType[] { StackType.DOUBLE, StackType.DOUBLE }), StackType.DOUBLE.asList(), RawJavaType.DOUBLE),  DNEG(119, 0, StackType.DOUBLE.asList(), StackType.DOUBLE.asList(), RawJavaType.DOUBLE),  DREM(115, 0, new StackTypes(new StackType[] { StackType.DOUBLE, StackType.DOUBLE }), StackType.DOUBLE.asList(), RawJavaType.DOUBLE),  DRETURN(175, 0, StackType.DOUBLE.asList(), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryReturn()),  DSTORE(57, 1, StackType.DOUBLE.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  DSTORE_WIDE(-1, 3, StackType.DOUBLE.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  DSTORE_0(71, 0, StackType.DOUBLE.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  DSTORE_1(72, 0, StackType.DOUBLE.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  DSTORE_2(73, 0, StackType.DOUBLE.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  DSTORE_3(74, 0, StackType.DOUBLE.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  DSUB(103, 0, new StackTypes(new StackType[] { StackType.DOUBLE, StackType.DOUBLE }), StackType.DOUBLE.asList(), RawJavaType.DOUBLE),  DUP(89, 0, null, null, null, new OperationFactoryDup()),  DUP_X1(90, 0, null, null, null, new OperationFactoryDupX1()),  DUP_X2(91, 0, null, null, null, new OperationFactoryDupX2()),  DUP2(92, 0, null, null, null, new OperationFactoryDup2()),  DUP2_X1(93, 0, null, null, null, new OperationFactoryDup2X1()),  DUP2_X2(94, 0, null, null, null, new OperationFactoryDup2X2()),  F2D(141, 0, StackType.FLOAT.asList(), StackType.DOUBLE.asList(), RawJavaType.DOUBLE),  F2I(139, 0, StackType.FLOAT.asList(), StackType.INT.asList(), RawJavaType.INT),  F2L(140, 0, StackType.FLOAT.asList(), StackType.LONG.asList(), RawJavaType.LONG),  FADD(98, 0, new StackTypes(new StackType[] { StackType.FLOAT, StackType.FLOAT }), StackType.FLOAT.asList(), RawJavaType.FLOAT),  FALOAD(48, 0, new StackTypes(new StackType[] { StackType.REF, StackType.INT }), StackType.FLOAT.asList(), RawJavaType.FLOAT),  FASTORE(81, 0, new StackTypes(new StackType[] { StackType.REF, StackType.INT, StackType.FLOAT }), StackTypes.EMPTY, RawJavaType.VOID),  FCMPG(150, 0, new StackTypes(new StackType[] { StackType.FLOAT, StackType.FLOAT }), StackType.INT.asList(), RawJavaType.INT),  FCMPL(149, 0, new StackTypes(new StackType[] { StackType.FLOAT, StackType.FLOAT }), StackType.INT.asList(), RawJavaType.INT),  FCONST_0(11, 0, StackTypes.EMPTY, StackType.FLOAT.asList(), RawJavaType.FLOAT, true),  FCONST_1(12, 0, StackTypes.EMPTY, StackType.FLOAT.asList(), RawJavaType.FLOAT, true),  FCONST_2(13, 0, StackTypes.EMPTY, StackType.FLOAT.asList(), RawJavaType.FLOAT, true),  FDIV(110, 0, new StackTypes(new StackType[] { StackType.FLOAT, StackType.FLOAT }), StackType.FLOAT.asList(), RawJavaType.FLOAT),  FLOAD(23, 1, StackTypes.EMPTY, StackType.FLOAT.asList(), RawJavaType.FLOAT, true),  FLOAD_WIDE(-1, 3, StackTypes.EMPTY, StackType.FLOAT.asList(), RawJavaType.FLOAT, true),  FLOAD_0(34, 0, StackTypes.EMPTY, StackType.FLOAT.asList(), RawJavaType.FLOAT, true),  FLOAD_1(35, 0, StackTypes.EMPTY, StackType.FLOAT.asList(), RawJavaType.FLOAT, true),  FLOAD_2(36, 0, StackTypes.EMPTY, StackType.FLOAT.asList(), RawJavaType.FLOAT, true),  FLOAD_3(37, 0, StackTypes.EMPTY, StackType.FLOAT.asList(), RawJavaType.FLOAT, true),  FMUL(106, 0, new StackTypes(new StackType[] { StackType.FLOAT, StackType.FLOAT }), StackType.FLOAT.asList(), RawJavaType.FLOAT),  FNEG(118, 0, StackType.FLOAT.asList(), StackType.FLOAT.asList(), RawJavaType.FLOAT),  FREM(114, 0, new StackTypes(new StackType[] { StackType.FLOAT, StackType.FLOAT }), StackType.FLOAT.asList(), RawJavaType.FLOAT),  FRETURN(174, 0, StackType.FLOAT.asList(), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryReturn(), true),  FSTORE(56, 1, StackType.FLOAT.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  FSTORE_WIDE(-1, 3, StackType.FLOAT.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  FSTORE_0(67, 0, StackType.FLOAT.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  FSTORE_1(68, 0, StackType.FLOAT.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  FSTORE_2(69, 0, StackType.FLOAT.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  FSTORE_3(70, 0, StackType.FLOAT.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  FSUB(102, 0, new StackTypes(new StackType[] { StackType.FLOAT, StackType.FLOAT }), StackType.FLOAT.asList(), RawJavaType.FLOAT),  GETFIELD(180, 2, null, null, null, new OperationFactoryGetField()),  GETSTATIC(178, 2, null, null, null, new OperationFactoryGetStatic()),  GOTO(167, 2, StackTypes.EMPTY, StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryGoto(), true),  GOTO_W(200, 4, StackTypes.EMPTY, StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryGotoW(), true),  I2B(145, 0, StackType.INT.asList(), StackType.INT.asList(), RawJavaType.BYTE),  I2C(146, 0, StackType.INT.asList(), StackType.INT.asList(), RawJavaType.CHAR),  I2D(135, 0, StackType.INT.asList(), StackType.DOUBLE.asList(), RawJavaType.DOUBLE),  I2F(134, 0, StackType.INT.asList(), StackType.FLOAT.asList(), RawJavaType.FLOAT),  I2L(133, 0, StackType.INT.asList(), StackType.LONG.asList(), RawJavaType.LONG, true),  I2S(147, 0, StackType.INT.asList(), StackType.INT.asList(), RawJavaType.SHORT),  IADD(96, 0, new StackTypes(new StackType[] { StackType.INT, StackType.INT }), StackType.INT.asList(), RawJavaType.INT),  IALOAD(46, 0, new StackTypes(new StackType[] { StackType.REF, StackType.INT }), StackType.INT.asList(), RawJavaType.INT),  IAND(126, 0, new StackTypes(new StackType[] { StackType.INT, StackType.INT }), StackType.INT.asList(), RawJavaType.INT),  IASTORE(79, 0, new StackTypes(new StackType[] { StackType.REF, StackType.INT, StackType.INT }), StackTypes.EMPTY, RawJavaType.VOID),  ICONST_M1(2, 0, StackTypes.EMPTY, StackType.INT.asList(), RawJavaType.INT, true),  ICONST_0(3, 0, StackTypes.EMPTY, StackType.INT.asList(), RawJavaType.INT, true),  ICONST_1(4, 0, StackTypes.EMPTY, StackType.INT.asList(), RawJavaType.INT, true),  ICONST_2(5, 0, StackTypes.EMPTY, StackType.INT.asList(), RawJavaType.INT, true),  ICONST_3(6, 0, StackTypes.EMPTY, StackType.INT.asList(), RawJavaType.INT, true),  ICONST_4(7, 0, StackTypes.EMPTY, StackType.INT.asList(), RawJavaType.INT, true),  ICONST_5(8, 0, StackTypes.EMPTY, StackType.INT.asList(), RawJavaType.INT, true),  IDIV(108, 0, new StackTypes(new StackType[] { StackType.INT, StackType.INT }), StackType.INT.asList(), RawJavaType.INT),  IF_ACMPEQ(165, 2, new StackTypes(new StackType[] { StackType.REF, StackType.REF }), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryConditionalJump()),  IF_ACMPNE(166, 2, new StackTypes(new StackType[] { StackType.REF, StackType.REF }), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryConditionalJump()),  IF_ICMPEQ(159, 2, new StackTypes(new StackType[] { StackType.INT, StackType.INT }), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryConditionalJump(), true),  IF_ICMPNE(160, 2, new StackTypes(new StackType[] { StackType.INT, StackType.INT }), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryConditionalJump(), true),  IF_ICMPLT(161, 2, new StackTypes(new StackType[] { StackType.INT, StackType.INT }), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryConditionalJump(), true),  IF_ICMPGE(162, 2, new StackTypes(new StackType[] { StackType.INT, StackType.INT }), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryConditionalJump(), true),  IF_ICMPGT(163, 2, new StackTypes(new StackType[] { StackType.INT, StackType.INT }), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryConditionalJump(), true),  IF_ICMPLE(164, 2, new StackTypes(new StackType[] { StackType.INT, StackType.INT }), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryConditionalJump(), true),  IFEQ(153, 2, StackType.INT.asList(), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryConditionalJump(), true),  IFNE(154, 2, StackType.INT.asList(), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryConditionalJump(), true),  IFLT(155, 2, StackType.INT.asList(), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryConditionalJump(), true),  IFGE(156, 2, StackType.INT.asList(), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryConditionalJump(), true),  IFGT(157, 2, StackType.INT.asList(), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryConditionalJump(), true),  IFLE(158, 2, StackType.INT.asList(), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryConditionalJump(), true),  IFNONNULL(199, 2, StackType.REF.asList(), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryConditionalJump(), true),  IFNULL(198, 2, StackType.REF.asList(), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryConditionalJump(), true),  IINC(132, 2, StackTypes.EMPTY, StackTypes.EMPTY, RawJavaType.VOID),  IINC_WIDE(-1, 5, StackTypes.EMPTY, StackTypes.EMPTY, RawJavaType.VOID),  ILOAD(21, 1, StackTypes.EMPTY, StackType.INT.asList(), RawJavaType.INT, true),  ILOAD_WIDE(-1, 3, StackTypes.EMPTY, StackType.INT.asList(), RawJavaType.INT, true),  ILOAD_0(26, 0, StackTypes.EMPTY, StackType.INT.asList(), RawJavaType.INT, true),  ILOAD_1(27, 0, StackTypes.EMPTY, StackType.INT.asList(), RawJavaType.INT, true),  ILOAD_2(28, 0, StackTypes.EMPTY, StackType.INT.asList(), RawJavaType.INT, true),  ILOAD_3(29, 0, StackTypes.EMPTY, StackType.INT.asList(), RawJavaType.INT, true),  IMUL(104, 0, new StackTypes(new StackType[] { StackType.INT, StackType.INT }), StackType.INT.asList(), RawJavaType.INT),  INEG(116, 0, StackType.INT.asList(), StackType.INT.asList(), RawJavaType.INT),  INSTANCEOF(193, 2, StackType.REF.asList(), StackType.INT.asList(), RawJavaType.BOOLEAN, new OperationFactoryCPEntryW()),  INVOKEDYNAMIC(186, 4, null, null, null, new OperationFactoryInvokeDynamic()),  INVOKEINTERFACE(185, 4, null, null, null, new OperationFactoryInvokeInterface()),  INVOKESPECIAL(183, 2, null, null, null, new OperationFactoryInvoke(true)),  INVOKESTATIC(184, 2, null, null, null, new OperationFactoryInvoke(false)),  INVOKEVIRTUAL(182, 2, null, null, null, new OperationFactoryInvoke(true)),  IOR(128, 0, new StackTypes(new StackType[] { StackType.INT, StackType.INT }), StackType.INT.asList(), RawJavaType.INT),  IREM(112, 0, new StackTypes(new StackType[] { StackType.INT, StackType.INT }), StackType.INT.asList(), RawJavaType.INT),  IRETURN(172, 0, StackType.INT.asList(), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryReturn(), true),  ISHL(120, 0, new StackTypes(new StackType[] { StackType.INT, StackType.INT }), StackType.INT.asList(), RawJavaType.INT),  ISHR(122, 0, new StackTypes(new StackType[] { StackType.INT, StackType.INT }), StackType.INT.asList(), RawJavaType.INT),  ISTORE(54, 1, StackType.INT.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  ISTORE_WIDE(-1, 3, StackType.INT.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  ISTORE_0(59, 0, StackType.INT.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  ISTORE_1(60, 0, StackType.INT.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  ISTORE_2(61, 0, StackType.INT.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  ISTORE_3(62, 0, StackType.INT.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  ISUB(100, 0, new StackTypes(new StackType[] { StackType.INT, StackType.INT }), StackType.INT.asList(), RawJavaType.INT),  IUSHR(124, 0, new StackTypes(new StackType[] { StackType.INT, StackType.INT }), StackType.INT.asList(), RawJavaType.INT),  IXOR(130, 0, new StackTypes(new StackType[] { StackType.INT, StackType.INT }), StackType.INT.asList(), RawJavaType.INT),  JSR(168, 2, StackTypes.EMPTY, StackType.RETURNADDRESS.asList(), RawJavaType.RETURNADDRESS, new OperationFactoryGoto()),  JSR_W(201, 4, StackTypes.EMPTY, StackType.RETURNADDRESS.asList(), RawJavaType.RETURNADDRESS, new OperationFactoryGotoW()),  L2D(138, 0, StackType.LONG.asList(), StackType.DOUBLE.asList(), RawJavaType.DOUBLE, true),  L2F(137, 0, StackType.LONG.asList(), StackType.FLOAT.asList(), RawJavaType.FLOAT, true),  L2I(136, 0, StackType.LONG.asList(), StackType.INT.asList(), RawJavaType.INT, true),  LADD(97, 0, new StackTypes(new StackType[] { StackType.LONG, StackType.LONG }), StackType.LONG.asList(), RawJavaType.LONG, true),  LALOAD(47, 0, new StackTypes(new StackType[] { StackType.REF, StackType.INT }), StackType.LONG.asList(), RawJavaType.LONG),  LAND(127, 0, new StackTypes(new StackType[] { StackType.LONG, StackType.LONG }), StackType.LONG.asList(), RawJavaType.LONG),  LASTORE(80, 0, new StackTypes(new StackType[] { StackType.REF, StackType.INT, StackType.LONG }), StackTypes.EMPTY, RawJavaType.VOID),  LCMP(148, 0, new StackTypes(new StackType[] { StackType.LONG, StackType.LONG }), StackType.INT.asList(), RawJavaType.INT, true),  LCONST_0(9, 0, StackTypes.EMPTY, StackType.LONG.asList(), RawJavaType.LONG, true),  LCONST_1(10, 0, StackTypes.EMPTY, StackType.LONG.asList(), RawJavaType.LONG, true),  LDC(18, 1, null, null, null, new OperationFactoryLDC(), true),  LDC_W(19, 2, null, null, null, new OperationFactoryLDCW(), true),  LDC2_W(20, 2, null, null, null, new OperationFactoryLDC2W(), true),  LDIV(109, 0, new StackTypes(new StackType[] { StackType.LONG, StackType.LONG }), StackType.LONG.asList(), RawJavaType.LONG),  LLOAD(22, 1, StackTypes.EMPTY, StackType.LONG.asList(), RawJavaType.LONG, true),  LLOAD_WIDE(-1, 3, StackTypes.EMPTY, StackType.LONG.asList(), RawJavaType.LONG, true),  LLOAD_0(30, 0, StackTypes.EMPTY, StackType.LONG.asList(), RawJavaType.LONG, true),  LLOAD_1(31, 0, StackTypes.EMPTY, StackType.LONG.asList(), RawJavaType.LONG, true),  LLOAD_2(32, 0, StackTypes.EMPTY, StackType.LONG.asList(), RawJavaType.LONG, true),  LLOAD_3(33, 0, StackTypes.EMPTY, StackType.LONG.asList(), RawJavaType.LONG, true),  LMUL(105, 0, new StackTypes(new StackType[] { StackType.LONG, StackType.LONG }), StackType.LONG.asList(), RawJavaType.LONG),  LNEG(117, 0, StackType.LONG.asList(), StackType.LONG.asList(), RawJavaType.LONG),  LOOKUPSWITCH(171, -1, StackType.INT.asList(), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryLookupSwitch()),  LOR(129, 0, new StackTypes(new StackType[] { StackType.LONG, StackType.LONG }), StackType.LONG.asList(), RawJavaType.LONG),  LREM(113, 0, new StackTypes(new StackType[] { StackType.LONG, StackType.LONG }), StackType.LONG.asList(), RawJavaType.LONG),  LRETURN(173, 0, StackType.LONG.asList(), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryReturn(), true),  LSHL(121, 0, new StackTypes(new StackType[] { StackType.LONG, StackType.INT }), StackType.LONG.asList(), RawJavaType.LONG),  LSHR(123, 0, new StackTypes(new StackType[] { StackType.LONG, StackType.INT }), StackType.LONG.asList(), RawJavaType.LONG),  LSTORE(55, 1, StackType.LONG.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  LSTORE_WIDE(-1, 3, StackType.LONG.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  LSTORE_0(63, 0, StackType.LONG.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  LSTORE_1(64, 0, StackType.LONG.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  LSTORE_2(65, 0, StackType.LONG.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  LSTORE_3(66, 0, StackType.LONG.asList(), StackTypes.EMPTY, RawJavaType.VOID, true),  LSUB(101, 0, new StackTypes(new StackType[] { StackType.LONG, StackType.LONG }), StackType.LONG.asList(), RawJavaType.LONG),  LUSHR(125, 0, new StackTypes(new StackType[] { StackType.LONG, StackType.INT }), StackType.LONG.asList(), RawJavaType.LONG),  LXOR(131, 0, new StackTypes(new StackType[] { StackType.LONG, StackType.LONG }), StackType.LONG.asList(), RawJavaType.LONG),  MONITORENTER(194, 0, StackType.REF.asList(), StackTypes.EMPTY, RawJavaType.VOID),  MONITOREXIT(195, 0, StackType.REF.asList(), StackTypes.EMPTY, RawJavaType.VOID),  MULTIANEWARRAY(197, 3, null, null, RawJavaType.REF, new OperationFactoryMultiANewArray()),  NEW(187, 2, StackTypes.EMPTY, StackType.REF.asList(), null, new OperationFactoryNew()),  NEWARRAY(188, 1, StackType.INT.asList(), StackType.REF.asList(), null),  NOP(0, 0, StackTypes.EMPTY, StackTypes.EMPTY, RawJavaType.VOID),  POP(87, 0, null, null, null, new OperationFactoryPop()),  POP2(88, 0, null, null, null, new OperationFactoryPop2()),  PUTFIELD(181, 2, null, null, RawJavaType.VOID, new OperationFactoryPutField()),  PUTSTATIC(179, 2, null, null, RawJavaType.VOID, new OperationFactoryPutStatic()),  RET(169, 1, StackTypes.EMPTY, StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryReturn()),  RET_WIDE(-1, 3, StackTypes.EMPTY, StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryReturn()),  RETURN(177, 0, StackTypes.EMPTY, StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryReturn(), true),  SALOAD(53, 0, new StackTypes(new StackType[] { StackType.REF, StackType.INT }), StackType.INT.asList(), RawJavaType.SHORT),  SASTORE(86, 0, new StackTypes(new StackType[] { StackType.REF, StackType.INT, StackType.INT }), StackTypes.EMPTY, RawJavaType.VOID),  SIPUSH(17, 2, StackTypes.EMPTY, StackType.INT.asList(), RawJavaType.SHORT),  SWAP(95, 0, null, null, null, new OperationFactorySwap()),  TABLESWITCH(170, -1, StackType.INT.asList(), StackTypes.EMPTY, RawJavaType.VOID, new OperationFactoryTableSwitch()),  WIDE(196, -1, null, null, null, new OperationFactoryWide()),  FAKE_TRY(-1, 0, StackTypes.EMPTY, StackTypes.EMPTY, RawJavaType.VOID),  FAKE_CATCH(-1, 0, StackTypes.EMPTY, StackType.REF.asList(), RawJavaType.REF, new OperationFactoryFakeCatch());
/*  20:    */   
/*  21:    */   private final int opcode;
/*  22:    */   private final int bytes;
/*  23:    */   private final StackTypes stackPopped;
/*  24:    */   private final StackTypes stackPushed;
/*  25:    */   private final RawJavaType rawJavaType;
/*  26:    */   private final String name;
/*  27:    */   private final OperationFactory handler;
/*  28:    */   private final boolean noThrow;
/*  29:    */   private static final Map<Integer, JVMInstr> opcodeLookup;
/*  30:    */   
/*  31:    */   static
/*  32:    */   {
/*  33:250 */     opcodeLookup = new HashMap();
/*  34:253 */     for (JVMInstr i : values()) {
/*  35:254 */       opcodeLookup.put(Integer.valueOf(i.getOpcode()), i);
/*  36:    */     }
/*  37:    */   }
/*  38:    */   
/*  39:    */   private JVMInstr(int opcode, int bytes, StackTypes popped, StackTypes pushed, RawJavaType rawJavaType)
/*  40:    */   {
/*  41:259 */     this(opcode, bytes, popped, pushed, rawJavaType, OperationFactoryDefault.Handler.INSTANCE.getHandler(), false);
/*  42:    */   }
/*  43:    */   
/*  44:    */   private JVMInstr(int opcode, int bytes, StackTypes popped, StackTypes pushed, RawJavaType rawJavaType, boolean noThrow)
/*  45:    */   {
/*  46:263 */     this(opcode, bytes, popped, pushed, rawJavaType, OperationFactoryDefault.Handler.INSTANCE.getHandler(), noThrow);
/*  47:    */   }
/*  48:    */   
/*  49:    */   private JVMInstr(int opcode, int bytes, StackTypes popped, StackTypes pushed, RawJavaType rawJavaType, OperationFactory handler)
/*  50:    */   {
/*  51:267 */     this(opcode, bytes, popped, pushed, rawJavaType, handler, false);
/*  52:    */   }
/*  53:    */   
/*  54:    */   private JVMInstr(int opcode, int bytes, StackTypes popped, StackTypes pushed, RawJavaType rawJavaType, OperationFactory handler, boolean noThrow)
/*  55:    */   {
/*  56:271 */     this.opcode = opcode;
/*  57:272 */     this.bytes = bytes;
/*  58:273 */     this.stackPopped = popped;
/*  59:274 */     this.stackPushed = pushed;
/*  60:275 */     this.name = super.toString().toLowerCase();
/*  61:276 */     this.handler = handler;
/*  62:277 */     this.rawJavaType = rawJavaType;
/*  63:278 */     this.noThrow = noThrow;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public int getOpcode()
/*  67:    */   {
/*  68:282 */     return this.opcode;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public String getName()
/*  72:    */   {
/*  73:286 */     return this.name;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public static JVMInstr find(int opcode)
/*  77:    */   {
/*  78:290 */     if (opcode < 0) {
/*  79:290 */       opcode += 256;
/*  80:    */     }
/*  81:291 */     Integer iOpcode = Integer.valueOf(opcode);
/*  82:292 */     if (!opcodeLookup.containsKey(iOpcode)) {
/*  83:293 */       throw new ConfusedCFRException("Unknown opcode [" + opcode + "]");
/*  84:    */     }
/*  85:295 */     return (JVMInstr)opcodeLookup.get(Integer.valueOf(opcode));
/*  86:    */   }
/*  87:    */   
/*  88:    */   protected int getRawLength()
/*  89:    */   {
/*  90:299 */     return this.bytes;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public StackTypes getRawStackPushed()
/*  94:    */   {
/*  95:306 */     return this.stackPushed;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public StackTypes getRawStackPopped()
/*  99:    */   {
/* 100:310 */     return this.stackPopped;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public StackDelta getStackDelta(byte[] data, ConstantPoolEntry[] constantPoolEntries, StackSim stackSim, Method method)
/* 104:    */   {
/* 105:314 */     return this.handler.getStackDelta(this, data, constantPoolEntries, stackSim, method);
/* 106:    */   }
/* 107:    */   
/* 108:    */   public Op01WithProcessedDataAndByteJumps createOperation(ByteData bd, ConstantPool cp, int offset)
/* 109:    */   {
/* 110:318 */     Op01WithProcessedDataAndByteJumps res = this.handler.createOperation(this, bd, cp, offset);
/* 111:319 */     return res;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public RawJavaType getRawJavaType()
/* 115:    */   {
/* 116:323 */     return this.rawJavaType;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public boolean isNoThrow()
/* 120:    */   {
/* 121:327 */     return this.noThrow;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public static boolean isAStore(JVMInstr instr)
/* 125:    */   {
/* 126:331 */     switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$opcode$JVMInstr[instr.ordinal()])
/* 127:    */     {
/* 128:    */     case 1: 
/* 129:    */     case 2: 
/* 130:    */     case 3: 
/* 131:    */     case 4: 
/* 132:    */     case 5: 
/* 133:    */     case 6: 
/* 134:338 */       return true;
/* 135:    */     }
/* 136:340 */     return false;
/* 137:    */   }
/* 138:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.JVMInstr
 * JD-Core Version:    0.7.0.1
 */