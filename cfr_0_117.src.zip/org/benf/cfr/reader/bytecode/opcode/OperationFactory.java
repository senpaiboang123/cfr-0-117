package org.benf.cfr.reader.bytecode.opcode;

import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
import org.benf.cfr.reader.bytecode.analysis.stack.StackDelta;
import org.benf.cfr.reader.bytecode.analysis.stack.StackSim;
import org.benf.cfr.reader.entities.Method;
import org.benf.cfr.reader.entities.constantpool.ConstantPool;
import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
import org.benf.cfr.reader.util.bytestream.ByteData;

public abstract interface OperationFactory
{
  public abstract StackDelta getStackDelta(JVMInstr paramJVMInstr, byte[] paramArrayOfByte, ConstantPoolEntry[] paramArrayOfConstantPoolEntry, StackSim paramStackSim, Method paramMethod);
  
  public abstract Op01WithProcessedDataAndByteJumps createOperation(JVMInstr paramJVMInstr, ByteData paramByteData, ConstantPool paramConstantPool, int paramInt);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactory
 * JD-Core Version:    0.7.0.1
 */