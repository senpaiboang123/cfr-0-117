/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDelta;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDeltaImpl;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackEntry;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackSim;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackTypes;
/* 10:   */ import org.benf.cfr.reader.entities.Method;
/* 11:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/* 12:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/* 13:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/* 14:   */ 
/* 15:   */ public class OperationFactoryPop2
/* 16:   */   extends OperationFactoryDefault
/* 17:   */ {
/* 18:   */   public StackDelta getStackDelta(JVMInstr instr, byte[] data, ConstantPoolEntry[] cpEntries, StackSim stackSim, Method method)
/* 19:   */   {
/* 20:19 */     StackType topStackEntry = stackSim.getEntry(0).getType();
/* 21:20 */     if (topStackEntry.getComputationCategory() == 2) {
/* 22:21 */       return new StackDeltaImpl(topStackEntry.asList(), StackTypes.EMPTY);
/* 23:   */     }
/* 24:23 */     StackType nextStackEntry = stackSim.getEntry(1).getType();
/* 25:24 */     StackTypes stackTypesPopped = new StackTypes(new StackType[] { topStackEntry, nextStackEntry });
/* 26:25 */     return new StackDeltaImpl(stackTypesPopped, StackTypes.EMPTY);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public Op01WithProcessedDataAndByteJumps createOperation(JVMInstr instr, ByteData bd, ConstantPool cp, int offset)
/* 30:   */   {
/* 31:31 */     byte[] args = null;
/* 32:32 */     int[] targetOffsets = null;
/* 33:33 */     return new Op01WithProcessedDataAndByteJumps(instr, args, targetOffsets, offset);
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryPop2
 * JD-Core Version:    0.7.0.1
 */