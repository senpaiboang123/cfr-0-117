/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDelta;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDeltaImpl;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackSim;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/*  7:   */ import org.benf.cfr.reader.entities.Method;
/*  8:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/*  9:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryFieldRef;
/* 10:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/* 11:   */ 
/* 12:   */ public class OperationFactoryGetField
/* 13:   */   extends OperationFactoryCPEntryW
/* 14:   */ {
/* 15:   */   public StackDelta getStackDelta(JVMInstr instr, byte[] data, ConstantPoolEntry[] cpEntries, StackSim stackSim, Method method)
/* 16:   */   {
/* 17:18 */     ConstantPoolEntryFieldRef fieldRef = (ConstantPoolEntryFieldRef)cpEntries[0];
/* 18:19 */     if (fieldRef == null) {
/* 19:19 */       throw new ConfusedCFRException("Expecting fieldRef");
/* 20:   */     }
/* 21:20 */     StackType stackType = fieldRef.getStackType();
/* 22:21 */     return new StackDeltaImpl(StackType.REF.asList(), stackType.asList());
/* 23:   */   }
/* 24:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryGetField
 * JD-Core Version:    0.7.0.1
 */