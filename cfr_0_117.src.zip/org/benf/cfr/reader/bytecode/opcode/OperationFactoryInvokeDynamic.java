/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDelta;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackSim;
/*  6:   */ import org.benf.cfr.reader.entities.Method;
/*  7:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  8:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/*  9:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryInvokeDynamic;
/* 10:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryNameAndType;
/* 11:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/* 12:   */ 
/* 13:   */ public class OperationFactoryInvokeDynamic
/* 14:   */   extends OperationFactoryDefault
/* 15:   */ {
/* 16:   */   private static final int LENGTH_OF_FIELD_INDEX = 2;
/* 17:   */   
/* 18:   */   public Op01WithProcessedDataAndByteJumps createOperation(JVMInstr instr, ByteData bd, ConstantPool cp, int offset)
/* 19:   */   {
/* 20:24 */     byte[] args = bd.getBytesAt(2, 1L);
/* 21:25 */     int[] targetOffsets = null;
/* 22:26 */     ConstantPoolEntry[] cpEntries = { cp.getEntry(bd.getS2At(1L)) };
/* 23:   */     
/* 24:28 */     return new Op01WithProcessedDataAndByteJumps(instr, args, targetOffsets, offset, cpEntries);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public StackDelta getStackDelta(JVMInstr instr, byte[] data, ConstantPoolEntry[] cpEntries, StackSim stackSim, Method method)
/* 28:   */   {
/* 29:34 */     ConstantPoolEntryInvokeDynamic invokeDynamic = (ConstantPoolEntryInvokeDynamic)cpEntries[0];
/* 30:   */     
/* 31:36 */     ConstantPoolEntryNameAndType nameAndType = invokeDynamic.getNameAndTypeEntry();
/* 32:37 */     return nameAndType.getStackDelta(false);
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryInvokeDynamic
 * JD-Core Version:    0.7.0.1
 */