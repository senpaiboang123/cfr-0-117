/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  4:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  5:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/*  6:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  7:   */ 
/*  8:   */ public class OperationFactoryNew
/*  9:   */   extends OperationFactoryDefault
/* 10:   */ {
/* 11:   */   private static final int LENGTH_OF_CLASS_INDEX = 2;
/* 12:   */   
/* 13:   */   public Op01WithProcessedDataAndByteJumps createOperation(JVMInstr instr, ByteData bd, ConstantPool cp, int offset)
/* 14:   */   {
/* 15:13 */     byte[] args = bd.getBytesAt(2, 1L);
/* 16:14 */     int[] targetOffsets = null;
/* 17:15 */     ConstantPoolEntry[] cpEntries = { cp.getEntry(bd.getS2At(1L)) };
/* 18:   */     
/* 19:   */ 
/* 20:18 */     return new Op01WithProcessedDataAndByteJumps(instr, args, targetOffsets, offset, cpEntries);
/* 21:   */   }
/* 22:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryNew
 * JD-Core Version:    0.7.0.1
 */