/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Map;
/*  5:   */ import java.util.Map.Entry;
/*  6:   */ import java.util.TreeMap;
/*  7:   */ import org.benf.cfr.reader.util.ListFactory;
/*  8:   */ import org.benf.cfr.reader.util.MapFactory;
/*  9:   */ import org.benf.cfr.reader.util.bytestream.BaseByteData;
/* 10:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/* 11:   */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/* 12:   */ 
/* 13:   */ public class DecodedLookupSwitch
/* 14:   */   implements DecodedSwitch
/* 15:   */ {
/* 16:   */   private static final int OFFSET_OF_DEFAULT = 0;
/* 17:   */   private static final int OFFSET_OF_NUMPAIRS = 4;
/* 18:   */   private static final int OFFSET_OF_PAIRS = 8;
/* 19:   */   private final int defaultTarget;
/* 20:   */   private final List<DecodedSwitchEntry> jumpTargets;
/* 21:   */   
/* 22:   */   public DecodedLookupSwitch(byte[] data, int offsetOfOriginalInstruction)
/* 23:   */   {
/* 24:25 */     int curoffset = offsetOfOriginalInstruction + 1;
/* 25:26 */     int overflow = curoffset % 4;
/* 26:27 */     int offset = overflow > 0 ? 4 - overflow : 0;
/* 27:   */     
/* 28:29 */     ByteData bd = new BaseByteData(data);
/* 29:30 */     int defaultvalue = bd.getS4At(offset + 0);
/* 30:31 */     int numpairs = bd.getS4At(offset + 4);
/* 31:32 */     int[] targets = new int[numpairs];
/* 32:33 */     this.defaultTarget = defaultvalue;
/* 33:   */     
/* 34:35 */     Map<Integer, List<Integer>> uniqueTargets = MapFactory.newLazyMap(new TreeMap(), new UnaryFunction()
/* 35:   */     {
/* 36:   */       public List<Integer> invoke(Integer arg)
/* 37:   */       {
/* 38:40 */         return ListFactory.newList();
/* 39:   */       }
/* 40:42 */     });
/* 41:43 */     ((List)uniqueTargets.get(Integer.valueOf(this.defaultTarget))).add(null);
/* 42:44 */     for (int x = 0; x < numpairs; x++)
/* 43:   */     {
/* 44:45 */       int value = bd.getS4At(offset + 8 + x * 8);
/* 45:46 */       int target = bd.getS4At(offset + 8 + x * 8 + 4);
/* 46:47 */       if (target != this.defaultTarget) {
/* 47:48 */         ((List)uniqueTargets.get(Integer.valueOf(target))).add(Integer.valueOf(value));
/* 48:   */       }
/* 49:   */     }
/* 50:51 */     this.jumpTargets = ListFactory.newList();
/* 51:52 */     for (Map.Entry<Integer, List<Integer>> entry : uniqueTargets.entrySet()) {
/* 52:53 */       this.jumpTargets.add(new DecodedSwitchEntry((List)entry.getValue(), ((Integer)entry.getKey()).intValue()));
/* 53:   */     }
/* 54:   */   }
/* 55:   */   
/* 56:   */   public List<DecodedSwitchEntry> getJumpTargets()
/* 57:   */   {
/* 58:59 */     return this.jumpTargets;
/* 59:   */   }
/* 60:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.DecodedLookupSwitch
 * JD-Core Version:    0.7.0.1
 */