/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDelta;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDeltaImpl;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackEntry;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackSim;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/* 10:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackTypes;
/* 11:   */ import org.benf.cfr.reader.entities.Method;
/* 12:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/* 13:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/* 14:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/* 15:   */ import org.benf.cfr.reader.util.ListFactory;
/* 16:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/* 17:   */ 
/* 18:   */ public class OperationFactoryDefault
/* 19:   */   implements OperationFactory
/* 20:   */ {
/* 21:   */   public static enum Handler
/* 22:   */   {
/* 23:21 */     INSTANCE(new OperationFactoryDefault());
/* 24:   */     
/* 25:   */     private final OperationFactoryDefault h;
/* 26:   */     
/* 27:   */     private Handler(OperationFactoryDefault h)
/* 28:   */     {
/* 29:26 */       this.h = h;
/* 30:   */     }
/* 31:   */     
/* 32:   */     public OperationFactory getHandler()
/* 33:   */     {
/* 34:30 */       return this.h;
/* 35:   */     }
/* 36:   */   }
/* 37:   */   
/* 38:   */   public StackDelta getStackDelta(JVMInstr instr, byte[] data, ConstantPoolEntry[] cpEntries, StackSim stackSim, Method method)
/* 39:   */   {
/* 40:37 */     return new StackDeltaImpl(instr.getRawStackPopped(), instr.getRawStackPushed());
/* 41:   */   }
/* 42:   */   
/* 43:   */   public Op01WithProcessedDataAndByteJumps createOperation(JVMInstr instr, ByteData bd, ConstantPool cp, int offset)
/* 44:   */   {
/* 45:42 */     byte[] args = instr.getRawLength() == 0 ? null : bd.getBytesAt(instr.getRawLength(), 1L);
/* 46:43 */     int[] targetOffsets = null;
/* 47:44 */     return new Op01WithProcessedDataAndByteJumps(instr, args, targetOffsets, offset);
/* 48:   */   }
/* 49:   */   
/* 50:   */   protected static StackTypes getStackTypes(StackSim stackSim, Integer... indexes)
/* 51:   */   {
/* 52:51 */     if (indexes.length == 1) {
/* 53:52 */       return stackSim.getEntry(indexes[0].intValue()).getType().asList();
/* 54:   */     }
/* 55:54 */     List<StackType> stackTypes = ListFactory.newList();
/* 56:55 */     for (Integer index : indexes) {
/* 57:56 */       stackTypes.add(stackSim.getEntry(index.intValue()).getType());
/* 58:   */     }
/* 59:58 */     return new StackTypes(stackTypes);
/* 60:   */   }
/* 61:   */   
/* 62:   */   protected static int getCat(StackSim stackSim, int index)
/* 63:   */   {
/* 64:63 */     return stackSim.getEntry(index).getType().getComputationCategory();
/* 65:   */   }
/* 66:   */   
/* 67:   */   protected static void checkCat(StackSim stackSim, int index, int category)
/* 68:   */   {
/* 69:67 */     if (getCat(stackSim, index) != category) {
/* 70:68 */       throw new ConfusedCFRException("Expected category " + category + " at index " + index);
/* 71:   */     }
/* 72:   */   }
/* 73:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryDefault
 * JD-Core Version:    0.7.0.1
 */