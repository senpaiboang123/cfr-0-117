/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDelta;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDeltaImpl;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackSim;
/*  7:   */ import org.benf.cfr.reader.entities.Method;
/*  8:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  9:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/* 10:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/* 11:   */ 
/* 12:   */ public class OperationFactoryDupX2
/* 13:   */   extends OperationFactoryDupBase
/* 14:   */ {
/* 15:   */   public StackDelta getStackDelta(JVMInstr instr, byte[] data, ConstantPoolEntry[] cpEntries, StackSim stackSim, Method method)
/* 16:   */   {
/* 17:17 */     if (getCat(stackSim, 1) == 2)
/* 18:   */     {
/* 19:18 */       checkCat(stackSim, 0, 1);
/* 20:19 */       return new StackDeltaImpl(getStackTypes(stackSim, new Integer[] { Integer.valueOf(0), Integer.valueOf(1) }), getStackTypes(stackSim, new Integer[] { Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(0) }));
/* 21:   */     }
/* 22:24 */     checkCat(stackSim, 0, 1);
/* 23:25 */     checkCat(stackSim, 2, 1);
/* 24:26 */     return new StackDeltaImpl(getStackTypes(stackSim, new Integer[] { Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2) }), getStackTypes(stackSim, new Integer[] { Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(0) }));
/* 25:   */   }
/* 26:   */   
/* 27:   */   public Op01WithProcessedDataAndByteJumps createOperation(JVMInstr instr, ByteData bd, ConstantPool cp, int offset)
/* 28:   */   {
/* 29:35 */     byte[] args = null;
/* 30:36 */     int[] targetOffsets = null;
/* 31:37 */     return new Op01WithProcessedDataAndByteJumps(instr, args, targetOffsets, offset);
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryDupX2
 * JD-Core Version:    0.7.0.1
 */