/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDelta;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackSim;
/*  6:   */ import org.benf.cfr.reader.entities.Method;
/*  7:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  8:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/*  9:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodRef;
/* 10:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryNameAndType;
/* 11:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/* 12:   */ 
/* 13:   */ public class OperationFactoryInvokeInterface
/* 14:   */   extends OperationFactoryDefault
/* 15:   */ {
/* 16:   */   private static final int LENGTH_OF_METHOD_INDEX = 2;
/* 17:   */   private static final int OFFSET_OF_METHOD_INDEX = 1;
/* 18:   */   private static final int LENGTH_OF_DATA = 4;
/* 19:   */   
/* 20:   */   public Op01WithProcessedDataAndByteJumps createOperation(JVMInstr instr, ByteData bd, ConstantPool cp, int offset)
/* 21:   */   {
/* 22:22 */     byte[] args = bd.getBytesAt(4, 1L);
/* 23:23 */     int[] targetOffsets = null;
/* 24:24 */     ConstantPoolEntry[] cpEntries = { cp.getEntry(bd.getS2At(1L)) };
/* 25:   */     
/* 26:   */ 
/* 27:27 */     return new Op01WithProcessedDataAndByteJumps(instr, args, targetOffsets, offset, cpEntries);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public StackDelta getStackDelta(JVMInstr instr, byte[] data, ConstantPoolEntry[] cpEntries, StackSim stackSim, Method method)
/* 31:   */   {
/* 32:33 */     ConstantPoolEntryMethodRef methodRef = (ConstantPoolEntryMethodRef)cpEntries[0];
/* 33:   */     
/* 34:35 */     return methodRef.getNameAndTypeEntry().getStackDelta(true);
/* 35:   */   }
/* 36:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryInvokeInterface
 * JD-Core Version:    0.7.0.1
 */