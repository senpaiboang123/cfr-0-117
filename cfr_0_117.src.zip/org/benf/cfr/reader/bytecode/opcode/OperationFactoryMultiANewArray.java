/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDelta;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDeltaImpl;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackSim;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackTypes;
/* 10:   */ import org.benf.cfr.reader.entities.Method;
/* 11:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/* 12:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/* 13:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/* 14:   */ import org.benf.cfr.reader.util.ListFactory;
/* 15:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/* 16:   */ 
/* 17:   */ public class OperationFactoryMultiANewArray
/* 18:   */   extends OperationFactoryDefault
/* 19:   */ {
/* 20:   */   private static final int LENGTH_OF_DATA = 3;
/* 21:   */   public static final int OFFSET_OF_DIMS = 2;
/* 22:   */   
/* 23:   */   public Op01WithProcessedDataAndByteJumps createOperation(JVMInstr instr, ByteData bd, ConstantPool cp, int offset)
/* 24:   */   {
/* 25:24 */     byte[] args = bd.getBytesAt(3, 1L);
/* 26:25 */     int[] targetOffsets = null;
/* 27:26 */     ConstantPoolEntry[] cpEntries = { cp.getEntry(bd.getS2At(1L)) };
/* 28:   */     
/* 29:28 */     return new Op01WithProcessedDataAndByteJumps(instr, args, targetOffsets, offset, cpEntries);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public StackDelta getStackDelta(JVMInstr instr, byte[] data, ConstantPoolEntry[] cpEntries, StackSim stackSim, Method method)
/* 33:   */   {
/* 34:34 */     short numDims = (short)data[2];
/* 35:35 */     if (numDims < 0) {
/* 36:36 */       throw new ConfusedCFRException("NYI : Unsupported num of dims, should be using a short not a byte.");
/* 37:   */     }
/* 38:39 */     List<StackType> stackTypeList = ListFactory.newList();
/* 39:40 */     for (int x = 0; x < numDims; x++) {
/* 40:41 */       stackTypeList.add(StackType.INT);
/* 41:   */     }
/* 42:43 */     return new StackDeltaImpl(new StackTypes(stackTypeList), StackType.REF.asList());
/* 43:   */   }
/* 44:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryMultiANewArray
 * JD-Core Version:    0.7.0.1
 */