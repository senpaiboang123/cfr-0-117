/*  1:   */ package org.benf.cfr.reader.bytecode.opcode;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDelta;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDeltaImpl;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackSim;
/*  7:   */ import org.benf.cfr.reader.entities.Method;
/*  8:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  9:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/* 10:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/* 11:   */ 
/* 12:   */ public class OperationFactoryDupX1
/* 13:   */   extends OperationFactoryDupBase
/* 14:   */ {
/* 15:   */   public StackDelta getStackDelta(JVMInstr instr, byte[] data, ConstantPoolEntry[] cpEntries, StackSim stackSim, Method method)
/* 16:   */   {
/* 17:17 */     checkCat(stackSim, 0, 1);
/* 18:18 */     checkCat(stackSim, 1, 1);
/* 19:19 */     return new StackDeltaImpl(getStackTypes(stackSim, new Integer[] { Integer.valueOf(0), Integer.valueOf(1) }), getStackTypes(stackSim, new Integer[] { Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(0) }));
/* 20:   */   }
/* 21:   */   
/* 22:   */   public Op01WithProcessedDataAndByteJumps createOperation(JVMInstr instr, ByteData bd, ConstantPool cp, int offset)
/* 23:   */   {
/* 24:27 */     byte[] args = null;
/* 25:28 */     int[] targetOffsets = null;
/* 26:29 */     return new Op01WithProcessedDataAndByteJumps(instr, args, targetOffsets, offset);
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.opcode.OperationFactoryDupX1
 * JD-Core Version:    0.7.0.1
 */