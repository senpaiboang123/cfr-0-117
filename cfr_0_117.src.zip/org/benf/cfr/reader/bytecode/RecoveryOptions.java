/*  1:   */ package org.benf.cfr.reader.bytecode;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.state.DCCommonState;
/*  5:   */ import org.benf.cfr.reader.util.DecompilerComment;
/*  6:   */ import org.benf.cfr.reader.util.ListFactory;
/*  7:   */ import org.benf.cfr.reader.util.getopt.MutableOptions;
/*  8:   */ import org.benf.cfr.reader.util.getopt.Options;
/*  9:   */ 
/* 10:   */ public class RecoveryOptions
/* 11:   */ {
/* 12:   */   private final List<RecoveryOption<?>> recoveryOptions;
/* 13:   */   
/* 14:   */   public RecoveryOptions(RecoveryOption<?>... recoveryOptions)
/* 15:   */   {
/* 16:16 */     this.recoveryOptions = ListFactory.newList(recoveryOptions);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public RecoveryOptions(RecoveryOptions prev, RecoveryOption<?>... recoveryOptions)
/* 20:   */   {
/* 21:20 */     List<RecoveryOption<?>> recoveryOptionList = ListFactory.newList(recoveryOptions);
/* 22:21 */     this.recoveryOptions = ListFactory.newList();
/* 23:22 */     this.recoveryOptions.addAll(prev.recoveryOptions);
/* 24:23 */     this.recoveryOptions.addAll(recoveryOptionList);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public static class Applied
/* 28:   */   {
/* 29:   */     public Options options;
/* 30:   */     public List<DecompilerComment> comments;
/* 31:   */     public boolean valid;
/* 32:   */     
/* 33:   */     public Applied(Options options, List<DecompilerComment> comments, boolean valid)
/* 34:   */     {
/* 35:32 */       this.options = options;
/* 36:33 */       this.comments = comments;
/* 37:34 */       this.valid = valid;
/* 38:   */     }
/* 39:   */   }
/* 40:   */   
/* 41:   */   public Applied apply(DCCommonState commonState, Options originalOptions, BytecodeMeta bytecodeMeta)
/* 42:   */   {
/* 43:39 */     MutableOptions mutableOptions = new MutableOptions(originalOptions);
/* 44:40 */     List<DecompilerComment> appliedComments = ListFactory.newList();
/* 45:41 */     boolean hadEffect = false;
/* 46:42 */     for (RecoveryOption<?> option : this.recoveryOptions) {
/* 47:43 */       if (option.apply(mutableOptions, appliedComments, bytecodeMeta)) {
/* 48:43 */         hadEffect = true;
/* 49:   */       }
/* 50:   */     }
/* 51:45 */     return new Applied(mutableOptions, appliedComments, hadEffect);
/* 52:   */   }
/* 53:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.RecoveryOptions
 * JD-Core Version:    0.7.0.1
 */