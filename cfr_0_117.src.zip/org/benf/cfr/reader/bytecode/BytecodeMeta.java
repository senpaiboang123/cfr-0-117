/*  1:   */ package org.benf.cfr.reader.bytecode;
/*  2:   */ 
/*  3:   */ import java.util.EnumSet;
/*  4:   */ import java.util.List;
/*  5:   */ import java.util.Map;
/*  6:   */ import java.util.Set;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/* 10:   */ import org.benf.cfr.reader.entities.attributes.AttributeCode;
/* 11:   */ import org.benf.cfr.reader.util.MapFactory;
/* 12:   */ import org.benf.cfr.reader.util.SetFactory;
/* 13:   */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/* 14:   */ 
/* 15:   */ public class BytecodeMeta
/* 16:   */ {
/* 17:   */   public static enum CodeInfoFlag
/* 18:   */   {
/* 19:19 */     USES_MONITORS,  USES_EXCEPTIONS,  USES_INVOKEDYNAMIC,  LIVENESS_CLASH,  ITERATED_TYPE_HINTS;
/* 20:   */     
/* 21:   */     private CodeInfoFlag() {}
/* 22:   */   }
/* 23:   */   
/* 24:26 */   private final EnumSet<CodeInfoFlag> flags = EnumSet.noneOf(CodeInfoFlag.class);
/* 25:28 */   private final Set<Integer> livenessClashes = SetFactory.newSet();
/* 26:29 */   private final Map<Integer, JavaTypeInstance> iteratedTypeHints = MapFactory.newMap();
/* 27:   */   
/* 28:   */   public BytecodeMeta(List<Op01WithProcessedDataAndByteJumps> op1s, AttributeCode code)
/* 29:   */   {
/* 30:32 */     int flagCount = CodeInfoFlag.values().length;
/* 31:33 */     if (!code.getExceptionTableEntries().isEmpty()) {
/* 32:33 */       this.flags.add(CodeInfoFlag.USES_EXCEPTIONS);
/* 33:   */     }
/* 34:34 */     for (Op01WithProcessedDataAndByteJumps op : op1s)
/* 35:   */     {
/* 36:35 */       switch (1.$SwitchMap$org$benf$cfr$reader$bytecode$opcode$JVMInstr[op.getJVMInstr().ordinal()])
/* 37:   */       {
/* 38:   */       case 1: 
/* 39:   */       case 2: 
/* 40:38 */         this.flags.add(CodeInfoFlag.USES_MONITORS);
/* 41:39 */         break;
/* 42:   */       case 3: 
/* 43:41 */         this.flags.add(CodeInfoFlag.USES_INVOKEDYNAMIC);
/* 44:   */       }
/* 45:45 */       if (this.flags.size() == flagCount) {
/* 46:45 */         return;
/* 47:   */       }
/* 48:   */     }
/* 49:   */   }
/* 50:   */   
/* 51:   */   public boolean has(CodeInfoFlag flag)
/* 52:   */   {
/* 53:50 */     return this.flags.contains(flag);
/* 54:   */   }
/* 55:   */   
/* 56:   */   public void informLivenessClashes(Set<Integer> slots)
/* 57:   */   {
/* 58:54 */     this.flags.add(CodeInfoFlag.LIVENESS_CLASH);
/* 59:55 */     this.livenessClashes.addAll(slots);
/* 60:   */   }
/* 61:   */   
/* 62:   */   public void takeIteratedTypeHint(InferredJavaType inferredJavaType, JavaTypeInstance itertype)
/* 63:   */   {
/* 64:59 */     int bytecodeIdx = inferredJavaType.getTaggedBytecodeLocation();
/* 65:60 */     if (bytecodeIdx < 0) {
/* 66:60 */       return;
/* 67:   */     }
/* 68:61 */     Integer key = Integer.valueOf(bytecodeIdx);
/* 69:62 */     if (this.iteratedTypeHints.containsKey(key))
/* 70:   */     {
/* 71:63 */       JavaTypeInstance already = (JavaTypeInstance)this.iteratedTypeHints.get(key);
/* 72:64 */       if (already == null) {
/* 73:64 */         return;
/* 74:   */       }
/* 75:65 */       if (!itertype.equals(already)) {
/* 76:66 */         this.iteratedTypeHints.put(key, null);
/* 77:   */       }
/* 78:   */     }
/* 79:   */     else
/* 80:   */     {
/* 81:69 */       this.flags.add(CodeInfoFlag.ITERATED_TYPE_HINTS);
/* 82:70 */       this.iteratedTypeHints.put(key, itertype);
/* 83:   */     }
/* 84:   */   }
/* 85:   */   
/* 86:   */   public Map<Integer, JavaTypeInstance> getIteratedTypeHints()
/* 87:   */   {
/* 88:75 */     return this.iteratedTypeHints;
/* 89:   */   }
/* 90:   */   
/* 91:   */   public Set<Integer> getLivenessClashes()
/* 92:   */   {
/* 93:79 */     return this.livenessClashes;
/* 94:   */   }
/* 95:   */   
/* 96:   */   private static class FlagTest
/* 97:   */     implements UnaryFunction<BytecodeMeta, Boolean>
/* 98:   */   {
/* 99:   */     private final BytecodeMeta.CodeInfoFlag[] flags;
/* :0:   */     
/* :1:   */     private FlagTest(BytecodeMeta.CodeInfoFlag[] flags)
/* :2:   */     {
/* :3:86 */       this.flags = flags;
/* :4:   */     }
/* :5:   */     
/* :6:   */     public Boolean invoke(BytecodeMeta arg)
/* :7:   */     {
/* :8:91 */       for (BytecodeMeta.CodeInfoFlag flag : this.flags) {
/* :9:92 */         if (arg.has(flag)) {
/* ;0:92 */           return Boolean.valueOf(true);
/* ;1:   */         }
/* ;2:   */       }
/* ;3:94 */       return Boolean.valueOf(false);
/* ;4:   */     }
/* ;5:   */   }
/* ;6:   */   
/* ;7:   */   public static UnaryFunction<BytecodeMeta, Boolean> hasAnyFlag(CodeInfoFlag... flag)
/* ;8:   */   {
/* ;9:99 */     return new FlagTest(flag, null);
/* <0:   */   }
/* <1:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.bytecode.BytecodeMeta
 * JD-Core Version:    0.7.0.1
 */