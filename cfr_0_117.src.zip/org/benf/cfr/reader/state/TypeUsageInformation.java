package org.benf.cfr.reader.state;

import java.util.Set;
import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;

public abstract interface TypeUsageInformation
{
  public abstract Set<JavaRefTypeInstance> getShortenedClassTypes();
  
  public abstract Set<JavaRefTypeInstance> getUsedClassTypes();
  
  public abstract Set<JavaRefTypeInstance> getUsedInnerClassTypes();
  
  public abstract String getName(JavaTypeInstance paramJavaTypeInstance);
  
  public abstract String generateInnerClassShortName(JavaRefTypeInstance paramJavaRefTypeInstance);
  
  public abstract String generateOverriddenName(JavaRefTypeInstance paramJavaRefTypeInstance);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.state.TypeUsageInformation
 * JD-Core Version:    0.7.0.1
 */