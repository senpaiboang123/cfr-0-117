/*   1:    */ package org.benf.cfr.reader.state;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.FileInputStream;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.InputStream;
/*   7:    */ import java.io.PrintStream;
/*   8:    */ import java.util.Arrays;
/*   9:    */ import java.util.Collection;
/*  10:    */ import java.util.Collections;
/*  11:    */ import java.util.Enumeration;
/*  12:    */ import java.util.List;
/*  13:    */ import java.util.Map;
/*  14:    */ import java.util.Map.Entry;
/*  15:    */ import java.util.zip.ZipEntry;
/*  16:    */ import java.util.zip.ZipFile;
/*  17:    */ import org.benf.cfr.reader.api.ClassFileSource;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  19:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  20:    */ import org.benf.cfr.reader.util.ListFactory;
/*  21:    */ import org.benf.cfr.reader.util.MapFactory;
/*  22:    */ import org.benf.cfr.reader.util.StringUtils;
/*  23:    */ import org.benf.cfr.reader.util.getopt.Options;
/*  24:    */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*  25:    */ 
/*  26:    */ public class ClassFileSourceImpl
/*  27:    */   implements ClassFileSource
/*  28:    */ {
/*  29:    */   private Map<String, String> classToPathMap;
/*  30:    */   private final Options options;
/*  31: 27 */   private boolean unexpectedDirectory = false;
/*  32: 28 */   private String pathPrefix = "";
/*  33: 29 */   private String classRemovePrefix = "";
/*  34:    */   
/*  35:    */   public ClassFileSourceImpl(Options options)
/*  36:    */   {
/*  37: 33 */     this.options = options;
/*  38:    */   }
/*  39:    */   
/*  40:    */   private byte[] getBytesFromFile(InputStream is, long length)
/*  41:    */     throws IOException
/*  42:    */   {
/*  43: 41 */     if (length > 2147483647L) {}
/*  44: 46 */     byte[] bytes = new byte[(int)length];
/*  45:    */     
/*  46:    */ 
/*  47: 49 */     int offset = 0;
/*  48: 50 */     int numRead = 0;
/*  49: 51 */     while ((offset < bytes.length) && ((numRead = is.read(bytes, offset, bytes.length - offset)) >= 0)) {
/*  50: 53 */       offset += numRead;
/*  51:    */     }
/*  52: 57 */     if (offset < bytes.length) {
/*  53: 58 */       throw new IOException("Could not completely read file");
/*  54:    */     }
/*  55: 62 */     is.close();
/*  56: 63 */     return bytes;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public Pair<byte[], String> getClassFileContent(String path)
/*  60:    */     throws IOException
/*  61:    */   {
/*  62: 70 */     Map<String, String> classPathFiles = getClassPathClasses();
/*  63: 71 */     String jarName = (String)classPathFiles.get(path);
/*  64: 72 */     ZipFile zipFile = null;
/*  65:    */     try
/*  66:    */     {
/*  67: 75 */       InputStream is = null;
/*  68: 76 */       long length = 0L;
/*  69:    */       
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74: 82 */       String usePath = path;
/*  75: 83 */       if (this.unexpectedDirectory)
/*  76:    */       {
/*  77: 84 */         if (usePath.startsWith(this.classRemovePrefix)) {
/*  78: 85 */           usePath = usePath.substring(this.classRemovePrefix.length());
/*  79:    */         }
/*  80: 87 */         usePath = this.pathPrefix + usePath;
/*  81:    */       }
/*  82: 89 */       File file = new File(usePath);
/*  83: 90 */       if (file.exists())
/*  84:    */       {
/*  85: 91 */         is = new FileInputStream(file);
/*  86: 92 */         length = file.length();
/*  87:    */       }
/*  88: 93 */       else if (jarName != null)
/*  89:    */       {
/*  90: 94 */         zipFile = new ZipFile(new File(jarName), 1);
/*  91: 95 */         ZipEntry zipEntry = zipFile.getEntry(path);
/*  92: 96 */         length = zipEntry.getSize();
/*  93: 97 */         is = zipFile.getInputStream(zipEntry);
/*  94:    */       }
/*  95:    */       else
/*  96:    */       {
/*  97: 99 */         throw new IOException("No such file");
/*  98:    */       }
/*  99:102 */       byte[] content = getBytesFromFile(is, length);
/* 100:103 */       return Pair.make(content, usePath);
/* 101:    */     }
/* 102:    */     finally
/* 103:    */     {
/* 104:105 */       if (zipFile != null) {
/* 105:105 */         zipFile.close();
/* 106:    */       }
/* 107:    */     }
/* 108:    */   }
/* 109:    */   
/* 110:    */   public Collection<String> addJar(String jarPath)
/* 111:    */   {
/* 112:111 */     getClassPathClasses();
/* 113:    */     
/* 114:113 */     File file = new File(jarPath);
/* 115:114 */     if (!file.exists()) {
/* 116:115 */       throw new ConfusedCFRException("No such jar file " + jarPath);
/* 117:    */     }
/* 118:117 */     Map<String, String> thisJar = MapFactory.newLinkedMap();
/* 119:118 */     if (!processClassPathFile(file, jarPath, thisJar, false)) {
/* 120:119 */       throw new ConfusedCFRException("Failed to load jar " + jarPath);
/* 121:    */     }
/* 122:122 */     List<String> output = ListFactory.newList();
/* 123:123 */     for (Map.Entry<String, String> entry : thisJar.entrySet())
/* 124:    */     {
/* 125:124 */       String classPath = (String)entry.getKey();
/* 126:125 */       if (classPath.toLowerCase().endsWith(".class"))
/* 127:    */       {
/* 128:126 */         this.classToPathMap.put(classPath, entry.getValue());
/* 129:127 */         output.add(classPath);
/* 130:    */       }
/* 131:    */     }
/* 132:131 */     return output;
/* 133:    */   }
/* 134:    */   
/* 135:    */   private Map<String, String> getClassPathClasses()
/* 136:    */   {
/* 137:136 */     if (this.classToPathMap == null)
/* 138:    */     {
/* 139:137 */       boolean dump = ((Boolean)this.options.getOption(OptionsImpl.DUMP_CLASS_PATH)).booleanValue();
/* 140:    */       
/* 141:139 */       this.classToPathMap = MapFactory.newMap();
/* 142:140 */       String classPath = System.getProperty("java.class.path") + ":" + System.getProperty("sun.boot.class.path");
/* 143:141 */       if (dump) {
/* 144:142 */         System.out.println("/* ClassPath Diagnostic - searching :" + classPath);
/* 145:    */       }
/* 146:144 */       String extraClassPath = (String)this.options.getOption(OptionsImpl.EXTRA_CLASS_PATH);
/* 147:145 */       if (null != extraClassPath) {
/* 148:146 */         classPath = classPath + File.pathSeparatorChar + extraClassPath;
/* 149:    */       }
/* 150:148 */       String[] classPaths = classPath.split("" + File.pathSeparatorChar);
/* 151:149 */       for (String path : classPaths)
/* 152:    */       {
/* 153:150 */         if (dump) {
/* 154:151 */           System.out.println(" " + path);
/* 155:    */         }
/* 156:153 */         File f = new File(path);
/* 157:154 */         if (f.exists())
/* 158:    */         {
/* 159:155 */           if (f.isDirectory())
/* 160:    */           {
/* 161:156 */             if (dump) {
/* 162:157 */               System.out.println(" (Directory)");
/* 163:    */             }
/* 164:160 */             for (File file : f.listFiles()) {
/* 165:161 */               processClassPathFile(file, file.getAbsolutePath(), this.classToPathMap, dump);
/* 166:    */             }
/* 167:    */           }
/* 168:    */           else
/* 169:    */           {
/* 170:164 */             processClassPathFile(f, path, this.classToPathMap, dump);
/* 171:    */           }
/* 172:    */         }
/* 173:167 */         else if (dump) {
/* 174:168 */           System.out.println(" (Can't access)");
/* 175:    */         }
/* 176:    */       }
/* 177:172 */       if (dump) {
/* 178:173 */         System.out.println(" */");
/* 179:    */       }
/* 180:    */     }
/* 181:176 */     return this.classToPathMap;
/* 182:    */   }
/* 183:    */   
/* 184:    */   private boolean processClassPathFile(File file, String path, Map<String, String> classToPathMap, boolean dump)
/* 185:    */   {
/* 186:    */     try
/* 187:    */     {
/* 188:181 */       ZipFile zipFile = new ZipFile(file, 1);
/* 189:    */       try
/* 190:    */       {
/* 191:183 */         Enumeration<? extends ZipEntry> enumeration = zipFile.entries();
/* 192:184 */         while (enumeration.hasMoreElements())
/* 193:    */         {
/* 194:185 */           ZipEntry entry = (ZipEntry)enumeration.nextElement();
/* 195:186 */           if (!entry.isDirectory())
/* 196:    */           {
/* 197:187 */             String name = entry.getName();
/* 198:188 */             if (name.endsWith(".class"))
/* 199:    */             {
/* 200:189 */               if (dump) {
/* 201:190 */                 System.out.println("  " + name);
/* 202:    */               }
/* 203:192 */               classToPathMap.put(name, path);
/* 204:    */             }
/* 205:194 */             else if (dump)
/* 206:    */             {
/* 207:195 */               System.out.println("  [ignoring] " + name);
/* 208:    */             }
/* 209:    */           }
/* 210:    */         }
/* 211:    */       }
/* 212:    */       finally
/* 213:    */       {
/* 214:201 */         zipFile.close();
/* 215:    */       }
/* 216:    */     }
/* 217:    */     catch (IOException e)
/* 218:    */     {
/* 219:204 */       return false;
/* 220:    */     }
/* 221:206 */     return true;
/* 222:    */   }
/* 223:    */   
/* 224:    */   public void informAnalysisRelativePathDetail(String usePath, String specPath)
/* 225:    */   {
/* 226:211 */     new Configurator(null).configureWith(usePath, specPath);
/* 227:    */   }
/* 228:    */   
/* 229:    */   private class Configurator
/* 230:    */   {
/* 231:    */     private Configurator() {}
/* 232:    */     
/* 233:    */     private void reverse(String[] in)
/* 234:    */     {
/* 235:223 */       List<String> l = Arrays.asList(in);
/* 236:224 */       Collections.reverse(l);
/* 237:225 */       l.toArray(in);
/* 238:    */     }
/* 239:    */     
/* 240:    */     private void getCommonRoot(String filePath, String classPath)
/* 241:    */     {
/* 242:229 */       String npath = filePath.replace('\\', '/');
/* 243:230 */       String[] fileParts = npath.split("/");
/* 244:231 */       String[] classParts = classPath.split("/");
/* 245:232 */       reverse(fileParts);
/* 246:233 */       reverse(classParts);
/* 247:234 */       int min = Math.min(fileParts.length, classParts.length);
/* 248:235 */       int diffpt = 0;
/* 249:236 */       while ((diffpt < min) && (fileParts[diffpt].equals(classParts[diffpt]))) {
/* 250:237 */         diffpt++;
/* 251:    */       }
/* 252:239 */       fileParts = (String[])Arrays.copyOfRange(fileParts, diffpt, fileParts.length);
/* 253:240 */       classParts = (String[])Arrays.copyOfRange(classParts, diffpt, classParts.length);
/* 254:241 */       reverse(fileParts);
/* 255:242 */       reverse(classParts);
/* 256:243 */       ClassFileSourceImpl.this.pathPrefix = (StringUtils.join(fileParts, "/") + "/");
/* 257:244 */       ClassFileSourceImpl.this.classRemovePrefix = (StringUtils.join(classParts, "/") + "/");
/* 258:    */     }
/* 259:    */     
/* 260:    */     public void configureWith(String usePath, String specPath)
/* 261:    */     {
/* 262:248 */       String path = usePath;
/* 263:249 */       String actualPath = specPath;
/* 264:250 */       if (!actualPath.equals(path))
/* 265:    */       {
/* 266:251 */         ClassFileSourceImpl.this.unexpectedDirectory = true;
/* 267:252 */         if (path.endsWith(actualPath)) {
/* 268:253 */           ClassFileSourceImpl.this.pathPrefix = path.substring(0, path.length() - actualPath.length());
/* 269:    */         } else {
/* 270:258 */           getCommonRoot(path, actualPath);
/* 271:    */         }
/* 272:    */       }
/* 273:    */     }
/* 274:    */   }
/* 275:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.state.ClassFileSourceImpl
 * JD-Core Version:    0.7.0.1
 */