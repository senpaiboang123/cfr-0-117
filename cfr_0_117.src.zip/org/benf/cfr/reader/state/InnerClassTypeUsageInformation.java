/*  1:   */ package org.benf.cfr.reader.state;
/*  2:   */ 
/*  3:   */ import java.util.Map;
/*  4:   */ import java.util.Set;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.types.InnerClassInfo;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  8:   */ import org.benf.cfr.reader.util.MapFactory;
/*  9:   */ import org.benf.cfr.reader.util.SetFactory;
/* 10:   */ 
/* 11:   */ public class InnerClassTypeUsageInformation
/* 12:   */   implements TypeUsageInformation
/* 13:   */ {
/* 14:   */   private final TypeUsageInformation delegate;
/* 15:   */   private final JavaRefTypeInstance analysisInnerClass;
/* 16:17 */   private final Map<JavaRefTypeInstance, String> localTypeNames = MapFactory.newMap();
/* 17:18 */   private final Set<String> usedLocalTypeNames = SetFactory.newSet();
/* 18:19 */   private final Set<JavaRefTypeInstance> usedInnerClassTypes = SetFactory.newSet();
/* 19:   */   
/* 20:   */   public InnerClassTypeUsageInformation(TypeUsageInformation delegate, JavaRefTypeInstance analysisInnerClass)
/* 21:   */   {
/* 22:22 */     this.delegate = delegate;
/* 23:23 */     this.analysisInnerClass = analysisInnerClass;
/* 24:24 */     initializeFrom();
/* 25:   */   }
/* 26:   */   
/* 27:   */   private void initializeFrom()
/* 28:   */   {
/* 29:28 */     Set<JavaRefTypeInstance> outerInners = this.delegate.getUsedInnerClassTypes();
/* 30:29 */     for (JavaRefTypeInstance outerInner : outerInners) {
/* 31:30 */       if (outerInner.getInnerClassHereInfo().isTransitiveInnerClassOf(this.analysisInnerClass))
/* 32:   */       {
/* 33:31 */         this.usedInnerClassTypes.add(outerInner);
/* 34:32 */         String name = TypeUsageUtils.generateInnerClassShortName(outerInner, this.analysisInnerClass, false);
/* 35:33 */         if (!this.usedLocalTypeNames.contains(name))
/* 36:   */         {
/* 37:34 */           this.localTypeNames.put(outerInner, name);
/* 38:35 */           this.usedLocalTypeNames.add(name);
/* 39:   */         }
/* 40:   */       }
/* 41:   */     }
/* 42:   */   }
/* 43:   */   
/* 44:   */   public Set<JavaRefTypeInstance> getUsedClassTypes()
/* 45:   */   {
/* 46:43 */     return this.delegate.getUsedClassTypes();
/* 47:   */   }
/* 48:   */   
/* 49:   */   public Set<JavaRefTypeInstance> getUsedInnerClassTypes()
/* 50:   */   {
/* 51:48 */     return this.usedInnerClassTypes;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public String getName(JavaTypeInstance type)
/* 55:   */   {
/* 56:53 */     String local = (String)this.localTypeNames.get(type);
/* 57:54 */     if (local != null) {
/* 58:54 */       return local;
/* 59:   */     }
/* 60:56 */     String res = this.delegate.getName(type);
/* 61:57 */     if (this.usedLocalTypeNames.contains(res)) {
/* 62:58 */       return type.getRawName();
/* 63:   */     }
/* 64:60 */     return res;
/* 65:   */   }
/* 66:   */   
/* 67:   */   public String generateInnerClassShortName(JavaRefTypeInstance clazz)
/* 68:   */   {
/* 69:66 */     return this.delegate.generateInnerClassShortName(clazz);
/* 70:   */   }
/* 71:   */   
/* 72:   */   public String generateOverriddenName(JavaRefTypeInstance clazz)
/* 73:   */   {
/* 74:71 */     return this.delegate.generateOverriddenName(clazz);
/* 75:   */   }
/* 76:   */   
/* 77:   */   public Set<JavaRefTypeInstance> getShortenedClassTypes()
/* 78:   */   {
/* 79:76 */     return this.delegate.getShortenedClassTypes();
/* 80:   */   }
/* 81:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.state.InnerClassTypeUsageInformation
 * JD-Core Version:    0.7.0.1
 */