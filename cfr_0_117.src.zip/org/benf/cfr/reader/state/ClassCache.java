/*  1:   */ package org.benf.cfr.reader.state;
/*  2:   */ 
/*  3:   */ import java.util.Collection;
/*  4:   */ import java.util.Map;
/*  5:   */ import java.util.Set;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.types.ClassNameUtils;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  9:   */ import org.benf.cfr.reader.bytecode.analysis.types.TypeConstants;
/* 10:   */ import org.benf.cfr.reader.util.MapFactory;
/* 11:   */ import org.benf.cfr.reader.util.SetFactory;
/* 12:   */ 
/* 13:   */ public class ClassCache
/* 14:   */ {
/* 15:19 */   private final Map<String, JavaRefTypeInstance> refClassTypeCache = MapFactory.newMap();
/* 16:22 */   private final Set<String> simpleClassNamesSeen = SetFactory.newSet();
/* 17:   */   private final DCCommonState dcCommonState;
/* 18:   */   
/* 19:   */   public ClassCache(DCCommonState dcCommonState)
/* 20:   */   {
/* 21:27 */     this.dcCommonState = dcCommonState;
/* 22:   */     
/* 23:29 */     add(TypeConstants.ASSERTION_ERROR.getRawName(), TypeConstants.ASSERTION_ERROR);
/* 24:30 */     add(TypeConstants.OBJECT.getRawName(), TypeConstants.OBJECT);
/* 25:31 */     add(TypeConstants.STRING.getRawName(), TypeConstants.STRING);
/* 26:32 */     add(TypeConstants.ENUM.getRawName(), TypeConstants.ENUM);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public JavaRefTypeInstance getRefClassFor(String rawClassName)
/* 30:   */   {
/* 31:36 */     String name = ClassNameUtils.convertFromPath(rawClassName);
/* 32:37 */     JavaRefTypeInstance typeInstance = (JavaRefTypeInstance)this.refClassTypeCache.get(name);
/* 33:38 */     if (typeInstance == null)
/* 34:   */     {
/* 35:39 */       typeInstance = JavaRefTypeInstance.create(name, this.dcCommonState);
/* 36:40 */       add(name, typeInstance);
/* 37:   */     }
/* 38:42 */     return typeInstance;
/* 39:   */   }
/* 40:   */   
/* 41:   */   private void add(String name, JavaRefTypeInstance typeInstance)
/* 42:   */   {
/* 43:46 */     this.refClassTypeCache.put(name, typeInstance);
/* 44:47 */     this.simpleClassNamesSeen.add(typeInstance.getRawShortName());
/* 45:   */   }
/* 46:   */   
/* 47:   */   public boolean isClassName(String name)
/* 48:   */   {
/* 49:51 */     return this.simpleClassNamesSeen.contains(name);
/* 50:   */   }
/* 51:   */   
/* 52:   */   public Pair<JavaRefTypeInstance, JavaRefTypeInstance> getRefClassForInnerOuterPair(String rawInnerName, String rawOuterName)
/* 53:   */   {
/* 54:55 */     String innerName = ClassNameUtils.convertFromPath(rawInnerName);
/* 55:56 */     String outerName = ClassNameUtils.convertFromPath(rawOuterName);
/* 56:57 */     JavaRefTypeInstance inner = (JavaRefTypeInstance)this.refClassTypeCache.get(innerName);
/* 57:58 */     JavaRefTypeInstance outer = (JavaRefTypeInstance)this.refClassTypeCache.get(outerName);
/* 58:59 */     if ((inner != null) && (outer != null)) {
/* 59:59 */       return Pair.make(inner, outer);
/* 60:   */     }
/* 61:60 */     Pair<JavaRefTypeInstance, JavaRefTypeInstance> pair = JavaRefTypeInstance.createKnownInnerOuter(innerName, outerName, outer, this.dcCommonState);
/* 62:61 */     if (inner == null)
/* 63:   */     {
/* 64:62 */       add(innerName, (JavaRefTypeInstance)pair.getFirst());
/* 65:63 */       inner = (JavaRefTypeInstance)pair.getFirst();
/* 66:   */     }
/* 67:65 */     if (outer == null)
/* 68:   */     {
/* 69:66 */       add(outerName, (JavaRefTypeInstance)pair.getSecond());
/* 70:67 */       outer = (JavaRefTypeInstance)pair.getSecond();
/* 71:   */     }
/* 72:69 */     return Pair.make(inner, outer);
/* 73:   */   }
/* 74:   */   
/* 75:   */   public Collection<JavaRefTypeInstance> getLoadedTypes()
/* 76:   */   {
/* 77:74 */     return this.refClassTypeCache.values();
/* 78:   */   }
/* 79:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.state.ClassCache
 * JD-Core Version:    0.7.0.1
 */