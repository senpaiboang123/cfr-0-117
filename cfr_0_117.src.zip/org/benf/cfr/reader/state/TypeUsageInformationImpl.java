/*   1:    */ package org.benf.cfr.reader.state;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.Comparator;
/*   6:    */ import java.util.LinkedList;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.Map.Entry;
/*  10:    */ import java.util.Set;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.types.InnerClassInfo;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  15:    */ import org.benf.cfr.reader.util.Functional;
/*  16:    */ import org.benf.cfr.reader.util.ListFactory;
/*  17:    */ import org.benf.cfr.reader.util.MapFactory;
/*  18:    */ import org.benf.cfr.reader.util.Predicate;
/*  19:    */ import org.benf.cfr.reader.util.SetFactory;
/*  20:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  21:    */ 
/*  22:    */ public class TypeUsageInformationImpl
/*  23:    */   implements TypeUsageInformation
/*  24:    */ {
/*  25:    */   private final JavaRefTypeInstance analysisType;
/*  26: 15 */   private final Set<JavaRefTypeInstance> usedRefTypes = SetFactory.newOrderedSet();
/*  27: 16 */   private final Set<JavaRefTypeInstance> shortenedRefTypes = SetFactory.newOrderedSet();
/*  28: 17 */   private final Set<JavaRefTypeInstance> usedLocalInnerTypes = SetFactory.newOrderedSet();
/*  29: 18 */   private final Map<JavaRefTypeInstance, String> displayName = MapFactory.newMap();
/*  30: 19 */   private final Map<String, LinkedList<JavaRefTypeInstance>> shortNames = MapFactory.newLazyMap(new UnaryFunction()
/*  31:    */   {
/*  32:    */     public LinkedList<JavaRefTypeInstance> invoke(String arg)
/*  33:    */     {
/*  34: 22 */       return ListFactory.newLinkedList();
/*  35:    */     }
/*  36: 19 */   });
/*  37:    */   
/*  38:    */   public TypeUsageInformationImpl(JavaRefTypeInstance analysisType, Set<JavaRefTypeInstance> usedRefTypes)
/*  39:    */   {
/*  40: 27 */     this.analysisType = analysisType;
/*  41: 28 */     initialiseFrom(usedRefTypes);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public String generateInnerClassShortName(JavaRefTypeInstance clazz)
/*  45:    */   {
/*  46: 33 */     return TypeUsageUtils.generateInnerClassShortName(clazz, this.analysisType, false);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public String generateOverriddenName(JavaRefTypeInstance clazz)
/*  50:    */   {
/*  51: 38 */     if (clazz.getInnerClassHereInfo().isInnerClass()) {
/*  52: 39 */       return TypeUsageUtils.generateInnerClassShortName(clazz, this.analysisType, true);
/*  53:    */     }
/*  54: 41 */     return clazz.getRawName();
/*  55:    */   }
/*  56:    */   
/*  57:    */   private void initialiseFrom(Set<JavaRefTypeInstance> usedRefTypes)
/*  58:    */   {
/*  59: 45 */     List<JavaRefTypeInstance> usedRefs = ListFactory.newList(usedRefTypes);
/*  60: 46 */     Collections.sort(usedRefs, new Comparator()
/*  61:    */     {
/*  62:    */       public int compare(JavaRefTypeInstance a, JavaRefTypeInstance b)
/*  63:    */       {
/*  64: 49 */         return a.getRawName().compareTo(b.getRawName());
/*  65:    */       }
/*  66: 51 */     });
/*  67: 52 */     this.usedRefTypes.addAll(usedRefs);
/*  68:    */     
/*  69: 54 */     Pair<List<JavaRefTypeInstance>, List<JavaRefTypeInstance>> types = Functional.partition(usedRefs, new Predicate()
/*  70:    */     {
/*  71:    */       public boolean test(JavaRefTypeInstance in)
/*  72:    */       {
/*  73: 57 */         return in.getInnerClassHereInfo().isTransitiveInnerClassOf(TypeUsageInformationImpl.this.analysisType);
/*  74:    */       }
/*  75: 59 */     });
/*  76: 60 */     this.usedLocalInnerTypes.addAll((Collection)types.getFirst());
/*  77: 61 */     addDisplayNames(usedRefTypes);
/*  78:    */   }
/*  79:    */   
/*  80:    */   private void addDisplayNames(Collection<JavaRefTypeInstance> types)
/*  81:    */   {
/*  82: 65 */     if (!this.shortNames.isEmpty()) {
/*  83: 65 */       throw new IllegalStateException();
/*  84:    */     }
/*  85: 66 */     for (JavaRefTypeInstance type : types)
/*  86:    */     {
/*  87: 67 */       InnerClassInfo innerClassInfo = type.getInnerClassHereInfo();
/*  88: 68 */       if (innerClassInfo.isInnerClass())
/*  89:    */       {
/*  90: 69 */         String name = generateInnerClassShortName(type);
/*  91: 70 */         ((LinkedList)this.shortNames.get(name)).addFirst(type);
/*  92:    */       }
/*  93:    */       else
/*  94:    */       {
/*  95: 72 */         String name = type.getRawShortName();
/*  96: 73 */         ((LinkedList)this.shortNames.get(name)).addLast(type);
/*  97:    */       }
/*  98:    */     }
/*  99: 79 */     for (Map.Entry<String, LinkedList<JavaRefTypeInstance>> nameList : this.shortNames.entrySet())
/* 100:    */     {
/* 101: 80 */       LinkedList<JavaRefTypeInstance> typeList = (LinkedList)nameList.getValue();
/* 102: 81 */       String name = (String)nameList.getKey();
/* 103: 82 */       if (typeList.size() == 1)
/* 104:    */       {
/* 105: 83 */         this.displayName.put(typeList.get(0), name);
/* 106: 84 */         this.shortenedRefTypes.add(typeList.get(0));
/* 107:    */       }
/* 108:    */       else
/* 109:    */       {
/* 110:136 */         List<1PriClass> priClasses = Functional.map(typeList, new UnaryFunction()
/* 111:    */         {
/* 112:    */           public TypeUsageInformationImpl.1PriClass invoke(JavaRefTypeInstance arg)
/* 113:    */           {
/* 114:139 */             return new TypeUsageInformationImpl.1PriClass(TypeUsageInformationImpl.this, arg);
/* 115:    */           }
/* 116:141 */         });
/* 117:142 */         Collections.sort(priClasses);
/* 118:    */         
/* 119:144 */         this.displayName.put(((1PriClass)priClasses.get(0)).type, name);
/* 120:145 */         this.shortenedRefTypes.add(((1PriClass)priClasses.get(0)).type);
/* 121:146 */         priClasses.set(0, null);
/* 122:147 */         for (int x = 0; x < priClasses.size(); x++)
/* 123:    */         {
/* 124:148 */           Comparable priClass = (1PriClass)priClasses.get(x);
/* 125:149 */           if ((priClass != null) && (priClass.priType == 1))
/* 126:    */           {
/* 127:150 */             this.displayName.put(priClass.type, name);
/* 128:151 */             this.shortenedRefTypes.add(priClass.type);
/* 129:152 */             priClasses.set(x, null);
/* 130:    */           }
/* 131:    */         }
/* 132:155 */         for (Comparable priClass : priClasses) {
/* 133:156 */           if (priClass != null) {
/* 134:157 */             if (priClass.innerClass)
/* 135:    */             {
/* 136:158 */               String useName = generateInnerClassShortName(priClass.type);
/* 137:159 */               this.shortenedRefTypes.add(priClass.type);
/* 138:160 */               this.displayName.put(priClass.type, useName);
/* 139:    */             }
/* 140:    */             else
/* 141:    */             {
/* 142:162 */               String useName = priClass.type.getRawName();
/* 143:163 */               this.displayName.put(priClass.type, useName);
/* 144:    */             }
/* 145:    */           }
/* 146:    */         }
/* 147:    */       }
/* 148:    */     }
/* 149:    */   }
/* 150:    */   
/* 151:    */   public Set<JavaRefTypeInstance> getUsedClassTypes()
/* 152:    */   {
/* 153:172 */     return this.usedRefTypes;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public Set<JavaRefTypeInstance> getShortenedClassTypes()
/* 157:    */   {
/* 158:177 */     return this.shortenedRefTypes;
/* 159:    */   }
/* 160:    */   
/* 161:    */   public Set<JavaRefTypeInstance> getUsedInnerClassTypes()
/* 162:    */   {
/* 163:182 */     return this.usedLocalInnerTypes;
/* 164:    */   }
/* 165:    */   
/* 166:    */   public String getName(JavaTypeInstance type)
/* 167:    */   {
/* 168:187 */     String res = (String)this.displayName.get(type);
/* 169:188 */     if (res == null) {
/* 170:190 */       return type.getRawName();
/* 171:    */     }
/* 172:193 */     return res;
/* 173:    */   }
/* 174:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.state.TypeUsageInformationImpl
 * JD-Core Version:    0.7.0.1
 */