/*  1:   */ package org.benf.cfr.reader.state;
/*  2:   */ 
/*  3:   */ import java.util.Collection;
/*  4:   */ import java.util.Iterator;
/*  5:   */ import java.util.Set;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.types.InnerClassInfo;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  9:   */ import org.benf.cfr.reader.entities.ClassFile;
/* 10:   */ import org.benf.cfr.reader.util.SetFactory;
/* 11:   */ import org.benf.cfr.reader.util.TypeUsageCollectable;
/* 12:   */ 
/* 13:   */ public class TypeUsageCollector
/* 14:   */ {
/* 15:   */   private final JavaRefTypeInstance analysisType;
/* 16:20 */   private final Set<JavaRefTypeInstance> typeInstanceSet = SetFactory.newSet();
/* 17:21 */   private final Set<JavaTypeInstance> seen = SetFactory.newSet();
/* 18:   */   
/* 19:   */   public TypeUsageCollector(ClassFile analysisClass)
/* 20:   */   {
/* 21:24 */     this.analysisType = ((JavaRefTypeInstance)analysisClass.getClassType().getDeGenerifiedType());
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void collectRefType(JavaRefTypeInstance type)
/* 25:   */   {
/* 26:28 */     this.typeInstanceSet.add(type);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void collect(JavaTypeInstance type)
/* 30:   */   {
/* 31:32 */     if (type == null) {
/* 32:32 */       return;
/* 33:   */     }
/* 34:33 */     if (this.seen.add(type))
/* 35:   */     {
/* 36:34 */       type.collectInto(this);
/* 37:35 */       InnerClassInfo innerClassInfo = type.getInnerClassHereInfo();
/* 38:36 */       if (innerClassInfo.isInnerClass()) {
/* 39:37 */         collect(innerClassInfo.getOuterClass());
/* 40:   */       }
/* 41:   */     }
/* 42:   */   }
/* 43:   */   
/* 44:   */   public void collect(Collection<? extends JavaTypeInstance> types)
/* 45:   */   {
/* 46:43 */     if (types == null) {
/* 47:   */       return;
/* 48:   */     }
/* 49:   */     JavaTypeInstance type;
/* 50:44 */     for (Iterator i$ = types.iterator(); i$.hasNext(); collect(type)) {
/* 51:44 */       type = (JavaTypeInstance)i$.next();
/* 52:   */     }
/* 53:   */   }
/* 54:   */   
/* 55:   */   public void collectFrom(TypeUsageCollectable collectable)
/* 56:   */   {
/* 57:48 */     if (collectable != null) {
/* 58:48 */       collectable.collectTypeUsages(this);
/* 59:   */     }
/* 60:   */   }
/* 61:   */   
/* 62:   */   public void collectFrom(Collection<? extends TypeUsageCollectable> collectables)
/* 63:   */   {
/* 64:52 */     if (collectables != null) {
/* 65:53 */       for (TypeUsageCollectable collectable : collectables) {
/* 66:54 */         if (collectable != null) {
/* 67:54 */           collectable.collectTypeUsages(this);
/* 68:   */         }
/* 69:   */       }
/* 70:   */     }
/* 71:   */   }
/* 72:   */   
/* 73:   */   public TypeUsageInformation getTypeUsageInformation()
/* 74:   */   {
/* 75:61 */     return new TypeUsageInformationImpl(this.analysisType, this.typeInstanceSet);
/* 76:   */   }
/* 77:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.state.TypeUsageCollector
 * JD-Core Version:    0.7.0.1
 */