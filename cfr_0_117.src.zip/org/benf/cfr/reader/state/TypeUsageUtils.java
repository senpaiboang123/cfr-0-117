/*  1:   */ package org.benf.cfr.reader.state;
/*  2:   */ 
/*  3:   */ import java.util.LinkedList;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.types.InnerClassInfo;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  6:   */ import org.benf.cfr.reader.util.ListFactory;
/*  7:   */ import org.benf.cfr.reader.util.StringUtils;
/*  8:   */ 
/*  9:   */ public class TypeUsageUtils
/* 10:   */ {
/* 11:   */   public static String generateInnerClassShortName(JavaRefTypeInstance clazz, JavaRefTypeInstance analysisType, boolean prefixAnalysisType)
/* 12:   */   {
/* 13:12 */     LinkedList<JavaRefTypeInstance> classStack = ListFactory.newLinkedList();
/* 14:   */     
/* 15:14 */     boolean analysisTypeFound = false;
/* 16:15 */     if (clazz.getRawName().startsWith(analysisType.getRawName()))
/* 17:   */     {
/* 18:18 */       String possible = clazz.getRawName().substring(analysisType.getRawName().length());
/* 19:19 */       if (!possible.isEmpty()) {
/* 20:20 */         switch (possible.charAt(0))
/* 21:   */         {
/* 22:   */         case '$': 
/* 23:   */         case '.': 
/* 24:23 */           analysisTypeFound = true;
/* 25:   */         }
/* 26:   */       }
/* 27:   */     }
/* 28:28 */     JavaRefTypeInstance currentClass = clazz;
/* 29:   */     for (;;)
/* 30:   */     {
/* 31:30 */       InnerClassInfo innerClassInfo = currentClass.getInnerClassHereInfo();
/* 32:31 */       if (!innerClassInfo.isAnonymousClass()) {
/* 33:32 */         classStack.addFirst(currentClass);
/* 34:   */       }
/* 35:34 */       if (!innerClassInfo.isInnerClass()) {
/* 36:   */         break;
/* 37:   */       }
/* 38:37 */       currentClass = innerClassInfo.getOuterClass();
/* 39:38 */       if (currentClass.equals(analysisType))
/* 40:   */       {
/* 41:39 */         analysisTypeFound = true;
/* 42:40 */         break;
/* 43:   */       }
/* 44:   */     }
/* 45:47 */     if (analysisTypeFound == currentClass.equals(analysisType))
/* 46:   */     {
/* 47:48 */       StringBuilder sb = new StringBuilder();
/* 48:49 */       boolean first = true;
/* 49:53 */       if (prefixAnalysisType)
/* 50:   */       {
/* 51:54 */         sb.append(analysisType.getRawShortName());
/* 52:55 */         first = false;
/* 53:   */       }
/* 54:58 */       for (JavaRefTypeInstance stackClass : classStack)
/* 55:   */       {
/* 56:59 */         first = StringUtils.dot(first, sb);
/* 57:60 */         sb.append(stackClass.getRawShortName());
/* 58:   */       }
/* 59:62 */       return sb.toString();
/* 60:   */     }
/* 61:65 */     String clazzRawName = clazz.getRawName();
/* 62:   */     
/* 63:67 */     String analysisTypeRawName = analysisType.getRawName();
/* 64:69 */     if (clazzRawName.equals(analysisTypeRawName))
/* 65:   */     {
/* 66:70 */       int idx = clazzRawName.lastIndexOf('.');
/* 67:71 */       if ((idx >= 1) && (idx < clazzRawName.length() - 1)) {
/* 68:72 */         return clazzRawName.substring(idx + 1);
/* 69:   */       }
/* 70:   */     }
/* 71:76 */     if (analysisTypeRawName.length() >= clazzRawName.length() - 1) {
/* 72:77 */       return clazzRawName;
/* 73:   */     }
/* 74:79 */     return clazzRawName.substring(analysisType.getRawName().length() + 1);
/* 75:   */   }
/* 76:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.state.TypeUsageUtils
 * JD-Core Version:    0.7.0.1
 */