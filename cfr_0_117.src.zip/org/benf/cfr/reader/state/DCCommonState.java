/*   1:    */ package org.benf.cfr.reader.state;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.util.LinkedHashSet;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Set;
/*   8:    */ import org.benf.cfr.reader.api.ClassFileSource;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.types.ClassNameUtils;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  13:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  14:    */ import org.benf.cfr.reader.util.CannotLoadClassException;
/*  15:    */ import org.benf.cfr.reader.util.ListFactory;
/*  16:    */ import org.benf.cfr.reader.util.MapFactory;
/*  17:    */ import org.benf.cfr.reader.util.bytestream.BaseByteData;
/*  18:    */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  19:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  20:    */ import org.benf.cfr.reader.util.getopt.Options;
/*  21:    */ 
/*  22:    */ public class DCCommonState
/*  23:    */ {
/*  24: 22 */   private final ClassCache classCache = new ClassCache(this);
/*  25:    */   private final ClassFileSource classFileSource;
/*  26:    */   private final Options options;
/*  27: 26 */   private transient LinkedHashSet<String> couldNotLoadClasses = new LinkedHashSet();
/*  28:    */   
/*  29:    */   public DCCommonState(Options options, ClassFileSource classFileSource)
/*  30:    */   {
/*  31: 29 */     this.options = options;
/*  32: 30 */     this.classFileSource = classFileSource;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void configureWith(ClassFile classFile)
/*  36:    */   {
/*  37: 34 */     this.classFileSource.informAnalysisRelativePathDetail(classFile.getUsePath(), classFile.getFilePath());
/*  38:    */   }
/*  39:    */   
/*  40:    */   public Set<String> getCouldNotLoadClasses()
/*  41:    */   {
/*  42: 38 */     return this.couldNotLoadClasses;
/*  43:    */   }
/*  44:    */   
/*  45: 41 */   private Map<String, ClassFile> classFileCache = MapFactory.newExceptionRetainingLazyMap(new UnaryFunction()
/*  46:    */   {
/*  47:    */     public ClassFile invoke(String arg)
/*  48:    */     {
/*  49: 44 */       return DCCommonState.this.loadClassFileAtPath(arg);
/*  50:    */     }
/*  51: 41 */   });
/*  52:    */   
/*  53:    */   private ClassFile loadClassFileAtPath(String path)
/*  54:    */   {
/*  55:    */     try
/*  56:    */     {
/*  57: 50 */       Pair<byte[], String> content = this.classFileSource.getClassFileContent(path);
/*  58: 51 */       ByteData data = new BaseByteData((byte[])content.getFirst());
/*  59: 52 */       return new ClassFile(data, (String)content.getSecond(), this);
/*  60:    */     }
/*  61:    */     catch (Exception e)
/*  62:    */     {
/*  63: 55 */       this.couldNotLoadClasses.add(path);
/*  64: 56 */       throw new CannotLoadClassException(path, e);
/*  65:    */     }
/*  66:    */   }
/*  67:    */   
/*  68:    */   public List<JavaTypeInstance> explicitlyLoadJar(String path)
/*  69:    */   {
/*  70: 62 */     List<JavaTypeInstance> output = ListFactory.newList();
/*  71: 63 */     for (String classPath : this.classFileSource.addJar(path)) {
/*  72: 65 */       if (classPath.toLowerCase().endsWith(".class")) {
/*  73: 66 */         output.add(this.classCache.getRefClassFor(classPath.substring(0, classPath.length() - 6)));
/*  74:    */       }
/*  75:    */     }
/*  76: 69 */     return output;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public ClassFile getClassFile(String path)
/*  80:    */     throws CannotLoadClassException
/*  81:    */   {
/*  82: 73 */     return (ClassFile)this.classFileCache.get(path);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public JavaRefTypeInstance getClassTypeOrNull(String path)
/*  86:    */   {
/*  87:    */     try
/*  88:    */     {
/*  89: 78 */       ClassFile classFile = getClassFile(path);
/*  90: 79 */       return (JavaRefTypeInstance)classFile.getClassType();
/*  91:    */     }
/*  92:    */     catch (CannotLoadClassException e) {}
/*  93: 81 */     return null;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public ClassFile getClassFile(JavaTypeInstance classInfo)
/*  97:    */     throws CannotLoadClassException
/*  98:    */   {
/*  99: 86 */     String path = classInfo.getRawName();
/* 100: 87 */     path = ClassNameUtils.convertToPath(path) + ".class";
/* 101: 88 */     return getClassFile(path);
/* 102:    */   }
/* 103:    */   
/* 104:    */   public ClassFile getClassFileMaybePath(String pathOrName)
/* 105:    */     throws CannotLoadClassException
/* 106:    */   {
/* 107: 92 */     if (pathOrName.endsWith(".class")) {
/* 108: 94 */       return getClassFile(pathOrName);
/* 109:    */     }
/* 110: 97 */     File f = new File(pathOrName);
/* 111: 98 */     if (f.exists())
/* 112:    */     {
/* 113: 99 */       f = null;
/* 114:100 */       return getClassFile(pathOrName);
/* 115:    */     }
/* 116:102 */     return getClassFile(ClassNameUtils.convertToPath(pathOrName) + ".class");
/* 117:    */   }
/* 118:    */   
/* 119:    */   public ClassCache getClassCache()
/* 120:    */   {
/* 121:107 */     return this.classCache;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public Options getOptions()
/* 125:    */   {
/* 126:111 */     return this.options;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public String detectClsJar(String path)
/* 130:    */   {
/* 131:116 */     if (path.toLowerCase().endsWith(".jar")) {
/* 132:116 */       return "jar";
/* 133:    */     }
/* 134:117 */     return "class";
/* 135:    */   }
/* 136:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.state.DCCommonState
 * JD-Core Version:    0.7.0.1
 */