/*  1:   */ package org.benf.cfr.reader.state;
/*  2:   */ 
/*  3:   */ import java.util.Map;
/*  4:   */ import java.util.Map.Entry;
/*  5:   */ import java.util.Set;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  8:   */ import org.benf.cfr.reader.util.MapFactory;
/*  9:   */ import org.benf.cfr.reader.util.SetFactory;
/* 10:   */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/* 11:   */ 
/* 12:   */ public class LocalClassAwareTypeUsageInformation
/* 13:   */   implements TypeUsageInformation
/* 14:   */ {
/* 15:   */   private final TypeUsageInformation delegate;
/* 16:   */   private final Map<JavaTypeInstance, String> localTypeNames;
/* 17:   */   private final Set<String> usedLocalTypeNames;
/* 18:   */   
/* 19:   */   public LocalClassAwareTypeUsageInformation(Map<JavaRefTypeInstance, String> localClassTypes, TypeUsageInformation delegate)
/* 20:   */   {
/* 21:18 */     this.delegate = delegate;
/* 22:19 */     Map<String, Integer> lastClassByName = MapFactory.newLazyMap(new UnaryFunction()
/* 23:   */     {
/* 24:   */       public Integer invoke(String arg)
/* 25:   */       {
/* 26:22 */         return Integer.valueOf(0);
/* 27:   */       }
/* 28:24 */     });
/* 29:25 */     this.localTypeNames = MapFactory.newMap();
/* 30:26 */     this.usedLocalTypeNames = SetFactory.newSet();
/* 31:27 */     for (Map.Entry<JavaRefTypeInstance, String> entry : localClassTypes.entrySet())
/* 32:   */     {
/* 33:28 */       JavaRefTypeInstance localType = (JavaRefTypeInstance)entry.getKey();
/* 34:29 */       String suggestedName = (String)entry.getValue();
/* 35:   */       String usedName;
/* 36:   */       String usedName;
/* 37:31 */       if (suggestedName != null)
/* 38:   */       {
/* 39:32 */         usedName = suggestedName;
/* 40:   */       }
/* 41:   */       else
/* 42:   */       {
/* 43:34 */         String name = delegate.generateInnerClassShortName(localType);
/* 44:   */         
/* 45:   */ 
/* 46:   */ 
/* 47:38 */         int idx = 0;
/* 48:38 */         for (int len = name.length(); idx < len; idx++)
/* 49:   */         {
/* 50:39 */           char c = name.charAt(idx);
/* 51:40 */           if ((c < '0') || (c > '9'))
/* 52:   */           {
/* 53:41 */             name = name.substring(idx);
/* 54:42 */             break;
/* 55:   */           }
/* 56:   */         }
/* 57:44 */         int x = ((Integer)lastClassByName.get(name)).intValue();
/* 58:45 */         lastClassByName.put(name, Integer.valueOf(x + 1));
/* 59:46 */         usedName = name + (x == 0 ? "" : new StringBuilder().append("_").append(x).toString());
/* 60:   */       }
/* 61:48 */       this.localTypeNames.put(localType, usedName);
/* 62:49 */       this.usedLocalTypeNames.add(usedName);
/* 63:   */     }
/* 64:   */   }
/* 65:   */   
/* 66:   */   public Set<JavaRefTypeInstance> getUsedClassTypes()
/* 67:   */   {
/* 68:55 */     return this.delegate.getUsedClassTypes();
/* 69:   */   }
/* 70:   */   
/* 71:   */   public Set<JavaRefTypeInstance> getUsedInnerClassTypes()
/* 72:   */   {
/* 73:60 */     return this.delegate.getUsedInnerClassTypes();
/* 74:   */   }
/* 75:   */   
/* 76:   */   public String getName(JavaTypeInstance type)
/* 77:   */   {
/* 78:65 */     String local = (String)this.localTypeNames.get(type);
/* 79:66 */     if (local != null) {
/* 80:66 */       return local;
/* 81:   */     }
/* 82:68 */     String res = this.delegate.getName(type);
/* 83:69 */     if (this.usedLocalTypeNames.contains(res))
/* 84:   */     {
/* 85:70 */       if ((type instanceof JavaRefTypeInstance)) {
/* 86:71 */         return this.delegate.generateOverriddenName((JavaRefTypeInstance)type);
/* 87:   */       }
/* 88:73 */       return type.getRawName();
/* 89:   */     }
/* 90:76 */     return res;
/* 91:   */   }
/* 92:   */   
/* 93:   */   public String generateInnerClassShortName(JavaRefTypeInstance clazz)
/* 94:   */   {
/* 95:81 */     return this.delegate.generateInnerClassShortName(clazz);
/* 96:   */   }
/* 97:   */   
/* 98:   */   public String generateOverriddenName(JavaRefTypeInstance clazz)
/* 99:   */   {
/* :0:86 */     return this.delegate.generateOverriddenName(clazz);
/* :1:   */   }
/* :2:   */   
/* :3:   */   public Set<JavaRefTypeInstance> getShortenedClassTypes()
/* :4:   */   {
/* :5:91 */     return this.delegate.getShortenedClassTypes();
/* :6:   */   }
/* :7:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.state.LocalClassAwareTypeUsageInformation
 * JD-Core Version:    0.7.0.1
 */