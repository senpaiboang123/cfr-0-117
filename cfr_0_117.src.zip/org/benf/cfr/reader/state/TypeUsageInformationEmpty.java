/*  1:   */ package org.benf.cfr.reader.state;
/*  2:   */ 
/*  3:   */ import java.util.Set;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  6:   */ import org.benf.cfr.reader.util.SetFactory;
/*  7:   */ 
/*  8:   */ public class TypeUsageInformationEmpty
/*  9:   */   implements TypeUsageInformation
/* 10:   */ {
/* 11:   */   public Set<JavaRefTypeInstance> getUsedClassTypes()
/* 12:   */   {
/* 13:12 */     return SetFactory.newOrderedSet();
/* 14:   */   }
/* 15:   */   
/* 16:   */   public Set<JavaRefTypeInstance> getUsedInnerClassTypes()
/* 17:   */   {
/* 18:17 */     return SetFactory.newOrderedSet();
/* 19:   */   }
/* 20:   */   
/* 21:   */   public Set<JavaRefTypeInstance> getShortenedClassTypes()
/* 22:   */   {
/* 23:22 */     return SetFactory.newOrderedSet();
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName(JavaTypeInstance type)
/* 27:   */   {
/* 28:27 */     return type.getRawName();
/* 29:   */   }
/* 30:   */   
/* 31:   */   public String generateOverriddenName(JavaRefTypeInstance clazz)
/* 32:   */   {
/* 33:32 */     return clazz.getRawName();
/* 34:   */   }
/* 35:   */   
/* 36:   */   public String generateInnerClassShortName(JavaRefTypeInstance clazz)
/* 37:   */   {
/* 38:37 */     return clazz.getRawName();
/* 39:   */   }
/* 40:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.state.TypeUsageInformationEmpty
 * JD-Core Version:    0.7.0.1
 */