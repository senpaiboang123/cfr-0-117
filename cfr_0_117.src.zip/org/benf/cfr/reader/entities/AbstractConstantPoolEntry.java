/*  1:   */ package org.benf.cfr.reader.entities;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  4:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/*  5:   */ 
/*  6:   */ public abstract class AbstractConstantPoolEntry
/*  7:   */   implements ConstantPoolEntry
/*  8:   */ {
/*  9:   */   private final ConstantPool cp;
/* 10:   */   
/* 11:   */   protected AbstractConstantPoolEntry(ConstantPool cp)
/* 12:   */   {
/* 13:10 */     this.cp = cp;
/* 14:   */   }
/* 15:   */   
/* 16:   */   protected ConstantPool getCp()
/* 17:   */   {
/* 18:14 */     if (!this.cp.isLoaded()) {
/* 19:15 */       throw new IllegalStateException("Attempt to use constant pool before it's fully loaded.");
/* 20:   */     }
/* 21:17 */     return this.cp;
/* 22:   */   }
/* 23:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.AbstractConstantPoolEntry
 * JD-Core Version:    0.7.0.1
 */