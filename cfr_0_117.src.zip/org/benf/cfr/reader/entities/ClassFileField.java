/*  1:   */ package org.benf.cfr.reader.entities;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  6:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  7:   */ 
/*  8:   */ public class ClassFileField
/*  9:   */ {
/* 10:   */   private final Field field;
/* 11:   */   private Expression initialValue;
/* 12:   */   private boolean isHidden;
/* 13:   */   private boolean isSyntheticOuterRef;
/* 14:   */   private String overriddenName;
/* 15:   */   
/* 16:   */   public ClassFileField(Field field)
/* 17:   */   {
/* 18:23 */     this.field = field;
/* 19:24 */     TypedLiteral constantValue = field.getConstantValue();
/* 20:25 */     this.initialValue = (constantValue == null ? null : new Literal(constantValue));
/* 21:26 */     this.isHidden = false;
/* 22:27 */     this.isSyntheticOuterRef = false;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public Field getField()
/* 26:   */   {
/* 27:31 */     return this.field;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public Expression getInitialValue()
/* 31:   */   {
/* 32:35 */     return this.initialValue;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void setInitialValue(Expression rValue)
/* 36:   */   {
/* 37:39 */     this.initialValue = rValue;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public boolean shouldNotDisplay()
/* 41:   */   {
/* 42:43 */     return (this.isHidden) || (this.isSyntheticOuterRef);
/* 43:   */   }
/* 44:   */   
/* 45:   */   public boolean isSyntheticOuterRef()
/* 46:   */   {
/* 47:47 */     return this.isSyntheticOuterRef;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public void markHidden()
/* 51:   */   {
/* 52:51 */     this.isHidden = true;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public void markSyntheticOuterRef()
/* 56:   */   {
/* 57:55 */     this.isSyntheticOuterRef = true;
/* 58:   */   }
/* 59:   */   
/* 60:   */   public void overrideName(String override)
/* 61:   */   {
/* 62:59 */     this.overriddenName = override;
/* 63:   */   }
/* 64:   */   
/* 65:   */   public String getFieldName()
/* 66:   */   {
/* 67:63 */     if (this.overriddenName != null) {
/* 68:63 */       return this.overriddenName;
/* 69:   */     }
/* 70:64 */     return this.field.getFieldName();
/* 71:   */   }
/* 72:   */   
/* 73:   */   public void dump(Dumper d)
/* 74:   */   {
/* 75:68 */     this.field.dump(d, getFieldName());
/* 76:69 */     if (this.initialValue != null) {
/* 77:70 */       d.print(" = ").dump(this.initialValue);
/* 78:   */     }
/* 79:72 */     d.endCodeln();
/* 80:   */   }
/* 81:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.ClassFileField
 * JD-Core Version:    0.7.0.1
 */