/*  1:   */ package org.benf.cfr.reader.entities;
/*  2:   */ 
/*  3:   */ import java.util.EnumSet;
/*  4:   */ import java.util.Map;
/*  5:   */ import java.util.Set;
/*  6:   */ import org.benf.cfr.reader.entities.attributes.Attribute;
/*  7:   */ 
/*  8:   */ public enum AccessFlagMethod
/*  9:   */ {
/* 10:12 */   ACC_PUBLIC("public"),  ACC_PRIVATE("private"),  ACC_PROTECTED("protected"),  ACC_STATIC("static"),  ACC_FINAL("final"),  ACC_SYNCHRONISED("synchronized"),  ACC_BRIDGE("/* bridge */"),  ACC_VARARGS("/* varargs */"),  ACC_NATIVE("native"),  ACC_ABSTRACT("abstract"),  ACC_STRICT("strictfp"),  ACC_SYNTHETIC("/* synthetic */");
/* 11:   */   
/* 12:   */   private final String name;
/* 13:   */   
/* 14:   */   private AccessFlagMethod(String name)
/* 15:   */   {
/* 16:28 */     this.name = name;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public static EnumSet<AccessFlagMethod> build(int raw)
/* 20:   */   {
/* 21:32 */     EnumSet<AccessFlagMethod> res = EnumSet.noneOf(AccessFlagMethod.class);
/* 22:35 */     if (0 != (raw & 0x1)) {
/* 23:35 */       res.add(ACC_PUBLIC);
/* 24:   */     }
/* 25:36 */     if (0 != (raw & 0x2)) {
/* 26:36 */       res.add(ACC_PRIVATE);
/* 27:   */     }
/* 28:37 */     if (0 != (raw & 0x4)) {
/* 29:37 */       res.add(ACC_PROTECTED);
/* 30:   */     }
/* 31:38 */     if (0 != (raw & 0x8)) {
/* 32:38 */       res.add(ACC_STATIC);
/* 33:   */     }
/* 34:39 */     if (0 != (raw & 0x10)) {
/* 35:39 */       res.add(ACC_FINAL);
/* 36:   */     }
/* 37:40 */     if (0 != (raw & 0x20)) {
/* 38:40 */       res.add(ACC_SYNCHRONISED);
/* 39:   */     }
/* 40:41 */     if (0 != (raw & 0x40)) {
/* 41:41 */       res.add(ACC_BRIDGE);
/* 42:   */     }
/* 43:42 */     if (0 != (raw & 0x80)) {
/* 44:42 */       res.add(ACC_VARARGS);
/* 45:   */     }
/* 46:43 */     if (0 != (raw & 0x100)) {
/* 47:43 */       res.add(ACC_NATIVE);
/* 48:   */     }
/* 49:44 */     if (0 != (raw & 0x400)) {
/* 50:44 */       res.add(ACC_ABSTRACT);
/* 51:   */     }
/* 52:45 */     if (0 != (raw & 0x800)) {
/* 53:45 */       res.add(ACC_STRICT);
/* 54:   */     }
/* 55:46 */     if (0 != (raw & 0x1000)) {
/* 56:46 */       res.add(ACC_SYNTHETIC);
/* 57:   */     }
/* 58:48 */     if (res.isEmpty()) {
/* 59:48 */       return res;
/* 60:   */     }
/* 61:49 */     EnumSet<AccessFlagMethod> resaf = EnumSet.copyOf(res);
/* 62:50 */     return resaf;
/* 63:   */   }
/* 64:   */   
/* 65:   */   public String toString()
/* 66:   */   {
/* 67:56 */     return this.name;
/* 68:   */   }
/* 69:   */   
/* 70:   */   public static void applyAttributes(Map<String, Attribute> attributeMap, Set<AccessFlagMethod> accessFlagSet)
/* 71:   */   {
/* 72:60 */     if (attributeMap.containsKey("Synthetic")) {
/* 73:60 */       accessFlagSet.add(ACC_SYNTHETIC);
/* 74:   */     }
/* 75:   */   }
/* 76:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.AccessFlagMethod
 * JD-Core Version:    0.7.0.1
 */