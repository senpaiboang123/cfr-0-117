/*  1:   */ package org.benf.cfr.reader.entities.exceptions;
/*  2:   */ 
/*  3:   */ import java.util.Set;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  6:   */ import org.benf.cfr.reader.util.SetFactory;
/*  7:   */ 
/*  8:   */ public class BasicExceptions
/*  9:   */ {
/* 10:13 */   public static Set<? extends JavaTypeInstance> instances = SetFactory.newSet(new JavaRefTypeInstance[] { JavaRefTypeInstance.createTypeConstant("java.lang.AbstractMethodError", "AbstractMethodError", new JavaRefTypeInstance[0]), JavaRefTypeInstance.createTypeConstant("java.lang.ArithmeticException", "ArithmeticException", new JavaRefTypeInstance[0]), JavaRefTypeInstance.createTypeConstant("java.lang.ArrayIndexOutOfBoundsException", "ArrayIndexOutOfBoundsException", new JavaRefTypeInstance[0]), JavaRefTypeInstance.createTypeConstant("java.lang.ArrayStoreException", "ArrayStoreException", new JavaRefTypeInstance[0]), JavaRefTypeInstance.createTypeConstant("java.lang.ClassCastException", "ClassCastException", new JavaRefTypeInstance[0]), JavaRefTypeInstance.createTypeConstant("java.lang.IllegalAccessError", "IllegalAccessError", new JavaRefTypeInstance[0]), JavaRefTypeInstance.createTypeConstant("java.lang.IllegalMonitorStateException", "IllegalMonitorStateException", new JavaRefTypeInstance[0]), JavaRefTypeInstance.createTypeConstant("java.lang.IncompatibleClassChangeError", "IncompatibleClassChangeError", new JavaRefTypeInstance[0]), JavaRefTypeInstance.createTypeConstant("java.lang.InstantiationError", "InstantiationError", new JavaRefTypeInstance[0]), JavaRefTypeInstance.createTypeConstant("java.lang.NegativeArraySizeException", "NegativeArraySizeException", new JavaRefTypeInstance[0]), JavaRefTypeInstance.createTypeConstant("java.lang.NullPointerException", "NullPointerException", new JavaRefTypeInstance[0]), JavaRefTypeInstance.createTypeConstant("java.lang.UnsatisfiedLinkError", "UnsatisfiedLinkError", new JavaRefTypeInstance[0]) });
/* 11:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.exceptions.BasicExceptions
 * JD-Core Version:    0.7.0.1
 */