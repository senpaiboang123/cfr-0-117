/*  1:   */ package org.benf.cfr.reader.entities.exceptions;
/*  2:   */ 
/*  3:   */ import java.util.Set;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractMemberFunctionInvokation;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  7:   */ 
/*  8:   */ public class ExceptionCheckSimple
/*  9:   */   implements ExceptionCheck
/* 10:   */ {
/* 11:10 */   public static final ExceptionCheck INSTANCE = new ExceptionCheckSimple();
/* 12:   */   
/* 13:   */   public boolean checkAgainst(Set<? extends JavaTypeInstance> thrown)
/* 14:   */   {
/* 15:17 */     return true;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public boolean checkAgainst(AbstractMemberFunctionInvokation functionInvokation)
/* 19:   */   {
/* 20:22 */     return true;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public boolean checkAgainstException(Expression expression)
/* 24:   */   {
/* 25:27 */     return true;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public boolean mightCatchUnchecked()
/* 29:   */   {
/* 30:32 */     return true;
/* 31:   */   }
/* 32:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.exceptions.ExceptionCheckSimple
 * JD-Core Version:    0.7.0.1
 */