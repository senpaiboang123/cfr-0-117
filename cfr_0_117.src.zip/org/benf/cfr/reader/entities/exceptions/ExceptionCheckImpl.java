/*   1:    */ package org.benf.cfr.reader.entities.exceptions;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.Map;
/*   5:    */ import java.util.Set;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractMemberFunctionInvokation;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationSimple;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.types.BindingSuperContainer;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  12:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  13:    */ import org.benf.cfr.reader.entities.Method;
/*  14:    */ import org.benf.cfr.reader.state.DCCommonState;
/*  15:    */ import org.benf.cfr.reader.util.CannotLoadClassException;
/*  16:    */ import org.benf.cfr.reader.util.SetFactory;
/*  17:    */ import org.benf.cfr.reader.util.SetUtil;
/*  18:    */ 
/*  19:    */ public class ExceptionCheckImpl
/*  20:    */   implements ExceptionCheck
/*  21:    */ {
/*  22: 19 */   private final Set<JavaRefTypeInstance> caughtChecked = SetFactory.newSet();
/*  23: 20 */   private final Set<JavaRefTypeInstance> caughtUnchecked = SetFactory.newSet();
/*  24:    */   private final boolean mightUseUnchecked;
/*  25:    */   private final boolean missingInfo;
/*  26:    */   private final DCCommonState dcCommonState;
/*  27:    */   private final JavaRefTypeInstance runtimeExceptionType;
/*  28:    */   
/*  29:    */   public ExceptionCheckImpl(DCCommonState dcCommonState, Set<JavaRefTypeInstance> caught)
/*  30:    */   {
/*  31: 27 */     this.dcCommonState = dcCommonState;
/*  32: 28 */     this.runtimeExceptionType = dcCommonState.getClassTypeOrNull("java/lang/RuntimeException.class");
/*  33: 29 */     if (this.runtimeExceptionType == null)
/*  34:    */     {
/*  35: 30 */       this.mightUseUnchecked = true;
/*  36: 31 */       this.missingInfo = true;
/*  37: 32 */       return;
/*  38:    */     }
/*  39: 35 */     boolean lmightUseUnchecked = false;
/*  40: 36 */     boolean lmissinginfo = false;
/*  41: 37 */     for (JavaRefTypeInstance ref : caught)
/*  42:    */     {
/*  43: 38 */       BindingSuperContainer superContainer = ref.getBindingSupers();
/*  44: 39 */       if (superContainer == null)
/*  45:    */       {
/*  46: 40 */         lmightUseUnchecked = true;
/*  47: 41 */         lmissinginfo = true;
/*  48:    */       }
/*  49:    */       else
/*  50:    */       {
/*  51: 44 */         Map<JavaRefTypeInstance, ?> supers = superContainer.getBoundSuperClasses();
/*  52: 45 */         if (supers == null)
/*  53:    */         {
/*  54: 46 */           lmightUseUnchecked = true;
/*  55: 47 */           lmissinginfo = true;
/*  56:    */         }
/*  57: 50 */         else if (supers.containsKey(this.runtimeExceptionType))
/*  58:    */         {
/*  59: 51 */           lmightUseUnchecked = true;
/*  60: 52 */           this.caughtUnchecked.add(ref);
/*  61:    */         }
/*  62:    */         else
/*  63:    */         {
/*  64: 54 */           this.caughtChecked.add(ref);
/*  65:    */         }
/*  66:    */       }
/*  67:    */     }
/*  68: 57 */     this.mightUseUnchecked = lmightUseUnchecked;
/*  69: 58 */     this.missingInfo = lmissinginfo;
/*  70:    */   }
/*  71:    */   
/*  72:    */   private boolean checkAgainstInternal(Set<? extends JavaTypeInstance> thrown)
/*  73:    */   {
/*  74: 62 */     if (thrown.isEmpty()) {
/*  75: 62 */       return false;
/*  76:    */     }
/*  77: 64 */     for (JavaTypeInstance thrownType : thrown) {
/*  78:    */       try
/*  79:    */       {
/*  80: 66 */         ClassFile thrownClassFile = this.dcCommonState.getClassFile(thrownType);
/*  81: 67 */         if (thrownClassFile == null) {
/*  82: 67 */           return true;
/*  83:    */         }
/*  84: 68 */         BindingSuperContainer bindingSuperContainer = thrownClassFile.getBindingSupers();
/*  85: 69 */         if (bindingSuperContainer == null) {
/*  86: 69 */           return true;
/*  87:    */         }
/*  88: 70 */         Map<JavaRefTypeInstance, ?> boundSuperClasses = bindingSuperContainer.getBoundSuperClasses();
/*  89: 71 */         if (boundSuperClasses == null) {
/*  90: 71 */           return true;
/*  91:    */         }
/*  92: 72 */         if (SetUtil.hasIntersection(this.caughtChecked, boundSuperClasses.keySet())) {
/*  93: 72 */           return true;
/*  94:    */         }
/*  95:    */       }
/*  96:    */       catch (CannotLoadClassException e)
/*  97:    */       {
/*  98: 74 */         return true;
/*  99:    */       }
/* 100:    */     }
/* 101: 77 */     return false;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public boolean checkAgainst(Set<? extends JavaTypeInstance> thrown)
/* 105:    */   {
/* 106:    */     try
/* 107:    */     {
/* 108: 83 */       return checkAgainstInternal(thrown);
/* 109:    */     }
/* 110:    */     catch (Exception e) {}
/* 111: 85 */     return true;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public boolean checkAgainst(AbstractMemberFunctionInvokation functionInvokation)
/* 115:    */   {
/* 116: 92 */     if (this.mightUseUnchecked) {
/* 117: 92 */       return true;
/* 118:    */     }
/* 119: 93 */     JavaTypeInstance type = functionInvokation.getClassTypeInstance();
/* 120:    */     try
/* 121:    */     {
/* 122: 95 */       ClassFile classFile = this.dcCommonState.getClassFile(type);
/* 123: 96 */       Method method = classFile.getMethodByPrototype(functionInvokation.getMethodPrototype());
/* 124: 97 */       return checkAgainstInternal(method.getThrownTypes());
/* 125:    */     }
/* 126:    */     catch (NoSuchMethodException e)
/* 127:    */     {
/* 128: 99 */       return true;
/* 129:    */     }
/* 130:    */     catch (CannotLoadClassException e) {}
/* 131:101 */     return true;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public boolean checkAgainstException(Expression expression)
/* 135:    */   {
/* 136:107 */     if (this.missingInfo) {
/* 137:107 */       return true;
/* 138:    */     }
/* 139:112 */     if (!(expression instanceof ConstructorInvokationSimple)) {
/* 140:112 */       return true;
/* 141:    */     }
/* 142:113 */     ConstructorInvokationSimple constructorInvokation = (ConstructorInvokationSimple)expression;
/* 143:114 */     JavaTypeInstance type = constructorInvokation.getTypeInstance();
/* 144:115 */     Map<JavaRefTypeInstance, ?> boundSuperClasses = null;
/* 145:    */     try
/* 146:    */     {
/* 147:117 */       ClassFile classFile = this.dcCommonState.getClassFile(type);
/* 148:118 */       if (classFile == null) {
/* 149:118 */         return true;
/* 150:    */       }
/* 151:119 */       BindingSuperContainer bindingSuperContainer = classFile.getBindingSupers();
/* 152:120 */       if (bindingSuperContainer == null) {
/* 153:120 */         return true;
/* 154:    */       }
/* 155:121 */       boundSuperClasses = bindingSuperContainer.getBoundSuperClasses();
/* 156:122 */       if (boundSuperClasses == null) {
/* 157:122 */         return true;
/* 158:    */       }
/* 159:    */     }
/* 160:    */     catch (CannotLoadClassException e)
/* 161:    */     {
/* 162:125 */       return true;
/* 163:    */     }
/* 164:130 */     Collection<JavaRefTypeInstance> throwingBases = boundSuperClasses.keySet();
/* 165:131 */     if (SetUtil.hasIntersection(this.caughtChecked, throwingBases)) {
/* 166:131 */       return true;
/* 167:    */     }
/* 168:132 */     if (SetUtil.hasIntersection(this.caughtUnchecked, throwingBases)) {
/* 169:132 */       return true;
/* 170:    */     }
/* 171:133 */     return false;
/* 172:    */   }
/* 173:    */   
/* 174:    */   public boolean mightCatchUnchecked()
/* 175:    */   {
/* 176:138 */     return this.mightUseUnchecked;
/* 177:    */   }
/* 178:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.exceptions.ExceptionCheckImpl
 * JD-Core Version:    0.7.0.1
 */