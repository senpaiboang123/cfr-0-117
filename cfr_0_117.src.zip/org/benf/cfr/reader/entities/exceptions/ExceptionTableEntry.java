/*   1:    */ package org.benf.cfr.reader.entities.exceptions;
/*   2:    */ 
/*   3:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*   4:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*   5:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass;
/*   6:    */ import org.benf.cfr.reader.state.ClassCache;
/*   7:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*   8:    */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*   9:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  10:    */ 
/*  11:    */ public class ExceptionTableEntry
/*  12:    */   implements Comparable<ExceptionTableEntry>
/*  13:    */ {
/*  14:    */   private static final int OFFSET_INDEX_FROM = 0;
/*  15:    */   private static final int OFFSET_INDEX_TO = 2;
/*  16:    */   private static final int OFFSET_INDEX_HANDLER = 4;
/*  17:    */   private static final int OFFSET_CATCH_TYPE = 6;
/*  18:    */   private final short bytecode_index_from;
/*  19:    */   private final short bytecode_index_to;
/*  20:    */   private final short bytecode_index_handler;
/*  21:    */   private final short catch_type;
/*  22:    */   private final int priority;
/*  23:    */   
/*  24:    */   public ExceptionTableEntry(ByteData raw, int priority)
/*  25:    */   {
/*  26: 24 */     this(raw.getS2At(0L), raw.getS2At(2L), raw.getS2At(4L), raw.getS2At(6L), priority);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public ExceptionTableEntry(short from, short to, short handler, short catchType, int priority)
/*  30:    */   {
/*  31: 33 */     this.bytecode_index_from = from;
/*  32: 34 */     this.bytecode_index_to = to;
/*  33: 35 */     this.bytecode_index_handler = handler;
/*  34: 36 */     this.catch_type = catchType;
/*  35: 37 */     this.priority = priority;
/*  36: 38 */     if (to < from) {
/*  37: 39 */       throw new IllegalStateException("Malformed exception block, to < from");
/*  38:    */     }
/*  39:    */   }
/*  40:    */   
/*  41:    */   public ExceptionTableEntry withThrowableCatchType()
/*  42:    */   {
/*  43: 44 */     return new ExceptionTableEntry(this.bytecode_index_from, this.bytecode_index_to, this.bytecode_index_handler, (short)0, this.priority);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public JavaRefTypeInstance getCatchType(ConstantPool cp)
/*  47:    */   {
/*  48: 49 */     if (this.catch_type == 0) {
/*  49: 50 */       return cp.getClassCache().getRefClassFor("java.lang.Throwable");
/*  50:    */     }
/*  51: 52 */     return (JavaRefTypeInstance)cp.getClassEntry(this.catch_type).getTypeInstance();
/*  52:    */   }
/*  53:    */   
/*  54:    */   public ExceptionTableEntry copyWithRange(short from, short to)
/*  55:    */   {
/*  56: 57 */     return new ExceptionTableEntry(from, to, this.bytecode_index_handler, this.catch_type, this.priority);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public short getBytecodeIndexFrom()
/*  60:    */   {
/*  61: 61 */     return this.bytecode_index_from;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public short getBytecodeIndexTo()
/*  65:    */   {
/*  66: 65 */     return this.bytecode_index_to;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public short getBytecodeIndexHandler()
/*  70:    */   {
/*  71: 69 */     return this.bytecode_index_handler;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public short getCatchType()
/*  75:    */   {
/*  76: 73 */     return this.catch_type;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public int getPriority()
/*  80:    */   {
/*  81: 77 */     return this.priority;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public ExceptionTableEntry aggregateWith(ExceptionTableEntry later)
/*  85:    */   {
/*  86: 81 */     if ((this.bytecode_index_from >= later.bytecode_index_from) || (this.bytecode_index_to != later.bytecode_index_from)) {
/*  87: 83 */       throw new ConfusedCFRException("Can't aggregate exceptionTableEntries");
/*  88:    */     }
/*  89: 86 */     return new ExceptionTableEntry(this.bytecode_index_from, later.bytecode_index_to, this.bytecode_index_handler, this.catch_type, this.priority);
/*  90:    */   }
/*  91:    */   
/*  92:    */   public ExceptionTableEntry aggregateWithLenient(ExceptionTableEntry later)
/*  93:    */   {
/*  94: 90 */     if (this.bytecode_index_from >= later.bytecode_index_from) {
/*  95: 91 */       throw new ConfusedCFRException("Can't aggregate exceptionTableEntries");
/*  96:    */     }
/*  97: 94 */     return new ExceptionTableEntry(this.bytecode_index_from, later.bytecode_index_to, this.bytecode_index_handler, this.catch_type, this.priority);
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static UnaryFunction<ByteData, ExceptionTableEntry> getBuilder(ConstantPool cp)
/* 101:    */   {
/* 102: 98 */     return new ExceptionTableEntryBuilder(cp);
/* 103:    */   }
/* 104:    */   
/* 105:    */   private static class ExceptionTableEntryBuilder
/* 106:    */     implements UnaryFunction<ByteData, ExceptionTableEntry>
/* 107:    */   {
/* 108:102 */     int idx = 0;
/* 109:    */     
/* 110:    */     public ExceptionTableEntryBuilder(ConstantPool cp) {}
/* 111:    */     
/* 112:    */     public ExceptionTableEntry invoke(ByteData arg)
/* 113:    */     {
/* 114:109 */       return new ExceptionTableEntry(arg, this.idx++);
/* 115:    */     }
/* 116:    */   }
/* 117:    */   
/* 118:    */   public int compareTo(ExceptionTableEntry other)
/* 119:    */   {
/* 120:115 */     int res = this.bytecode_index_from - other.bytecode_index_from;
/* 121:116 */     if (res != 0) {
/* 122:116 */       return res;
/* 123:    */     }
/* 124:117 */     res = this.bytecode_index_to - other.bytecode_index_to;
/* 125:119 */     if (res != 0) {
/* 126:119 */       return 0 - res;
/* 127:    */     }
/* 128:120 */     res = this.bytecode_index_handler - other.bytecode_index_handler;
/* 129:121 */     return res;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public String toString()
/* 133:    */   {
/* 134:126 */     return "ExceptionTableEntry " + this.priority + " : [" + this.bytecode_index_from + "->" + this.bytecode_index_to + ") : " + this.bytecode_index_handler;
/* 135:    */   }
/* 136:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.exceptions.ExceptionTableEntry
 * JD-Core Version:    0.7.0.1
 */