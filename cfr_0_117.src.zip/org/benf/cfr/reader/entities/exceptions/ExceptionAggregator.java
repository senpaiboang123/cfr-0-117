/*   1:    */ package org.benf.cfr.reader.entities.exceptions;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.Comparator;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Map;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifierFactory;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockType;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  13:    */ import org.benf.cfr.reader.bytecode.opcode.JVMInstr;
/*  14:    */ import org.benf.cfr.reader.entities.Method;
/*  15:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  16:    */ import org.benf.cfr.reader.util.Functional;
/*  17:    */ import org.benf.cfr.reader.util.ListFactory;
/*  18:    */ import org.benf.cfr.reader.util.MapFactory;
/*  19:    */ import org.benf.cfr.reader.util.Predicate;
/*  20:    */ import org.benf.cfr.reader.util.Troolean;
/*  21:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  22:    */ import org.benf.cfr.reader.util.getopt.Options;
/*  23:    */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*  24:    */ 
/*  25:    */ public class ExceptionAggregator
/*  26:    */ {
/*  27: 21 */   private final List<ExceptionGroup> exceptionsByRange = ListFactory.newList();
/*  28:    */   private final Method method;
/*  29:    */   private final Map<Integer, Integer> lutByOffset;
/*  30:    */   private final Map<Integer, Integer> lutByIdx;
/*  31:    */   private final List<Op01WithProcessedDataAndByteJumps> instrs;
/*  32:    */   private final Options options;
/*  33:    */   private final boolean aggressivePrune;
/*  34:    */   private final boolean aggressiveAggregate;
/*  35:    */   private final boolean removedLoopingExceptions;
/*  36:    */   
/*  37:    */   private static class CompareExceptionTablesByRange
/*  38:    */     implements Comparator<ExceptionTableEntry>
/*  39:    */   {
/*  40:    */     public int compare(ExceptionTableEntry exceptionTableEntry, ExceptionTableEntry exceptionTableEntry1)
/*  41:    */     {
/*  42: 35 */       int res = exceptionTableEntry.getBytecodeIndexFrom() - exceptionTableEntry1.getBytecodeIndexFrom();
/*  43: 36 */       if (res != 0) {
/*  44: 36 */         return res;
/*  45:    */       }
/*  46: 37 */       return exceptionTableEntry.getBytecodeIndexTo() - exceptionTableEntry1.getBytecodeIndexTo();
/*  47:    */     }
/*  48:    */   }
/*  49:    */   
/*  50:    */   private class ByTarget
/*  51:    */   {
/*  52:    */     private final List<ExceptionTableEntry> entries;
/*  53:    */     
/*  54:    */     public ByTarget()
/*  55:    */     {
/*  56: 45 */       this.entries = entries;
/*  57:    */     }
/*  58:    */     
/*  59:    */     public Collection<ExceptionTableEntry> getAggregated()
/*  60:    */     {
/*  61: 49 */       Collections.sort(this.entries, new ExceptionAggregator.CompareExceptionTablesByRange(null));
/*  62:    */       
/*  63:    */ 
/*  64:    */ 
/*  65: 53 */       List<ExceptionTableEntry> res = ListFactory.newList();
/*  66: 54 */       ExceptionTableEntry held = null;
/*  67: 55 */       for (ExceptionTableEntry entry : this.entries) {
/*  68: 56 */         if (held == null)
/*  69:    */         {
/*  70: 57 */           held = entry;
/*  71:    */         }
/*  72: 61 */         else if (held.getBytecodeIndexTo() == entry.getBytecodeIndexFrom())
/*  73:    */         {
/*  74: 62 */           held = held.aggregateWith(entry);
/*  75:    */         }
/*  76: 63 */         else if ((held.getBytecodeIndexFrom() == entry.getBytecodeIndexFrom()) && (held.getBytecodeIndexTo() <= entry.getBytecodeIndexTo()))
/*  77:    */         {
/*  78: 65 */           held = entry;
/*  79:    */         }
/*  80: 66 */         else if ((held.getBytecodeIndexFrom() < entry.getBytecodeIndexFrom()) && (entry.getBytecodeIndexFrom() < held.getBytecodeIndexTo()) && (entry.getBytecodeIndexTo() > held.getBytecodeIndexTo()))
/*  81:    */         {
/*  82: 69 */           held = held.aggregateWithLenient(entry);
/*  83:    */         }
/*  84: 70 */         else if ((ExceptionAggregator.this.aggressiveAggregate) && (ExceptionAggregator.this.canExtendTo(held, entry)))
/*  85:    */         {
/*  86: 71 */           held = held.aggregateWithLenient(entry);
/*  87:    */         }
/*  88:    */         else
/*  89:    */         {
/*  90: 73 */           res.add(held);
/*  91: 74 */           held = entry;
/*  92:    */         }
/*  93:    */       }
/*  94: 78 */       if (held != null) {
/*  95: 78 */         res.add(held);
/*  96:    */       }
/*  97: 79 */       return res;
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   private static class ValidException
/* 102:    */     implements Predicate<ExceptionTableEntry>
/* 103:    */   {
/* 104:    */     public boolean test(ExceptionTableEntry in)
/* 105:    */     {
/* 106: 87 */       return in.getBytecodeIndexFrom() != in.getBytecodeIndexHandler();
/* 107:    */     }
/* 108:    */   }
/* 109:    */   
/* 110:    */   private boolean canExtendTo(ExceptionTableEntry a, ExceptionTableEntry b)
/* 111:    */   {
/* 112:100 */     int startNext = b.getBytecodeIndexFrom();
/* 113:101 */     int current = a.getBytecodeIndexTo();
/* 114:102 */     if (current > startNext) {
/* 115:102 */       return false;
/* 116:    */     }
/* 117:104 */     while (current < startNext)
/* 118:    */     {
/* 119:105 */       Integer idx = (Integer)this.lutByOffset.get(Integer.valueOf(current));
/* 120:106 */       if (idx == null) {
/* 121:106 */         return false;
/* 122:    */       }
/* 123:107 */       Op01WithProcessedDataAndByteJumps op = (Op01WithProcessedDataAndByteJumps)this.instrs.get(idx.intValue());
/* 124:108 */       JVMInstr instr = op.getJVMInstr();
/* 125:109 */       if (instr.isNoThrow()) {
/* 126:110 */         current += op.getInstructionLength();
/* 127:111 */       } else if (this.aggressivePrune) {
/* 128:112 */         switch (4.$SwitchMap$org$benf$cfr$reader$bytecode$opcode$JVMInstr[instr.ordinal()])
/* 129:    */         {
/* 130:    */         case 1: 
/* 131:116 */           current += op.getInstructionLength();
/* 132:117 */           break;
/* 133:    */         default: 
/* 134:119 */           return false;
/* 135:    */         }
/* 136:    */       } else {
/* 137:122 */         return false;
/* 138:    */       }
/* 139:    */     }
/* 140:125 */     return true;
/* 141:    */   }
/* 142:    */   
/* 143:    */   private static int canExpandTryBy(int idx, List<Op01WithProcessedDataAndByteJumps> statements)
/* 144:    */   {
/* 145:131 */     Op01WithProcessedDataAndByteJumps op = (Op01WithProcessedDataAndByteJumps)statements.get(idx);
/* 146:132 */     JVMInstr instr = op.getJVMInstr();
/* 147:133 */     switch (4.$SwitchMap$org$benf$cfr$reader$bytecode$opcode$JVMInstr[instr.ordinal()])
/* 148:    */     {
/* 149:    */     case 2: 
/* 150:    */     case 3: 
/* 151:    */     case 4: 
/* 152:    */     case 5: 
/* 153:    */     case 6: 
/* 154:    */     case 7: 
/* 155:    */     case 8: 
/* 156:    */     case 9: 
/* 157:142 */       return op.getInstructionLength();
/* 158:    */     case 10: 
/* 159:    */     case 11: 
/* 160:    */     case 12: 
/* 161:    */     case 13: 
/* 162:    */     case 14: 
/* 163:149 */       Op01WithProcessedDataAndByteJumps op2 = (Op01WithProcessedDataAndByteJumps)statements.get(idx + 1);
/* 164:150 */       if (op2.getJVMInstr() == JVMInstr.MONITOREXIT) {
/* 165:151 */         return op.getInstructionLength() + op2.getInstructionLength();
/* 166:    */       }
/* 167:    */       break;
/* 168:    */     }
/* 169:155 */     return 0;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public ExceptionAggregator(List<ExceptionTableEntry> rawExceptions, BlockIdentifierFactory blockIdentifierFactory, Map<Integer, Integer> lutByOffset, Map<Integer, Integer> lutByIdx, List<Op01WithProcessedDataAndByteJumps> instrs, Options options, ConstantPool cp, Method method)
/* 173:    */   {
/* 174:170 */     this.method = method;
/* 175:171 */     this.lutByIdx = lutByIdx;
/* 176:172 */     this.lutByOffset = lutByOffset;
/* 177:173 */     this.instrs = instrs;
/* 178:174 */     this.options = options;
/* 179:175 */     this.aggressivePrune = (options.getOption(OptionsImpl.FORCE_PRUNE_EXCEPTIONS) == Troolean.TRUE);
/* 180:176 */     this.aggressiveAggregate = (options.getOption(OptionsImpl.FORCE_AGGRESSIVE_EXCEPTION_AGG) == Troolean.TRUE);
/* 181:    */     
/* 182:178 */     List<ExceptionTableEntry> tmpExceptions = Functional.filter(rawExceptions, new ValidException(null));
/* 183:179 */     boolean removedLoopingExceptions = false;
/* 184:180 */     if (tmpExceptions.size() != rawExceptions.size())
/* 185:    */     {
/* 186:181 */       rawExceptions = tmpExceptions;
/* 187:182 */       removedLoopingExceptions = true;
/* 188:    */     }
/* 189:184 */     this.removedLoopingExceptions = removedLoopingExceptions;
/* 190:185 */     if (rawExceptions.isEmpty()) {
/* 191:185 */       return;
/* 192:    */     }
/* 193:199 */     List<ExceptionTableEntry> extended = ListFactory.newList();
/* 194:200 */     for (ExceptionTableEntry exceptionTableEntry : rawExceptions)
/* 195:    */     {
/* 196:202 */       ExceptionTableEntry exceptionTableEntryOrig = exceptionTableEntry;
/* 197:    */       
/* 198:204 */       int indexTo = exceptionTableEntry.getBytecodeIndexTo();
/* 199:    */       do
/* 200:    */       {
/* 201:207 */         exceptionTableEntryOrig = exceptionTableEntry;
/* 202:208 */         Integer tgtIdx = (Integer)lutByOffset.get(Integer.valueOf(indexTo));
/* 203:209 */         if (tgtIdx != null)
/* 204:    */         {
/* 205:212 */           int offset = canExpandTryBy(tgtIdx.intValue(), instrs);
/* 206:213 */           if (offset != 0) {
/* 207:214 */             exceptionTableEntry = exceptionTableEntry.copyWithRange(exceptionTableEntry.getBytecodeIndexFrom(), (short)(exceptionTableEntry.getBytecodeIndexTo() + offset));
/* 208:    */           }
/* 209:217 */           indexTo += offset;
/* 210:    */         }
/* 211:220 */       } while (exceptionTableEntry != exceptionTableEntryOrig);
/* 212:226 */       int handlerIndex = exceptionTableEntry.getBytecodeIndexHandler();
/* 213:227 */       indexTo = exceptionTableEntry.getBytecodeIndexTo();
/* 214:228 */       int indexFrom = exceptionTableEntry.getBytecodeIndexFrom();
/* 215:229 */       if ((indexFrom < handlerIndex) && (indexTo >= handlerIndex)) {
/* 216:231 */         exceptionTableEntry = exceptionTableEntry.copyWithRange((short)indexFrom, (short)handlerIndex);
/* 217:    */       }
/* 218:233 */       extended.add(exceptionTableEntry);
/* 219:    */     }
/* 220:235 */     rawExceptions = extended;
/* 221:    */     
/* 222:    */ 
/* 223:    */ 
/* 224:    */ 
/* 225:    */ 
/* 226:    */ 
/* 227:    */ 
/* 228:243 */     Map<Short, List<ExceptionTableEntry>> grouped = Functional.groupToMapBy(rawExceptions, new UnaryFunction()
/* 229:    */     {
/* 230:    */       public Short invoke(ExceptionTableEntry arg)
/* 231:    */       {
/* 232:246 */         return Short.valueOf(arg.getCatchType());
/* 233:    */       }
/* 234:249 */     });
/* 235:250 */     List<ExceptionTableEntry> processedExceptions = ListFactory.newList(rawExceptions.size());
/* 236:251 */     for (List<ExceptionTableEntry> list : grouped.values())
/* 237:    */     {
/* 238:252 */       intervalCount = new IntervalCount();
/* 239:253 */       for (ExceptionTableEntry e : list)
/* 240:    */       {
/* 241:254 */         short from = e.getBytecodeIndexFrom();
/* 242:255 */         short to = e.getBytecodeIndexTo();
/* 243:256 */         Pair<Short, Short> res = intervalCount.generateNonIntersection(Short.valueOf(from), Short.valueOf(to));
/* 244:257 */         if (res != null) {
/* 245:258 */           processedExceptions.add(new ExceptionTableEntry(((Short)res.getFirst()).shortValue(), ((Short)res.getSecond()).shortValue(), e.getBytecodeIndexHandler(), e.getCatchType(), e.getPriority()));
/* 246:    */         }
/* 247:    */       }
/* 248:    */     }
/* 249:    */     IntervalCount intervalCount;
/* 250:265 */     Collection<ByTarget> byTargetList = Functional.groupBy(processedExceptions, new Comparator()
/* 251:    */     
/* 252:    */ 
/* 253:    */ 
/* 254:    */ 
/* 255:270 */       new UnaryFunction
/* 256:    */       {
/* 257:    */         public int compare(ExceptionTableEntry exceptionTableEntry, ExceptionTableEntry exceptionTableEntry1)
/* 258:    */         {
/* 259:268 */           int hd = exceptionTableEntry.getBytecodeIndexHandler() - exceptionTableEntry1.getBytecodeIndexHandler();
/* 260:269 */           if (hd != 0) {
/* 261:269 */             return hd;
/* 262:    */           }
/* 263:270 */           return exceptionTableEntry.getCatchType() - exceptionTableEntry1.getCatchType();
/* 264:    */         }
/* 265:270 */       }, new UnaryFunction()
/* 266:    */       {
/* 267:    */         public ExceptionAggregator.ByTarget invoke(List<ExceptionTableEntry> arg)
/* 268:    */         {
/* 269:275 */           return new ExceptionAggregator.ByTarget(ExceptionAggregator.this, arg);
/* 270:    */         }
/* 271:279 */       });
/* 272:280 */     rawExceptions = ListFactory.newList();
/* 273:    */     
/* 274:    */ 
/* 275:    */ 
/* 276:    */ 
/* 277:    */ 
/* 278:    */ 
/* 279:    */ 
/* 280:    */ 
/* 281:    */ 
/* 282:    */ 
/* 283:    */ 
/* 284:    */ 
/* 285:    */ 
/* 286:    */ 
/* 287:    */ 
/* 288:    */ 
/* 289:297 */     Map<Short, ByTarget> byTargetMap = MapFactory.newMap();
/* 290:298 */     for (ByTarget t : byTargetList) {
/* 291:299 */       byTargetMap.put(Short.valueOf(((ExceptionTableEntry)t.entries.get(0)).getBytecodeIndexHandler()), t);
/* 292:    */     }
/* 293:331 */     for (ByTarget byTarget : byTargetList) {
/* 294:332 */       rawExceptions.addAll(byTarget.getAggregated());
/* 295:    */     }
/* 296:339 */     IntervalOverlapper intervalOverlapper = new IntervalOverlapper(rawExceptions);
/* 297:340 */     rawExceptions = intervalOverlapper.getExceptions();
/* 298:    */     
/* 299:342 */     Collections.sort(rawExceptions);
/* 300:    */     
/* 301:344 */     CompareExceptionTablesByRange compareExceptionTablesByStart = new CompareExceptionTablesByRange(null);
/* 302:345 */     ExceptionTableEntry prev = null;
/* 303:346 */     ExceptionGroup currentGroup = null;
/* 304:347 */     List<ExceptionGroup> rawExceptionsByRange = ListFactory.newList();
/* 305:348 */     for (ExceptionTableEntry e : rawExceptions)
/* 306:    */     {
/* 307:349 */       if ((prev == null) || (compareExceptionTablesByStart.compare(e, prev) != 0))
/* 308:    */       {
/* 309:350 */         currentGroup = new ExceptionGroup(e.getBytecodeIndexFrom(), blockIdentifierFactory.getNextBlockIdentifier(BlockType.TRYBLOCK), cp);
/* 310:351 */         rawExceptionsByRange.add(currentGroup);
/* 311:352 */         prev = e;
/* 312:    */       }
/* 313:354 */       currentGroup.add(e);
/* 314:    */     }
/* 315:358 */     this.exceptionsByRange.addAll(rawExceptionsByRange);
/* 316:    */   }
/* 317:    */   
/* 318:    */   public List<ExceptionGroup> getExceptionsGroups()
/* 319:    */   {
/* 320:362 */     return this.exceptionsByRange;
/* 321:    */   }
/* 322:    */   
/* 323:    */   public void removeSynchronisedHandlers(Map<Integer, Integer> lutByOffset, Map<Integer, Integer> lutByIdx, List<Op01WithProcessedDataAndByteJumps> instrs)
/* 324:    */   {
/* 325:371 */     Iterator<ExceptionGroup> groupIterator = this.exceptionsByRange.iterator();
/* 326:372 */     ExceptionGroup prev = null;
/* 327:373 */     while (groupIterator.hasNext())
/* 328:    */     {
/* 329:374 */       ExceptionGroup group = (ExceptionGroup)groupIterator.next();
/* 330:375 */       boolean prevSame = false;
/* 331:376 */       if (prev != null)
/* 332:    */       {
/* 333:377 */         List<ExceptionGroup.Entry> groupEntries = group.getEntries();
/* 334:378 */         List<ExceptionGroup.Entry> prevEntries = prev.getEntries();
/* 335:379 */         if (groupEntries.equals(prevEntries)) {
/* 336:380 */           prevSame = true;
/* 337:    */         }
/* 338:    */       }
/* 339:383 */       group.removeSynchronisedHandlers(lutByOffset, lutByIdx, instrs);
/* 340:384 */       if (group.getEntries().isEmpty()) {
/* 341:385 */         groupIterator.remove();
/* 342:    */       } else {
/* 343:387 */         prev = group;
/* 344:    */       }
/* 345:    */     }
/* 346:    */   }
/* 347:    */   
/* 348:    */   public void aggressivePruning(Map<Integer, Integer> lutByOffset, Map<Integer, Integer> lutByIdx, List<Op01WithProcessedDataAndByteJumps> instrs)
/* 349:    */   {
/* 350:423 */     Iterator<ExceptionGroup> groupIterator = this.exceptionsByRange.iterator();
/* 351:424 */     while (groupIterator.hasNext())
/* 352:    */     {
/* 353:425 */       ExceptionGroup group = (ExceptionGroup)groupIterator.next();
/* 354:426 */       List<ExceptionGroup.Entry> entries = group.getEntries();
/* 355:427 */       if (entries.size() == 1)
/* 356:    */       {
/* 357:428 */         ExceptionGroup.Entry entry = (ExceptionGroup.Entry)entries.get(0);
/* 358:429 */         int handler = entry.getBytecodeIndexHandler();
/* 359:430 */         Integer index = (Integer)lutByOffset.get(Integer.valueOf(handler));
/* 360:431 */         if (index != null)
/* 361:    */         {
/* 362:432 */           Op01WithProcessedDataAndByteJumps handlerStartInstr = (Op01WithProcessedDataAndByteJumps)instrs.get(index.intValue());
/* 363:433 */           if (handlerStartInstr.getJVMInstr() == JVMInstr.ATHROW) {
/* 364:434 */             groupIterator.remove();
/* 365:    */           }
/* 366:    */         }
/* 367:    */       }
/* 368:    */     }
/* 369:    */   }
/* 370:    */   
/* 371:    */   public boolean RemovedLoopingExceptions()
/* 372:    */   {
/* 373:441 */     return this.removedLoopingExceptions;
/* 374:    */   }
/* 375:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.exceptions.ExceptionAggregator
 * JD-Core Version:    0.7.0.1
 */