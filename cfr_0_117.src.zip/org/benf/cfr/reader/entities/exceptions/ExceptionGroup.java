/*   1:    */ package org.benf.cfr.reader.entities.exceptions;
/*   2:    */ 
/*   3:    */ import java.util.Iterator;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Map;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op01WithProcessedDataAndByteJumps;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.BlockIdentifier;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.ComparableUnderEC;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.EquivalenceConstraint;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  11:    */ import org.benf.cfr.reader.bytecode.opcode.JVMInstr;
/*  12:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  13:    */ import org.benf.cfr.reader.util.ListFactory;
/*  14:    */ import org.benf.cfr.reader.util.StringUtils;
/*  15:    */ 
/*  16:    */ public class ExceptionGroup
/*  17:    */ {
/*  18:    */   private short bytecodeIndexFrom;
/*  19:    */   private short byteCodeIndexTo;
/*  20: 22 */   private short minHandlerStart = 32767;
/*  21: 23 */   private List<Entry> entries = ListFactory.newList();
/*  22:    */   private final BlockIdentifier tryBlockIdentifier;
/*  23:    */   private final ConstantPool cp;
/*  24:    */   
/*  25:    */   public ExceptionGroup(short bytecodeIndexFrom, BlockIdentifier blockIdentifier, ConstantPool cp)
/*  26:    */   {
/*  27: 28 */     this.bytecodeIndexFrom = bytecodeIndexFrom;
/*  28: 29 */     this.tryBlockIdentifier = blockIdentifier;
/*  29: 30 */     this.cp = cp;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void add(ExceptionTableEntry entry)
/*  33:    */   {
/*  34: 34 */     if (entry.getBytecodeIndexHandler() == entry.getBytecodeIndexFrom()) {
/*  35: 34 */       return;
/*  36:    */     }
/*  37: 35 */     if (entry.getBytecodeIndexHandler() < this.minHandlerStart) {
/*  38: 35 */       this.minHandlerStart = entry.getBytecodeIndexHandler();
/*  39:    */     }
/*  40: 36 */     this.entries.add(new Entry(entry));
/*  41: 37 */     if (entry.getBytecodeIndexTo() > this.byteCodeIndexTo) {
/*  42: 37 */       this.byteCodeIndexTo = entry.getBytecodeIndexTo();
/*  43:    */     }
/*  44:    */   }
/*  45:    */   
/*  46:    */   public List<Entry> getEntries()
/*  47:    */   {
/*  48: 42 */     return this.entries;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void mutateBytecodeIndexFrom(short bytecodeIndexFrom)
/*  52:    */   {
/*  53: 46 */     this.bytecodeIndexFrom = bytecodeIndexFrom;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public short getBytecodeIndexFrom()
/*  57:    */   {
/*  58: 50 */     return this.bytecodeIndexFrom;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public short getByteCodeIndexTo()
/*  62:    */   {
/*  63: 54 */     return this.byteCodeIndexTo;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public BlockIdentifier getTryBlockIdentifier()
/*  67:    */   {
/*  68: 58 */     return this.tryBlockIdentifier;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void removeSynchronisedHandlers(Map<Integer, Integer> lutByOffset, Map<Integer, Integer> lutByIdx, List<Op01WithProcessedDataAndByteJumps> instrs)
/*  72:    */   {
/*  73: 64 */     Iterator<Entry> entryIterator = this.entries.iterator();
/*  74: 65 */     while (entryIterator.hasNext())
/*  75:    */     {
/*  76: 66 */       Entry entry = (Entry)entryIterator.next();
/*  77: 67 */       if (isSynchronisedHandler(entry, lutByOffset, lutByIdx, instrs)) {
/*  78: 67 */         entryIterator.remove();
/*  79:    */       }
/*  80:    */     }
/*  81:    */   }
/*  82:    */   
/*  83:    */   private boolean isSynchronisedHandler(Entry entry, Map<Integer, Integer> lutByOffset, Map<Integer, Integer> lutByIdx, List<Op01WithProcessedDataAndByteJumps> instrs)
/*  84:    */   {
/*  85: 78 */     ExceptionTableEntry tableEntry = entry.entry;
/*  86:    */     
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90: 83 */     Integer offset = (Integer)lutByOffset.get(Integer.valueOf(tableEntry.getBytecodeIndexHandler()));
/*  91: 84 */     if (offset == null) {
/*  92: 84 */       return false;
/*  93:    */     }
/*  94: 86 */     int idx = offset.intValue();
/*  95: 87 */     if (idx >= instrs.size()) {
/*  96: 87 */       return false;
/*  97:    */     }
/*  98: 89 */     Op01WithProcessedDataAndByteJumps start = (Op01WithProcessedDataAndByteJumps)instrs.get(idx);
/*  99: 90 */     Integer catchStore = start.getAStoreIdx();
/* 100: 91 */     if (catchStore == null) {
/* 101: 91 */       return false;
/* 102:    */     }
/* 103: 92 */     idx++;
/* 104: 93 */     int nUnlocks = 0;
/* 105:    */     for (;;)
/* 106:    */     {
/* 107: 95 */       if (idx + 1 >= instrs.size()) {
/* 108: 95 */         return false;
/* 109:    */       }
/* 110: 96 */       Op01WithProcessedDataAndByteJumps load = (Op01WithProcessedDataAndByteJumps)instrs.get(idx);
/* 111: 97 */       Integer loadIdx = load.getALoadIdx();
/* 112: 98 */       if (loadIdx == null)
/* 113:    */       {
/* 114:100 */         JVMInstr instr = load.getJVMInstr();
/* 115:101 */         if (instr != JVMInstr.LDC) {
/* 116:    */           break;
/* 117:    */         }
/* 118:    */       }
/* 119:106 */       Op01WithProcessedDataAndByteJumps next = (Op01WithProcessedDataAndByteJumps)instrs.get(idx + 1);
/* 120:107 */       if (next.getJVMInstr() != JVMInstr.MONITOREXIT) {
/* 121:    */         break;
/* 122:    */       }
/* 123:108 */       nUnlocks++;
/* 124:109 */       idx += 2;
/* 125:    */     }
/* 126:111 */     if (nUnlocks == 0) {
/* 127:111 */       return false;
/* 128:    */     }
/* 129:112 */     Integer catchLoad = ((Op01WithProcessedDataAndByteJumps)instrs.get(idx)).getALoadIdx();
/* 130:113 */     if (!catchStore.equals(catchLoad)) {
/* 131:113 */       return false;
/* 132:    */     }
/* 133:114 */     idx++;
/* 134:115 */     if (((Op01WithProcessedDataAndByteJumps)instrs.get(idx)).getJVMInstr() != JVMInstr.ATHROW) {
/* 135:115 */       return false;
/* 136:    */     }
/* 137:116 */     return true;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public String toString()
/* 141:    */   {
/* 142:121 */     StringBuilder sb = new StringBuilder();
/* 143:122 */     sb.append("[egrp ").append(this.tryBlockIdentifier).append(" [");
/* 144:123 */     boolean bfirst = true;
/* 145:124 */     for (Entry e : this.entries)
/* 146:    */     {
/* 147:125 */       bfirst = StringUtils.comma(bfirst, sb);
/* 148:126 */       sb.append(e.getPriority());
/* 149:    */     }
/* 150:128 */     sb.append(" : ").append(this.bytecodeIndexFrom).append("->").append(this.byteCodeIndexTo).append(")]");
/* 151:129 */     return sb.toString();
/* 152:    */   }
/* 153:    */   
/* 154:    */   public class Entry
/* 155:    */     implements ComparableUnderEC
/* 156:    */   {
/* 157:    */     private final ExceptionTableEntry entry;
/* 158:    */     private final JavaRefTypeInstance refType;
/* 159:    */     
/* 160:    */     public Entry(ExceptionTableEntry entry)
/* 161:    */     {
/* 162:137 */       this.entry = entry;
/* 163:138 */       this.refType = entry.getCatchType(ExceptionGroup.this.cp);
/* 164:    */     }
/* 165:    */     
/* 166:    */     public short getBytecodeIndexTo()
/* 167:    */     {
/* 168:142 */       return this.entry.getBytecodeIndexTo();
/* 169:    */     }
/* 170:    */     
/* 171:    */     public short getBytecodeIndexHandler()
/* 172:    */     {
/* 173:146 */       return this.entry.getBytecodeIndexHandler();
/* 174:    */     }
/* 175:    */     
/* 176:    */     public boolean isJustThrowable()
/* 177:    */     {
/* 178:150 */       JavaRefTypeInstance type = this.entry.getCatchType(ExceptionGroup.this.cp);
/* 179:151 */       return type.getRawName().equals("java.lang.Throwable");
/* 180:    */     }
/* 181:    */     
/* 182:    */     public int getPriority()
/* 183:    */     {
/* 184:155 */       return this.entry.getPriority();
/* 185:    */     }
/* 186:    */     
/* 187:    */     public JavaRefTypeInstance getCatchType()
/* 188:    */     {
/* 189:159 */       return this.refType;
/* 190:    */     }
/* 191:    */     
/* 192:    */     public ExceptionGroup getExceptionGroup()
/* 193:    */     {
/* 194:163 */       return ExceptionGroup.this;
/* 195:    */     }
/* 196:    */     
/* 197:    */     public BlockIdentifier getTryBlockIdentifier()
/* 198:    */     {
/* 199:167 */       return ExceptionGroup.this.getTryBlockIdentifier();
/* 200:    */     }
/* 201:    */     
/* 202:    */     public String toString()
/* 203:    */     {
/* 204:172 */       JavaRefTypeInstance name = getCatchType();
/* 205:173 */       return ExceptionGroup.this.toString() + " " + name.getRawName();
/* 206:    */     }
/* 207:    */     
/* 208:    */     public boolean equivalentUnder(Object o, EquivalenceConstraint constraint)
/* 209:    */     {
/* 210:178 */       if (o == null) {
/* 211:178 */         return false;
/* 212:    */       }
/* 213:179 */       if (o == this) {
/* 214:179 */         return true;
/* 215:    */       }
/* 216:180 */       if (getClass() != o.getClass()) {
/* 217:180 */         return false;
/* 218:    */       }
/* 219:181 */       Entry other = (Entry)o;
/* 220:182 */       if (!constraint.equivalent(this.entry, other.entry)) {
/* 221:182 */         return false;
/* 222:    */       }
/* 223:183 */       if (!constraint.equivalent(this.refType, other.refType)) {
/* 224:183 */         return false;
/* 225:    */       }
/* 226:184 */       return true;
/* 227:    */     }
/* 228:    */     
/* 229:    */     public ExceptionGroup.ExtenderKey getExtenderKey()
/* 230:    */     {
/* 231:188 */       return new ExceptionGroup.ExtenderKey(ExceptionGroup.this, this.refType, this.entry.getBytecodeIndexHandler());
/* 232:    */     }
/* 233:    */   }
/* 234:    */   
/* 235:    */   public class ExtenderKey
/* 236:    */   {
/* 237:    */     private final JavaRefTypeInstance type;
/* 238:    */     private final short handler;
/* 239:    */     
/* 240:    */     public ExtenderKey(JavaRefTypeInstance type, short handler)
/* 241:    */     {
/* 242:199 */       this.type = type;
/* 243:200 */       this.handler = handler;
/* 244:    */     }
/* 245:    */     
/* 246:    */     public JavaRefTypeInstance getType()
/* 247:    */     {
/* 248:204 */       return this.type;
/* 249:    */     }
/* 250:    */     
/* 251:    */     public short getHandler()
/* 252:    */     {
/* 253:208 */       return this.handler;
/* 254:    */     }
/* 255:    */     
/* 256:    */     public boolean equals(Object o)
/* 257:    */     {
/* 258:213 */       if (this == o) {
/* 259:213 */         return true;
/* 260:    */       }
/* 261:214 */       if ((o == null) || (getClass() != o.getClass())) {
/* 262:214 */         return false;
/* 263:    */       }
/* 264:216 */       ExtenderKey that = (ExtenderKey)o;
/* 265:218 */       if (this.handler != that.handler) {
/* 266:218 */         return false;
/* 267:    */       }
/* 268:219 */       if (this.type != null ? !this.type.equals(that.type) : that.type != null) {
/* 269:219 */         return false;
/* 270:    */       }
/* 271:221 */       return true;
/* 272:    */     }
/* 273:    */     
/* 274:    */     public int hashCode()
/* 275:    */     {
/* 276:226 */       int result = this.type != null ? this.type.hashCode() : 0;
/* 277:227 */       result = 31 * result + this.handler;
/* 278:228 */       return result;
/* 279:    */     }
/* 280:    */   }
/* 281:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.exceptions.ExceptionGroup
 * JD-Core Version:    0.7.0.1
 */