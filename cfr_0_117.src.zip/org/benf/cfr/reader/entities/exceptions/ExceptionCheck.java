package org.benf.cfr.reader.entities.exceptions;

import java.util.Set;
import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractMemberFunctionInvokation;
import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;

public abstract interface ExceptionCheck
{
  public abstract boolean checkAgainst(Set<? extends JavaTypeInstance> paramSet);
  
  public abstract boolean checkAgainst(AbstractMemberFunctionInvokation paramAbstractMemberFunctionInvokation);
  
  public abstract boolean checkAgainstException(Expression paramExpression);
  
  public abstract boolean mightCatchUnchecked();
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.exceptions.ExceptionCheck
 * JD-Core Version:    0.7.0.1
 */