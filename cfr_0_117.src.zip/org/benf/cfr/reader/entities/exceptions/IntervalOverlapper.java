/*   1:    */ package org.benf.cfr.reader.entities.exceptions;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.NavigableMap;
/*   7:    */ import java.util.Set;
/*   8:    */ import java.util.TreeSet;
/*   9:    */ import org.benf.cfr.reader.util.ListFactory;
/*  10:    */ import org.benf.cfr.reader.util.MapFactory;
/*  11:    */ import org.benf.cfr.reader.util.SetFactory;
/*  12:    */ 
/*  13:    */ public class IntervalOverlapper
/*  14:    */ {
/*  15: 11 */   private final NavigableMap<Short, Set<ExceptionTableEntry>> starts = MapFactory.newTreeMap();
/*  16: 12 */   private final NavigableMap<Short, Set<ExceptionTableEntry>> ends = MapFactory.newTreeMap();
/*  17:    */   
/*  18:    */   public IntervalOverlapper(List<ExceptionTableEntry> entries)
/*  19:    */   {
/*  20: 17 */     processEntries(entries);
/*  21:    */   }
/*  22:    */   
/*  23:    */   private void processEntries(List<ExceptionTableEntry> entries)
/*  24:    */   {
/*  25: 21 */     for (ExceptionTableEntry e : entries) {
/*  26: 22 */       processEntry(e);
/*  27:    */     }
/*  28:    */   }
/*  29:    */   
/*  30:    */   private static <X> Set<X> raze(Collection<Set<X>> in)
/*  31:    */   {
/*  32: 27 */     Set<X> res = SetFactory.newSet();
/*  33: 28 */     for (Set<X> i : in) {
/*  34: 29 */       res.addAll(i);
/*  35:    */     }
/*  36: 31 */     return res;
/*  37:    */   }
/*  38:    */   
/*  39:    */   private void processEntry(ExceptionTableEntry e)
/*  40:    */   {
/*  41: 36 */     short from = e.getBytecodeIndexFrom();
/*  42: 37 */     short to = e.getBytecodeIndexTo();
/*  43:    */     
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47: 42 */     NavigableMap<Short, Set<ExceptionTableEntry>> startedBeforeStart = this.starts.headMap(Short.valueOf(from), false);
/*  48: 43 */     NavigableMap<Short, Set<ExceptionTableEntry>> endsBeforeEnd = this.ends.headMap(Short.valueOf(to), false);
/*  49: 44 */     NavigableMap<Short, Set<ExceptionTableEntry>> endsInside = endsBeforeEnd.tailMap(Short.valueOf(from), false);
/*  50:    */     
/*  51:    */ 
/*  52: 47 */     Set<ExceptionTableEntry> overlapStartsBefore = raze(endsInside.values());
/*  53: 48 */     overlapStartsBefore.retainAll(raze(startedBeforeStart.values()));
/*  54:    */     
/*  55: 50 */     NavigableMap<Short, Set<ExceptionTableEntry>> endsAfterEnd = this.ends.tailMap(Short.valueOf(to), false);
/*  56: 51 */     NavigableMap<Short, Set<ExceptionTableEntry>> startedAfterStart = this.starts.tailMap(Short.valueOf(from), false);
/*  57: 52 */     NavigableMap<Short, Set<ExceptionTableEntry>> startsInside = startedAfterStart.headMap(Short.valueOf(to), false);
/*  58:    */     
/*  59: 54 */     Set<ExceptionTableEntry> overlapEndsAfter = raze(startsInside.values());
/*  60: 55 */     overlapEndsAfter.retainAll(raze(endsAfterEnd.values()));
/*  61: 57 */     if ((overlapEndsAfter.isEmpty()) && (overlapStartsBefore.isEmpty()))
/*  62:    */     {
/*  63: 58 */       addEntry(e);
/*  64: 59 */       return;
/*  65:    */     }
/*  66: 64 */     short remainingBlockStart = from;
/*  67: 65 */     short remainingBlockTo = to;
/*  68: 66 */     List<ExceptionTableEntry> output = ListFactory.newList();
/*  69:    */     Set<Short> blockEnds;
/*  70:    */     short currentFrom;
/*  71:    */     Iterator i$;
/*  72: 68 */     if (!overlapStartsBefore.isEmpty())
/*  73:    */     {
/*  74: 69 */       blockEnds = new TreeSet();
/*  75: 70 */       for (ExceptionTableEntry e2 : overlapStartsBefore)
/*  76:    */       {
/*  77: 71 */         blockEnds.add(Short.valueOf(e2.getBytecodeIndexTo()));
/*  78: 72 */         ((Set)this.starts.get(Short.valueOf(e2.getBytecodeIndexFrom()))).remove(e2);
/*  79: 73 */         ((Set)this.ends.get(Short.valueOf(e2.getBytecodeIndexTo()))).remove(e2);
/*  80:    */       }
/*  81: 76 */       currentFrom = from;
/*  82: 77 */       for (Short end : blockEnds)
/*  83:    */       {
/*  84: 78 */         ExceptionTableEntry out = e.copyWithRange(currentFrom, end.shortValue());
/*  85: 79 */         addEntry(out);
/*  86: 80 */         output.add(out);
/*  87: 81 */         currentFrom = end.shortValue();
/*  88:    */       }
/*  89: 83 */       remainingBlockStart = currentFrom;
/*  90: 84 */       blockEnds.add(Short.valueOf(from));
/*  91: 85 */       for (i$ = overlapStartsBefore.iterator(); i$.hasNext();)
/*  92:    */       {
/*  93: 85 */         e2 = (ExceptionTableEntry)i$.next();
/*  94: 86 */         currentFrom = e2.getBytecodeIndexFrom();
/*  95: 87 */         for (Short end : blockEnds)
/*  96:    */         {
/*  97: 88 */           if (end.shortValue() > e2.getBytecodeIndexTo()) {
/*  98:    */             break;
/*  99:    */           }
/* 100: 89 */           ExceptionTableEntry out = e2.copyWithRange(currentFrom, end.shortValue());
/* 101: 90 */           addEntry(out);
/* 102: 91 */           output.add(out);
/* 103: 92 */           currentFrom = end.shortValue();
/* 104:    */         }
/* 105:    */       }
/* 106:    */     }
/* 107:    */     ExceptionTableEntry e2;
/* 108:    */     List<Short> revBlockStarts;
/* 109:    */     short currentTo;
/* 110: 98 */     if (!overlapEndsAfter.isEmpty())
/* 111:    */     {
/* 112: 99 */       Set<Short> blockStarts = new TreeSet();
/* 113:100 */       for (ExceptionTableEntry e2 : overlapStartsBefore)
/* 114:    */       {
/* 115:101 */         blockStarts.add(Short.valueOf(e2.getBytecodeIndexFrom()));
/* 116:102 */         ((Set)this.starts.get(Short.valueOf(e2.getBytecodeIndexFrom()))).remove(e2);
/* 117:103 */         ((Set)this.ends.get(Short.valueOf(e2.getBytecodeIndexTo()))).remove(e2);
/* 118:    */       }
/* 119:105 */       revBlockStarts = ListFactory.newList(blockStarts);
/* 120:106 */       currentTo = to;
/* 121:107 */       for (int x = revBlockStarts.size() - 1; x >= 0; x--)
/* 122:    */       {
/* 123:108 */         Short start = (Short)revBlockStarts.get(x);
/* 124:109 */         ExceptionTableEntry out = e.copyWithRange(start.shortValue(), currentTo);
/* 125:110 */         addEntry(out);
/* 126:111 */         output.add(out);
/* 127:112 */         currentTo = start.shortValue();
/* 128:    */       }
/* 129:114 */       remainingBlockTo = currentTo;
/* 130:115 */       revBlockStarts.add(Short.valueOf(to));
/* 131:116 */       for (ExceptionTableEntry e2 : overlapStartsBefore)
/* 132:    */       {
/* 133:117 */         currentTo = e2.getBytecodeIndexTo();
/* 134:118 */         for (int x = revBlockStarts.size() - 1; x >= 0; x--)
/* 135:    */         {
/* 136:119 */           Short start = (Short)revBlockStarts.get(x);
/* 137:120 */           if (start.shortValue() <= e2.getBytecodeIndexFrom()) {
/* 138:    */             break;
/* 139:    */           }
/* 140:121 */           ExceptionTableEntry out = e.copyWithRange(start.shortValue(), currentTo);
/* 141:122 */           addEntry(out);
/* 142:123 */           output.add(out);
/* 143:124 */           currentTo = start.shortValue();
/* 144:    */         }
/* 145:    */       }
/* 146:    */     }
/* 147:129 */     ExceptionTableEntry out = e.copyWithRange(remainingBlockStart, remainingBlockTo);
/* 148:130 */     addEntry(out);
/* 149:131 */     output.add(out);
/* 150:    */   }
/* 151:    */   
/* 152:    */   void addEntry(ExceptionTableEntry e)
/* 153:    */   {
/* 154:135 */     add(this.starts, Short.valueOf(e.getBytecodeIndexFrom()), e);
/* 155:136 */     add(this.ends, Short.valueOf(e.getBytecodeIndexTo()), e);
/* 156:    */   }
/* 157:    */   
/* 158:    */   <A, B> void add(NavigableMap<A, Set<B>> m, A k, B v)
/* 159:    */   {
/* 160:140 */     Set<B> b = (Set)m.get(k);
/* 161:141 */     if (b == null)
/* 162:    */     {
/* 163:142 */       b = SetFactory.newSet();
/* 164:143 */       m.put(k, b);
/* 165:    */     }
/* 166:145 */     b.add(v);
/* 167:    */   }
/* 168:    */   
/* 169:    */   public List<ExceptionTableEntry> getExceptions()
/* 170:    */   {
/* 171:149 */     return ListFactory.newList(raze(this.starts.values()));
/* 172:    */   }
/* 173:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.exceptions.IntervalOverlapper
 * JD-Core Version:    0.7.0.1
 */