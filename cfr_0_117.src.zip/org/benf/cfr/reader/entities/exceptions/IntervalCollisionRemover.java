/*  1:   */ package org.benf.cfr.reader.entities.exceptions;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Map.Entry;
/*  5:   */ import java.util.TreeMap;
/*  6:   */ import org.benf.cfr.reader.util.ListFactory;
/*  7:   */ 
/*  8:   */ public class IntervalCollisionRemover
/*  9:   */ {
/* 10:17 */   private final TreeMap<Integer, Boolean> covered = new TreeMap();
/* 11:   */   
/* 12:   */   public List<ClosedIdxExceptionEntry> removeIllegals(ClosedIdxExceptionEntry e)
/* 13:   */   {
/* 14:20 */     List<ClosedIdxExceptionEntry> res = ListFactory.newList();
/* 15:   */     
/* 16:22 */     int start = e.getStart();
/* 17:23 */     int end = e.getEnd();
/* 18:   */     for (;;)
/* 19:   */     {
/* 20:26 */       Map.Entry<Integer, Boolean> before = this.covered.floorEntry(Integer.valueOf(start));
/* 21:27 */       if ((before == null) || (!((Boolean)before.getValue()).booleanValue()))
/* 22:   */       {
/* 23:28 */         if ((before == null) || (((Integer)before.getKey()).intValue() < start)) {
/* 24:30 */           this.covered.put(Integer.valueOf(start), Boolean.valueOf(true));
/* 25:   */         } else {
/* 26:33 */           this.covered.remove(Integer.valueOf(start));
/* 27:   */         }
/* 28:37 */         Map.Entry<Integer, Boolean> nextStart = this.covered.ceilingEntry(Integer.valueOf(start + 1));
/* 29:38 */         if ((nextStart == null) || (((Integer)nextStart.getKey()).intValue() > end))
/* 30:   */         {
/* 31:39 */           this.covered.put(Integer.valueOf(end + 1), Boolean.valueOf(false));
/* 32:40 */           res.add(e.withRange(start, end));
/* 33:41 */           return res;
/* 34:   */         }
/* 35:45 */         this.covered.remove(nextStart.getKey());
/* 36:46 */         res.add(e.withRange(start, ((Integer)nextStart.getKey()).intValue() - 1));
/* 37:47 */         start = ((Integer)nextStart.getKey()).intValue();
/* 38:   */       }
/* 39:   */       else
/* 40:   */       {
/* 41:50 */         if (((Integer)before.getKey()).equals(Integer.valueOf(start))) {
/* 42:50 */           start++;
/* 43:   */         }
/* 44:52 */         Map.Entry<Integer, Boolean> nextEnd = this.covered.ceilingEntry(Integer.valueOf(start));
/* 45:53 */         int nextEndIdx = ((Integer)nextEnd.getKey()).intValue();
/* 46:54 */         if (((Boolean)nextEnd.getValue()).booleanValue()) {
/* 47:54 */           throw new IllegalStateException();
/* 48:   */         }
/* 49:56 */         if (nextEndIdx > end) {
/* 50:56 */           return res;
/* 51:   */         }
/* 52:57 */         start = nextEndIdx;
/* 53:   */       }
/* 54:   */     }
/* 55:   */   }
/* 56:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.exceptions.IntervalCollisionRemover
 * JD-Core Version:    0.7.0.1
 */