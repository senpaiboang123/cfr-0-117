/*  1:   */ package org.benf.cfr.reader.entities.exceptions;
/*  2:   */ 
/*  3:   */ import java.util.Map;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  5:   */ 
/*  6:   */ public class ClosedIdxExceptionEntry
/*  7:   */ {
/*  8:   */   private final int start;
/*  9:   */   private final int end;
/* 10:   */   private final int handler;
/* 11:   */   private final short catchType;
/* 12:   */   private final int priority;
/* 13:   */   private final JavaRefTypeInstance catchRefType;
/* 14:   */   
/* 15:   */   public ClosedIdxExceptionEntry(int start, int end, int handler, short catchType, int priority, JavaRefTypeInstance catchRefType)
/* 16:   */   {
/* 17:25 */     this.start = start;
/* 18:26 */     this.end = end;
/* 19:27 */     this.handler = handler;
/* 20:28 */     this.catchType = catchType;
/* 21:29 */     this.priority = priority;
/* 22:30 */     this.catchRefType = catchRefType;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public int getStart()
/* 26:   */   {
/* 27:34 */     return this.start;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public int getEnd()
/* 31:   */   {
/* 32:38 */     return this.end;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public int getHandler()
/* 36:   */   {
/* 37:42 */     return this.handler;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public short getCatchType()
/* 41:   */   {
/* 42:46 */     return this.catchType;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public int getPriority()
/* 46:   */   {
/* 47:50 */     return this.priority;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public JavaRefTypeInstance getCatchRefType()
/* 51:   */   {
/* 52:54 */     return this.catchRefType;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public ClosedIdxExceptionEntry withRange(int newStart, int newEnd)
/* 56:   */   {
/* 57:58 */     if ((this.start == newStart) && (this.end == newEnd)) {
/* 58:58 */       return this;
/* 59:   */     }
/* 60:59 */     return new ClosedIdxExceptionEntry(newStart, newEnd, this.handler, this.catchType, this.priority, this.catchRefType);
/* 61:   */   }
/* 62:   */   
/* 63:   */   public ExceptionTableEntry convertToRaw(Map<Integer, Integer> offsetByIdx)
/* 64:   */   {
/* 65:69 */     return new ExceptionTableEntry((short)((Integer)offsetByIdx.get(Integer.valueOf(this.start))).intValue(), (short)((Integer)offsetByIdx.get(Integer.valueOf(this.end + 1))).intValue(), (short)((Integer)offsetByIdx.get(Integer.valueOf(this.handler))).intValue(), this.catchType, this.priority);
/* 66:   */   }
/* 67:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.exceptions.ClosedIdxExceptionEntry
 * JD-Core Version:    0.7.0.1
 */