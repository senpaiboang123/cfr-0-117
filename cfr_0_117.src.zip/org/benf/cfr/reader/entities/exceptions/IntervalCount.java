/*  1:   */ package org.benf.cfr.reader.entities.exceptions;
/*  2:   */ 
/*  3:   */ import java.util.Iterator;
/*  4:   */ import java.util.Map.Entry;
/*  5:   */ import java.util.NavigableMap;
/*  6:   */ import java.util.Set;
/*  7:   */ import java.util.TreeMap;
/*  8:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  9:   */ import org.benf.cfr.reader.util.MapFactory;
/* 10:   */ 
/* 11:   */ public class IntervalCount
/* 12:   */ {
/* 13:10 */   private final TreeMap<Short, Boolean> op = MapFactory.newTreeMap();
/* 14:   */   
/* 15:   */   public Pair<Short, Short> generateNonIntersection(Short from, Short to)
/* 16:   */   {
/* 17:16 */     if (to.shortValue() < from.shortValue()) {
/* 18:16 */       return null;
/* 19:   */     }
/* 20:18 */     Map.Entry<Short, Boolean> prevEntry = this.op.floorEntry(from);
/* 21:19 */     Boolean previous = prevEntry == null ? null : (Boolean)prevEntry.getValue();
/* 22:20 */     boolean braOutside = (previous == null) || (!previous.booleanValue());
/* 23:22 */     if (braOutside)
/* 24:   */     {
/* 25:23 */       this.op.put(from, Boolean.valueOf(true));
/* 26:   */     }
/* 27:   */     else
/* 28:   */     {
/* 29:25 */       from = (Short)prevEntry.getKey();
/* 30:   */       
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:30 */       Map.Entry<Short, Boolean> nextEntry = this.op.ceilingEntry(Short.valueOf((short)(from.shortValue() + 1)));
/* 35:31 */       if (nextEntry == null) {
/* 36:32 */         throw new IllegalStateException("Internal exception pattern invalid");
/* 37:   */       }
/* 38:34 */       if ((!((Boolean)nextEntry.getValue()).booleanValue()) && 
/* 39:35 */         (((Short)nextEntry.getKey()).shortValue() >= to.shortValue())) {
/* 40:37 */         return null;
/* 41:   */       }
/* 42:   */     }
/* 43:42 */     NavigableMap<Short, Boolean> afterMap = this.op.tailMap(from, false);
/* 44:   */     
/* 45:44 */     Set<Map.Entry<Short, Boolean>> afterSet = afterMap.entrySet();
/* 46:45 */     Iterator<Map.Entry<Short, Boolean>> afterIter = afterSet.iterator();
/* 47:46 */     while (afterIter.hasNext())
/* 48:   */     {
/* 49:47 */       Map.Entry<Short, Boolean> next = (Map.Entry)afterIter.next();
/* 50:48 */       Short end = (Short)next.getKey();
/* 51:49 */       boolean isKet = Boolean.FALSE == next.getValue();
/* 52:50 */       if (end.shortValue() > to.shortValue())
/* 53:   */       {
/* 54:51 */         if (isKet) {
/* 55:53 */           return Pair.make(from, end);
/* 56:   */         }
/* 57:56 */         this.op.put(to, Boolean.valueOf(false));
/* 58:57 */         return Pair.make(from, to);
/* 59:   */       }
/* 60:58 */       if (end.equals(to))
/* 61:   */       {
/* 62:59 */         if (isKet) {
/* 63:61 */           return Pair.make(from, end);
/* 64:   */         }
/* 65:64 */         afterIter.remove();
/* 66:65 */         return Pair.make(from, to);
/* 67:   */       }
/* 68:71 */       afterIter.remove();
/* 69:   */     }
/* 70:74 */     this.op.put(to, Boolean.valueOf(false));
/* 71:75 */     return Pair.make(from, to);
/* 72:   */   }
/* 73:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.exceptions.IntervalCount
 * JD-Core Version:    0.7.0.1
 */