/*  1:   */ package org.benf.cfr.reader.entities;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.Collections;
/*  5:   */ import java.util.List;
/*  6:   */ import org.benf.cfr.reader.entities.attributes.AttributeCode;
/*  7:   */ import org.benf.cfr.reader.entities.attributes.AttributeLineNumberTable;
/*  8:   */ 
/*  9:   */ public class MethodOrdering
/* 10:   */ {
/* 11:   */   private static class OrderData
/* 12:   */     implements Comparable<OrderData>
/* 13:   */   {
/* 14:   */     private final Method method;
/* 15:   */     private final boolean hasLineNumber;
/* 16:   */     private final int origIdx;
/* 17:   */     
/* 18:   */     private OrderData(Method method, boolean hasLineNumber, int origIdx)
/* 19:   */     {
/* 20:22 */       this.method = method;
/* 21:23 */       this.hasLineNumber = hasLineNumber;
/* 22:24 */       this.origIdx = origIdx;
/* 23:   */     }
/* 24:   */     
/* 25:   */     public int compareTo(OrderData o)
/* 26:   */     {
/* 27:29 */       if (this.hasLineNumber != o.hasLineNumber) {
/* 28:30 */         return this.hasLineNumber ? -1 : 1;
/* 29:   */       }
/* 30:32 */       return this.origIdx - o.origIdx;
/* 31:   */     }
/* 32:   */   }
/* 33:   */   
/* 34:   */   public static List<Method> sort(List<Method> methods)
/* 35:   */   {
/* 36:37 */     List<OrderData> od = new ArrayList();
/* 37:38 */     boolean hasLineNumbers = false;
/* 38:39 */     int x = 0;
/* 39:39 */     for (int len = methods.size(); x < len; x++)
/* 40:   */     {
/* 41:40 */       Method method = (Method)methods.get(x);
/* 42:41 */       boolean hasLineNumber = false;
/* 43:42 */       int idx = x;
/* 44:43 */       AttributeCode codeAttribute = method.getCodeAttribute();
/* 45:44 */       if (codeAttribute != null)
/* 46:   */       {
/* 47:45 */         AttributeLineNumberTable lineNumberTable = codeAttribute.getLineNumberTable();
/* 48:46 */         if ((lineNumberTable != null) && (lineNumberTable.hasEntries()))
/* 49:   */         {
/* 50:47 */           hasLineNumber = true;
/* 51:48 */           hasLineNumbers = true;
/* 52:49 */           idx = lineNumberTable.getStartLine();
/* 53:   */         }
/* 54:   */       }
/* 55:52 */       od.add(new OrderData(method, hasLineNumber, idx, null));
/* 56:   */     }
/* 57:54 */     if (!hasLineNumbers) {
/* 58:54 */       return methods;
/* 59:   */     }
/* 60:55 */     Collections.sort(od);
/* 61:56 */     List<Method> res = new ArrayList(methods.size());
/* 62:57 */     for (OrderData o : od) {
/* 63:58 */       res.add(o.method);
/* 64:   */     }
/* 65:60 */     return res;
/* 66:   */   }
/* 67:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.MethodOrdering
 * JD-Core Version:    0.7.0.1
 */