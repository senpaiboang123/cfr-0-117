/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  4:   */ import org.benf.cfr.reader.entities.annotations.ElementValue;
/*  5:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  6:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  7:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  8:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  9:   */ 
/* 10:   */ public class AttributeAnnotationDefault
/* 11:   */   extends Attribute
/* 12:   */ {
/* 13:   */   public static final String ATTRIBUTE_NAME = "AnnotationDefault";
/* 14:   */   private static final long OFFSET_OF_ATTRIBUTE_LENGTH = 2L;
/* 15:   */   private static final long OFFSET_OF_REMAINDER = 6L;
/* 16:   */   private final int length;
/* 17:   */   private final ElementValue elementValue;
/* 18:   */   
/* 19:   */   public AttributeAnnotationDefault(ByteData raw, ConstantPool cp)
/* 20:   */   {
/* 21:21 */     this.length = raw.getS4At(2L);
/* 22:22 */     Pair<Long, ElementValue> tmp = AnnotationHelpers.getElementValue(raw, 6L, cp);
/* 23:23 */     this.elementValue = ((ElementValue)tmp.getSecond());
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getRawName()
/* 27:   */   {
/* 28:28 */     return "AnnotationDefault";
/* 29:   */   }
/* 30:   */   
/* 31:   */   public Dumper dump(Dumper d)
/* 32:   */   {
/* 33:33 */     return this.elementValue.dump(d);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public long getRawByteLength()
/* 37:   */   {
/* 38:38 */     return 6L + this.length;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public String toString()
/* 42:   */   {
/* 43:43 */     return "Annotationdefault : " + this.elementValue;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public ElementValue getElementValue()
/* 47:   */   {
/* 48:47 */     return this.elementValue;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 52:   */   {
/* 53:52 */     this.elementValue.collectTypeUsages(collector);
/* 54:   */   }
/* 55:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AttributeAnnotationDefault
 * JD-Core Version:    0.7.0.1
 */