/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  4:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  5:   */ 
/*  6:   */ public class AttributeRuntimeVisibleParameterAnnotations
/*  7:   */   extends AttributeParameterAnnotations
/*  8:   */ {
/*  9:   */   public static final String ATTRIBUTE_NAME = "RuntimeVisibleParameterAnnotations";
/* 10:   */   
/* 11:   */   public AttributeRuntimeVisibleParameterAnnotations(ByteData raw, ConstantPool cp)
/* 12:   */   {
/* 13:10 */     super(raw, cp);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public String getRawName()
/* 17:   */   {
/* 18:15 */     return "RuntimeVisibleParameterAnnotations";
/* 19:   */   }
/* 20:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AttributeRuntimeVisibleParameterAnnotations
 * JD-Core Version:    0.7.0.1
 */