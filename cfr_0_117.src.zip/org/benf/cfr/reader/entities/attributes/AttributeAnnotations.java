/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  6:   */ import org.benf.cfr.reader.entities.annotations.AnnotationTableEntry;
/*  7:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  8:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  9:   */ import org.benf.cfr.reader.util.Functional;
/* 10:   */ import org.benf.cfr.reader.util.ListFactory;
/* 11:   */ import org.benf.cfr.reader.util.Predicate;
/* 12:   */ import org.benf.cfr.reader.util.TypeUsageCollectable;
/* 13:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/* 14:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 15:   */ 
/* 16:   */ public abstract class AttributeAnnotations
/* 17:   */   extends Attribute
/* 18:   */   implements TypeUsageCollectable
/* 19:   */ {
/* 20:   */   private static final long OFFSET_OF_ATTRIBUTE_LENGTH = 2L;
/* 21:   */   private static final long OFFSET_OF_REMAINDER = 6L;
/* 22:   */   private static final long OFFSET_OF_NUMBER_OF_ANNOTATIONS = 6L;
/* 23:   */   private static final long OFFSET_OF_ANNOTATION_TABLE = 8L;
/* 24:24 */   private final List<AnnotationTableEntry> annotationTableEntryList = ListFactory.newList();
/* 25:   */   private final int length;
/* 26:   */   
/* 27:   */   public AttributeAnnotations(ByteData raw, ConstantPool cp)
/* 28:   */   {
/* 29:29 */     this.length = raw.getS4At(2L);
/* 30:30 */     short numAnnotations = raw.getS2At(6L);
/* 31:31 */     long offset = 8L;
/* 32:32 */     for (int x = 0; x < numAnnotations; x++)
/* 33:   */     {
/* 34:33 */       Pair<Long, AnnotationTableEntry> ape = AnnotationHelpers.getAnnotation(raw, offset, cp);
/* 35:34 */       offset = ((Long)ape.getFirst()).longValue();
/* 36:35 */       this.annotationTableEntryList.add(ape.getSecond());
/* 37:   */     }
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void hide(final JavaTypeInstance type)
/* 41:   */   {
/* 42:40 */     List<AnnotationTableEntry> hideThese = Functional.filter(this.annotationTableEntryList, new Predicate()
/* 43:   */     {
/* 44:   */       public boolean test(AnnotationTableEntry in)
/* 45:   */       {
/* 46:43 */         return in.getClazz().equals(type);
/* 47:   */       }
/* 48:   */     });
/* 49:46 */     for (AnnotationTableEntry hide : hideThese) {
/* 50:47 */       hide.setHidden();
/* 51:   */     }
/* 52:   */   }
/* 53:   */   
/* 54:   */   public Dumper dump(Dumper d)
/* 55:   */   {
/* 56:53 */     for (AnnotationTableEntry annotationTableEntry : this.annotationTableEntryList) {
/* 57:54 */       if (!annotationTableEntry.isHidden())
/* 58:   */       {
/* 59:55 */         annotationTableEntry.dump(d);
/* 60:56 */         d.newln();
/* 61:   */       }
/* 62:   */     }
/* 63:59 */     return d;
/* 64:   */   }
/* 65:   */   
/* 66:   */   public long getRawByteLength()
/* 67:   */   {
/* 68:64 */     return 6L + this.length;
/* 69:   */   }
/* 70:   */   
/* 71:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 72:   */   {
/* 73:69 */     for (AnnotationTableEntry annotationTableEntry : this.annotationTableEntryList) {
/* 74:70 */       annotationTableEntry.collectTypeUsages(collector);
/* 75:   */     }
/* 76:   */   }
/* 77:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AttributeAnnotations
 * JD-Core Version:    0.7.0.1
 */