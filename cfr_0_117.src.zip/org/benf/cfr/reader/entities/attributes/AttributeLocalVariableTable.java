/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  5:   */ import org.benf.cfr.reader.util.ListFactory;
/*  6:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  7:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  8:   */ 
/*  9:   */ public class AttributeLocalVariableTable
/* 10:   */   extends Attribute
/* 11:   */ {
/* 12:   */   public static final String ATTRIBUTE_NAME = "LocalVariableTable";
/* 13:   */   private static final long OFFSET_OF_ATTRIBUTE_LENGTH = 2L;
/* 14:   */   private static final long OFFSET_OF_ENTRY_COUNT = 6L;
/* 15:   */   private static final long OFFSET_OF_ENTRIES = 8L;
/* 16:   */   private static final long OFFSET_OF_REMAINDER = 6L;
/* 17:17 */   private final List<LocalVariableEntry> localVariableEntryList = ListFactory.newList();
/* 18:   */   private final int length;
/* 19:   */   
/* 20:   */   public AttributeLocalVariableTable(ByteData raw, ConstantPool cp)
/* 21:   */   {
/* 22:22 */     this.length = raw.getS4At(2L);
/* 23:23 */     short numLocalVariables = raw.getS2At(6L);
/* 24:24 */     long offset = 8L;
/* 25:25 */     for (int x = 0; x < numLocalVariables; x++)
/* 26:   */     {
/* 27:26 */       short startPc = raw.getS2At(offset + 0L);
/* 28:27 */       short length = raw.getS2At(offset + 2L);
/* 29:28 */       short nameIndex = raw.getS2At(offset + 4L);
/* 30:29 */       short descriptorIndex = raw.getS2At(offset + 6L);
/* 31:30 */       short index = raw.getS2At(offset + 8L);
/* 32:31 */       this.localVariableEntryList.add(new LocalVariableEntry(startPc, length, nameIndex, descriptorIndex, index));
/* 33:32 */       offset += 10L;
/* 34:   */     }
/* 35:   */   }
/* 36:   */   
/* 37:   */   public String getRawName()
/* 38:   */   {
/* 39:38 */     return "LocalVariableTable";
/* 40:   */   }
/* 41:   */   
/* 42:   */   public Dumper dump(Dumper d)
/* 43:   */   {
/* 44:43 */     return d;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public List<LocalVariableEntry> getLocalVariableEntryList()
/* 48:   */   {
/* 49:47 */     return this.localVariableEntryList;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public long getRawByteLength()
/* 53:   */   {
/* 54:52 */     return 6L + this.length;
/* 55:   */   }
/* 56:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AttributeLocalVariableTable
 * JD-Core Version:    0.7.0.1
 */