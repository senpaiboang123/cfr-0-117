/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ public class LocalVariableEntry
/*  4:   */ {
/*  5:   */   private final short startPc;
/*  6:   */   private final short length;
/*  7:   */   private final short nameIndex;
/*  8:   */   private final short descriptorIndex;
/*  9:   */   private final short index;
/* 10:   */   
/* 11:   */   public LocalVariableEntry(short startPc, short length, short nameIndex, short descriptorIndex, short index)
/* 12:   */   {
/* 13:11 */     this.startPc = startPc;
/* 14:12 */     this.length = length;
/* 15:13 */     this.nameIndex = nameIndex;
/* 16:14 */     this.descriptorIndex = descriptorIndex;
/* 17:15 */     this.index = index;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public short getStartPc()
/* 21:   */   {
/* 22:19 */     return this.startPc;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public short getLength()
/* 26:   */   {
/* 27:23 */     return this.length;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public short getNameIndex()
/* 31:   */   {
/* 32:27 */     return this.nameIndex;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public short getDescriptorIndex()
/* 36:   */   {
/* 37:31 */     return this.descriptorIndex;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public short getIndex()
/* 41:   */   {
/* 42:35 */     return this.index;
/* 43:   */   }
/* 44:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.LocalVariableEntry
 * JD-Core Version:    0.7.0.1
 */