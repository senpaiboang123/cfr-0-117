/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  5:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass;
/*  6:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  7:   */ import org.benf.cfr.reader.util.ListFactory;
/*  8:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  9:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 10:   */ 
/* 11:   */ public class AttributeExceptions
/* 12:   */   extends Attribute
/* 13:   */ {
/* 14:   */   public static final String ATTRIBUTE_NAME = "Exceptions";
/* 15:   */   private static final long OFFSET_OF_ATTRIBUTE_LENGTH = 2L;
/* 16:   */   private static final long OFFSET_OF_NUMBER_OF_EXCEPTIONS = 6L;
/* 17:   */   private static final long OFFSET_OF_EXCEPTION_TABLE = 8L;
/* 18:   */   private static final long OFFSET_OF_REMAINDER = 6L;
/* 19:20 */   private final List<ConstantPoolEntryClass> exceptionClassList = ListFactory.newList();
/* 20:   */   private final int length;
/* 21:   */   
/* 22:   */   public AttributeExceptions(ByteData raw, ConstantPool cp)
/* 23:   */   {
/* 24:25 */     this.length = raw.getS4At(2L);
/* 25:26 */     short numExceptions = raw.getS2At(6L);
/* 26:27 */     long offset = 8L;
/* 27:28 */     for (int x = 0; x < numExceptions; offset += 2L)
/* 28:   */     {
/* 29:29 */       this.exceptionClassList.add(cp.getClassEntry(raw.getS2At(offset)));x++;
/* 30:   */     }
/* 31:   */   }
/* 32:   */   
/* 33:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 34:   */   {
/* 35:35 */     for (ConstantPoolEntryClass exceptionClass : this.exceptionClassList) {
/* 36:36 */       collector.collect(exceptionClass.getTypeInstance());
/* 37:   */     }
/* 38:   */   }
/* 39:   */   
/* 40:   */   public String getRawName()
/* 41:   */   {
/* 42:42 */     return "Exceptions";
/* 43:   */   }
/* 44:   */   
/* 45:   */   public Dumper dump(Dumper d)
/* 46:   */   {
/* 47:47 */     return d;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public List<ConstantPoolEntryClass> getExceptionClassList()
/* 51:   */   {
/* 52:51 */     return this.exceptionClassList;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public long getRawByteLength()
/* 56:   */   {
/* 57:56 */     return 6L + this.length;
/* 58:   */   }
/* 59:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AttributeExceptions
 * JD-Core Version:    0.7.0.1
 */