/*   1:    */ package org.benf.cfr.reader.entities.attributes;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*   5:    */ import org.benf.cfr.reader.util.ClassFileVersion;
/*   6:    */ import org.benf.cfr.reader.util.ListFactory;
/*   7:    */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*   8:    */ import org.benf.cfr.reader.util.bytestream.OffsettingByteData;
/*   9:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  10:    */ 
/*  11:    */ public class AttributeStackMapTable
/*  12:    */   extends Attribute
/*  13:    */ {
/*  14:    */   public static final String ATTRIBUTE_NAME = "StackMapTable";
/*  15:    */   private static final long OFFSET_OF_ATTRIBUTE_LENGTH = 2L;
/*  16:    */   private static final long OFFSET_OF_REMAINDER = 6L;
/*  17:    */   private static final long OFFSET_OF_NUMBER_OF_ENTRIES = 6L;
/*  18:    */   private static final long OFFSET_OF_STACK_MAP_FRAMES = 8L;
/*  19:    */   private final int length;
/*  20:    */   private final boolean valid;
/*  21:    */   private final List<StackMapFrame> stackMapFrames;
/*  22:    */   
/*  23:    */   public AttributeStackMapTable(ByteData raw, ConstantPool cp)
/*  24:    */   {
/*  25: 53 */     this.length = raw.getS4At(2L);
/*  26: 54 */     this.valid = false;
/*  27: 55 */     this.stackMapFrames = null;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public AttributeStackMapTable(ByteData raw, ConstantPool cp, ClassFileVersion classFileVersion)
/*  31:    */   {
/*  32: 63 */     this.length = raw.getS4At(2L);
/*  33: 64 */     int numEntries = raw.getU2At(6L);
/*  34: 65 */     long offset = 8L;
/*  35: 66 */     List<StackMapFrame> frames = ListFactory.newList();
/*  36: 67 */     boolean isValid = true;
/*  37: 68 */     OffsettingByteData data = raw.getOffsettingOffsetData(offset);
/*  38:    */     try
/*  39:    */     {
/*  40: 70 */       for (int x = 0; x < numEntries; x++)
/*  41:    */       {
/*  42: 71 */         StackMapFrame frame = readStackMapFrame(data);
/*  43: 72 */         frames.add(frame);
/*  44:    */       }
/*  45:    */     }
/*  46:    */     catch (Exception e)
/*  47:    */     {
/*  48: 75 */       isValid = false;
/*  49:    */     }
/*  50: 77 */     this.stackMapFrames = frames;
/*  51: 78 */     this.valid = isValid;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public boolean isValid()
/*  55:    */   {
/*  56: 82 */     return this.valid;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public List<StackMapFrame> getStackMapFrames()
/*  60:    */   {
/*  61: 86 */     return this.stackMapFrames;
/*  62:    */   }
/*  63:    */   
/*  64:    */   private static StackMapFrame readStackMapFrame(OffsettingByteData raw)
/*  65:    */   {
/*  66: 90 */     short frameType = raw.getU1At(0L);
/*  67: 91 */     raw.advance(1L);
/*  68: 92 */     if (frameType < 64) {
/*  69: 93 */       return new StackMapFrameSameFrame(frameType, null);
/*  70:    */     }
/*  71: 95 */     if (frameType < 127) {
/*  72: 96 */       return same_locals_1_stack_item_frame(frameType, raw);
/*  73:    */     }
/*  74: 98 */     if (frameType < 247) {
/*  75:100 */       throw new IllegalStateException();
/*  76:    */     }
/*  77:102 */     switch (frameType)
/*  78:    */     {
/*  79:    */     case 247: 
/*  80:104 */       return same_locals_1_stack_item_frame_extended(raw);
/*  81:    */     case 248: 
/*  82:    */     case 249: 
/*  83:    */     case 250: 
/*  84:108 */       return chop_frame(frameType, raw);
/*  85:    */     case 251: 
/*  86:110 */       return same_frame_extended(raw);
/*  87:    */     case 252: 
/*  88:    */     case 253: 
/*  89:    */     case 254: 
/*  90:114 */       return append_frame(frameType, raw);
/*  91:    */     case 255: 
/*  92:116 */       return full_frame(raw);
/*  93:    */     }
/*  94:118 */     throw new IllegalStateException();
/*  95:    */   }
/*  96:    */   
/*  97:    */   private static StackMapFrame same_locals_1_stack_item_frame(short type, OffsettingByteData raw)
/*  98:    */   {
/*  99:123 */     VerificationInfo verificationInfo = readVerificationInfo(raw);
/* 100:124 */     return new StackMapFrameSameLocals1SameItemFrame(type, verificationInfo, null);
/* 101:    */   }
/* 102:    */   
/* 103:    */   private static StackMapFrame same_locals_1_stack_item_frame_extended(OffsettingByteData raw)
/* 104:    */   {
/* 105:128 */     int offset_delta = raw.getU2At(0L);
/* 106:129 */     raw.advance(2L);
/* 107:130 */     VerificationInfo verificationInfo = readVerificationInfo(raw);
/* 108:131 */     return new StackMapFrameSameLocals1SameItemFrameExtended(offset_delta, verificationInfo, null);
/* 109:    */   }
/* 110:    */   
/* 111:    */   private static StackMapFrame chop_frame(short frame_type, OffsettingByteData raw)
/* 112:    */   {
/* 113:135 */     int offset_delta = raw.getU2At(0L);
/* 114:136 */     raw.advance(2L);
/* 115:137 */     return new StackMapFrameChopFrame(frame_type, offset_delta, null);
/* 116:    */   }
/* 117:    */   
/* 118:    */   private static StackMapFrame same_frame_extended(OffsettingByteData raw)
/* 119:    */   {
/* 120:141 */     int offset_delta = raw.getU2At(0L);
/* 121:142 */     raw.advance(2L);
/* 122:143 */     return new StackMapFrameSameFrameExtended(offset_delta, null);
/* 123:    */   }
/* 124:    */   
/* 125:    */   private static StackMapFrame append_frame(short frame_type, OffsettingByteData raw)
/* 126:    */   {
/* 127:147 */     int offset_delta = raw.getU2At(0L);
/* 128:148 */     raw.advance(2L);
/* 129:149 */     int num_ver = frame_type - 251;
/* 130:150 */     VerificationInfo[] verificationInfos = new VerificationInfo[num_ver];
/* 131:151 */     for (int x = 0; x < num_ver; x++) {
/* 132:152 */       verificationInfos[x] = readVerificationInfo(raw);
/* 133:    */     }
/* 134:154 */     return new StackMapFrameAppendFrame(frame_type, offset_delta, verificationInfos, null);
/* 135:    */   }
/* 136:    */   
/* 137:    */   private static StackMapFrame full_frame(OffsettingByteData raw)
/* 138:    */   {
/* 139:158 */     int offset_delta = raw.getU2At(0L);
/* 140:159 */     raw.advance(2L);
/* 141:160 */     int number_of_locals = raw.getU2At(0L);
/* 142:161 */     raw.advance(2L);
/* 143:162 */     long offset = 5L;
/* 144:163 */     VerificationInfo[] verificationLocals = new VerificationInfo[number_of_locals];
/* 145:164 */     for (int x = 0; x < number_of_locals; x++) {
/* 146:165 */       verificationLocals[x] = readVerificationInfo(raw);
/* 147:    */     }
/* 148:167 */     int number_of_stack_items = raw.getU2At(0L);
/* 149:168 */     raw.advance(2L);
/* 150:169 */     VerificationInfo[] verificationStackItems = new VerificationInfo[number_of_stack_items];
/* 151:170 */     for (int x = 0; x < number_of_stack_items; x++) {
/* 152:171 */       verificationStackItems[x] = readVerificationInfo(raw);
/* 153:    */     }
/* 154:173 */     return new StackMapFrameFullFrame(offset_delta, verificationLocals, verificationStackItems, null);
/* 155:    */   }
/* 156:    */   
/* 157:    */   private static VerificationInfo readVerificationInfo(OffsettingByteData raw)
/* 158:    */   {
/* 159:177 */     short type = raw.getU1At(0L);
/* 160:178 */     raw.advance(1L);
/* 161:179 */     switch (type)
/* 162:    */     {
/* 163:    */     case 0: 
/* 164:181 */       return VerificationInfoTop.INSTANCE;
/* 165:    */     case 1: 
/* 166:183 */       return VerificationInfoInteger.INSTANCE;
/* 167:    */     case 2: 
/* 168:185 */       return VerificationInfoFloat.INSTANCE;
/* 169:    */     case 3: 
/* 170:187 */       return VerificationInfoDouble.INSTANCE;
/* 171:    */     case 4: 
/* 172:189 */       return VerificationInfoLong.INSTANCE;
/* 173:    */     case 5: 
/* 174:191 */       return VerificationInfoNull.INSTANCE;
/* 175:    */     case 6: 
/* 176:193 */       return VerificationInfoUninitializedThis.INSTANCE;
/* 177:    */     case 7: 
/* 178:195 */       int u2 = raw.getU2At(0L);
/* 179:196 */       raw.advance(2L);
/* 180:197 */       return new VerificationInfoObject(u2, null);
/* 181:    */     case 8: 
/* 182:200 */       int u2 = raw.getU2At(0L);
/* 183:201 */       raw.advance(2L);
/* 184:202 */       return new VerificationInfoUninitialized(u2, null);
/* 185:    */     }
/* 186:205 */     throw new IllegalStateException();
/* 187:    */   }
/* 188:    */   
/* 189:    */   public String getRawName()
/* 190:    */   {
/* 191:211 */     return "StackMapTable";
/* 192:    */   }
/* 193:    */   
/* 194:    */   public Dumper dump(Dumper d)
/* 195:    */   {
/* 196:216 */     return d;
/* 197:    */   }
/* 198:    */   
/* 199:    */   public long getRawByteLength()
/* 200:    */   {
/* 201:221 */     return 6L + this.length;
/* 202:    */   }
/* 203:    */   
/* 204:    */   private static abstract interface StackMapFrame {}
/* 205:    */   
/* 206:    */   private static class StackMapFrameSameFrame
/* 207:    */     implements AttributeStackMapTable.StackMapFrame
/* 208:    */   {
/* 209:    */     private final short id;
/* 210:    */     
/* 211:    */     private StackMapFrameSameFrame(short id)
/* 212:    */     {
/* 213:231 */       this.id = id;
/* 214:    */     }
/* 215:    */   }
/* 216:    */   
/* 217:    */   private static class StackMapFrameSameLocals1SameItemFrame
/* 218:    */     implements AttributeStackMapTable.StackMapFrame
/* 219:    */   {
/* 220:    */     private final short id;
/* 221:    */     private final AttributeStackMapTable.VerificationInfo verificationInfo;
/* 222:    */     
/* 223:    */     private StackMapFrameSameLocals1SameItemFrame(short id, AttributeStackMapTable.VerificationInfo verificationInfo)
/* 224:    */     {
/* 225:241 */       this.id = id;
/* 226:242 */       this.verificationInfo = verificationInfo;
/* 227:    */     }
/* 228:    */   }
/* 229:    */   
/* 230:    */   private static class StackMapFrameSameLocals1SameItemFrameExtended
/* 231:    */     implements AttributeStackMapTable.StackMapFrame
/* 232:    */   {
/* 233:    */     private final int offset_delta;
/* 234:    */     private final AttributeStackMapTable.VerificationInfo verificationInfo;
/* 235:    */     
/* 236:    */     private StackMapFrameSameLocals1SameItemFrameExtended(int offset_delta, AttributeStackMapTable.VerificationInfo verificationInfo)
/* 237:    */     {
/* 238:252 */       this.offset_delta = offset_delta;
/* 239:253 */       this.verificationInfo = verificationInfo;
/* 240:    */     }
/* 241:    */   }
/* 242:    */   
/* 243:    */   private static class StackMapFrameChopFrame
/* 244:    */     implements AttributeStackMapTable.StackMapFrame
/* 245:    */   {
/* 246:    */     private final short frame_type;
/* 247:    */     private final int offset_delta;
/* 248:    */     
/* 249:    */     private StackMapFrameChopFrame(short frame_type, int offset_delta)
/* 250:    */     {
/* 251:263 */       this.frame_type = frame_type;
/* 252:264 */       this.offset_delta = offset_delta;
/* 253:    */     }
/* 254:    */   }
/* 255:    */   
/* 256:    */   private static class StackMapFrameSameFrameExtended
/* 257:    */     implements AttributeStackMapTable.StackMapFrame
/* 258:    */   {
/* 259:    */     private final int offset_delta;
/* 260:    */     
/* 261:    */     private StackMapFrameSameFrameExtended(int offset_delta)
/* 262:    */     {
/* 263:273 */       this.offset_delta = offset_delta;
/* 264:    */     }
/* 265:    */   }
/* 266:    */   
/* 267:    */   private static class StackMapFrameAppendFrame
/* 268:    */     implements AttributeStackMapTable.StackMapFrame
/* 269:    */   {
/* 270:    */     private final short frame_type;
/* 271:    */     private final int offset_delta;
/* 272:    */     private final AttributeStackMapTable.VerificationInfo[] verificationInfos;
/* 273:    */     
/* 274:    */     private StackMapFrameAppendFrame(short frame_type, int offset_delta, AttributeStackMapTable.VerificationInfo[] verificationInfos)
/* 275:    */     {
/* 276:284 */       this.frame_type = frame_type;
/* 277:285 */       this.offset_delta = offset_delta;
/* 278:286 */       this.verificationInfos = verificationInfos;
/* 279:    */     }
/* 280:    */   }
/* 281:    */   
/* 282:    */   private static class StackMapFrameFullFrame
/* 283:    */     implements AttributeStackMapTable.StackMapFrame
/* 284:    */   {
/* 285:    */     private final int offset_delta;
/* 286:    */     private final AttributeStackMapTable.VerificationInfo[] verificationLocals;
/* 287:    */     private final AttributeStackMapTable.VerificationInfo[] verificationStackItems;
/* 288:    */     
/* 289:    */     private StackMapFrameFullFrame(int offset_delta, AttributeStackMapTable.VerificationInfo[] verificationLocals, AttributeStackMapTable.VerificationInfo[] verificationStackItems)
/* 290:    */     {
/* 291:297 */       this.offset_delta = offset_delta;
/* 292:298 */       this.verificationLocals = verificationLocals;
/* 293:299 */       this.verificationStackItems = verificationStackItems;
/* 294:    */     }
/* 295:    */   }
/* 296:    */   
/* 297:    */   private static abstract interface VerificationInfo {}
/* 298:    */   
/* 299:    */   private static class AbstractVerificationInfo
/* 300:    */     implements AttributeStackMapTable.VerificationInfo
/* 301:    */   {}
/* 302:    */   
/* 303:    */   private static class VerificationInfoTop
/* 304:    */     extends AttributeStackMapTable.AbstractVerificationInfo
/* 305:    */   {
/* 306:    */     private static final char TYPE = '\000';
/* 307:    */     
/* 308:    */     private VerificationInfoTop()
/* 309:    */     {
/* 310:312 */       super();
/* 311:    */     }
/* 312:    */     
/* 313:314 */     private static AttributeStackMapTable.VerificationInfo INSTANCE = new VerificationInfoTop();
/* 314:    */   }
/* 315:    */   
/* 316:    */   private static class VerificationInfoInteger
/* 317:    */     extends AttributeStackMapTable.AbstractVerificationInfo
/* 318:    */   {
/* 319:    */     private static final char TYPE = '\001';
/* 320:    */     
/* 321:    */     private VerificationInfoInteger()
/* 322:    */     {
/* 323:317 */       super();
/* 324:    */     }
/* 325:    */     
/* 326:319 */     private static AttributeStackMapTable.VerificationInfo INSTANCE = new VerificationInfoInteger();
/* 327:    */   }
/* 328:    */   
/* 329:    */   private static class VerificationInfoFloat
/* 330:    */     extends AttributeStackMapTable.AbstractVerificationInfo
/* 331:    */   {
/* 332:    */     private static final char TYPE = '\002';
/* 333:    */     
/* 334:    */     private VerificationInfoFloat()
/* 335:    */     {
/* 336:322 */       super();
/* 337:    */     }
/* 338:    */     
/* 339:324 */     private static AttributeStackMapTable.VerificationInfo INSTANCE = new VerificationInfoFloat();
/* 340:    */   }
/* 341:    */   
/* 342:    */   private static class VerificationInfoDouble
/* 343:    */     extends AttributeStackMapTable.AbstractVerificationInfo
/* 344:    */   {
/* 345:    */     private static final char TYPE = '\003';
/* 346:    */     
/* 347:    */     private VerificationInfoDouble()
/* 348:    */     {
/* 349:327 */       super();
/* 350:    */     }
/* 351:    */     
/* 352:329 */     private static AttributeStackMapTable.VerificationInfo INSTANCE = new VerificationInfoDouble();
/* 353:    */   }
/* 354:    */   
/* 355:    */   private static class VerificationInfoLong
/* 356:    */     extends AttributeStackMapTable.AbstractVerificationInfo
/* 357:    */   {
/* 358:    */     private static final char TYPE = '\004';
/* 359:    */     
/* 360:    */     private VerificationInfoLong()
/* 361:    */     {
/* 362:332 */       super();
/* 363:    */     }
/* 364:    */     
/* 365:334 */     private static AttributeStackMapTable.VerificationInfo INSTANCE = new VerificationInfoLong();
/* 366:    */   }
/* 367:    */   
/* 368:    */   private static class VerificationInfoNull
/* 369:    */     extends AttributeStackMapTable.AbstractVerificationInfo
/* 370:    */   {
/* 371:    */     private static final char TYPE = '\005';
/* 372:    */     
/* 373:    */     private VerificationInfoNull()
/* 374:    */     {
/* 375:337 */       super();
/* 376:    */     }
/* 377:    */     
/* 378:339 */     private static AttributeStackMapTable.VerificationInfo INSTANCE = new VerificationInfoNull();
/* 379:    */   }
/* 380:    */   
/* 381:    */   private static class VerificationInfoUninitializedThis
/* 382:    */     extends AttributeStackMapTable.AbstractVerificationInfo
/* 383:    */   {
/* 384:    */     private static final char TYPE = '\006';
/* 385:    */     
/* 386:    */     private VerificationInfoUninitializedThis()
/* 387:    */     {
/* 388:342 */       super();
/* 389:    */     }
/* 390:    */     
/* 391:344 */     private static AttributeStackMapTable.VerificationInfo INSTANCE = new VerificationInfoUninitializedThis();
/* 392:    */   }
/* 393:    */   
/* 394:    */   private static class VerificationInfoObject
/* 395:    */     implements AttributeStackMapTable.VerificationInfo
/* 396:    */   {
/* 397:    */     private static final char TYPE = '\007';
/* 398:    */     private final int cpool_index;
/* 399:    */     
/* 400:    */     private VerificationInfoObject(int cpool_index)
/* 401:    */     {
/* 402:352 */       this.cpool_index = cpool_index;
/* 403:    */     }
/* 404:    */   }
/* 405:    */   
/* 406:    */   private static class VerificationInfoUninitialized
/* 407:    */     implements AttributeStackMapTable.VerificationInfo
/* 408:    */   {
/* 409:    */     private static final char TYPE = '\b';
/* 410:    */     private final int offset;
/* 411:    */     
/* 412:    */     private VerificationInfoUninitialized(int offset)
/* 413:    */     {
/* 414:362 */       this.offset = offset;
/* 415:    */     }
/* 416:    */   }
/* 417:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AttributeStackMapTable
 * JD-Core Version:    0.7.0.1
 */