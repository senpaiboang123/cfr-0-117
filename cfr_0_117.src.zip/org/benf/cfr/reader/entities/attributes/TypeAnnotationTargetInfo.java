/*   1:    */ package org.benf.cfr.reader.entities.attributes;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*   5:    */ import org.benf.cfr.reader.util.ListFactory;
/*   6:    */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*   7:    */ 
/*   8:    */ public abstract interface TypeAnnotationTargetInfo
/*   9:    */ {
/*  10:    */   public static class TypeAnnotationParameterTarget
/*  11:    */     implements TypeAnnotationTargetInfo
/*  12:    */   {
/*  13:    */     private final short type_parameter_index;
/*  14:    */     
/*  15:    */     private TypeAnnotationParameterTarget(short type_parameter_index)
/*  16:    */     {
/*  17: 15 */       this.type_parameter_index = type_parameter_index;
/*  18:    */     }
/*  19:    */     
/*  20:    */     public static Pair<Long, TypeAnnotationTargetInfo> Read(ByteData raw, long offset)
/*  21:    */     {
/*  22: 19 */       short type_parameter_index = raw.getU1At(offset++);
/*  23: 20 */       return Pair.make(Long.valueOf(offset), new TypeAnnotationParameterTarget(type_parameter_index));
/*  24:    */     }
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static class TypeAnnotationSupertypeTarget
/*  28:    */     implements TypeAnnotationTargetInfo
/*  29:    */   {
/*  30:    */     private final int supertype_index;
/*  31:    */     
/*  32:    */     private TypeAnnotationSupertypeTarget(int supertype_index)
/*  33:    */     {
/*  34: 28 */       this.supertype_index = supertype_index;
/*  35:    */     }
/*  36:    */     
/*  37:    */     public static Pair<Long, TypeAnnotationTargetInfo> Read(ByteData raw, long offset)
/*  38:    */     {
/*  39: 32 */       int supertype_index = raw.getU2At(offset);
/*  40: 33 */       offset += 2L;
/*  41: 34 */       return Pair.make(Long.valueOf(offset), new TypeAnnotationSupertypeTarget(supertype_index));
/*  42:    */     }
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static class TypeAnnotationParameterBoundTarget
/*  46:    */     implements TypeAnnotationTargetInfo
/*  47:    */   {
/*  48:    */     private final short type_parameter_index;
/*  49:    */     private final short bound_index;
/*  50:    */     
/*  51:    */     private TypeAnnotationParameterBoundTarget(short type_parameter_index, short bound_index)
/*  52:    */     {
/*  53: 44 */       this.type_parameter_index = type_parameter_index;
/*  54: 45 */       this.bound_index = bound_index;
/*  55:    */     }
/*  56:    */     
/*  57:    */     public static Pair<Long, TypeAnnotationTargetInfo> Read(ByteData raw, long offset)
/*  58:    */     {
/*  59: 49 */       short type_parameter_index = raw.getU1At(offset++);
/*  60: 50 */       short bound_index = raw.getU1At(offset++);
/*  61: 51 */       return Pair.make(Long.valueOf(offset), new TypeAnnotationParameterBoundTarget(type_parameter_index, bound_index));
/*  62:    */     }
/*  63:    */   }
/*  64:    */   
/*  65:    */   public static class TypeAnnotationEmptyTarget
/*  66:    */     implements TypeAnnotationTargetInfo
/*  67:    */   {
/*  68:    */     public static Pair<Long, TypeAnnotationTargetInfo> Read(ByteData raw, long offset)
/*  69:    */     {
/*  70: 59 */       return Pair.make(Long.valueOf(offset), new TypeAnnotationEmptyTarget());
/*  71:    */     }
/*  72:    */   }
/*  73:    */   
/*  74:    */   public static class TypeAnnotationFormalParameterTarget
/*  75:    */     implements TypeAnnotationTargetInfo
/*  76:    */   {
/*  77:    */     private final short formal_parameter_index;
/*  78:    */     
/*  79:    */     private TypeAnnotationFormalParameterTarget(short formal_parameter_index)
/*  80:    */     {
/*  81: 67 */       this.formal_parameter_index = formal_parameter_index;
/*  82:    */     }
/*  83:    */     
/*  84:    */     public static Pair<Long, TypeAnnotationTargetInfo> Read(ByteData raw, long offset)
/*  85:    */     {
/*  86: 71 */       short formal_parameter_index = raw.getU1At(offset++);
/*  87: 72 */       return Pair.make(Long.valueOf(offset), new TypeAnnotationFormalParameterTarget(formal_parameter_index));
/*  88:    */     }
/*  89:    */   }
/*  90:    */   
/*  91:    */   public static class TypeAnnotationThrowsTarget
/*  92:    */     implements TypeAnnotationTargetInfo
/*  93:    */   {
/*  94:    */     private final int throws_type_index;
/*  95:    */     
/*  96:    */     private TypeAnnotationThrowsTarget(int throws_type_index)
/*  97:    */     {
/*  98: 81 */       this.throws_type_index = throws_type_index;
/*  99:    */     }
/* 100:    */     
/* 101:    */     public static Pair<Long, TypeAnnotationTargetInfo> Read(ByteData raw, long offset)
/* 102:    */     {
/* 103: 85 */       int throws_type_index = raw.getU2At(offset);
/* 104: 86 */       offset += 2L;
/* 105: 87 */       return Pair.make(Long.valueOf(offset), new TypeAnnotationThrowsTarget(throws_type_index));
/* 106:    */     }
/* 107:    */   }
/* 108:    */   
/* 109:    */   public static class LocalVarTarget
/* 110:    */   {
/* 111:    */     private final int start;
/* 112:    */     private final int length;
/* 113:    */     private final int index;
/* 114:    */     
/* 115:    */     public LocalVarTarget(int start, int length, int index)
/* 116:    */     {
/* 117: 99 */       this.start = start;
/* 118:100 */       this.length = length;
/* 119:101 */       this.index = index;
/* 120:    */     }
/* 121:    */     
/* 122:    */     public boolean matches(int offset, int slot, int tolerance)
/* 123:    */     {
/* 124:105 */       return (offset >= this.start - tolerance) && (offset < this.start + this.length) && (slot == this.index);
/* 125:    */     }
/* 126:    */   }
/* 127:    */   
/* 128:    */   public static class TypeAnnotationLocalVarTarget
/* 129:    */     implements TypeAnnotationTargetInfo
/* 130:    */   {
/* 131:    */     private final List<TypeAnnotationTargetInfo.LocalVarTarget> targets;
/* 132:    */     
/* 133:    */     public TypeAnnotationLocalVarTarget(List<TypeAnnotationTargetInfo.LocalVarTarget> targets)
/* 134:    */     {
/* 135:114 */       this.targets = targets;
/* 136:    */     }
/* 137:    */     
/* 138:    */     public boolean matches(int offset, int slot, int tolerance)
/* 139:    */     {
/* 140:118 */       for (TypeAnnotationTargetInfo.LocalVarTarget tgt : this.targets) {
/* 141:119 */         if (tgt.matches(offset, slot, tolerance)) {
/* 142:119 */           return true;
/* 143:    */         }
/* 144:    */       }
/* 145:121 */       return false;
/* 146:    */     }
/* 147:    */     
/* 148:    */     public static Pair<Long, TypeAnnotationTargetInfo> Read(ByteData raw, long offset)
/* 149:    */     {
/* 150:125 */       int count = raw.getU2At(offset);
/* 151:126 */       offset += 2L;
/* 152:127 */       List<TypeAnnotationTargetInfo.LocalVarTarget> targetList = ListFactory.newList();
/* 153:128 */       for (int x = 0; x < count; x++)
/* 154:    */       {
/* 155:129 */         int start = raw.getU2At(offset);
/* 156:130 */         offset += 2L;
/* 157:131 */         int length = raw.getU2At(offset);
/* 158:132 */         offset += 2L;
/* 159:133 */         int index = raw.getU2At(offset);
/* 160:134 */         offset += 2L;
/* 161:135 */         targetList.add(new TypeAnnotationTargetInfo.LocalVarTarget(start, length, index));
/* 162:    */       }
/* 163:137 */       return Pair.make(Long.valueOf(offset), new TypeAnnotationLocalVarTarget(targetList));
/* 164:    */     }
/* 165:    */   }
/* 166:    */   
/* 167:    */   public static class TypeAnnotationCatchTarget
/* 168:    */     implements TypeAnnotationTargetInfo
/* 169:    */   {
/* 170:    */     private final int exception_table_index;
/* 171:    */     
/* 172:    */     private TypeAnnotationCatchTarget(int exception_table_index)
/* 173:    */     {
/* 174:145 */       this.exception_table_index = exception_table_index;
/* 175:    */     }
/* 176:    */     
/* 177:    */     public static Pair<Long, TypeAnnotationTargetInfo> Read(ByteData raw, long offset)
/* 178:    */     {
/* 179:149 */       int exception_table_index = raw.getU2At(offset);
/* 180:150 */       offset += 2L;
/* 181:151 */       return Pair.make(Long.valueOf(offset), new TypeAnnotationCatchTarget(exception_table_index));
/* 182:    */     }
/* 183:    */   }
/* 184:    */   
/* 185:    */   public static class TypeAnnotationOffsetTarget
/* 186:    */     implements TypeAnnotationTargetInfo
/* 187:    */   {
/* 188:    */     private final int offset;
/* 189:    */     
/* 190:    */     private TypeAnnotationOffsetTarget(int offset)
/* 191:    */     {
/* 192:159 */       this.offset = offset;
/* 193:    */     }
/* 194:    */     
/* 195:    */     public static Pair<Long, TypeAnnotationTargetInfo> Read(ByteData raw, long offset)
/* 196:    */     {
/* 197:163 */       int offset_val = raw.getU2At(offset);
/* 198:164 */       offset += 2L;
/* 199:165 */       return Pair.make(Long.valueOf(offset), new TypeAnnotationOffsetTarget(offset_val));
/* 200:    */     }
/* 201:    */   }
/* 202:    */   
/* 203:    */   public static class TypeAnnotationTypeArgumentTarget
/* 204:    */     implements TypeAnnotationTargetInfo
/* 205:    */   {
/* 206:    */     private final int offset;
/* 207:    */     private final short type_argument_index;
/* 208:    */     
/* 209:    */     private TypeAnnotationTypeArgumentTarget(int offset, short type_argument_index)
/* 210:    */     {
/* 211:174 */       this.offset = offset;
/* 212:175 */       this.type_argument_index = type_argument_index;
/* 213:    */     }
/* 214:    */     
/* 215:    */     public static Pair<Long, TypeAnnotationTargetInfo> Read(ByteData raw, long offset)
/* 216:    */     {
/* 217:179 */       int offset_val = raw.getU2At(offset);
/* 218:180 */       offset += 2L;
/* 219:181 */       short type_argument_index = raw.getU1At(offset++);
/* 220:182 */       return Pair.make(Long.valueOf(offset), new TypeAnnotationTypeArgumentTarget(offset_val, type_argument_index));
/* 221:    */     }
/* 222:    */   }
/* 223:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.TypeAnnotationTargetInfo
 * JD-Core Version:    0.7.0.1
 */