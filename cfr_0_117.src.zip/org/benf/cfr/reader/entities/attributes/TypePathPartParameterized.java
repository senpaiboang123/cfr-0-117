/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaAnnotatedTypeIterator;
/*  4:   */ import org.benf.cfr.reader.util.DecompilerComments;
/*  5:   */ 
/*  6:   */ public class TypePathPartParameterized
/*  7:   */   implements TypePathPart
/*  8:   */ {
/*  9:   */   private final int index;
/* 10:   */   
/* 11:   */   public TypePathPartParameterized(int index)
/* 12:   */   {
/* 13:10 */     this.index = index;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public JavaAnnotatedTypeIterator apply(JavaAnnotatedTypeIterator it, DecompilerComments comments)
/* 17:   */   {
/* 18:15 */     return it.moveParameterized(this.index, comments);
/* 19:   */   }
/* 20:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.TypePathPartParameterized
 * JD-Core Version:    0.7.0.1
 */