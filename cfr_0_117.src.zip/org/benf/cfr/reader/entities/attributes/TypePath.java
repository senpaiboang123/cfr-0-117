/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ 
/*  5:   */ public class TypePath
/*  6:   */ {
/*  7:   */   public final List<TypePathPart> segments;
/*  8:   */   
/*  9:   */   public TypePath(List<TypePathPart> segments)
/* 10:   */   {
/* 11:20 */     this.segments = segments;
/* 12:   */   }
/* 13:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.TypePath
 * JD-Core Version:    0.7.0.1
 */