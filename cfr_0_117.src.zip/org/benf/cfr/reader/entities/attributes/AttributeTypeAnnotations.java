/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import java.util.Map;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  6:   */ import org.benf.cfr.reader.entities.annotations.AnnotationTableTypeEntry;
/*  7:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  8:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  9:   */ import org.benf.cfr.reader.util.Functional;
/* 10:   */ import org.benf.cfr.reader.util.ListFactory;
/* 11:   */ import org.benf.cfr.reader.util.MapFactory;
/* 12:   */ import org.benf.cfr.reader.util.Predicate;
/* 13:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/* 14:   */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/* 15:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 16:   */ 
/* 17:   */ public abstract class AttributeTypeAnnotations
/* 18:   */   extends Attribute
/* 19:   */ {
/* 20:   */   private static final long OFFSET_OF_ATTRIBUTE_LENGTH = 2L;
/* 21:   */   private static final long OFFSET_OF_REMAINDER = 6L;
/* 22:   */   private static final long OFFSET_OF_NUMBER_OF_ANNOTATIONS = 6L;
/* 23:   */   private static final long OFFSET_OF_ANNOTATION_TABLE = 8L;
/* 24:22 */   private final Map<TypeAnnotationEntryKind, List<AnnotationTableTypeEntry>> annotationTableEntryData = MapFactory.newLazyMap(new UnaryFunction()
/* 25:   */   {
/* 26:   */     public List<AnnotationTableTypeEntry> invoke(TypeAnnotationEntryKind arg)
/* 27:   */     {
/* 28:25 */       return ListFactory.newList();
/* 29:   */     }
/* 30:22 */   });
/* 31:   */   private final int length;
/* 32:   */   
/* 33:   */   public AttributeTypeAnnotations(ByteData raw, ConstantPool cp)
/* 34:   */   {
/* 35:33 */     this.length = raw.getS4At(2L);
/* 36:34 */     int numAnnotations = raw.getU2At(6L);
/* 37:35 */     long offset = 8L;
/* 38:36 */     for (int x = 0; x < numAnnotations; x++)
/* 39:   */     {
/* 40:37 */       Pair<Long, AnnotationTableTypeEntry> ape = AnnotationHelpers.getTypeAnnotation(raw, offset, cp);
/* 41:38 */       offset = ((Long)ape.getFirst()).longValue();
/* 42:39 */       AnnotationTableTypeEntry entry = (AnnotationTableTypeEntry)ape.getSecond();
/* 43:40 */       ((List)this.annotationTableEntryData.get(entry.getKind())).add(entry);
/* 44:   */     }
/* 45:   */   }
/* 46:   */   
/* 47:   */   public Dumper dump(Dumper d)
/* 48:   */   {
/* 49:46 */     for (List<AnnotationTableTypeEntry> annotationTableEntryList : this.annotationTableEntryData.values()) {
/* 50:47 */       for (AnnotationTableTypeEntry annotationTableEntry : annotationTableEntryList)
/* 51:   */       {
/* 52:48 */         annotationTableEntry.dump(d);
/* 53:49 */         d.newln();
/* 54:   */       }
/* 55:   */     }
/* 56:52 */     return d;
/* 57:   */   }
/* 58:   */   
/* 59:   */   public long getRawByteLength()
/* 60:   */   {
/* 61:58 */     return 6L + this.length;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 65:   */   {
/* 66:63 */     for (List<AnnotationTableTypeEntry> annotationTableEntryList : this.annotationTableEntryData.values()) {
/* 67:64 */       for (AnnotationTableTypeEntry annotationTableEntry : annotationTableEntryList) {
/* 68:65 */         annotationTableEntry.collectTypeUsages(collector);
/* 69:   */       }
/* 70:   */     }
/* 71:   */   }
/* 72:   */   
/* 73:   */   public List<AnnotationTableTypeEntry<TypeAnnotationTargetInfo.TypeAnnotationLocalVarTarget>> getLocalVariableAnnotations(final int offset, final int slot, final int tolerance)
/* 74:   */   {
/* 75:72 */     if (!this.annotationTableEntryData.containsKey(TypeAnnotationEntryKind.localvar_target)) {
/* 76:72 */       return ListFactory.newList();
/* 77:   */     }
/* 78:73 */     List<AnnotationTableTypeEntry> entries = (List)this.annotationTableEntryData.get(TypeAnnotationEntryKind.localvar_target);
/* 79:   */     
/* 80:75 */     entries = Functional.filter(entries, new Predicate()
/* 81:   */     {
/* 82:   */       public boolean test(AnnotationTableTypeEntry in)
/* 83:   */       {
/* 84:78 */         TypeAnnotationTargetInfo.TypeAnnotationLocalVarTarget tgt = (TypeAnnotationTargetInfo.TypeAnnotationLocalVarTarget)in.getTargetInfo();
/* 85:79 */         return tgt.matches(offset, slot, tolerance);
/* 86:   */       }
/* 87:82 */     });
/* 88:83 */     return (List)entries;
/* 89:   */   }
/* 90:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AttributeTypeAnnotations
 * JD-Core Version:    0.7.0.1
 */