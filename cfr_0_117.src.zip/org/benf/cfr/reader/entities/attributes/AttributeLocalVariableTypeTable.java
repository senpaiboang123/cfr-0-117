/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  5:   */ import org.benf.cfr.reader.util.ListFactory;
/*  6:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  7:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  8:   */ 
/*  9:   */ public class AttributeLocalVariableTypeTable
/* 10:   */   extends Attribute
/* 11:   */ {
/* 12:   */   public static final String ATTRIBUTE_NAME = "LocalVariableTypeTable";
/* 13:   */   private static final long OFFSET_OF_ATTRIBUTE_LENGTH = 2L;
/* 14:   */   private static final long OFFSET_OF_REMAINDER = 6L;
/* 15:15 */   private final List<LocalVariableEntry> localVariableEntryList = ListFactory.newList();
/* 16:   */   private final int length;
/* 17:   */   
/* 18:   */   public AttributeLocalVariableTypeTable(ByteData raw, ConstantPool cp)
/* 19:   */   {
/* 20:20 */     this.length = raw.getS4At(2L);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String getRawName()
/* 24:   */   {
/* 25:25 */     return "LocalVariableTypeTable";
/* 26:   */   }
/* 27:   */   
/* 28:   */   public Dumper dump(Dumper d)
/* 29:   */   {
/* 30:30 */     return d;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public long getRawByteLength()
/* 34:   */   {
/* 35:35 */     return 6L + this.length;
/* 36:   */   }
/* 37:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AttributeLocalVariableTypeTable
 * JD-Core Version:    0.7.0.1
 */