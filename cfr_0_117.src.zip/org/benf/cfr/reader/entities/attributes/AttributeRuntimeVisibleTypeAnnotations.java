/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  4:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  5:   */ 
/*  6:   */ public class AttributeRuntimeVisibleTypeAnnotations
/*  7:   */   extends AttributeTypeAnnotations
/*  8:   */ {
/*  9:   */   public static final String ATTRIBUTE_NAME = "RuntimeVisibleTypeAnnotations";
/* 10:   */   
/* 11:   */   public AttributeRuntimeVisibleTypeAnnotations(ByteData raw, ConstantPool cp)
/* 12:   */   {
/* 13:10 */     super(raw, cp);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public String getRawName()
/* 17:   */   {
/* 18:15 */     return "RuntimeVisibleTypeAnnotations";
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String toString()
/* 22:   */   {
/* 23:20 */     return "RuntimeVisibleTypeAnnotations";
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AttributeRuntimeVisibleTypeAnnotations
 * JD-Core Version:    0.7.0.1
 */