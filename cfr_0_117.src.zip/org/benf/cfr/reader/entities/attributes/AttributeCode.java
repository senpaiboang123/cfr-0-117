/*   1:    */ package org.benf.cfr.reader.entities.attributes;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Map;
/*   7:    */ import org.benf.cfr.reader.bytecode.CodeAnalyser;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*   9:    */ import org.benf.cfr.reader.entities.Method;
/*  10:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  11:    */ import org.benf.cfr.reader.entities.exceptions.ExceptionTableEntry;
/*  12:    */ import org.benf.cfr.reader.entityfactories.AttributeFactory;
/*  13:    */ import org.benf.cfr.reader.entityfactories.ContiguousEntityFactory;
/*  14:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  15:    */ import org.benf.cfr.reader.util.ClassFileVersion;
/*  16:    */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  17:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  18:    */ 
/*  19:    */ public class AttributeCode
/*  20:    */   extends Attribute
/*  21:    */ {
/*  22:    */   public static final String ATTRIBUTE_NAME = "Code";
/*  23:    */   private static final long OFFSET_OF_ATTRIBUTE_LENGTH = 2L;
/*  24:    */   private static final long OFFSET_OF_MAX_STACK = 6L;
/*  25:    */   private final int length;
/*  26:    */   private final short maxStack;
/*  27:    */   private final short maxLocals;
/*  28:    */   private final int codeLength;
/*  29:    */   private final List<ExceptionTableEntry> exceptionTableEntries;
/*  30:    */   private final Map<String, Attribute> attributes;
/*  31:    */   private final ConstantPool cp;
/*  32:    */   private final ByteData rawData;
/*  33:    */   private final CodeAnalyser codeAnalyser;
/*  34:    */   
/*  35:    */   public AttributeCode(ByteData raw, ConstantPool cp, ClassFileVersion classFileVersion)
/*  36:    */   {
/*  37: 38 */     this.cp = cp;
/*  38: 39 */     this.length = raw.getS4At(2L);
/*  39:    */     
/*  40: 41 */     long OFFSET_OF_MAX_LOCALS = 8L;
/*  41: 42 */     long OFFSET_OF_CODE_LENGTH = 10L;
/*  42: 43 */     long OFFSET_OF_CODE = 14L;
/*  43:    */     
/*  44: 45 */     short maxStack = 0;
/*  45: 46 */     short maxLocals = 0;
/*  46: 47 */     int codeLength = 0;
/*  47: 48 */     if (classFileVersion.before(ClassFileVersion.JAVA_1_0))
/*  48:    */     {
/*  49: 49 */       OFFSET_OF_MAX_LOCALS = 7L;
/*  50: 50 */       OFFSET_OF_CODE_LENGTH = 8L;
/*  51: 51 */       OFFSET_OF_CODE = 10L;
/*  52:    */       
/*  53: 53 */       maxStack = raw.getU1At(6L);
/*  54: 54 */       maxLocals = raw.getU1At(OFFSET_OF_MAX_LOCALS);
/*  55: 55 */       codeLength = raw.getU2At(OFFSET_OF_CODE_LENGTH);
/*  56:    */     }
/*  57:    */     else
/*  58:    */     {
/*  59: 58 */       maxStack = raw.getS2At(6L);
/*  60: 59 */       maxLocals = raw.getS2At(OFFSET_OF_MAX_LOCALS);
/*  61: 60 */       codeLength = raw.getS4At(OFFSET_OF_CODE_LENGTH);
/*  62:    */     }
/*  63: 62 */     this.maxStack = maxStack;
/*  64: 63 */     this.maxLocals = maxLocals;
/*  65: 64 */     this.codeLength = codeLength;
/*  66:    */     
/*  67: 66 */     long OFFSET_OF_EXCEPTION_TABLE_LENGTH = OFFSET_OF_CODE + codeLength;
/*  68: 67 */     long OFFSET_OF_EXCEPTION_TABLE = OFFSET_OF_EXCEPTION_TABLE_LENGTH + 2L;
/*  69:    */     
/*  70: 69 */     ArrayList<ExceptionTableEntry> etis = new ArrayList();
/*  71: 70 */     short numExceptions = raw.getS2At(OFFSET_OF_EXCEPTION_TABLE_LENGTH);
/*  72: 71 */     etis.ensureCapacity(numExceptions);
/*  73: 72 */     long numBytesExceptionInfo = ContiguousEntityFactory.buildSized(raw.getOffsetData(OFFSET_OF_EXCEPTION_TABLE), numExceptions, 8, etis, ExceptionTableEntry.getBuilder(cp));
/*  74:    */     
/*  75:    */ 
/*  76: 75 */     this.exceptionTableEntries = etis;
/*  77:    */     
/*  78: 77 */     long OFFSET_OF_ATTRIBUTES_COUNT = OFFSET_OF_EXCEPTION_TABLE + numBytesExceptionInfo;
/*  79: 78 */     long OFFSET_OF_ATTRIBUTES = OFFSET_OF_ATTRIBUTES_COUNT + 2L;
/*  80: 79 */     short numAttributes = raw.getS2At(OFFSET_OF_ATTRIBUTES_COUNT);
/*  81: 80 */     ArrayList<Attribute> tmpAttributes = new ArrayList();
/*  82: 81 */     tmpAttributes.ensureCapacity(numAttributes);
/*  83: 82 */     ContiguousEntityFactory.build(raw.getOffsetData(OFFSET_OF_ATTRIBUTES), numAttributes, tmpAttributes, AttributeFactory.getBuilder(cp, classFileVersion));
/*  84:    */     
/*  85: 84 */     this.attributes = ContiguousEntityFactory.addToMap(new HashMap(), tmpAttributes);
/*  86:    */     
/*  87: 86 */     this.rawData = raw.getOffsetData(OFFSET_OF_CODE);
/*  88: 87 */     this.codeAnalyser = new CodeAnalyser(this);
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void setMethod(Method method)
/*  92:    */   {
/*  93: 91 */     this.codeAnalyser.setMethod(method);
/*  94:    */   }
/*  95:    */   
/*  96:    */   public Op04StructuredStatement analyse()
/*  97:    */   {
/*  98: 95 */     return this.codeAnalyser.getAnalysis(getConstantPool().getDCCommonState());
/*  99:    */   }
/* 100:    */   
/* 101:    */   public ConstantPool getConstantPool()
/* 102:    */   {
/* 103: 99 */     return this.cp;
/* 104:    */   }
/* 105:    */   
/* 106:    */   private <T extends Attribute> T getAttributeByName(String name)
/* 107:    */   {
/* 108:103 */     Attribute attribute = (Attribute)this.attributes.get(name);
/* 109:104 */     if (attribute == null) {
/* 110:104 */       return null;
/* 111:    */     }
/* 112:106 */     T tmp = attribute;
/* 113:107 */     return tmp;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public AttributeLocalVariableTable getLocalVariableTable()
/* 117:    */   {
/* 118:111 */     return (AttributeLocalVariableTable)getAttributeByName("LocalVariableTable");
/* 119:    */   }
/* 120:    */   
/* 121:    */   public AttributeLineNumberTable getLineNumberTable()
/* 122:    */   {
/* 123:115 */     return (AttributeLineNumberTable)getAttributeByName("LineNumberTable");
/* 124:    */   }
/* 125:    */   
/* 126:    */   public AttributeRuntimeVisibleTypeAnnotations getRuntimeVisibleTypeAnnotations()
/* 127:    */   {
/* 128:119 */     return (AttributeRuntimeVisibleTypeAnnotations)getAttributeByName("RuntimeVisibleTypeAnnotations");
/* 129:    */   }
/* 130:    */   
/* 131:    */   public ByteData getRawData()
/* 132:    */   {
/* 133:123 */     return this.rawData;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public List<ExceptionTableEntry> getExceptionTableEntries()
/* 137:    */   {
/* 138:127 */     return this.exceptionTableEntries;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public short getMaxStack()
/* 142:    */   {
/* 143:131 */     return this.maxStack;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public short getMaxLocals()
/* 147:    */   {
/* 148:135 */     return this.maxLocals;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public int getCodeLength()
/* 152:    */   {
/* 153:139 */     return this.codeLength;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public Dumper dump(Dumper d)
/* 157:    */   {
/* 158:144 */     return this.codeAnalyser.getAnalysis(getConstantPool().getDCCommonState()).dump(d);
/* 159:    */   }
/* 160:    */   
/* 161:    */   public long getRawByteLength()
/* 162:    */   {
/* 163:149 */     return 6L + this.length;
/* 164:    */   }
/* 165:    */   
/* 166:    */   public String getRawName()
/* 167:    */   {
/* 168:154 */     return "Code";
/* 169:    */   }
/* 170:    */   
/* 171:    */   public void collectTypeUsages(TypeUsageCollector collector)
/* 172:    */   {
/* 173:159 */     for (Attribute attribute : this.attributes.values()) {
/* 174:160 */       attribute.collectTypeUsages(collector);
/* 175:    */     }
/* 176:    */   }
/* 177:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AttributeCode
 * JD-Core Version:    0.7.0.1
 */