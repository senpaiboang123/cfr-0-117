/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaAnnotatedTypeIterator;
/*  4:   */ import org.benf.cfr.reader.util.DecompilerComments;
/*  5:   */ 
/*  6:   */ public class TypePathPartArray
/*  7:   */   implements TypePathPart
/*  8:   */ {
/*  9: 7 */   public static TypePathPartArray INSTANCE = new TypePathPartArray();
/* 10:   */   
/* 11:   */   public JavaAnnotatedTypeIterator apply(JavaAnnotatedTypeIterator it, DecompilerComments comments)
/* 12:   */   {
/* 13:14 */     return it.moveArray(comments);
/* 14:   */   }
/* 15:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.TypePathPartArray
 * JD-Core Version:    0.7.0.1
 */