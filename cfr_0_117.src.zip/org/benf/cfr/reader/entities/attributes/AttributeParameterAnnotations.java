/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  5:   */ import org.benf.cfr.reader.entities.annotations.AnnotationTableEntry;
/*  6:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  7:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  8:   */ import org.benf.cfr.reader.util.ListFactory;
/*  9:   */ import org.benf.cfr.reader.util.TypeUsageCollectable;
/* 10:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/* 11:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 12:   */ 
/* 13:   */ public abstract class AttributeParameterAnnotations
/* 14:   */   extends Attribute
/* 15:   */   implements TypeUsageCollectable
/* 16:   */ {
/* 17:   */   private static final long OFFSET_OF_ATTRIBUTE_LENGTH = 2L;
/* 18:   */   private static final long OFFSET_OF_REMAINDER = 6L;
/* 19:   */   private static final long OFFSET_OF_NUMBER_OF_PARAMETERS = 6L;
/* 20:   */   private static final long OFFSET_OF_ANNOTATION_NAME_TABLE = 7L;
/* 21:   */   private final List<List<AnnotationTableEntry>> annotationTableEntryListList;
/* 22:   */   private final int length;
/* 23:   */   
/* 24:   */   public AttributeParameterAnnotations(ByteData raw, ConstantPool cp)
/* 25:   */   {
/* 26:25 */     this.length = raw.getS4At(2L);
/* 27:26 */     byte numParameters = raw.getS1At(6L);
/* 28:27 */     long offset = 7L;
/* 29:28 */     this.annotationTableEntryListList = ListFactory.newList();
/* 30:29 */     for (int x = 0; x < numParameters; x++)
/* 31:   */     {
/* 32:30 */       List<AnnotationTableEntry> annotationTableEntryList = ListFactory.newList();
/* 33:   */       
/* 34:32 */       short numAnnotations = raw.getS2At(offset);
/* 35:33 */       offset += 2L;
/* 36:34 */       for (int y = 0; y < numAnnotations; y++)
/* 37:   */       {
/* 38:35 */         Pair<Long, AnnotationTableEntry> ape = AnnotationHelpers.getAnnotation(raw, offset, cp);
/* 39:36 */         offset = ((Long)ape.getFirst()).longValue();
/* 40:37 */         annotationTableEntryList.add(ape.getSecond());
/* 41:   */       }
/* 42:39 */       this.annotationTableEntryListList.add(annotationTableEntryList);
/* 43:   */     }
/* 44:   */   }
/* 45:   */   
/* 46:   */   public List<AnnotationTableEntry> getAnnotationsForParamIdx(int idx)
/* 47:   */   {
/* 48:44 */     if ((idx < 0) || (idx >= this.annotationTableEntryListList.size())) {
/* 49:44 */       return null;
/* 50:   */     }
/* 51:45 */     return (List)this.annotationTableEntryListList.get(idx);
/* 52:   */   }
/* 53:   */   
/* 54:   */   public Dumper dump(Dumper d)
/* 55:   */   {
/* 56:50 */     return d;
/* 57:   */   }
/* 58:   */   
/* 59:   */   public long getRawByteLength()
/* 60:   */   {
/* 61:55 */     return 6L + this.length;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 65:   */   {
/* 66:60 */     for (List<AnnotationTableEntry> annotationTableEntryList : this.annotationTableEntryListList) {
/* 67:61 */       for (AnnotationTableEntry annotationTableEntry : annotationTableEntryList) {
/* 68:62 */         annotationTableEntry.collectTypeUsages(collector);
/* 69:   */       }
/* 70:   */     }
/* 71:   */   }
/* 72:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AttributeParameterAnnotations
 * JD-Core Version:    0.7.0.1
 */