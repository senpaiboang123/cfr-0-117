/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  4:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  5:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  6:   */ 
/*  7:   */ public class AttributeSynthetic
/*  8:   */   extends Attribute
/*  9:   */ {
/* 10:   */   public static final String ATTRIBUTE_NAME = "Synthetic";
/* 11:   */   private static final long OFFSET_OF_ATTRIBUTE_LENGTH = 2L;
/* 12:   */   private static final long OFFSET_OF_REMAINDER = 6L;
/* 13:   */   private final int length;
/* 14:   */   
/* 15:   */   public AttributeSynthetic(ByteData raw, ConstantPool cp)
/* 16:   */   {
/* 17:19 */     this.length = raw.getS4At(2L);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public String getRawName()
/* 21:   */   {
/* 22:24 */     return "Synthetic";
/* 23:   */   }
/* 24:   */   
/* 25:   */   public Dumper dump(Dumper d)
/* 26:   */   {
/* 27:29 */     return d;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public long getRawByteLength()
/* 31:   */   {
/* 32:34 */     return 6L + this.length;
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AttributeSynthetic
 * JD-Core Version:    0.7.0.1
 */