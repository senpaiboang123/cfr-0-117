package org.benf.cfr.reader.entities.attributes;

import org.benf.cfr.reader.state.TypeUsageCollector;
import org.benf.cfr.reader.util.KnowsRawName;
import org.benf.cfr.reader.util.KnowsRawSize;
import org.benf.cfr.reader.util.TypeUsageCollectable;
import org.benf.cfr.reader.util.output.Dumpable;
import org.benf.cfr.reader.util.output.Dumper;

public abstract class Attribute
  implements KnowsRawSize, KnowsRawName, Dumpable, TypeUsageCollectable
{
  public abstract Dumper dump(Dumper paramDumper);
  
  public void collectTypeUsages(TypeUsageCollector collector) {}
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.Attribute
 * JD-Core Version:    0.7.0.1
 */