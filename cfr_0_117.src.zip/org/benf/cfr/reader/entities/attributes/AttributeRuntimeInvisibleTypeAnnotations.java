/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  4:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  5:   */ 
/*  6:   */ public class AttributeRuntimeInvisibleTypeAnnotations
/*  7:   */   extends AttributeTypeAnnotations
/*  8:   */ {
/*  9:   */   public static final String ATTRIBUTE_NAME = "RuntimeInvisibleTypeAnnotations";
/* 10:   */   
/* 11:   */   public AttributeRuntimeInvisibleTypeAnnotations(ByteData raw, ConstantPool cp)
/* 12:   */   {
/* 13:10 */     super(raw, cp);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public String getRawName()
/* 17:   */   {
/* 18:15 */     return "RuntimeInvisibleTypeAnnotations";
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String toString()
/* 22:   */   {
/* 23:20 */     return "RuntimeInvisibleTypeAnnotations";
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AttributeRuntimeInvisibleTypeAnnotations
 * JD-Core Version:    0.7.0.1
 */