package org.benf.cfr.reader.entities.attributes;

public abstract interface TypePathAccessor {}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.TypePathAccessor
 * JD-Core Version:    0.7.0.1
 */