package org.benf.cfr.reader.entities.attributes;

public class BadAttributeException
  extends RuntimeException
{}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.BadAttributeException
 * JD-Core Version:    0.7.0.1
 */