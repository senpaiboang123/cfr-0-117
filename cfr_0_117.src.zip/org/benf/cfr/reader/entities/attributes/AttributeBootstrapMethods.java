/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.entities.bootstrap.BootstrapMethodInfo;
/*  5:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  6:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/*  7:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodHandle;
/*  8:   */ import org.benf.cfr.reader.util.ListFactory;
/*  9:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/* 10:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 11:   */ 
/* 12:   */ public class AttributeBootstrapMethods
/* 13:   */   extends Attribute
/* 14:   */ {
/* 15:   */   public static final String ATTRIBUTE_NAME = "BootstrapMethods";
/* 16:   */   private static final long OFFSET_OF_ATTRIBUTE_LENGTH = 2L;
/* 17:   */   private static final long OFFSET_OF_REMAINDER = 6L;
/* 18:   */   private static final long OFFSET_OF_NUM_METHODS = 6L;
/* 19:   */   private final int length;
/* 20:   */   private final List<BootstrapMethodInfo> methodInfoList;
/* 21:   */   
/* 22:   */   public AttributeBootstrapMethods(ByteData raw, ConstantPool cp)
/* 23:   */   {
/* 24:25 */     this.length = raw.getS4At(2L);
/* 25:26 */     this.methodInfoList = decodeMethods(raw, cp);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public BootstrapMethodInfo getBootStrapMethodInfo(int idx)
/* 29:   */   {
/* 30:30 */     if ((idx < 0) || (idx >= this.methodInfoList.size())) {
/* 31:31 */       throw new IllegalArgumentException("Invalid bootstrap index.");
/* 32:   */     }
/* 33:33 */     return (BootstrapMethodInfo)this.methodInfoList.get(idx);
/* 34:   */   }
/* 35:   */   
/* 36:   */   private static List<BootstrapMethodInfo> decodeMethods(ByteData raw, ConstantPool cp)
/* 37:   */   {
/* 38:38 */     List<BootstrapMethodInfo> res = ListFactory.newList();
/* 39:39 */     int numMethods = raw.getS2At(6L);
/* 40:40 */     long offset = 8L;
/* 41:41 */     for (int x = 0; x < numMethods; x++)
/* 42:   */     {
/* 43:42 */       short methodRef = raw.getS2At(offset);
/* 44:43 */       ConstantPoolEntryMethodHandle methodHandle = cp.getMethodHandleEntry(methodRef);
/* 45:   */       
/* 46:45 */       offset += 2L;
/* 47:46 */       short numBootstrapArguments = raw.getS2At(offset);
/* 48:47 */       offset += 2L;
/* 49:48 */       ConstantPoolEntry[] bootstrapArguments = new ConstantPoolEntry[numBootstrapArguments];
/* 50:49 */       for (int y = 0; y < numBootstrapArguments; y++)
/* 51:   */       {
/* 52:50 */         bootstrapArguments[y] = cp.getEntry(raw.getS2At(offset));
/* 53:51 */         offset += 2L;
/* 54:   */       }
/* 55:53 */       res.add(new BootstrapMethodInfo(methodHandle, bootstrapArguments, cp));
/* 56:   */     }
/* 57:55 */     return res;
/* 58:   */   }
/* 59:   */   
/* 60:   */   public String getRawName()
/* 61:   */   {
/* 62:60 */     return "BootstrapMethods";
/* 63:   */   }
/* 64:   */   
/* 65:   */   public Dumper dump(Dumper d)
/* 66:   */   {
/* 67:65 */     return d.print("BootstrapMethods");
/* 68:   */   }
/* 69:   */   
/* 70:   */   public long getRawByteLength()
/* 71:   */   {
/* 72:70 */     return 6L + this.length;
/* 73:   */   }
/* 74:   */   
/* 75:   */   public String toString()
/* 76:   */   {
/* 77:75 */     return "BootstrapMethods";
/* 78:   */   }
/* 79:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AttributeBootstrapMethods
 * JD-Core Version:    0.7.0.1
 */