/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ import java.util.Map.Entry;
/*  4:   */ import java.util.NavigableMap;
/*  5:   */ import java.util.TreeMap;
/*  6:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  7:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  8:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  9:   */ 
/* 10:   */ public class AttributeLineNumberTable
/* 11:   */   extends Attribute
/* 12:   */ {
/* 13:   */   public static final String ATTRIBUTE_NAME = "LineNumberTable";
/* 14:   */   private static final long OFFSET_OF_ATTRIBUTE_LENGTH = 2L;
/* 15:   */   private static final long OFFSET_OF_REMAINDER = 6L;
/* 16:   */   private static final long OFFSET_OF_ENTRY_COUNT = 6L;
/* 17:   */   private static final long OFFSET_OF_ENTRIES = 8L;
/* 18:   */   private final int length;
/* 19:19 */   private final NavigableMap<Integer, Integer> entries = new TreeMap();
/* 20:   */   
/* 21:   */   public AttributeLineNumberTable(ByteData raw, ConstantPool cp)
/* 22:   */   {
/* 23:23 */     this.length = raw.getS4At(2L);
/* 24:24 */     short numLineNumbers = raw.getS2At(6L);
/* 25:25 */     if (numLineNumbers * 2 <= this.length)
/* 26:   */     {
/* 27:26 */       long offset = 8L;
/* 28:27 */       for (int x = 0; x < numLineNumbers; offset += 4L)
/* 29:   */       {
/* 30:28 */         short startPc = raw.getS2At(offset + 0L);
/* 31:29 */         short lineNumber = raw.getS2At(offset + 2L);
/* 32:30 */         this.entries.put(Integer.valueOf(startPc), Integer.valueOf(lineNumber));x++;
/* 33:   */       }
/* 34:   */     }
/* 35:   */   }
/* 36:   */   
/* 37:   */   public boolean hasEntries()
/* 38:   */   {
/* 39:36 */     return !this.entries.isEmpty();
/* 40:   */   }
/* 41:   */   
/* 42:   */   public int getStartLine()
/* 43:   */   {
/* 44:40 */     return ((Integer)this.entries.firstEntry().getValue()).intValue();
/* 45:   */   }
/* 46:   */   
/* 47:   */   public String getRawName()
/* 48:   */   {
/* 49:45 */     return "LineNumberTable";
/* 50:   */   }
/* 51:   */   
/* 52:   */   public Dumper dump(Dumper d)
/* 53:   */   {
/* 54:50 */     return d.print("LineNumberTable");
/* 55:   */   }
/* 56:   */   
/* 57:   */   public long getRawByteLength()
/* 58:   */   {
/* 59:55 */     return 6L + this.length;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public String toString()
/* 63:   */   {
/* 64:60 */     return "LineNumberTable";
/* 65:   */   }
/* 66:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AttributeLineNumberTable
 * JD-Core Version:    0.7.0.1
 */