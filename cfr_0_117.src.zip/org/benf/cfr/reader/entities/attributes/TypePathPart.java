package org.benf.cfr.reader.entities.attributes;

import org.benf.cfr.reader.bytecode.analysis.types.JavaAnnotatedTypeIterator;
import org.benf.cfr.reader.util.DecompilerComments;

public abstract interface TypePathPart
{
  public abstract JavaAnnotatedTypeIterator apply(JavaAnnotatedTypeIterator paramJavaAnnotatedTypeIterator, DecompilerComments paramDecompilerComments);
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.TypePathPart
 * JD-Core Version:    0.7.0.1
 */