/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  4:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryUTF8;
/*  5:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  6:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  7:   */ 
/*  8:   */ public class AttributeSignature
/*  9:   */   extends Attribute
/* 10:   */ {
/* 11:   */   public static final String ATTRIBUTE_NAME = "Signature";
/* 12:   */   private static final long OFFSET_OF_ATTRIBUTE_LENGTH = 2L;
/* 13:   */   private static final long OFFSET_OF_REMAINDER = 6L;
/* 14:   */   private final int length;
/* 15:   */   private final ConstantPool cp;
/* 16:   */   private final ConstantPoolEntryUTF8 signature;
/* 17:   */   
/* 18:   */   public AttributeSignature(ByteData raw, ConstantPool cp)
/* 19:   */   {
/* 20:48 */     this.length = raw.getS4At(2L);
/* 21:49 */     this.cp = cp;
/* 22:50 */     this.signature = cp.getUTF8Entry(raw.getS2At(6L));
/* 23:   */   }
/* 24:   */   
/* 25:   */   public String getRawName()
/* 26:   */   {
/* 27:55 */     return "Signature";
/* 28:   */   }
/* 29:   */   
/* 30:   */   public Dumper dump(Dumper d)
/* 31:   */   {
/* 32:60 */     return d.print("Signature : " + this.signature);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public long getRawByteLength()
/* 36:   */   {
/* 37:65 */     return 6L + this.length;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public ConstantPoolEntryUTF8 getSignature()
/* 41:   */   {
/* 42:69 */     return this.signature;
/* 43:   */   }
/* 44:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AttributeSignature
 * JD-Core Version:    0.7.0.1
 */