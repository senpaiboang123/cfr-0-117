/*   1:    */ package org.benf.cfr.reader.entities.attributes;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Map;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*   9:    */ import org.benf.cfr.reader.entities.annotations.AnnotationTableEntry;
/*  10:    */ import org.benf.cfr.reader.entities.annotations.AnnotationTableTypeEntry;
/*  11:    */ import org.benf.cfr.reader.entities.annotations.ElementValue;
/*  12:    */ import org.benf.cfr.reader.entities.annotations.ElementValueAnnotation;
/*  13:    */ import org.benf.cfr.reader.entities.annotations.ElementValueArray;
/*  14:    */ import org.benf.cfr.reader.entities.annotations.ElementValueClass;
/*  15:    */ import org.benf.cfr.reader.entities.annotations.ElementValueConst;
/*  16:    */ import org.benf.cfr.reader.entities.annotations.ElementValueEnum;
/*  17:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  18:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/*  19:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryUTF8;
/*  20:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolUtils;
/*  21:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  22:    */ import org.benf.cfr.reader.util.ListFactory;
/*  23:    */ import org.benf.cfr.reader.util.MapFactory;
/*  24:    */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  25:    */ 
/*  26:    */ public class AnnotationHelpers
/*  27:    */ {
/*  28:    */   public static Pair<Long, AnnotationTableEntry> getAnnotation(ByteData raw, long offset, ConstantPool cp)
/*  29:    */   {
/*  30: 25 */     ConstantPoolEntryUTF8 typeName = cp.getUTF8Entry(raw.getS2At(offset));
/*  31: 26 */     offset += 2L;
/*  32: 27 */     int numElementPairs = raw.getS2At(offset);
/*  33: 28 */     offset += 2L;
/*  34: 29 */     Map<String, ElementValue> elementValueMap = MapFactory.newLinkedMap();
/*  35: 30 */     for (int x = 0; x < numElementPairs; x++) {
/*  36: 31 */       offset = getElementValuePair(raw, offset, cp, elementValueMap);
/*  37:    */     }
/*  38: 33 */     return new Pair(Long.valueOf(offset), new AnnotationTableEntry(ConstantPoolUtils.decodeTypeTok(typeName.getValue(), cp), elementValueMap));
/*  39:    */   }
/*  40:    */   
/*  41:    */   private static long getElementValuePair(ByteData raw, long offset, ConstantPool cp, Map<String, ElementValue> res)
/*  42:    */   {
/*  43: 37 */     ConstantPoolEntryUTF8 elementName = cp.getUTF8Entry(raw.getS2At(offset));
/*  44: 38 */     offset += 2L;
/*  45: 39 */     Pair<Long, ElementValue> elementValueP = getElementValue(raw, offset, cp);
/*  46: 40 */     offset = ((Long)elementValueP.getFirst()).longValue();
/*  47: 41 */     res.put(elementName.getValue(), elementValueP.getSecond());
/*  48: 42 */     return offset;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static Pair<Long, ElementValue> getElementValue(ByteData raw, long offset, ConstantPool cp)
/*  52:    */   {
/*  53: 47 */     char c = (char)raw.getU1At(offset);
/*  54: 48 */     offset += 1L;
/*  55: 49 */     switch (c)
/*  56:    */     {
/*  57:    */     case 'B': 
/*  58:    */     case 'C': 
/*  59:    */     case 'D': 
/*  60:    */     case 'F': 
/*  61:    */     case 'I': 
/*  62:    */     case 'J': 
/*  63:    */     case 'S': 
/*  64:    */     case 'Z': 
/*  65: 58 */       RawJavaType rawJavaType = ConstantPoolUtils.decodeRawJavaType(c);
/*  66: 59 */       ConstantPoolEntry constantPoolEntry = cp.getEntry(raw.getS2At(offset));
/*  67: 60 */       TypedLiteral typedLiteral = TypedLiteral.getConstantPoolEntry(cp, constantPoolEntry);
/*  68: 61 */       return new Pair(Long.valueOf(offset + 2L), new ElementValueConst(typedLiteral));
/*  69:    */     case 's': 
/*  70: 64 */       ConstantPoolEntry constantPoolEntry = cp.getEntry(raw.getS2At(offset));
/*  71: 65 */       TypedLiteral typedLiteral = TypedLiteral.getConstantPoolEntryUTF8((ConstantPoolEntryUTF8)constantPoolEntry);
/*  72: 66 */       return new Pair(Long.valueOf(offset + 2L), new ElementValueConst(typedLiteral));
/*  73:    */     case 'e': 
/*  74: 69 */       ConstantPoolEntryUTF8 enumClassName = cp.getUTF8Entry(raw.getS2At(offset));
/*  75: 70 */       ConstantPoolEntryUTF8 enumEntryName = cp.getUTF8Entry(raw.getS2At(offset + 2L));
/*  76: 71 */       return new Pair(Long.valueOf(offset + 4L), new ElementValueEnum(ConstantPoolUtils.decodeTypeTok(enumClassName.getValue(), cp), enumEntryName.getValue()));
/*  77:    */     case 'c': 
/*  78: 74 */       ConstantPoolEntryUTF8 className = cp.getUTF8Entry(raw.getS2At(offset));
/*  79: 75 */       String typeName = className.getValue();
/*  80: 76 */       if (typeName.equals("V")) {
/*  81: 77 */         return new Pair(Long.valueOf(offset + 2L), new ElementValueClass(RawJavaType.VOID));
/*  82:    */       }
/*  83: 79 */       return new Pair(Long.valueOf(offset + 2L), new ElementValueClass(ConstantPoolUtils.decodeTypeTok(typeName, cp)));
/*  84:    */     case '@': 
/*  85: 83 */       Pair<Long, AnnotationTableEntry> ape = getAnnotation(raw, offset, cp);
/*  86: 84 */       return new Pair(ape.getFirst(), new ElementValueAnnotation((AnnotationTableEntry)ape.getSecond()));
/*  87:    */     case '[': 
/*  88: 87 */       int numArrayEntries = raw.getS2At(offset);
/*  89: 88 */       offset += 2L;
/*  90: 89 */       List<ElementValue> res = ListFactory.newList();
/*  91: 90 */       for (int x = 0; x < numArrayEntries; x++)
/*  92:    */       {
/*  93: 91 */         Pair<Long, ElementValue> ape = getElementValue(raw, offset, cp);
/*  94: 92 */         offset = ((Long)ape.getFirst()).longValue();
/*  95: 93 */         res.add(ape.getSecond());
/*  96:    */       }
/*  97: 95 */       return new Pair(Long.valueOf(offset), new ElementValueArray(res));
/*  98:    */     }
/*  99: 98 */     throw new ConfusedCFRException("Illegal attribute tag [" + c + "]");
/* 100:    */   }
/* 101:    */   
/* 102:    */   public static Pair<Long, AnnotationTableTypeEntry> getTypeAnnotation(ByteData raw, long offset, ConstantPool cp)
/* 103:    */   {
/* 104:103 */     short targetType = raw.getU1At(offset++);
/* 105:    */     TypeAnnotationEntryKind kind;
/* 106:105 */     switch (targetType)
/* 107:    */     {
/* 108:    */     case 0: 
/* 109:    */     case 1: 
/* 110:108 */       kind = TypeAnnotationEntryKind.type_parameter_target;
/* 111:109 */       break;
/* 112:    */     case 16: 
/* 113:111 */       kind = TypeAnnotationEntryKind.supertype_target;
/* 114:112 */       break;
/* 115:    */     case 17: 
/* 116:    */     case 18: 
/* 117:115 */       kind = TypeAnnotationEntryKind.type_parameter_bound_target;
/* 118:116 */       break;
/* 119:    */     case 19: 
/* 120:    */     case 20: 
/* 121:    */     case 21: 
/* 122:120 */       kind = TypeAnnotationEntryKind.empty_target;
/* 123:121 */       break;
/* 124:    */     case 22: 
/* 125:123 */       kind = TypeAnnotationEntryKind.method_formal_parameter_target;
/* 126:124 */       break;
/* 127:    */     case 23: 
/* 128:126 */       kind = TypeAnnotationEntryKind.throws_target;
/* 129:127 */       break;
/* 130:    */     case 64: 
/* 131:    */     case 65: 
/* 132:130 */       kind = TypeAnnotationEntryKind.localvar_target;
/* 133:131 */       break;
/* 134:    */     case 66: 
/* 135:133 */       kind = TypeAnnotationEntryKind.catch_target;
/* 136:134 */       break;
/* 137:    */     case 67: 
/* 138:    */     case 68: 
/* 139:    */     case 69: 
/* 140:    */     case 70: 
/* 141:139 */       kind = TypeAnnotationEntryKind.offset_target;
/* 142:140 */       break;
/* 143:    */     case 71: 
/* 144:    */     case 72: 
/* 145:    */     case 73: 
/* 146:    */     case 74: 
/* 147:    */     case 75: 
/* 148:146 */       kind = TypeAnnotationEntryKind.localvar_target;
/* 149:147 */       break;
/* 150:    */     case 2: 
/* 151:    */     case 3: 
/* 152:    */     case 4: 
/* 153:    */     case 5: 
/* 154:    */     case 6: 
/* 155:    */     case 7: 
/* 156:    */     case 8: 
/* 157:    */     case 9: 
/* 158:    */     case 10: 
/* 159:    */     case 11: 
/* 160:    */     case 12: 
/* 161:    */     case 13: 
/* 162:    */     case 14: 
/* 163:    */     case 15: 
/* 164:    */     case 24: 
/* 165:    */     case 25: 
/* 166:    */     case 26: 
/* 167:    */     case 27: 
/* 168:    */     case 28: 
/* 169:    */     case 29: 
/* 170:    */     case 30: 
/* 171:    */     case 31: 
/* 172:    */     case 32: 
/* 173:    */     case 33: 
/* 174:    */     case 34: 
/* 175:    */     case 35: 
/* 176:    */     case 36: 
/* 177:    */     case 37: 
/* 178:    */     case 38: 
/* 179:    */     case 39: 
/* 180:    */     case 40: 
/* 181:    */     case 41: 
/* 182:    */     case 42: 
/* 183:    */     case 43: 
/* 184:    */     case 44: 
/* 185:    */     case 45: 
/* 186:    */     case 46: 
/* 187:    */     case 47: 
/* 188:    */     case 48: 
/* 189:    */     case 49: 
/* 190:    */     case 50: 
/* 191:    */     case 51: 
/* 192:    */     case 52: 
/* 193:    */     case 53: 
/* 194:    */     case 54: 
/* 195:    */     case 55: 
/* 196:    */     case 56: 
/* 197:    */     case 57: 
/* 198:    */     case 58: 
/* 199:    */     case 59: 
/* 200:    */     case 60: 
/* 201:    */     case 61: 
/* 202:    */     case 62: 
/* 203:    */     case 63: 
/* 204:    */     default: 
/* 205:150 */       throw new BadAttributeException();
/* 206:    */     }
/* 207:    */     TypeAnnotationLocation location;
/* 208:153 */     switch (targetType)
/* 209:    */     {
/* 210:    */     case 0: 
/* 211:    */     case 16: 
/* 212:    */     case 17: 
/* 213:157 */       location = TypeAnnotationLocation.ClassFile;
/* 214:158 */       break;
/* 215:    */     case 1: 
/* 216:    */     case 18: 
/* 217:    */     case 20: 
/* 218:    */     case 21: 
/* 219:    */     case 22: 
/* 220:    */     case 23: 
/* 221:165 */       location = TypeAnnotationLocation.method_info;
/* 222:166 */       break;
/* 223:    */     case 19: 
/* 224:168 */       location = TypeAnnotationLocation.field_info;
/* 225:169 */       break;
/* 226:    */     case 2: 
/* 227:    */     case 3: 
/* 228:    */     case 4: 
/* 229:    */     case 5: 
/* 230:    */     case 6: 
/* 231:    */     case 7: 
/* 232:    */     case 8: 
/* 233:    */     case 9: 
/* 234:    */     case 10: 
/* 235:    */     case 11: 
/* 236:    */     case 12: 
/* 237:    */     case 13: 
/* 238:    */     case 14: 
/* 239:    */     case 15: 
/* 240:    */     default: 
/* 241:171 */       location = TypeAnnotationLocation.Code;
/* 242:    */     }
/* 243:174 */     Pair<Long, TypeAnnotationTargetInfo> targetInfoPair = readTypeAnnotationTargetInfo(kind, raw, offset);
/* 244:175 */     offset = ((Long)targetInfoPair.getFirst()).longValue();
/* 245:176 */     TypeAnnotationTargetInfo targetInfo = (TypeAnnotationTargetInfo)targetInfoPair.getSecond();
/* 246:    */     
/* 247:178 */     short type_path_length = raw.getU1At(offset++);
/* 248:179 */     List<TypePathPart> pathData = ListFactory.newList();
/* 249:180 */     for (int x = 0; x < type_path_length; x++)
/* 250:    */     {
/* 251:181 */       short type_path_kind = raw.getU1At(offset++);
/* 252:182 */       short type_argument_index = raw.getU1At(offset++);
/* 253:183 */       switch (type_path_kind)
/* 254:    */       {
/* 255:    */       case 0: 
/* 256:185 */         pathData.add(TypePathPartArray.INSTANCE);
/* 257:186 */         break;
/* 258:    */       case 1: 
/* 259:188 */         pathData.add(TypePathPartNested.INSTANCE);
/* 260:189 */         break;
/* 261:    */       case 2: 
/* 262:191 */         pathData.add(TypePathPartBound.INSTANCE);
/* 263:192 */         break;
/* 264:    */       case 3: 
/* 265:194 */         pathData.add(new TypePathPartParameterized(type_argument_index));
/* 266:    */       }
/* 267:    */     }
/* 268:198 */     TypePath path = new TypePath(pathData);
/* 269:    */     
/* 270:200 */     int type_index = raw.getU2At(offset);
/* 271:201 */     offset += 2L;
/* 272:202 */     ConstantPoolEntryUTF8 type_entry = cp.getUTF8Entry(type_index);
/* 273:203 */     JavaTypeInstance type = ConstantPoolUtils.decodeTypeTok(type_entry.getValue(), cp);
/* 274:    */     
/* 275:    */ 
/* 276:206 */     int numElementPairs = raw.getS2At(offset);
/* 277:207 */     offset += 2L;
/* 278:208 */     Map<String, ElementValue> elementValueMap = MapFactory.newLinkedMap();
/* 279:209 */     for (int x = 0; x < numElementPairs; x++) {
/* 280:210 */       offset = getElementValuePair(raw, offset, cp, elementValueMap);
/* 281:    */     }
/* 282:213 */     AnnotationTableTypeEntry res = new AnnotationTableTypeEntry(kind, location, targetInfo, path, type, elementValueMap);
/* 283:    */     
/* 284:215 */     return new Pair(Long.valueOf(offset), res);
/* 285:    */   }
/* 286:    */   
/* 287:    */   public static Pair<Long, TypeAnnotationTargetInfo> readTypeAnnotationTargetInfo(TypeAnnotationEntryKind kind, ByteData raw, long offset)
/* 288:    */   {
/* 289:220 */     switch (1.$SwitchMap$org$benf$cfr$reader$entities$attributes$TypeAnnotationEntryKind[kind.ordinal()])
/* 290:    */     {
/* 291:    */     case 1: 
/* 292:222 */       return TypeAnnotationTargetInfo.TypeAnnotationParameterTarget.Read(raw, offset);
/* 293:    */     case 2: 
/* 294:224 */       return TypeAnnotationTargetInfo.TypeAnnotationSupertypeTarget.Read(raw, offset);
/* 295:    */     case 3: 
/* 296:226 */       return TypeAnnotationTargetInfo.TypeAnnotationParameterBoundTarget.Read(raw, offset);
/* 297:    */     case 4: 
/* 298:228 */       return TypeAnnotationTargetInfo.TypeAnnotationEmptyTarget.Read(raw, offset);
/* 299:    */     case 5: 
/* 300:230 */       return TypeAnnotationTargetInfo.TypeAnnotationFormalParameterTarget.Read(raw, offset);
/* 301:    */     case 6: 
/* 302:232 */       return TypeAnnotationTargetInfo.TypeAnnotationThrowsTarget.Read(raw, offset);
/* 303:    */     case 7: 
/* 304:234 */       return TypeAnnotationTargetInfo.TypeAnnotationLocalVarTarget.Read(raw, offset);
/* 305:    */     case 8: 
/* 306:236 */       return TypeAnnotationTargetInfo.TypeAnnotationCatchTarget.Read(raw, offset);
/* 307:    */     case 9: 
/* 308:238 */       return TypeAnnotationTargetInfo.TypeAnnotationOffsetTarget.Read(raw, offset);
/* 309:    */     case 10: 
/* 310:240 */       return TypeAnnotationTargetInfo.TypeAnnotationTypeArgumentTarget.Read(raw, offset);
/* 311:    */     }
/* 312:242 */     throw new BadAttributeException();
/* 313:    */   }
/* 314:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AnnotationHelpers
 * JD-Core Version:    0.7.0.1
 */