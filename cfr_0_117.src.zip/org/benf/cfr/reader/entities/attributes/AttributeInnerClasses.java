/*   1:    */ package org.benf.cfr.reader.entities.attributes;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.types.InnerClassInfo;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*   7:    */ import org.benf.cfr.reader.entities.AccessFlag;
/*   8:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*   9:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass;
/*  10:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryUTF8;
/*  11:    */ import org.benf.cfr.reader.entities.innerclass.InnerClassAttributeInfo;
/*  12:    */ import org.benf.cfr.reader.util.ListFactory;
/*  13:    */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  14:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  15:    */ 
/*  16:    */ public class AttributeInnerClasses
/*  17:    */   extends Attribute
/*  18:    */ {
/*  19:    */   public static final String ATTRIBUTE_NAME = "InnerClasses";
/*  20:    */   private static final long OFFSET_OF_ATTRIBUTE_LENGTH = 2L;
/*  21:    */   private static final long OFFSET_OF_REMAINDER = 6L;
/*  22:    */   private static final long OFFSET_OF_NUMBER_OF_CLASSES = 6L;
/*  23:    */   private static final long OFFSET_OF_CLASS_ARRAY = 8L;
/*  24:    */   private final int length;
/*  25: 25 */   private final List<InnerClassAttributeInfo> innerClassAttributeInfoList = ListFactory.newList();
/*  26:    */   
/*  27:    */   private static JavaTypeInstance getOptClass(int idx, ConstantPool cp)
/*  28:    */   {
/*  29: 28 */     if (idx == 0) {
/*  30: 29 */       return null;
/*  31:    */     }
/*  32: 31 */     return cp.getClassEntry(idx).getTypeInstance();
/*  33:    */   }
/*  34:    */   
/*  35:    */   private static String getOptName(int idx, ConstantPool cp)
/*  36:    */   {
/*  37: 35 */     if (idx == 0) {
/*  38: 36 */       return null;
/*  39:    */     }
/*  40: 38 */     return cp.getUTF8Entry(idx).getValue();
/*  41:    */   }
/*  42:    */   
/*  43:    */   private static Pair<JavaTypeInstance, JavaTypeInstance> getInnerOuter(int idxinner, int idxouter, ConstantPool cp)
/*  44:    */   {
/*  45: 42 */     if ((idxinner == 0) || (idxouter == 0)) {
/*  46: 43 */       return Pair.make(getOptClass(idxinner, cp), getOptClass(idxouter, cp));
/*  47:    */     }
/*  48: 45 */     ConstantPoolEntryClass cpecInner = cp.getClassEntry(idxinner);
/*  49: 46 */     ConstantPoolEntryClass cpecOuter = cp.getClassEntry(idxouter);
/*  50: 47 */     JavaTypeInstance innerType = cpecInner.getTypeInstanceKnownOuter(cpecOuter);
/*  51: 48 */     JavaTypeInstance outerType = cpecInner.getTypeInstanceKnownInner(cpecOuter);
/*  52: 49 */     return Pair.make(innerType, outerType);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public AttributeInnerClasses(ByteData raw, ConstantPool cp)
/*  56:    */   {
/*  57: 53 */     this.length = raw.getS4At(2L);
/*  58: 54 */     int numberInnerClasses = raw.getS2At(6L);
/*  59: 55 */     long offset = 8L;
/*  60: 56 */     for (int x = 0; x < numberInnerClasses; x++)
/*  61:    */     {
/*  62: 57 */       short innerClassInfoIdx = raw.getS2At(offset);
/*  63: 58 */       offset += 2L;
/*  64: 59 */       short outerClassInfoIdx = raw.getS2At(offset);
/*  65: 60 */       offset += 2L;
/*  66: 61 */       short innerNameIdx = raw.getS2At(offset);
/*  67: 62 */       offset += 2L;
/*  68: 63 */       int innerAccessFlags = raw.getS2At(offset);
/*  69: 64 */       offset += 2L;
/*  70: 65 */       Pair<JavaTypeInstance, JavaTypeInstance> innerOuter = getInnerOuter(innerClassInfoIdx, outerClassInfoIdx, cp);
/*  71: 66 */       JavaTypeInstance innerClassType = (JavaTypeInstance)innerOuter.getFirst();
/*  72: 67 */       JavaTypeInstance outerClassType = (JavaTypeInstance)innerOuter.getSecond();
/*  73: 72 */       if (outerClassType == null)
/*  74:    */       {
/*  75: 73 */         boolean methodScoped = innerNameIdx == 0;
/*  76: 74 */         innerClassType.getInnerClassHereInfo().markMethodScoped(methodScoped);
/*  77:    */       }
/*  78: 76 */       this.innerClassAttributeInfoList.add(new InnerClassAttributeInfo(innerClassType, outerClassType, getOptName(innerNameIdx, cp), AccessFlag.build(innerAccessFlags)));
/*  79:    */     }
/*  80:    */   }
/*  81:    */   
/*  82:    */   public String getRawName()
/*  83:    */   {
/*  84: 87 */     return "InnerClasses";
/*  85:    */   }
/*  86:    */   
/*  87:    */   public Dumper dump(Dumper d)
/*  88:    */   {
/*  89: 92 */     return d.print("InnerClasses");
/*  90:    */   }
/*  91:    */   
/*  92:    */   public long getRawByteLength()
/*  93:    */   {
/*  94: 97 */     return 6L + this.length;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public List<InnerClassAttributeInfo> getInnerClassAttributeInfoList()
/*  98:    */   {
/*  99:101 */     return this.innerClassAttributeInfoList;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public String toString()
/* 103:    */   {
/* 104:106 */     return "InnerClasses";
/* 105:    */   }
/* 106:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AttributeInnerClasses
 * JD-Core Version:    0.7.0.1
 */