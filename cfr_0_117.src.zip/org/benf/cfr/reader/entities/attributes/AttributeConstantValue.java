/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  4:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/*  5:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  6:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  7:   */ 
/*  8:   */ public class AttributeConstantValue
/*  9:   */   extends Attribute
/* 10:   */ {
/* 11:   */   public static final String ATTRIBUTE_NAME = "ConstantValue";
/* 12:   */   private static final long OFFSET_OF_ATTRIBUTE_LENGTH = 2L;
/* 13:   */   private static final long OFFSET_OF_REMAINDER = 6L;
/* 14:   */   private final int length;
/* 15:   */   private final ConstantPoolEntry value;
/* 16:   */   
/* 17:   */   public AttributeConstantValue(ByteData raw, ConstantPool cp)
/* 18:   */   {
/* 19:18 */     this.length = raw.getS4At(2L);
/* 20:19 */     this.value = cp.getEntry(raw.getS2At(6L));
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String getRawName()
/* 24:   */   {
/* 25:24 */     return "ConstantValue";
/* 26:   */   }
/* 27:   */   
/* 28:   */   public Dumper dump(Dumper d)
/* 29:   */   {
/* 30:29 */     return d.print("ConstantValue : " + this.value);
/* 31:   */   }
/* 32:   */   
/* 33:   */   public long getRawByteLength()
/* 34:   */   {
/* 35:34 */     return 6L + this.length;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public String toString()
/* 39:   */   {
/* 40:39 */     return "ConstantValue : " + this.value;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public ConstantPoolEntry getValue()
/* 44:   */   {
/* 45:43 */     return this.value;
/* 46:   */   }
/* 47:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AttributeConstantValue
 * JD-Core Version:    0.7.0.1
 */