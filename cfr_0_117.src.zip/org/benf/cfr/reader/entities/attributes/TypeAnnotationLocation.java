package org.benf.cfr.reader.entities.attributes;

public enum TypeAnnotationLocation
{
  ClassFile,  method_info,  field_info,  Code;
  
  private TypeAnnotationLocation() {}
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.TypeAnnotationLocation
 * JD-Core Version:    0.7.0.1
 */