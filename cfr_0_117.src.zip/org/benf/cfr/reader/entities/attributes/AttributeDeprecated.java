/*  1:   */ package org.benf.cfr.reader.entities.attributes;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  4:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  5:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  6:   */ 
/*  7:   */ public class AttributeDeprecated
/*  8:   */   extends Attribute
/*  9:   */ {
/* 10:   */   public static final String ATTRIBUTE_NAME = "Deprecated";
/* 11:   */   private static final long OFFSET_OF_ATTRIBUTE_LENGTH = 2L;
/* 12:   */   private static final long OFFSET_OF_REMAINDER = 6L;
/* 13:   */   private final int length;
/* 14:   */   private final ConstantPool cp;
/* 15:   */   
/* 16:   */   public AttributeDeprecated(ByteData raw, ConstantPool cp)
/* 17:   */   {
/* 18:18 */     this.length = raw.getS4At(2L);
/* 19:19 */     this.cp = cp;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String getRawName()
/* 23:   */   {
/* 24:24 */     return "Deprecated";
/* 25:   */   }
/* 26:   */   
/* 27:   */   public Dumper dump(Dumper d)
/* 28:   */   {
/* 29:29 */     return d.print("Deprecated");
/* 30:   */   }
/* 31:   */   
/* 32:   */   public long getRawByteLength()
/* 33:   */   {
/* 34:34 */     return 6L + this.length;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public String toString()
/* 38:   */   {
/* 39:39 */     return "Deprecated";
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.attributes.AttributeDeprecated
 * JD-Core Version:    0.7.0.1
 */