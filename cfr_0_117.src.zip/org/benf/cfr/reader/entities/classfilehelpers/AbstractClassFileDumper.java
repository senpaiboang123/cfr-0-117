/*   1:    */ package org.benf.cfr.reader.entities.classfilehelpers;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Set;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.types.ClassSignature;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.types.FormalTypeParameter;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.types.InnerClassInfo;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.types.InnerClassInfoUtils;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  13:    */ import org.benf.cfr.reader.entities.AccessFlag;
/*  14:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  15:    */ import org.benf.cfr.reader.entities.attributes.AttributeRuntimeInvisibleAnnotations;
/*  16:    */ import org.benf.cfr.reader.entities.attributes.AttributeRuntimeVisibleAnnotations;
/*  17:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass;
/*  18:    */ import org.benf.cfr.reader.state.DCCommonState;
/*  19:    */ import org.benf.cfr.reader.state.TypeUsageInformation;
/*  20:    */ import org.benf.cfr.reader.util.CannotLoadClassException;
/*  21:    */ import org.benf.cfr.reader.util.DecompilerComments;
/*  22:    */ import org.benf.cfr.reader.util.Functional;
/*  23:    */ import org.benf.cfr.reader.util.ListFactory;
/*  24:    */ import org.benf.cfr.reader.util.Predicate;
/*  25:    */ import org.benf.cfr.reader.util.StringUtils;
/*  26:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  27:    */ import org.benf.cfr.reader.util.getopt.Options;
/*  28:    */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*  29:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  30:    */ 
/*  31:    */ public abstract class AbstractClassFileDumper
/*  32:    */   implements ClassFileDumper
/*  33:    */ {
/*  34:    */   private final DCCommonState dcCommonState;
/*  35:    */   
/*  36:    */   protected static String getAccessFlagsString(Set<AccessFlag> accessFlags, AccessFlag[] dumpableAccessFlags)
/*  37:    */   {
/*  38: 25 */     StringBuilder sb = new StringBuilder();
/*  39: 27 */     for (AccessFlag accessFlag : dumpableAccessFlags) {
/*  40: 28 */       if (accessFlags.contains(accessFlag)) {
/*  41: 28 */         sb.append(accessFlag).append(' ');
/*  42:    */       }
/*  43:    */     }
/*  44: 30 */     return sb.toString();
/*  45:    */   }
/*  46:    */   
/*  47:    */   public AbstractClassFileDumper(DCCommonState dcCommonState)
/*  48:    */   {
/*  49: 36 */     this.dcCommonState = dcCommonState;
/*  50:    */   }
/*  51:    */   
/*  52:    */   protected void dumpTopHeader(ClassFile classFile, Dumper d)
/*  53:    */   {
/*  54: 40 */     if (this.dcCommonState == null) {
/*  55: 40 */       return;
/*  56:    */     }
/*  57: 41 */     Options options = this.dcCommonState.getOptions();
/*  58: 42 */     String header = "Decompiled with CFR" + (((Boolean)options.getOption(OptionsImpl.SHOW_CFR_VERSION)).booleanValue() ? " 0_117" : "") + ".";
/*  59:    */     
/*  60: 44 */     d.print("/*").newln();
/*  61: 45 */     d.print(" * ").print(header).newln();
/*  62: 46 */     if (((Boolean)options.getOption(OptionsImpl.DECOMPILER_COMMENTS)).booleanValue())
/*  63:    */     {
/*  64: 47 */       TypeUsageInformation typeUsageInformation = d.getTypeUsageInformation();
/*  65: 48 */       List<JavaTypeInstance> couldNotLoad = ListFactory.newList();
/*  66: 49 */       for (JavaTypeInstance type : typeUsageInformation.getUsedClassTypes()) {
/*  67: 50 */         if ((type instanceof JavaRefTypeInstance))
/*  68:    */         {
/*  69: 51 */           ClassFile loadedClass = null;
/*  70:    */           try
/*  71:    */           {
/*  72: 53 */             loadedClass = this.dcCommonState.getClassFile(type);
/*  73:    */           }
/*  74:    */           catch (CannotLoadClassException e) {}
/*  75: 56 */           if (loadedClass == null) {
/*  76: 57 */             couldNotLoad.add(type);
/*  77:    */           }
/*  78:    */         }
/*  79:    */       }
/*  80: 61 */       if (!couldNotLoad.isEmpty())
/*  81:    */       {
/*  82: 62 */         d.print(" * ").newln();
/*  83: 63 */         d.print(" * Could not load the following classes:").newln();
/*  84: 64 */         for (JavaTypeInstance type : couldNotLoad) {
/*  85: 65 */           d.print(" *  ").print(type.getRawName()).newln();
/*  86:    */         }
/*  87:    */       }
/*  88:    */     }
/*  89: 69 */     d.print(" */").newln();
/*  90: 70 */     String packageName = classFile.getThisClassConstpoolEntry().getPackageName();
/*  91: 71 */     if (!packageName.isEmpty()) {
/*  92: 74 */       d.print("package ").print(packageName).endCodeln().newln();
/*  93:    */     }
/*  94:    */   }
/*  95:    */   
/*  96:    */   protected static void getFormalParametersText(ClassSignature signature, Dumper d)
/*  97:    */   {
/*  98: 79 */     List<FormalTypeParameter> formalTypeParameters = signature.getFormalTypeParameters();
/*  99: 80 */     if ((formalTypeParameters == null) || (formalTypeParameters.isEmpty())) {
/* 100: 80 */       return;
/* 101:    */     }
/* 102: 81 */     d.print('<');
/* 103: 82 */     boolean first = true;
/* 104: 83 */     for (FormalTypeParameter formalTypeParameter : formalTypeParameters)
/* 105:    */     {
/* 106: 84 */       first = StringUtils.comma(first, d);
/* 107: 85 */       d.dump(formalTypeParameter);
/* 108:    */     }
/* 109: 87 */     d.print('>');
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void dumpImports(Dumper d, ClassFile classFile)
/* 113:    */   {
/* 114: 91 */     List<JavaTypeInstance> classTypes = classFile.getAllClassTypes();
/* 115: 92 */     Set<JavaRefTypeInstance> types = d.getTypeUsageInformation().getShortenedClassTypes();
/* 116: 93 */     types.removeAll(classTypes);
/* 117:    */     
/* 118:    */ 
/* 119:    */ 
/* 120: 97 */     List<JavaRefTypeInstance> inners = Functional.filter(types, new Predicate()
/* 121:    */     {
/* 122:    */       public boolean test(JavaRefTypeInstance in)
/* 123:    */       {
/* 124:100 */         return in.getInnerClassHereInfo().isInnerClass();
/* 125:    */       }
/* 126:102 */     });
/* 127:103 */     types.removeAll(inners);
/* 128:104 */     for (JavaRefTypeInstance inner : inners) {
/* 129:105 */       types.add(InnerClassInfoUtils.getTransitiveOuterClass(inner));
/* 130:    */     }
/* 131:113 */     types.removeAll(Functional.filter(types, new Predicate()
/* 132:    */     {
/* 133:    */       public boolean test(JavaRefTypeInstance in)
/* 134:    */       {
/* 135:116 */         if ("".equals(in.getPackageName())) {
/* 136:116 */           return true;
/* 137:    */         }
/* 138:117 */         return false;
/* 139:    */       }
/* 140:120 */     }));
/* 141:121 */     Options options = this.dcCommonState.getOptions();
/* 142:    */     
/* 143:123 */     Collection<JavaRefTypeInstance> importTypes = types;
/* 144:124 */     if (((Boolean)options.getOption(OptionsImpl.HIDE_LANG_IMPORTS)).booleanValue()) {
/* 145:125 */       importTypes = Functional.filter(importTypes, new Predicate()
/* 146:    */       {
/* 147:    */         public boolean test(JavaRefTypeInstance in)
/* 148:    */         {
/* 149:128 */           if ("java.lang".equals(in.getPackageName())) {
/* 150:128 */             return false;
/* 151:    */           }
/* 152:129 */           return true;
/* 153:    */         }
/* 154:    */       });
/* 155:    */     }
/* 156:134 */     List<String> names = Functional.map(importTypes, new UnaryFunction()
/* 157:    */     {
/* 158:    */       public String invoke(JavaRefTypeInstance arg)
/* 159:    */       {
/* 160:137 */         if (arg.getInnerClassHereInfo().isInnerClass())
/* 161:    */         {
/* 162:138 */           String name = arg.getRawName();
/* 163:139 */           return name.replace('$', '.');
/* 164:    */         }
/* 165:141 */         return arg.getRawName();
/* 166:    */       }
/* 167:    */     });
/* 168:145 */     if (names.isEmpty()) {
/* 169:145 */       return;
/* 170:    */     }
/* 171:146 */     Collections.sort(names);
/* 172:147 */     for (String name : names) {
/* 173:148 */       d.print("import " + name + ";\n");
/* 174:    */     }
/* 175:150 */     d.print("\n");
/* 176:    */   }
/* 177:    */   
/* 178:    */   protected void dumpComments(ClassFile classFile, Dumper d)
/* 179:    */   {
/* 180:154 */     DecompilerComments comments = classFile.getDecompilerComments();
/* 181:155 */     if (comments == null) {
/* 182:155 */       return;
/* 183:    */     }
/* 184:156 */     comments.dump(d);
/* 185:    */   }
/* 186:    */   
/* 187:    */   protected void dumpAnnotations(ClassFile classFile, Dumper d)
/* 188:    */   {
/* 189:160 */     AttributeRuntimeVisibleAnnotations runtimeVisibleAnnotations = (AttributeRuntimeVisibleAnnotations)classFile.getAttributeByName("RuntimeVisibleAnnotations");
/* 190:161 */     AttributeRuntimeInvisibleAnnotations runtimeInvisibleAnnotations = (AttributeRuntimeInvisibleAnnotations)classFile.getAttributeByName("RuntimeInvisibleAnnotations");
/* 191:162 */     if (runtimeVisibleAnnotations != null) {
/* 192:162 */       runtimeVisibleAnnotations.dump(d);
/* 193:    */     }
/* 194:163 */     if (runtimeInvisibleAnnotations != null) {
/* 195:163 */       runtimeInvisibleAnnotations.dump(d);
/* 196:    */     }
/* 197:    */   }
/* 198:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.classfilehelpers.AbstractClassFileDumper
 * JD-Core Version:    0.7.0.1
 */