/*   1:    */ package org.benf.cfr.reader.entities.classfilehelpers;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Set;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.Literal;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.types.BindingSuperContainer;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.types.GenericTypeBinder;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericBaseInstance;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericRefTypeInstance;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.types.TypeConstants;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.types.discovery.InferredJavaType;
/*  22:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  23:    */ import org.benf.cfr.reader.util.Functional;
/*  24:    */ import org.benf.cfr.reader.util.ListFactory;
/*  25:    */ import org.benf.cfr.reader.util.MapFactory;
/*  26:    */ import org.benf.cfr.reader.util.Predicate;
/*  27:    */ import org.benf.cfr.reader.util.SetFactory;
/*  28:    */ import org.benf.cfr.reader.util.SetUtil;
/*  29:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  30:    */ 
/*  31:    */ public class OverloadMethodSet
/*  32:    */ {
/*  33:    */   private final ClassFile classFile;
/*  34:    */   private final MethodData actualPrototype;
/*  35:    */   private final List<MethodData> allPrototypes;
/*  36:    */   
/*  37:    */   private static class MethodData
/*  38:    */   {
/*  39:    */     private final MethodPrototype methodPrototype;
/*  40:    */     private final List<JavaTypeInstance> methodArgs;
/*  41:    */     private final int size;
/*  42:    */     
/*  43:    */     private MethodData(MethodPrototype methodPrototype, List<JavaTypeInstance> methodArgs)
/*  44:    */     {
/*  45: 37 */       this.methodPrototype = methodPrototype;
/*  46: 38 */       this.methodArgs = methodArgs;
/*  47: 39 */       this.size = methodArgs.size();
/*  48:    */     }
/*  49:    */     
/*  50:    */     private JavaTypeInstance getArgType(int idx, JavaTypeInstance used)
/*  51:    */     {
/*  52: 43 */       if ((idx >= this.size - 1) && (this.methodPrototype.isVarArgs()))
/*  53:    */       {
/*  54: 44 */         JavaTypeInstance res = (JavaTypeInstance)this.methodArgs.get(this.size - 1);
/*  55: 45 */         if (res.getNumArrayDimensions() == used.getNumArrayDimensions() + 1) {
/*  56: 46 */           return res.removeAnArrayIndirection();
/*  57:    */         }
/*  58: 48 */         return res;
/*  59:    */       }
/*  60: 50 */       if (idx >= this.size) {
/*  61: 51 */         return null;
/*  62:    */       }
/*  63: 53 */       return (JavaTypeInstance)this.methodArgs.get(idx);
/*  64:    */     }
/*  65:    */     
/*  66:    */     public boolean isVararg(int idx)
/*  67:    */     {
/*  68: 57 */       return (idx >= this.size - 1) && (this.methodPrototype.isVarArgs());
/*  69:    */     }
/*  70:    */     
/*  71:    */     public boolean is(MethodData other)
/*  72:    */     {
/*  73: 61 */       return this.methodPrototype == other.methodPrototype;
/*  74:    */     }
/*  75:    */     
/*  76:    */     public String toString()
/*  77:    */     {
/*  78: 67 */       return this.methodPrototype.toString();
/*  79:    */     }
/*  80:    */     
/*  81:    */     private MethodData getBoundVersion(final GenericTypeBinder genericTypeBinder)
/*  82:    */     {
/*  83: 71 */       List<JavaTypeInstance> rebound = Functional.map(this.methodArgs, new UnaryFunction()
/*  84:    */       {
/*  85:    */         public JavaTypeInstance invoke(JavaTypeInstance arg)
/*  86:    */         {
/*  87: 74 */           if ((arg instanceof JavaGenericBaseInstance)) {
/*  88: 75 */             return ((JavaGenericBaseInstance)arg).getBoundInstance(genericTypeBinder);
/*  89:    */           }
/*  90: 77 */           return arg;
/*  91:    */         }
/*  92: 81 */       });
/*  93: 82 */       return new MethodData(this.methodPrototype, rebound);
/*  94:    */     }
/*  95:    */   }
/*  96:    */   
/*  97:    */   public OverloadMethodSet(ClassFile classFile, MethodPrototype actualPrototype, List<MethodPrototype> allPrototypes)
/*  98:    */   {
/*  99: 90 */     this.classFile = classFile;
/* 100: 91 */     UnaryFunction<MethodPrototype, MethodData> mk = new UnaryFunction()
/* 101:    */     {
/* 102:    */       public OverloadMethodSet.MethodData invoke(MethodPrototype arg)
/* 103:    */       {
/* 104: 94 */         return new OverloadMethodSet.MethodData(arg, arg.getArgs(), null);
/* 105:    */       }
/* 106: 96 */     };
/* 107: 97 */     this.actualPrototype = ((MethodData)mk.invoke(actualPrototype));
/* 108: 98 */     this.allPrototypes = Functional.map(allPrototypes, mk);
/* 109:    */   }
/* 110:    */   
/* 111:    */   private OverloadMethodSet(ClassFile classFile, MethodData actualPrototype, List<MethodData> allPrototypes)
/* 112:    */   {
/* 113:102 */     this.classFile = classFile;
/* 114:103 */     this.actualPrototype = actualPrototype;
/* 115:104 */     this.allPrototypes = allPrototypes;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public OverloadMethodSet specialiseTo(JavaGenericRefTypeInstance type)
/* 119:    */   {
/* 120:108 */     final GenericTypeBinder genericTypeBinder = this.classFile.getGenericTypeBinder(type);
/* 121:109 */     if (genericTypeBinder == null) {
/* 122:109 */       return null;
/* 123:    */     }
/* 124:110 */     UnaryFunction<MethodData, MethodData> mk = new UnaryFunction()
/* 125:    */     {
/* 126:    */       public OverloadMethodSet.MethodData invoke(OverloadMethodSet.MethodData arg)
/* 127:    */       {
/* 128:113 */         return arg.getBoundVersion(genericTypeBinder);
/* 129:    */       }
/* 130:115 */     };
/* 131:116 */     return new OverloadMethodSet(this.classFile, (MethodData)mk.invoke(this.actualPrototype), Functional.map(this.allPrototypes, mk));
/* 132:    */   }
/* 133:    */   
/* 134:    */   public JavaTypeInstance getArgType(int idx, JavaTypeInstance used)
/* 135:    */   {
/* 136:120 */     return this.actualPrototype.getArgType(idx, used);
/* 137:    */   }
/* 138:    */   
/* 139:    */   public boolean callsCorrectEntireMethod(List<Expression> args, GenericTypeBinder gtb)
/* 140:    */   {
/* 141:125 */     final int argCount = args.size();
/* 142:    */     
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:130 */     Set<MethodData> possibleMatches = SetFactory.newSet(Functional.filter(this.allPrototypes, new Predicate()
/* 147:    */     {
/* 148:    */       public boolean test(OverloadMethodSet.MethodData in)
/* 149:    */       {
/* 150:134 */         return in.methodArgs.size() <= argCount;
/* 151:    */       }
/* 152:138 */     }));
/* 153:139 */     Map<Integer, Set<MethodData>> weakMatches = MapFactory.newLazyMap(new UnaryFunction()
/* 154:    */     {
/* 155:    */       public Set<OverloadMethodSet.MethodData> invoke(Integer arg)
/* 156:    */       {
/* 157:142 */         return SetFactory.newSet();
/* 158:    */       }
/* 159:145 */     });
/* 160:146 */     int x = 0;
/* 161:146 */     for (int len = args.size(); x < len; x++)
/* 162:    */     {
/* 163:147 */       Expression arg = (Expression)args.get(x);
/* 164:148 */       boolean isNull = Literal.NULL.equals(arg);
/* 165:149 */       JavaTypeInstance actual = arg.getInferredJavaType().getJavaTypeInstance();
/* 166:150 */       actual = actual.getDeGenerifiedType();
/* 167:151 */       Iterator<MethodData> possiter = possibleMatches.iterator();
/* 168:152 */       while (possiter.hasNext())
/* 169:    */       {
/* 170:153 */         MethodData prototype = (MethodData)possiter.next();
/* 171:154 */         JavaTypeInstance argType = prototype.getArgType(x, actual);
/* 172:155 */         if (argType != null)
/* 173:    */         {
/* 174:156 */           argType = argType.getDeGenerifiedType();
/* 175:160 */           if (isNull)
/* 176:    */           {
/* 177:161 */             if (argType.isObject())
/* 178:    */             {
/* 179:162 */               if (TypeConstants.OBJECT.equals(argType)) {
/* 180:163 */                 ((Set)weakMatches.get(Integer.valueOf(x))).add(prototype);
/* 181:    */               }
/* 182:    */             }
/* 183:    */             else {
/* 184:167 */               possiter.remove();
/* 185:    */             }
/* 186:    */           }
/* 187:172 */           else if ((actual.implicitlyCastsTo(argType, gtb)) && (actual.impreciseCanCastTo(argType, gtb))) {}
/* 188:    */         }
/* 189:    */         else
/* 190:    */         {
/* 191:176 */           possiter.remove();
/* 192:    */         }
/* 193:    */       }
/* 194:    */     }
/* 195:179 */     if (possibleMatches.isEmpty()) {
/* 196:179 */       return false;
/* 197:    */     }
/* 198:181 */     if ((possibleMatches.size() > 1) && (!weakMatches.isEmpty()))
/* 199:    */     {
/* 200:185 */       int x = 0;
/* 201:185 */       for (int len = args.size(); x < len; x++) {
/* 202:186 */         if (weakMatches.containsKey(Integer.valueOf(x)))
/* 203:    */         {
/* 204:187 */           Set<MethodData> weakMatchedMethods = (Set)weakMatches.get(Integer.valueOf(x));
/* 205:    */           
/* 206:189 */           List<MethodData> remaining = SetUtil.differenceAtakeBtoList(possibleMatches, weakMatchedMethods);
/* 207:190 */           if (remaining.size() == 1)
/* 208:    */           {
/* 209:191 */             possibleMatches.clear();
/* 210:192 */             possibleMatches.addAll(remaining);
/* 211:193 */             break;
/* 212:    */           }
/* 213:    */         }
/* 214:    */       }
/* 215:    */     }
/* 216:199 */     if (possibleMatches.size() > 1)
/* 217:    */     {
/* 218:200 */       List<MethodData> remaining = ListFactory.newList(possibleMatches);
/* 219:    */       
/* 220:    */ 
/* 221:203 */       int x = 0;
/* 222:203 */       for (int len = args.size(); x < len; x++)
/* 223:    */       {
/* 224:204 */         JavaTypeInstance argTypeUsed = ((Expression)args.get(x)).getInferredJavaType().getJavaTypeInstance();
/* 225:205 */         JavaTypeInstance mostDefined = null;
/* 226:206 */         int best = -1;
/* 227:207 */         int y = 0;
/* 228:207 */         for (int len2 = remaining.size(); y < len2; y++)
/* 229:    */         {
/* 230:208 */           JavaTypeInstance t = ((MethodData)remaining.get(y)).getArgType(x, argTypeUsed);
/* 231:209 */           BindingSuperContainer t2bs = t.getBindingSupers();
/* 232:210 */           if (t2bs == null)
/* 233:    */           {
/* 234:211 */             best = -1;
/* 235:212 */             break;
/* 236:    */           }
/* 237:214 */           if (mostDefined == null)
/* 238:    */           {
/* 239:215 */             mostDefined = t;
/* 240:216 */             best = 0;
/* 241:    */           }
/* 242:    */           else
/* 243:    */           {
/* 244:219 */             boolean ainb = t2bs.containsBase(mostDefined);
/* 245:220 */             boolean bina = mostDefined.getBindingSupers().containsBase(t);
/* 246:221 */             if ((ainb ^ bina))
/* 247:    */             {
/* 248:222 */               if (ainb)
/* 249:    */               {
/* 250:223 */                 mostDefined = t;
/* 251:224 */                 best = y;
/* 252:    */               }
/* 253:    */             }
/* 254:    */             else
/* 255:    */             {
/* 256:229 */               best = -1;
/* 257:230 */               break;
/* 258:    */             }
/* 259:    */           }
/* 260:    */         }
/* 261:233 */         if (best != -1)
/* 262:    */         {
/* 263:234 */           MethodData match = (MethodData)remaining.get(best);
/* 264:235 */           possibleMatches.clear();
/* 265:236 */           possibleMatches.add(match);
/* 266:237 */           break;
/* 267:    */         }
/* 268:    */       }
/* 269:    */     }
/* 270:242 */     if (possibleMatches.size() == 1)
/* 271:    */     {
/* 272:243 */       MethodData methodData = (MethodData)possibleMatches.iterator().next();
/* 273:244 */       return methodData.methodPrototype.equals(this.actualPrototype.methodPrototype);
/* 274:    */     }
/* 275:246 */     return false;
/* 276:    */   }
/* 277:    */   
/* 278:    */   public boolean callsCorrectMethod(Expression newArg, int idx, GenericTypeBinder gtb)
/* 279:    */   {
/* 280:267 */     JavaTypeInstance newArgType = newArg.getInferredJavaType().getJavaTypeInstance();
/* 281:    */     
/* 282:    */ 
/* 283:    */ 
/* 284:    */ 
/* 285:272 */     Set<MethodPrototype> exactMatches = SetFactory.newSet();
/* 286:273 */     for (MethodData prototype : this.allPrototypes)
/* 287:    */     {
/* 288:274 */       JavaTypeInstance type = prototype.getArgType(idx, newArgType);
/* 289:276 */       if ((type != null) && (type.equals(newArgType))) {
/* 290:277 */         exactMatches.add(prototype.methodPrototype);
/* 291:    */       }
/* 292:    */     }
/* 293:281 */     if (exactMatches.contains(this.actualPrototype.methodPrototype)) {
/* 294:281 */       return true;
/* 295:    */     }
/* 296:290 */     JavaTypeInstance expectedArgType = this.actualPrototype.getArgType(idx, newArgType);
/* 297:292 */     if ((expectedArgType instanceof RawJavaType)) {
/* 298:293 */       return callsCorrectApproxRawMethod(newArg, newArgType, idx, gtb);
/* 299:    */     }
/* 300:295 */     return callsCorrectApproxObjMethod(newArg, newArgType, idx, gtb);
/* 301:    */   }
/* 302:    */   
/* 303:    */   public boolean callsCorrectApproxRawMethod(Expression newArg, JavaTypeInstance actual, int idx, GenericTypeBinder gtb)
/* 304:    */   {
/* 305:300 */     List<MethodData> matches = ListFactory.newList();
/* 306:301 */     for (MethodData prototype : this.allPrototypes)
/* 307:    */     {
/* 308:302 */       JavaTypeInstance arg = prototype.getArgType(idx, actual);
/* 309:304 */       if ((actual.implicitlyCastsTo(arg, null)) && (actual.impreciseCanCastTo(arg, gtb))) {
/* 310:305 */         matches.add(prototype);
/* 311:    */       }
/* 312:    */     }
/* 313:308 */     if (matches.isEmpty()) {
/* 314:310 */       return false;
/* 315:    */     }
/* 316:312 */     if ((matches.size() == 1) && (((MethodData)matches.get(0)).is(this.actualPrototype))) {
/* 317:313 */       return true;
/* 318:    */     }
/* 319:326 */     boolean boxingFirst = !(actual instanceof RawJavaType);
/* 320:    */     
/* 321:    */ 
/* 322:    */ 
/* 323:330 */     MethodData lowest = (MethodData)matches.get(0);
/* 324:331 */     JavaTypeInstance lowestType = lowest.getArgType(idx, actual);
/* 325:332 */     for (int x = 1; x < matches.size(); x++)
/* 326:    */     {
/* 327:333 */       MethodData next = (MethodData)matches.get(x);
/* 328:334 */       JavaTypeInstance nextType = next.getArgType(idx, actual);
/* 329:335 */       if (nextType.implicitlyCastsTo(lowestType, null))
/* 330:    */       {
/* 331:336 */         lowest = next;
/* 332:337 */         lowestType = nextType;
/* 333:    */       }
/* 334:    */     }
/* 335:341 */     if (lowest.is(this.actualPrototype)) {
/* 336:341 */       return true;
/* 337:    */     }
/* 338:342 */     return false;
/* 339:    */   }
/* 340:    */   
/* 341:    */   public boolean callsCorrectApproxObjMethod(Expression newArg, final JavaTypeInstance actual, final int idx, GenericTypeBinder gtb)
/* 342:    */   {
/* 343:346 */     List<MethodData> matches = ListFactory.newList();
/* 344:347 */     boolean podMatchExists = false;
/* 345:348 */     boolean nonPodMatchExists = false;
/* 346:349 */     for (MethodData prototype : this.allPrototypes)
/* 347:    */     {
/* 348:350 */       JavaTypeInstance arg = prototype.getArgType(idx, actual);
/* 349:352 */       if ((arg != null) && (actual.implicitlyCastsTo(arg, null)) && (actual.impreciseCanCastTo(arg, gtb)))
/* 350:    */       {
/* 351:353 */         if ((arg instanceof RawJavaType)) {
/* 352:354 */           podMatchExists = true;
/* 353:    */         } else {
/* 354:356 */           nonPodMatchExists = true;
/* 355:    */         }
/* 356:358 */         matches.add(prototype);
/* 357:    */       }
/* 358:    */     }
/* 359:361 */     if (matches.isEmpty()) {
/* 360:363 */       return false;
/* 361:    */     }
/* 362:366 */     if ((matches.size() == 1) && (((MethodData)matches.get(0)).is(this.actualPrototype))) {
/* 363:367 */       return true;
/* 364:    */     }
/* 365:372 */     Literal nullLit = new Literal(TypedLiteral.getNull());
/* 366:373 */     if ((newArg.equals(nullLit)) && (actual == RawJavaType.NULL))
/* 367:    */     {
/* 368:374 */       MethodData best = null;
/* 369:375 */       JavaTypeInstance bestType = null;
/* 370:376 */       for (MethodData match : matches)
/* 371:    */       {
/* 372:377 */         JavaTypeInstance arg = match.getArgType(idx, actual);
/* 373:378 */         if (!arg.equals(TypeConstants.OBJECT)) {
/* 374:379 */           if (best == null)
/* 375:    */           {
/* 376:380 */             best = match;
/* 377:381 */             bestType = arg;
/* 378:    */           }
/* 379:383 */           else if (arg.implicitlyCastsTo(bestType, null))
/* 380:    */           {
/* 381:384 */             best = match;
/* 382:385 */             bestType = arg;
/* 383:    */           }
/* 384:386 */           else if (!bestType.implicitlyCastsTo(arg, null))
/* 385:    */           {
/* 386:390 */             return false;
/* 387:    */           }
/* 388:    */         }
/* 389:    */       }
/* 390:395 */       if (best != null) {
/* 391:396 */         return best.is(this.actualPrototype);
/* 392:    */       }
/* 393:    */     }
/* 394:408 */     boolean isPOD = actual instanceof RawJavaType;
/* 395:409 */     boolean onlyMatchPod = (isPOD) && (podMatchExists);
/* 396:414 */     if (onlyMatchPod) {
/* 397:414 */       matches = Functional.filter(matches, new Predicate()
/* 398:    */       {
/* 399:    */         public boolean test(OverloadMethodSet.MethodData in)
/* 400:    */         {
/* 401:417 */           return in.getArgType(idx, actual) instanceof RawJavaType;
/* 402:    */         }
/* 403:    */       });
/* 404:    */     }
/* 405:420 */     if (!isPOD)
/* 406:    */     {
/* 407:422 */       Pair<List<MethodData>, List<MethodData>> partition = Functional.partition(matches, new Predicate()
/* 408:    */       {
/* 409:    */         public boolean test(OverloadMethodSet.MethodData in)
/* 410:    */         {
/* 411:425 */           return !(in.getArgType(idx, actual) instanceof RawJavaType);
/* 412:    */         }
/* 413:427 */       });
/* 414:428 */       matches.clear();
/* 415:429 */       matches.addAll((Collection)partition.getFirst());
/* 416:430 */       if (!nonPodMatchExists) {
/* 417:430 */         matches.addAll((Collection)partition.getSecond());
/* 418:    */       }
/* 419:    */     }
/* 420:433 */     if (matches.isEmpty()) {
/* 421:433 */       return false;
/* 422:    */     }
/* 423:434 */     MethodData lowest = (MethodData)matches.get(0);
/* 424:435 */     JavaTypeInstance lowestType = lowest.getArgType(idx, actual);
/* 425:436 */     for (int x = 0; x < matches.size(); x++)
/* 426:    */     {
/* 427:437 */       MethodData next = (MethodData)matches.get(x);
/* 428:438 */       JavaTypeInstance nextType = next.getArgType(idx, actual);
/* 429:439 */       if (nextType.implicitlyCastsTo(lowestType, null))
/* 430:    */       {
/* 431:440 */         lowest = next;
/* 432:441 */         lowestType = nextType;
/* 433:    */       }
/* 434:    */     }
/* 435:445 */     if (lowest.is(this.actualPrototype)) {
/* 436:445 */       return true;
/* 437:    */     }
/* 438:446 */     return false;
/* 439:    */   }
/* 440:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.classfilehelpers.OverloadMethodSet
 * JD-Core Version:    0.7.0.1
 */