/*   1:    */ package org.benf.cfr.reader.entities.classfilehelpers;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractConstructorInvokation;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationAnonymousInner;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationSimple;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.lvalue.StaticVariable;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.types.ClassSignature;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  12:    */ import org.benf.cfr.reader.entities.AccessFlag;
/*  13:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  14:    */ import org.benf.cfr.reader.entities.ClassFileField;
/*  15:    */ import org.benf.cfr.reader.entities.Method;
/*  16:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass;
/*  17:    */ import org.benf.cfr.reader.state.DCCommonState;
/*  18:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  19:    */ import org.benf.cfr.reader.util.TypeUsageCollectable;
/*  20:    */ import org.benf.cfr.reader.util.output.Dumpable;
/*  21:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  22:    */ 
/*  23:    */ public class ClassFileDumperEnum
/*  24:    */   extends AbstractClassFileDumper
/*  25:    */ {
/*  26: 22 */   private static final AccessFlag[] dumpableAccessFlagsEnum = { AccessFlag.ACC_PUBLIC, AccessFlag.ACC_PRIVATE, AccessFlag.ACC_PROTECTED, AccessFlag.ACC_STRICT, AccessFlag.ACC_STATIC };
/*  27:    */   private final List<Pair<StaticVariable, AbstractConstructorInvokation>> entries;
/*  28:    */   
/*  29:    */   public ClassFileDumperEnum(DCCommonState dcCommonState, List<Pair<StaticVariable, AbstractConstructorInvokation>> entries)
/*  30:    */   {
/*  31: 29 */     super(dcCommonState);
/*  32: 30 */     this.entries = entries;
/*  33:    */   }
/*  34:    */   
/*  35:    */   private static void dumpHeader(ClassFile c, ClassFileDumper.InnerClassDumpType innerClassDumpType, Dumper d)
/*  36:    */   {
/*  37: 34 */     d.print(getAccessFlagsString(c.getAccessFlags(), dumpableAccessFlagsEnum));
/*  38:    */     
/*  39: 36 */     d.print("enum ").dump(c.getThisClassConstpoolEntry().getTypeInstance()).print(" ");
/*  40:    */     
/*  41: 38 */     ClassSignature signature = c.getClassSignature();
/*  42: 39 */     List<JavaTypeInstance> interfaces = signature.getInterfaces();
/*  43: 40 */     if (!interfaces.isEmpty())
/*  44:    */     {
/*  45: 41 */       d.print("implements ");
/*  46: 42 */       int size = interfaces.size();
/*  47: 43 */       for (int x = 0; x < size; x++)
/*  48:    */       {
/*  49: 44 */         JavaTypeInstance iface = (JavaTypeInstance)interfaces.get(x);
/*  50: 45 */         d.dump(iface).print(x < size - 1 ? ",\n" : "\n");
/*  51:    */       }
/*  52:    */     }
/*  53:    */   }
/*  54:    */   
/*  55:    */   private static void dumpEntry(Dumper d, Pair<StaticVariable, AbstractConstructorInvokation> entry, boolean last)
/*  56:    */   {
/*  57: 51 */     StaticVariable staticVariable = (StaticVariable)entry.getFirst();
/*  58: 52 */     AbstractConstructorInvokation constructorInvokation = (AbstractConstructorInvokation)entry.getSecond();
/*  59: 53 */     d.print(staticVariable.getFieldName());
/*  60: 55 */     if ((constructorInvokation instanceof ConstructorInvokationSimple))
/*  61:    */     {
/*  62: 56 */       List<Expression> args = constructorInvokation.getArgs();
/*  63: 57 */       if (args.size() > 2)
/*  64:    */       {
/*  65: 58 */         d.print('(');
/*  66: 59 */         int x = 2;
/*  67: 59 */         for (int len = args.size(); x < len; x++)
/*  68:    */         {
/*  69: 60 */           if (x > 2) {
/*  70: 60 */             d.print(", ");
/*  71:    */           }
/*  72: 61 */           d.dump((Dumpable)args.get(x));
/*  73:    */         }
/*  74: 63 */         d.print(')');
/*  75:    */       }
/*  76:    */     }
/*  77: 65 */     else if ((constructorInvokation instanceof ConstructorInvokationAnonymousInner))
/*  78:    */     {
/*  79: 66 */       ((ConstructorInvokationAnonymousInner)constructorInvokation).dumpForEnum(d);
/*  80:    */     }
/*  81: 70 */     if (last) {
/*  82: 71 */       d.endCodeln();
/*  83:    */     } else {
/*  84: 73 */       d.print(",\n");
/*  85:    */     }
/*  86:    */   }
/*  87:    */   
/*  88:    */   public Dumper dump(ClassFile classFile, ClassFileDumper.InnerClassDumpType innerClass, Dumper d)
/*  89:    */   {
/*  90: 80 */     if (!innerClass.isInnerClass())
/*  91:    */     {
/*  92: 81 */       dumpTopHeader(classFile, d);
/*  93: 82 */       dumpImports(d, classFile);
/*  94:    */     }
/*  95: 85 */     dumpComments(classFile, d);
/*  96: 86 */     dumpAnnotations(classFile, d);
/*  97: 87 */     dumpHeader(classFile, innerClass, d);
/*  98: 88 */     d.print("{\n");
/*  99: 89 */     d.indent(1);
/* 100:    */     
/* 101: 91 */     int x = 0;
/* 102: 91 */     for (int len = this.entries.size(); x < len; x++) {
/* 103: 92 */       dumpEntry(d, (Pair)this.entries.get(x), x == len - 1);
/* 104:    */     }
/* 105: 94 */     d.print("\n");
/* 106:    */     
/* 107: 96 */     List<ClassFileField> fields = classFile.getFields();
/* 108: 97 */     for (ClassFileField field : fields) {
/* 109: 98 */       if (!field.shouldNotDisplay()) {
/* 110: 99 */         field.dump(d);
/* 111:    */       }
/* 112:    */     }
/* 113:101 */     List<Method> methods = classFile.getMethods();
/* 114:102 */     if (!methods.isEmpty()) {
/* 115:103 */       for (Method method : methods) {
/* 116:104 */         if (!method.isHiddenFromDisplay())
/* 117:    */         {
/* 118:105 */           d.newln();
/* 119:106 */           method.dump(d, true);
/* 120:    */         }
/* 121:    */       }
/* 122:    */     }
/* 123:109 */     classFile.dumpNamedInnerClasses(d);
/* 124:110 */     d.indent(-1);
/* 125:111 */     d.print("}\n");
/* 126:    */     
/* 127:113 */     return d;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public void collectTypeUsages(TypeUsageCollector collector)
/* 131:    */   {
/* 132:118 */     for (Pair<StaticVariable, AbstractConstructorInvokation> entry : this.entries)
/* 133:    */     {
/* 134:119 */       collector.collectFrom((TypeUsageCollectable)entry.getFirst());
/* 135:120 */       collector.collectFrom((TypeUsageCollectable)entry.getSecond());
/* 136:    */     }
/* 137:    */   }
/* 138:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumperEnum
 * JD-Core Version:    0.7.0.1
 */