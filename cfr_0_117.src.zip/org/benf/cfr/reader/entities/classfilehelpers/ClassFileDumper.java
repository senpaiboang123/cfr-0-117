/*  1:   */ package org.benf.cfr.reader.entities.classfilehelpers;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.entities.ClassFile;
/*  4:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  5:   */ import org.benf.cfr.reader.util.TypeUsageCollectable;
/*  6:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  7:   */ 
/*  8:   */ public abstract interface ClassFileDumper
/*  9:   */   extends TypeUsageCollectable
/* 10:   */ {
/* 11:   */   public abstract Dumper dump(ClassFile paramClassFile, InnerClassDumpType paramInnerClassDumpType, Dumper paramDumper);
/* 12:   */   
/* 13:   */   public abstract void collectTypeUsages(TypeUsageCollector paramTypeUsageCollector);
/* 14:   */   
/* 15:   */   public static enum InnerClassDumpType
/* 16:   */   {
/* 17:10 */     NOT(false),  INNER_CLASS(true),  INLINE_CLASS(true);
/* 18:   */     
/* 19:   */     final boolean isInnerClass;
/* 20:   */     
/* 21:   */     private InnerClassDumpType(boolean isInnerClass)
/* 22:   */     {
/* 23:17 */       this.isInnerClass = isInnerClass;
/* 24:   */     }
/* 25:   */     
/* 26:   */     public boolean isInnerClass()
/* 27:   */     {
/* 28:21 */       return this.isInnerClass;
/* 29:   */     }
/* 30:   */   }
/* 31:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumper
 * JD-Core Version:    0.7.0.1
 */