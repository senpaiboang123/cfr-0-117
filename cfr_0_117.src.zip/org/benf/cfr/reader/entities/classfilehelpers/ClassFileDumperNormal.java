/*  1:   */ package org.benf.cfr.reader.entities.classfilehelpers;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.types.ClassSignature;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  6:   */ import org.benf.cfr.reader.entities.AccessFlag;
/*  7:   */ import org.benf.cfr.reader.entities.ClassFile;
/*  8:   */ import org.benf.cfr.reader.entities.ClassFileField;
/*  9:   */ import org.benf.cfr.reader.entities.Method;
/* 10:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass;
/* 11:   */ import org.benf.cfr.reader.state.DCCommonState;
/* 12:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 13:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 14:   */ 
/* 15:   */ public class ClassFileDumperNormal
/* 16:   */   extends AbstractClassFileDumper
/* 17:   */ {
/* 18:14 */   private static final AccessFlag[] dumpableAccessFlagsClass = { AccessFlag.ACC_PUBLIC, AccessFlag.ACC_PRIVATE, AccessFlag.ACC_PROTECTED, AccessFlag.ACC_STRICT, AccessFlag.ACC_STATIC, AccessFlag.ACC_FINAL, AccessFlag.ACC_ABSTRACT };
/* 19:17 */   private static final AccessFlag[] dumpableAccessFlagsInlineClass = { AccessFlag.ACC_PUBLIC, AccessFlag.ACC_PRIVATE, AccessFlag.ACC_PROTECTED, AccessFlag.ACC_STRICT, AccessFlag.ACC_FINAL, AccessFlag.ACC_ABSTRACT };
/* 20:   */   
/* 21:   */   public ClassFileDumperNormal(DCCommonState dcCommonState)
/* 22:   */   {
/* 23:22 */     super(dcCommonState);
/* 24:   */   }
/* 25:   */   
/* 26:   */   private void dumpHeader(ClassFile c, ClassFileDumper.InnerClassDumpType innerClassDumpType, Dumper d)
/* 27:   */   {
/* 28:26 */     AccessFlag[] accessFlagsToDump = innerClassDumpType == ClassFileDumper.InnerClassDumpType.INLINE_CLASS ? dumpableAccessFlagsInlineClass : dumpableAccessFlagsClass;
/* 29:27 */     d.print(getAccessFlagsString(c.getAccessFlags(), accessFlagsToDump));
/* 30:   */     
/* 31:29 */     ClassSignature signature = c.getClassSignature();
/* 32:   */     
/* 33:31 */     d.print("class ").dump(c.getThisClassConstpoolEntry().getTypeInstance());
/* 34:32 */     getFormalParametersText(signature, d);
/* 35:33 */     d.print("\n");
/* 36:   */     
/* 37:35 */     JavaTypeInstance superClass = signature.getSuperClass();
/* 38:36 */     if ((superClass != null) && 
/* 39:37 */       (!superClass.getRawName().equals("java.lang.Object"))) {
/* 40:38 */       d.print("extends ").dump(superClass).print("\n");
/* 41:   */     }
/* 42:42 */     List<JavaTypeInstance> interfaces = signature.getInterfaces();
/* 43:43 */     if (!interfaces.isEmpty())
/* 44:   */     {
/* 45:44 */       d.print("implements ");
/* 46:45 */       int size = interfaces.size();
/* 47:46 */       for (int x = 0; x < size; x++)
/* 48:   */       {
/* 49:47 */         JavaTypeInstance iface = (JavaTypeInstance)interfaces.get(x);
/* 50:48 */         d.dump(iface).print(x < size - 1 ? ",\n" : "\n");
/* 51:   */       }
/* 52:   */     }
/* 53:51 */     d.removePendingCarriageReturn().print(" ");
/* 54:   */   }
/* 55:   */   
/* 56:   */   public Dumper dump(ClassFile classFile, ClassFileDumper.InnerClassDumpType innerClass, Dumper d)
/* 57:   */   {
/* 58:56 */     if (!d.canEmitClass(classFile.getClassType())) {
/* 59:56 */       return d;
/* 60:   */     }
/* 61:58 */     if (!innerClass.isInnerClass())
/* 62:   */     {
/* 63:59 */       dumpTopHeader(classFile, d);
/* 64:60 */       dumpImports(d, classFile);
/* 65:   */     }
/* 66:63 */     dumpComments(classFile, d);
/* 67:64 */     dumpAnnotations(classFile, d);
/* 68:65 */     dumpHeader(classFile, innerClass, d);
/* 69:66 */     d.print("{\n");
/* 70:67 */     d.indent(1);
/* 71:68 */     boolean first = true;
/* 72:   */     
/* 73:70 */     List<ClassFileField> fields = classFile.getFields();
/* 74:71 */     for (ClassFileField field : fields) {
/* 75:72 */       if (!field.shouldNotDisplay())
/* 76:   */       {
/* 77:73 */         field.dump(d);
/* 78:74 */         first = false;
/* 79:   */       }
/* 80:   */     }
/* 81:77 */     List<Method> methods = classFile.getMethods();
/* 82:78 */     if (!methods.isEmpty()) {
/* 83:79 */       for (Method method : methods) {
/* 84:80 */         if (!method.isHiddenFromDisplay())
/* 85:   */         {
/* 86:83 */           if (!first) {
/* 87:84 */             d.newln();
/* 88:   */           }
/* 89:86 */           first = false;
/* 90:87 */           method.dump(d, true);
/* 91:   */         }
/* 92:   */       }
/* 93:   */     }
/* 94:90 */     classFile.dumpNamedInnerClasses(d);
/* 95:91 */     d.indent(-1);
/* 96:92 */     d.print("}\n");
/* 97:   */     
/* 98:94 */     return d;
/* 99:   */   }
/* :0:   */   
/* :1:   */   public void collectTypeUsages(TypeUsageCollector collector) {}
/* :2:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumperNormal
 * JD-Core Version:    0.7.0.1
 */