/*  1:   */ package org.benf.cfr.reader.entities.classfilehelpers;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.types.ClassSignature;
/*  5:   */ import org.benf.cfr.reader.entities.AccessFlag;
/*  6:   */ import org.benf.cfr.reader.entities.ClassFile;
/*  7:   */ import org.benf.cfr.reader.entities.ClassFileField;
/*  8:   */ import org.benf.cfr.reader.entities.Method;
/*  9:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass;
/* 10:   */ import org.benf.cfr.reader.state.DCCommonState;
/* 11:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 12:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 13:   */ 
/* 14:   */ public class ClassFileDumperAnnotation
/* 15:   */   extends AbstractClassFileDumper
/* 16:   */ {
/* 17:15 */   private static final AccessFlag[] dumpableAccessFlagsInterface = { AccessFlag.ACC_PUBLIC, AccessFlag.ACC_PRIVATE, AccessFlag.ACC_PROTECTED, AccessFlag.ACC_STATIC, AccessFlag.ACC_FINAL };
/* 18:   */   
/* 19:   */   public ClassFileDumperAnnotation(DCCommonState dcCommonState)
/* 20:   */   {
/* 21:20 */     super(dcCommonState);
/* 22:   */   }
/* 23:   */   
/* 24:   */   private void dumpHeader(ClassFile c, ClassFileDumper.InnerClassDumpType innerClassDumpType, Dumper d)
/* 25:   */   {
/* 26:25 */     d.print(getAccessFlagsString(c.getAccessFlags(), dumpableAccessFlagsInterface));
/* 27:   */     
/* 28:27 */     ClassSignature signature = c.getClassSignature();
/* 29:   */     
/* 30:29 */     d.print("@interface ").dump(c.getThisClassConstpoolEntry().getTypeInstance());
/* 31:30 */     getFormalParametersText(signature, d);
/* 32:31 */     d.print("\n");
/* 33:   */     
/* 34:33 */     d.removePendingCarriageReturn().print(" ");
/* 35:   */   }
/* 36:   */   
/* 37:   */   public Dumper dump(ClassFile classFile, ClassFileDumper.InnerClassDumpType innerClass, Dumper d)
/* 38:   */   {
/* 39:40 */     if (!innerClass.isInnerClass())
/* 40:   */     {
/* 41:41 */       dumpTopHeader(classFile, d);
/* 42:42 */       dumpImports(d, classFile);
/* 43:   */     }
/* 44:45 */     boolean first = true;
/* 45:46 */     dumpAnnotations(classFile, d);
/* 46:47 */     dumpHeader(classFile, innerClass, d);
/* 47:48 */     d.print("{\n");
/* 48:49 */     d.indent(1);
/* 49:   */     
/* 50:51 */     List<ClassFileField> fields = classFile.getFields();
/* 51:52 */     for (ClassFileField field : fields)
/* 52:   */     {
/* 53:53 */       field.dump(d);
/* 54:54 */       first = false;
/* 55:   */     }
/* 56:56 */     List<Method> methods = classFile.getMethods();
/* 57:57 */     if (!methods.isEmpty()) {
/* 58:58 */       for (Method meth : methods)
/* 59:   */       {
/* 60:59 */         if (!first) {
/* 61:60 */           d.newln();
/* 62:   */         }
/* 63:62 */         first = false;
/* 64:   */         
/* 65:64 */         meth.dump(d, false);
/* 66:   */       }
/* 67:   */     }
/* 68:67 */     classFile.dumpNamedInnerClasses(d);
/* 69:68 */     d.indent(-1);
/* 70:69 */     d.print("}\n");
/* 71:70 */     return d;
/* 72:   */   }
/* 73:   */   
/* 74:   */   public void collectTypeUsages(TypeUsageCollector collector) {}
/* 75:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumperAnnotation
 * JD-Core Version:    0.7.0.1
 */