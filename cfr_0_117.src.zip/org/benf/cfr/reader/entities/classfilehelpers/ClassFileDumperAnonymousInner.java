/*  1:   */ package org.benf.cfr.reader.entities.classfilehelpers;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.parse.Expression;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.types.ClassSignature;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  8:   */ import org.benf.cfr.reader.entities.ClassFile;
/*  9:   */ import org.benf.cfr.reader.entities.ClassFileField;
/* 10:   */ import org.benf.cfr.reader.entities.Method;
/* 11:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 12:   */ import org.benf.cfr.reader.util.ListFactory;
/* 13:   */ import org.benf.cfr.reader.util.StringUtils;
/* 14:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 15:   */ 
/* 16:   */ public class ClassFileDumperAnonymousInner
/* 17:   */   extends AbstractClassFileDumper
/* 18:   */ {
/* 19:   */   public ClassFileDumperAnonymousInner()
/* 20:   */   {
/* 21:18 */     super(null);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public Dumper dump(ClassFile classFile, ClassFileDumper.InnerClassDumpType innerClass, Dumper d)
/* 25:   */   {
/* 26:23 */     return dumpWithArgs(classFile, null, ListFactory.newList(), false, d);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public Dumper dumpWithArgs(ClassFile classFile, MethodPrototype usedMethod, List<Expression> args, boolean isEnum, Dumper d)
/* 30:   */   {
/* 31:28 */     if (classFile == null)
/* 32:   */     {
/* 33:29 */       d.print("/* Unavailable Anonymous Inner Class!! */");
/* 34:30 */       return d;
/* 35:   */     }
/* 36:33 */     if (!d.canEmitClass(classFile.getClassType())) {
/* 37:34 */       return d;
/* 38:   */     }
/* 39:37 */     if (!isEnum)
/* 40:   */     {
/* 41:38 */       ClassSignature signature = classFile.getClassSignature();
/* 42:39 */       if (signature.getInterfaces().isEmpty())
/* 43:   */       {
/* 44:40 */         JavaTypeInstance superclass = signature.getSuperClass();
/* 45:41 */         d.dump(superclass);
/* 46:   */       }
/* 47:   */       else
/* 48:   */       {
/* 49:43 */         JavaTypeInstance interfaceType = (JavaTypeInstance)signature.getInterfaces().get(0);
/* 50:44 */         d.dump(interfaceType);
/* 51:   */       }
/* 52:   */     }
/* 53:47 */     if ((!isEnum) || (!args.isEmpty()))
/* 54:   */     {
/* 55:48 */       d.print("(");
/* 56:49 */       boolean first = true;
/* 57:50 */       int i = 0;
/* 58:50 */       for (int len = args.size(); i < len; i++) {
/* 59:51 */         if ((usedMethod == null) || (!usedMethod.isHiddenArg(i)))
/* 60:   */         {
/* 61:52 */           Expression arg = (Expression)args.get(i);
/* 62:53 */           first = StringUtils.comma(first, d);
/* 63:54 */           d.dump(arg);
/* 64:   */         }
/* 65:   */       }
/* 66:56 */       d.print(")");
/* 67:   */     }
/* 68:58 */     d.print("{\n");
/* 69:59 */     d.indent(1);
/* 70:60 */     int outcrs = d.getOutputCount();
/* 71:   */     
/* 72:   */ 
/* 73:63 */     List<ClassFileField> fields = classFile.getFields();
/* 74:64 */     for (ClassFileField field : fields) {
/* 75:65 */       if (!field.shouldNotDisplay()) {
/* 76:65 */         field.dump(d);
/* 77:   */       }
/* 78:   */     }
/* 79:67 */     List<Method> methods = classFile.getMethods();
/* 80:68 */     if (!methods.isEmpty()) {
/* 81:69 */       for (Method method : methods) {
/* 82:70 */         if ((!method.isHiddenFromDisplay()) && 
/* 83:   */         
/* 84:72 */           (!method.isConstructor()))
/* 85:   */         {
/* 86:73 */           d.newln();
/* 87:74 */           method.dump(d, true);
/* 88:   */         }
/* 89:   */       }
/* 90:   */     }
/* 91:77 */     classFile.dumpNamedInnerClasses(d);
/* 92:78 */     d.indent(-1);
/* 93:80 */     if (d.getOutputCount() == outcrs) {
/* 94:81 */       d.removePendingCarriageReturn();
/* 95:   */     }
/* 96:83 */     d.print("}\n");
/* 97:   */     
/* 98:85 */     return d;
/* 99:   */   }
/* :0:   */   
/* :1:   */   public void collectTypeUsages(TypeUsageCollector collector) {}
/* :2:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumperAnonymousInner
 * JD-Core Version:    0.7.0.1
 */