/*  1:   */ package org.benf.cfr.reader.entities.classfilehelpers;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.types.ClassSignature;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  6:   */ import org.benf.cfr.reader.entities.AccessFlag;
/*  7:   */ import org.benf.cfr.reader.entities.ClassFile;
/*  8:   */ import org.benf.cfr.reader.entities.ClassFileField;
/*  9:   */ import org.benf.cfr.reader.entities.Method;
/* 10:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass;
/* 11:   */ import org.benf.cfr.reader.state.DCCommonState;
/* 12:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/* 13:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 14:   */ 
/* 15:   */ public class ClassFileDumperInterface
/* 16:   */   extends AbstractClassFileDumper
/* 17:   */ {
/* 18:16 */   private static final AccessFlag[] dumpableAccessFlagsInterface = { AccessFlag.ACC_PUBLIC, AccessFlag.ACC_PRIVATE, AccessFlag.ACC_PROTECTED, AccessFlag.ACC_STRICT, AccessFlag.ACC_STATIC, AccessFlag.ACC_FINAL };
/* 19:   */   
/* 20:   */   public ClassFileDumperInterface(DCCommonState dcCommonState)
/* 21:   */   {
/* 22:21 */     super(dcCommonState);
/* 23:   */   }
/* 24:   */   
/* 25:   */   private void dumpHeader(ClassFile c, ClassFileDumper.InnerClassDumpType innerClassDumpType, Dumper d)
/* 26:   */   {
/* 27:26 */     d.print(getAccessFlagsString(c.getAccessFlags(), dumpableAccessFlagsInterface));
/* 28:   */     
/* 29:28 */     ClassSignature signature = c.getClassSignature();
/* 30:   */     
/* 31:30 */     d.print("interface ").dump(c.getThisClassConstpoolEntry().getTypeInstance());
/* 32:31 */     getFormalParametersText(signature, d);
/* 33:32 */     d.print("\n");
/* 34:   */     
/* 35:34 */     List<JavaTypeInstance> interfaces = signature.getInterfaces();
/* 36:35 */     if (!interfaces.isEmpty())
/* 37:   */     {
/* 38:36 */       d.print("extends ");
/* 39:37 */       int size = interfaces.size();
/* 40:38 */       for (int x = 0; x < size; x++)
/* 41:   */       {
/* 42:39 */         JavaTypeInstance iface = (JavaTypeInstance)interfaces.get(x);
/* 43:40 */         d.dump(iface).print(x < size - 1 ? ",\n" : "\n");
/* 44:   */       }
/* 45:   */     }
/* 46:43 */     d.removePendingCarriageReturn().print(" ");
/* 47:   */   }
/* 48:   */   
/* 49:   */   public Dumper dump(ClassFile classFile, ClassFileDumper.InnerClassDumpType innerClass, Dumper d)
/* 50:   */   {
/* 51:49 */     if (!innerClass.isInnerClass())
/* 52:   */     {
/* 53:50 */       dumpTopHeader(classFile, d);
/* 54:51 */       dumpImports(d, classFile);
/* 55:   */     }
/* 56:54 */     dumpAnnotations(classFile, d);
/* 57:55 */     dumpHeader(classFile, innerClass, d);
/* 58:56 */     boolean first = true;
/* 59:57 */     d.print("{\n");
/* 60:58 */     d.indent(1);
/* 61:   */     
/* 62:60 */     List<ClassFileField> fields = classFile.getFields();
/* 63:61 */     for (ClassFileField field : fields)
/* 64:   */     {
/* 65:62 */       field.dump(d);
/* 66:63 */       first = false;
/* 67:   */     }
/* 68:65 */     List<Method> methods = classFile.getMethods();
/* 69:66 */     if (!methods.isEmpty()) {
/* 70:67 */       for (Method method : methods) {
/* 71:68 */         if (!method.isHiddenFromDisplay())
/* 72:   */         {
/* 73:69 */           if (!first) {
/* 74:70 */             d.newln();
/* 75:   */           }
/* 76:72 */           first = false;
/* 77:   */           
/* 78:74 */           method.dump(d, false);
/* 79:   */         }
/* 80:   */       }
/* 81:   */     }
/* 82:77 */     classFile.dumpNamedInnerClasses(d);
/* 83:78 */     d.indent(-1);
/* 84:79 */     d.print("}\n");
/* 85:80 */     return d;
/* 86:   */   }
/* 87:   */   
/* 88:   */   public void collectTypeUsages(TypeUsageCollector collector) {}
/* 89:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumperInterface
 * JD-Core Version:    0.7.0.1
 */