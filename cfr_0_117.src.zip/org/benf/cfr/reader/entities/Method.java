/*   1:    */ package org.benf.cfr.reader.entities;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ import java.util.ArrayList;
/*   5:    */ import java.util.EnumSet;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.Set;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.types.BindingSuperContainer;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.types.InnerClassInfo;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototypeAnnotationsHelper;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.variables.Ident;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.variables.VariableNamer;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.variables.VariableNamerFactory;
/*  20:    */ import org.benf.cfr.reader.entities.attributes.Attribute;
/*  21:    */ import org.benf.cfr.reader.entities.attributes.AttributeAnnotationDefault;
/*  22:    */ import org.benf.cfr.reader.entities.attributes.AttributeCode;
/*  23:    */ import org.benf.cfr.reader.entities.attributes.AttributeExceptions;
/*  24:    */ import org.benf.cfr.reader.entities.attributes.AttributeRuntimeInvisibleAnnotations;
/*  25:    */ import org.benf.cfr.reader.entities.attributes.AttributeRuntimeInvisibleParameterAnnotations;
/*  26:    */ import org.benf.cfr.reader.entities.attributes.AttributeRuntimeVisibleAnnotations;
/*  27:    */ import org.benf.cfr.reader.entities.attributes.AttributeRuntimeVisibleParameterAnnotations;
/*  28:    */ import org.benf.cfr.reader.entities.attributes.AttributeSignature;
/*  29:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  30:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass;
/*  31:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryUTF8;
/*  32:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolUtils;
/*  33:    */ import org.benf.cfr.reader.entityfactories.AttributeFactory;
/*  34:    */ import org.benf.cfr.reader.entityfactories.ContiguousEntityFactory;
/*  35:    */ import org.benf.cfr.reader.state.DCCommonState;
/*  36:    */ import org.benf.cfr.reader.state.LocalClassAwareTypeUsageInformation;
/*  37:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  38:    */ import org.benf.cfr.reader.state.TypeUsageInformation;
/*  39:    */ import org.benf.cfr.reader.util.ClassFileVersion;
/*  40:    */ import org.benf.cfr.reader.util.CollectionUtils;
/*  41:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  42:    */ import org.benf.cfr.reader.util.DecompilerComment;
/*  43:    */ import org.benf.cfr.reader.util.DecompilerComments;
/*  44:    */ import org.benf.cfr.reader.util.KnowsRawSize;
/*  45:    */ import org.benf.cfr.reader.util.MapFactory;
/*  46:    */ import org.benf.cfr.reader.util.SetFactory;
/*  47:    */ import org.benf.cfr.reader.util.StringUtils;
/*  48:    */ import org.benf.cfr.reader.util.TypeUsageCollectable;
/*  49:    */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  50:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  51:    */ import org.benf.cfr.reader.util.getopt.Options;
/*  52:    */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*  53:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  54:    */ import org.benf.cfr.reader.util.output.TypeOverridingDumper;
/*  55:    */ 
/*  56:    */ public class Method
/*  57:    */   implements KnowsRawSize, TypeUsageCollectable
/*  58:    */ {
/*  59:    */   private static final long OFFSET_OF_ACCESS_FLAGS = 0L;
/*  60:    */   private static final long OFFSET_OF_NAME_INDEX = 2L;
/*  61:    */   private static final long OFFSET_OF_DESCRIPTOR_INDEX = 4L;
/*  62:    */   private static final long OFFSET_OF_ATTRIBUTES_COUNT = 6L;
/*  63:    */   private static final long OFFSET_OF_ATTRIBUTES = 8L;
/*  64:    */   private final long length;
/*  65:    */   private final EnumSet<AccessFlagMethod> accessFlags;
/*  66:    */   private final Map<String, Attribute> attributes;
/*  67:    */   private MethodConstructor isConstructor;
/*  68:    */   private final short descriptorIndex;
/*  69:    */   private final AttributeCode codeAttribute;
/*  70:    */   private final ConstantPool cp;
/*  71:    */   private final VariableNamer variableNamer;
/*  72:    */   private final MethodPrototype methodPrototype;
/*  73:    */   private final ClassFile classFile;
/*  74:    */   private boolean hidden;
/*  75:    */   private DecompilerComments comments;
/*  76:    */   
/*  77:    */   public static enum MethodConstructor
/*  78:    */   {
/*  79: 37 */     NOT(false),  STATIC_CONSTRUCTOR(false),  CONSTRUCTOR(true),  ENUM_CONSTRUCTOR(true);
/*  80:    */     
/*  81:    */     private final boolean isConstructor;
/*  82:    */     
/*  83:    */     private MethodConstructor(boolean isConstructor)
/*  84:    */     {
/*  85: 45 */       this.isConstructor = isConstructor;
/*  86:    */     }
/*  87:    */     
/*  88:    */     public boolean isConstructor()
/*  89:    */     {
/*  90: 49 */       return this.isConstructor;
/*  91:    */     }
/*  92:    */   }
/*  93:    */   
/*  94: 71 */   private final Map<JavaRefTypeInstance, String> localClasses = MapFactory.newLinkedMap();
/*  95:    */   private boolean isOverride;
/*  96: 73 */   private transient Set<JavaTypeInstance> thrownTypes = null;
/*  97:    */   
/*  98:    */   public Method(ByteData raw, ClassFile classFile, ConstantPool cp, DCCommonState dcCommonState, ClassFileVersion classFileVersion)
/*  99:    */   {
/* 100: 76 */     Options options = dcCommonState.getOptions();
/* 101:    */     
/* 102: 78 */     this.cp = cp;
/* 103: 79 */     this.classFile = classFile;
/* 104: 80 */     this.accessFlags = AccessFlagMethod.build(raw.getS2At(0L));
/* 105: 81 */     this.descriptorIndex = raw.getS2At(4L);
/* 106: 82 */     short nameIndex = raw.getS2At(2L);
/* 107: 83 */     String initialName = cp.getUTF8Entry(nameIndex).getValue();
/* 108:    */     
/* 109: 85 */     short numAttributes = raw.getS2At(6L);
/* 110: 86 */     ArrayList<Attribute> tmpAttributes = new ArrayList();
/* 111: 87 */     tmpAttributes.ensureCapacity(numAttributes);
/* 112: 88 */     long attributesLength = ContiguousEntityFactory.build(raw.getOffsetData(8L), numAttributes, tmpAttributes, AttributeFactory.getBuilder(cp, classFileVersion));
/* 113:    */     
/* 114:    */ 
/* 115: 91 */     this.attributes = ContiguousEntityFactory.addToMap(new HashMap(), tmpAttributes);
/* 116: 92 */     AccessFlagMethod.applyAttributes(this.attributes, this.accessFlags);
/* 117: 93 */     this.length = (8L + attributesLength);
/* 118:    */     
/* 119:    */ 
/* 120:    */ 
/* 121: 97 */     MethodConstructor methodConstructor = MethodConstructor.NOT;
/* 122: 98 */     if (initialName.equals("<init>"))
/* 123:    */     {
/* 124: 99 */       boolean isEnum = classFile.getAccessFlags().contains(AccessFlag.ACC_ENUM);
/* 125:100 */       methodConstructor = isEnum ? MethodConstructor.ENUM_CONSTRUCTOR : MethodConstructor.CONSTRUCTOR;
/* 126:    */     }
/* 127:101 */     else if (initialName.equals("<clinit>"))
/* 128:    */     {
/* 129:102 */       methodConstructor = MethodConstructor.STATIC_CONSTRUCTOR;
/* 130:    */     }
/* 131:104 */     this.isConstructor = methodConstructor;
/* 132:105 */     if ((isConstructor()) && (this.accessFlags.contains(AccessFlagMethod.ACC_STRICT)))
/* 133:    */     {
/* 134:106 */       this.accessFlags.remove(AccessFlagMethod.ACC_STRICT);
/* 135:107 */       classFile.getAccessFlags().add(AccessFlag.ACC_STRICT);
/* 136:    */     }
/* 137:110 */     Attribute codeAttribute = (Attribute)this.attributes.get("Code");
/* 138:111 */     if (codeAttribute == null)
/* 139:    */     {
/* 140:113 */       this.variableNamer = VariableNamerFactory.getNamer(null, cp);
/* 141:114 */       this.codeAttribute = null;
/* 142:    */     }
/* 143:    */     else
/* 144:    */     {
/* 145:116 */       this.codeAttribute = ((AttributeCode)codeAttribute);
/* 146:    */       
/* 147:    */ 
/* 148:119 */       this.variableNamer = VariableNamerFactory.getNamer(this.codeAttribute.getLocalVariableTable(), cp);
/* 149:120 */       this.codeAttribute.setMethod(this);
/* 150:    */     }
/* 151:123 */     this.methodPrototype = generateMethodPrototype(initialName);
/* 152:124 */     if ((this.accessFlags.contains(AccessFlagMethod.ACC_BRIDGE)) && (((Boolean)options.getOption(OptionsImpl.HIDE_BRIDGE_METHODS)).booleanValue())) {
/* 153:126 */       this.hidden = true;
/* 154:    */     }
/* 155:    */   }
/* 156:    */   
/* 157:    */   public void collectTypeUsages(TypeUsageCollector collector)
/* 158:    */   {
/* 159:132 */     this.methodPrototype.collectTypeUsages(collector);
/* 160:133 */     collector.collectFrom(getAttributeByName("RuntimeVisibleAnnotations"));
/* 161:134 */     collector.collectFrom(getAttributeByName("RuntimeInvisibleAnnotations"));
/* 162:135 */     collector.collectFrom(getAttributeByName("RuntimeVisibleParameterAnnotations"));
/* 163:136 */     collector.collectFrom(getAttributeByName("RuntimeInvisibleParameterAnnotations"));
/* 164:137 */     collector.collectFrom(getAttributeByName("AnnotationDefault"));
/* 165:138 */     if (this.codeAttribute != null)
/* 166:    */     {
/* 167:139 */       this.codeAttribute.collectTypeUsages(collector);
/* 168:140 */       this.codeAttribute.analyse().collectTypeUsages(collector);
/* 169:    */     }
/* 170:142 */     collector.collect(this.localClasses.keySet());
/* 171:143 */     collector.collectFrom(getAttributeByName("Exceptions"));
/* 172:    */   }
/* 173:    */   
/* 174:    */   public Set<AccessFlagMethod> getAccessFlags()
/* 175:    */   {
/* 176:147 */     return this.accessFlags;
/* 177:    */   }
/* 178:    */   
/* 179:    */   public void hideSynthetic()
/* 180:    */   {
/* 181:151 */     this.hidden = true;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public boolean isHiddenFromDisplay()
/* 185:    */   {
/* 186:155 */     return this.hidden;
/* 187:    */   }
/* 188:    */   
/* 189:    */   public boolean testAccessFlag(AccessFlagMethod flag)
/* 190:    */   {
/* 191:159 */     return this.accessFlags.contains(flag);
/* 192:    */   }
/* 193:    */   
/* 194:    */   public MethodConstructor getConstructorFlag()
/* 195:    */   {
/* 196:163 */     return this.isConstructor;
/* 197:    */   }
/* 198:    */   
/* 199:    */   public AttributeSignature getSignatureAttribute()
/* 200:    */   {
/* 201:167 */     return (AttributeSignature)getAttributeByName("Signature");
/* 202:    */   }
/* 203:    */   
/* 204:    */   private <T extends Attribute> T getAttributeByName(String name)
/* 205:    */   {
/* 206:171 */     Attribute attribute = (Attribute)this.attributes.get(name);
/* 207:172 */     if (attribute == null) {
/* 208:172 */       return null;
/* 209:    */     }
/* 210:174 */     T tmp = attribute;
/* 211:175 */     return tmp;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public VariableNamer getVariableNamer()
/* 215:    */   {
/* 216:179 */     return this.variableNamer;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public ClassFile getClassFile()
/* 220:    */   {
/* 221:183 */     return this.classFile;
/* 222:    */   }
/* 223:    */   
/* 224:    */   public long getRawByteLength()
/* 225:    */   {
/* 226:188 */     return this.length;
/* 227:    */   }
/* 228:    */   
/* 229:    */   public String getName()
/* 230:    */   {
/* 231:192 */     return this.methodPrototype.getName();
/* 232:    */   }
/* 233:    */   
/* 234:    */   private MethodPrototype generateMethodPrototype(String initialName)
/* 235:    */   {
/* 236:205 */     AttributeSignature sig = getSignatureAttribute();
/* 237:206 */     ConstantPoolEntryUTF8 signature = sig == null ? null : sig.getSignature();
/* 238:207 */     ConstantPoolEntryUTF8 descriptor = this.cp.getUTF8Entry(this.descriptorIndex);
/* 239:208 */     ConstantPoolEntryUTF8 prototype = null;
/* 240:209 */     if (signature == null) {
/* 241:210 */       prototype = descriptor;
/* 242:    */     } else {
/* 243:212 */       prototype = signature;
/* 244:    */     }
/* 245:214 */     boolean isInstance = !this.accessFlags.contains(AccessFlagMethod.ACC_STATIC);
/* 246:215 */     boolean isVarargs = this.accessFlags.contains(AccessFlagMethod.ACC_VARARGS);
/* 247:216 */     boolean isSynthetic = this.accessFlags.contains(AccessFlagMethod.ACC_SYNTHETIC);
/* 248:217 */     MethodPrototype res = ConstantPoolUtils.parseJavaMethodPrototype(this.classFile, this.classFile.getClassType(), initialName, isInstance, getConstructorFlag(), prototype, this.cp, isVarargs, isSynthetic, this.variableNamer);
/* 249:223 */     if ((this.classFile.isInnerClass()) && 
/* 250:224 */       (signature != null))
/* 251:    */     {
/* 252:225 */       MethodPrototype descriptorProto = ConstantPoolUtils.parseJavaMethodPrototype(this.classFile, this.classFile.getClassType(), initialName, isInstance, getConstructorFlag(), descriptor, this.cp, isVarargs, isSynthetic, this.variableNamer);
/* 253:226 */       if (descriptorProto.getArgs().size() != res.getArgs().size()) {
/* 254:228 */         res = fixupInnerClassSignature(descriptorProto, res);
/* 255:    */       }
/* 256:    */     }
/* 257:232 */     return res;
/* 258:    */   }
/* 259:    */   
/* 260:    */   private static MethodPrototype fixupInnerClassSignature(MethodPrototype descriptor, MethodPrototype signature)
/* 261:    */   {
/* 262:236 */     List<JavaTypeInstance> descriptorArgs = descriptor.getArgs();
/* 263:237 */     List<JavaTypeInstance> signatureArgs = signature.getArgs();
/* 264:238 */     if (signatureArgs.size() != descriptorArgs.size() - 1) {
/* 265:240 */       return signature;
/* 266:    */     }
/* 267:242 */     for (int x = 0; x < signatureArgs.size(); x++) {
/* 268:243 */       if (!((JavaTypeInstance)descriptorArgs.get(x + 1)).equals(((JavaTypeInstance)signatureArgs.get(x)).getDeGenerifiedType())) {
/* 269:245 */         return signature;
/* 270:    */       }
/* 271:    */     }
/* 272:252 */     signatureArgs.add(0, descriptorArgs.get(0));
/* 273:253 */     return signature;
/* 274:    */   }
/* 275:    */   
/* 276:    */   public MethodPrototype getMethodPrototype()
/* 277:    */   {
/* 278:257 */     return this.methodPrototype;
/* 279:    */   }
/* 280:    */   
/* 281:    */   public void markOverride()
/* 282:    */   {
/* 283:261 */     this.isOverride = true;
/* 284:    */   }
/* 285:    */   
/* 286:    */   public void markUsedLocalClassType(JavaTypeInstance javaTypeInstance, String suggestedName)
/* 287:    */   {
/* 288:265 */     javaTypeInstance = javaTypeInstance.getDeGenerifiedType();
/* 289:266 */     if (!(javaTypeInstance instanceof JavaRefTypeInstance)) {
/* 290:267 */       throw new IllegalStateException("Bad local class Type " + javaTypeInstance.getRawName());
/* 291:    */     }
/* 292:268 */     this.localClasses.put((JavaRefTypeInstance)javaTypeInstance, suggestedName);
/* 293:    */   }
/* 294:    */   
/* 295:    */   public void markUsedLocalClassType(JavaTypeInstance javaTypeInstance)
/* 296:    */   {
/* 297:272 */     markUsedLocalClassType(javaTypeInstance, null);
/* 298:    */   }
/* 299:    */   
/* 300:    */   private void dumpMethodAnnotations(Dumper d)
/* 301:    */   {
/* 302:276 */     AttributeRuntimeVisibleAnnotations runtimeVisibleAnnotations = (AttributeRuntimeVisibleAnnotations)getAttributeByName("RuntimeVisibleAnnotations");
/* 303:277 */     AttributeRuntimeInvisibleAnnotations runtimeInvisibleAnnotations = (AttributeRuntimeInvisibleAnnotations)getAttributeByName("RuntimeInvisibleAnnotations");
/* 304:278 */     if (runtimeVisibleAnnotations != null) {
/* 305:278 */       runtimeVisibleAnnotations.dump(d);
/* 306:    */     }
/* 307:279 */     if (runtimeInvisibleAnnotations != null) {
/* 308:279 */       runtimeInvisibleAnnotations.dump(d);
/* 309:    */     }
/* 310:280 */     if (this.isOverride) {
/* 311:281 */       d.print("@Override\n");
/* 312:    */     }
/* 313:    */   }
/* 314:    */   
/* 315:    */   public Set<JavaTypeInstance> getThrownTypes()
/* 316:    */   {
/* 317:286 */     if (this.thrownTypes == null)
/* 318:    */     {
/* 319:287 */       this.thrownTypes = SetFactory.newOrderedSet();
/* 320:288 */       AttributeExceptions exceptionsAttribute = (AttributeExceptions)getAttributeByName("Exceptions");
/* 321:289 */       if (exceptionsAttribute != null)
/* 322:    */       {
/* 323:290 */         List<ConstantPoolEntryClass> exceptionClasses = exceptionsAttribute.getExceptionClassList();
/* 324:291 */         for (ConstantPoolEntryClass exceptionClass : exceptionClasses)
/* 325:    */         {
/* 326:292 */           JavaTypeInstance typeInstance = exceptionClass.getTypeInstance();
/* 327:293 */           this.thrownTypes.add(typeInstance);
/* 328:    */         }
/* 329:    */       }
/* 330:    */     }
/* 331:297 */     return this.thrownTypes;
/* 332:    */   }
/* 333:    */   
/* 334:    */   public void dumpSignatureText(boolean asClass, Dumper d)
/* 335:    */   {
/* 336:302 */     dumpMethodAnnotations(d);
/* 337:    */     
/* 338:304 */     EnumSet<AccessFlagMethod> localAccessFlags = this.accessFlags;
/* 339:305 */     if (!asClass)
/* 340:    */     {
/* 341:306 */       if (this.codeAttribute != null) {
/* 342:306 */         d.print("default ");
/* 343:    */       }
/* 344:308 */       localAccessFlags = SetFactory.newSet(localAccessFlags);
/* 345:309 */       localAccessFlags.remove(AccessFlagMethod.ACC_ABSTRACT);
/* 346:    */     }
/* 347:311 */     String prefix = CollectionUtils.join(localAccessFlags, " ");
/* 348:313 */     if (!prefix.isEmpty()) {
/* 349:313 */       d.print(prefix);
/* 350:    */     }
/* 351:315 */     if (this.isConstructor == MethodConstructor.STATIC_CONSTRUCTOR) {
/* 352:316 */       return;
/* 353:    */     }
/* 354:319 */     if (!prefix.isEmpty()) {
/* 355:319 */       d.print(' ');
/* 356:    */     }
/* 357:321 */     MethodPrototypeAnnotationsHelper paramAnnotationsHelper = new MethodPrototypeAnnotationsHelper((AttributeRuntimeVisibleParameterAnnotations)getAttributeByName("RuntimeVisibleParameterAnnotations"), (AttributeRuntimeInvisibleParameterAnnotations)getAttributeByName("RuntimeInvisibleParameterAnnotations"));
/* 358:    */     
/* 359:    */ 
/* 360:    */ 
/* 361:    */ 
/* 362:326 */     String displayName = this.isConstructor.isConstructor() ? d.getTypeUsageInformation().getName(this.classFile.getClassType()) : this.methodPrototype.getFixedName();
/* 363:    */     
/* 364:    */ 
/* 365:    */ 
/* 366:330 */     getMethodPrototype().dumpDeclarationSignature(d, displayName, this.isConstructor, paramAnnotationsHelper);
/* 367:331 */     AttributeExceptions exceptionsAttribute = (AttributeExceptions)getAttributeByName("Exceptions");
/* 368:    */     boolean first;
/* 369:332 */     if (exceptionsAttribute != null)
/* 370:    */     {
/* 371:333 */       d.print(" throws ");
/* 372:334 */       first = true;
/* 373:335 */       for (JavaTypeInstance typeInstance : getThrownTypes())
/* 374:    */       {
/* 375:336 */         first = StringUtils.comma(first, d);
/* 376:337 */         d.dump(typeInstance);
/* 377:    */       }
/* 378:    */     }
/* 379:    */   }
/* 380:    */   
/* 381:    */   public Op04StructuredStatement getAnalysis()
/* 382:    */   {
/* 383:343 */     if (this.codeAttribute == null) {
/* 384:343 */       throw new ConfusedCFRException("No code in this method to analyze");
/* 385:    */     }
/* 386:344 */     Op04StructuredStatement analysis = this.codeAttribute.analyse();
/* 387:345 */     return analysis;
/* 388:    */   }
/* 389:    */   
/* 390:    */   public boolean isConstructor()
/* 391:    */   {
/* 392:349 */     return this.isConstructor.isConstructor();
/* 393:    */   }
/* 394:    */   
/* 395:    */   public void analyse()
/* 396:    */   {
/* 397:    */     try
/* 398:    */     {
/* 399:354 */       if (this.codeAttribute != null) {
/* 400:355 */         this.codeAttribute.analyse();
/* 401:    */       }
/* 402:357 */       if (!this.methodPrototype.parametersComputed())
/* 403:    */       {
/* 404:361 */         Map<Integer, Ident> identMap = MapFactory.newLazyMap(new UnaryFunction()
/* 405:    */         {
/* 406:362 */           public int x = 0;
/* 407:    */           
/* 408:    */           public Ident invoke(Integer arg)
/* 409:    */           {
/* 410:366 */             return new Ident(arg.intValue(), 0);
/* 411:    */           }
/* 412:368 */         });
/* 413:369 */         this.methodPrototype.computeParameters(getConstructorFlag(), identMap);
/* 414:    */       }
/* 415:    */     }
/* 416:    */     catch (RuntimeException e)
/* 417:    */     {
/* 418:372 */       System.out.println("While processing method : " + getName());
/* 419:373 */       throw e;
/* 420:    */     }
/* 421:    */   }
/* 422:    */   
/* 423:    */   public boolean hasCodeAttribute()
/* 424:    */   {
/* 425:378 */     return this.codeAttribute != null;
/* 426:    */   }
/* 427:    */   
/* 428:    */   public AttributeCode getCodeAttribute()
/* 429:    */   {
/* 430:382 */     return this.codeAttribute;
/* 431:    */   }
/* 432:    */   
/* 433:    */   public void dumpComments(Dumper d)
/* 434:    */   {
/* 435:386 */     if (this.comments != null)
/* 436:    */     {
/* 437:387 */       this.comments.dump(d);
/* 438:389 */       for (DecompilerComment decompilerComment : this.comments.getCommentCollection())
/* 439:    */       {
/* 440:390 */         String string = decompilerComment.getSummaryMessage();
/* 441:391 */         if (string != null) {
/* 442:392 */           d.addSummaryError(this, string);
/* 443:    */         }
/* 444:    */       }
/* 445:    */     }
/* 446:    */   }
/* 447:    */   
/* 448:    */   public void setComments(DecompilerComments comments)
/* 449:    */   {
/* 450:399 */     this.comments = comments;
/* 451:    */   }
/* 452:    */   
/* 453:    */   private boolean isInnerVisibleTo(JavaTypeInstance maybeCaller)
/* 454:    */   {
/* 455:403 */     JavaRefTypeInstance thisClass = getClassFile().getRefClasstype();
/* 456:408 */     if (maybeCaller.getInnerClassHereInfo().isTransitiveInnerClassOf(thisClass)) {
/* 457:408 */       return true;
/* 458:    */     }
/* 459:409 */     if (thisClass.getInnerClassHereInfo().isTransitiveInnerClassOf(maybeCaller)) {
/* 460:409 */       return true;
/* 461:    */     }
/* 462:410 */     return false;
/* 463:    */   }
/* 464:    */   
/* 465:    */   public boolean isVisibleTo(JavaRefTypeInstance maybeCaller)
/* 466:    */   {
/* 467:414 */     if (this.accessFlags.contains(AccessFlagMethod.ACC_PUBLIC)) {
/* 468:414 */       return true;
/* 469:    */     }
/* 470:415 */     if (maybeCaller.equals(getClassFile().getClassType())) {
/* 471:415 */       return true;
/* 472:    */     }
/* 473:416 */     if (this.accessFlags.contains(AccessFlagMethod.ACC_PRIVATE)) {
/* 474:417 */       return isInnerVisibleTo(maybeCaller);
/* 475:    */     }
/* 476:419 */     if (this.accessFlags.contains(AccessFlagMethod.ACC_PROTECTED))
/* 477:    */     {
/* 478:421 */       BindingSuperContainer bindingSuperContainer = maybeCaller.getBindingSupers();
/* 479:423 */       if (bindingSuperContainer == null) {
/* 480:423 */         return false;
/* 481:    */       }
/* 482:424 */       if (bindingSuperContainer.containsBase(getClassFile().getClassType())) {
/* 483:424 */         return true;
/* 484:    */       }
/* 485:425 */       return isInnerVisibleTo(maybeCaller);
/* 486:    */     }
/* 487:428 */     if (maybeCaller.getPackageName().equals(getClassFile().getRefClasstype().getPackageName())) {
/* 488:428 */       return true;
/* 489:    */     }
/* 490:429 */     return false;
/* 491:    */   }
/* 492:    */   
/* 493:    */   public void dump(Dumper d, boolean asClass)
/* 494:    */   {
/* 495:433 */     if (this.codeAttribute != null) {
/* 496:435 */       this.codeAttribute.analyse();
/* 497:    */     }
/* 498:437 */     dumpComments(d);
/* 499:438 */     dumpSignatureText(asClass, d);
/* 500:439 */     if (this.codeAttribute == null)
/* 501:    */     {
/* 502:440 */       AttributeAnnotationDefault annotationDefault = (AttributeAnnotationDefault)getAttributeByName("AnnotationDefault");
/* 503:441 */       if (annotationDefault != null) {
/* 504:442 */         d.print(" default ").dump(annotationDefault.getElementValue());
/* 505:    */       }
/* 506:444 */       d.endCodeln();
/* 507:    */     }
/* 508:    */     else
/* 509:    */     {
/* 510:449 */       if (!this.localClasses.isEmpty())
/* 511:    */       {
/* 512:450 */         TypeUsageInformation overrides = new LocalClassAwareTypeUsageInformation(this.localClasses, d.getTypeUsageInformation());
/* 513:451 */         d = new TypeOverridingDumper(d, overrides);
/* 514:    */       }
/* 515:453 */       d.print(' ').dump(this.codeAttribute);
/* 516:    */     }
/* 517:    */   }
/* 518:    */   
/* 519:    */   public String toString()
/* 520:    */   {
/* 521:459 */     return getName() + ": " + this.methodPrototype;
/* 522:    */   }
/* 523:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.Method
 * JD-Core Version:    0.7.0.1
 */