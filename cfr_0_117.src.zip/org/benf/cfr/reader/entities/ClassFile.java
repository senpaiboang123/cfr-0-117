/*    1:     */ package org.benf.cfr.reader.entities;
/*    2:     */ 
/*    3:     */ import java.util.ArrayList;
/*    4:     */ import java.util.Collection;
/*    5:     */ import java.util.HashMap;
/*    6:     */ import java.util.Iterator;
/*    7:     */ import java.util.LinkedHashMap;
/*    8:     */ import java.util.List;
/*    9:     */ import java.util.Map;
/*   10:     */ import java.util.Map.Entry;
/*   11:     */ import java.util.Set;
/*   12:     */ import org.benf.cfr.reader.bytecode.CodeAnalyserWholeClass;
/*   13:     */ import org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationAnonymousInner;
/*   14:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*   15:     */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Triplet;
/*   16:     */ import org.benf.cfr.reader.bytecode.analysis.types.BindingSuperContainer;
/*   17:     */ import org.benf.cfr.reader.bytecode.analysis.types.BindingSuperContainer.Route;
/*   18:     */ import org.benf.cfr.reader.bytecode.analysis.types.BoundSuperCollector;
/*   19:     */ import org.benf.cfr.reader.bytecode.analysis.types.ClassSignature;
/*   20:     */ import org.benf.cfr.reader.bytecode.analysis.types.FormalTypeParameter;
/*   21:     */ import org.benf.cfr.reader.bytecode.analysis.types.GenericTypeBinder;
/*   22:     */ import org.benf.cfr.reader.bytecode.analysis.types.InnerClassInfo;
/*   23:     */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericRefTypeInstance;
/*   24:     */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*   25:     */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*   26:     */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*   27:     */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*   28:     */ import org.benf.cfr.reader.bytecode.analysis.types.TypeConstants;
/*   29:     */ import org.benf.cfr.reader.entities.attributes.Attribute;
/*   30:     */ import org.benf.cfr.reader.entities.attributes.AttributeBootstrapMethods;
/*   31:     */ import org.benf.cfr.reader.entities.attributes.AttributeInnerClasses;
/*   32:     */ import org.benf.cfr.reader.entities.attributes.AttributeRuntimeVisibleAnnotations;
/*   33:     */ import org.benf.cfr.reader.entities.attributes.AttributeSignature;
/*   34:     */ import org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumper;
/*   35:     */ import org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumper.InnerClassDumpType;
/*   36:     */ import org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumperAnnotation;
/*   37:     */ import org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumperInterface;
/*   38:     */ import org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumperNormal;
/*   39:     */ import org.benf.cfr.reader.entities.classfilehelpers.OverloadMethodSet;
/*   40:     */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*   41:     */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass;
/*   42:     */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolUtils;
/*   43:     */ import org.benf.cfr.reader.entities.innerclass.InnerClassAttributeInfo;
/*   44:     */ import org.benf.cfr.reader.entityfactories.AttributeFactory;
/*   45:     */ import org.benf.cfr.reader.entityfactories.ContiguousEntityFactory;
/*   46:     */ import org.benf.cfr.reader.relationship.MemberNameResolver;
/*   47:     */ import org.benf.cfr.reader.state.DCCommonState;
/*   48:     */ import org.benf.cfr.reader.state.InnerClassTypeUsageInformation;
/*   49:     */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*   50:     */ import org.benf.cfr.reader.state.TypeUsageInformation;
/*   51:     */ import org.benf.cfr.reader.util.CannotLoadClassException;
/*   52:     */ import org.benf.cfr.reader.util.ClassFileVersion;
/*   53:     */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*   54:     */ import org.benf.cfr.reader.util.DecompilerComment;
/*   55:     */ import org.benf.cfr.reader.util.DecompilerComments;
/*   56:     */ import org.benf.cfr.reader.util.Functional;
/*   57:     */ import org.benf.cfr.reader.util.ListFactory;
/*   58:     */ import org.benf.cfr.reader.util.MapFactory;
/*   59:     */ import org.benf.cfr.reader.util.Predicate;
/*   60:     */ import org.benf.cfr.reader.util.SetFactory;
/*   61:     */ import org.benf.cfr.reader.util.TypeUsageCollectable;
/*   62:     */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*   63:     */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*   64:     */ import org.benf.cfr.reader.util.getopt.Options;
/*   65:     */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*   66:     */ import org.benf.cfr.reader.util.output.Dumpable;
/*   67:     */ import org.benf.cfr.reader.util.output.Dumper;
/*   68:     */ import org.benf.cfr.reader.util.output.IllegalIdentifierReplacement;
/*   69:     */ import org.benf.cfr.reader.util.output.TypeOverridingDumper;
/*   70:     */ 
/*   71:     */ public class ClassFile
/*   72:     */   implements Dumpable, TypeUsageCollectable
/*   73:     */ {
/*   74:  35 */   private final long OFFSET_OF_MAGIC = 0L;
/*   75:  36 */   private final long OFFSET_OF_MINOR = 4L;
/*   76:  37 */   private final long OFFSET_OF_MAJOR = 6L;
/*   77:  38 */   private final long OFFSET_OF_CONSTANT_POOL_COUNT = 8L;
/*   78:  39 */   private final long OFFSET_OF_CONSTANT_POOL = 10L;
/*   79:     */   private final short minorVer;
/*   80:     */   private final short majorVer;
/*   81:     */   private final ConstantPool constantPool;
/*   82:     */   private final Set<AccessFlag> accessFlags;
/*   83:     */   private final List<ClassFileField> fields;
/*   84:     */   private Map<String, Map<JavaTypeInstance, ClassFileField>> fieldsByName;
/*   85:     */   private final List<Method> methods;
/*   86:     */   private Map<String, List<Method>> methodsByName;
/*   87:     */   private final Map<JavaTypeInstance, Pair<InnerClassAttributeInfo, ClassFile>> innerClassesByTypeInfo;
/*   88:     */   private final Map<String, Attribute> attributes;
/*   89:     */   private final ConstantPoolEntryClass thisClass;
/*   90:     */   private final ConstantPoolEntryClass rawSuperClass;
/*   91:     */   private final List<ConstantPoolEntryClass> rawInterfaces;
/*   92:     */   private final ClassSignature classSignature;
/*   93:     */   private final ClassFileVersion classFileVersion;
/*   94:     */   private DecompilerComments decompilerComments;
/*   95:     */   private boolean begunAnalysis;
/*   96:     */   private boolean hiddenInnerClass;
/*   97:     */   private BindingSuperContainer boundSuperClasses;
/*   98:     */   private ClassFileDumper dumpHelper;
/*   99:     */   private final String usePath;
/*  100:     */   
/*  101:     */   public ClassFile(ByteData data, String usePath, final DCCommonState dcCommonState)
/*  102:     */   {
/*  103:  86 */     this.usePath = usePath;
/*  104:  87 */     Options options = dcCommonState.getOptions();
/*  105:     */     
/*  106:  89 */     int magic = data.getS4At(0L);
/*  107:  90 */     if (magic != -889275714) {
/*  108:  90 */       throw new ConfusedCFRException("Magic != Cafebabe for class file '" + usePath + "'");
/*  109:     */     }
/*  110:  92 */     this.minorVer = data.getS2At(4L);
/*  111:  93 */     this.majorVer = data.getS2At(6L);
/*  112:  94 */     ClassFileVersion classFileVersion = new ClassFileVersion(this.majorVer, this.minorVer);
/*  113:  95 */     final ClassFileVersion cfv = classFileVersion;
/*  114:  96 */     short constantPoolCount = data.getS2At(8L);
/*  115:  97 */     this.constantPool = new ConstantPool(this, dcCommonState, data.getOffsetData(10L), constantPoolCount);
/*  116:  98 */     long OFFSET_OF_ACCESS_FLAGS = 10L + this.constantPool.getRawByteLength();
/*  117:  99 */     long OFFSET_OF_THIS_CLASS = OFFSET_OF_ACCESS_FLAGS + 2L;
/*  118: 100 */     long OFFSET_OF_SUPER_CLASS = OFFSET_OF_THIS_CLASS + 2L;
/*  119: 101 */     long OFFSET_OF_INTERFACES_COUNT = OFFSET_OF_SUPER_CLASS + 2L;
/*  120: 102 */     long OFFSET_OF_INTERFACES = OFFSET_OF_INTERFACES_COUNT + 2L;
/*  121:     */     
/*  122: 104 */     short numInterfaces = data.getS2At(OFFSET_OF_INTERFACES_COUNT);
/*  123: 105 */     ArrayList<ConstantPoolEntryClass> tmpInterfaces = new ArrayList();
/*  124: 106 */     ContiguousEntityFactory.buildSized(data.getOffsetData(OFFSET_OF_INTERFACES), numInterfaces, 2, tmpInterfaces, new UnaryFunction()
/*  125:     */     {
/*  126:     */       public ConstantPoolEntryClass invoke(ByteData arg)
/*  127:     */       {
/*  128: 110 */         return (ConstantPoolEntryClass)ClassFile.this.constantPool.getEntry(arg.getS2At(0L));
/*  129:     */       }
/*  130: 113 */     });
/*  131: 114 */     this.thisClass = ((ConstantPoolEntryClass)this.constantPool.getEntry(data.getS2At(OFFSET_OF_THIS_CLASS)));
/*  132:     */     
/*  133:     */ 
/*  134:     */ 
/*  135:     */ 
/*  136: 119 */     this.rawInterfaces = tmpInterfaces;
/*  137:     */     
/*  138:     */ 
/*  139: 122 */     this.accessFlags = AccessFlag.build(data.getS2At(OFFSET_OF_ACCESS_FLAGS));
/*  140:     */     
/*  141: 124 */     long OFFSET_OF_FIELDS_COUNT = OFFSET_OF_INTERFACES + 2 * numInterfaces;
/*  142: 125 */     long OFFSET_OF_FIELDS = OFFSET_OF_FIELDS_COUNT + 2L;
/*  143: 126 */     short numFields = data.getS2At(OFFSET_OF_FIELDS_COUNT);
/*  144: 127 */     List<Field> tmpFields = ListFactory.newList();
/*  145: 128 */     long fieldsLength = ContiguousEntityFactory.build(data.getOffsetData(OFFSET_OF_FIELDS), numFields, tmpFields, new UnaryFunction()
/*  146:     */     {
/*  147:     */       public Field invoke(ByteData arg)
/*  148:     */       {
/*  149: 132 */         return new Field(arg, ClassFile.this.constantPool, cfv);
/*  150:     */       }
/*  151: 134 */     });
/*  152: 135 */     this.fields = ListFactory.newList();
/*  153: 136 */     for (Field tmpField : tmpFields) {
/*  154: 137 */       this.fields.add(new ClassFileField(tmpField));
/*  155:     */     }
/*  156: 140 */     long OFFSET_OF_METHODS_COUNT = OFFSET_OF_FIELDS + fieldsLength;
/*  157: 141 */     long OFFSET_OF_METHODS = OFFSET_OF_METHODS_COUNT + 2L;
/*  158: 142 */     short numMethods = data.getS2At(OFFSET_OF_METHODS_COUNT);
/*  159: 143 */     List<Method> tmpMethods = new ArrayList(numMethods);
/*  160: 144 */     long methodsLength = ContiguousEntityFactory.build(data.getOffsetData(OFFSET_OF_METHODS), numMethods, tmpMethods, new UnaryFunction()
/*  161:     */     {
/*  162:     */       public Method invoke(ByteData arg)
/*  163:     */       {
/*  164: 148 */         return new Method(arg, ClassFile.this, ClassFile.this.constantPool, dcCommonState, cfv);
/*  165:     */       }
/*  166:     */     });
/*  167: 152 */     if (this.accessFlags.contains(AccessFlag.ACC_STRICT)) {
/*  168: 153 */       for (Method method : tmpMethods) {
/*  169: 154 */         method.getAccessFlags().remove(AccessFlagMethod.ACC_STRICT);
/*  170:     */       }
/*  171:     */     }
/*  172: 157 */     if (!((Boolean)options.getOption(OptionsImpl.RENAME_ILLEGAL_IDENTS)).booleanValue()) {
/*  173: 158 */       for (Method method : tmpMethods) {
/*  174: 159 */         if (IllegalIdentifierReplacement.isIllegalMethodName(method.getName()))
/*  175:     */         {
/*  176: 160 */           addComment(DecompilerComment.ILLEGAL_IDENTIFIERS);
/*  177: 161 */           break;
/*  178:     */         }
/*  179:     */       }
/*  180:     */     }
/*  181: 166 */     long OFFSET_OF_ATTRIBUTES_COUNT = OFFSET_OF_METHODS + methodsLength;
/*  182: 167 */     long OFFSET_OF_ATTRIBUTES = OFFSET_OF_ATTRIBUTES_COUNT + 2L;
/*  183: 168 */     short numAttributes = data.getS2At(OFFSET_OF_ATTRIBUTES_COUNT);
/*  184: 169 */     ArrayList<Attribute> tmpAttributes = new ArrayList();
/*  185: 170 */     tmpAttributes.ensureCapacity(numAttributes);
/*  186: 171 */     ContiguousEntityFactory.build(data.getOffsetData(OFFSET_OF_ATTRIBUTES), numAttributes, tmpAttributes, AttributeFactory.getBuilder(this.constantPool, classFileVersion));
/*  187:     */     
/*  188:     */ 
/*  189:     */ 
/*  190: 175 */     this.attributes = ContiguousEntityFactory.addToMap(new HashMap(), tmpAttributes);
/*  191: 176 */     AccessFlag.applyAttributes(this.attributes, this.accessFlags);
/*  192:     */     
/*  193: 178 */     short superClassIndex = data.getS2At(OFFSET_OF_SUPER_CLASS);
/*  194: 179 */     if (superClassIndex == 0) {
/*  195: 180 */       this.rawSuperClass = null;
/*  196:     */     } else {
/*  197: 182 */       this.rawSuperClass = ((ConstantPoolEntryClass)this.constantPool.getEntry(superClassIndex));
/*  198:     */     }
/*  199: 184 */     this.classSignature = getSignature(this.constantPool, this.rawSuperClass, this.rawInterfaces);
/*  200:     */     
/*  201: 186 */     this.methods = tmpMethods;
/*  202:     */     
/*  203:     */ 
/*  204: 189 */     this.innerClassesByTypeInfo = new LinkedHashMap();
/*  205:     */     
/*  206: 191 */     boolean isInterface = this.accessFlags.contains(AccessFlag.ACC_INTERFACE);
/*  207: 192 */     boolean isAnnotation = this.accessFlags.contains(AccessFlag.ACC_ANNOTATION);
/*  208: 196 */     if (isInterface)
/*  209:     */     {
/*  210: 197 */       if (isAnnotation) {
/*  211: 198 */         this.dumpHelper = new ClassFileDumperAnnotation(dcCommonState);
/*  212:     */       } else {
/*  213: 200 */         this.dumpHelper = new ClassFileDumperInterface(dcCommonState);
/*  214:     */       }
/*  215:     */     }
/*  216:     */     else {
/*  217: 203 */       this.dumpHelper = new ClassFileDumperNormal(dcCommonState);
/*  218:     */     }
/*  219: 209 */     if (classFileVersion.before(ClassFileVersion.JAVA_6))
/*  220:     */     {
/*  221: 210 */       boolean hasSignature = false;
/*  222: 211 */       if (null != getAttributeByName("Signature")) {
/*  223: 211 */         hasSignature = true;
/*  224:     */       }
/*  225: 212 */       if (!hasSignature) {
/*  226: 213 */         for (Method method : this.methods) {
/*  227: 214 */           if (null != method.getSignatureAttribute())
/*  228:     */           {
/*  229: 215 */             hasSignature = true;
/*  230: 216 */             break;
/*  231:     */           }
/*  232:     */         }
/*  233:     */       }
/*  234: 220 */       if (hasSignature)
/*  235:     */       {
/*  236: 221 */         addComment("This class specifies class file version " + classFileVersion + " but uses Java 6 signatures.  Assumed Java 6.");
/*  237: 222 */         classFileVersion = ClassFileVersion.JAVA_6;
/*  238:     */       }
/*  239:     */     }
/*  240: 225 */     if (classFileVersion.before(ClassFileVersion.JAVA_1_0)) {
/*  241: 226 */       addComment(new DecompilerComment("Class file version " + classFileVersion + " predates " + ClassFileVersion.JAVA_1_0 + ", recompilation may lose compatibility!"));
/*  242:     */     }
/*  243: 229 */     this.classFileVersion = classFileVersion;
/*  244:     */     
/*  245:     */ 
/*  246:     */ 
/*  247:     */ 
/*  248:     */ 
/*  249: 235 */     AttributeInnerClasses attributeInnerClasses = (AttributeInnerClasses)getAttributeByName("InnerClasses");
/*  250: 236 */     JavaRefTypeInstance typeInstance = (JavaRefTypeInstance)this.thisClass.getTypeInstance();
/*  251: 237 */     if (typeInstance.getInnerClassHereInfo().isInnerClass()) {
/*  252: 238 */       checkInnerClassAssumption(attributeInnerClasses, typeInstance);
/*  253:     */     }
/*  254: 245 */     if ((!((Boolean)options.getOption(OptionsImpl.RENAME_DUP_MEMBERS)).booleanValue()) && 
/*  255: 246 */       (MemberNameResolver.verifySingleClassNames(this))) {
/*  256: 247 */       addComment(DecompilerComment.RENAME_MEMBERS);
/*  257:     */     }
/*  258: 251 */     fixConfusingEnumConstructors();
/*  259: 253 */     if (((Boolean)options.getOption(OptionsImpl.ELIDE_SCALA)).booleanValue()) {
/*  260: 254 */       elideScala();
/*  261:     */     }
/*  262:     */   }
/*  263:     */   
/*  264:     */   private void fixConfusingEnumConstructors()
/*  265:     */   {
/*  266: 267 */     if ((testAccessFlag(AccessFlag.ACC_ENUM)) && (TypeConstants.ENUM.equals(getBaseClassType())))
/*  267:     */     {
/*  268: 268 */       List<Method> constructors = getConstructors();
/*  269: 269 */       for (Method constructor : constructors)
/*  270:     */       {
/*  271: 270 */         MethodPrototype prototype = constructor.getMethodPrototype();
/*  272: 271 */         prototype.unbreakEnumConstructor();
/*  273:     */       }
/*  274:     */     }
/*  275:     */   }
/*  276:     */   
/*  277:     */   private void elideScala()
/*  278:     */   {
/*  279:     */     try
/*  280:     */     {
/*  281: 285 */       ClassFileField f = getFieldByName("serialVersionUID", RawJavaType.LONG);
/*  282: 286 */       f.markHidden();
/*  283:     */     }
/*  284:     */     catch (Exception e) {}
/*  285: 290 */     AttributeRuntimeVisibleAnnotations annotations = (AttributeRuntimeVisibleAnnotations)getAttributeByName("RuntimeVisibleAnnotations");
/*  286: 291 */     if (annotations != null) {
/*  287: 292 */       annotations.hide(TypeConstants.SCALA_SIGNATURE);
/*  288:     */     }
/*  289:     */   }
/*  290:     */   
/*  291:     */   private static void checkInnerClassAssumption(AttributeInnerClasses attributeInnerClasses, JavaRefTypeInstance typeInstance)
/*  292:     */   {
/*  293: 300 */     if (attributeInnerClasses != null) {
/*  294: 301 */       for (InnerClassAttributeInfo innerClassAttributeInfo : attributeInnerClasses.getInnerClassAttributeInfoList()) {
/*  295: 302 */         if (innerClassAttributeInfo.getInnerClassInfo().equals(typeInstance)) {
/*  296: 303 */           return;
/*  297:     */         }
/*  298:     */       }
/*  299:     */     }
/*  300: 310 */     typeInstance.markNotInner();
/*  301:     */   }
/*  302:     */   
/*  303:     */   public String getUsePath()
/*  304:     */   {
/*  305: 314 */     return this.usePath;
/*  306:     */   }
/*  307:     */   
/*  308:     */   public void addComment(DecompilerComment comment)
/*  309:     */   {
/*  310: 318 */     if (this.decompilerComments == null) {
/*  311: 318 */       this.decompilerComments = new DecompilerComments();
/*  312:     */     }
/*  313: 319 */     this.decompilerComments.addComment(comment);
/*  314:     */   }
/*  315:     */   
/*  316:     */   public void addComment(String comment)
/*  317:     */   {
/*  318: 323 */     if (this.decompilerComments == null) {
/*  319: 323 */       this.decompilerComments = new DecompilerComments();
/*  320:     */     }
/*  321: 324 */     this.decompilerComments.addComment(comment);
/*  322:     */   }
/*  323:     */   
/*  324:     */   private void addComment(String comment, Exception e)
/*  325:     */   {
/*  326: 328 */     addComment(new DecompilerComment(comment, e));
/*  327:     */   }
/*  328:     */   
/*  329:     */   public DecompilerComments getDecompilerComments()
/*  330:     */   {
/*  331: 332 */     return this.decompilerComments;
/*  332:     */   }
/*  333:     */   
/*  334:     */   private void getAllCps(Set<ConstantPool> tgt)
/*  335:     */   {
/*  336: 336 */     tgt.add(this.constantPool);
/*  337: 337 */     for (Pair<InnerClassAttributeInfo, ClassFile> pair : this.innerClassesByTypeInfo.values()) {
/*  338: 338 */       ((ClassFile)pair.getSecond()).getAllCps(tgt);
/*  339:     */     }
/*  340:     */   }
/*  341:     */   
/*  342:     */   public List<JavaTypeInstance> getAllClassTypes()
/*  343:     */   {
/*  344: 343 */     List<JavaTypeInstance> res = ListFactory.newList();
/*  345: 344 */     getAllClassTypes(res);
/*  346: 345 */     return res;
/*  347:     */   }
/*  348:     */   
/*  349:     */   public void collectTypeUsages(TypeUsageCollector collector)
/*  350:     */   {
/*  351: 350 */     if (this.thisClass != null) {
/*  352: 351 */       collector.collect(this.thisClass.getTypeInstance());
/*  353:     */     }
/*  354: 353 */     collector.collectFrom(this.classSignature);
/*  355: 355 */     for (ClassFileField field : this.fields)
/*  356:     */     {
/*  357: 356 */       collector.collectFrom(field.getField());
/*  358: 357 */       collector.collectFrom(field.getInitialValue());
/*  359:     */     }
/*  360: 359 */     collector.collectFrom(this.methods);
/*  361: 361 */     for (Map.Entry<JavaTypeInstance, Pair<InnerClassAttributeInfo, ClassFile>> innerClassByTypeInfo : this.innerClassesByTypeInfo.entrySet())
/*  362:     */     {
/*  363: 362 */       collector.collect((JavaTypeInstance)innerClassByTypeInfo.getKey());
/*  364: 363 */       ClassFile innerClassFile = (ClassFile)((Pair)innerClassByTypeInfo.getValue()).getSecond();
/*  365: 364 */       innerClassFile.collectTypeUsages(collector);
/*  366:     */     }
/*  367: 366 */     collector.collectFrom(this.dumpHelper);
/*  368: 367 */     collector.collectFrom(getAttributeByName("RuntimeVisibleAnnotations"));
/*  369: 368 */     collector.collectFrom(getAttributeByName("RuntimeInvisibleAnnotations"));
/*  370:     */   }
/*  371:     */   
/*  372:     */   private void getAllClassTypes(List<JavaTypeInstance> tgt)
/*  373:     */   {
/*  374: 372 */     tgt.add(getClassType());
/*  375: 373 */     for (Pair<InnerClassAttributeInfo, ClassFile> pair : this.innerClassesByTypeInfo.values()) {
/*  376: 374 */       ((ClassFile)pair.getSecond()).getAllClassTypes(tgt);
/*  377:     */     }
/*  378:     */   }
/*  379:     */   
/*  380:     */   public void setDumpHelper(ClassFileDumper dumpHelper)
/*  381:     */   {
/*  382: 379 */     this.dumpHelper = dumpHelper;
/*  383:     */   }
/*  384:     */   
/*  385:     */   public void markHiddenInnerClass()
/*  386:     */   {
/*  387: 383 */     this.hiddenInnerClass = true;
/*  388:     */   }
/*  389:     */   
/*  390:     */   public ClassFileVersion getClassFileVersion()
/*  391:     */   {
/*  392: 387 */     return this.classFileVersion;
/*  393:     */   }
/*  394:     */   
/*  395:     */   public boolean isInnerClass()
/*  396:     */   {
/*  397: 391 */     if (this.thisClass == null) {
/*  398: 391 */       return false;
/*  399:     */     }
/*  400: 392 */     return this.thisClass.getTypeInstance().getInnerClassHereInfo().isInnerClass();
/*  401:     */   }
/*  402:     */   
/*  403:     */   public ConstantPool getConstantPool()
/*  404:     */   {
/*  405: 396 */     return this.constantPool;
/*  406:     */   }
/*  407:     */   
/*  408:     */   public boolean testAccessFlag(AccessFlag accessFlag)
/*  409:     */   {
/*  410: 400 */     return this.accessFlags.contains(accessFlag);
/*  411:     */   }
/*  412:     */   
/*  413:     */   private void markAsStatic()
/*  414:     */   {
/*  415: 404 */     this.accessFlags.add(AccessFlag.ACC_STATIC);
/*  416:     */   }
/*  417:     */   
/*  418:     */   public boolean hasFormalTypeParameters()
/*  419:     */   {
/*  420: 408 */     List<FormalTypeParameter> formalTypeParameters = this.classSignature.getFormalTypeParameters();
/*  421: 409 */     return (formalTypeParameters != null) && (!formalTypeParameters.isEmpty());
/*  422:     */   }
/*  423:     */   
/*  424:     */   public ClassFileField getFieldByName(String name, JavaTypeInstance type)
/*  425:     */     throws NoSuchFieldException
/*  426:     */   {
/*  427: 414 */     if (this.fieldsByName == null)
/*  428:     */     {
/*  429: 415 */       Options options = this.constantPool.getDCCommonState().getOptions();
/*  430: 416 */       boolean testIllegal = !((Boolean)options.getOption(OptionsImpl.RENAME_ILLEGAL_IDENTS)).booleanValue();
/*  431: 417 */       boolean illegal = false;
/*  432: 418 */       this.fieldsByName = MapFactory.newMap();
/*  433: 419 */       if (testIllegal) {
/*  434: 420 */         for (ClassFileField field : this.fields)
/*  435:     */         {
/*  436: 421 */           String rawFieldName = field.getFieldName();
/*  437: 423 */           if (IllegalIdentifierReplacement.isIllegal(rawFieldName))
/*  438:     */           {
/*  439: 424 */             illegal = true;
/*  440: 425 */             break;
/*  441:     */           }
/*  442:     */         }
/*  443:     */       }
/*  444: 429 */       int smallMemberThreshold = ((Integer)options.getOption(OptionsImpl.RENAME_SMALL_MEMBERS)).intValue();
/*  445: 430 */       boolean renameSmallMembers = smallMemberThreshold > 0;
/*  446: 431 */       for (ClassFileField field : this.fields)
/*  447:     */       {
/*  448: 432 */         String fieldName = field.getFieldName();
/*  449: 433 */         JavaTypeInstance fieldType = field.getField().getJavaTypeInstance();
/*  450: 434 */         Map<JavaTypeInstance, ClassFileField> perNameMap = (Map)this.fieldsByName.get(fieldName);
/*  451: 435 */         if (perNameMap == null)
/*  452:     */         {
/*  453: 436 */           perNameMap = MapFactory.newLinkedMap();
/*  454: 437 */           this.fieldsByName.put(fieldName, perNameMap);
/*  455:     */         }
/*  456: 439 */         perNameMap.put(fieldType, field);
/*  457: 440 */         if ((renameSmallMembers) && (fieldName.length() <= smallMemberThreshold)) {
/*  458: 441 */           field.getField().setDisambiguate();
/*  459:     */         }
/*  460:     */       }
/*  461: 444 */       boolean warnAmbig = false;
/*  462: 445 */       for (Map<JavaTypeInstance, ClassFileField> typeMap : this.fieldsByName.values()) {
/*  463: 446 */         if (typeMap.size() > 1) {
/*  464: 447 */           if (((Boolean)this.constantPool.getDCCommonState().getOptions().getOption(OptionsImpl.RENAME_DUP_MEMBERS)).booleanValue()) {
/*  465: 448 */             for (ClassFileField field : typeMap.values()) {
/*  466: 449 */               field.getField().setDisambiguate();
/*  467:     */             }
/*  468:     */           } else {
/*  469: 452 */             warnAmbig = true;
/*  470:     */           }
/*  471:     */         }
/*  472:     */       }
/*  473: 456 */       if (warnAmbig) {
/*  474: 457 */         addComment(DecompilerComment.RENAME_MEMBERS);
/*  475:     */       }
/*  476: 459 */       if (illegal) {
/*  477: 460 */         addComment(DecompilerComment.ILLEGAL_IDENTIFIERS);
/*  478:     */       }
/*  479:     */     }
/*  480: 463 */     Map<JavaTypeInstance, ClassFileField> fieldsByType = (Map)this.fieldsByName.get(name);
/*  481: 464 */     if ((fieldsByType == null) || (fieldsByType.isEmpty())) {
/*  482: 465 */       throw new NoSuchFieldException(name);
/*  483:     */     }
/*  484: 467 */     ClassFileField field = (ClassFileField)fieldsByType.get(type);
/*  485: 468 */     if (field == null) {
/*  486: 470 */       return (ClassFileField)fieldsByType.values().iterator().next();
/*  487:     */     }
/*  488: 472 */     return field;
/*  489:     */   }
/*  490:     */   
/*  491:     */   public List<ClassFileField> getFields()
/*  492:     */   {
/*  493: 476 */     return this.fields;
/*  494:     */   }
/*  495:     */   
/*  496:     */   public List<Method> getMethods()
/*  497:     */   {
/*  498: 480 */     return this.methods;
/*  499:     */   }
/*  500:     */   
/*  501:     */   public void removePointlessMethod(Method method)
/*  502:     */   {
/*  503: 484 */     this.methodsByName.remove(method.getName());
/*  504: 485 */     this.methods.remove(method);
/*  505:     */   }
/*  506:     */   
/*  507:     */   private List<Method> getMethodsWithMatchingName(final MethodPrototype prototype)
/*  508:     */   {
/*  509: 489 */     List<Method> named = Functional.filter(this.methods, new Predicate()
/*  510:     */     {
/*  511:     */       public boolean test(Method in)
/*  512:     */       {
/*  513: 492 */         return in.getName().equals(prototype.getName());
/*  514:     */       }
/*  515: 494 */     });
/*  516: 495 */     return named;
/*  517:     */   }
/*  518:     */   
/*  519:     */   public OverloadMethodSet getOverloadMethodSet(MethodPrototype prototype)
/*  520:     */   {
/*  521: 499 */     List<Method> named = getMethodsWithMatchingName(prototype);
/*  522:     */     
/*  523:     */ 
/*  524:     */ 
/*  525: 503 */     final boolean isInstance = prototype.isInstanceMethod();
/*  526: 504 */     final int numArgs = prototype.getArgs().size();
/*  527: 505 */     final boolean isVarArgs = prototype.isVarArgs();
/*  528: 506 */     named = Functional.filter(named, new Predicate()
/*  529:     */     {
/*  530:     */       public boolean test(Method in)
/*  531:     */       {
/*  532: 509 */         MethodPrototype other = in.getMethodPrototype();
/*  533: 510 */         if (other.isInstanceMethod() != isInstance) {
/*  534: 510 */           return false;
/*  535:     */         }
/*  536: 511 */         boolean otherIsVarargs = other.isVarArgs();
/*  537: 512 */         if (isVarArgs)
/*  538:     */         {
/*  539: 513 */           if (otherIsVarargs) {
/*  540: 513 */             return true;
/*  541:     */           }
/*  542: 514 */           return other.getArgs().size() >= numArgs;
/*  543:     */         }
/*  544: 516 */         if (otherIsVarargs) {
/*  545: 517 */           return other.getArgs().size() <= numArgs;
/*  546:     */         }
/*  547: 519 */         return other.getArgs().size() == numArgs;
/*  548:     */       }
/*  549: 521 */     });
/*  550: 522 */     List<MethodPrototype> prototypes = Functional.map(named, new UnaryFunction()
/*  551:     */     {
/*  552:     */       public MethodPrototype invoke(Method arg)
/*  553:     */       {
/*  554: 525 */         return arg.getMethodPrototype();
/*  555:     */       }
/*  556: 533 */     });
/*  557: 534 */     List<MethodPrototype> out = ListFactory.newList();
/*  558: 535 */     Set<String> matched = SetFactory.newSet();
/*  559: 536 */     out.add(prototype);
/*  560: 537 */     matched.add(prototype.getComparableString());
/*  561: 538 */     for (MethodPrototype other : prototypes) {
/*  562: 539 */       if (matched.add(other.getComparableString())) {
/*  563: 540 */         out.add(other);
/*  564:     */       }
/*  565:     */     }
/*  566: 544 */     return new OverloadMethodSet(this, prototype, out);
/*  567:     */   }
/*  568:     */   
/*  569:     */   public Method getMethodByPrototype(MethodPrototype prototype)
/*  570:     */     throws NoSuchMethodException
/*  571:     */   {
/*  572: 554 */     List<Method> named = getMethodsWithMatchingName(prototype);
/*  573: 555 */     Method methodMatch = null;
/*  574: 556 */     for (Method method : named)
/*  575:     */     {
/*  576: 557 */       MethodPrototype tgt = method.getMethodPrototype();
/*  577: 558 */       if (tgt.equalsMatch(prototype)) {
/*  578: 558 */         return method;
/*  579:     */       }
/*  580: 559 */       if (tgt.equalsGeneric(prototype)) {
/*  581: 560 */         methodMatch = method;
/*  582:     */       }
/*  583:     */     }
/*  584: 563 */     if (methodMatch != null) {
/*  585: 563 */       return methodMatch;
/*  586:     */     }
/*  587: 564 */     throw new NoSuchMethodException();
/*  588:     */   }
/*  589:     */   
/*  590:     */   public Method getAccessibleMethodByPrototype(MethodPrototype prototype, GenericTypeBinder binder, JavaRefTypeInstance accessor)
/*  591:     */     throws NoSuchMethodException
/*  592:     */   {
/*  593: 568 */     List<Method> named = getMethodsWithMatchingName(prototype);
/*  594: 569 */     Method methodMatch = null;
/*  595: 570 */     for (Method method : named) {
/*  596: 571 */       if (method.isVisibleTo(accessor))
/*  597:     */       {
/*  598: 572 */         MethodPrototype tgt = method.getMethodPrototype();
/*  599: 573 */         if (tgt.equalsMatch(prototype)) {
/*  600: 573 */           return method;
/*  601:     */         }
/*  602: 574 */         if ((binder != null) && 
/*  603: 575 */           (tgt.equalsGeneric(prototype, binder))) {
/*  604: 576 */           methodMatch = method;
/*  605:     */         }
/*  606:     */       }
/*  607:     */     }
/*  608: 580 */     if (methodMatch != null) {
/*  609: 580 */       return methodMatch;
/*  610:     */     }
/*  611: 581 */     throw new NoSuchMethodException();
/*  612:     */   }
/*  613:     */   
/*  614:     */   public Method getSingleMethodByNameOrNull(String name)
/*  615:     */   {
/*  616: 586 */     List<Method> methodList = getMethodsByNameOrNull(name);
/*  617: 587 */     if ((methodList == null) || (methodList.size() != 1)) {
/*  618: 587 */       return null;
/*  619:     */     }
/*  620: 588 */     return (Method)methodList.get(0);
/*  621:     */   }
/*  622:     */   
/*  623:     */   public List<Method> getMethodsByNameOrNull(String name)
/*  624:     */   {
/*  625: 592 */     if (this.methodsByName == null)
/*  626:     */     {
/*  627: 593 */       this.methodsByName = MapFactory.newMap();
/*  628: 594 */       for (Method method : this.methods)
/*  629:     */       {
/*  630: 595 */         List<Method> list = (List)this.methodsByName.get(method.getName());
/*  631: 596 */         if (list == null)
/*  632:     */         {
/*  633: 597 */           list = ListFactory.newList();
/*  634: 598 */           this.methodsByName.put(method.getName(), list);
/*  635:     */         }
/*  636: 600 */         list.add(method);
/*  637:     */       }
/*  638:     */     }
/*  639: 603 */     return (List)this.methodsByName.get(name);
/*  640:     */   }
/*  641:     */   
/*  642:     */   public List<Method> getMethodByName(String name)
/*  643:     */     throws NoSuchMethodException
/*  644:     */   {
/*  645: 607 */     List<Method> methods = getMethodsByNameOrNull(name);
/*  646: 608 */     if (methods == null) {
/*  647: 608 */       throw new NoSuchMethodException(name);
/*  648:     */     }
/*  649: 609 */     return methods;
/*  650:     */   }
/*  651:     */   
/*  652:     */   public List<Method> getConstructors()
/*  653:     */   {
/*  654: 614 */     List<Method> res = ListFactory.newList();
/*  655: 615 */     for (Method method : this.methods) {
/*  656: 616 */       if (method.isConstructor()) {
/*  657: 616 */         res.add(method);
/*  658:     */       }
/*  659:     */     }
/*  660: 618 */     return res;
/*  661:     */   }
/*  662:     */   
/*  663:     */   public <X extends Attribute> X getAttributeByName(String name)
/*  664:     */   {
/*  665: 622 */     Attribute attribute = (Attribute)this.attributes.get(name);
/*  666: 623 */     if (attribute == null) {
/*  667: 623 */       return null;
/*  668:     */     }
/*  669: 625 */     X tmp = attribute;
/*  670: 626 */     return tmp;
/*  671:     */   }
/*  672:     */   
/*  673:     */   public AttributeBootstrapMethods getBootstrapMethods()
/*  674:     */   {
/*  675: 630 */     return (AttributeBootstrapMethods)getAttributeByName("BootstrapMethods");
/*  676:     */   }
/*  677:     */   
/*  678:     */   public ConstantPoolEntryClass getThisClassConstpoolEntry()
/*  679:     */   {
/*  680: 634 */     return this.thisClass;
/*  681:     */   }
/*  682:     */   
/*  683:     */   public void loadInnerClasses(DCCommonState dcCommonState)
/*  684:     */   {
/*  685: 639 */     Options options = dcCommonState.getOptions();
/*  686:     */     
/*  687: 641 */     AttributeInnerClasses attributeInnerClasses = (AttributeInnerClasses)getAttributeByName("InnerClasses");
/*  688: 642 */     if (attributeInnerClasses == null) {
/*  689: 643 */       return;
/*  690:     */     }
/*  691: 645 */     List<InnerClassAttributeInfo> innerClassAttributeInfoList = attributeInnerClasses.getInnerClassAttributeInfoList();
/*  692:     */     
/*  693: 647 */     JavaTypeInstance thisType = this.thisClass.getTypeInstance();
/*  694: 650 */     for (InnerClassAttributeInfo innerClassAttributeInfo : innerClassAttributeInfoList)
/*  695:     */     {
/*  696: 651 */       JavaTypeInstance innerType = innerClassAttributeInfo.getInnerClassInfo();
/*  697: 652 */       if (innerType != null)
/*  698:     */       {
/*  699: 654 */         if (innerType == thisType)
/*  700:     */         {
/*  701: 655 */           JavaTypeInstance outerType = innerClassAttributeInfo.getOuterClassInfo();
/*  702: 656 */           if ((outerType == null) || (outerType == thisType))
/*  703:     */           {
/*  704: 657 */             this.accessFlags.addAll(innerClassAttributeInfo.getAccessFlags());
/*  705:     */             
/*  706: 659 */             sanitiseAccessPermissions();
/*  707:     */           }
/*  708:     */         }
/*  709: 667 */         if (innerType.getInnerClassHereInfo().isInnerClassOf(thisType)) {
/*  710:     */           try
/*  711:     */           {
/*  712: 672 */             ClassFile innerClass = dcCommonState.getClassFile(innerType);
/*  713: 673 */             innerClass.loadInnerClasses(dcCommonState);
/*  714:     */             
/*  715:     */ 
/*  716:     */ 
/*  717: 677 */             this.innerClassesByTypeInfo.put(innerType, new Pair(innerClassAttributeInfo, innerClass));
/*  718:     */           }
/*  719:     */           catch (CannotLoadClassException e) {}
/*  720:     */         }
/*  721:     */       }
/*  722:     */     }
/*  723:     */   }
/*  724:     */   
/*  725:     */   private void analyseInnerClassesPass1(DCCommonState state)
/*  726:     */   {
/*  727: 685 */     if (this.innerClassesByTypeInfo == null) {
/*  728: 685 */       return;
/*  729:     */     }
/*  730: 686 */     for (Pair<InnerClassAttributeInfo, ClassFile> innerClassInfoClassFilePair : this.innerClassesByTypeInfo.values())
/*  731:     */     {
/*  732: 687 */       ClassFile classFile = (ClassFile)innerClassInfoClassFilePair.getSecond();
/*  733: 688 */       classFile.analyseMid(state);
/*  734:     */     }
/*  735:     */   }
/*  736:     */   
/*  737:     */   private void analysePassOuterFirst(DCCommonState state)
/*  738:     */   {
/*  739:     */     try
/*  740:     */     {
/*  741: 694 */       CodeAnalyserWholeClass.wholeClassAnalysisPass2(this, state);
/*  742:     */     }
/*  743:     */     catch (RuntimeException e)
/*  744:     */     {
/*  745: 696 */       addComment("Exception performing whole class analysis ignored.", e);
/*  746:     */     }
/*  747: 699 */     if (this.innerClassesByTypeInfo == null) {
/*  748: 699 */       return;
/*  749:     */     }
/*  750: 700 */     for (Pair<InnerClassAttributeInfo, ClassFile> innerClassInfoClassFilePair : this.innerClassesByTypeInfo.values())
/*  751:     */     {
/*  752: 701 */       ClassFile classFile = (ClassFile)innerClassInfoClassFilePair.getSecond();
/*  753: 702 */       classFile.analysePassOuterFirst(state);
/*  754:     */     }
/*  755:     */   }
/*  756:     */   
/*  757:     */   public void analyseTop(DCCommonState dcCommonState)
/*  758:     */   {
/*  759: 707 */     analyseMid(dcCommonState);
/*  760: 708 */     analysePassOuterFirst(dcCommonState);
/*  761:     */   }
/*  762:     */   
/*  763:     */   private void analyseOverrides()
/*  764:     */   {
/*  765:     */     try
/*  766:     */     {
/*  767: 713 */       BindingSuperContainer bindingSuperContainer = getBindingSupers();
/*  768: 714 */       Map<JavaRefTypeInstance, JavaGenericRefTypeInstance> boundSupers = bindingSuperContainer.getBoundSuperClasses();
/*  769: 715 */       bindTesters = ListFactory.newList();
/*  770: 716 */       for (Map.Entry<JavaRefTypeInstance, JavaGenericRefTypeInstance> entry : boundSupers.entrySet())
/*  771:     */       {
/*  772: 717 */         JavaRefTypeInstance superC = (JavaRefTypeInstance)entry.getKey();
/*  773: 718 */         if (!superC.equals(getClassType()))
/*  774:     */         {
/*  775: 719 */           ClassFile superClsFile = null;
/*  776:     */           try
/*  777:     */           {
/*  778: 721 */             superClsFile = superC.getClassFile();
/*  779:     */           }
/*  780:     */           catch (CannotLoadClassException e) {}
/*  781: 724 */           if ((superClsFile != null) && 
/*  782: 725 */             (superClsFile != this))
/*  783:     */           {
/*  784: 727 */             JavaGenericRefTypeInstance boundSuperC = (JavaGenericRefTypeInstance)entry.getValue();
/*  785: 728 */             GenericTypeBinder binder = null;
/*  786: 729 */             if (boundSuperC != null) {
/*  787: 730 */               binder = superClsFile.getGenericTypeBinder(boundSuperC);
/*  788:     */             }
/*  789: 733 */             bindTesters.add(Triplet.make(superC, superClsFile, binder));
/*  790:     */           }
/*  791:     */         }
/*  792:     */       }
/*  793: 737 */       for (Method method : this.methods) {
/*  794: 738 */         if ((!method.isConstructor()) && 
/*  795: 739 */           (!method.testAccessFlag(AccessFlagMethod.ACC_STATIC)))
/*  796:     */         {
/*  797: 740 */           MethodPrototype prototype = method.getMethodPrototype();
/*  798: 741 */           Method baseMethod = null;
/*  799: 742 */           for (Triplet<JavaRefTypeInstance, ClassFile, GenericTypeBinder> bindTester : bindTesters)
/*  800:     */           {
/*  801: 743 */             JavaRefTypeInstance refType = (JavaRefTypeInstance)bindTester.getFirst();
/*  802: 744 */             ClassFile classFile = (ClassFile)bindTester.getSecond();
/*  803: 745 */             GenericTypeBinder genericTypeBinder = (GenericTypeBinder)bindTester.getThird();
/*  804:     */             try
/*  805:     */             {
/*  806: 747 */               baseMethod = classFile.getAccessibleMethodByPrototype(prototype, genericTypeBinder, (JavaRefTypeInstance)getClassType().getDeGenerifiedType());
/*  807:     */             }
/*  808:     */             catch (NoSuchMethodException e) {}
/*  809: 750 */             if (baseMethod != null) {
/*  810:     */               break;
/*  811:     */             }
/*  812:     */           }
/*  813: 752 */           if (baseMethod != null) {
/*  814: 752 */             method.markOverride();
/*  815:     */           }
/*  816:     */         }
/*  817:     */       }
/*  818:     */     }
/*  819:     */     catch (RuntimeException e)
/*  820:     */     {
/*  821:     */       List<Triplet<JavaRefTypeInstance, ClassFile, GenericTypeBinder>> bindTesters;
/*  822: 755 */       addComment("Failed to analyse overrides", e);
/*  823:     */     }
/*  824:     */   }
/*  825:     */   
/*  826:     */   public void analyseMid(DCCommonState state)
/*  827:     */   {
/*  828: 761 */     Options options = state.getOptions();
/*  829: 762 */     if (this.begunAnalysis) {
/*  830: 763 */       return;
/*  831:     */     }
/*  832: 765 */     this.begunAnalysis = true;
/*  833: 770 */     if (((Boolean)options.getOption(OptionsImpl.DECOMPILE_INNER_CLASSES)).booleanValue()) {
/*  834: 771 */       analyseInnerClassesPass1(state);
/*  835:     */     }
/*  836: 774 */     for (Method method : this.methods) {
/*  837: 775 */       method.analyse();
/*  838:     */     }
/*  839:     */     try
/*  840:     */     {
/*  841: 779 */       if (((Boolean)options.getOption(OptionsImpl.OVERRIDES, this.classFileVersion)).booleanValue()) {
/*  842: 780 */         analyseOverrides();
/*  843:     */       }
/*  844: 783 */       CodeAnalyserWholeClass.wholeClassAnalysisPass1(this, state);
/*  845:     */     }
/*  846:     */     catch (RuntimeException e)
/*  847:     */     {
/*  848: 785 */       addComment(DecompilerComment.WHOLE_CLASS_EXCEPTION);
/*  849:     */     }
/*  850:     */   }
/*  851:     */   
/*  852:     */   public JavaTypeInstance getClassType()
/*  853:     */   {
/*  854: 791 */     return this.thisClass.getTypeInstance();
/*  855:     */   }
/*  856:     */   
/*  857:     */   public JavaRefTypeInstance getRefClasstype()
/*  858:     */   {
/*  859: 795 */     return (JavaRefTypeInstance)this.thisClass.getTypeInstance();
/*  860:     */   }
/*  861:     */   
/*  862:     */   public JavaTypeInstance getBaseClassType()
/*  863:     */   {
/*  864: 799 */     return this.classSignature.getSuperClass();
/*  865:     */   }
/*  866:     */   
/*  867:     */   public ClassSignature getClassSignature()
/*  868:     */   {
/*  869: 803 */     return this.classSignature;
/*  870:     */   }
/*  871:     */   
/*  872:     */   public Set<AccessFlag> getAccessFlags()
/*  873:     */   {
/*  874: 807 */     return this.accessFlags;
/*  875:     */   }
/*  876:     */   
/*  877:     */   private void sanitiseAccessPermissions()
/*  878:     */   {
/*  879: 811 */     if (this.accessFlags.contains(AccessFlag.ACC_PRIVATE))
/*  880:     */     {
/*  881: 812 */       this.accessFlags.remove(AccessFlag.ACC_PROTECTED);
/*  882: 813 */       this.accessFlags.remove(AccessFlag.ACC_PUBLIC);
/*  883: 814 */       return;
/*  884:     */     }
/*  885: 816 */     if (this.accessFlags.contains(AccessFlag.ACC_PROTECTED))
/*  886:     */     {
/*  887: 817 */       this.accessFlags.remove(AccessFlag.ACC_PUBLIC);
/*  888: 818 */       return;
/*  889:     */     }
/*  890:     */   }
/*  891:     */   
/*  892:     */   private ClassSignature getSignature(ConstantPool cp, ConstantPoolEntryClass rawSuperClass, List<ConstantPoolEntryClass> rawInterfaces)
/*  893:     */   {
/*  894: 825 */     AttributeSignature signatureAttribute = (AttributeSignature)getAttributeByName("Signature");
/*  895: 828 */     if (signatureAttribute == null)
/*  896:     */     {
/*  897: 829 */       List<JavaTypeInstance> interfaces = ListFactory.newList();
/*  898: 830 */       for (ConstantPoolEntryClass rawInterface : rawInterfaces) {
/*  899: 831 */         interfaces.add(rawInterface.getTypeInstance());
/*  900:     */       }
/*  901: 834 */       return new ClassSignature(null, rawSuperClass == null ? null : rawSuperClass.getTypeInstance(), interfaces);
/*  902:     */     }
/*  903: 839 */     return ConstantPoolUtils.parseClassSignature(signatureAttribute.getSignature(), cp);
/*  904:     */   }
/*  905:     */   
/*  906:     */   public void dumpNamedInnerClasses(Dumper d)
/*  907:     */   {
/*  908: 844 */     if ((this.innerClassesByTypeInfo == null) || (this.innerClassesByTypeInfo.isEmpty())) {
/*  909: 844 */       return;
/*  910:     */     }
/*  911: 846 */     d.newln();
/*  912: 848 */     for (Pair<InnerClassAttributeInfo, ClassFile> innerClassEntry : this.innerClassesByTypeInfo.values())
/*  913:     */     {
/*  914: 850 */       InnerClassInfo innerClassInfo = ((InnerClassAttributeInfo)innerClassEntry.getFirst()).getInnerClassInfo().getInnerClassHereInfo();
/*  915: 851 */       if ((!innerClassInfo.isSyntheticFriendClass()) && 
/*  916:     */       
/*  917:     */ 
/*  918: 854 */         (!innerClassInfo.isMethodScopedClass()))
/*  919:     */       {
/*  920: 857 */         ClassFile classFile = (ClassFile)innerClassEntry.getSecond();
/*  921: 858 */         if (!classFile.hiddenInnerClass)
/*  922:     */         {
/*  923: 861 */           TypeUsageInformation typeUsageInformation = d.getTypeUsageInformation();
/*  924: 862 */           TypeUsageInformation innerclassTypeUsageInformation = new InnerClassTypeUsageInformation(typeUsageInformation, (JavaRefTypeInstance)classFile.getClassType());
/*  925: 863 */           Dumper d2 = new TypeOverridingDumper(d, innerclassTypeUsageInformation);
/*  926:     */           
/*  927: 865 */           classFile.dumpHelper.dump(classFile, ClassFileDumper.InnerClassDumpType.INNER_CLASS, d2);
/*  928: 866 */           d.newln();
/*  929:     */         }
/*  930:     */       }
/*  931:     */     }
/*  932:     */   }
/*  933:     */   
/*  934:     */   public Dumper dump(Dumper d)
/*  935:     */   {
/*  936: 872 */     return this.dumpHelper.dump(this, ClassFileDumper.InnerClassDumpType.NOT, d);
/*  937:     */   }
/*  938:     */   
/*  939:     */   public Dumper dumpAsInlineClass(Dumper d)
/*  940:     */   {
/*  941: 876 */     return this.dumpHelper.dump(this, ClassFileDumper.InnerClassDumpType.INLINE_CLASS, d);
/*  942:     */   }
/*  943:     */   
/*  944:     */   public String getFilePath()
/*  945:     */   {
/*  946: 880 */     return this.thisClass.getFilePath();
/*  947:     */   }
/*  948:     */   
/*  949:     */   public String toString()
/*  950:     */   {
/*  951: 885 */     return this.thisClass.getTextPath();
/*  952:     */   }
/*  953:     */   
/*  954:     */   public BindingSuperContainer getBindingSupers()
/*  955:     */   {
/*  956: 894 */     if (this.boundSuperClasses == null) {
/*  957: 895 */       this.boundSuperClasses = generateBoundSuperClasses();
/*  958:     */     }
/*  959: 897 */     return this.boundSuperClasses;
/*  960:     */   }
/*  961:     */   
/*  962:     */   private BindingSuperContainer generateBoundSuperClasses()
/*  963:     */   {
/*  964: 901 */     BoundSuperCollector boundSuperCollector = new BoundSuperCollector(this);
/*  965:     */     
/*  966: 903 */     JavaTypeInstance thisType = getClassSignature().getThisGeneralTypeClass(getClassType(), getConstantPool());
/*  967:     */     GenericTypeBinder genericTypeBinder;
/*  968: 906 */     if ((thisType instanceof JavaGenericRefTypeInstance))
/*  969:     */     {
/*  970: 907 */       JavaGenericRefTypeInstance genericThisType = (JavaGenericRefTypeInstance)thisType;
/*  971: 908 */       GenericTypeBinder genericTypeBinder = GenericTypeBinder.buildIdentityBindings(genericThisType);
/*  972: 909 */       boundSuperCollector.collect(genericThisType, BindingSuperContainer.Route.IDENTITY);
/*  973:     */     }
/*  974:     */     else
/*  975:     */     {
/*  976: 911 */       genericTypeBinder = null;
/*  977: 912 */       boundSuperCollector.collect((JavaRefTypeInstance)thisType, BindingSuperContainer.Route.IDENTITY);
/*  978:     */     }
/*  979: 915 */     getBoundSuperClasses2(this.classSignature.getSuperClass(), genericTypeBinder, boundSuperCollector, BindingSuperContainer.Route.EXTENSION, SetFactory.newSet());
/*  980: 916 */     for (JavaTypeInstance interfaceBase : this.classSignature.getInterfaces()) {
/*  981: 917 */       getBoundSuperClasses2(interfaceBase, genericTypeBinder, boundSuperCollector, BindingSuperContainer.Route.INTERFACE, SetFactory.newSet());
/*  982:     */     }
/*  983: 920 */     return boundSuperCollector.getBoundSupers();
/*  984:     */   }
/*  985:     */   
/*  986:     */   public void getBoundSuperClasses(JavaTypeInstance boundGeneric, BoundSuperCollector boundSuperCollector, BindingSuperContainer.Route route, Set<JavaTypeInstance> seen)
/*  987:     */   {
/*  988: 927 */     JavaTypeInstance thisType = getClassSignature().getThisGeneralTypeClass(getClassType(), getConstantPool());
/*  989:     */     GenericTypeBinder genericTypeBinder;
/*  990:     */     GenericTypeBinder genericTypeBinder;
/*  991: 945 */     if (!(thisType instanceof JavaGenericRefTypeInstance))
/*  992:     */     {
/*  993: 946 */       genericTypeBinder = null;
/*  994:     */     }
/*  995:     */     else
/*  996:     */     {
/*  997: 948 */       JavaGenericRefTypeInstance genericThisType = (JavaGenericRefTypeInstance)thisType;
/*  998:     */       GenericTypeBinder genericTypeBinder;
/*  999: 950 */       if ((boundGeneric instanceof JavaGenericRefTypeInstance)) {
/* 1000: 951 */         genericTypeBinder = GenericTypeBinder.extractBindings(genericThisType, (JavaGenericRefTypeInstance)boundGeneric);
/* 1001:     */       } else {
/* 1002: 953 */         genericTypeBinder = null;
/* 1003:     */       }
/* 1004:     */     }
/* 1005: 959 */     getBoundSuperClasses2(this.classSignature.getSuperClass(), genericTypeBinder, boundSuperCollector, route, SetFactory.newSet(seen));
/* 1006: 960 */     for (JavaTypeInstance interfaceBase : this.classSignature.getInterfaces()) {
/* 1007: 961 */       getBoundSuperClasses2(interfaceBase, genericTypeBinder, boundSuperCollector, BindingSuperContainer.Route.INTERFACE, SetFactory.newSet(seen));
/* 1008:     */     }
/* 1009:     */   }
/* 1010:     */   
/* 1011:     */   public GenericTypeBinder getGenericTypeBinder(JavaGenericRefTypeInstance boundGeneric)
/* 1012:     */   {
/* 1013: 966 */     JavaTypeInstance thisType = getClassSignature().getThisGeneralTypeClass(getClassType(), getConstantPool());
/* 1014: 967 */     if (!(thisType instanceof JavaGenericRefTypeInstance)) {
/* 1015: 968 */       return null;
/* 1016:     */     }
/* 1017: 970 */     JavaGenericRefTypeInstance genericThisType = (JavaGenericRefTypeInstance)thisType;
/* 1018: 971 */     return GenericTypeBinder.extractBindings(genericThisType, boundGeneric);
/* 1019:     */   }
/* 1020:     */   
/* 1021:     */   private void getBoundSuperClasses2(JavaTypeInstance base, GenericTypeBinder genericTypeBinder, BoundSuperCollector boundSuperCollector, BindingSuperContainer.Route route, Set<JavaTypeInstance> seen)
/* 1022:     */   {
/* 1023: 977 */     if (seen.contains(base)) {
/* 1024: 977 */       return;
/* 1025:     */     }
/* 1026: 978 */     seen.add(base);
/* 1027: 980 */     if ((base instanceof JavaRefTypeInstance))
/* 1028:     */     {
/* 1029: 982 */       boundSuperCollector.collect((JavaRefTypeInstance)base, route);
/* 1030: 983 */       ClassFile classFile = ((JavaRefTypeInstance)base).getClassFile();
/* 1031: 984 */       if (classFile != null) {
/* 1032: 984 */         classFile.getBoundSuperClasses(base, boundSuperCollector, route, seen);
/* 1033:     */       }
/* 1034: 985 */       return;
/* 1035:     */     }
/* 1036: 989 */     if (!(base instanceof JavaGenericRefTypeInstance)) {
/* 1037: 990 */       throw new IllegalStateException("Base class is not generic");
/* 1038:     */     }
/* 1039: 992 */     JavaGenericRefTypeInstance genericBase = (JavaGenericRefTypeInstance)base;
/* 1040:     */     
/* 1041:     */ 
/* 1042:     */ 
/* 1043: 996 */     JavaGenericRefTypeInstance boundBase = genericBase.getBoundInstance(genericTypeBinder);
/* 1044:     */     
/* 1045: 998 */     boundSuperCollector.collect(boundBase, route);
/* 1046:     */     
/* 1047:     */ 
/* 1048:     */ 
/* 1049:1002 */     ClassFile classFile = null;
/* 1050:     */     try
/* 1051:     */     {
/* 1052:1004 */       classFile = genericBase.getDeGenerifiedType().getClassFile();
/* 1053:     */     }
/* 1054:     */     catch (CannotLoadClassException e) {}
/* 1055:1007 */     if (classFile == null) {
/* 1056:1008 */       return;
/* 1057:     */     }
/* 1058:1010 */     classFile.getBoundSuperClasses(boundBase, boundSuperCollector, route, seen);
/* 1059:     */   }
/* 1060:     */   
/* 1061:1013 */   private List<ConstructorInvokationAnonymousInner> anonymousUsages = ListFactory.newList();
/* 1062:     */   
/* 1063:     */   public void noteAnonymousUse(ConstructorInvokationAnonymousInner anoynmousInner)
/* 1064:     */   {
/* 1065:1016 */     this.anonymousUsages.add(anoynmousInner);
/* 1066:     */   }
/* 1067:     */   
/* 1068:     */   public List<ConstructorInvokationAnonymousInner> getAnonymousUsages()
/* 1069:     */   {
/* 1070:1020 */     return this.anonymousUsages;
/* 1071:     */   }
/* 1072:     */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.ClassFile
 * JD-Core Version:    0.7.0.1
 */