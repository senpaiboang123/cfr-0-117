/*  1:   */ package org.benf.cfr.reader.entities.constantpool;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/*  4:   */ import org.benf.cfr.reader.entities.AbstractConstantPoolEntry;
/*  5:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  6:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  7:   */ 
/*  8:   */ public class ConstantPoolEntryInteger
/*  9:   */   extends AbstractConstantPoolEntry
/* 10:   */   implements ConstantPoolEntryLiteral
/* 11:   */ {
/* 12:   */   private static final long OFFSET_OF_BYTES = 1L;
/* 13:   */   private final int value;
/* 14:   */   
/* 15:   */   public ConstantPoolEntryInteger(ConstantPool cp, ByteData data)
/* 16:   */   {
/* 17:14 */     super(cp);
/* 18:15 */     this.value = data.getS4At(1L);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public long getRawByteLength()
/* 22:   */   {
/* 23:20 */     return 5L;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void dump(Dumper d)
/* 27:   */   {
/* 28:25 */     d.print("CONSTANT_Integer value=" + this.value);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public int getValue()
/* 32:   */   {
/* 33:29 */     return this.value;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public StackType getStackType()
/* 37:   */   {
/* 38:34 */     return StackType.INT;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public String toString()
/* 42:   */   {
/* 43:39 */     return "CONSTANT_Integer value=" + this.value;
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryInteger
 * JD-Core Version:    0.7.0.1
 */