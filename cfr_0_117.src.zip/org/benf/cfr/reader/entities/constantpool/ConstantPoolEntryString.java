/*  1:   */ package org.benf.cfr.reader.entities.constantpool;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.QuotingUtils;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/*  5:   */ import org.benf.cfr.reader.entities.AbstractConstantPoolEntry;
/*  6:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  7:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  8:   */ 
/*  9:   */ public class ConstantPoolEntryString
/* 10:   */   extends AbstractConstantPoolEntry
/* 11:   */   implements ConstantPoolEntryLiteral
/* 12:   */ {
/* 13:   */   private static final long OFFSET_OF_STRING_INDEX = 1L;
/* 14:   */   private final long stringIndex;
/* 15:   */   private transient String string;
/* 16:   */   
/* 17:   */   public ConstantPoolEntryString(ConstantPool cp, ByteData data)
/* 18:   */   {
/* 19:18 */     super(cp);
/* 20:19 */     this.stringIndex = data.getS2At(1L);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public long getRawByteLength()
/* 24:   */   {
/* 25:24 */     return 3L;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void dump(Dumper d)
/* 29:   */   {
/* 30:29 */     d.print("String " + getValue());
/* 31:   */   }
/* 32:   */   
/* 33:   */   public String getValue()
/* 34:   */   {
/* 35:33 */     if (this.string == null) {
/* 36:34 */       this.string = QuotingUtils.enquoteString(getCp().getUTF8Entry((int)this.stringIndex).getValue());
/* 37:   */     }
/* 38:36 */     return this.string;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public StackType getStackType()
/* 42:   */   {
/* 43:41 */     return StackType.REF;
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryString
 * JD-Core Version:    0.7.0.1
 */