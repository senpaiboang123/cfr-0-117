/*   1:    */ package org.benf.cfr.reader.entities.constantpool;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.logging.Logger;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDelta;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDeltaImpl;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.types.ClassSignature;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.types.FormalTypeParameter;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaArrayTypeInstance;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericPlaceholderTypeInstance;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericRefTypeInstance;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaWildcardTypeInstance;
/*  16:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  17:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  18:    */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/*  19:    */ import org.benf.cfr.reader.bytecode.analysis.types.StackTypes;
/*  20:    */ import org.benf.cfr.reader.bytecode.analysis.types.WildcardType;
/*  21:    */ import org.benf.cfr.reader.bytecode.analysis.variables.VariableNamer;
/*  22:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  23:    */ import org.benf.cfr.reader.entities.Method.MethodConstructor;
/*  24:    */ import org.benf.cfr.reader.state.ClassCache;
/*  25:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  26:    */ import org.benf.cfr.reader.util.ListFactory;
/*  27:    */ import org.benf.cfr.reader.util.output.LoggerFactory;
/*  28:    */ 
/*  29:    */ public class ConstantPoolUtils
/*  30:    */ {
/*  31: 20 */   private static final Logger logger = LoggerFactory.create(ConstantPoolUtils.class);
/*  32:    */   
/*  33:    */   private static JavaTypeInstance parseRefType(String tok, ConstantPool cp, boolean isTemplate)
/*  34:    */   {
/*  35: 23 */     int idxGen = tok.indexOf('<');
/*  36: 24 */     int idxStart = 0;
/*  37: 26 */     if (idxGen != -1)
/*  38:    */     {
/*  39: 27 */       List<JavaTypeInstance> genericTypes = null;
/*  40: 28 */       String already = "";
/*  41: 29 */       while (idxGen != -1)
/*  42:    */       {
/*  43: 30 */         String pre = tok.substring(idxStart, idxGen);
/*  44: 31 */         already = already + pre;
/*  45: 32 */         String gen = tok.substring(idxGen + 1, tok.length() - 1);
/*  46: 33 */         Pair<List<JavaTypeInstance>, Integer> genericTypePair = parseTypeList(gen, cp);
/*  47: 34 */         genericTypes = (List)genericTypePair.getFirst();
/*  48: 35 */         idxStart = idxGen + ((Integer)genericTypePair.getSecond()).intValue() + 1;
/*  49: 36 */         if (idxStart >= gen.length()) {
/*  50:    */           break;
/*  51:    */         }
/*  52: 37 */         if (tok.charAt(idxStart) != '>') {
/*  53: 38 */           throw new IllegalStateException();
/*  54:    */         }
/*  55: 40 */         idxStart++;
/*  56: 41 */         idxGen = tok.indexOf('<', idxStart);
/*  57: 42 */         if (idxGen == -1)
/*  58:    */         {
/*  59: 44 */           already = already + tok.substring(idxStart, tok.length());
/*  60: 45 */           return cp.getClassCache().getRefClassFor(already);
/*  61:    */         }
/*  62:    */       }
/*  63: 55 */       JavaRefTypeInstance clazzType = cp.getClassCache().getRefClassFor(already);
/*  64: 56 */       return new JavaGenericRefTypeInstance(clazzType, genericTypes);
/*  65:    */     }
/*  66: 57 */     if (isTemplate) {
/*  67: 58 */       return new JavaGenericPlaceholderTypeInstance(tok, cp);
/*  68:    */     }
/*  69: 60 */     return cp.getClassCache().getRefClassFor(tok);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public static JavaTypeInstance decodeTypeTok(String tok, ConstantPool cp)
/*  73:    */   {
/*  74: 65 */     int idx = 0;
/*  75: 66 */     int numArrayDims = 0;
/*  76: 67 */     char c = tok.charAt(idx);
/*  77: 68 */     WildcardType wildcardType = WildcardType.NONE;
/*  78: 69 */     if ((c == '-') || (c == '+'))
/*  79:    */     {
/*  80: 70 */       wildcardType = c == '+' ? WildcardType.EXTENDS : WildcardType.SUPER;
/*  81: 71 */       c = tok.charAt(++idx);
/*  82:    */     }
/*  83: 73 */     while (c == '[')
/*  84:    */     {
/*  85: 74 */       numArrayDims++;
/*  86: 75 */       c = tok.charAt(++idx);
/*  87:    */     }
/*  88: 77 */     JavaTypeInstance javaTypeInstance = null;
/*  89: 78 */     switch (c)
/*  90:    */     {
/*  91:    */     case '*': 
/*  92: 80 */       javaTypeInstance = new JavaGenericPlaceholderTypeInstance("?", cp);
/*  93: 81 */       break;
/*  94:    */     case 'L': 
/*  95: 83 */       javaTypeInstance = parseRefType(tok.substring(idx + 1, tok.length() - 1), cp, false);
/*  96: 84 */       break;
/*  97:    */     case 'T': 
/*  98: 86 */       javaTypeInstance = parseRefType(tok.substring(idx + 1, tok.length() - 1), cp, true);
/*  99: 87 */       break;
/* 100:    */     case 'B': 
/* 101:    */     case 'C': 
/* 102:    */     case 'D': 
/* 103:    */     case 'F': 
/* 104:    */     case 'I': 
/* 105:    */     case 'J': 
/* 106:    */     case 'S': 
/* 107:    */     case 'Z': 
/* 108: 96 */       javaTypeInstance = decodeRawJavaType(c);
/* 109: 97 */       break;
/* 110:    */     default: 
/* 111: 99 */       throw new ConfusedCFRException("Invalid type string " + tok);
/* 112:    */     }
/* 113:101 */     if (numArrayDims > 0) {
/* 114:101 */       javaTypeInstance = new JavaArrayTypeInstance(numArrayDims, javaTypeInstance);
/* 115:    */     }
/* 116:102 */     if (wildcardType != WildcardType.NONE) {
/* 117:103 */       javaTypeInstance = new JavaWildcardTypeInstance(wildcardType, javaTypeInstance);
/* 118:    */     }
/* 119:105 */     return javaTypeInstance;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public static RawJavaType decodeRawJavaType(char c)
/* 123:    */   {
/* 124:    */     RawJavaType javaTypeInstance;
/* 125:110 */     switch (c)
/* 126:    */     {
/* 127:    */     case 'B': 
/* 128:112 */       javaTypeInstance = RawJavaType.BYTE;
/* 129:113 */       break;
/* 130:    */     case 'C': 
/* 131:115 */       javaTypeInstance = RawJavaType.CHAR;
/* 132:116 */       break;
/* 133:    */     case 'I': 
/* 134:118 */       javaTypeInstance = RawJavaType.INT;
/* 135:119 */       break;
/* 136:    */     case 'S': 
/* 137:121 */       javaTypeInstance = RawJavaType.SHORT;
/* 138:122 */       break;
/* 139:    */     case 'Z': 
/* 140:124 */       javaTypeInstance = RawJavaType.BOOLEAN;
/* 141:125 */       break;
/* 142:    */     case 'F': 
/* 143:127 */       javaTypeInstance = RawJavaType.FLOAT;
/* 144:128 */       break;
/* 145:    */     case 'D': 
/* 146:130 */       javaTypeInstance = RawJavaType.DOUBLE;
/* 147:131 */       break;
/* 148:    */     case 'J': 
/* 149:133 */       javaTypeInstance = RawJavaType.LONG;
/* 150:134 */       break;
/* 151:    */     case 'E': 
/* 152:    */     case 'G': 
/* 153:    */     case 'H': 
/* 154:    */     case 'K': 
/* 155:    */     case 'L': 
/* 156:    */     case 'M': 
/* 157:    */     case 'N': 
/* 158:    */     case 'O': 
/* 159:    */     case 'P': 
/* 160:    */     case 'Q': 
/* 161:    */     case 'R': 
/* 162:    */     case 'T': 
/* 163:    */     case 'U': 
/* 164:    */     case 'V': 
/* 165:    */     case 'W': 
/* 166:    */     case 'X': 
/* 167:    */     case 'Y': 
/* 168:    */     default: 
/* 169:136 */       throw new ConfusedCFRException("Illegal raw java type");
/* 170:    */     }
/* 171:138 */     return javaTypeInstance;
/* 172:    */   }
/* 173:    */   
/* 174:    */   private static String getNextTypeTok(String proto, int curridx)
/* 175:    */   {
/* 176:142 */     int startidx = curridx;
/* 177:143 */     char c = proto.charAt(curridx);
/* 178:145 */     if ((c == '-') || (c == '+')) {
/* 179:146 */       c = proto.charAt(++curridx);
/* 180:    */     }
/* 181:149 */     while (c == '[') {
/* 182:150 */       c = proto.charAt(++curridx);
/* 183:    */     }
/* 184:153 */     switch (c)
/* 185:    */     {
/* 186:    */     case '*': 
/* 187:155 */       curridx++;
/* 188:156 */       break;
/* 189:    */     case 'L': 
/* 190:    */     case 'T': 
/* 191:159 */       int openBra = 0;
/* 192:    */       do
/* 193:    */       {
/* 194:161 */         c = proto.charAt(++curridx);
/* 195:162 */         switch (c)
/* 196:    */         {
/* 197:    */         case '<': 
/* 198:164 */           openBra++;
/* 199:165 */           break;
/* 200:    */         case '>': 
/* 201:167 */           openBra--;
/* 202:    */         }
/* 203:170 */       } while ((openBra > 0) || (c != ';'));
/* 204:171 */       curridx++;
/* 205:172 */       break;
/* 206:    */     case 'B': 
/* 207:    */     case 'C': 
/* 208:    */     case 'D': 
/* 209:    */     case 'F': 
/* 210:    */     case 'I': 
/* 211:    */     case 'J': 
/* 212:    */     case 'S': 
/* 213:    */     case 'Z': 
/* 214:182 */       curridx++;
/* 215:183 */       break;
/* 216:    */     default: 
/* 217:185 */       throw new ConfusedCFRException("Can't parse proto : " + proto + " starting " + proto.substring(startidx));
/* 218:    */     }
/* 219:187 */     return proto.substring(startidx, curridx);
/* 220:    */   }
/* 221:    */   
/* 222:    */   private static String getNextFormalTypeTok(String proto, int curridx)
/* 223:    */   {
/* 224:191 */     int startidx = curridx;
/* 225:193 */     while (proto.charAt(curridx) != ':') {
/* 226:194 */       curridx++;
/* 227:    */     }
/* 228:196 */     curridx++;
/* 229:197 */     if (proto.charAt(curridx) != ':')
/* 230:    */     {
/* 231:199 */       String classBound = getNextTypeTok(proto, curridx);
/* 232:200 */       curridx += classBound.length();
/* 233:    */     }
/* 234:202 */     if (proto.charAt(curridx) == ':')
/* 235:    */     {
/* 236:204 */       curridx++;
/* 237:205 */       String interfaceBound = getNextTypeTok(proto, curridx);
/* 238:206 */       curridx += interfaceBound.length();
/* 239:    */     }
/* 240:208 */     return proto.substring(startidx, curridx);
/* 241:    */   }
/* 242:    */   
/* 243:    */   private static FormalTypeParameter decodeFormalTypeTok(String tok, ConstantPool cp, int idx)
/* 244:    */   {
/* 245:213 */     while (tok.charAt(idx) != ':') {
/* 246:214 */       idx++;
/* 247:    */     }
/* 248:216 */     String name = tok.substring(0, idx);
/* 249:217 */     idx++;
/* 250:218 */     JavaTypeInstance classBound = null;
/* 251:219 */     if (tok.charAt(idx) != ':')
/* 252:    */     {
/* 253:221 */       String classBoundTok = getNextTypeTok(tok, idx);
/* 254:222 */       classBound = decodeTypeTok(classBoundTok, cp);
/* 255:223 */       idx += classBoundTok.length();
/* 256:    */     }
/* 257:225 */     JavaTypeInstance interfaceBound = null;
/* 258:226 */     if ((idx < tok.length()) && 
/* 259:227 */       (tok.charAt(idx) == ':'))
/* 260:    */     {
/* 261:229 */       idx++;
/* 262:230 */       String interfaceBoundTok = getNextTypeTok(tok, idx);
/* 263:231 */       interfaceBound = decodeTypeTok(interfaceBoundTok, cp);
/* 264:232 */       idx += interfaceBoundTok.length();
/* 265:    */     }
/* 266:235 */     return new FormalTypeParameter(name, classBound, interfaceBound);
/* 267:    */   }
/* 268:    */   
/* 269:    */   public static ClassSignature parseClassSignature(ConstantPoolEntryUTF8 signature, ConstantPool cp)
/* 270:    */   {
/* 271:239 */     String sig = signature.getValue();
/* 272:240 */     int curridx = 0;
/* 273:    */     
/* 274:    */ 
/* 275:    */ 
/* 276:    */ 
/* 277:245 */     List<FormalTypeParameter> formalTypeParameters = null;
/* 278:246 */     if (sig.charAt(curridx) == '<')
/* 279:    */     {
/* 280:247 */       formalTypeParameters = ListFactory.newList();
/* 281:248 */       curridx++;
/* 282:249 */       while (sig.charAt(curridx) != '>')
/* 283:    */       {
/* 284:250 */         String formalTypeTok = getNextFormalTypeTok(sig, curridx);
/* 285:251 */         FormalTypeParameter formalTypeParameter = decodeFormalTypeTok(formalTypeTok, cp, 0);
/* 286:253 */         if (!formalTypeParameter.getName().equals("")) {
/* 287:254 */           formalTypeParameters.add(formalTypeParameter);
/* 288:    */         }
/* 289:256 */         curridx += formalTypeTok.length();
/* 290:    */       }
/* 291:258 */       curridx++;
/* 292:    */     }
/* 293:263 */     String superClassSignatureTok = getNextTypeTok(sig, curridx);
/* 294:264 */     curridx += superClassSignatureTok.length();
/* 295:265 */     JavaTypeInstance superClassSignature = decodeTypeTok(superClassSignatureTok, cp);
/* 296:    */     
/* 297:267 */     List<JavaTypeInstance> interfaceClassSignatures = ListFactory.newList();
/* 298:268 */     while (curridx < sig.length())
/* 299:    */     {
/* 300:269 */       String interfaceSignatureTok = getNextTypeTok(sig, curridx);
/* 301:270 */       curridx += interfaceSignatureTok.length();
/* 302:271 */       interfaceClassSignatures.add(decodeTypeTok(interfaceSignatureTok, cp));
/* 303:    */     }
/* 304:274 */     return new ClassSignature(formalTypeParameters, superClassSignature, interfaceClassSignatures);
/* 305:    */   }
/* 306:    */   
/* 307:    */   public static MethodPrototype parseJavaMethodPrototype(ClassFile classFile, JavaTypeInstance classType, String name, boolean instanceMethod, Method.MethodConstructor constructorFlag, ConstantPoolEntryUTF8 prototype, ConstantPool cp, boolean varargs, boolean synthetic, VariableNamer variableNamer)
/* 308:    */   {
/* 309:278 */     String proto = prototype.getValue();
/* 310:279 */     int curridx = 0;
/* 311:    */     
/* 312:    */ 
/* 313:    */ 
/* 314:283 */     List<FormalTypeParameter> formalTypeParameters = null;
/* 315:284 */     if (proto.charAt(curridx) == '<')
/* 316:    */     {
/* 317:285 */       formalTypeParameters = ListFactory.newList();
/* 318:286 */       curridx++;
/* 319:287 */       while (proto.charAt(curridx) != '>')
/* 320:    */       {
/* 321:288 */         String formalTypeTok = getNextFormalTypeTok(proto, curridx);
/* 322:289 */         formalTypeParameters.add(decodeFormalTypeTok(formalTypeTok, cp, 0));
/* 323:290 */         curridx += formalTypeTok.length();
/* 324:    */       }
/* 325:292 */       curridx++;
/* 326:    */     }
/* 327:294 */     if (proto.charAt(curridx) != '(') {
/* 328:294 */       throw new ConfusedCFRException("Prototype " + proto + " is invalid");
/* 329:    */     }
/* 330:295 */     curridx++;
/* 331:296 */     List<JavaTypeInstance> args = ListFactory.newList();
/* 332:298 */     while (proto.charAt(curridx) != ')')
/* 333:    */     {
/* 334:299 */       String typeTok = getNextTypeTok(proto, curridx);
/* 335:300 */       args.add(decodeTypeTok(typeTok, cp));
/* 336:301 */       curridx += typeTok.length();
/* 337:    */     }
/* 338:303 */     curridx++;
/* 339:304 */     JavaTypeInstance resultType = RawJavaType.VOID;
/* 340:305 */     switch (proto.charAt(curridx))
/* 341:    */     {
/* 342:    */     case 'V': 
/* 343:    */       break;
/* 344:    */     default: 
/* 345:309 */       resultType = decodeTypeTok(getNextTypeTok(proto, curridx), cp);
/* 346:    */     }
/* 347:312 */     MethodPrototype res = new MethodPrototype(classFile, classType, name, instanceMethod, constructorFlag, formalTypeParameters, args, resultType, varargs, variableNamer, synthetic);
/* 348:    */     
/* 349:314 */     return res;
/* 350:    */   }
/* 351:    */   
/* 352:    */   public static Pair<List<JavaTypeInstance>, Integer> parseTypeList(String proto, ConstantPool cp)
/* 353:    */   {
/* 354:318 */     int curridx = 0;
/* 355:319 */     int len = proto.length();
/* 356:320 */     List<JavaTypeInstance> res = ListFactory.newList();
/* 357:321 */     while ((curridx < len) && (proto.charAt(curridx) != '>'))
/* 358:    */     {
/* 359:322 */       String typeTok = getNextTypeTok(proto, curridx);
/* 360:323 */       res.add(decodeTypeTok(typeTok, cp));
/* 361:324 */       curridx += typeTok.length();
/* 362:    */     }
/* 363:326 */     return Pair.make(res, Integer.valueOf(curridx));
/* 364:    */   }
/* 365:    */   
/* 366:    */   public static StackDelta parseMethodPrototype(boolean member, ConstantPoolEntryUTF8 prototype, ConstantPool cp)
/* 367:    */   {
/* 368:333 */     String proto = prototype.getValue();
/* 369:334 */     int curridx = 1;
/* 370:335 */     if (!proto.startsWith("(")) {
/* 371:335 */       throw new ConfusedCFRException("Prototype " + proto + " is invalid");
/* 372:    */     }
/* 373:336 */     StackTypes argumentTypes = new StackTypes(new StackType[0]);
/* 374:337 */     if (member) {
/* 375:338 */       argumentTypes.add(StackType.REF);
/* 376:    */     }
/* 377:340 */     while (proto.charAt(curridx) != ')')
/* 378:    */     {
/* 379:341 */       String typeTok = getNextTypeTok(proto, curridx);
/* 380:342 */       argumentTypes.add(decodeTypeTok(typeTok, cp).getStackType());
/* 381:343 */       curridx += typeTok.length();
/* 382:    */     }
/* 383:345 */     curridx++;
/* 384:346 */     StackTypes resultType = StackTypes.EMPTY;
/* 385:347 */     switch (proto.charAt(curridx))
/* 386:    */     {
/* 387:    */     case 'V': 
/* 388:    */       break;
/* 389:    */     default: 
/* 390:351 */       resultType = decodeTypeTok(getNextTypeTok(proto, curridx), cp).getStackType().asList();
/* 391:    */     }
/* 392:354 */     StackDelta res = new StackDeltaImpl(argumentTypes, resultType);
/* 393:    */     
/* 394:356 */     return res;
/* 395:    */   }
/* 396:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.constantpool.ConstantPoolUtils
 * JD-Core Version:    0.7.0.1
 */