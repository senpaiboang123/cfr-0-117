/*  1:   */ package org.benf.cfr.reader.entities.constantpool;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.entities.AbstractConstantPoolEntry;
/*  4:   */ import org.benf.cfr.reader.entities.bootstrap.MethodHandleBehaviour;
/*  5:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  6:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  7:   */ 
/*  8:   */ public class ConstantPoolEntryMethodHandle
/*  9:   */   extends AbstractConstantPoolEntry
/* 10:   */ {
/* 11:   */   private static final long OFFSET_OF_REFERENCE_KIND = 1L;
/* 12:   */   private static final long OFFSET_OF_REFERENCE_INDEX = 2L;
/* 13:   */   private final MethodHandleBehaviour referenceKind;
/* 14:   */   private final short referenceIndex;
/* 15:   */   
/* 16:   */   public ConstantPoolEntryMethodHandle(ConstantPool cp, ByteData data)
/* 17:   */   {
/* 18:16 */     super(cp);
/* 19:17 */     this.referenceKind = MethodHandleBehaviour.decode(data.getS1At(1L));
/* 20:18 */     this.referenceIndex = data.getS2At(2L);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public long getRawByteLength()
/* 24:   */   {
/* 25:23 */     return 4L;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void dump(Dumper d)
/* 29:   */   {
/* 30:28 */     d.print(toString());
/* 31:   */   }
/* 32:   */   
/* 33:   */   public MethodHandleBehaviour getReferenceKind()
/* 34:   */   {
/* 35:32 */     return this.referenceKind;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public ConstantPoolEntryMethodRef getMethodRef()
/* 39:   */   {
/* 40:36 */     return getCp().getMethodRefEntry(this.referenceIndex);
/* 41:   */   }
/* 42:   */   
/* 43:   */   public String toString()
/* 44:   */   {
/* 45:41 */     return "MethodHandle value=" + this.referenceKind + "," + this.referenceIndex;
/* 46:   */   }
/* 47:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodHandle
 * JD-Core Version:    0.7.0.1
 */