/*  1:   */ package org.benf.cfr.reader.entities.constantpool;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.types.ClassNameUtils;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*  6:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  7:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/*  8:   */ import org.benf.cfr.reader.entities.AbstractConstantPoolEntry;
/*  9:   */ import org.benf.cfr.reader.state.ClassCache;
/* 10:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/* 11:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 12:   */ 
/* 13:   */ public class ConstantPoolEntryClass
/* 14:   */   extends AbstractConstantPoolEntry
/* 15:   */   implements ConstantPoolEntryLiteral
/* 16:   */ {
/* 17:   */   private static final long OFFSET_OF_NAME_INDEX = 1L;
/* 18:   */   final short nameIndex;
/* 19:16 */   transient JavaTypeInstance javaTypeInstance = null;
/* 20:   */   
/* 21:   */   public ConstantPoolEntryClass(ConstantPool cp, ByteData data)
/* 22:   */   {
/* 23:19 */     super(cp);
/* 24:20 */     this.nameIndex = data.getS2At(1L);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public long getRawByteLength()
/* 28:   */   {
/* 29:25 */     return 3L;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public String toString()
/* 33:   */   {
/* 34:30 */     return "CONSTANT_Class " + this.nameIndex;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public String getTextPath()
/* 38:   */   {
/* 39:34 */     return ClassNameUtils.convertFromPath(getCp().getUTF8Entry(this.nameIndex).getValue()) + ".class";
/* 40:   */   }
/* 41:   */   
/* 42:   */   public String getFilePath()
/* 43:   */   {
/* 44:38 */     return getCp().getUTF8Entry(this.nameIndex).getValue() + ".class";
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void dump(Dumper d)
/* 48:   */   {
/* 49:43 */     d.print("Class " + getCp().getUTF8Entry(this.nameIndex).getValue());
/* 50:   */   }
/* 51:   */   
/* 52:   */   public String getPackageName()
/* 53:   */   {
/* 54:47 */     String full = ClassNameUtils.convertFromPath(getCp().getUTF8Entry(this.nameIndex).getValue());
/* 55:48 */     int idx = full.lastIndexOf('.');
/* 56:49 */     if (idx == -1) {
/* 57:49 */       return "";
/* 58:   */     }
/* 59:50 */     return full.substring(0, idx);
/* 60:   */   }
/* 61:   */   
/* 62:   */   public JavaTypeInstance convertFromString(String rawType)
/* 63:   */   {
/* 64:54 */     if (rawType.startsWith("[")) {
/* 65:55 */       return ConstantPoolUtils.decodeTypeTok(rawType, getCp());
/* 66:   */     }
/* 67:57 */     return getCp().getClassCache().getRefClassFor(ClassNameUtils.convertFromPath(rawType));
/* 68:   */   }
/* 69:   */   
/* 70:   */   public JavaTypeInstance getTypeInstance()
/* 71:   */   {
/* 72:62 */     if (this.javaTypeInstance == null)
/* 73:   */     {
/* 74:63 */       String rawType = getCp().getUTF8Entry(this.nameIndex).getValue();
/* 75:64 */       this.javaTypeInstance = convertFromString(rawType);
/* 76:   */     }
/* 77:66 */     return this.javaTypeInstance;
/* 78:   */   }
/* 79:   */   
/* 80:   */   public JavaTypeInstance getTypeInstanceKnownOuter(ConstantPoolEntryClass outer)
/* 81:   */   {
/* 82:70 */     if (this.javaTypeInstance != null) {
/* 83:71 */       return this.javaTypeInstance;
/* 84:   */     }
/* 85:73 */     String thisInnerType = getCp().getUTF8Entry(this.nameIndex).getValue();
/* 86:74 */     String thisOuterType = getCp().getUTF8Entry(outer.nameIndex).getValue();
/* 87:75 */     Pair<JavaRefTypeInstance, JavaRefTypeInstance> pair = getCp().getClassCache().getRefClassForInnerOuterPair(thisInnerType, thisOuterType);
/* 88:76 */     this.javaTypeInstance = ((JavaTypeInstance)pair.getFirst());
/* 89:77 */     return this.javaTypeInstance;
/* 90:   */   }
/* 91:   */   
/* 92:   */   public JavaTypeInstance getTypeInstanceKnownInner(ConstantPoolEntryClass inner)
/* 93:   */   {
/* 94:81 */     if (this.javaTypeInstance != null) {
/* 95:82 */       return this.javaTypeInstance;
/* 96:   */     }
/* 97:84 */     String thisInnerType = getCp().getUTF8Entry(inner.nameIndex).getValue();
/* 98:85 */     String thisOuterType = getCp().getUTF8Entry(this.nameIndex).getValue();
/* 99:86 */     Pair<JavaRefTypeInstance, JavaRefTypeInstance> pair = getCp().getClassCache().getRefClassForInnerOuterPair(thisInnerType, thisOuterType);
/* :0:87 */     this.javaTypeInstance = ((JavaTypeInstance)pair.getSecond());
/* :1:88 */     return this.javaTypeInstance;
/* :2:   */   }
/* :3:   */   
/* :4:   */   public StackType getStackType()
/* :5:   */   {
/* :6:93 */     return StackType.REF;
/* :7:   */   }
/* :8:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryClass
 * JD-Core Version:    0.7.0.1
 */