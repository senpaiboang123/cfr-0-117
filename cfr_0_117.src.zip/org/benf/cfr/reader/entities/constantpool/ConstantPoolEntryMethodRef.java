/*   1:    */ package org.benf.cfr.reader.entities.constantpool;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.Map;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.types.BindingSuperContainer;
/*   6:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaRefTypeInstance;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.variables.VariableNamer;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.variables.VariableNamerDefault;
/*  11:    */ import org.benf.cfr.reader.entities.AbstractConstantPoolEntry;
/*  12:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  13:    */ import org.benf.cfr.reader.entities.Method;
/*  14:    */ import org.benf.cfr.reader.entities.Method.MethodConstructor;
/*  15:    */ import org.benf.cfr.reader.entities.classfilehelpers.OverloadMethodSet;
/*  16:    */ import org.benf.cfr.reader.state.DCCommonState;
/*  17:    */ import org.benf.cfr.reader.util.CannotLoadClassException;
/*  18:    */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  19:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  20:    */ 
/*  21:    */ public class ConstantPoolEntryMethodRef
/*  22:    */   extends AbstractConstantPoolEntry
/*  23:    */ {
/*  24:    */   private static final long OFFSET_OF_CLASS_INDEX = 1L;
/*  25:    */   private static final long OFFSET_OF_NAME_AND_TYPE_INDEX = 3L;
/*  26:    */   private final boolean interfaceMethod;
/*  27: 23 */   private static final VariableNamer fakeNamer = new VariableNamerDefault();
/*  28: 24 */   private MethodPrototype methodPrototype = null;
/*  29: 25 */   private OverloadMethodSet overloadMethodSet = null;
/*  30:    */   private final short classIndex;
/*  31:    */   private final short nameAndTypeIndex;
/*  32:    */   
/*  33:    */   public ConstantPoolEntryMethodRef(ConstantPool cp, ByteData data, boolean interfaceMethod)
/*  34:    */   {
/*  35: 31 */     super(cp);
/*  36: 32 */     this.classIndex = data.getS2At(1L);
/*  37: 33 */     this.nameAndTypeIndex = data.getS2At(3L);
/*  38: 34 */     this.interfaceMethod = interfaceMethod;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public long getRawByteLength()
/*  42:    */   {
/*  43: 39 */     return 5L;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public void dump(Dumper d)
/*  47:    */   {
/*  48: 44 */     ConstantPool cp = getCp();
/*  49: 45 */     d.print("Method " + cp.getNameAndTypeEntry(this.nameAndTypeIndex).getName().getValue() + ":" + cp.getNameAndTypeEntry(this.nameAndTypeIndex).getDescriptor().getValue());
/*  50:    */   }
/*  51:    */   
/*  52:    */   public ConstantPool getCp()
/*  53:    */   {
/*  54: 51 */     return super.getCp();
/*  55:    */   }
/*  56:    */   
/*  57:    */   public String toString()
/*  58:    */   {
/*  59: 56 */     return "Method classIndex " + this.classIndex + " nameAndTypeIndex " + this.nameAndTypeIndex;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public ConstantPoolEntryClass getClassEntry()
/*  63:    */   {
/*  64: 60 */     return getCp().getClassEntry(this.classIndex);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public ConstantPoolEntryNameAndType getNameAndTypeEntry()
/*  68:    */   {
/*  69: 64 */     return getCp().getNameAndTypeEntry(this.nameAndTypeIndex);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public MethodPrototype getMethodPrototype()
/*  73:    */   {
/*  74: 71 */     if (this.methodPrototype == null)
/*  75:    */     {
/*  76: 72 */       ConstantPool cp = getCp();
/*  77: 73 */       JavaTypeInstance classType = cp.getClassEntry(this.classIndex).getTypeInstance();
/*  78:    */       
/*  79: 75 */       ConstantPoolEntryNameAndType nameAndType = cp.getNameAndTypeEntry(this.nameAndTypeIndex);
/*  80: 76 */       ConstantPoolEntryUTF8 descriptor = nameAndType.getDescriptor();
/*  81: 77 */       MethodPrototype basePrototype = ConstantPoolUtils.parseJavaMethodPrototype(null, classType, getName(), false, Method.MethodConstructor.NOT, descriptor, cp, false, false, fakeNamer);
/*  82:    */       try
/*  83:    */       {
/*  84: 82 */         loadType = classType.getArrayStrippedType().getDeGenerifiedType();
/*  85: 83 */         classFile = cp.getDCCommonState().getClassFile(loadType);
/*  86:    */         try
/*  87:    */         {
/*  88: 86 */           replacement = classFile.getMethodByPrototype(basePrototype).getMethodPrototype();
/*  89:    */         }
/*  90:    */         catch (NoSuchMethodException e)
/*  91:    */         {
/*  92: 88 */           if (!basePrototype.getName().equals("<init>")) {}
/*  93:    */         }
/*  94:    */       }
/*  95:    */       catch (CannotLoadClassException ignore)
/*  96:    */       {
/*  97:    */         JavaTypeInstance loadType;
/*  98:    */         ClassFile classFile;
/*  99:    */         MethodPrototype replacement;
/* 100:    */         BindingSuperContainer bindingSuperContainer;
/* 101:    */         Collection<JavaRefTypeInstance> supers;
/* 102:119 */         x = 1;
/* 103:    */       }
/* 104: 92 */       bindingSuperContainer = classFile.getBindingSupers();
/* 105: 93 */       if (bindingSuperContainer != null)
/* 106:    */       {
/* 107: 94 */         supers = bindingSuperContainer.getBoundSuperClasses().keySet();
/* 108: 95 */         for (JavaTypeInstance supertype : supers)
/* 109:    */         {
/* 110: 96 */           loadType = supertype.getDeGenerifiedType();
/* 111: 97 */           ClassFile superClassFile = cp.getDCCommonState().getClassFile(loadType);
/* 112:    */           try
/* 113:    */           {
/* 114: 99 */             MethodPrototype baseReplacement = superClassFile.getMethodByPrototype(basePrototype).getMethodPrototype();
/* 115:    */             
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:107 */             classFile = superClassFile;
/* 123:108 */             replacement = baseReplacement;
/* 124:    */           }
/* 125:    */           catch (NoSuchMethodException e2) {}
/* 126:    */         }
/* 127:    */         break label251;
/* 128:116 */         this.overloadMethodSet = classFile.getOverloadMethodSet(replacement);
/* 129:117 */         basePrototype = replacement;
/* 130:    */       }
/* 131:    */       int x;
/* 132:    */       label251:
/* 133:122 */       this.methodPrototype = basePrototype;
/* 134:    */     }
/* 135:124 */     return this.methodPrototype;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public OverloadMethodSet getOverloadMethodSet()
/* 139:    */   {
/* 140:129 */     return this.overloadMethodSet;
/* 141:    */   }
/* 142:    */   
/* 143:    */   public String getName()
/* 144:    */   {
/* 145:133 */     return getCp().getNameAndTypeEntry(this.nameAndTypeIndex).getName().getValue();
/* 146:    */   }
/* 147:    */   
/* 148:    */   public boolean isInitMethod()
/* 149:    */   {
/* 150:137 */     String name = getName();
/* 151:138 */     return "<init>".equals(name);
/* 152:    */   }
/* 153:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodRef
 * JD-Core Version:    0.7.0.1
 */