/*   1:    */ package org.benf.cfr.reader.entities.constantpool;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.logging.Logger;
/*   6:    */ import org.benf.cfr.reader.entities.ClassFile;
/*   7:    */ import org.benf.cfr.reader.state.ClassCache;
/*   8:    */ import org.benf.cfr.reader.state.DCCommonState;
/*   9:    */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  10:    */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  11:    */ import org.benf.cfr.reader.util.bytestream.OffsettingByteData;
/*  12:    */ import org.benf.cfr.reader.util.getopt.Options;
/*  13:    */ import org.benf.cfr.reader.util.output.LoggerFactory;
/*  14:    */ 
/*  15:    */ public class ConstantPool
/*  16:    */ {
/*  17: 17 */   private static final Logger logger = LoggerFactory.create(ConstantPool.class);
/*  18:    */   private final long length;
/*  19:    */   private final List<ConstantPoolEntry> entries;
/*  20:    */   private final Options options;
/*  21:    */   private final DCCommonState dcCommonState;
/*  22:    */   private final ClassCache classCache;
/*  23:    */   private final ClassFile classFile;
/*  24:    */   private String comparisonKey;
/*  25: 26 */   private boolean isLoaded = false;
/*  26: 27 */   private final int idx = sidx++;
/*  27: 28 */   private static int sidx = 0;
/*  28:    */   
/*  29:    */   public ConstantPool(ClassFile classFile, DCCommonState dcCommonState, ByteData raw, short count)
/*  30:    */   {
/*  31: 31 */     this.classFile = classFile;
/*  32: 32 */     this.options = dcCommonState.getOptions();
/*  33: 33 */     ArrayList<ConstantPoolEntry> res = new ArrayList();
/*  34: 34 */     count = (short)(count - 1);
/*  35: 35 */     res.ensureCapacity(count);
/*  36:    */     
/*  37: 37 */     this.length = processRaw(raw, count, res);
/*  38: 38 */     this.entries = res;
/*  39: 39 */     this.dcCommonState = dcCommonState;
/*  40: 40 */     this.classCache = dcCommonState.getClassCache();
/*  41: 41 */     this.isLoaded = true;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public DCCommonState getDCCommonState()
/*  45:    */   {
/*  46: 45 */     return this.dcCommonState;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public boolean isLoaded()
/*  50:    */   {
/*  51: 49 */     return this.isLoaded;
/*  52:    */   }
/*  53:    */   
/*  54:    */   private long processRaw(ByteData raw, short count, List<ConstantPoolEntry> tgt)
/*  55:    */   {
/*  56: 53 */     OffsettingByteData data = raw.getOffsettingOffsetData(0L);
/*  57: 54 */     logger.info("Processing " + count + " constpool entries.");
/*  58: 55 */     for (short x = 0; x < count; x = (short)(x + 1))
/*  59:    */     {
/*  60: 56 */       ConstantPoolEntry.Type type = ConstantPoolEntry.Type.get(data.getS1At(0L));
/*  61:    */       ConstantPoolEntry cpe;
/*  62: 58 */       switch (1.$SwitchMap$org$benf$cfr$reader$entities$constantpool$ConstantPoolEntry$Type[type.ordinal()])
/*  63:    */       {
/*  64:    */       case 1: 
/*  65: 60 */         cpe = new ConstantPoolEntryNameAndType(this, data);
/*  66: 61 */         break;
/*  67:    */       case 2: 
/*  68: 63 */         cpe = new ConstantPoolEntryString(this, data);
/*  69: 64 */         break;
/*  70:    */       case 3: 
/*  71: 66 */         cpe = new ConstantPoolEntryFieldRef(this, data);
/*  72: 67 */         break;
/*  73:    */       case 4: 
/*  74: 69 */         cpe = new ConstantPoolEntryMethodRef(this, data, false);
/*  75: 70 */         break;
/*  76:    */       case 5: 
/*  77: 72 */         cpe = new ConstantPoolEntryMethodRef(this, data, true);
/*  78: 73 */         break;
/*  79:    */       case 6: 
/*  80: 75 */         cpe = new ConstantPoolEntryClass(this, data);
/*  81: 76 */         break;
/*  82:    */       case 7: 
/*  83: 78 */         cpe = new ConstantPoolEntryDouble(this, data);
/*  84: 79 */         break;
/*  85:    */       case 8: 
/*  86: 81 */         cpe = new ConstantPoolEntryFloat(this, data);
/*  87: 82 */         break;
/*  88:    */       case 9: 
/*  89: 84 */         cpe = new ConstantPoolEntryLong(this, data);
/*  90: 85 */         break;
/*  91:    */       case 10: 
/*  92: 87 */         cpe = new ConstantPoolEntryInteger(this, data);
/*  93: 88 */         break;
/*  94:    */       case 11: 
/*  95: 90 */         cpe = new ConstantPoolEntryUTF8(this, data, this.options);
/*  96: 91 */         break;
/*  97:    */       case 12: 
/*  98: 93 */         cpe = new ConstantPoolEntryMethodHandle(this, data);
/*  99: 94 */         break;
/* 100:    */       case 13: 
/* 101: 96 */         cpe = new ConstantPoolEntryMethodType(this, data);
/* 102: 97 */         break;
/* 103:    */       case 14: 
/* 104: 99 */         cpe = new ConstantPoolEntryInvokeDynamic(this, data);
/* 105:100 */         break;
/* 106:    */       default: 
/* 107:102 */         throw new ConfusedCFRException("Invalid constant pool entry : " + type);
/* 108:    */       }
/* 109:104 */       logger.info("" + (x + 1) + " : " + cpe);
/* 110:105 */       tgt.add(cpe);
/* 111:106 */       switch (1.$SwitchMap$org$benf$cfr$reader$entities$constantpool$ConstantPoolEntry$Type[type.ordinal()])
/* 112:    */       {
/* 113:    */       case 7: 
/* 114:    */       case 9: 
/* 115:109 */         tgt.add(null);
/* 116:110 */         x = (short)(x + 1);
/* 117:    */       }
/* 118:114 */       long size = cpe.getRawByteLength();
/* 119:115 */       data.advance(size);
/* 120:    */     }
/* 121:117 */     return data.getOffset();
/* 122:    */   }
/* 123:    */   
/* 124:    */   public long getRawByteLength()
/* 125:    */   {
/* 126:121 */     return this.length;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public ConstantPoolEntry getEntry(int index)
/* 130:    */   {
/* 131:125 */     if (index == 0) {
/* 132:125 */       throw new ConfusedCFRException("Attempt to fetch element 0 from constant pool");
/* 133:    */     }
/* 134:127 */     return (ConstantPoolEntry)this.entries.get(index - 1);
/* 135:    */   }
/* 136:    */   
/* 137:    */   public ConstantPoolEntryUTF8 getUTF8Entry(int index)
/* 138:    */   {
/* 139:131 */     return (ConstantPoolEntryUTF8)getEntry(index);
/* 140:    */   }
/* 141:    */   
/* 142:    */   public ConstantPoolEntryNameAndType getNameAndTypeEntry(int index)
/* 143:    */   {
/* 144:135 */     return (ConstantPoolEntryNameAndType)getEntry(index);
/* 145:    */   }
/* 146:    */   
/* 147:    */   public ConstantPoolEntryMethodHandle getMethodHandleEntry(int index)
/* 148:    */   {
/* 149:139 */     return (ConstantPoolEntryMethodHandle)getEntry(index);
/* 150:    */   }
/* 151:    */   
/* 152:    */   public ConstantPoolEntryMethodRef getMethodRefEntry(int index)
/* 153:    */   {
/* 154:143 */     return (ConstantPoolEntryMethodRef)getEntry(index);
/* 155:    */   }
/* 156:    */   
/* 157:    */   public ConstantPoolEntryClass getClassEntry(int index)
/* 158:    */   {
/* 159:147 */     return (ConstantPoolEntryClass)getEntry(index);
/* 160:    */   }
/* 161:    */   
/* 162:    */   public ClassCache getClassCache()
/* 163:    */   {
/* 164:151 */     return this.classCache;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public boolean equals(Object o)
/* 168:    */   {
/* 169:156 */     getComparisonKey();
/* 170:157 */     if (this == o) {
/* 171:157 */       return true;
/* 172:    */     }
/* 173:158 */     if ((o == null) || (getClass() != o.getClass())) {
/* 174:158 */       return false;
/* 175:    */     }
/* 176:160 */     ConstantPool that = (ConstantPool)o;
/* 177:162 */     if (!this.comparisonKey.equals(that.comparisonKey)) {
/* 178:162 */       return false;
/* 179:    */     }
/* 180:164 */     return true;
/* 181:    */   }
/* 182:    */   
/* 183:    */   public String toString()
/* 184:    */   {
/* 185:169 */     return getComparisonKey() + "[" + this.idx + "]";
/* 186:    */   }
/* 187:    */   
/* 188:    */   public int hashCode()
/* 189:    */   {
/* 190:174 */     return getComparisonKey().hashCode();
/* 191:    */   }
/* 192:    */   
/* 193:    */   private String getComparisonKey()
/* 194:    */   {
/* 195:178 */     if (this.comparisonKey == null) {
/* 196:178 */       this.comparisonKey = this.classFile.getFilePath();
/* 197:    */     }
/* 198:179 */     return this.comparisonKey;
/* 199:    */   }
/* 200:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.constantpool.ConstantPool
 * JD-Core Version:    0.7.0.1
 */