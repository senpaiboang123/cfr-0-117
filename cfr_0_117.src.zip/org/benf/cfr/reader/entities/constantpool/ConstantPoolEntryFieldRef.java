/*  1:   */ package org.benf.cfr.reader.entities.constantpool;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/*  5:   */ import org.benf.cfr.reader.entities.AbstractConstantPoolEntry;
/*  6:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  7:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  8:   */ 
/*  9:   */ public class ConstantPoolEntryFieldRef
/* 10:   */   extends AbstractConstantPoolEntry
/* 11:   */ {
/* 12:   */   private static final long OFFSET_OF_CLASS_INDEX = 1L;
/* 13:   */   private static final long OFFSET_OF_NAME_AND_TYPE_INDEX = 3L;
/* 14:   */   final short classIndex;
/* 15:   */   final short nameAndTypeIndex;
/* 16:   */   JavaTypeInstance cachedDecodedType;
/* 17:   */   
/* 18:   */   public ConstantPoolEntryFieldRef(ConstantPool cp, ByteData data)
/* 19:   */   {
/* 20:18 */     super(cp);
/* 21:19 */     this.classIndex = data.getS2At(1L);
/* 22:20 */     this.nameAndTypeIndex = data.getS2At(3L);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public long getRawByteLength()
/* 26:   */   {
/* 27:25 */     return 5L;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void dump(Dumper d)
/* 31:   */   {
/* 32:30 */     ConstantPool cp = getCp();
/* 33:31 */     d.print("Field " + cp.getNameAndTypeEntry(this.nameAndTypeIndex).getName().getValue() + ":" + getJavaTypeInstance());
/* 34:   */   }
/* 35:   */   
/* 36:   */   public ConstantPoolEntryClass getClassEntry()
/* 37:   */   {
/* 38:37 */     return getCp().getClassEntry(this.classIndex);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public ConstantPoolEntryNameAndType getNameAndTypeEntry()
/* 42:   */   {
/* 43:41 */     return getCp().getNameAndTypeEntry(this.nameAndTypeIndex);
/* 44:   */   }
/* 45:   */   
/* 46:   */   public String getLocalName()
/* 47:   */   {
/* 48:45 */     return getCp().getNameAndTypeEntry(this.nameAndTypeIndex).getName().getValue();
/* 49:   */   }
/* 50:   */   
/* 51:   */   public JavaTypeInstance getJavaTypeInstance()
/* 52:   */   {
/* 53:49 */     if (this.cachedDecodedType == null)
/* 54:   */     {
/* 55:51 */       ConstantPool cp = getCp();
/* 56:52 */       this.cachedDecodedType = ConstantPoolUtils.decodeTypeTok(cp.getNameAndTypeEntry(this.nameAndTypeIndex).getDescriptor().getValue(), cp);
/* 57:   */     }
/* 58:54 */     return this.cachedDecodedType;
/* 59:   */   }
/* 60:   */   
/* 61:   */   public StackType getStackType()
/* 62:   */   {
/* 63:58 */     return getJavaTypeInstance().getStackType();
/* 64:   */   }
/* 65:   */   
/* 66:   */   public String toString()
/* 67:   */   {
/* 68:64 */     return "ConstantPool_FieldRef [classIndex:" + this.classIndex + ", nameAndTypeIndex:" + this.nameAndTypeIndex + "]";
/* 69:   */   }
/* 70:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryFieldRef
 * JD-Core Version:    0.7.0.1
 */