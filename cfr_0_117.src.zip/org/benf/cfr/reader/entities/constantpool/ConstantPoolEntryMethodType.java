/*  1:   */ package org.benf.cfr.reader.entities.constantpool;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.entities.AbstractConstantPoolEntry;
/*  4:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  5:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  6:   */ 
/*  7:   */ public class ConstantPoolEntryMethodType
/*  8:   */   extends AbstractConstantPoolEntry
/*  9:   */ {
/* 10:   */   private static final long OFFSET_OF_DESCRIPTOR_INDEX = 1L;
/* 11:   */   private final short descriptorIndex;
/* 12:   */   
/* 13:   */   public ConstantPoolEntryMethodType(ConstantPool cp, ByteData data)
/* 14:   */   {
/* 15:13 */     super(cp);
/* 16:14 */     this.descriptorIndex = data.getS2At(1L);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public ConstantPool getCp()
/* 20:   */   {
/* 21:18 */     return super.getCp();
/* 22:   */   }
/* 23:   */   
/* 24:   */   public long getRawByteLength()
/* 25:   */   {
/* 26:23 */     return 3L;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void dump(Dumper d)
/* 30:   */   {
/* 31:28 */     d.print(toString());
/* 32:   */   }
/* 33:   */   
/* 34:   */   public ConstantPoolEntryUTF8 getDescriptor()
/* 35:   */   {
/* 36:32 */     return getCp().getUTF8Entry(this.descriptorIndex);
/* 37:   */   }
/* 38:   */   
/* 39:   */   public String toString()
/* 40:   */   {
/* 41:37 */     return "MethodType value=" + this.descriptorIndex;
/* 42:   */   }
/* 43:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodType
 * JD-Core Version:    0.7.0.1
 */