/*  1:   */ package org.benf.cfr.reader.entities.constantpool;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.types.StackType;
/*  4:   */ import org.benf.cfr.reader.entities.AbstractConstantPoolEntry;
/*  5:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  6:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  7:   */ 
/*  8:   */ public class ConstantPoolEntryFloat
/*  9:   */   extends AbstractConstantPoolEntry
/* 10:   */   implements ConstantPoolEntryLiteral
/* 11:   */ {
/* 12:   */   private final float value;
/* 13:   */   
/* 14:   */   public ConstantPoolEntryFloat(ConstantPool cp, ByteData data)
/* 15:   */   {
/* 16:12 */     super(cp);
/* 17:13 */     this.value = data.getFloatAt(1L);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public long getRawByteLength()
/* 21:   */   {
/* 22:18 */     return 5L;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void dump(Dumper d)
/* 26:   */   {
/* 27:23 */     d.print("CONSTANT_Float");
/* 28:   */   }
/* 29:   */   
/* 30:   */   public StackType getStackType()
/* 31:   */   {
/* 32:28 */     return StackType.FLOAT;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public float getValue()
/* 36:   */   {
/* 37:32 */     return this.value;
/* 38:   */   }
/* 39:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryFloat
 * JD-Core Version:    0.7.0.1
 */