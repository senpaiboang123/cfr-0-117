/*  1:   */ package org.benf.cfr.reader.entities.constantpool;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.util.ConfusedCFRException;
/*  4:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  5:   */ 
/*  6:   */ public abstract interface ConstantPoolEntry
/*  7:   */ {
/*  8:   */   public abstract long getRawByteLength();
/*  9:   */   
/* 10:   */   public abstract void dump(Dumper paramDumper);
/* 11:   */   
/* 12:   */   public static enum Type
/* 13:   */   {
/* 14:13 */     CPT_UTF8,  CPT_Integer,  CPT_Float,  CPT_Long,  CPT_Double,  CPT_Class,  CPT_String,  CPT_FieldRef,  CPT_MethodRef,  CPT_InterfaceMethodRef,  CPT_NameAndType,  CPT_MethodHandle,  CPT_MethodType,  CPT_InvokeDynamic;
/* 15:   */     
/* 16:   */     private static final byte VAL_UTF8 = 1;
/* 17:   */     private static final byte VAL_Integer = 3;
/* 18:   */     private static final byte VAL_Float = 4;
/* 19:   */     private static final byte VAL_Long = 5;
/* 20:   */     private static final byte VAL_Double = 6;
/* 21:   */     private static final byte VAL_Class = 7;
/* 22:   */     private static final byte VAL_String = 8;
/* 23:   */     private static final byte VAL_FieldRef = 9;
/* 24:   */     private static final byte VAL_MethodRef = 10;
/* 25:   */     private static final byte VAL_InterfaceMethodRef = 11;
/* 26:   */     private static final byte VAL_NameAndType = 12;
/* 27:   */     private static final byte VAL_MethodHandle = 15;
/* 28:   */     private static final byte VAL_MethodType = 16;
/* 29:   */     private static final byte VAL_InvokeDynamic = 18;
/* 30:   */     
/* 31:   */     private Type() {}
/* 32:   */     
/* 33:   */     public static Type get(byte val)
/* 34:   */     {
/* 35:44 */       switch (val)
/* 36:   */       {
/* 37:   */       case 1: 
/* 38:46 */         return CPT_UTF8;
/* 39:   */       case 3: 
/* 40:48 */         return CPT_Integer;
/* 41:   */       case 4: 
/* 42:50 */         return CPT_Float;
/* 43:   */       case 5: 
/* 44:52 */         return CPT_Long;
/* 45:   */       case 6: 
/* 46:54 */         return CPT_Double;
/* 47:   */       case 7: 
/* 48:56 */         return CPT_Class;
/* 49:   */       case 8: 
/* 50:58 */         return CPT_String;
/* 51:   */       case 9: 
/* 52:60 */         return CPT_FieldRef;
/* 53:   */       case 10: 
/* 54:62 */         return CPT_MethodRef;
/* 55:   */       case 11: 
/* 56:64 */         return CPT_InterfaceMethodRef;
/* 57:   */       case 12: 
/* 58:66 */         return CPT_NameAndType;
/* 59:   */       case 15: 
/* 60:68 */         return CPT_MethodHandle;
/* 61:   */       case 16: 
/* 62:70 */         return CPT_MethodType;
/* 63:   */       case 18: 
/* 64:72 */         return CPT_InvokeDynamic;
/* 65:   */       }
/* 66:74 */       throw new ConfusedCFRException("Invalid constant pool entry type : " + val);
/* 67:   */     }
/* 68:   */   }
/* 69:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry
 * JD-Core Version:    0.7.0.1
 */