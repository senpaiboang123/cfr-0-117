/*  1:   */ package org.benf.cfr.reader.entities.constantpool;
/*  2:   */ 
/*  3:   */ import java.nio.charset.Charset;
/*  4:   */ import org.benf.cfr.reader.entities.AbstractConstantPoolEntry;
/*  5:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  6:   */ import org.benf.cfr.reader.util.getopt.Options;
/*  7:   */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*  8:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  9:   */ 
/* 10:   */ public class ConstantPoolEntryUTF8
/* 11:   */   extends AbstractConstantPoolEntry
/* 12:   */ {
/* 13:13 */   private static final Charset UTF8_CHARSET = Charset.forName("UTF-8");
/* 14:   */   private static final long OFFSET_OF_LENGTH = 1L;
/* 15:   */   private static final long OFFSET_OF_DATA = 3L;
/* 16:   */   private final int length;
/* 17:   */   private final String value;
/* 18:   */   private static int idx;
/* 19:   */   
/* 20:   */   public ConstantPoolEntryUTF8(ConstantPool cp, ByteData data, Options options)
/* 21:   */   {
/* 22:24 */     super(cp);
/* 23:25 */     this.length = data.getU2At(1L);
/* 24:26 */     byte[] bytes = data.getBytesAt(this.length, 3L);
/* 25:27 */     char[] outchars = new char[bytes.length];
/* 26:28 */     String tmpValue = null;
/* 27:29 */     int out = 0;
/* 28:30 */     boolean needsUTF = false;
/* 29:   */     try
/* 30:   */     {
/* 31:32 */       for (int i = 0; i < bytes.length; i++)
/* 32:   */       {
/* 33:33 */         int x = bytes[i];
/* 34:34 */         if ((x & 0x80) == 0)
/* 35:   */         {
/* 36:35 */           outchars[(out++)] = ((char)x);
/* 37:   */         }
/* 38:36 */         else if ((x & 0xE0) == 192)
/* 39:   */         {
/* 40:37 */           int y = bytes[(++i)];
/* 41:38 */           if ((y & 0xC0) == 128)
/* 42:   */           {
/* 43:39 */             int val = ((x & 0x1F) << 6) + (y & 0x3F);
/* 44:40 */             outchars[(out++)] = ((char)val);
/* 45:41 */             needsUTF = true;
/* 46:   */           }
/* 47:   */           else
/* 48:   */           {
/* 49:43 */             throw new IllegalArgumentException();
/* 50:   */           }
/* 51:   */         }
/* 52:45 */         else if ((x & 0xF0) == 224)
/* 53:   */         {
/* 54:46 */           int y = bytes[(++i)];
/* 55:47 */           int z = bytes[(++i)];
/* 56:48 */           if (((y & 0xC0) == 128) && ((z & 0xC0) == 128))
/* 57:   */           {
/* 58:49 */             int val = ((x & 0xF) << 12) + ((y & 0x3F) << 6) + (z & 0x3F);
/* 59:50 */             outchars[(out++)] = ((char)val);
/* 60:51 */             needsUTF = true;
/* 61:   */           }
/* 62:   */           else
/* 63:   */           {
/* 64:53 */             throw new IllegalArgumentException();
/* 65:   */           }
/* 66:   */         }
/* 67:   */         else
/* 68:   */         {
/* 69:56 */           throw new IllegalArgumentException();
/* 70:   */         }
/* 71:   */       }
/* 72:59 */       tmpValue = new String(outchars, 0, out);
/* 73:   */     }
/* 74:   */     catch (IllegalArgumentException e) {}catch (IndexOutOfBoundsException e) {}
/* 75:63 */     if (tmpValue == null) {
/* 76:65 */       tmpValue = new String(bytes, UTF8_CHARSET);
/* 77:   */     }
/* 78:67 */     if ((tmpValue.length() > 512) && (((Boolean)options.getOption(OptionsImpl.HIDE_LONGSTRINGS)).booleanValue())) {
/* 79:68 */       tmpValue = "longStr" + idx++ + "[" + tmpValue.substring(0, 10).replace('\r', '_').replace('\n', '_') + "]";
/* 80:   */     }
/* 81:71 */     this.value = tmpValue;
/* 82:   */   }
/* 83:   */   
/* 84:   */   public long getRawByteLength()
/* 85:   */   {
/* 86:77 */     return 3 + this.length;
/* 87:   */   }
/* 88:   */   
/* 89:   */   public String getValue()
/* 90:   */   {
/* 91:81 */     return this.value;
/* 92:   */   }
/* 93:   */   
/* 94:   */   public void dump(Dumper d)
/* 95:   */   {
/* 96:86 */     d.print("CONSTANT_UTF8 value=" + this.value);
/* 97:   */   }
/* 98:   */   
/* 99:   */   public String toString()
/* :0:   */   {
/* :1:91 */     return "ConstantUTF8[" + this.value + "]";
/* :2:   */   }
/* :3:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryUTF8
 * JD-Core Version:    0.7.0.1
 */