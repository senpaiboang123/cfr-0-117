package org.benf.cfr.reader.entities.constantpool;

import org.benf.cfr.reader.bytecode.analysis.types.StackType;

public abstract interface ConstantPoolEntryLiteral
{
  public abstract StackType getStackType();
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryLiteral
 * JD-Core Version:    0.7.0.1
 */