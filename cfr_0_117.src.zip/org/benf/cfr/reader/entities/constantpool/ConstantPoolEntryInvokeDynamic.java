/*  1:   */ package org.benf.cfr.reader.entities.constantpool;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.entities.AbstractConstantPoolEntry;
/*  4:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  5:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  6:   */ 
/*  7:   */ public class ConstantPoolEntryInvokeDynamic
/*  8:   */   extends AbstractConstantPoolEntry
/*  9:   */ {
/* 10:   */   private static final long OFFSET_OF_BOOTSTRAP_METHOD_ATTR_INDEX = 1L;
/* 11:   */   private static final long OFFSET_OF_NAME_AND_TYPE_INDEX = 3L;
/* 12:   */   private final short bootstrapMethodAttrIndex;
/* 13:   */   private final short nameAndTypeIndex;
/* 14:   */   
/* 15:   */   public ConstantPoolEntryInvokeDynamic(ConstantPool cp, ByteData data)
/* 16:   */   {
/* 17:17 */     super(cp);
/* 18:18 */     this.bootstrapMethodAttrIndex = data.getS2At(1L);
/* 19:19 */     this.nameAndTypeIndex = data.getS2At(3L);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public long getRawByteLength()
/* 23:   */   {
/* 24:24 */     return 5L;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void dump(Dumper d)
/* 28:   */   {
/* 29:29 */     d.print(toString());
/* 30:   */   }
/* 31:   */   
/* 32:   */   public short getBootstrapMethodAttrIndex()
/* 33:   */   {
/* 34:33 */     return this.bootstrapMethodAttrIndex;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public ConstantPoolEntryNameAndType getNameAndTypeEntry()
/* 38:   */   {
/* 39:37 */     return getCp().getNameAndTypeEntry(this.nameAndTypeIndex);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public String toString()
/* 43:   */   {
/* 44:42 */     return "InvokeDynamic value=" + this.bootstrapMethodAttrIndex + "," + this.nameAndTypeIndex;
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryInvokeDynamic
 * JD-Core Version:    0.7.0.1
 */