/*  1:   */ package org.benf.cfr.reader.entities.constantpool;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.stack.StackDelta;
/*  4:   */ import org.benf.cfr.reader.entities.AbstractConstantPoolEntry;
/*  5:   */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  6:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  7:   */ 
/*  8:   */ public class ConstantPoolEntryNameAndType
/*  9:   */   extends AbstractConstantPoolEntry
/* 10:   */ {
/* 11:   */   private static final long OFFSET_OF_NAME_INDEX = 1L;
/* 12:   */   private static final long OFFSET_OF_DESCRIPTOR_INDEX = 3L;
/* 13:   */   private final short nameIndex;
/* 14:   */   private final short descriptorIndex;
/* 15:14 */   private StackDelta[] stackDelta = new StackDelta[2];
/* 16:   */   
/* 17:   */   public ConstantPoolEntryNameAndType(ConstantPool cp, ByteData data)
/* 18:   */   {
/* 19:17 */     super(cp);
/* 20:18 */     this.nameIndex = data.getS2At(1L);
/* 21:19 */     this.descriptorIndex = data.getS2At(3L);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public long getRawByteLength()
/* 25:   */   {
/* 26:24 */     return 5L;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void dump(Dumper d)
/* 30:   */   {
/* 31:29 */     d.print("CONSTANT_NameAndType nameIndex=" + this.nameIndex + ", descriptorIndex=" + this.descriptorIndex);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public String toString()
/* 35:   */   {
/* 36:34 */     return "CONSTANT_NameAndType nameIndex=" + this.nameIndex + ", descriptorIndex=" + this.descriptorIndex;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public ConstantPoolEntryUTF8 getName()
/* 40:   */   {
/* 41:38 */     return getCp().getUTF8Entry(this.nameIndex);
/* 42:   */   }
/* 43:   */   
/* 44:   */   public ConstantPoolEntryUTF8 getDescriptor()
/* 45:   */   {
/* 46:42 */     return getCp().getUTF8Entry(this.descriptorIndex);
/* 47:   */   }
/* 48:   */   
/* 49:   */   public StackDelta getStackDelta(boolean member)
/* 50:   */   {
/* 51:46 */     int idx = member ? 1 : 0;
/* 52:47 */     ConstantPool cp = getCp();
/* 53:48 */     if (this.stackDelta[idx] == null) {
/* 54:49 */       this.stackDelta[idx] = ConstantPoolUtils.parseMethodPrototype(member, cp.getUTF8Entry(this.descriptorIndex), cp);
/* 55:   */     }
/* 56:50 */     return this.stackDelta[idx];
/* 57:   */   }
/* 58:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryNameAndType
 * JD-Core Version:    0.7.0.1
 */