/*  1:   */ package org.benf.cfr.reader.entities.innerclass;
/*  2:   */ 
/*  3:   */ import java.util.Set;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  5:   */ import org.benf.cfr.reader.entities.AccessFlag;
/*  6:   */ import org.benf.cfr.reader.util.annotation.Nullable;
/*  7:   */ 
/*  8:   */ public class InnerClassAttributeInfo
/*  9:   */ {
/* 10:   */   @Nullable
/* 11:   */   private final JavaTypeInstance innerClassInfo;
/* 12:   */   @Nullable
/* 13:   */   private final JavaTypeInstance outerClassInfo;
/* 14:   */   @Nullable
/* 15:   */   private final String innerName;
/* 16:   */   private final Set<AccessFlag> accessFlags;
/* 17:   */   
/* 18:   */   public InnerClassAttributeInfo(JavaTypeInstance innerClassInfo, JavaTypeInstance outerClassInfo, String innerName, Set<AccessFlag> accessFlags)
/* 19:   */   {
/* 20:22 */     this.innerClassInfo = innerClassInfo;
/* 21:23 */     this.outerClassInfo = outerClassInfo;
/* 22:24 */     this.innerName = innerName;
/* 23:25 */     this.accessFlags = accessFlags;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public JavaTypeInstance getInnerClassInfo()
/* 27:   */   {
/* 28:29 */     return this.innerClassInfo;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public JavaTypeInstance getOuterClassInfo()
/* 32:   */   {
/* 33:33 */     return this.outerClassInfo;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public String getInnerName()
/* 37:   */   {
/* 38:37 */     return this.innerName;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public Set<AccessFlag> getAccessFlags()
/* 42:   */   {
/* 43:41 */     return this.accessFlags;
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.innerclass.InnerClassAttributeInfo
 * JD-Core Version:    0.7.0.1
 */