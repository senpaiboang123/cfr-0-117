/*  1:   */ package org.benf.cfr.reader.entities.annotations;
/*  2:   */ 
/*  3:   */ import java.util.Map;
/*  4:   */ import java.util.Map.Entry;
/*  5:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  6:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  7:   */ import org.benf.cfr.reader.util.StringUtils;
/*  8:   */ import org.benf.cfr.reader.util.TypeUsageCollectable;
/*  9:   */ import org.benf.cfr.reader.util.output.Dumper;
/* 10:   */ 
/* 11:   */ public class AnnotationTableEntry
/* 12:   */   implements TypeUsageCollectable
/* 13:   */ {
/* 14:   */   private final JavaTypeInstance clazz;
/* 15:   */   private final Map<String, ElementValue> elementValueMap;
/* 16:   */   private boolean hidden;
/* 17:   */   
/* 18:   */   public AnnotationTableEntry(JavaTypeInstance clazz, Map<String, ElementValue> elementValueMap)
/* 19:   */   {
/* 20:18 */     this.clazz = clazz;
/* 21:19 */     this.elementValueMap = elementValueMap;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void setHidden()
/* 25:   */   {
/* 26:23 */     this.hidden = true;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public boolean isHidden()
/* 30:   */   {
/* 31:27 */     return this.hidden;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public JavaTypeInstance getClazz()
/* 35:   */   {
/* 36:31 */     return this.clazz;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public Dumper dump(Dumper d)
/* 40:   */   {
/* 41:35 */     d.print('@').dump(this.clazz);
/* 42:36 */     if ((this.elementValueMap != null) && (!this.elementValueMap.isEmpty()))
/* 43:   */     {
/* 44:37 */       d.print('(');
/* 45:38 */       boolean first = true;
/* 46:39 */       for (Map.Entry<String, ElementValue> elementValueEntry : this.elementValueMap.entrySet())
/* 47:   */       {
/* 48:40 */         first = StringUtils.comma(first, d);
/* 49:41 */         d.print((String)elementValueEntry.getKey()).print('=');
/* 50:42 */         ((ElementValue)elementValueEntry.getValue()).dump(d);
/* 51:   */       }
/* 52:44 */       d.print(')');
/* 53:   */     }
/* 54:46 */     return d;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 58:   */   {
/* 59:51 */     collector.collect(this.clazz);
/* 60:52 */     if (this.elementValueMap != null) {
/* 61:53 */       for (ElementValue elementValue : this.elementValueMap.values()) {
/* 62:54 */         elementValue.collectTypeUsages(collector);
/* 63:   */       }
/* 64:   */     }
/* 65:   */   }
/* 66:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.annotations.AnnotationTableEntry
 * JD-Core Version:    0.7.0.1
 */