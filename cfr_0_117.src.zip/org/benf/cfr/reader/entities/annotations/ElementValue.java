package org.benf.cfr.reader.entities.annotations;

import org.benf.cfr.reader.util.TypeUsageCollectable;
import org.benf.cfr.reader.util.output.Dumpable;

public abstract interface ElementValue
  extends Dumpable, TypeUsageCollectable
{}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.annotations.ElementValue
 * JD-Core Version:    0.7.0.1
 */