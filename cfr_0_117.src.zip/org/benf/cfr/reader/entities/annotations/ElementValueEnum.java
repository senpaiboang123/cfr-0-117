/*  1:   */ package org.benf.cfr.reader.entities.annotations;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  4:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  5:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  6:   */ 
/*  7:   */ public class ElementValueEnum
/*  8:   */   implements ElementValue
/*  9:   */ {
/* 10:   */   private final JavaTypeInstance type;
/* 11:   */   private final String valueName;
/* 12:   */   
/* 13:   */   public ElementValueEnum(JavaTypeInstance type, String valueName)
/* 14:   */   {
/* 15:12 */     this.type = type;
/* 16:13 */     this.valueName = valueName;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public Dumper dump(Dumper d)
/* 20:   */   {
/* 21:18 */     return d.dump(this.type).print('.').print(this.valueName);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 25:   */   {
/* 26:23 */     collector.collect(this.type);
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.annotations.ElementValueEnum
 * JD-Core Version:    0.7.0.1
 */