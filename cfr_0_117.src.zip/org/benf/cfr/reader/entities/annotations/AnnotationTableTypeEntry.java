/*  1:   */ package org.benf.cfr.reader.entities.annotations;
/*  2:   */ 
/*  3:   */ import java.util.Map;
/*  4:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  5:   */ import org.benf.cfr.reader.entities.attributes.TypeAnnotationEntryKind;
/*  6:   */ import org.benf.cfr.reader.entities.attributes.TypeAnnotationLocation;
/*  7:   */ import org.benf.cfr.reader.entities.attributes.TypeAnnotationTargetInfo;
/*  8:   */ import org.benf.cfr.reader.entities.attributes.TypePath;
/*  9:   */ 
/* 10:   */ public class AnnotationTableTypeEntry<T extends TypeAnnotationTargetInfo>
/* 11:   */   extends AnnotationTableEntry
/* 12:   */ {
/* 13:   */   private final TypeAnnotationEntryKind kind;
/* 14:   */   private final TypeAnnotationLocation location;
/* 15:   */   private final T targetInfo;
/* 16:   */   private final TypePath typePath;
/* 17:   */   
/* 18:   */   public AnnotationTableTypeEntry(TypeAnnotationEntryKind kind, TypeAnnotationLocation location, T targetInfo, TypePath typePath, JavaTypeInstance type, Map<String, ElementValue> elementValueMap)
/* 19:   */   {
/* 20:21 */     super(type, elementValueMap);
/* 21:22 */     this.kind = kind;
/* 22:23 */     this.location = location;
/* 23:24 */     this.targetInfo = targetInfo;
/* 24:25 */     this.typePath = typePath;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public TypePath getTypePath()
/* 28:   */   {
/* 29:29 */     return this.typePath;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public TypeAnnotationEntryKind getKind()
/* 33:   */   {
/* 34:33 */     return this.kind;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public T getTargetInfo()
/* 38:   */   {
/* 39:37 */     return this.targetInfo;
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.annotations.AnnotationTableTypeEntry
 * JD-Core Version:    0.7.0.1
 */