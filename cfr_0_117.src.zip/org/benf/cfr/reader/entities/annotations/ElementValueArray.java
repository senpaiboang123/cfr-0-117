/*  1:   */ package org.benf.cfr.reader.entities.annotations;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  5:   */ import org.benf.cfr.reader.util.StringUtils;
/*  6:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  7:   */ 
/*  8:   */ public class ElementValueArray
/*  9:   */   implements ElementValue
/* 10:   */ {
/* 11:   */   private final List<ElementValue> content;
/* 12:   */   
/* 13:   */   public ElementValueArray(List<ElementValue> content)
/* 14:   */   {
/* 15:13 */     this.content = content;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public Dumper dump(Dumper d)
/* 19:   */   {
/* 20:18 */     d.print('{');
/* 21:19 */     boolean first = true;
/* 22:20 */     for (ElementValue value : this.content)
/* 23:   */     {
/* 24:21 */       first = StringUtils.comma(first, d);
/* 25:22 */       value.dump(d);
/* 26:   */     }
/* 27:24 */     d.print('}');
/* 28:25 */     return d;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 32:   */   {
/* 33:30 */     for (ElementValue e : this.content) {
/* 34:31 */       e.collectTypeUsages(collector);
/* 35:   */     }
/* 36:   */   }
/* 37:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.annotations.ElementValueArray
 * JD-Core Version:    0.7.0.1
 */