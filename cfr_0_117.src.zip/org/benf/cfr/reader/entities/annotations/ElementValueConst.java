/*  1:   */ package org.benf.cfr.reader.entities.annotations;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*  4:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  5:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  6:   */ 
/*  7:   */ public class ElementValueConst
/*  8:   */   implements ElementValue
/*  9:   */ {
/* 10:   */   private final TypedLiteral value;
/* 11:   */   
/* 12:   */   public ElementValueConst(TypedLiteral value)
/* 13:   */   {
/* 14:11 */     this.value = value;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public Dumper dump(Dumper d)
/* 18:   */   {
/* 19:16 */     return d.dump(this.value);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public void collectTypeUsages(TypeUsageCollector collector) {}
/* 23:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.annotations.ElementValueConst
 * JD-Core Version:    0.7.0.1
 */