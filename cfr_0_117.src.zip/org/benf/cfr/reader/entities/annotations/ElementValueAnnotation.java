/*  1:   */ package org.benf.cfr.reader.entities.annotations;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  4:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  5:   */ 
/*  6:   */ public class ElementValueAnnotation
/*  7:   */   implements ElementValue
/*  8:   */ {
/*  9:   */   private final AnnotationTableEntry annotationTableEntry;
/* 10:   */   
/* 11:   */   public ElementValueAnnotation(AnnotationTableEntry annotationTableEntry)
/* 12:   */   {
/* 13:10 */     this.annotationTableEntry = annotationTableEntry;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public Dumper dump(Dumper d)
/* 17:   */   {
/* 18:15 */     return this.annotationTableEntry.dump(d);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 22:   */   {
/* 23:20 */     this.annotationTableEntry.collectTypeUsages(collector);
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.annotations.ElementValueAnnotation
 * JD-Core Version:    0.7.0.1
 */