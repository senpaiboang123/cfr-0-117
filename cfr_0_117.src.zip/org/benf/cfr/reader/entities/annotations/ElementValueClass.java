/*  1:   */ package org.benf.cfr.reader.entities.annotations;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  4:   */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  5:   */ import org.benf.cfr.reader.util.output.Dumper;
/*  6:   */ 
/*  7:   */ public class ElementValueClass
/*  8:   */   implements ElementValue
/*  9:   */ {
/* 10:   */   private final JavaTypeInstance classType;
/* 11:   */   
/* 12:   */   public ElementValueClass(JavaTypeInstance classType)
/* 13:   */   {
/* 14:11 */     this.classType = classType;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public Dumper dump(Dumper d)
/* 18:   */   {
/* 19:16 */     return d.dump(this.classType).print(".class");
/* 20:   */   }
/* 21:   */   
/* 22:   */   public void collectTypeUsages(TypeUsageCollector collector)
/* 23:   */   {
/* 24:21 */     collector.collect(this.classType);
/* 25:   */   }
/* 26:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.annotations.ElementValueClass
 * JD-Core Version:    0.7.0.1
 */