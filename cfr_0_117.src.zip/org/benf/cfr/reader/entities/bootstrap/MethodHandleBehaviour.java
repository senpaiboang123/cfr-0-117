/*  1:   */ package org.benf.cfr.reader.entities.bootstrap;
/*  2:   */ 
/*  3:   */ public enum MethodHandleBehaviour
/*  4:   */ {
/*  5: 4 */   GET_FIELD,  GET_STATIC,  PUT_FIELD,  PUT_STATIC,  INVOKE_VIRTUAL,  INVOKE_STATIC,  INVOKE_SPECIAL,  NEW_INVOKE_SPECIAL,  INVOKE_INTERFACE;
/*  6:   */   
/*  7:   */   private MethodHandleBehaviour() {}
/*  8:   */   
/*  9:   */   public static MethodHandleBehaviour decode(byte value)
/* 10:   */   {
/* 11:15 */     switch (value)
/* 12:   */     {
/* 13:   */     case 1: 
/* 14:17 */       return GET_FIELD;
/* 15:   */     case 2: 
/* 16:19 */       return GET_STATIC;
/* 17:   */     case 3: 
/* 18:21 */       return PUT_FIELD;
/* 19:   */     case 4: 
/* 20:23 */       return PUT_STATIC;
/* 21:   */     case 5: 
/* 22:25 */       return INVOKE_VIRTUAL;
/* 23:   */     case 6: 
/* 24:27 */       return INVOKE_STATIC;
/* 25:   */     case 7: 
/* 26:29 */       return INVOKE_SPECIAL;
/* 27:   */     case 8: 
/* 28:31 */       return NEW_INVOKE_SPECIAL;
/* 29:   */     case 9: 
/* 30:33 */       return INVOKE_INTERFACE;
/* 31:   */     }
/* 32:35 */     throw new IllegalArgumentException("Unknown method handle behaviour " + value);
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.bootstrap.MethodHandleBehaviour
 * JD-Core Version:    0.7.0.1
 */