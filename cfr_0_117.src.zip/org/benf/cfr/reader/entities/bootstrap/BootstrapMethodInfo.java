/*  1:   */ package org.benf.cfr.reader.entities.bootstrap;
/*  2:   */ 
/*  3:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  4:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntry;
/*  5:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodHandle;
/*  6:   */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryMethodRef;
/*  7:   */ 
/*  8:   */ public class BootstrapMethodInfo
/*  9:   */ {
/* 10:   */   private final MethodHandleBehaviour methodHandleBehaviour;
/* 11:   */   private final ConstantPoolEntryMethodRef constantPoolEntryMethodRef;
/* 12:   */   private final ConstantPoolEntry[] bootstrapArguments;
/* 13:   */   
/* 14:   */   public BootstrapMethodInfo(ConstantPoolEntryMethodHandle methodHandle, ConstantPoolEntry[] bootstrapArguments, ConstantPool cp)
/* 15:   */   {
/* 16:21 */     this.methodHandleBehaviour = methodHandle.getReferenceKind();
/* 17:22 */     if ((this.methodHandleBehaviour != MethodHandleBehaviour.INVOKE_STATIC) && (this.methodHandleBehaviour != MethodHandleBehaviour.NEW_INVOKE_SPECIAL)) {
/* 18:24 */       throw new IllegalArgumentException("Expected INVOKE_STATIC / NEWINVOKE_SPECIAL, got " + this.methodHandleBehaviour);
/* 19:   */     }
/* 20:26 */     this.constantPoolEntryMethodRef = methodHandle.getMethodRef();
/* 21:27 */     this.bootstrapArguments = bootstrapArguments;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public ConstantPoolEntryMethodRef getConstantPoolEntryMethodRef()
/* 25:   */   {
/* 26:31 */     return this.constantPoolEntryMethodRef;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public ConstantPoolEntry[] getBootstrapArguments()
/* 30:   */   {
/* 31:35 */     return this.bootstrapArguments;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public MethodHandleBehaviour getMethodHandleBehaviour()
/* 35:   */   {
/* 36:39 */     return this.methodHandleBehaviour;
/* 37:   */   }
/* 38:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.bootstrap.BootstrapMethodInfo
 * JD-Core Version:    0.7.0.1
 */