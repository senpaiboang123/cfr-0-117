/*  1:   */ package org.benf.cfr.reader.entities;
/*  2:   */ 
/*  3:   */ import java.util.EnumSet;
/*  4:   */ import java.util.Map;
/*  5:   */ import java.util.Set;
/*  6:   */ import java.util.TreeSet;
/*  7:   */ import org.benf.cfr.reader.entities.attributes.Attribute;
/*  8:   */ 
/*  9:   */ public enum AccessFlag
/* 10:   */ {
/* 11:12 */   ACC_PUBLIC("public"),  ACC_PRIVATE("private"),  ACC_PROTECTED("protected"),  ACC_STATIC("static"),  ACC_FINAL("final"),  ACC_SUPER("super"),  ACC_VOLATILE("volatile"),  ACC_TRANSIENT("transient"),  ACC_INTERFACE("interface"),  ACC_ABSTRACT("abstract"),  ACC_STRICT("strictfp"),  ACC_SYNTHETIC("/* synthetic */"),  ACC_ANNOTATION("/* annotation */"),  ACC_ENUM("/* enum */");
/* 12:   */   
/* 13:   */   public final String name;
/* 14:   */   
/* 15:   */   private AccessFlag(String name)
/* 16:   */   {
/* 17:30 */     this.name = name;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public static Set<AccessFlag> build(int raw)
/* 21:   */   {
/* 22:34 */     Set<AccessFlag> res = new TreeSet();
/* 23:37 */     if (0 != (raw & 0x1)) {
/* 24:37 */       res.add(ACC_PUBLIC);
/* 25:   */     }
/* 26:38 */     if (0 != (raw & 0x2)) {
/* 27:38 */       res.add(ACC_PRIVATE);
/* 28:   */     }
/* 29:39 */     if (0 != (raw & 0x4)) {
/* 30:39 */       res.add(ACC_PROTECTED);
/* 31:   */     }
/* 32:40 */     if (0 != (raw & 0x8)) {
/* 33:40 */       res.add(ACC_STATIC);
/* 34:   */     }
/* 35:41 */     if (0 != (raw & 0x10)) {
/* 36:41 */       res.add(ACC_FINAL);
/* 37:   */     }
/* 38:42 */     if (0 != (raw & 0x20)) {
/* 39:42 */       res.add(ACC_SUPER);
/* 40:   */     }
/* 41:43 */     if (0 != (raw & 0x40)) {
/* 42:43 */       res.add(ACC_VOLATILE);
/* 43:   */     }
/* 44:44 */     if (0 != (raw & 0x80)) {
/* 45:44 */       res.add(ACC_TRANSIENT);
/* 46:   */     }
/* 47:45 */     if (0 != (raw & 0x200)) {
/* 48:45 */       res.add(ACC_INTERFACE);
/* 49:   */     }
/* 50:46 */     if (0 != (raw & 0x400)) {
/* 51:46 */       res.add(ACC_ABSTRACT);
/* 52:   */     }
/* 53:47 */     if (0 != (raw & 0x1000)) {
/* 54:47 */       res.add(ACC_SYNTHETIC);
/* 55:   */     }
/* 56:48 */     if (0 != (raw & 0x2000)) {
/* 57:48 */       res.add(ACC_ANNOTATION);
/* 58:   */     }
/* 59:49 */     if (0 != (raw & 0x4000)) {
/* 60:49 */       res.add(ACC_ENUM);
/* 61:   */     }
/* 62:51 */     if (res.isEmpty()) {
/* 63:51 */       return res;
/* 64:   */     }
/* 65:52 */     Set<AccessFlag> resaf = EnumSet.copyOf(res);
/* 66:53 */     return resaf;
/* 67:   */   }
/* 68:   */   
/* 69:   */   public String toString()
/* 70:   */   {
/* 71:58 */     return this.name;
/* 72:   */   }
/* 73:   */   
/* 74:   */   public static void applyAttributes(Map<String, Attribute> attributeMap, Set<AccessFlag> accessFlagSet)
/* 75:   */   {
/* 76:62 */     if (attributeMap.containsKey("Synthetic")) {
/* 77:62 */       accessFlagSet.add(ACC_SYNTHETIC);
/* 78:   */     }
/* 79:   */   }
/* 80:   */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.AccessFlag
 * JD-Core Version:    0.7.0.1
 */