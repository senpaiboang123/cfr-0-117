/*   1:    */ package org.benf.cfr.reader.entities;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.Map;
/*   6:    */ import java.util.Set;
/*   7:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral;
/*   8:    */ import org.benf.cfr.reader.bytecode.analysis.parse.literal.TypedLiteral.LiteralType;
/*   9:    */ import org.benf.cfr.reader.bytecode.analysis.types.ClassNameUtils;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.types.RawJavaType;
/*  12:    */ import org.benf.cfr.reader.entities.attributes.Attribute;
/*  13:    */ import org.benf.cfr.reader.entities.attributes.AttributeConstantValue;
/*  14:    */ import org.benf.cfr.reader.entities.attributes.AttributeRuntimeInvisibleAnnotations;
/*  15:    */ import org.benf.cfr.reader.entities.attributes.AttributeRuntimeVisibleAnnotations;
/*  16:    */ import org.benf.cfr.reader.entities.attributes.AttributeSignature;
/*  17:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPool;
/*  18:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolEntryUTF8;
/*  19:    */ import org.benf.cfr.reader.entities.constantpool.ConstantPoolUtils;
/*  20:    */ import org.benf.cfr.reader.entityfactories.AttributeFactory;
/*  21:    */ import org.benf.cfr.reader.entityfactories.ContiguousEntityFactory;
/*  22:    */ import org.benf.cfr.reader.state.TypeUsageCollector;
/*  23:    */ import org.benf.cfr.reader.util.ClassFileVersion;
/*  24:    */ import org.benf.cfr.reader.util.CollectionUtils;
/*  25:    */ import org.benf.cfr.reader.util.KnowsRawSize;
/*  26:    */ import org.benf.cfr.reader.util.TypeUsageCollectable;
/*  27:    */ import org.benf.cfr.reader.util.bytestream.ByteData;
/*  28:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  29:    */ 
/*  30:    */ public class Field
/*  31:    */   implements KnowsRawSize, TypeUsageCollectable
/*  32:    */ {
/*  33:    */   private static final long OFFSET_OF_ACCESS_FLAGS = 0L;
/*  34:    */   private static final long OFFSET_OF_NAME_INDEX = 2L;
/*  35:    */   private static final long OFFSET_OF_DESCRIPTOR_INDEX = 4L;
/*  36:    */   private static final long OFFSET_OF_ATTRIBUTES_COUNT = 6L;
/*  37:    */   private static final long OFFSET_OF_ATTRIBUTES = 8L;
/*  38:    */   private final ConstantPool cp;
/*  39:    */   private final long length;
/*  40:    */   private final short descriptorIndex;
/*  41:    */   private final Set<AccessFlag> accessFlags;
/*  42:    */   private final Map<String, Attribute> attributes;
/*  43:    */   private final TypedLiteral constantValue;
/*  44:    */   private final String fieldName;
/*  45:    */   private boolean disambiguate;
/*  46:    */   private transient JavaTypeInstance cachedDecodedType;
/*  47:    */   
/*  48:    */   public Field(ByteData raw, ConstantPool cp, ClassFileVersion classFileVersion)
/*  49:    */   {
/*  50: 50 */     this.cp = cp;
/*  51: 51 */     this.accessFlags = AccessFlag.build(raw.getS2At(0L));
/*  52: 52 */     short attributes_count = raw.getS2At(6L);
/*  53: 53 */     ArrayList<Attribute> tmpAttributes = new ArrayList();
/*  54: 54 */     tmpAttributes.ensureCapacity(attributes_count);
/*  55: 55 */     long attributesLength = ContiguousEntityFactory.build(raw.getOffsetData(8L), attributes_count, tmpAttributes, AttributeFactory.getBuilder(cp, classFileVersion));
/*  56:    */     
/*  57:    */ 
/*  58: 58 */     this.attributes = ContiguousEntityFactory.addToMap(new HashMap(), tmpAttributes);
/*  59: 59 */     AccessFlag.applyAttributes(this.attributes, this.accessFlags);
/*  60: 60 */     this.descriptorIndex = raw.getS2At(4L);
/*  61: 61 */     short nameIndex = raw.getS2At(2L);
/*  62: 62 */     this.length = (8L + attributesLength);
/*  63: 63 */     Attribute cvAttribute = (Attribute)this.attributes.get("ConstantValue");
/*  64: 64 */     this.fieldName = cp.getUTF8Entry(nameIndex).getValue();
/*  65: 65 */     this.disambiguate = false;
/*  66: 66 */     TypedLiteral constValue = null;
/*  67: 67 */     if (cvAttribute != null)
/*  68:    */     {
/*  69: 68 */       constValue = TypedLiteral.getConstantPoolEntry(cp, ((AttributeConstantValue)cvAttribute).getValue());
/*  70: 69 */       if (constValue.getType() == TypedLiteral.LiteralType.Integer)
/*  71:    */       {
/*  72: 72 */         JavaTypeInstance thisType = getJavaTypeInstance();
/*  73: 73 */         if ((thisType instanceof RawJavaType)) {
/*  74: 74 */           constValue = TypedLiteral.shrinkTo(constValue, (RawJavaType)thisType);
/*  75:    */         }
/*  76:    */       }
/*  77:    */     }
/*  78: 78 */     this.constantValue = constValue;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public long getRawByteLength()
/*  82:    */   {
/*  83: 83 */     return this.length;
/*  84:    */   }
/*  85:    */   
/*  86:    */   private AttributeSignature getSignatureAttribute()
/*  87:    */   {
/*  88: 87 */     Attribute attribute = (Attribute)this.attributes.get("Signature");
/*  89: 88 */     if (attribute == null) {
/*  90: 88 */       return null;
/*  91:    */     }
/*  92: 89 */     return (AttributeSignature)attribute;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public JavaTypeInstance getJavaTypeInstance()
/*  96:    */   {
/*  97: 93 */     if (this.cachedDecodedType == null)
/*  98:    */     {
/*  99: 94 */       AttributeSignature sig = getSignatureAttribute();
/* 100: 95 */       ConstantPoolEntryUTF8 signature = sig == null ? null : sig.getSignature();
/* 101: 96 */       ConstantPoolEntryUTF8 descriptor = this.cp.getUTF8Entry(this.descriptorIndex);
/* 102: 97 */       ConstantPoolEntryUTF8 prototype = null;
/* 103: 98 */       if (signature == null) {
/* 104: 99 */         prototype = descriptor;
/* 105:    */       } else {
/* 106:101 */         prototype = signature;
/* 107:    */       }
/* 108:106 */       this.cachedDecodedType = ConstantPoolUtils.decodeTypeTok(prototype.getValue(), this.cp);
/* 109:    */     }
/* 110:108 */     return this.cachedDecodedType;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public void setDisambiguate()
/* 114:    */   {
/* 115:112 */     this.disambiguate = true;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public String getFieldName()
/* 119:    */   {
/* 120:116 */     if (this.disambiguate) {
/* 121:117 */       return "var_" + ClassNameUtils.getTypeFixPrefix(getJavaTypeInstance()) + this.fieldName;
/* 122:    */     }
/* 123:119 */     return this.fieldName;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public boolean testAccessFlag(AccessFlag accessFlag)
/* 127:    */   {
/* 128:123 */     return this.accessFlags.contains(accessFlag);
/* 129:    */   }
/* 130:    */   
/* 131:    */   public TypedLiteral getConstantValue()
/* 132:    */   {
/* 133:127 */     return this.constantValue;
/* 134:    */   }
/* 135:    */   
/* 136:    */   private <T extends Attribute> T getAttributeByName(String name)
/* 137:    */   {
/* 138:131 */     Attribute attribute = (Attribute)this.attributes.get(name);
/* 139:132 */     if (attribute == null) {
/* 140:132 */       return null;
/* 141:    */     }
/* 142:134 */     T tmp = attribute;
/* 143:135 */     return tmp;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public void collectTypeUsages(TypeUsageCollector collector)
/* 147:    */   {
/* 148:140 */     collector.collect(getJavaTypeInstance());
/* 149:141 */     collector.collectFrom(getAttributeByName("RuntimeVisibleAnnotations"));
/* 150:142 */     collector.collectFrom(getAttributeByName("RuntimeInvisibleAnnotations"));
/* 151:    */   }
/* 152:    */   
/* 153:    */   public void dump(Dumper d, String name)
/* 154:    */   {
/* 155:146 */     AttributeRuntimeVisibleAnnotations runtimeVisibleAnnotations = (AttributeRuntimeVisibleAnnotations)getAttributeByName("RuntimeVisibleAnnotations");
/* 156:147 */     AttributeRuntimeInvisibleAnnotations runtimeInvisibleAnnotations = (AttributeRuntimeInvisibleAnnotations)getAttributeByName("RuntimeInvisibleAnnotations");
/* 157:148 */     if (runtimeVisibleAnnotations != null) {
/* 158:148 */       runtimeVisibleAnnotations.dump(d);
/* 159:    */     }
/* 160:149 */     if (runtimeInvisibleAnnotations != null) {
/* 161:149 */       runtimeInvisibleAnnotations.dump(d);
/* 162:    */     }
/* 163:150 */     String prefix = CollectionUtils.join(this.accessFlags, " ");
/* 164:151 */     if (!prefix.isEmpty()) {
/* 165:152 */       d.print(prefix).print(' ');
/* 166:    */     }
/* 167:154 */     JavaTypeInstance type = getJavaTypeInstance();
/* 168:155 */     d.dump(type).print(' ').identifier(name);
/* 169:    */   }
/* 170:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.entities.Field
 * JD-Core Version:    0.7.0.1
 */