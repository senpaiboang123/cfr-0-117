/*   1:    */ package org.benf.cfr.reader;
/*   2:    */ 
/*   3:    */ import java.util.Map;
/*   4:    */ import org.benf.cfr.reader.api.ClassFileSource;
/*   5:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*   6:    */ import org.benf.cfr.reader.entities.Method;
/*   7:    */ import org.benf.cfr.reader.state.ClassFileSourceImpl;
/*   8:    */ import org.benf.cfr.reader.state.DCCommonState;
/*   9:    */ import org.benf.cfr.reader.state.TypeUsageInformation;
/*  10:    */ import org.benf.cfr.reader.util.MapFactory;
/*  11:    */ import org.benf.cfr.reader.util.getopt.Options;
/*  12:    */ import org.benf.cfr.reader.util.getopt.OptionsImpl;
/*  13:    */ import org.benf.cfr.reader.util.output.Dumper;
/*  14:    */ import org.benf.cfr.reader.util.output.DumperFactory;
/*  15:    */ import org.benf.cfr.reader.util.output.FileSummaryDumper;
/*  16:    */ import org.benf.cfr.reader.util.output.IllegalIdentifierDump;
/*  17:    */ import org.benf.cfr.reader.util.output.IllegalIdentifierDump.Nop;
/*  18:    */ import org.benf.cfr.reader.util.output.NopSummaryDumper;
/*  19:    */ import org.benf.cfr.reader.util.output.StreamDumper;
/*  20:    */ import org.benf.cfr.reader.util.output.SummaryDumper;
/*  21:    */ 
/*  22:    */ public class PluginRunner
/*  23:    */ {
/*  24:    */   private final DCCommonState dcCommonState;
/*  25: 20 */   private final IllegalIdentifierDump illegalIdentifierDump = new IllegalIdentifierDump.Nop();
/*  26:    */   private final ClassFileSource classFileSource;
/*  27:    */   
/*  28:    */   public PluginRunner()
/*  29:    */   {
/*  30: 27 */     this(MapFactory.newMap(), null);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public PluginRunner(Map<String, String> options)
/*  34:    */   {
/*  35: 31 */     this(options, null);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public PluginRunner(Map<String, String> options, ClassFileSource classFileSource)
/*  39:    */   {
/*  40: 35 */     this.dcCommonState = initDCState(options, classFileSource);
/*  41: 36 */     this.classFileSource = classFileSource;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public Options getOptions()
/*  45:    */   {
/*  46: 40 */     return this.dcCommonState.getOptions();
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void addJarPaths(String[] jarPaths)
/*  50:    */   {
/*  51: 44 */     for (String jarPath : jarPaths) {
/*  52: 45 */       addJarPath(jarPath);
/*  53:    */     }
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void addJarPath(String jarPath)
/*  57:    */   {
/*  58:    */     try
/*  59:    */     {
/*  60: 51 */       this.dcCommonState.explicitlyLoadJar(jarPath);
/*  61:    */     }
/*  62:    */     catch (Exception e) {}
/*  63:    */   }
/*  64:    */   
/*  65:    */   class StringStreamDumper
/*  66:    */     extends StreamDumper
/*  67:    */   {
/*  68:    */     private final StringBuilder stringBuilder;
/*  69:    */     
/*  70:    */     public StringStreamDumper(StringBuilder sb, TypeUsageInformation typeUsageInformation, Options options)
/*  71:    */     {
/*  72: 60 */       super(options, PluginRunner.this.illegalIdentifierDump);
/*  73: 61 */       this.stringBuilder = sb;
/*  74:    */     }
/*  75:    */     
/*  76:    */     protected void write(String s)
/*  77:    */     {
/*  78: 66 */       this.stringBuilder.append(s);
/*  79:    */     }
/*  80:    */     
/*  81:    */     public void close() {}
/*  82:    */     
/*  83:    */     public void addSummaryError(Method method, String s) {}
/*  84:    */   }
/*  85:    */   
/*  86:    */   private class PluginDumperFactory
/*  87:    */     implements DumperFactory
/*  88:    */   {
/*  89:    */     private final StringBuilder outBuffer;
/*  90:    */     
/*  91:    */     public PluginDumperFactory(StringBuilder out)
/*  92:    */     {
/*  93: 83 */       this.outBuffer = out;
/*  94:    */     }
/*  95:    */     
/*  96:    */     public Dumper getNewTopLevelDumper(Options options, JavaTypeInstance classType, SummaryDumper summaryDumper, TypeUsageInformation typeUsageInformation, IllegalIdentifierDump illegalIdentifierDump)
/*  97:    */     {
/*  98: 87 */       return new PluginRunner.StringStreamDumper(PluginRunner.this, this.outBuffer, typeUsageInformation, options);
/*  99:    */     }
/* 100:    */     
/* 101:    */     public SummaryDumper getSummaryDumper(Options options)
/* 102:    */     {
/* 103: 94 */       if (!options.optionIsSet(OptionsImpl.OUTPUT_DIR)) {
/* 104: 94 */         return new NopSummaryDumper();
/* 105:    */       }
/* 106: 96 */       return new FileSummaryDumper((String)options.getOption(OptionsImpl.OUTPUT_DIR));
/* 107:    */     }
/* 108:    */   }
/* 109:    */   
/* 110:    */   public String getDecompilationFor(String classFilePath)
/* 111:    */   {
/* 112:    */     try
/* 113:    */     {
/* 114:102 */       StringBuilder output = new StringBuilder();
/* 115:103 */       DumperFactory dumperFactory = new PluginDumperFactory(output);
/* 116:104 */       Main.doClass(this.dcCommonState, classFilePath, dumperFactory);
/* 117:105 */       return output.toString();
/* 118:    */     }
/* 119:    */     catch (Exception e)
/* 120:    */     {
/* 121:107 */       return e.toString();
/* 122:    */     }
/* 123:    */   }
/* 124:    */   
/* 125:    */   private static DCCommonState initDCState(Map<String, String> optionsMap, ClassFileSource classFileSource)
/* 126:    */   {
/* 127:112 */     OptionsImpl options = new OptionsImpl(null, null, optionsMap);
/* 128:113 */     if (classFileSource == null) {
/* 129:113 */       classFileSource = new ClassFileSourceImpl(options);
/* 130:    */     }
/* 131:114 */     DCCommonState dcCommonState = new DCCommonState(options, classFileSource);
/* 132:115 */     return dcCommonState;
/* 133:    */   }
/* 134:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.PluginRunner
 * JD-Core Version:    0.7.0.1
 */