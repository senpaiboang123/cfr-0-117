/*   1:    */ package org.benf.cfr.reader.relationship;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Map.Entry;
/*   8:    */ import java.util.Set;
/*   9:    */ import java.util.Stack;
/*  10:    */ import org.benf.cfr.reader.bytecode.analysis.types.BindingSuperContainer;
/*  11:    */ import org.benf.cfr.reader.bytecode.analysis.types.ClassNameUtils;
/*  12:    */ import org.benf.cfr.reader.bytecode.analysis.types.ClassSignature;
/*  13:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaGenericBaseInstance;
/*  14:    */ import org.benf.cfr.reader.bytecode.analysis.types.JavaTypeInstance;
/*  15:    */ import org.benf.cfr.reader.bytecode.analysis.types.MethodPrototype;
/*  16:    */ import org.benf.cfr.reader.entities.AccessFlagMethod;
/*  17:    */ import org.benf.cfr.reader.entities.ClassFile;
/*  18:    */ import org.benf.cfr.reader.entities.Method;
/*  19:    */ import org.benf.cfr.reader.state.DCCommonState;
/*  20:    */ import org.benf.cfr.reader.util.CannotLoadClassException;
/*  21:    */ import org.benf.cfr.reader.util.Functional;
/*  22:    */ import org.benf.cfr.reader.util.ListFactory;
/*  23:    */ import org.benf.cfr.reader.util.MapFactory;
/*  24:    */ import org.benf.cfr.reader.util.SetFactory;
/*  25:    */ import org.benf.cfr.reader.util.SetUtil;
/*  26:    */ import org.benf.cfr.reader.util.StackFactory;
/*  27:    */ import org.benf.cfr.reader.util.functors.UnaryFunction;
/*  28:    */ 
/*  29:    */ public class MemberNameResolver
/*  30:    */ {
/*  31:    */   private final DCCommonState dcCommonState;
/*  32:    */   
/*  33:    */   public static void resolveNames(DCCommonState dcCommonState, Collection<? extends JavaTypeInstance> types)
/*  34:    */   {
/*  35: 15 */     MemberNameResolver self = new MemberNameResolver(dcCommonState);
/*  36: 16 */     self.initialise(types);
/*  37: 17 */     self.resolve();
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static boolean verifySingleClassNames(ClassFile oneClassFile)
/*  41:    */   {
/*  42: 21 */     MemberInfo memberInfo = new MemberInfo(oneClassFile, null);
/*  43: 23 */     for (Method method : oneClassFile.getMethods()) {
/*  44: 24 */       if ((!method.isHiddenFromDisplay()) && (!method.testAccessFlag(AccessFlagMethod.ACC_BRIDGE)) && (!method.testAccessFlag(AccessFlagMethod.ACC_SYNTHETIC))) {
/*  45: 28 */         memberInfo.add(method);
/*  46:    */       }
/*  47:    */     }
/*  48: 30 */     return memberInfo.hasClashes();
/*  49:    */   }
/*  50:    */   
/*  51: 34 */   private final transient UnaryFunction<ClassFile, Set<ClassFile>> mapFactory = new UnaryFunction()
/*  52:    */   {
/*  53:    */     public Set<ClassFile> invoke(ClassFile arg)
/*  54:    */     {
/*  55: 37 */       return SetFactory.newOrderedSet();
/*  56:    */     }
/*  57:    */   };
/*  58: 40 */   private final Map<ClassFile, Set<ClassFile>> childToParent = MapFactory.newLazyMap(this.mapFactory);
/*  59: 41 */   private final Map<ClassFile, Set<ClassFile>> parentToChild = MapFactory.newLazyMap(this.mapFactory);
/*  60: 42 */   private final Map<ClassFile, MemberInfo> infoMap = MapFactory.newIdentityMap();
/*  61:    */   
/*  62:    */   private MemberNameResolver(DCCommonState dcCommonState)
/*  63:    */   {
/*  64: 46 */     this.dcCommonState = dcCommonState;
/*  65:    */   }
/*  66:    */   
/*  67:    */   private ClassFile classFileOrNull(JavaTypeInstance type)
/*  68:    */   {
/*  69:    */     try
/*  70:    */     {
/*  71: 51 */       return this.dcCommonState.getClassFile(type);
/*  72:    */     }
/*  73:    */     catch (CannotLoadClassException e) {}
/*  74: 53 */     return null;
/*  75:    */   }
/*  76:    */   
/*  77:    */   private void initialise(Collection<? extends JavaTypeInstance> types)
/*  78:    */   {
/*  79: 58 */     List<ClassFile> classFiles = ListFactory.newList();
/*  80: 59 */     for (JavaTypeInstance type : types) {
/*  81:    */       try
/*  82:    */       {
/*  83: 61 */         classFiles.add(this.dcCommonState.getClassFile(type));
/*  84:    */       }
/*  85:    */       catch (CannotLoadClassException e) {}
/*  86:    */     }
/*  87: 71 */     for (Iterator i$ = classFiles.iterator(); i$.hasNext();)
/*  88:    */     {
/*  89: 71 */       classFile = (ClassFile)i$.next();
/*  90: 72 */       ClassSignature signature = classFile.getClassSignature();
/*  91: 73 */       if (signature != null)
/*  92:    */       {
/*  93: 74 */         JavaTypeInstance superClass = signature.getSuperClass();
/*  94: 75 */         if (superClass != null)
/*  95:    */         {
/*  96: 76 */           ClassFile base = classFileOrNull(superClass);
/*  97: 77 */           if (base != null)
/*  98:    */           {
/*  99: 78 */             ((Set)this.childToParent.get(classFile)).add(base);
/* 100: 79 */             ((Set)this.parentToChild.get(base)).add(classFile);
/* 101:    */           }
/* 102: 81 */           for (JavaTypeInstance interfac : signature.getInterfaces())
/* 103:    */           {
/* 104: 82 */             ClassFile iface = classFileOrNull(interfac);
/* 105: 83 */             if (iface != null)
/* 106:    */             {
/* 107: 84 */               ((Set)this.childToParent.get(classFile)).add(iface);
/* 108: 85 */               ((Set)this.parentToChild.get(iface)).add(classFile);
/* 109:    */             }
/* 110:    */           }
/* 111:    */         }
/* 112:    */       }
/* 113:    */     }
/* 114:    */     ClassFile classFile;
/* 115: 90 */     for (ClassFile classFile : classFiles)
/* 116:    */     {
/* 117: 91 */       MemberInfo memberInfo = new MemberInfo(classFile, null);
/* 118: 93 */       for (Method method : classFile.getMethods()) {
/* 119: 94 */         memberInfo.add(method);
/* 120:    */       }
/* 121: 96 */       this.infoMap.put(classFile, memberInfo);
/* 122:    */     }
/* 123:    */   }
/* 124:    */   
/* 125:    */   private void resolve()
/* 126:    */   {
/* 127:104 */     List<ClassFile> roots = SetUtil.differenceAtakeBtoList(this.parentToChild.keySet(), this.childToParent.keySet());
/* 128:105 */     for (ClassFile root : roots) {
/* 129:106 */       checkBadNames(root);
/* 130:    */     }
/* 131:113 */     insertParentClashes();
/* 132:118 */     for (ClassFile root : roots) {
/* 133:119 */       rePushBadNames(root);
/* 134:    */     }
/* 135:127 */     patchBadNames();
/* 136:    */   }
/* 137:    */   
/* 138:    */   private void patchBadNames()
/* 139:    */   {
/* 140:131 */     Collection<MemberInfo> memberInfos = this.infoMap.values();
/* 141:132 */     for (Iterator i$ = memberInfos.iterator(); i$.hasNext();)
/* 142:    */     {
/* 143:132 */       memberInfo = (MemberInfo)i$.next();
/* 144:133 */       if (memberInfo.hasClashes())
/* 145:    */       {
/* 146:134 */         Set<MethodKey> clashes = memberInfo.getClashes();
/* 147:135 */         for (MethodKey clashKey : clashes)
/* 148:    */         {
/* 149:136 */           Map<JavaTypeInstance, Collection<Method>> clashMap = memberInfo.getClashedMethodsFor(clashKey);
/* 150:137 */           for (i$ = clashMap.entrySet().iterator(); i$.hasNext();)
/* 151:    */           {
/* 152:137 */             clashByType = (Map.Entry)i$.next();
/* 153:138 */             resolvedName = null;
/* 154:139 */             for (Method method : (Collection)clashByType.getValue())
/* 155:    */             {
/* 156:140 */               MethodPrototype methodPrototype = method.getMethodPrototype();
/* 157:141 */               if (methodPrototype.hasNameBeenFixed())
/* 158:    */               {
/* 159:142 */                 if (resolvedName == null) {
/* 160:142 */                   resolvedName = methodPrototype.getFixedName();
/* 161:    */                 }
/* 162:    */               }
/* 163:    */               else
/* 164:    */               {
/* 165:146 */                 if (resolvedName == null) {
/* 166:147 */                   resolvedName = ClassNameUtils.getTypeFixPrefix((JavaTypeInstance)clashByType.getKey()) + methodPrototype.getName();
/* 167:    */                 }
/* 168:149 */                 methodPrototype.setFixedName(resolvedName);
/* 169:    */               }
/* 170:    */             }
/* 171:    */           }
/* 172:    */         }
/* 173:    */       }
/* 174:    */     }
/* 175:    */     MemberInfo memberInfo;
/* 176:    */     Iterator i$;
/* 177:    */     Map.Entry<JavaTypeInstance, Collection<Method>> clashByType;
/* 178:    */     String resolvedName;
/* 179:    */   }
/* 180:    */   
/* 181:    */   private void insertParentClashes()
/* 182:    */   {
/* 183:158 */     for (Iterator i$ = this.infoMap.values().iterator(); i$.hasNext();)
/* 184:    */     {
/* 185:158 */       memberInfo = (MemberInfo)i$.next();
/* 186:159 */       if (memberInfo.hasClashes())
/* 187:    */       {
/* 188:160 */         Set<MethodKey> clashes = memberInfo.getClashes();
/* 189:161 */         for (i$ = clashes.iterator(); i$.hasNext();)
/* 190:    */         {
/* 191:161 */           clash = (MethodKey)i$.next();
/* 192:162 */           for (Collection<Method> methodList : memberInfo.getClashedMethodsFor(clash).values()) {
/* 193:163 */             for (Method method : methodList) {
/* 194:164 */               ((MemberInfo)this.infoMap.get(method.getClassFile())).addClash(clash);
/* 195:    */             }
/* 196:    */           }
/* 197:    */         }
/* 198:    */       }
/* 199:    */     }
/* 200:    */     MemberInfo memberInfo;
/* 201:    */     Iterator i$;
/* 202:    */     MethodKey clash;
/* 203:    */   }
/* 204:    */   
/* 205:    */   private void rePushBadNames(ClassFile c)
/* 206:    */   {
/* 207:177 */     Stack<ClassFile> parents = StackFactory.newStack();
/* 208:178 */     Set<MethodKey> clashes = SetFactory.newSet();
/* 209:179 */     rePushBadNames(c, clashes, parents);
/* 210:    */   }
/* 211:    */   
/* 212:    */   private void rePushBadNames(ClassFile c, Set<MethodKey> clashes, Stack<ClassFile> parents)
/* 213:    */   {
/* 214:183 */     MemberInfo memberInfo = (MemberInfo)this.infoMap.get(c);
/* 215:184 */     if (memberInfo != null)
/* 216:    */     {
/* 217:185 */       memberInfo.addClashes(clashes);
/* 218:186 */       if (!memberInfo.getClashes().isEmpty())
/* 219:    */       {
/* 220:187 */         clashes = SetFactory.newSet(clashes);
/* 221:188 */         clashes.addAll(memberInfo.getClashes());
/* 222:    */       }
/* 223:    */     }
/* 224:192 */     parents.push(c);
/* 225:193 */     for (ClassFile child : (Set)this.parentToChild.get(c)) {
/* 226:194 */       rePushBadNames(child, clashes, parents);
/* 227:    */     }
/* 228:196 */     parents.pop();
/* 229:    */   }
/* 230:    */   
/* 231:    */   private void checkBadNames(ClassFile c)
/* 232:    */   {
/* 233:201 */     Stack<ClassFile> parents = StackFactory.newStack();
/* 234:202 */     MemberInfo base = new MemberInfo(null, null);
/* 235:203 */     checkBadNames(c, base, parents);
/* 236:    */   }
/* 237:    */   
/* 238:    */   private void checkBadNames(ClassFile c, MemberInfo inherited, Stack<ClassFile> parents)
/* 239:    */   {
/* 240:208 */     MemberInfo memberInfo = (MemberInfo)this.infoMap.get(c);
/* 241:209 */     if (memberInfo == null) {
/* 242:210 */       memberInfo = inherited;
/* 243:    */     } else {
/* 244:212 */       memberInfo.inheritFrom(inherited);
/* 245:    */     }
/* 246:215 */     parents.push(c);
/* 247:216 */     for (ClassFile child : (Set)this.parentToChild.get(c)) {
/* 248:217 */       checkBadNames(child, memberInfo, parents);
/* 249:    */     }
/* 250:219 */     parents.pop();
/* 251:    */   }
/* 252:    */   
/* 253:    */   private static class MemberInfo
/* 254:    */   {
/* 255:    */     private final ClassFile classFile;
/* 256:226 */     private final Map<MemberNameResolver.MethodKey, Map<JavaTypeInstance, Collection<Method>>> knownMethods = MapFactory.newLazyMap(new UnaryFunction()
/* 257:    */     {
/* 258:    */       public Map<JavaTypeInstance, Collection<Method>> invoke(MemberNameResolver.MethodKey arg)
/* 259:    */       {
/* 260:229 */         MapFactory.newLazyMap(new UnaryFunction()
/* 261:    */         {
/* 262:    */           public Collection<Method> invoke(JavaTypeInstance arg)
/* 263:    */           {
/* 264:232 */             return SetFactory.newOrderedSet();
/* 265:    */           }
/* 266:    */         });
/* 267:    */       }
/* 268:226 */     });
/* 269:237 */     private final Set<MemberNameResolver.MethodKey> clashes = SetFactory.newSet();
/* 270:    */     
/* 271:    */     private MemberInfo(ClassFile classFile)
/* 272:    */     {
/* 273:240 */       this.classFile = classFile;
/* 274:    */     }
/* 275:    */     
/* 276:    */     public void add(Method method)
/* 277:    */     {
/* 278:246 */       if (method.isConstructor()) {
/* 279:246 */         return;
/* 280:    */       }
/* 281:248 */       MethodPrototype prototype = method.getMethodPrototype();
/* 282:249 */       String name = prototype.getName();
/* 283:250 */       List<JavaTypeInstance> args = Functional.map(prototype.getArgs(), new UnaryFunction()
/* 284:    */       {
/* 285:    */         public JavaTypeInstance invoke(JavaTypeInstance arg)
/* 286:    */         {
/* 287:253 */           return arg.getDeGenerifiedType();
/* 288:    */         }
/* 289:255 */       });
/* 290:256 */       MemberNameResolver.MethodKey methodKey = new MemberNameResolver.MethodKey(name, args, null);
/* 291:257 */       JavaTypeInstance type = prototype.getReturnType();
/* 292:258 */       if ((type instanceof JavaGenericBaseInstance)) {
/* 293:258 */         return;
/* 294:    */       }
/* 295:259 */       add(methodKey, prototype.getReturnType(), method, false);
/* 296:    */     }
/* 297:    */     
/* 298:    */     private void add(MemberNameResolver.MethodKey key1, JavaTypeInstance key2, Method method, boolean fromParent)
/* 299:    */     {
/* 300:263 */       Map<JavaTypeInstance, Collection<Method>> methods = (Map)this.knownMethods.get(key1);
/* 301:264 */       if (method.isHiddenFromDisplay()) {
/* 302:264 */         return;
/* 303:    */       }
/* 304:265 */       if ((fromParent) && (!methods.containsKey(key2)) && (!methods.isEmpty())) {
/* 305:267 */         if (methods.keySet().size() == 1)
/* 306:    */         {
/* 307:268 */           JavaTypeInstance existing = (JavaTypeInstance)methods.keySet().iterator().next();
/* 308:269 */           BindingSuperContainer supers = existing.getBindingSupers();
/* 309:270 */           if ((supers != null) && (supers.containsBase(key2))) {
/* 310:271 */             key2 = existing;
/* 311:    */           }
/* 312:    */         }
/* 313:    */       }
/* 314:275 */       ((Collection)methods.get(key2)).add(method);
/* 315:276 */       if (methods.size() > 1) {
/* 316:277 */         this.clashes.add(key1);
/* 317:    */       }
/* 318:    */     }
/* 319:    */     
/* 320:    */     public boolean hasClashes()
/* 321:    */     {
/* 322:282 */       return !this.clashes.isEmpty();
/* 323:    */     }
/* 324:    */     
/* 325:    */     public Set<MemberNameResolver.MethodKey> getClashes()
/* 326:    */     {
/* 327:286 */       return this.clashes;
/* 328:    */     }
/* 329:    */     
/* 330:    */     public void addClashes(Set<MemberNameResolver.MethodKey> newClashes)
/* 331:    */     {
/* 332:290 */       this.clashes.addAll(newClashes);
/* 333:    */     }
/* 334:    */     
/* 335:    */     public void addClash(MemberNameResolver.MethodKey clash)
/* 336:    */     {
/* 337:294 */       this.clashes.add(clash);
/* 338:    */     }
/* 339:    */     
/* 340:    */     public Map<JavaTypeInstance, Collection<Method>> getClashedMethodsFor(MemberNameResolver.MethodKey key)
/* 341:    */     {
/* 342:298 */       return (Map)this.knownMethods.get(key);
/* 343:    */     }
/* 344:    */     
/* 345:    */     public void inheritFrom(MemberInfo base)
/* 346:    */     {
/* 347:302 */       for (Map.Entry<MemberNameResolver.MethodKey, Map<JavaTypeInstance, Collection<Method>>> entry : base.knownMethods.entrySet())
/* 348:    */       {
/* 349:303 */         key = (MemberNameResolver.MethodKey)entry.getKey();
/* 350:304 */         for (Map.Entry<JavaTypeInstance, Collection<Method>> entry2 : ((Map)entry.getValue()).entrySet())
/* 351:    */         {
/* 352:305 */           returnType = (JavaTypeInstance)entry2.getKey();
/* 353:306 */           Collection<Method> methods = (Collection)entry2.getValue();
/* 354:310 */           for (Method method : methods) {
/* 355:311 */             if (method.isVisibleTo(this.classFile.getRefClasstype())) {
/* 356:312 */               add(key, returnType, method, true);
/* 357:    */             }
/* 358:    */           }
/* 359:    */         }
/* 360:    */       }
/* 361:    */       MemberNameResolver.MethodKey key;
/* 362:    */       JavaTypeInstance returnType;
/* 363:    */     }
/* 364:    */     
/* 365:    */     public String toString()
/* 366:    */     {
/* 367:321 */       return "" + this.classFile;
/* 368:    */     }
/* 369:    */   }
/* 370:    */   
/* 371:    */   private static class MethodKey
/* 372:    */   {
/* 373:    */     private final String name;
/* 374:    */     private final List<JavaTypeInstance> args;
/* 375:    */     
/* 376:    */     private MethodKey(String name, List<JavaTypeInstance> args)
/* 377:    */     {
/* 378:330 */       this.name = name;
/* 379:331 */       this.args = args;
/* 380:    */     }
/* 381:    */     
/* 382:    */     public boolean equals(Object o)
/* 383:    */     {
/* 384:336 */       if (this == o) {
/* 385:336 */         return true;
/* 386:    */       }
/* 387:337 */       if ((o == null) || (getClass() != o.getClass())) {
/* 388:337 */         return false;
/* 389:    */       }
/* 390:339 */       MethodKey methodKey = (MethodKey)o;
/* 391:341 */       if (!this.args.equals(methodKey.args)) {
/* 392:341 */         return false;
/* 393:    */       }
/* 394:342 */       if (!this.name.equals(methodKey.name)) {
/* 395:342 */         return false;
/* 396:    */       }
/* 397:344 */       return true;
/* 398:    */     }
/* 399:    */     
/* 400:    */     public int hashCode()
/* 401:    */     {
/* 402:349 */       int result = this.name.hashCode();
/* 403:350 */       result = 31 * result + this.args.hashCode();
/* 404:351 */       return result;
/* 405:    */     }
/* 406:    */     
/* 407:    */     public String toString()
/* 408:    */     {
/* 409:356 */       return "MethodKey{name='" + this.name + '\'' + ", args=" + this.args + '}';
/* 410:    */     }
/* 411:    */   }
/* 412:    */ }


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.relationship.MemberNameResolver
 * JD-Core Version:    0.7.0.1
 */