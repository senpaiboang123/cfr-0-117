package org.benf.cfr.reader.api;

import java.io.IOException;
import java.util.Collection;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;

public abstract interface ClassFileSource
{
  public abstract void informAnalysisRelativePathDetail(String paramString1, String paramString2);
  
  public abstract Collection<String> addJar(String paramString);
  
  public abstract Pair<byte[], String> getClassFileContent(String paramString)
    throws IOException;
}


/* Location:           C:\Users\PC\Desktop\app\libs\cfr_0_117.jar
 * Qualified Name:     org.benf.cfr.reader.api.ClassFileSource
 * JD-Core Version:    0.7.0.1
 */